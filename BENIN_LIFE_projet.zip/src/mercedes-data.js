// Mission 026 — collection privée de Mercedes-Benz du joueur (garage souterrain de la VILLA NOVA).
// Noms de MODÈLES RÉELS commercialisés par Mercedes-Benz, cités à titre descriptif : la collection est fictive (jeu),
// non affiliée à Mercedes-Benz, sans partenariat ; le logo officiel (marque déposée) n'est pas reproduit.
// Silhouettes procédurales construites à partir des dimensions approximatives de chaque modèle (stylisées, sans
// reproduction exacte de carrosserie). Performances et valeurs : données de JEU approximatives (pas des fiches officielles).
// Profils : z = longueur (avant positif), y = hauteur ; mêmes champs que cars-data.js (compatibles avec GarageCar).

const MB = { noir: 0x0c0d0f, blanc: 0xf2f2ef, argent: 0xb9bdc2, gris: 0x6a6f76, bleu: 0x1d2f52, rouge: 0x7a1020, vert: 0x1f4a36, beige: 0xb8a582, opalite: 0xe8e6df, graphite: 0x2c2f34, sable: 0xc8b48a, cuivre: 0x9a5a3a };
export const MB_COLORS = [['noir', 'Noir obsidienne'], ['blanc', 'Blanc polaire'], ['argent', 'Argent iridium'], ['gris', 'Gris sélénite'], ['graphite', 'Graphite'], ['bleu', 'Bleu nautique'], ['rouge', 'Rouge hyacinthe'], ['vert', 'Vert émeraude'], ['beige', 'Beige désert'], ['opalite', 'Blanc opalite'], ['sable', 'Sable'], ['cuivre', 'Cuivre']].map(([k, n]) => ({ id: k, name: n, hex: MB[k] }));

// ---- générateurs de silhouettes (dimensions en mètres) ----
const r2 = (v) => Math.round(v * 100) / 100;
function axles(L, wbRatio = 0.6, front = 0.18) { const fz = L / 2 - front * L, wb = wbRatio * L; return [r2(fz), r2(fz - wb)]; }
function sedan(L, W, H, o = {}) {
  const belt = r2(0.68 * H), h = L / 2, trunk = o.hatch ? 0.25 : o.fast ? 0.6 : 0.95, cab0 = -h + trunk, rearGlass = o.hatch ? 0.25 : o.fast ? 1.25 : 0.65;
  return { len: L, width: W, wheelR: o.wheelR || 0.35, wheelZ: axles(L, o.wb || 0.6), wheelX: r2(W / 2 - 0.12),
    lower: [[-h, 0.32], [-h - 0.02, belt - 0.15], [-h + 0.2, belt], [cab0, belt + 0.02], [h - 1.25, belt + 0.02], [h - 0.3, belt - 0.12], [h, belt - 0.4], [h - 0.02, 0.32]].map(([z, y]) => [r2(z), r2(y)]),
    cabin: [[cab0, belt], [cab0 + rearGlass, r2(H - 0.02)], [r2(h - 2.15), r2(H)], [r2(h - 1.25), belt]].map(([z, y]) => [r2(z), y]),
    roof: [r2((cab0 + rearGlass + h - 2.15) / 2), r2(H + 0.01), r2(Math.max(0.4, h - 2.15 - cab0 - rearGlass))], belt, headY: r2(belt - 0.28), tailY: r2(belt - 0.08), doorZ: [1.0, r2(Math.min(1.3, L * 0.24))], seatZ: r2(-L * 0.04), eyeY: r2(H - 0.27) };
}
function suv(L, W, H, o = {}) {
  const belt = r2(0.6 * H + 0.08), h = L / 2;
  return { len: L, width: W, wheelR: o.wheelR || 0.42, wheelZ: axles(L, o.wb || 0.59), wheelX: r2(W / 2 - 0.13),
    lower: [[-h, 0.42], [-h, belt], [h - 1.05, belt + 0.02], [h - 0.18, belt - 0.1], [h, belt - 0.42], [h - 0.02, 0.42]].map(([z, y]) => [r2(z), r2(y)]),
    cabin: [[r2(-h + 0.05), belt], [r2(-h + (o.coupe ? 0.9 : 0.3)), r2(H - 0.03)], [r2(h - 1.95), r2(H)], [r2(h - 1.05), belt]],
    roof: [r2((-h + (o.coupe ? 0.9 : 0.3) + h - 1.95) / 2), r2(H + 0.01), r2(L - 2.3 - (o.coupe ? 0.6 : 0))], belt, headY: r2(belt - 0.22), tailY: r2(belt - 0.1), doorZ: [1.2, r2(Math.min(1.3, L * 0.25))], seatZ: 0.0, eyeY: r2(H - 0.3) };
}
function gwagen(L, W, H) { // silhouette carrée de la Classe G (feux ronds, roue de secours, ailes marquées)
  const h = L / 2, belt = r2(0.58 * H);
  return { len: L, width: W, wheelR: 0.43, wheelZ: axles(L, 0.59, 0.2), wheelX: r2(W / 2 - 0.12),
    lower: [[r2(-h), 0.45], [r2(-h - 0.02), belt], [r2(h - 0.12), belt], [r2(h), r2(belt - 0.2)], [r2(h - 0.02), 0.45]],
    cabin: [[r2(-h + 0.02), belt - 0.02], [r2(-h + 0.04), r2(H - 0.05)], [r2(h - 1.85), r2(H - 0.05)], [r2(h - 1.68), belt - 0.02]],
    roof: [r2((-h + h - 1.85) / 2), r2(H - 0.03), r2(L - 1.9)], belt, headY: r2(belt - 0.17), tailY: r2(belt - 0.2), roundLights: true, spare: true, flares: true, boxy: true, doorZ: [1.05, 1.1], seatZ: -0.1, eyeY: r2(H - 0.3) };
}
function coupe(L, W, H, o = {}) {
  const belt = r2(0.68 * H), h = L / 2;
  return { len: L, width: W, wheelR: o.wheelR || 0.36, wheelZ: axles(L, o.wb || 0.58, 0.19), wheelX: r2(W / 2 - 0.13),
    lower: [[-h, 0.3], [-h - 0.02, belt - 0.14], [-h + 0.22, belt], [r2(-h + 1.05), belt + 0.02], [r2(h - 1.4), belt + 0.02], [h - 0.32, belt - 0.14], [h, belt - 0.4], [h - 0.02, 0.3]].map(([z, y]) => [r2(z), r2(y)]),
    cabin: [[r2(-h + 1.05), belt], [r2(-h + (o.roadster ? 1.7 : 2.0)), r2(H - 0.02)], [r2(h - 2.35), r2(H)], [r2(h - 1.4), belt]],
    roof: [r2((-h + 2.0 + h - 2.35) / 2), r2(H + 0.01), 0.55], blackRoof: !!o.roadster, belt, headY: r2(belt - 0.27), tailY: r2(belt - 0.06), doorZ: [1.05, r2(Math.min(1.35, L * 0.27))], seatZ: r2(-L * 0.06), eyeY: r2(H - 0.24) };
}
function van(L, W, H, o = {}) {
  const belt = r2(o.sprinter ? 1.35 : 1.12), h = L / 2;
  return { len: L, width: W, wheelR: 0.38, wheelZ: axles(L, o.sprinter ? 0.62 : 0.62, 0.15), wheelX: r2(W / 2 - 0.13),
    lower: [[r2(-h), 0.4], [r2(-h), belt], [r2(h - 0.95), belt], [r2(h - 0.15), r2(belt - 0.18)], [r2(h), 0.85], [r2(h - 0.02), 0.4]],
    cabin: [[r2(-h + 0.02), belt], [r2(-h + 0.02), r2(H - 0.06)], [r2(h - 1.45), r2(H - 0.06)], [r2(h - 0.95), belt]],
    roof: [r2(-0.7), r2(H - 0.03), r2(L - 1.6)], belt, headY: r2(belt - 0.3), tailY: r2(belt - 0.2), doorZ: [1.2, 1.1], seatZ: r2(h - 1.9), eyeY: r2(o.sprinter ? 2.05 : 1.82) };
}
function hyper(L, W, H) { // hypercar à moteur central (AMG ONE)
  const h = L / 2;
  return { len: L, width: W, wheelR: 0.36, wheelZ: [r2(h - 0.95), r2(-h + 1.0)], wheelX: r2(W / 2 - 0.15),
    lower: [[r2(-h), 0.28], [r2(-h - 0.02), 0.86], [r2(-h + 0.7), 0.96], [-0.5, 0.92], [1.0, 0.82], [r2(h - 0.3), 0.6], [r2(h), 0.42], [r2(h - 0.02), 0.28]],
    cabin: [[-1.0, 0.9], [-0.35, r2(H - 0.02)], [0.35, r2(H)], [1.15, 0.83]], roof: [0, r2(H + 0.01), 0.62], belt: 0.86, headY: 0.6, tailY: 0.8,
    spoiler: 'wing', sideIntake: true, exhaust: 2, doorZ: [0.95, 1.1], seatZ: -0.1, eyeY: r2(H - 0.2) };
}

// ---- catalogue : [id, nom officiel du modèle, série, catégorie, silhouette, options d'apparence, stats de jeu, son, couleurs, valeur de jeu (FCFA)] ----
const st = (vmax, t100, o = {}) => ({ vmax: Math.min(vmax, 260), t100, brake: o.brake || 10.5, grip: o.grip || 7, steer: o.steer || 0.55, mass: o.mass || 2000, realVmax: vmax });
const DEF = [
  ['mb_g450d', 'Mercedes-Benz G 450 d', 'Classe G', 'Tout-terrain de luxe', gwagen(4.83, 1.93, 1.97), { grille: 'wide' }, st(210, 5.8, { mass: 2600, grip: 6, steer: 0.6 }), ['diesel', 0.9], ['noir', 'blanc', 'argent', 'vert', 'beige', 'gris'], 105e6],
  ['mb_g500', 'Mercedes-Benz G 500', 'Classe G', 'Tout-terrain de luxe', gwagen(4.83, 1.93, 1.97), { grille: 'wide' }, st(210, 5.4, { mass: 2550, grip: 6, steer: 0.6 }), ['i6', 1.0], ['noir', 'blanc', 'argent', 'vert', 'beige', 'graphite'], 115e6],
  ['mb_g63', 'Mercedes-AMG G 63', 'Classe G', 'Tout-terrain sportif AMG', gwagen(4.87, 1.98, 1.97), { grille: 'tall', exhaust: 4 }, st(220, 4.3, { mass: 2600, grip: 6.5, steer: 0.6 }), ['v8', 1.0], ['noir', 'blanc', 'gris', 'vert', 'rouge', 'sable'], 145e6],
  ['mb_g580', 'Mercedes-Benz G 580 avec technologie EQ', 'Classe G', 'Tout-terrain 100 % électrique', gwagen(4.83, 1.93, 1.99), { grille: 'wide', lightbarRear: true }, st(180, 4.7, { mass: 3100, grip: 6.5, steer: 0.62 }), ['ev', 1.0], ['noir', 'blanc', 'argent', 'vert', 'bleu', 'beige'], 140e6],
  ['mb_s580', 'Mercedes-Benz S 580 (Classe S)', 'Classe S', 'Berline de prestige', sedan(5.29, 1.95, 1.5, { wb: 0.6 }), { grille: 'tall', chromeLine: true }, st(250, 4.4, { mass: 2200, grip: 7.5 }), ['v8', 0.85], ['noir', 'argent', 'gris', 'bleu', 'blanc', 'graphite'], 95e6],
  ['mb_mays680', 'Mercedes-Maybach S 680', 'Mercedes-Maybach', 'Berline d’ultra-luxe', sedan(5.47, 1.92, 1.51, { wb: 0.62 }), { grille: 'tall', chromeLine: true, blackRoof: true }, st(250, 4.5, { mass: 2400, grip: 7.2 }), ['v12', 0.9], ['noir', 'argent', 'opalite', 'rouge', 'bleu', 'cuivre'], 185e6],
  ['mb_s63', 'Mercedes-AMG S 63 E PERFORMANCE', 'Classe S', 'Berline sportive hybride AMG', sedan(5.34, 1.95, 1.5, { wb: 0.6 }), { grille: 'tall', exhaust: 4 }, st(290, 3.3, { mass: 2600, grip: 8 }), ['v8', 1.1], ['noir', 'gris', 'graphite', 'blanc', 'bleu', 'rouge'], 125e6],
  ['mb_e300', 'Mercedes-Benz E 300 (Classe E)', 'Classe E', 'Berline premium', sedan(4.95, 1.88, 1.47), { grille: 'wide', lightbarRear: true }, st(245, 6.2, { mass: 1900 }), ['i6', 0.95], ['noir', 'argent', 'blanc', 'gris', 'bleu', 'graphite'], 55e6],
  ['mb_c300', 'Mercedes-Benz C 300 (Classe C)', 'Classe C', 'Berline compacte premium', sedan(4.75, 1.82, 1.44), { grille: 'wide' }, st(250, 6.0, { mass: 1700, grip: 7.5 }), ['i6', 1.0], ['blanc', 'noir', 'argent', 'bleu', 'rouge', 'gris'], 40e6],
  ['mb_a250', 'Mercedes-Benz A 250 (Classe A)', 'Classe A', 'Compacte', sedan(4.42, 1.8, 1.44, { hatch: true, wb: 0.62, wheelR: 0.33 }), { grille: 'wide' }, st(250, 6.2, { mass: 1500, grip: 7.5, steer: 0.6 }), ['i6', 1.15], ['blanc', 'noir', 'rouge', 'gris', 'bleu', 'argent'], 30e6],
  ['mb_cla', 'Mercedes-Benz CLA 250+ avec technologie EQ (nouvelle génération)', 'CLA', 'Coupé 4 portes électrique', sedan(4.72, 1.86, 1.47, { fast: true }), { lightbar: true }, st(210, 6.7, { mass: 2050, grip: 7.5 }), ['ev', 1.1], ['blanc', 'noir', 'gris', 'bleu', 'rouge', 'argent'], 38e6],
  ['mb_gla', 'Mercedes-Benz GLA 250', 'GLA', 'SUV compact', suv(4.41, 1.83, 1.61, { wheelR: 0.38 }), { grille: 'wide' }, st(240, 6.7, { mass: 1650, grip: 7 }), ['i6', 1.15], ['blanc', 'noir', 'gris', 'rouge', 'bleu', 'argent'], 33e6],
  ['mb_glb', 'Mercedes-Benz GLB 250', 'GLB', 'SUV compact 7 places', suv(4.63, 1.83, 1.66, { wheelR: 0.38 }), { grille: 'wide' }, st(236, 6.9, { mass: 1750 }), ['i6', 1.1], ['blanc', 'noir', 'gris', 'bleu', 'argent', 'sable'], 36e6],
  ['mb_glc', 'Mercedes-Benz GLC 300', 'GLC', 'SUV premium', suv(4.72, 1.89, 1.64), { grille: 'wide' }, st(240, 6.2, { mass: 1950 }), ['i6', 1.0], ['blanc', 'noir', 'argent', 'bleu', 'gris', 'rouge'], 45e6],
  ['mb_gle450', 'Mercedes-Benz GLE 450', 'GLE', 'Grand SUV', suv(4.92, 2.02, 1.77), { grille: 'wide', chromeLine: true }, st(250, 5.8, { mass: 2300 }), ['i6', 0.95], ['noir', 'blanc', 'argent', 'bleu', 'gris', 'beige'], 62e6],
  ['mb_gle63', 'Mercedes-AMG GLE 63 S', 'GLE', 'Grand SUV sportif AMG', suv(4.95, 2.01, 1.78), { grille: 'tall', exhaust: 4, flares: true }, st(280, 3.8, { mass: 2450, grip: 7.8 }), ['v8', 1.05], ['noir', 'blanc', 'gris', 'rouge', 'bleu', 'graphite'], 92e6],
  ['mb_gls580', 'Mercedes-Benz GLS 580', 'GLS', 'SUV de luxe 7 places', suv(5.21, 2.03, 1.82, { wheelR: 0.44 }), { grille: 'wide', chromeLine: true }, st(250, 5.3, { mass: 2600 }), ['v8', 0.9], ['noir', 'blanc', 'argent', 'bleu', 'gris', 'beige'], 80e6],
  ['mb_maygls', 'Mercedes-Maybach GLS 600', 'Mercedes-Maybach', 'SUV d’ultra-luxe', suv(5.21, 2.03, 1.84, { wheelR: 0.45 }), { grille: 'tall', chromeLine: true, blackRoof: true }, st(250, 4.9, { mass: 2800 }), ['v8', 0.85], ['noir', 'argent', 'opalite', 'rouge', 'bleu', 'cuivre'], 155e6],
  ['mb_eqs580', 'Mercedes-Benz EQS 580', 'EQS', 'Berline électrique de luxe', sedan(5.22, 1.93, 1.51, { fast: true }), { lightbar: true }, st(210, 4.4, { mass: 2600, grip: 7.5 }), ['ev', 0.9], ['noir', 'blanc', 'argent', 'bleu', 'gris', 'opalite'], 100e6],
  ['mb_eqe350', 'Mercedes-Benz EQE 350', 'EQE', 'Berline électrique', sedan(4.95, 1.91, 1.51, { fast: true }), { lightbar: true }, st(210, 6.4, { mass: 2350 }), ['ev', 1.0], ['blanc', 'noir', 'argent', 'bleu', 'gris', 'rouge'], 65e6],
  ['mb_eqssuv', 'Mercedes-Benz EQS 580 SUV', 'EQS', 'SUV électrique de luxe', suv(5.13, 2.03, 1.72, { wheelR: 0.44 }), { lightbar: true, chromeLine: true }, st(210, 4.6, { mass: 2900 }), ['ev', 0.9], ['noir', 'blanc', 'argent', 'bleu', 'gris', 'opalite'], 105e6],
  ['mb_eqesuv', 'Mercedes-Benz EQE 350 SUV', 'EQE', 'SUV électrique', suv(4.86, 1.94, 1.68), { lightbar: true }, st(210, 6.6, { mass: 2600 }), ['ev', 1.0], ['blanc', 'noir', 'argent', 'bleu', 'gris', 'rouge'], 70e6],
  ['mb_mayeqs', 'Mercedes-Maybach EQS 680 SUV', 'Mercedes-Maybach', 'SUV électrique d’ultra-luxe', suv(5.13, 2.03, 1.72, { wheelR: 0.45 }), { lightbar: true, chromeLine: true, blackRoof: true }, st(210, 4.4, { mass: 2950 }), ['ev', 0.85], ['noir', 'opalite', 'argent', 'cuivre', 'bleu', 'rouge'], 160e6],
  ['mb_v300', 'Mercedes-Benz V 300 d (Classe V)', 'Classe V', 'Monospace de luxe', van(5.14, 1.93, 1.88), { grille: 'wide' }, st(220, 7.8, { mass: 2500, grip: 6, steer: 0.5 }), ['diesel', 0.95], ['noir', 'blanc', 'argent', 'gris', 'bleu', 'graphite'], 50e6],
  ['mb_sprinter', 'Mercedes-Benz Sprinter (aménagement VIP)', 'Sprinter', 'Fourgon aménagé en salon VIP (aménagement fictif)', van(5.93, 2.02, 2.7, { sprinter: true }), { grille: 'wide', chromeLine: true }, st(160, 12, { mass: 3500, grip: 5.5, steer: 0.48, brake: 9 }), ['diesel', 0.85], ['noir', 'blanc', 'argent', 'graphite', 'bleu', 'gris'], 120e6],
  ['mb_cle300', 'Mercedes-Benz CLE 300 Coupé', 'CLE', 'Coupé', coupe(4.85, 1.86, 1.43), { grille: 'wide' }, st(250, 5.4, { mass: 1800, grip: 8 }), ['i6', 1.05], ['blanc', 'noir', 'rouge', 'bleu', 'gris', 'argent'], 45e6],
  ['mb_amggt', 'Mercedes-AMG GT 63 Coupé', 'AMG GT', 'Coupé sportif AMG', coupe(4.73, 1.98, 1.35, { wb: 0.6 }), { grille: 'tall', exhaust: 4, spoiler: 'lip' }, st(315, 3.2, { mass: 1900, grip: 9, steer: 0.52, brake: 12 }), ['v8', 1.2], ['gris', 'noir', 'blanc', 'rouge', 'vert', 'sable'], 125e6],
  ['mb_amggt4', 'Mercedes-AMG GT 63 S E PERFORMANCE 4 portes', 'AMG GT', 'Coupé 4 portes hybride AMG', sedan(5.05, 1.95, 1.45, { fast: true }), { grille: 'tall', exhaust: 4, spoiler: 'lip' }, st(316, 2.9, { mass: 2380, grip: 8.8, brake: 12 }), ['v8', 1.2], ['gris', 'noir', 'blanc', 'rouge', 'bleu', 'graphite'], 130e6],
  ['mb_sl63', 'Mercedes-AMG SL 63', 'SL', 'Roadster sportif AMG', coupe(4.71, 1.92, 1.36, { roadster: true }), { grille: 'tall', exhaust: 4 }, st(315, 3.6, { mass: 1900, grip: 8.8, brake: 12 }), ['v8', 1.15], ['rouge', 'noir', 'blanc', 'gris', 'bleu', 'vert'], 130e6],
  ['mb_maysl', 'Mercedes-Maybach SL 680 Monogram Series', 'Mercedes-Maybach', 'Roadster d’ultra-luxe', coupe(4.72, 1.92, 1.36, { roadster: true }), { grille: 'tall', chromeLine: true }, st(260, 4.1, { mass: 2000, grip: 8.5 }), ['v8', 0.95], ['opalite', 'rouge', 'noir', 'cuivre', 'bleu', 'argent'], 250e6],
  ['mb_amgone', 'Mercedes-AMG ONE', 'AMG ONE', 'Hypercar hybride (technologie issue de la F1)', hyper(4.76, 2.01, 1.26), {}, st(352, 2.9, { mass: 1700, grip: 10, steer: 0.5, brake: 13 }), ['v6', 1.35], ['argent', 'noir', 'gris', 'rouge', 'blanc', 'graphite'], 1800e6],
];
const COL = (k) => MB[k];
export const MB_CARS = DEF.map(([id, name, series, cat, body, look, stats, [snd, mul], cols, value], i) => ({
  ...body, ...look, id, name, series, type: cat, brand: 'Mercedes-Benz', collection: 'mb', stats, gears: snd === 'ev' ? 1 : 9, sound: { type: snd, mul },
  horn: [370 + (i % 4) * 22, 466 + (i % 4) * 22], colors: cols.map(COL), colorKeys: cols, value,
}));
export const MB_BY_ID = Object.fromEntries(MB_CARS.map((c) => [c.id, c]));
export const MB_SERIES = [...new Set(MB_CARS.map((c) => c.series))];
