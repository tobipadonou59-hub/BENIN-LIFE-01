// Personnage humain procédural à squelette (SkinnedMesh) : proportions réalistes,
// animations procédurales de repos, marche, course, saut et position assise.
// Un seul maillage et un seul matériau par personnage (1 appel de rendu).
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { pagne } from './textures.js';
import { clamp, lerp } from './util.js';

export const SKINS = [0x5a3a26, 0x4a2e1e, 0x6b4630, 0x3d2618, 0x7a5236];

const PAGNE_PALETTES = [
  ['#f2b400', '#c8102e', '#0b6e4f', '#1a1a1a'],
  ['#1f4e9c', '#f2c500', '#e46a1f', '#ffffff'],
  ['#7a1f5c', '#f2b400', '#2aa0a0', '#1a1a1a'],
  ['#0b6e4f', '#ffffff', '#e46a1f', '#c8102e'],
  ['#e46a1f', '#1a1a1a', '#f2c500', '#1f4e9c'],
  ['#ffffff', '#1f4e9c', '#c8102e', '#f2b400'],
  ['#c8302a', '#1a1a1a', '#f2e6c8', '#0b6e4f'], // garde-robe (mission 016)
  ['#d8a830', '#5a2a4a', '#ffffff', '#1a1a1a'],
];

// Atlas : moitié gauche = motif wax, moitié droite = blanc (teinté par couleur de sommet)
const mats = new Map();
function atlasMaterial(key) {
  if (mats.has(key)) return mats.get(key);
  const c = document.createElement('canvas');
  c.width = 512; c.height = 256;
  const x = c.getContext('2d');
  if (typeof key === 'number') {
    const t = pagne(PAGNE_PALETTES[key % PAGNE_PALETTES.length], 500 + key).image;
    for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) x.drawImage(t, i * 128, j * 128);
  } else {
    x.fillStyle = key; x.fillRect(0, 0, 256, 256);
    x.fillStyle = 'rgba(0,0,0,0.06)'; for (let k = 0; k < 256; k += 4) x.fillRect(0, k, 256, 1);
  }
  x.fillStyle = '#ffffff'; x.fillRect(256, 0, 256, 256);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  const m = new THREE.MeshStandardMaterial({ map: tex, vertexColors: true, roughness: 0.75 });
  mats.set(key, m);
  return m;
}

// Os : [nom, parent, position relative au parent]
const BONES = [
  ['hips', -1, [0, 0.97, 0]],
  ['spine', 0, [0, 0.1, 0]],
  ['chest', 1, [0, 0.2, 0]],
  ['neck', 2, [0, 0.2, 0]],
  ['head', 3, [0, 0.08, 0]],
  ['armL', 2, [0.19, 0.16, 0]], ['foreL', 5, [0, -0.29, 0]], ['handL', 6, [0, -0.25, 0]],
  ['armR', 2, [-0.19, 0.16, 0]], ['foreR', 8, [0, -0.29, 0]], ['handR', 9, [0, -0.25, 0]],
  ['thighL', 0, [0.095, -0.05, 0]], ['shinL', 11, [0, -0.43, 0]], ['footL', 12, [0, -0.42, 0]],
  ['thighR', 0, [-0.095, -0.05, 0]], ['shinR', 14, [0, -0.43, 0]], ['footR', 15, [0, -0.42, 0]],
];
const B = Object.fromEntries(BONES.map((b, i) => [b[0], i]));
// position monde (pose de liaison) de chaque os
const BIND = [];
BONES.forEach(([, p, pos], i) => {
  const v = new THREE.Vector3(...pos);
  if (p >= 0) v.add(BIND[p]);
  BIND.push(v);
});

const SOLID_UV = [0.75, 0.5];

// pièce : géométrie + os + couleur + (motif ou uni)
function part(geo, bone, color, patterned = false, uvScale = 1) {
  const g = geo.index ? geo : geo;
  const n = g.attributes.position.count;
  const col = new Float32Array(n * 3), si = new Uint16Array(n * 4), sw = new Float32Array(n * 4);
  const c = new THREE.Color(color);
  const uv = g.attributes.uv;
  for (let i = 0; i < n; i++) {
    col[i * 3] = c.r; col[i * 3 + 1] = c.g; col[i * 3 + 2] = c.b;
    si[i * 4] = bone; sw[i * 4] = 1;
    if (patterned) uv.setXY(i, (uv.getX(i) * uvScale) % 1 * 0.5, uv.getY(i) * uvScale % 1);
    else uv.setXY(i, SOLID_UV[0], SOLID_UV[1]);
  }
  g.setAttribute('color', new THREE.BufferAttribute(col, 3));
  g.setAttribute('skinIndex', new THREE.Uint16BufferAttribute(si, 4));
  g.setAttribute('skinWeight', new THREE.Float32BufferAttribute(sw, 4));
  return g;
}

// segment de membre (capsule) entre deux points verticaux
function limb(r1, r2, len, segs = 8) {
  const g = new THREE.CylinderGeometry(r1, r2, len, segs, 3);
  const p = g.attributes.position;
  // arrondit légèrement (muscle)
  for (let i = 0; i < p.count; i++) {
    const y = p.getY(i) / len + 0.5; // 0 bas, 1 haut
    const bulge = 1 + Math.sin(y * Math.PI) * 0.12;
    p.setX(i, p.getX(i) * bulge); p.setZ(i, p.getZ(i) * bulge);
  }
  g.computeVertexNormals();
  return g;
}
const at = (g, v, dy = 0, dx = 0, dz = 0) => g.translate(v.x + dx, v.y + dy, v.z + dz);

function buildGeometry(o) {
  const skin = o.skin, shirtC = o.shirtColor ?? 0xffffff, pants = o.pants, shoes = o.shoes ?? 0x1c1c1c, hair = 0x141010;
  const patterned = o.shirtColor == null;
  const female = o.female;
  const skirt = o.skirt ?? female, headwrap = o.headwrap ?? female;
  const parts = [];
  const P = (geo, bone, color, pat = false, s = 1) => parts.push(part(geo, B[bone], color, pat, s));
  const shirt = patterned ? 0xffffff : shirtC;

  // bassin
  { const g = new THREE.SphereGeometry(0.15, 12, 8); g.scale(1.05, 0.7, 0.8); at(g, BIND[B.hips], -0.02); P(g, 'hips', skirt ? shirt : pants, skirt && patterned, 2); }
  // abdomen
  { const g = new THREE.CylinderGeometry(0.135, 0.145, 0.24, 12, 2); g.scale(1, 1, 0.75); at(g, BIND[B.spine], 0.04); P(g, 'spine', shirt, patterned, 2); }
  // thorax (plus large aux épaules)
  {
    const g = new THREE.CylinderGeometry(female ? 0.16 : 0.185, 0.14, 0.3, 14, 3); g.scale(1, 1, 0.68);
    if (female) { const b = new THREE.SphereGeometry(0.075, 8, 6); b.scale(1, 0.9, 0.8); for (const s of [-1, 1]) P(b.clone().translate(BIND[B.chest].x + s * 0.07, BIND[B.chest].y + 0.06, 0.07), 'chest', shirt, patterned, 2); }
    at(g, BIND[B.chest], 0.1); P(g, 'chest', shirt, patterned, 2);
  }
  // épaules
  for (const s of ['L', 'R']) { const g = new THREE.SphereGeometry(0.07, 10, 8); at(g, BIND[B['arm' + s]], 0.0); P(g, 'chest', shirt, patterned, 1); }
  // cou + tête
  { const g = new THREE.CylinderGeometry(0.048, 0.056, 0.12, 10); at(g, BIND[B.neck], 0.05); P(g, 'neck', skin); }
  {
    const h = BIND[B.head];
    const g = new THREE.SphereGeometry(0.105, 16, 14); g.scale(0.9, 1.12, 1.0); at(g, h, 0.1, 0, 0.01); P(g, 'head', skin);
    const jaw = new THREE.SphereGeometry(0.075, 12, 8); jaw.scale(1, 0.75, 1); at(jaw, h, 0.03, 0, 0.035); P(jaw, 'head', skin);
    const nose = new THREE.SphereGeometry(0.022, 8, 6); nose.scale(1.2, 0.9, 1); at(nose, h, 0.085, 0, 0.1); P(nose, 'head', skin);
    for (const s of [-1, 1]) {
      const ear = new THREE.SphereGeometry(0.022, 6, 6); ear.scale(0.5, 1, 0.8); at(ear, h, 0.1, s * 0.095, 0); P(ear, 'head', skin);
      const eye = new THREE.SphereGeometry(0.012, 6, 5); at(eye, h, 0.115, s * 0.035, 0.093); P(eye, 'head', 0x0b0b0b);
      const white = new THREE.SphereGeometry(0.017, 6, 5); white.scale(1.2, 0.7, 0.5); at(white, h, 0.115, s * 0.035, 0.088); P(white, 'head', 0xe8e2d8);
    }
    if (headwrap) {
      // foulard noué (attaché) en tissu wax
      const wrap = new THREE.SphereGeometry(0.125, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.55); wrap.scale(1.05, 1.15, 1.15); at(wrap, h, 0.14, 0, -0.01); P(wrap, 'head', o.wrapColor ?? 0xffffff, o.wrapColor == null && patterned, 1);
      const knot = new THREE.SphereGeometry(0.06, 8, 6); knot.scale(1.4, 0.8, 1); at(knot, h, 0.26, 0, -0.02); P(knot, 'head', o.wrapColor ?? 0xffffff, o.wrapColor == null && patterned, 1);
    } else {
      const cap = new THREE.SphereGeometry(0.11, 14, 8, 0, Math.PI * 2, 0, Math.PI * 0.45); cap.scale(0.93, 1.1, 1.02); at(cap, h, 0.115, 0, 0.0); P(cap, 'head', hair);
    }
    if (o.carry) {
      // bassine portée sur la tête avec marchandises
      const pad = new THREE.TorusGeometry(0.07, 0.025, 6, 10); pad.rotateX(Math.PI / 2); at(pad, h, 0.27); P(pad, 'head', 0xd8c8a0);
      const basin = new THREE.CylinderGeometry(0.3, 0.2, 0.14, 16, 1, true); at(basin, h, 0.35); P(basin, 'head', o.carryColor ?? 0x2a7ad0);
      const bottom = new THREE.CircleGeometry(0.2, 12); bottom.rotateX(-Math.PI / 2); at(bottom, h, 0.285); P(bottom, 'head', o.carryColor ?? 0x2a7ad0);
      for (let k = 0; k < 7; k++) {
        const fruit = new THREE.SphereGeometry(0.07, 7, 5); const a = k * 0.9;
        at(fruit, h, 0.42 + (k % 2) * 0.03, Math.cos(a) * 0.15 * (k > 0), Math.sin(a) * 0.15 * (k > 0)); P(fruit, 'head', o.goodsColor ?? 0xe8a020);
      }
    }
  }
  // bras
  for (const s of ['L', 'R']) {
    const a = BIND[B['arm' + s]], f = BIND[B['fore' + s]], hd = BIND[B['hand' + s]];
    const up = limb(0.05, 0.043, 0.29); at(up, a, -0.145); P(up, 'arm' + s, skin);
    if (o.sleeves !== 'none') { const sleeve = limb(0.062, 0.056, 0.15, 10); at(sleeve, a, -0.06); P(sleeve, 'arm' + s, shirt, patterned, 1); }
    const fo = limb(0.042, 0.033, 0.25); at(fo, f, -0.125); P(fo, 'fore' + s, skin);
    const hand = new THREE.SphereGeometry(0.045, 8, 6); hand.scale(0.75, 1.3, 0.55); at(hand, hd, -0.05); P(hand, 'hand' + s, skin);
  }
  // jambes
  for (const s of ['L', 'R']) {
    const t = BIND[B['thigh' + s]], sh = BIND[B['shin' + s]], ft = BIND[B['foot' + s]];
    const th = limb(0.078, 0.058, 0.44, 10); at(th, t, -0.21); P(th, 'thigh' + s, skirt ? skin : pants);
    const knee = new THREE.SphereGeometry(0.058, 8, 6); at(knee, sh, 0); P(knee, 'shin' + s, skirt ? skin : (o.shorts ? skin : pants));
    const sn = limb(0.056, 0.04, 0.42, 10); at(sn, sh, -0.21); P(sn, 'shin' + s, skirt ? skin : (o.shorts ? skin : pants));
    const foot = new THREE.BoxGeometry(0.085, 0.06, 0.24, 2, 1, 2);
    { const p = foot.attributes.position; for (let i = 0; i < p.count; i++) if (p.getZ(i) > 0.05) p.setX(i, p.getX(i) * 0.85); }
    at(foot, ft, -0.03, 0, 0.05); P(foot, 'foot' + s, shoes);
  }
  if (skirt || o.robe) {
    // pagne noué en jupe longue (ou grand boubou), suit le bassin
    const g = o.robe ? new THREE.CylinderGeometry(0.2, 0.3, 0.86, 16, 4, true) : new THREE.CylinderGeometry(0.16, 0.25, 0.78, 16, 4, true);
    const p = g.attributes.position; for (let i = 0; i < p.count; i++) p.setZ(i, p.getZ(i) * 0.85);
    g.computeVertexNormals();
    at(g, BIND[B.hips], -0.4);
    parts.push(part(g, B.hips, o.skirtColor ?? 0xffffff, o.skirtColor == null && patterned, 2));
  }
  // ---- vêtements et accessoires de la garde-robe ----
  const PI2 = Math.PI * 2, jk = o.jacket;
  if (o.sleeves === 'long' || jk != null) for (const s of ['L', 'R']) {
    const a = BIND[B['arm' + s]], f = BIND[B['fore' + s]], c = jk ?? shirt, pt = jk == null && patterned;
    const up = limb(jk != null ? 0.066 : 0.06, jk != null ? 0.058 : 0.052, 0.29, 10); at(up, a, -0.145); P(up, 'arm' + s, c, pt, 1);
    const lo = limb(jk != null ? 0.052 : 0.048, jk != null ? 0.046 : 0.042, 0.23, 8); at(lo, f, -0.115); P(lo, 'fore' + s, c, pt, 1);
  }
  if (jk != null) { // veste ouverte sur le devant (la chemise reste visible)
    const r = female ? 0.172 : 0.197;
    const ch = new THREE.CylinderGeometry(r, 0.152, 0.32, 16, 2, true, 0.42, PI2 - 0.84); ch.scale(1, 1, 0.72); at(ch, BIND[B.chest], 0.1); P(ch, 'chest', jk);
    const sp = new THREE.CylinderGeometry(0.152, 0.16, 0.3, 16, 2, true, 0.5, PI2 - 1.0); sp.scale(1, 1, 0.8); at(sp, BIND[B.spine], 0.0); P(sp, 'spine', jk);
    for (const s of ['L', 'R']) { const g = new THREE.SphereGeometry(0.078, 10, 8); at(g, BIND[B['arm' + s]], 0.0); P(g, 'chest', jk); }
  }
  if (o.collar != null) { const g = new THREE.TorusGeometry(0.058, 0.017, 6, 16); g.rotateX(Math.PI / 2); at(g, BIND[B.neck], 0.0); P(g, 'chest', o.collar === true ? shirt : o.collar, o.collar === true && patterned, 1); }
  if (o.tie != null) { const t = new THREE.BoxGeometry(0.04, 0.3, 0.012); at(t, BIND[B.chest], -0.02, 0, female ? 0.118 : 0.13); P(t, 'chest', o.tie); const k = new THREE.BoxGeometry(0.03, 0.03, 0.02); at(k, BIND[B.chest], 0.15, 0, female ? 0.105 : 0.115); P(k, 'chest', o.tie); }
  if (o.stripe != null) { const g = new THREE.CylinderGeometry(female ? 0.164 : 0.189, female ? 0.158 : 0.18, 0.05, 16, 1, true); g.scale(1, 1, 0.7); at(g, BIND[B.chest], 0.04); P(g, 'chest', o.stripe); }
  if (o.hat) {
    const h = BIND[B.head], hc = o.hatColor ?? 0x1a1a1a;
    if (o.hat === 'cap') { const c = new THREE.SphereGeometry(0.117, 14, 8, 0, PI2, 0, Math.PI * 0.5); c.scale(0.95, 0.9, 1.02); at(c, h, 0.13); P(c, 'head', hc); const v = new THREE.BoxGeometry(0.15, 0.012, 0.1); at(v, h, 0.135, 0, 0.12); P(v, 'head', hc); }
    else if (o.hat === 'straw') { const br = new THREE.CylinderGeometry(0.21, 0.21, 0.014, 18); at(br, h, 0.15); P(br, 'head', hc); const cr = new THREE.CylinderGeometry(0.1, 0.115, 0.1, 14); at(cr, h, 0.2); P(cr, 'head', hc); }
    else if (o.hat === 'fila') { const g = new THREE.CylinderGeometry(0.108, 0.114, 0.1, 14); g.rotateZ(0.12); at(g, h, 0.19); P(g, 'head', hc); }
    else if (o.hat === 'toque') { const g = new THREE.CylinderGeometry(0.105, 0.1, 0.18, 14); at(g, h, 0.24); P(g, 'head', hc); const t = new THREE.SphereGeometry(0.13, 12, 8); t.scale(1, 0.6, 1); at(t, h, 0.34); P(t, 'head', hc); }
  }
  if (o.glasses != null) { const h = BIND[B.head]; for (const s of [-1, 1]) { const l = new THREE.BoxGeometry(0.042, 0.028, 0.008); at(l, h, 0.118, s * 0.036, 0.105); P(l, 'head', o.glasses); } const br = new THREE.BoxGeometry(0.03, 0.006, 0.006); at(br, h, 0.124, 0, 0.106); P(br, 'head', o.glasses); for (const s of [-1, 1]) { const arm = new THREE.BoxGeometry(0.006, 0.006, 0.1); at(arm, h, 0.122, s * 0.058, 0.055); P(arm, 'head', o.glasses); } }
  if (o.watch != null) { const g = new THREE.TorusGeometry(0.036, 0.011, 6, 12); g.rotateX(Math.PI / 2); at(g, BIND[B.foreL], -0.215); P(g, 'foreL', o.watch); }
  if (o.necklace != null) { const g = new THREE.TorusGeometry(0.075, 0.009, 6, 18); g.rotateX(Math.PI / 2 - 0.35); at(g, BIND[B.neck], -0.03, 0, 0.02); P(g, 'chest', o.necklace); }
  if (o.bag != null) { const g = new THREE.BoxGeometry(0.26, 0.32, 0.11); at(g, BIND[B.chest], -0.04, 0, female ? -0.15 : -0.165); P(g, 'chest', o.bag); for (const s of [-1, 1]) { const st = new THREE.BoxGeometry(0.03, 0.3, 0.02); at(st, BIND[B.chest], 0.02, s * 0.09, female ? 0.11 : 0.125); P(st, 'chest', o.bag); } }
  if (o.sole != null) for (const s of ['L', 'R']) { const g = new THREE.BoxGeometry(0.095, 0.022, 0.255); at(g, BIND[B['foot' + s]], -0.065, 0, 0.05); P(g, 'foot' + s, o.sole); }
  const merged = mergeGeometries(parts.map((g) => (g.index ? g.toNonIndexed() : g)));
  merged.computeBoundingSphere();
  return merged;
}

export function createCharacter(opts = {}) {
  const o = {
    skin: opts.skin ?? SKINS[0], pants: opts.pants ?? 0x2a2f3a, female: !!opts.female,
    shirtColor: opts.shirtColor, carry: !!opts.carry, carryColor: opts.carryColor, goodsColor: opts.goodsColor,
    shorts: !!opts.shorts, shoes: opts.shoes,
    // garde-robe (mission 016) : options facultatives, sans effet sur les personnages qui ne les utilisent pas
    sleeves: opts.sleeves, collar: opts.collar, jacket: opts.jacket, tie: opts.tie, stripe: opts.stripe, hat: opts.hat, hatColor: opts.hatColor,
    glasses: opts.glasses, watch: opts.watch, necklace: opts.necklace, bag: opts.bag, sole: opts.sole,
    skirt: opts.skirt, headwrap: opts.headwrap, robe: !!opts.robe, skirtColor: opts.skirtColor, wrapColor: opts.wrapColor,
  };
  const geo = buildGeometry(o);
  const mat = o.shirtColor != null ? atlasMaterial('#ffffff') : atlasMaterial(opts.pagne ?? 0);
  const bones = BONES.map(([name], i) => { const b = new THREE.Bone(); b.name = name; return b; });
  BONES.forEach(([, p, pos], i) => { bones[i].position.set(...pos); if (p >= 0) bones[p].add(bones[i]); });
  const mesh = new THREE.SkinnedMesh(geo, mat);
  mesh.add(bones[0]);
  mesh.updateMatrixWorld(true);
  mesh.bind(new THREE.Skeleton(bones));
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  // sphère englobante fixe (assez large pour toutes les poses) : le personnage n'est dessiné que s'il est à l'écran
  mesh.boundingSphere = new THREE.Sphere(new THREE.Vector3(0, 0.9, 0), 1.5);
  mesh.frustumCulled = true;

  const root = new THREE.Group();
  root.add(mesh);
  const b = Object.fromEntries(BONES.map(([name], i) => [name, bones[i]]));
  const hip0 = BONES[0][2][1];
  let phase = Math.random() * 6, t = Math.random() * 10, carry = o.carry;
  let seated = false;

  function reset() { for (const bn of bones) bn.rotation.set(0, 0, 0); b.hips.position.set(0, hip0, 0); }

  return {
    group: root,
    mesh,
    bones: b,
    hip0,
    animate(dt, speed) {
      if (seated) return;
      reset();
      t += dt;
      const walk = clamp(speed / 1.6, 0, 1);
      const run = clamp((speed - 2.8) / 2.8, 0, 1);
      const stride = lerp(1.35, 2.3, run);
      const prevS = Math.sin(phase);
      phase += (speed / stride) * Math.PI * 2 * dt * (speed > 0.05 ? 1 : 0);
      if (opts.onStep && speed > 0.4 && Math.sign(Math.sin(phase)) !== Math.sign(prevS)) opts.onStep(speed);
      const s = Math.sin(phase), c = Math.cos(phase);
      // jambes : hanche, genou (fléchi pendant la phase d'oscillation), cheville
      const A = lerp(0.42, 0.85, run) * walk;
      const K = lerp(0.75, 1.65, run) * walk;
      for (const [side, ph] of [['L', 0], ['R', Math.PI]]) {
        const ss = Math.sin(phase + ph), cc = Math.cos(phase + ph);
        b['thigh' + side].rotation.x = -ss * A - run * 0.15;
        b['shin' + side].rotation.x = (0.08 + Math.max(0, cc) * K + Math.max(0, -ss) * 0.15 * walk);
        b['foot' + side].rotation.x = -Math.max(0, cc) * 0.25 * walk + Math.max(0, ss) * 0.2 * walk;
      }
      // bras opposés aux jambes, coudes pliés en course
      const armA = lerp(0.35, 0.9, run) * walk;
      b.armL.rotation.x = s * armA; b.armR.rotation.x = -s * armA;
      b.armL.rotation.z = 0.08 + run * 0.1; b.armR.rotation.z = -0.08 - run * 0.1;
      b.foreL.rotation.x = -(0.15 + run * 1.35 + Math.max(0, -s) * 0.3 * walk);
      b.foreR.rotation.x = -(0.15 + run * 1.35 + Math.max(0, s) * 0.3 * walk);
      // bassin / buste : rebond, rotation, inclinaison en course
      b.hips.position.y = hip0 - (1 - Math.abs(Math.cos(phase))) * lerp(0.03, 0.07, run) * walk + Math.abs(Math.sin(phase)) * 0.0 - run * 0.04;
      b.hips.rotation.y = s * 0.1 * walk;
      b.hips.rotation.z = c * 0.04 * walk * (1 - run);
      b.spine.rotation.x = run * 0.22 + walk * 0.03;
      b.chest.rotation.y = -s * 0.14 * walk;
      b.head.rotation.x = -run * 0.15;
      // respiration et petits mouvements au repos
      const idle = 1 - walk;
      if (idle > 0) {
        b.chest.rotation.x += Math.sin(t * 1.6) * 0.02 * idle;
        b.hips.rotation.z += Math.sin(t * 0.45) * 0.025 * idle;
        b.thighL.rotation.z = -Math.sin(t * 0.45) * 0.03 * idle;
        b.thighR.rotation.z = -Math.sin(t * 0.45) * 0.03 * idle;
        b.head.rotation.y = Math.sin(t * 0.3) * 0.35 * idle;
        b.armL.rotation.z += 0.05 * idle; b.armR.rotation.z -= 0.05 * idle;
      }
      if (carry) {
        // une main tient la bassine, tête droite
        b.armR.rotation.x = -Math.PI * 0.92; b.armR.rotation.z = -0.25; b.foreR.rotation.x = -0.35;
        b.head.rotation.set(0, 0, 0); b.chest.rotation.y *= 0.3;
      }
    },
    sit(onMoto = true) {
      reset();
      seated = true;
      b.thighL.rotation.x = b.thighR.rotation.x = -1.45;
      b.thighL.rotation.z = 0.18; b.thighR.rotation.z = -0.18;
      b.shinL.rotation.x = b.shinR.rotation.x = onMoto ? 1.25 : 1.5;
      b.armL.rotation.x = b.armR.rotation.x = -1.05;
      b.armL.rotation.z = 0.25; b.armR.rotation.z = -0.25;
      b.foreL.rotation.x = b.foreR.rotation.x = -0.35;
      b.spine.rotation.x = 0.12;
    },
    stand() { seated = false; reset(); },
    jumpPose() {
      reset();
      b.thighL.rotation.x = -0.7; b.shinL.rotation.x = 1.1;
      b.thighR.rotation.x = 0.25; b.shinR.rotation.x = 0.7;
      b.armL.rotation.x = -0.6; b.armR.rotation.x = 0.5; b.armL.rotation.z = 0.5; b.armR.rotation.z = -0.5;
      b.foreL.rotation.x = b.foreR.rotation.x = -0.6;
      b.spine.rotation.x = 0.1;
    },
  };
}
