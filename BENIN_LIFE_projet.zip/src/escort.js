// Mission 018, étape 5 — véhicule d'escorte de la sécurité (un seul, identifiant « BL-ESCORTE-1 »).
// Quand des gardes accompagnent le PDG et qu'il se déplace en véhicule (limousine avec chauffeur, sa propre voiture,
// taxi), les gardes montent dans le 4×4 d'escorte qui suit le véhicule du PDG en reprenant exactement sa trajectoire
// (fil d'Ariane, donc sans couper à travers les bâtiments) à une douzaine de mètres. À l'arrêt, il se gare derrière ;
// les gardes en descendent et rejoignent le PDG à pied. Il repart à la base quand le PDG s'éloigne à pied.
import * as THREE from 'three';
import { createCarMesh } from './vehicles.js';

const GAP = 13, STEP = 0.8;
export class Escort {
  constructor(ctx) {
    Object.assign(this, ctx); // scene, player, security, chauffeur, transport, ui, onSave
    if (this.scene.getObjectByName('BL-ESCORTE-1')) throw new Error('véhicule d’escorte déjà créé');
    const m = createCarMesh(0x15181c, 'van'); this.mesh = m.group; this.wheels = m.wheels; this.mesh.name = 'BL-ESCORTE-1';
    const bar = new THREE.Group(); // gyrophares discrets (non utilisés en mode urgence : simple signalisation)
    bar.add(new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.08, 0.22), new THREE.MeshStandardMaterial({ color: 0x111111 })));
    this.lamps = [0x2f80ed, 0xd8a830].map((c, i) => { const l = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.1, 0.18), new THREE.MeshBasicMaterial({ color: c, toneMapped: false })); l.position.set(i ? 0.25 : -0.25, 0.06, 0); bar.add(l); return l; });
    bar.position.set(0, 2.18, 0.6); this.mesh.add(bar);
    const sign = document.createElement('canvas'); sign.width = 256; sign.height = 48; const x = sign.getContext('2d'); x.fillStyle = '#15181c'; x.fillRect(0, 0, 256, 48); x.fillStyle = '#d8a830'; x.font = '900 28px Arial'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('SÉCURITÉ NOVA', 128, 26);
    const tex = new THREE.CanvasTexture(sign); tex.colorSpace = THREE.SRGBColorSpace;
    for (const s of [-1, 1]) { const p = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 0.3), new THREE.MeshBasicMaterial({ map: tex })); p.position.set(s * 0.97, 1.5, -0.6); p.rotation.y = s * Math.PI / 2; this.mesh.add(p); }
    this.mesh.visible = false; this.scene.add(this.mesh);
    this.trail = []; this.state = 'base'; this.enabled = true; this.pos = { x: 0, z: 0, h: 0 }; this.spin = 0; this.away = 0;
  }
  lead() { // véhicule du PDG suivi par l'escorte
    const pl = this.player, C = this.chauffeur, T = this.transport;
    if (C && C.ride && ['riding', 'choose', 'parked', 'waiting'].includes(C.ride.phase)) { const c = C.car(); return { x: c.pos.x, z: c.pos.z, moving: C.riding }; }
    if (pl.inCar && !pl.inCar.isAircraft && !pl.inCar.isBoat) return { x: pl.inCar.pos.x, z: pl.inCar.pos.z, moving: true };
    if (T && T.ride && T.ride.phase === 'riding') return { x: T.ride.x, z: T.ride.z, moving: true };
    return null;
  }
  get active() { return this.state === 'follow'; }
  update(dt) {
    const S = this.security, guards = S ? S.escorting() : [];
    const L = this.enabled && guards.length ? this.lead() : null;
    if (L) {
      const last = this.trail[this.trail.length - 1];
      if (!last || Math.hypot(L.x - last.x, L.z - last.z) > STEP) { this.trail.push({ x: L.x, z: L.z }); if (this.trail.length > 400) this.trail.splice(0, this.trail.length - 400); }
      if (last && Math.hypot(L.x - last.x, L.z - last.z) > 60) this.trail = [{ x: L.x, z: L.z }]; // saut (trajet passé) : on repart de la nouvelle position
      // point à GAP mètres derrière le véhicule de tête, le long de la trajectoire
      let d = 0, i = this.trail.length - 1;
      while (i > 0 && d < GAP) { d += Math.hypot(this.trail[i].x - this.trail[i - 1].x, this.trail[i].z - this.trail[i - 1].z); i--; }
      if (d >= GAP - 1) {
        const a = this.trail[i], b = this.trail[Math.min(i + 1, this.trail.length - 1)], h = Math.atan2(b.x - a.x, b.z - a.z);
        const moved = Math.hypot(a.x - this.pos.x, a.z - this.pos.z);
        if (this.state !== 'follow') { this.state = 'follow'; this.mesh.visible = true; this.ui.toast(`🚙 Le véhicule d’escorte « Sécurité NOVA » suit votre véhicule (${guards.length} garde${guards.length > 1 ? 's' : ''} à bord).`, 2.5); }
        this.pos.x = a.x; this.pos.z = a.z; if (moved > 0.05) this.pos.h = h; this.spin += moved / 0.36; this.away = 0;
        this.mesh.position.set(a.x, 0, a.z); this.mesh.rotation.set(0, this.pos.h, 0);
        for (const w of this.wheels) if (w.spin) w.spin.rotation.x = this.spin;
        const t = performance.now() / 250; this.lamps[0].visible = Math.sin(t) > 0; this.lamps[1].visible = !this.lamps[0].visible;
      }
    } else if (this.state === 'follow') {
      // arrêt : l'escorte reste garée derrière, puis rentre à la base quand le PDG s'éloigne à pied
      const P = this.player.pos; this.away = Math.hypot(P.x - this.pos.x, P.z - this.pos.z);
      if (this.away > 90 || !guards.length) { this.state = 'base'; this.mesh.visible = false; this.trail = []; }
    }
  }
  exitPoint() { return this.state === 'follow' ? { x: this.pos.x, z: this.pos.z } : null; } // les gardes descendent de l'escorte
  where() { return this.state === 'follow' ? 'suit le véhicule du PDG' : 'à la base (résidence)'; }
  serialize() { return { enabled: this.enabled }; }
  restore(s) { if (s) this.enabled = s.enabled !== false; }
}
