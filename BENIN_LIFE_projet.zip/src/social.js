// Mission 017, étape 3 — rencontres avec les habitants et carnet de contacts complet.
// Chaque passant abordé reçoit une identité fictive stable (nom, âge, métier, ville d'origine, caractère). Le joueur peut
// saluer, se présenter, faire un compliment, une blague, discuter librement, puis demander ses coordonnées.
// L'habitant ACCEPTE OU REFUSE selon la sympathie, son caractère, l'heure et la réputation du PDG. Un refus est
// définitif pour cette rencontre : le jeu ne propose pas d'insister, et revenir à la charge fait baisser la sympathie.
// Le contact n'est enregistré qu'avec son accord (consentement noté avec la date). Les mineurs (élèves) ne donnent pas
// de coordonnées. Numéros « +229 00 … » et adresses e-mail en « .example » : fictifs, ils ne peuvent appartenir à personne.
import { SKINS } from './character.js';
import { mulberry32 } from './util.js';
import { regionZone } from './region-geo.js';

const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const norm = (s) => s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[’']/g, ' ');
const slug = (s) => norm(s).replace(/[^a-z]/g, '');
export const hashStr = (str) => { let h = 2166136261; for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };
const deTown = (t) => (/^[AEIOUÉÈ]/i.test(t) ? `d’${t}` : `de ${t}`);
const pickR = (R, a) => a[Math.floor(R() * a.length)];

const F_NAMES = ['Afiavi', 'Sènan', 'Rachida', 'Aïcha', 'Fifamè', 'Ornella', 'Carine', 'Gisèle', 'Nafissatou', 'Edwige', 'Mariam', 'Blandine', 'Fréjus', 'Sika', 'Huguette', 'Pélagie', 'Rosine', 'Inès', 'Yasmine', 'Mahouna'];
const M_NAMES = ['Codjo', 'Kossi', 'Sèdjro', 'Ismaël', 'Rodrigue', 'Bienvenu', 'Gildas', 'Romaric', 'Ulrich', 'Moussa', 'Florent', 'Hervé', 'Dossou', 'Arnaud', 'Wilfried', 'Comlan', 'Abdou', 'Fiacre', 'Landry', 'Mathias'];
const LAST = ['Agbossou', 'Houngbédji', 'Dossou-Yovo', 'Akpovi', 'Adjovi', 'Hounkpatin', 'Gbaguidi', 'Zinsou', 'Ahouansou', 'Tossou', 'Kpadonou', 'Assogba', 'Sossa', 'Yessoufou', 'Alapini', 'Degbo', 'Lawani', 'Amoussou', 'Houéto', 'Chabi'];
const ORIG = ['Cotonou', 'Porto-Novo', 'Abomey', 'Ouidah', 'Parakou', 'Bohicon', 'Lokossa', 'Natitingou', 'Djougou', 'Allada', 'Comè', 'Savalou'];
const HOBBY = ['le football', 'la musique', 'la cuisine', 'la danse', 'la lecture', 'le cinéma', 'la couture', 'le basket', 'les jeux de société', 'la photo'];
const JOBS = {
  adulte: ['mécanicien·ne', 'coiffeur·se', 'chauffeur·e de taxi', 'infirmier·ère', 'enseignant·e', 'menuisier·ère', 'agent·e de banque', 'couturier·ère', 'électricien·ne', 'pharmacien·ne'],
  jeune: ['apprenti·e mécanicien·ne', 'vendeur·se de téléphones', 'serveur·se', 'livreur·se', 'apprenti·e coiffeur·se'],
  age: ['retraité·e de l’enseignement', 'ancien·ne commerçant·e', 'retraité·e des chemins de fer', 'ancien·ne artisan·e'],
  eleve: ['élève au collège'], etudiant: ['étudiant·e à l’université', 'étudiant·e en droit', 'étudiant·e en informatique', 'étudiant·e en médecine'],
  bureau: ['comptable', 'assistant·e de direction', 'juriste', 'chargé·e de clientèle', 'informaticien·ne'],
  commercante: ['commerçante', 'vendeuse de tissus', 'vendeuse de fruits'], travailleur: ['maçon·ne', 'ouvrier·ère du bâtiment', 'docker'], parent: ['parent d’élève et commerçant·e', 'parent et fonctionnaire'],
};
const G = (txt, f) => txt.replace(/([\p{L}’]+)·(\p{L}+)/gu, (m, w, suf) => (!f ? w : suf === 'se' ? w.replace(/eur$/, 'euse') : suf === 'ère' ? w.replace(/er$/, 'ère') : w + suf));
const JOKES = [
  'Tu sais pourquoi les zems ne se perdent jamais à Cotonou ? Parce qu’ils connaissent même les raccourcis qui n’existent pas !',
  'Mon réveil et moi, on a un accord : il sonne, et moi je fais semblant de ne pas l’entendre.',
  'À Dantokpa, j’ai demandé le prix d’une mangue. Le temps de négocier, elle était devenue du jus !',
  'Le soleil de Cotonou est tellement fort que mon ombre cherche aussi de l’ombre.',
];
const COMPL = {
  tenue: { me: 'Très belle tenue, elle te va bien !', ok: ['Merci beaucoup, c’est un tissu de chez nous !', 'Ah merci, ça fait plaisir 😊'], k: 8 },
  aimable: { me: 'Tu es vraiment aimable, ça fait plaisir de discuter avec toi.', ok: ['C’est gentil, toi aussi !', 'Merci, c’est réciproque.'], k: 6 },
  quartier: { me: 'Il est agréable, ton quartier !', ok: ['N’est-ce pas ? On y vit bien, les gens sont accueillants.', 'Merci ! On est fiers de notre quartier.'], k: 5 },
};

// portrait illustré (SVG) : teint, tenue, foulard, âge
export function avatarSVG(o, size = 56) {
  const skin = '#' + (o.skin ?? SKINS[0]).toString(16).padStart(6, '0'), shirt = '#' + (o.shirt ?? 0x1f4e9c).toString(16).padStart(6, '0');
  const hair = o.age >= 62 ? '#cfcac0' : '#1a120c', bg = ['#f3d9a4', '#cfe3d0', '#d6e0f2', '#f2d0c4', '#e4d6ef'][(o.seed || 0) % 5];
  const head = o.female ? (o.wrap ? `<path d="M15 25 Q28 4 41 25 Q41 15 28 12 Q15 15 15 25Z" fill="${shirt}"/><circle cx="28" cy="11" r="5" fill="${shirt}"/>` : `<path d="M16 26 Q14 10 28 10 Q42 10 40 26 Q38 16 28 16 Q18 16 16 26Z" fill="${hair}"/><circle cx="28" cy="9" r="5" fill="${hair}"/>`) : `<path d="M17 22 Q18 11 28 11 Q38 11 39 22 Q35 15 28 15 Q21 15 17 22Z" fill="${hair}"/>`;
  return `<svg class="sc-av" viewBox="0 0 56 56" width="${size}" height="${size}" role="img" aria-label="portrait (illustration)"><rect width="56" height="56" rx="12" fill="${bg}"/><path d="M8 56 Q10 40 28 39 Q46 40 48 56Z" fill="${shirt}"/><rect x="24" y="31" width="8" height="9" fill="${skin}"/><ellipse cx="28" cy="25" rx="11" ry="12.5" fill="${skin}"/>${head}<circle cx="24" cy="25" r="1.3" fill="#140c08"/><circle cx="32" cy="25" r="1.3" fill="#140c08"/><path d="M24 31 Q28 34 32 31" stroke="#140c08" stroke-width="1.2" fill="none"/>${o.glasses ? '<circle cx="24" cy="25" r="3.2" stroke="#222" fill="none"/><circle cx="32" cy="25" r="3.2" stroke="#222" fill="none"/>' : ''}</svg>`;
}
export function fakePhone(seed) { const R = mulberry32(seed || 1), d = () => String(Math.floor(R() * 100)).padStart(2, '0'); return `+229 00 ${d()} ${d()} ${d()} ${d()}`; }

export class Social {
  constructor(ctx) {
    Object.assign(this, ctx); // ui, economy, env, world, audio, ceoLife, life, onSave
    this.book = {}; this.met = {}; this.cur = null; this.open = false; this.log = []; this.confirmDel = null;
    this.dom = document.querySelector('#meet');
    this.dom.addEventListener('click', (e) => this.onClick(e));
    this.dom.addEventListener('keydown', (e) => { if (e.target.classList.contains('tk-in') && e.key === 'Enter') { e.preventDefault(); this.sendInput(); } });
  }
  // ------------------------------------------------------------------ identité fictive d'un passant
  person(p) {
    if (!p.pid) p.pid = 1 + Math.floor(Math.random() * 2147483000);
    const R = mulberry32(p.pid), o = (p.c && p.c.opts) || {}, female = o.female ?? R() < 0.5, prof = p.prof ? p.prof.id : 'adulte';
    const first = pickR(R, female ? F_NAMES : M_NAMES), last = pickR(R, LAST);
    const age = prof === 'eleve' ? 11 + Math.floor(R() * 6) : prof === 'etudiant' ? 19 + Math.floor(R() * 7) : prof === 'jeune' ? 18 + Math.floor(R() * 8) : prof === 'age' ? 62 + Math.floor(R() * 17) : 26 + Math.floor(R() * 32);
    return { pid: p.pid, first, last, name: `${first} ${last}`, female, age, minor: age < 18, prof, profLabel: p.prof ? p.prof.label : 'Habitant', job: G(pickR(R, JOBS[prof] || JOBS.adulte), female), origin: pickR(R, ORIG), hobby: pickR(R, HOBBY), open: R(), humor: R(), skin: o.skin ?? SKINS[Math.floor(R() * SKINS.length)], shirt: o.shirtColor ?? [0xc8102e, 0x1f4e9c, 0x0b6e4f, 0xe46a1f, 0x7a2a8a][Math.floor(R() * 5)], wrap: !!o.headwrap, glasses: R() < 0.15, seed: p.pid };
  }
  memo(pid) { return this.met[pid] || (this.met[pid] = { rapport: 20, greeted: false, introduced: false, named: false, compl: {}, joked: false, chat: 0, asked: false, refused: false, accepted: false, pushy: 0 }); }
  e(f, m, w) { return f ? w : m; } // accord masculin / féminin
  // ------------------------------------------------------------------ rencontre
  start(p, onEnd) {
    const P = this.person(p), M = this.memo(P.pid), zone = regionZone(p.x, p.z) || (this.world.zoneName ? this.world.zoneName(p.x, p.z) : 'Cotonou');
    this.cur = { p, P, M, zone, onEnd }; this.log = []; this.confirmDel = null;
    p.state = 'talk'; p.t = 0; p.face = { x: this.player.pos.x, z: this.player.pos.z };
    const saved = this.book[`n:${P.pid}`];
    if (saved) { M.greeted = true; M.named = true; this.add('them', `${this.e(P.female, 'Ah', 'Oh')} ! Re-bonjour ! Ça fait plaisir de te revoir.`); }
    else if (M.refused) this.add('sys', `Tu as déjà rencontré cette personne : elle n’a pas souhaité donner ses coordonnées.`);
    this.open = true; this.dom.classList.add('show'); this.render();
  }
  close() {
    if (!this.open) return; this.open = false; this.dom.classList.remove('show');
    const c = this.cur; this.cur = null; if (c && c.onEnd) c.onEnd(); this.onSave && this.onSave();
  }
  add(who, txt) { if (who === 'me' && this.quiet) return; this.log.push({ who, txt }); if (who === 'them' && this.life && this.cur) this.life.voice(this.cur.p); }
  bump(n) { const M = this.cur.M; M.rapport = Math.max(0, Math.min(100, M.rapport + n)); }
  rep() { return this.ceoLife ? this.ceoLife.rep : 50; }
  busy() { const h = this.env.time, P = this.cur.P; return (P.prof === 'bureau' || P.prof === 'travailleur') && ((h > 7 && h < 9.2) || (h > 17 && h < 19)); }
  needGreet() { const M = this.cur.M; if (M.greeted) return false; this.bump(-5); this.add('them', 'Euh… on dit d’abord bonjour, non ? 😅'); return true; }
  act(a, arg) {
    const C = this.cur; if (!C) return; const { P, M } = C, f = P.female;
    if (a === 'hello') {
      this.add('me', this.env.time >= 18 ? 'Bonsoir !' : 'Bonjour !');
      if (M.greeted) { this.add('them', 'Oui, bonjour encore 🙂'); return; }
      M.greeted = true; this.bump(10);
      this.add('them', P.age >= 62 ? 'Bonjour mon enfant, bonne arrivée !' : P.minor ? 'Bonjour ! Bonne journée !' : pickR(Math.random, ['Bonjour ! Ça va un peu ?', 'Bonne arrivée ! On dit quoi ?', 'Bonjour, bonne journée à toi !']));
    } else if (a === 'intro') {
      if (this.needGreet()) return;
      this.add('me', 'Je me présente : je suis le PDG de NOVA BOOK, la maison d’édition.');
      if (M.introduced) { this.add('them', 'Oui, tu me l’as dit 🙂'); return; }
      M.introduced = true; M.named = true; this.bump(8);
      const fame = this.rep() >= 70 ? ' NOVA BOOK ? J’ai lu un de vos livres, bravo !' : this.rep() < 35 ? ' NOVA BOOK… j’ai entendu parler de retards de livraison, non ?' : '';
      if (fame) this.bump(this.rep() >= 70 ? 5 : -3);
      this.add('them', `${this.e(f, 'Enchanté', 'Enchantée')} ! Moi c’est ${P.first} ${P.last}. ${P.minor ? `Je suis ${P.job}, j’ai ${P.age} ans.` : `Je suis ${P.job}, originaire ${deTown(P.origin)}.`}${fame}`);
    } else if (a === 'compl') {
      if (this.needGreet()) return; const K = COMPL[arg]; if (!K) return;
      this.add('me', K.me);
      if (M.compl[arg]) { this.bump(-2); this.add('them', 'Merci… tu l’as déjà dit 😅'); return; }
      M.compl[arg] = 1; this.bump(K.k * (Object.keys(M.compl).length > 2 ? 0.5 : 1)); this.add('them', pickR(Math.random, K.ok));
    } else if (a === 'joke') {
      if (this.needGreet()) return;
      const j = JOKES[(P.pid + (M.joked ? 1 : 0)) % JOKES.length]; this.add('me', j);
      if (M.joked) { this.bump(1); this.add('them', 'Haha, tu as toujours une blague en réserve !'); return; }
      M.joked = true;
      if (P.humor > 0.35) { this.bump(8); this.add('them', pickR(Math.random, ['Hahaha ! Elle est bonne celle-là 😂', 'Ah toi alors ! Tu m’as fait rire 😄'])); } else { this.bump(-1); this.add('them', 'Hum… je ne l’ai pas trop comprise, celle-là.'); }
    } else if (a === 'ask') this.ask();
    else if (a === 'save') this.save();
    else if (a === 'bye') { this.add('me', 'Au revoir, bonne journée !'); this.add('them', M.rapport >= 50 ? 'Au revoir ! Ravi·e de t’avoir rencontré·e.'.replace(/·e/g, f ? 'e' : '') : 'Au revoir.'); this.render(); return setTimeout(() => this.close(), 900); }
    this.render();
  }
  ask() {
    const C = this.cur, { P, M } = C, f = P.female;
    if (this.needGreet()) return;
    if (M.refused) { M.pushy++; this.bump(-12); this.add('me', 'Tu es sûr·e de ne pas vouloir me donner ton numéro ?'.replace('sûr·e', f ? 'sûre' : 'sûr')); this.add('them', 'Je t’ai déjà répondu non. Merci de respecter ma décision.'); if (M.rapport <= 0 || M.pushy >= 2) { this.add('sys', `${P.first || 'La personne'} met fin à la conversation.`); this.render(); setTimeout(() => this.close(), 1400); } return; }
    if (M.accepted) return this.add('them', 'C’est déjà fait, tu as mon numéro 🙂');
    this.add('me', 'On pourrait garder contact ? Tu veux bien me donner ton numéro ?');
    if (P.minor) { M.refused = true; this.add('them', 'Je suis encore mineur·e, je ne donne pas mon numéro. Mes parents ne seraient pas d’accord.'.replace('mineur·e', f ? 'mineure' : 'mineur')); this.add('sys', 'Les mineurs ne partagent pas leurs coordonnées. Sa réponse est respectée.'); return; }
    const h = this.env.time, score = 0.18 + P.open * 0.3 + (M.rapport / 100) * 0.6 + (this.rep() - 50) / 400 + (M.introduced ? 0.05 : -0.1) - (this.busy() ? 0.25 : 0) - (h < 7 || h > 21 ? 0.15 : 0);
    const roll = mulberry32(P.pid ^ 0x5bd1e995)();
    M.asked = true;
    if (roll < score) {
      M.accepted = true; this.bump(5);
      this.add('them', pickR(Math.random, ['Oui, avec plaisir ! Note mon numéro.', 'D’accord, pourquoi pas ! Voici mon numéro et mon e-mail.', 'Bien sûr, c’était sympa de discuter. Je te donne mes coordonnées.']));
    } else {
      M.refused = true;
      const why = this.busy() ? 'Je suis pressé·e, désolé·e, une autre fois peut-être.' : !M.introduced ? 'Désolé·e, je ne donne pas mon numéro à quelqu’un dont je ne connais même pas le nom.' : M.rapport < 45 ? 'Je préfère pas, on vient juste de se rencontrer.' : 'C’était sympa de discuter, mais je préfère garder mon numéro pour moi. Merci de comprendre.';
      this.add('them', why.replace(/é·e/g, f ? 'ée' : 'é'));
      this.add('sys', 'Refus : son choix est respecté. Tu ne peux pas insister.');
    }
  }
  save() {
    const C = this.cur, { P, M, zone } = C; if (!M.accepted || this.book[`n:${P.pid}`]) return;
    const id = `n:${P.pid}`, now = this.economy.stamp();
    this.book[id] = { id, pid: P.pid, name: P.name, first: P.first, last: P.last, female: P.female, age: P.age, job: P.job, origin: P.origin, hobby: P.hobby, skin: P.skin, shirt: P.shirt, wrap: P.wrap, glasses: P.glasses, prof: P.prof,
      phone: fakePhone(P.pid), email: `${slug(P.first)}.${slug(P.last)}@contact.example`, address: `${zone}${/^(Porto-Novo|Ouidah|Pahou|Cocotomey|RNIE 1)$/.test(zone) ? '' : ', Cotonou'} (adresse précise non communiquée)`,
      metAt: now, metPlace: zone, consent: now, rapport: M.rapport, fav: false, hist: [{ t: now, txt: `Rencontre (${zone}) — accord pour partager ses coordonnées` }] };
    this.add('sys', `📇 ${P.name} est enregistré·e dans tes contacts, avec son accord.`.replace('enregistré·e', P.female ? 'enregistrée' : 'enregistré'));
    this.economy.notify && this.economy.notify(`📇 Nouveau contact : ${P.name}`);
    if (this.events) this.events.repAdd('reseau', 1);
    this.onSave && this.onSave();
  }
  // ------------------------------------------------------------------ discussion libre (en face à face)
  chatReply(raw) {
    this.quiet = true; try { this.chatInner(raw); } finally { this.quiet = false; }
  }
  chatInner(raw) {
    const C = this.cur, { P, M } = C, t = norm(raw), has = (re) => re.test(t);
    if (has(/\b(bonjour|bonsoir|salut|coucou|bjr)\b/) && !M.greeted) return this.act('hello');
    if (has(/(numero|ton contact|tes coordonnees|whatsapp|ton mail|ton e.mail|ton telephone)/)) return this.ask();
    if (has(/(au revoir|a plus|a bientot|bye|bonne journee)/)) return this.act('bye');
    if (this.needGreet()) return;
    M.chat++; if (M.chat <= 5) this.bump(2);
    let r;
    if (has(/(je suis|je m appelle|moi c est).*(pdg|nova|patron|directeur)|je me presente/)) return this.act('intro');
    if (has(/(comment tu t appelles|ton nom|tu t appelles|vous vous appelez)/)) { M.named = true; r = `Je m’appelle ${P.first}${P.minor ? '' : ` ${P.last}`}.`; }
    else if (has(/(ca va|comment vas|tu vas bien|la forme)/)) r = pickR(Math.random, ['Ça va bien, merci ! Et toi ?', 'Ça va un peu, on se bat ! Et toi ?', 'Très bien, merci de demander.']);
    else if (has(/(travail|metier|boulot|tu fais quoi|profession)/)) r = `Je suis ${P.job}.${P.minor ? ' Je travaille bien à l’école !' : ''}`;
    else if (has(/(d ou|originaire|tu viens|tu es ne|ou es.tu ne)/)) r = `Je suis originaire ${deTown(P.origin)}.`;
    else if (has(/(loisir|passion|week.?end|temps libre|tu aimes)/)) r = `J’adore ${P.hobby} !`;
    else if (has(/(age|quel age)/)) r = P.age >= 62 ? 'Oh, j’ai l’âge d’être ton parent 😄' : `J’ai ${P.age} ans.`;
    else if (has(/(chaud|pluie|meteo|soleil|temps qu il fait)/)) r = 'Ah, avec ce soleil, il faut boire beaucoup d’eau !';
    else if (has(/(quartier|ici|ville|cotonou)/)) r = `${C.zone}, c’est vivant ! Il y a des boutiques et des maquis partout.`;
    else if (has(/(belle|beau|jolie|elegant|tenue|habit)/)) return this.act('compl', 'tenue');
    else if (has(/(blague|rigoler|drole)/)) return this.act('joke');
    else if (has(/(famille|enfant|mari|femme)/)) r = P.minor ? 'J’habite avec mes parents.' : 'La famille va bien, merci ! Et la tienne ?';
    else if (has(/(nova|livre|edition)/)) r = this.rep() >= 60 ? 'NOVA BOOK ? Leurs livres sont bien faits !' : 'NOVA BOOK, la maison d’édition ? J’en ai entendu parler.';
    else if (raw.trim().endsWith('?')) r = pickR(Math.random, ['Bonne question… je ne sais pas trop !', 'Hum, je ne saurais pas te dire.', 'Ça, il faudrait demander à quelqu’un d’autre !']);
    else r = pickR(Math.random, ['Ah oui ? Intéressant !', 'Je vois, je vois.', 'C’est vrai ce que tu dis.', 'Hum hum 🙂']);
    this.add('them', r);
  }
  sendInput() { const i = this.dom.querySelector('.tk-in'); if (!i || !this.cur) return; const v = i.value.trim().slice(0, 200); i.value = ''; if (!v) return; this.add('me', v); this.chatReply(v); this.render(); }
  // ------------------------------------------------------------------ interface de rencontre
  render() {
    if (!this.open || !this.cur) return;
    const { P, M, zone } = this.cur, saved = !!this.book[`n:${P.pid}`];
    const who = M.named || saved ? esc(P.name) : `${this.e(P.female, 'Un', 'Une')} ${esc(P.profLabel.toLowerCase())}`;
    const btn = (k, l, dis) => `<button data-sc="${k}" ${dis ? 'disabled' : ''}>${l}</button>`;
    const askBtn = M.accepted ? (saved ? btn('noop', '📇 Dans tes contacts ✓', true) : '<button class="sc-go" data-sc="save">📇 Enregistrer le contact (avec son accord)</button>') : M.refused ? btn('noop', '🚫 Refus respecté', true) : btn('ask', '📇 Demander son contact');
    this.dom.innerHTML = `<div class="tk-box"><div class="tk-head">${avatarSVG(P, 44)}<h2>${who}<small class="sc-sub">${esc(P.profLabel)} • ${esc(zone)}${M.named || saved ? ` • ${esc(P.job)}` : ''}</small></h2><button data-sc="x">✕</button></div>
      <div class="sc-bar"><span>Sympathie</span><i><b style="width:${M.rapport}%"></b></i><em>${Math.round(M.rapport)}/100</em></div>
      <div class="tk-log">${this.log.map((l) => l.who === 'sys' ? `<p class="tk-sys">${esc(l.txt)}</p>` : `<div class="tk-msg ${l.who === 'me' ? 'me' : ''}"><span>${esc(l.txt)}</span></div>`).join('') || '<p class="tk-sys">Commence par saluer : au Bénin, on se dit toujours bonjour !</p>'}</div>
      ${M.accepted && !saved ? `<button class="sc-save" data-sc="save">📇 ${esc(P.first)} accepte : enregistrer le contact</button>` : ''}<div class="tk-sugg">${btn('hello', '👋 Saluer')}${btn('intro', '🙋 Me présenter')}${btn('compl:tenue', '👗 Compliment : tenue')}${btn('compl:aimable', '😊 Compliment : amabilité')}${btn('compl:quartier', '🏘️ Compliment : quartier')}${btn('joke', '😂 Blague')}${askBtn}${btn('bye', '👋 Au revoir')}</div>
      <div class="tk-write"><input class="tk-in" type="text" maxlength="200" placeholder="Discute librement…"><button data-sc="send">Envoyer</button></div>
      <p class="tk-note">Personnage fictif. Le contact n’est enregistré qu’avec son accord ; un refus doit être respecté.</p></div>`;
    const lg = this.dom.querySelector('.tk-log'); if (lg) lg.scrollTop = lg.scrollHeight;
  }
  onClick(ev) {
    const b = ev.target.closest('[data-sc]'); if (!b) { if (ev.target === this.dom) this.close(); return; }
    ev.stopPropagation(); const [a, arg] = b.dataset.sc.split(':');
    if (a === 'x') return this.close();
    if (a === 'send') return this.sendInput();
    if (a === 'noop') return;
    this.act(a, arg);
  }
  handleKeys(input) { if (input.hit('Escape')) this.close(); }
  // ------------------------------------------------------------------ carnet (téléphone)
  friends() { return Object.values(this.book).map((b) => ({ key: b.id, kind: 'ami', name: b.name, role: `${b.job} • rencontré${b.female ? 'e' : ''} : ${b.metPlace}`, icon: b.female ? '👩🏿' : '👨🏿', friend: b })); }
  remove(id) { if (!this.book[id]) return false; delete this.book[id]; const pid = id.slice(2); if (this.met[pid]) this.met[pid].accepted = false; this.onSave && this.onSave(); return true; }
  note(id, txt) { const b = this.book[id]; if (!b) return; b.hist.unshift({ t: this.economy.stamp(), txt }); b.hist.length = Math.min(b.hist.length, 30); }
  reply(c, txt) { // messages et appels avec un contact rencontré
    const b = c.friend, t = norm(txt), h = this.env.time; this.note(b.id, `Message : « ${txt.slice(0, 50)} »`);
    if (/(on se voit|rendez.vous|week.?end|boire un|manger ensemble)/.test(t)) return b.rapport >= 55 ? 'Avec plaisir ! Écris-moi quand tu es disponible.' : 'Peut-être, je te dirai. Je suis assez occupé·e en ce moment.'.replace('occupé·e', b.female ? 'occupée' : 'occupé');
    if (/(ca va|comment vas|nouvelles)/.test(t)) return pickR(Math.random, ['Ça va bien, merci ! Et toi ?', 'Tout va bien de mon côté 🙂', 'Ça va, merci de prendre des nouvelles !']);
    if (/(ravi|plaisir|rencontr)/.test(t)) { b.rapport = Math.min(100, b.rapport + 2); return 'Moi aussi, c’était une belle rencontre !'; }
    if (h < 7 || h > 22) return 'Je dormais… on se parle demain ? 😴';
    return pickR(Math.random, ['Merci pour ton message !', 'D’accord 🙂', 'Je vois ! Bonne journée à toi.']);
  }
  serialize() { const met = {}; for (const [k, m] of Object.entries(this.met)) if (m.refused || m.accepted) met[k] = { rapport: m.rapport, refused: m.refused, accepted: m.accepted, greeted: false, introduced: m.introduced, named: m.named, compl: {}, joked: false, chat: 0, asked: m.asked, pushy: 0 }; return { book: this.book, met }; }
  restore(s) { if (!s) return; this.book = s.book || {}; this.met = s.met || {}; }
}
