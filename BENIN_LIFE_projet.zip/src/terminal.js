// Mission 021, étape 1 — terminal international de l'aéroport de Cotonou (disposition fictive ; bâtiment existant de la
// mission 012 rendu visitable). Intérieur isolé : hall d'accueil, bureau d'information, tableau des départs, comptoirs
// d'enregistrement (compagnies fictives), contrôle des billets et de sûreté, boutiques (souvenirs du Bénin, boutique hors
// taxes fictive), restaurant et café, portes d'embarquement A1–A4, salon VIP, salon privé du PDG. PNJ : voyageurs,
// pilotes, hôtesses, agents d'aéroport, sûreté, commerçants. Application « NOVA TRAVEL » : destinations et horaires.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { colorize } from './vehicles.js';
import { createCharacter, SKINS } from './character.js';
import { fcfa } from './food-data.js';
import { ARTICLE_BY_ID } from './market-data.js';
import { AIRLINES, DESTS, departures, status, hh } from './travel-data.js';

const PI = Math.PI;
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const pick = (a) => a[Math.floor(Math.random() * a.length)];
export const TERM = { LV: 180, Y: 640, O: { x: -680, z: 141 }, DOOR: { x: -558.4, z: 141 } };
const SHOP = [ // articles vendus au terminal (ajoutés au catalogue des articles du joueur)
  ['apt_pagne', '🧵', 'Pagne tissé artisanal', 'Souvenir du Bénin, tissage local (boutique du terminal).', 18000, 'souv'],
  ['apt_bronze', '🏺', 'Statuette en bronze (artisanat)', 'Artisanat d’art inspiré des bronzes du Bénin, fabrication contemporaine.', 45000, 'souv'],
  ['apt_livre', '📖', 'Beau livre « Bénin, terre de culture »', 'Livre de photos et d’histoire (édition fictive).', 15000, 'souv'],
  ['apt_cajou', '🥜', 'Noix de cajou grillées', 'Produit du Bénin, sachet de 500 g.', 4000, 'souv'],
  ['apt_parfum', '🧴', 'Parfum « Lagune » (marque fictive)', 'Eau de parfum, boutique hors taxes.', 65000, 'duty'],
  ['apt_montre', '⌚', 'Montre élégante (marque fictive)', 'Boutique hors taxes du terminal.', 250000, 'duty'],
  ['apt_chocolat', '🍫', 'Coffret de chocolats', 'Boutique hors taxes du terminal.', 12000, 'duty'],
  ['apt_casque', '🎧', 'Casque audio de voyage', 'Réduction de bruit, boutique hors taxes.', 90000, 'duty'],
];
for (const [id, icon, name, desc] of SHOP) if (!ARTICLE_BY_ID[id]) ARTICLE_BY_ID[id] = { id, icon, name, desc };
const MEALS = [['Thiéboudienne du Golfe (plat fictif de la carte)', 6500, 45], ['Poulet braisé, alloco', 5500, 40], ['Salade de fruits frais', 2500, 15], ['Jus de bissap', 1500, 6], ['Café et beignets', 2000, 10]];

export class Terminal {
  constructor(ctx) {
    Object.assign(this, ctx); // scene, world, player, ui, audio, env, economy, needs, tpc, home, bizUI, driver, onSave
    this.inside = false; this.points = []; this.people = []; this.vipUntil = 0; this.spent = []; this.view = 'dest'; this.sel = null;
    this.buildOutside(); this.buildInside();
  }
  abs() { return (this.economy.day || 1) * 24 + this.env.time; }
  // ------------------------------------------------------------------ extérieur : porte du terminal, parking signalé
  buildOutside() {
    const g = new THREE.Group(); g.name = 'TERMINAL_PORTE'; this.scene.add(g); const P = [], D = TERM.DOOR;
    const box = (x0, y0, z0, x1, y1, z1, c) => P.push(colorize(new THREE.BoxGeometry(Math.abs(x1 - x0), Math.abs(y1 - y0), Math.abs(z1 - z0)).translate((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), c));
    box(D.x - 1.65, 0, D.z - 3, D.x - 1.55, 3.4, D.z + 3, 0x2a4a5a); box(D.x - 1.6, 3.4, D.z - 3.4, D.x + 1.2, 3.7, D.z + 3.4, 0xf2f0ea); // portes vitrées et auvent
    for (const z of [-3.2, 3.2]) box(D.x - 1.6, 0, D.z + z - 0.1, D.x + 1.2, 3.4, D.z + z + 0.1, 0xd8d4cc);
    for (let k = 0; k < 8; k++) box(-548 + k * 3, 0.03, 118, -547.9 + k * 3, 0.05, 124, 0xf6f6f6); // parking : places marquées
    this.label(g, 'TERMINAL INTERNATIONAL', 'Départs • Arrivées • Salon VIP', 6, 1.2, '#0b2a4a', D.x - 1.5, 4.6, D.z, -PI / 2);
    this.label(g, 'P', 'Parking du terminal', 1.6, 1.6, '#1f4e9c', -536, 2.8, 117, PI);
    g.add(new THREE.Mesh(mergeGeometries(P), new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.6 })));
  }
  label(g, a, b, w, h, bg, x, y, z, ry) {
    const c = document.createElement('canvas'); c.width = 512; c.height = Math.round(512 * h / w); const t = c.getContext('2d'); t.fillStyle = bg; t.fillRect(0, 0, c.width, c.height); t.fillStyle = '#fff'; t.textAlign = 'center';
    t.font = `900 ${Math.round(c.height * (b ? 0.34 : 0.7))}px Arial`; t.fillText(a, c.width / 2, c.height * (b ? 0.48 : 0.75)); if (b) { t.font = `700 ${Math.round(c.height * 0.18)}px Arial`; t.fillText(b, c.width / 2, c.height * 0.8); }
    const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace; const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ map: tex, toneMapped: false })); m.position.set(x, y, z); m.rotation.y = ry; g.add(m); return m;
  }
  // ------------------------------------------------------------------ intérieur (niveau isolé)
  buildInside() {
    const { LV, Y, O } = TERM, g = new THREE.Group(); g.position.set(O.x, Y, O.z); g.visible = false; this.scene.add(g); this.inGroup = g;
    const parts = [], glass = [], glow = [], col = this.world.collision, H = 6;
    const box = (x0, y0, z0, x1, y1, z1, c, arr = parts) => arr.push(colorize(new THREE.BoxGeometry(Math.abs(x1 - x0) || 0.01, Math.abs(y1 - y0) || 0.01, Math.abs(z1 - z0) || 0.01).translate((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), c));
    const solid = (x0, z0, x1, z1, h = H) => { const o = col.addBox(O.x + Math.min(x0, x1), O.z + Math.min(z0, z1), O.x + Math.max(x0, x1), O.z + Math.max(z0, z1), Y + h); o.lv = LV; return o; };
    const P = (x, z, r, label, action) => this.points.push({ x, z, r, label, action });
    // sol, murs, verrière
    box(-51, -0.1, -21, 51, 0, 21, 0x9a9488); for (let x = -50; x < 50; x += 4) box(x, 0.001, -20, x + 0.06, 0.004, 20, 0x6a665e); for (let z = -20; z < 20; z += 4) box(-50, 0.001, z, 50, 0.004, z + 0.06, 0x6a665e); box(-12, 0.002, -2.2, 46, 0.006, 2.2, 0x1f4e9c); // dalles de pierre, allée bleue
    const wall = (x0, z0, x1, z1) => { box(x0, 0, z0, x1, H, z1, 0xc8c2b6); solid(x0, z0, x1, z1); };
    wall(-51, 20, 51, 20.3); wall(-51, -20.3, 51, -20); wall(-51, -20, -50.7, 20); wall(50.7, -20, 51, -2.2); wall(50.7, 2.2, 51, 20);
    box(-50, H - 0.2, -20, 50, H, 20, 0xdfe6ea, glass); for (let x = -48; x <= 48; x += 8) box(x - 0.15, H - 0.6, -20, x + 0.15, H - 0.2, 20, 0xc8ccd2); // verrière
    box(50.75, 0, -2.2, 50.85, 3.2, 2.2, 0x2a4a5a, glass); // portes d'entrée
    // hall : bureau d'information, tableau des départs, bancs, plantes
    box(38, 0, 11, 42, 1.05, 12.2, 0x0b6e4f); box(37.9, 1.05, 10.9, 42.1, 1.12, 12.3, 0xece6dc); solid(38, 11, 42, 12.2, 1.1); P(40, 9.8, 1.6, 'Bureau d’information de l’aéroport', () => this.info());
    box(30, 2.4, 19.85, 42, 5.4, 20, 0x0a0a0c); this.board = new THREE.Mesh(new THREE.PlaneGeometry(11.6, 2.9), new THREE.MeshBasicMaterial({ toneMapped: false })); this.board.position.set(36, 3.9, 19.8); this.board.rotation.y = PI; g.add(this.board);
    P(36, 16.8, 2.4, 'Consulter le tableau des départs', () => this.openApp('horaires'));
    for (const [x, z] of [[28, -8], [28, -12], [34, -8], [34, -12]]) { box(x - 2.5, 0.42, z - 0.35, x + 2.5, 0.5, z + 0.35, 0x2a2d33); box(x - 2.5, 0.5, z + 0.25, x + 2.5, 0.95, z + 0.35, 0x2a2d33); for (const dx of [-2.2, 2.2]) box(x + dx - 0.05, 0, z - 0.3, x + dx + 0.05, 0.42, z + 0.3, 0xc8ccd2); solid(x - 2.5, z - 0.35, x + 2.5, z + 0.35, 0.9); }
    for (const [x, z] of [[47, 17], [47, -17], [23, 17], [23, -17], [-48, -2], [3, 17]]) { box(x - 0.45, 0, z - 0.45, x + 0.45, 0.8, z + 0.45, 0x3a3d42); box(x - 0.7, 0.8, z - 0.7, x + 0.7, 2.4, z + 0.7, 0x2f7a3a); solid(x - 0.5, z - 0.5, x + 0.5, z + 0.5, 2.4); }
    // comptoirs d'enregistrement (3 compagnies fictives) et files d'attente
    this.desks = [];
    Object.keys(AIRLINES).forEach((k, i) => { const x = 12 + i * 4; box(x - 1.5, 0, 12, x + 1.5, 1.05, 13.2, 0xd8dde2); box(x - 1.55, 1.05, 11.95, x + 1.55, 1.1, 13.25, 0x1a1a1e); box(x - 1.4, 0, 11.8, x + 1.4, 0.35, 12, 0x2a2d33); solid(x - 1.55, 12, x + 1.55, 13.25, 1.1); this.desks.push({ k, x }); for (let q = 0; q < 3; q++) box(x - 1.6 + q * 1.6 - 0.04, 0, 7.5, x - 1.6 + q * 1.6 + 0.04, 1.0, 7.58, 0xc8ccd2); box(x - 1.6, 0.92, 7.5, x + 1.6, 0.97, 7.56, AIRLINES[k].color === '#0b6e4f' ? 0x0b6e4f : AIRLINES[k].color === '#1f4e9c' ? 0x1f4e9c : 0xc8102e); P(x, 10.6, 1.5, `Comptoir d’enregistrement ${AIRLINES[k].name}`, () => this.checkin(k)); });
    // contrôle des billets et de sûreté : cloison x = 6 avec deux couloirs équipés de portiques
    for (const [z0, z1] of [[-20, -6.5], [-2.5, 2.5], [6.5, 20]]) { box(5.9, 0, z0, 6.1, 2.6, z1, 0x9ab8c4, glass); solid(5.9, z0, 6.1, z1, 2.6); }
    for (const zc of [-4.5, 4.5]) { box(5.6, 0, zc - 2, 6.4, 2.4, zc - 1.85, 0x8a8f96); box(5.6, 0, zc + 1.85, 6.4, 2.4, zc + 2, 0x8a8f96); box(5.6, 2.25, zc - 2, 6.4, 2.4, zc + 2, 0x8a8f96); box(7, 0, zc - 1, 9.5, 0.85, zc - 0.6, 0x2a2d33); }
    box(9.5, 0, -1.2, 11, 1.05, 1.2, 0x1f4e9c); solid(9.5, -1.2, 11, 1.2, 1.1); P(8.6, -4.5, 1.6, 'Contrôle des billets et de sûreté', () => this.security()); P(8.6, 4.5, 1.6, 'Contrôle des billets et de sûreté', () => this.security());
    this.label(g, 'CONTRÔLE • SÛRETÉ', 'Billet et pièce d’identité', 4, 0.8, '#1f4e9c', 6.25, 3.3, 0, PI / 2);
    // boutiques (nord) et restaurant / café (sud)
    for (const [x0, x1, t, sub, k, col2] of [[-10, -3.4, 'BOUTIQUE HORS TAXES', 'Parfums • montres • chocolats (marques fictives)', 'duty', '#2a2d33'], [-3, 4, 'SOUVENIRS DU BÉNIN', 'Artisanat • pagnes • livres • cajou', 'souv', '#b4532a']]) {
      for (let s = 0; s < 3; s++) { box(x0 + 0.4, 0, 19.2 - s * 0.01, x1 - 0.4, 2.2, 19.8, 0x5a3a22); for (let j = 0; j < 4; j++) box(x0 + 0.5, 0.3 + j * 0.5, 19.15, x1 - 0.5, 0.35 + j * 0.5, 19.7, 0x8a6440); }
      for (let i = 0; i < 12; i++) box(x0 + 0.7 + (i % 6) * ((x1 - x0 - 1.4) / 6), 0.36 + Math.floor(i / 6) * 0.5, 19.3, x0 + 0.95 + (i % 6) * ((x1 - x0 - 1.4) / 6), 0.6 + Math.floor(i / 6) * 0.5, 19.6, [0xe8112d, 0xfcd116, 0x0b6e4f, 0x2f80ed, 0xf6f6f6, 0x7a2a8a][i % 6]);
      solid(x0 + 0.4, 19.1, x1 - 0.4, 19.8, 2.2); box((x0 + x1) / 2 - 1, 0, 15.4, (x0 + x1) / 2 + 1, 1.0, 16.2, 0x1a1a1e); solid((x0 + x1) / 2 - 1, 15.4, (x0 + x1) / 2 + 1, 16.2, 1);
      this.label(g, t, sub, 5.6, 0.8, col2, (x0 + x1) / 2, 3.2, 19.75, PI); P((x0 + x1) / 2, 14.2, 1.7, t === 'SOUVENIRS DU BÉNIN' ? 'Boutique Souvenirs du Bénin' : 'Boutique hors taxes (marques fictives)', () => this.shop(k));
    }
    box(-12, 0, -19.6, -1, 1.1, -18.6, 0x6a4a32); box(-12.05, 1.1, -19.65, -0.95, 1.16, -18.55, 0xece6dc); solid(-12, -19.6, -1, -18.6, 1.2);
    for (let i = 0; i < 6; i++) { const x = -11 + (i % 3) * 4, z = -15 + Math.floor(i / 3) * 3.4; box(x - 0.6, 0.72, z - 0.6, x + 0.6, 0.78, z + 0.6, 0xd8c08a); box(x - 0.06, 0, z - 0.06, x + 0.06, 0.72, z + 0.06, 0x2a2d33); solid(x - 0.6, z - 0.6, x + 0.6, z + 0.6, 0.8); for (const [dx, dz] of [[-1, 0], [1, 0]]) box(x + dx - 0.22, 0, z + dz - 0.22, x + dx + 0.22, 0.48, z + dz + 0.22, 0xc8102e); }
    this.label(g, 'RESTAURANT LE GOLFE • CAFÉ', 'Cuisine béninoise et africaine (établissement fictif)', 6, 0.8, '#6a1a2a', -6.5, 3.2, -19.75, 0); P(-6.5, -17.2, 1.8, 'Restaurant Le Golfe et café', () => this.restaurant());
    // portes d'embarquement A1–A4 (sud-ouest) avec comptoirs, rangées de sièges et passerelles
    this.gates = {};
    ['A1', 'A2', 'A3', 'A4'].forEach((gt, i) => { const x = -46 + i * 8.5; box(x - 1.6, 0, -19.95, x + 1.6, 3, -19.9, 0x3a3d42); box(x - 1.2, 0, -16.6, x + 1.2, 1.05, -15.8, 0xd8dde2); solid(x - 1.2, -16.6, x + 1.2, -15.8, 1.1);
      this.label(g, `PORTE ${gt}`, '', 2.2, 0.7, '#0b2a4a', x, 3.6, -19.85, 0); this.gates[gt] = { x, z: -14.8 };
      for (const z of [-10, -7]) { box(x - 2.8, 0.42, z - 0.3, x + 2.8, 0.5, z + 0.3, 0x1f4e9c); box(x - 2.8, 0.5, z + 0.22, x + 2.8, 0.95, z + 0.3, 0x1f4e9c); solid(x - 2.8, z - 0.3, x + 2.8, z + 0.3, 0.9); }
      P(x, -14.3, 1.5, `Porte ${gt} : comptoir d’embarquement`, () => this.gate(gt)); });
    // salon VIP (nord-ouest, cloison vitrée, accès contrôlé) et salon privé du PDG
    box(-40, 0, 9.9, -29, 2.8, 10.1, 0x9ab8c4, glass); box(-25, 0, 9.9, -14, 2.8, 10.1, 0x9ab8c4, glass); solid(-40, 9.9, -29, 10.1, 2.8); solid(-25, 9.9, -14, 10.1, 2.8); box(-14.1, 0, 10, -13.9, 2.8, 20, 0x9ab8c4, glass); solid(-14.1, 10, -13.9, 20, 2.8);
    this.vipDoor = solid(-29, 9.9, -25, 10.1, 2.8); box(-29, 2.8, 9.85, -25, 3.6, 10.15, 0xd8a830);
    this.label(g, 'SALON VIP', 'Classe affaires • carte NOVA TRAVEL Platinum', 4, 0.9, '#3a2416', -27, 4.1, 9.8, PI);
    box(-39.5, 0, 10.5, -14.5, 0.02, 19.5, 0x3a2416); for (let k = 0; k < 4; k++) { const x = -37 + k * 6; box(x - 1.2, 0.4, 16, x + 1.2, 0.8, 16.9, 0x6a4630); box(x - 1.2, 0.8, 16.7, x + 1.2, 1.2, 16.9, 0x6a4630); solid(x - 1.2, 16, x + 1.2, 16.9, 1.2); box(x - 0.5, 0.4, 13.6, x + 0.5, 0.45, 14.4, 0xece6dc); }
    box(-20, 0, 18.6, -15, 1.1, 19.6, 0x1a1a1e); solid(-20, 18.6, -15, 19.6, 1.2); for (let k = 0; k < 8; k++) box(-19.6 + k * 0.55, 1.1, 19.2, -19.4 + k * 0.55, 1.4, 19.4, [0xe46a1f, 0xfcd116, 0xe8112d, 0x2fb04a][k % 4], glow);
    P(-27, 8.7, 1.8, 'Entrée du salon VIP', () => this.vip()); P(-17.5, 17.5, 1.8, 'Bar du salon VIP (jus de fruits, collations)', () => this.vipBar());
    box(-50.5, 0, 7.9, -42.5, 3.2, 8.1, 0xf2f0ea); solid(-50.5, 7.9, -42.5, 8.1, 3.2); box(-41, 0, 7.9, -40.1, 3.2, 8.1, 0xf2f0ea); solid(-41, 7.9, -40.1, 8.1, 3.2); box(-40.1, 0, 8, -39.9, 3.2, 20, 0xf2f0ea); solid(-40.1, 8, -39.9, 20, 3.2);
    this.pdgDoor = solid(-42.5, 7.9, -41, 8.1, 3.2); box(-42.5, 3.2, 7.85, -41, 3.6, 8.15, 0xd8a830); this.label(g, 'SALON PRIVÉ DU PDG', 'NOVA GROUPE', 3, 0.7, '#0b6e4f', -45, 4.0, 7.8, PI);
    box(-50, 0, 8.6, -40.5, 0.02, 19.5, 0x6a1a2a); box(-49.4, 0.4, 12, -48.4, 0.85, 17, 0x1a1a1e); box(-49.4, 0.85, 12, -49.2, 1.3, 17, 0x1a1a1e); solid(-49.4, 12, -48.4, 17, 1.0); box(-46.5, 0.72, 13.5, -43, 0.78, 15.5, 0x5a3a22); solid(-46.5, 13.5, -43, 15.5, 0.8); box(-42, 0.75, 18.4, -40.6, 0.8, 19.6, 0x3a2416); solid(-42, 18.4, -40.6, 19.6, 0.8);
    P(-47.5, 14.5, 1.6, 'Se reposer dans le salon privé du PDG', () => this.pdgRest()); P(-44.8, 12.8, 1.6, 'Table de réunion (NOVA Gestion)', () => this.bizUI && this.bizUI.toggle(true)); P(-41.2, 17.6, 1.4, 'Bar privé (jus de fruits)', () => this.vipBar());
    P(-41.75, 6.9, 1.4, 'Salon privé du PDG', () => this.pdg());
    P(48.8, 0, 1.6, 'Sortir du terminal', () => this.exit());
    for (let x = -46; x <= 46; x += 8) for (const z of [-14, 0, 14]) box(x - 0.25, H - 0.3, z - 0.25, x + 0.25, H - 0.22, z + 0.25, 0xfff4e0, glow);
    const mk = (arr, m) => { if (!arr.length) return; const ms = new THREE.Mesh(mergeGeometries(arr), m); ms.receiveShadow = true; g.add(ms); };
    mk(parts, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.6 })); mk(glass, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.05, metalness: 0.2, transparent: true, opacity: 0.35, depthWrite: false })); mk(glow, new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false }));
    this.drawBoard();
  }
  drawBoard() {
    if (!this._bc) { this._bc = document.createElement('canvas'); this._bc.width = 1024; this._bc.height = 256; this._bt = new THREE.CanvasTexture(this._bc); this._bt.colorSpace = THREE.SRGBColorSpace; this.board.material.map = this._bt; }
    const c = this._bc.getContext('2d'), deps = departures(this.abs(), 30).slice(0, 7); c.fillStyle = '#0a0d14'; c.fillRect(0, 0, 1024, 256); c.fillStyle = '#fcd116'; c.font = '900 26px Arial'; c.fillText('DÉPARTS • DEPARTURES', 16, 30); c.font = '700 15px Arial'; c.fillStyle = '#8a8f96'; c.fillText(`Heure locale ${hh(this.env.time)} • vols fictifs`, 720, 28);
    deps.forEach((d, i) => { const y = 60 + i * 27, [st, sc] = status(d, this.abs()); c.fillStyle = i % 2 ? '#121722' : '#0e131c'; c.fillRect(10, y - 19, 1004, 25); c.font = '700 18px Arial'; c.fillStyle = '#fff'; c.fillText(hh(d.h), 18, y); c.fillText(d.D.num, 100, y); c.fillText(`${d.D.city} (${d.D.country})`, 210, y); c.fillStyle = '#d8dde2'; c.fillText(AIRLINES[d.D.air].name, 560, y); c.fillText(d.D.gate, 760, y); c.fillStyle = sc; c.fillText(st, 830, y); });
    this._bt.needsUpdate = true;
  }
  // ------------------------------------------------------------------ PNJ
  clearPeople() { for (const p of this.people) p.c.group.parent && p.c.group.parent.remove(p.c.group); this.people = []; }
  spawnPeople() {
    this.clearPeople(); const g = this.inGroup;
    const add = (o, d) => { const c = createCharacter(o); g.add(c.group); const p = { c, x: d.x, z: d.z, h: d.h || 0, path: [], ...d }; c.group.position.set(p.x, 0, p.z); c.group.rotation.y = p.h; this.people.push(p); return p; };
    const staff = (o, x, z, h, role, name) => add({ skin: pick(SKINS), pants: 0x1a1d24, ...o }, { x, z, h, role, name, staff: true });
    Object.keys(AIRLINES).forEach((k, i) => staff({ female: i !== 1, shirtColor: [0x0b6e4f, 0x1f4e9c, 0xc8102e][i], collar: true, skirt: i !== 1 }, 12 + i * 4, 13.9, PI, 'agent', ['Mme Clarisse Adjovi', 'M. Hervé Dansou', 'Mme Ruth Akpo'][i]));
    staff({ female: true, shirtColor: 0x0b6e4f, collar: true }, 40, 12.9, PI, 'info', 'Mme Ange Sossou');
    for (const z of [-4.5, 4.5]) staff({ female: z > 0, shirtColor: 0x1a2a44, hat: 'cap', hatColor: 0x1a2a44 }, 7.4, z + 1.2, -PI / 2, 'surete', z > 0 ? 'Mme Joëlle Hounkanrin' : 'M. Patrice Ahouandjinou');
    staff({ female: false, shirtColor: 0x1f4e9c, collar: true }, 10.3, 1.9, -PI / 2, 'billets', 'M. Rodrigue Assogba');
    staff({ female: true, shirtColor: 0xf6f6f6, collar: true }, -6.7, 16.8, 0, 'shop', 'Mme Nadia Hessou'); staff({ female: false, shirtColor: 0xb4532a, collar: true }, 0.5, 16.8, 0, 'shop', 'M. Aristide Gnonlonfoun');
    staff({ female: true, shirtColor: 0xf6f6f6, headwrap: true }, -6.5, -18, 0, 'resto', 'Mme Pélagie Kiki');
    staff({ female: true, shirtColor: 0x6a1a2a, jacket: true, collar: true, skirt: true }, -27, 8.3, PI, 'vip', 'Mme Grâce Tossou');
    ['A1', 'A2'].forEach((gt, i) => staff({ female: i === 0, shirtColor: 0x0b6e4f, jacket: true, collar: true, skirt: i === 0 }, this.gates[gt].x, -16.9, 0, 'porte', i ? 'M. Serge Fanou' : 'Mme Estelle Avocè'));
    // équipages : pilotes et hôtesses qui traversent le terminal
    this.crew = [];
    for (let i = 0; i < 5; i++) { const pilot = i < 2, p = add({ female: !pilot || i === 1, skin: pick(SKINS), shirtColor: 0xf6f6f6, jacket: true, pants: 0x0a1a3a, tie: pilot, collar: true, hat: pilot ? 'cap' : undefined, hatColor: 0x0a1a3a, skirt: !pilot }, { x: -2 - i * 1.2, z: 1, role: pilot ? 'pilote' : 'hotesse', name: pilot ? (i ? 'Commandante Élise Gbaguidi' : 'Commandant Marc Houngbédji') : ['Hôtesse Sika', 'Hôtesse Mariam', 'Steward Josué'][i - 2], route: 'crew', speed: 1.25, k: i }); this.crew.push(p); }
    // voyageurs (avec valise), assis aux portes ou en mouvement
    for (let i = 0; i < 16; i++) { const f = i % 2 === 0, p = add({ female: f, skin: pick(SKINS), shirtColor: pick([0xfcd116, 0x2f80ed, 0xe8112d, 0x0b6e4f, 0xe46a1f, 0x7a2a8a, 0xf6f6f6]), pants: pick([0x1f2a44, 0x2a2d33, 0x6a4a32]), skirt: f && i % 4 === 0, headwrap: f && i % 3 === 0 }, { x: 46, z: 0, role: 'voyageur', name: f ? 'Voyageuse' : 'Voyageur', speed: 1.1 + Math.random() * 0.3, k: i });
      const bag = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.55, 0.24), new THREE.MeshStandardMaterial({ color: pick([0x1a1a1e, 0x6a1a2a, 0x1f4e9c, 0xc8c2b6]) })); bag.position.set(0.35, 0.3, -0.25); p.c.group.add(bag); p.bag = bag;
      if (i < 6) { const gt = this.gates[['A1', 'A2', 'A3', 'A4'][i % 4]]; p.seat = { x: gt.x - 2 + (i % 3) * 1.6, z: i < 3 ? -10.08 : -7.08 }; p.x = p.seat.x; p.z = p.seat.z; p.c.sit(false); p.c.group.position.set(p.x, -0.05, p.z); p.c.group.rotation.y = PI; p.bag.position.set(0.45, 0.28, 0.35); }
      else { p.route = 'voyageur'; p.t = (i - 6) * 0.1; this.newPath(p, true); } }
  }
  route(kind) { // parcours dans les zones ouvertes (pas de cloison traversée : couloirs de contrôle aux z = ±4,5)
    const lane = Math.random() < 0.5 ? -4.5 : 4.5, gt = pick(['A1', 'A2', 'A3', 'A4']), gx = this.gates[gt].x;
    const door = [[gx + 3.6, -4], [gx + 3.6, -12.8], [gx + 1.7, -13.6], [gx + 1.7, -18.4], [gx, -18.8]];
    if (kind === 'crew') return [[18, 2], [12.2, lane], [9, lane], [3, lane], [-6, 0], [-12, -4], ...door];
    const k = Math.floor(Math.random() * 3); const eat = Math.random() < 0.33; return [[46, 0], [36, 2], [12 + k * 4, 9], [12 + k * 4, 6.5], [12.2, lane], [9, lane], [3, lane], [-5, lane * 0.3], ...(eat ? [[-5, -13.3], [-5, -4]] : Math.random() < 0.5 ? [[-6.5, 12], [-6.5, 2]] : []), [-12, -4], ...door];
  }
  newPath(p, mid) { const r = this.route(p.route); const k = mid ? Math.floor(Math.random() * (r.length - 2)) : 0; p.path = r.slice(k + 1); [p.x, p.z] = r[k]; p.wait = 0; }
  // ------------------------------------------------------------------ entrer / sortir
  enter() {
    const { Y, LV, O } = TERM, pl = this.player; this.inside = true; this.inGroup.visible = true; this.world.collision.level = LV; pl.floorY = Y; pl.vy = 0;
    pl.pos.set(O.x + 47.5, Y, O.z); pl.facing = -PI / 2; pl.mesh.position.copy(pl.pos); if (this.tpc && this.tpc.snap) this.tpc.snap(pl.pos);
    this.vipDoor.disabled = this.vipOk(); this.pdgDoor.disabled = true; this.spawnPeople(); this.drawBoard(); this._bd = 0;
    this.ui.toast('✈️ Terminal international de l’aéroport de Cotonou (disposition fictive) — vols et compagnies fictifs.', 3.5); if (this.audio && this.audio.ctx) this.audio.door();
  }
  exit(silent) {
    const pl = this.player, D = TERM.DOOR; this.inside = false; this.inGroup.visible = false; this.world.collision.level = 0; pl.floorY = 0; pl.vy = 0; this.clearPeople();
    pl.pos.set(D.x + 1.8, 0, D.z); pl.facing = PI / 2; pl.mesh.position.copy(pl.pos); if (this.tpc && this.tpc.snap) this.tpc.snap(pl.pos); this.lightOff(); if (!silent) this.ui.toast('Tu sors du terminal.', 1.5);
  }
  lightOff() { const ls = this.home && this.home.lights; if (!ls || !this._orig) return; ls.forEach((l, i) => { l.position.copy(this._orig[i].p); l.distance = this._orig[i].d; l.intensity = 0; l.color.setHex(0xffe8c8); }); }
  zoneLabel() { if (!this.inside) return null; const P = this.player.pos, x = P.x - TERM.O.x, z = P.z - TERM.O.z; return x > 6 ? 'Aéroport — hall et enregistrement' : x < -40 && z > 8 ? 'Aéroport — salon privé du PDG' : z > 10 && x < -14 ? 'Aéroport — salon VIP' : 'Aéroport — zone d’embarquement'; }
  // ------------------------------------------------------------------ interactions
  nearest(x, z) {
    if (!this.inside) { const d = Math.hypot(x - (TERM.DOOR.x + 1.6), z - TERM.DOOR.z); return d < 2.4 ? { d, it: { label: () => 'Entrer dans le terminal international', action: () => this.enter() } } : null; }
    const O = TERM.O; let best = null;
    for (const p of this.points) { const d = Math.hypot(x - (O.x + p.x), z - (O.z + p.z)); if (d < p.r && (!best || d < best.d)) best = { d, it: { label: () => p.label, action: p.action } }; }
    for (const p of this.people) { const d = Math.hypot(x - (O.x + p.x), z - (O.z + p.z)); if (d < 1.4 && (!best || d < best.d - 0.2)) best = { d, it: { label: () => `Parler à ${p.name}${p.staff ? '' : ''}`, action: () => this.talk(p) } }; }
    return best;
  }
  talk(p) {
    const L = { agent: 'Bonjour ! L’enregistrement ouvre 3 heures avant le départ. Les réservations se font dans l’application NOVA TRAVEL ou ici.', info: 'Bienvenue à l’aéroport ! Le tableau des départs est derrière moi ; le salon VIP est au fond à gauche après le contrôle.', surete: 'Contrôle de sûreté : billet et pièce d’identité, s’il vous plaît. Liquides en petits flacons.', billets: 'Je vérifie les cartes d’embarquement avant la zone des portes.', shop: 'Bonjour, bienvenue ! Tout est en FCFA.', resto: 'Bonjour ! Plat du jour et jus frais, installez-vous.', vip: 'Bienvenue au salon VIP. L’accès est réservé à la classe affaires et aux détenteurs de la carte NOVA TRAVEL Platinum.', porte: 'L’embarquement commence 45 minutes avant le départ. Présentez votre carte d’embarquement ici.', pilote: pick(['Belle météo sur le golfe aujourd’hui !', 'Nous décollons dans une heure, la check-list est faite.', 'Bonjour ! Pilote de ligne depuis 15 ans.']), hotesse: pick(['Bonjour ! Je rejoins mon équipage à la porte.', 'Bon voyage à vous !']) };
    this.ui.toast(`${p.name} : « ${L[p.role] || pick(['Bonjour !', 'J’attends mon vol pour Abidjan.', 'Première fois en classe affaires !', 'Je rentre à Paris ce soir.', 'Mon vol est à l’heure, ouf !'])} »`, 4);
  }
  info() { const n = departures(this.abs(), 12).filter((d) => d.at >= this.abs()).slice(0, 3); this.ui.openMenu('ℹ️ Bureau d’information', 'Aéroport de Cotonou (disposition fictive) • vols et compagnies fictifs', [
    { label: '🛫 Prochains départs', action: () => this.ui.toast(n.map((d) => `${hh(d.h)} ${d.D.num} → ${d.D.city} (porte ${d.D.gate})`).join(' • '), 6) },
    { label: '📱 Ouvrir NOVA TRAVEL', action: () => this.openApp('dest') }, { label: '🥂 Salon VIP : conditions d’accès', action: () => this.ui.toast('Salon VIP : billet en classe affaires ou carte NOVA TRAVEL Platinum (1 500 000 FCFA, 30 jours). Salon privé du PDG : réservé à toi.', 5) },
    { label: '🚗 Parking : à l’extérieur, côté est du terminal', action: () => this.ui.toast('Parking du terminal : places marquées à l’est du terminal, près de la tour de contrôle.', 3) } ]); }
  checkin(k) { this.ui.toast(`🧳 ${AIRLINES[k].name} : enregistrement des bagages et cartes d’embarquement. La réservation des billets arrive avec la prochaine étape (vols).`, 4.5); }
  security() { this.ui.toast('🛂 Contrôle de sûreté : passage du portique. (Les cartes d’embarquement seront exigées dès l’ouverture des réservations.)', 4); }
  gate(gt) { const n = departures(this.abs(), 24).filter((d) => d.D.gate === gt && d.at >= this.abs()).slice(0, 2); this.ui.toast(`🛫 Porte ${gt} : ${n.length ? n.map((d) => `${hh(d.h)} ${d.D.num} → ${d.D.city} (${status(d, this.abs())[0].toLowerCase()})`).join(' • ') : 'aucun départ prévu aujourd’hui'}.`, 5); }
  shop(k) {
    const list = SHOP.filter((s) => s[5] === k);
    this.ui.openMenu(k === 'duty' ? '🛍️ Boutique hors taxes' : '🎁 Souvenirs du Bénin', 'Articles ajoutés à « Mes articles » du téléphone (rangeables à la villa).', list.map(([id, icon, name, , price]) => ({ label: `${icon} ${name}`, desc: fcfa(price), action: () => { if (!this.economy.pay(price, `${name} — terminal de l’aéroport`, 'Aéroport de Cotonou')) return this.ui.toast('Solde insuffisant.', 2); this.economy.addItem(id); this.spend('Boutique', price, name); this.ui.toast(`${icon} ${name} acheté.`, 2); } })));
  }
  restaurant() {
    this.ui.openMenu('🍽️ Restaurant Le Golfe • café', 'Établissement fictif du terminal', MEALS.map(([n, price, f]) => ({ label: n, desc: fcfa(price), action: () => { if (!this.economy.pay(price, `${n} — terminal`, 'Restaurant Le Golfe')) return this.ui.toast('Solde insuffisant.', 2); if (this.needs) this.needs.hunger = Math.min(100, this.needs.hunger + f); this.env.time = (this.env.time + 0.3) % 24; this.spend('Restauration', price, n); this.ui.toast(`🍽️ ${n} : bon appétit !`, 2); } })));
  }
  vipOk() { return this.abs() < this.vipUntil || !!(this.hasBiz && this.hasBiz()); }
  vip() {
    if (this.vipOk()) { this.vipDoor.disabled = true; return this.ui.toast('🥂 Mme Grâce Tossou : « Bienvenue au salon VIP, installez-vous. »', 2.5); }
    this.ui.openMenu('🥂 Salon VIP', 'Accès : classe affaires ou carte NOVA TRAVEL Platinum', [{ label: 'Acheter la carte NOVA TRAVEL Platinum (30 jours)', desc: fcfa(1500000), action: () => this.buyPlatinum() }, { label: 'Plus tard', action: () => {} }]);
  }
  buyPlatinum() { if (!this.economy.pay(1500000, 'Carte NOVA TRAVEL Platinum (salon VIP, 30 jours)', 'NOVA TRAVEL')) return this.ui.toast('Solde insuffisant.', 2); this.vipUntil = Math.max(this.vipUntil, this.abs()) + 30 * 24; this.vipDoor.disabled = true; this.spend('Services', 1500000, 'Carte Platinum'); this.ui.toast('💳 Carte Platinum activée pour 30 jours : salon VIP ouvert.', 3); this.onSave && this.onSave(); }
  vipBar() { if (this.needs) { this.needs.hunger = Math.min(100, this.needs.hunger + 15); this.needs.energy = Math.min(100, this.needs.energy + 5); } this.ui.toast('🥤 Jus d’ananas frais et petits fours : offerts au salon.', 2.5); }
  pdg() { this.pdgDoor.disabled = true; this.ui.toast('🔑 Salon privé du PDG : la porte s’ouvre pour toi.', 2.2); }
  pdgRest() { this.ui.fade && this.ui.fade(true); setTimeout(() => { this.env.time = (this.env.time + 1) % 24; if (this.needs) this.needs.energy = Math.min(100, this.needs.energy + 30); this.ui.fade && this.ui.fade(false); this.ui.toast('😌 Une heure de repos au calme dans ton salon privé.', 2.5); }, 600); }
  spend(cat, amount, what) { this.spent.unshift({ t: this.economy.stamp(), cat, amount, what }); this.spent.length = Math.min(this.spent.length, 120); this.onSave && this.onSave(); }
  openApp(view) { this.view = view; this.economy.togglePhone(true); this.economy.app = 'travel'; this.economy.renderPhone(); }
  // ------------------------------------------------------------------ boucle
  update(dt) {
    if (!this.inside) return; const P = this.player.pos;
    if (Math.abs((P.y || TERM.Y) - TERM.Y) > 6 || Math.hypot(P.x - TERM.O.x, P.z - TERM.O.z) > 70) { this.inside = false; this.inGroup.visible = false; this.world.collision.level = 0; this.player.floorY = 0; this.clearPeople(); this.lightOff(); return; }
    const ls = this.home && this.home.lights; if (ls) { if (!this._orig) this._orig = ls.map((l) => ({ p: l.position.clone(), d: l.distance })); ls.forEach((l, i) => { l.position.set(P.x - 8 + i * 8, TERM.Y + 5, P.z + (i === 1 ? 5 : -3)); l.distance = 22; l.decay = 1.2; l.intensity = 3.5; l.color.setHex(0xfff4e6); }); }
    this._bd = (this._bd || 0) - dt; if (this._bd < 0) { this._bd = 5; this.drawBoard(); }
    for (const p of this.people) {
      if (p.staff || p.seat) { if (!p.seat) p.c.animate(dt, 0); continue; }
      if (p.wait > 0) { p.wait -= dt; p.c.animate(dt, 0); continue; }
      if (!p.path.length) { this.newPath(p, false); p.wait = 1 + Math.random() * 3; }
      const [tx, tz] = p.path[0], dx = tx - p.x, dz = tz - p.z, d = Math.hypot(dx, dz);
      if (d < 0.2) { p.path.shift(); if (p.path.length === 2 && Math.random() < 0.3) p.wait = 2 + Math.random() * 4; continue; }
      const s = Math.min(d, p.speed * dt); p.x += dx / d * s; p.z += dz / d * s; p.h = Math.atan2(dx, dz); p.c.group.position.set(p.x, 0, p.z); p.c.group.rotation.y = p.h; p.c.animate(dt, p.speed);
    }
  }
  // ------------------------------------------------------------------ application « NOVA TRAVEL » (étape 1 : destinations, horaires, aéroport)
  renderApp(b) {
    const tabs = [['dest', 'Destinations'], ['horaires', 'Horaires'], ['aeroport', 'Aéroport'], ['depenses', 'Dépenses']], v = this.view, abs = this.abs();
    let h = `<h4>✈️ NOVA TRAVEL</h4><p class="ph-note">Vols et compagnies fictifs depuis l’aéroport de Cotonou ; durées indicatives. Les villes étrangères ne sont pas jouables pour l’instant.</p><div class="ph-chips">${tabs.map(([k, l]) => `<button data-tr="tab:${k}" class="${k === v ? 'on' : ''}">${l}</button>`).join('')}</div>`;
    if (v === 'dest') { let reg = ''; h += DESTS.map((D) => { const head = D.region !== reg ? `<h5>${D.region}</h5>` : ''; reg = D.region; return `${head}<div class="ph-row"><span><b>${esc(D.city)} — ${esc(D.country)}</b><small>${AIRLINES[D.air].name} ${D.num} • environ ${D.dur < 1 ? `${Math.round(D.dur * 60)} min` : `${D.dur.toString().replace('.', ',')} h`} • départ${D.times.length > 1 ? 's' : ''} ${D.times.map(hh).join(' et ')} • porte ${D.gate}</small><small>Économique ${fcfa(D.eco)} • Affaires ${fcfa(D.biz)}</small></span></div>`; }).join(''); }
    else if (v === 'horaires') h += `<p class="ph-note">Heure locale ${hh(this.env.time)} — jour ${this.economy.day}.</p>${departures(abs, 30).filter((d) => d.at >= abs - 1).slice(0, 14).map((d) => { const [st, sc] = status(d, abs); return `<div class="ph-row"><span><b>${hh(d.h)}${d.day > this.economy.day ? ' (demain)' : ''} • ${esc(d.D.city)}</b><small>${d.D.num} • ${AIRLINES[d.D.air].name} • porte ${d.D.gate}</small></span><em style="color:${sc}">${st}</em></div>`; }).join('')}`;
    else if (v === 'aeroport') h += `<div class="ph-list"><div class="ph-row"><span><b>Terminal international</b><small>Hall, enregistrement, contrôle, boutiques, restaurant, portes A1–A4, salon VIP, salon privé du PDG.</small></span>${this.driver ? '<button class="ph-mini" data-tr="go:1">🚘 M’y conduire</button>' : ''}</div>
      <div class="ph-row"><span><b>Carte NOVA TRAVEL Platinum</b><small>${abs < this.vipUntil ? `Active jusqu’au jour ${Math.floor(this.vipUntil / 24)}` : 'Accès au salon VIP pendant 30 jours'}</small></span>${abs < this.vipUntil ? '<em>✅</em>' : `<button class="ph-mini" data-tr="plat:1">${fcfa(1500000)}</button>`}</div></div>`;
    else { const tot = this.spent.reduce((a, s) => a + s.amount, 0); h += `<p class="ph-note">Total : ${fcfa(tot)}</p>${this.spent.slice(0, 20).map((s) => `<div class="ph-row"><span><b>${esc(s.what)}</b><small>${s.t} • ${esc(s.cat)}</small></span><em>${fcfa(s.amount)}</em></div>`).join('') || '<p class="ph-note">Aucune dépense de voyage.</p>'}`; }
    b.innerHTML = h;
  }
  onPhone(v) {
    const [a, arg] = v.split(':');
    if (a === 'tab') this.view = arg; else if (a === 'plat') this.buyPlatinum();
    else if (a === 'go' && this.driver) { this.economy.togglePhone(false); return this.driver.toDest({ id: 'terminal', label: 'Terminal international de l’aéroport', x: TERM.DOOR.x + 6, z: TERM.DOOR.z }); }
    this.economy.renderPhone();
  }
  serialize() { return { vipUntil: this.vipUntil, spent: this.spent }; }
  restore(s) { if (!s) return; this.vipUntil = s.vipUntil || 0; this.spent = s.spent || []; }
}
