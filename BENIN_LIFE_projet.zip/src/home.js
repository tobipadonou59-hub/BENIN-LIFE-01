// Maison personnelle du joueur (Mission 010) : villa contemporaine inspirée des résidences de Cotonou,
// intérieur visitable (salon, cuisine, chambre, salle de bain, dressing, garage), portes animées,
// éclairage, activités quotidiennes (manger, dormir, se laver, s'habiller, télévision) et garage.
// Tout est procédural (aucun modèle externe). Seul le rez-de-chaussée est visitable : l'étage est un volume extérieur.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { Reflector } from 'three/addons/objects/Reflector.js';
import * as T from './textures.js';
import { mulberry32 } from './util.js';

const PI = Math.PI;
export const HOME = {
  lot: { x0: -62, x1: -22, z0: 110, z1: 142 },
  house: { x0: -56, x1: -36, z0: 118, z1: 134 },
  garage: { x0: -36, x1: -28, z0: 118, z1: 128 },
  marker: { x: -44.5, z: 114 },          // devant la porte d'entrée (point « M »)
  carSpot: { x: -32, z: 123.4, h: PI },  // voiture garée, nez vers la sortie
  entry: { x: -44.5, z: 112 },
};

export const FOODS = [
  { id: 'amiwo', name: 'Amiwo au poulet', desc: 'Pâte de maïs rouge à la tomate', hunger: 45, cook: 6, color: 0xc8502a },
  { id: 'gombo', name: 'Pâte blanche & sauce gombo', desc: 'Le classique de midi', hunger: 50, cook: 6, color: 0x5a7a2a },
  { id: 'atassi', name: 'Atassi', desc: 'Riz-haricot, huile rouge, piment', hunger: 40, cook: 5, color: 0x8a5a3a },
  { id: 'akassa', name: 'Akassa & poisson braisé', desc: 'Pâte de maïs fermentée', hunger: 45, cook: 5, color: 0xe8e0c8 },
  { id: 'alloco', name: 'Alloco', desc: 'Banane plantain frite', hunger: 25, cook: 3, color: 0xe0a030 },
  { id: 'bissap', name: 'Jus de bissap', desc: 'Boisson fraîche, se boit tout de suite', hunger: 8, cook: 0, color: 0x8a1030, drink: true },
];

export const OUTFITS = {
  male: [
    { id: 'm-quot-1', cat: 'Quotidien', name: 'Chemise wax & jean', opts: { pagne: 0, pants: 0x2b3442 } },
    { id: 'm-quot-2', cat: 'Quotidien', name: 'Chemise wax verte & pantalon gris', opts: { pagne: 3, pants: 0x4a4a4a } },
    { id: 'm-eleg-1', cat: 'Élégant', name: 'Grand boubou en bazin blanc', opts: { shirtColor: 0xf2f0ea, pants: 0xf2f0ea, robe: true, skirtColor: 0xf2f0ea } },
    { id: 'm-eleg-2', cat: 'Élégant', name: 'Costume bleu nuit', opts: { shirtColor: 0x22283a, pants: 0x22283a, shoes: 0x2a1a10 } },
    { id: 'm-deco-1', cat: 'Décontracté', name: 'T-shirt rouge & short', opts: { shirtColor: 0xc8102e, pants: 0x1f3e7c, shorts: true } },
    { id: 'm-deco-2', cat: 'Décontracté', name: 'Maillot vert & short noir', opts: { shirtColor: 0x0b8a4f, pants: 0x111111, shorts: true, shoes: 0xf2f2f2 } },
  ],
  female: [
    { id: 'f-quot-1', cat: 'Quotidien', name: 'Pagne wax & foulard', opts: { female: true, pagne: 2 } },
    { id: 'f-quot-2', cat: 'Quotidien', name: 'Pagne orange & foulard', opts: { female: true, pagne: 4 } },
    { id: 'f-eleg-1', cat: 'Élégant', name: 'Robe en bazin violet', opts: { female: true, shirtColor: 0x5b2c83, skirtColor: 0x5b2c83, wrapColor: 0x5b2c83 } },
    { id: 'f-eleg-2', cat: 'Élégant', name: 'Ensemble doré de cérémonie', opts: { female: true, shirtColor: 0xd8a830, skirtColor: 0xd8a830, wrapColor: 0xd8a830 } },
    { id: 'f-deco-1', cat: 'Décontracté', name: 'T-shirt blanc & jean', opts: { female: true, skirt: false, headwrap: false, shirtColor: 0xf2f2f2, pants: 0x1f3e7c } },
    { id: 'f-deco-2', cat: 'Décontracté', name: 'Top jaune & short', opts: { female: true, skirt: false, headwrap: false, shirtColor: 0xf2c200, pants: 0x2a2a2a, shorts: true } },
  ],
};

// ---------- petites textures ----------
function cv(w, h, draw, repeat = true, srgb = true) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c);
  if (repeat) t.wrapS = t.wrapT = THREE.RepeatWrapping;
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 4;
  return t;
}
const noise = (x, w, h, n, a, R) => { for (let i = 0; i < n; i++) { x.fillStyle = R() < 0.5 ? `rgba(0,0,0,${a})` : `rgba(255,255,255,${a})`; x.fillRect(R() * w, R() * h, 1.5, 1.5); } };

function makeMaterials() {
  const R = mulberry32(1010);
  const std = (o) => new THREE.MeshStandardMaterial({ roughness: 0.85, ...o });
  return {
    plaster: std({ map: cv(128, 128, (x, w, h) => { x.fillStyle = '#efe8dc'; x.fillRect(0, 0, w, h); noise(x, w, h, 2500, 0.05, R); }) }),
    accentWall: std({ color: 0xc9714a }),
    wood: std({ map: cv(128, 128, (x, w, h) => { for (let i = 0; i < w; i += 8) { x.fillStyle = i % 16 ? '#6a4428' : '#7a5232'; x.fillRect(i, 0, 8, h); x.fillStyle = 'rgba(0,0,0,0.35)'; x.fillRect(i + 7, 0, 1, h); } noise(x, w, h, 900, 0.06, R); }), roughness: 0.7 }),
    stoneBase: std({ map: cv(128, 64, (x, w, h) => { x.fillStyle = '#7a7670'; x.fillRect(0, 0, w, h); for (let i = 0; i < 40; i++) { x.fillStyle = `hsl(30,6%,${35 + R() * 25}%)`; x.fillRect(R() * w, R() * h, 18 + R() * 20, 8 + R() * 8); } }) }),
    glass: new THREE.MeshStandardMaterial({ color: 0x223a48, metalness: 0.3, roughness: 0.05, transparent: true, opacity: 0.45, envMapIntensity: 1.5, side: THREE.DoubleSide, depthWrite: false }),
    frame: std({ color: 0x2c2e31, metalness: 0.6, roughness: 0.4 }),
    tile: std({ map: cv(128, 128, (x, w, h) => { x.fillStyle = '#e4ddd0'; x.fillRect(0, 0, w, h); x.strokeStyle = '#c9c0b0'; x.lineWidth = 2; x.strokeRect(1, 1, w - 2, h - 2); noise(x, w, h, 600, 0.04, R); }), roughness: 0.35 }),
    parquet: std({ map: cv(128, 128, (x, w, h) => { for (let r = 0; r < 8; r++) for (let k = -1; k < 3; k++) { x.fillStyle = `hsl(28,${35 + R() * 10}%,${32 + R() * 10}%)`; x.fillRect(k * 64 + (r % 2) * 32, r * 16, 63, 15); } }), roughness: 0.55 }),
    bathTile: std({ map: cv(128, 128, (x, w, h) => { for (let i = 0; i < 8; i++) for (let j = 0; j < 8; j++) { x.fillStyle = (i + j) % 5 === 0 ? '#2a6a9a' : '#f2f4f5'; x.fillRect(i * 16, j * 16, 15, 15); } }), roughness: 0.25 }),
    paint: std({ color: 0xf3eee6 }),
    worktop: std({ color: 0x2a2826, roughness: 0.25, metalness: 0.1 }),
    cabinet: std({ color: 0xf4f2ee, roughness: 0.4 }),
    furniture: std({ color: 0x8a5a36, roughness: 0.6 }),
    sofa: std({ color: 0x1f5a48, roughness: 0.95 }),
    cushion: std({ map: T.pagne(['#f2b400', '#c8102e', '#0b6e4f', '#1a1a1a'], 909), roughness: 0.9 }),
    bedding: std({ map: T.pagne(['#1f4e9c', '#f2c500', '#e46a1f', '#ffffff'], 910), roughness: 0.95 }),
    linen: std({ color: 0xf6f3ec, roughness: 0.95 }),
    rug: std({ map: cv(128, 128, (x, w, h) => { x.fillStyle = '#a8442a'; x.fillRect(0, 0, w, h); x.strokeStyle = '#f2c500'; x.lineWidth = 6; x.strokeRect(10, 10, w - 20, h - 20); x.fillStyle = '#1a1a1a'; for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) { x.beginPath(); x.moveTo(24 + i * 26, 20 + j * 26); x.lineTo(34 + i * 26, 30 + j * 26); x.lineTo(24 + i * 26, 40 + j * 26); x.lineTo(14 + i * 26, 30 + j * 26); x.fill(); } }, false) }),
    chrome: std({ color: 0xd8dcdf, metalness: 0.9, roughness: 0.2 }),
    black: std({ color: 0x141414, roughness: 0.4 }),
    porcelain: std({ color: 0xfbfbf8, roughness: 0.2 }),
    fridge: std({ color: 0xc8ccd0, metalness: 0.6, roughness: 0.3 }),
    grass: std({ map: T.grassHD(), roughness: 1 }),
    pavers: std({ ...T.paveHD(), roughness: 0.9 }),
    gate: std({ color: 0x2a2c30, metalness: 0.5, roughness: 0.5 }),
    wallC: std({ map: T.wall('#ece4d4') }),
    plant: std({ color: 0x2e6a2a, roughness: 0.9 }),
    pot: std({ color: 0xb06a3a, roughness: 0.8 }),
    lampOut: std({ color: 0xfff3d8, emissive: new THREE.Color(0xffd9a0), emissiveIntensity: 0 }),
    lampIn: std({ color: 0xfff8e8, emissive: new THREE.Color(0xfff0d0), emissiveIntensity: 0 }),
    burner: std({ color: 0x202020, emissive: new THREE.Color(0xff4010), emissiveIntensity: 0 }),
    food: std({ color: 0xc8502a, roughness: 0.7 }),
  };
}

// ---------- lots de géométrie fusionnée (peu d'appels de rendu) ----------
export class Batch {
  constructor(mats) { this.mats = mats; this.map = new Map(); }
  add(key, geo, cast = true) {
    let g = geo.index ? geo.toNonIndexed() : geo;
    for (const n of Object.keys(g.attributes)) if (!['position', 'normal', 'uv'].includes(n)) g.deleteAttribute(n);
    if (!this.map.has(key)) this.map.set(key, { geos: [], cast });
    this.map.get(key).geos.push(g);
  }
  build(group) {
    for (const [key, b] of this.map) {
      const m = new THREE.Mesh(mergeGeometries(b.geos), this.mats[key]);
      m.castShadow = b.cast; m.receiveShadow = true;
      group.add(m);
    }
  }
}
// boîte alignée sur les axes, UV en mètres (texture répétée tous les `tile` mètres)
export function box(x0, y0, z0, x1, y1, z1, tile = 1) {
  const w = x1 - x0, h = y1 - y0, d = z1 - z0;
  const g = new THREE.BoxGeometry(w, h, d);
  const uv = g.attributes.uv, dims = [[d, h], [d, h], [w, d], [w, d], [w, h], [w, h]];
  for (let f = 0; f < 6; f++) for (let k = 0; k < 4; k++) { const i = f * 4 + k; uv.setXY(i, uv.getX(i) * dims[f][0] / tile, uv.getY(i) * dims[f][1] / tile); }
  g.translate((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2);
  return g;
}
export function floorPlane(x0, z0, x1, z1, y, tile = 1) {
  const g = new THREE.PlaneGeometry(x1 - x0, z1 - z0); g.rotateX(-PI / 2);
  const uv = g.attributes.uv; for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * (x1 - x0) / tile, uv.getY(i) * (z1 - z0) / tile);
  g.translate((x0 + x1) / 2, y, (z0 + z1) / 2);
  return g;
}

// ---------- éléments animés ----------
class Door {
  // porte battante : charnière en (hx, hz), le battant s'étend sur `w` le long de l'axe du mur
  constructor(parent, col, mats, { hx, hz, axis, w, h = 2.2, swing = 1, mat = 'furniture', auto = true, label = 'la porte' }) {
    this.pivot = new THREE.Group(); this.pivot.position.set(hx, 0, hz);
    const panel = new THREE.Mesh(new THREE.BoxGeometry(Math.abs(w), h, 0.05), mats[mat]);
    panel.position.set(w / 2, h / 2, 0); panel.castShadow = true;
    const knob = new THREE.Mesh(new THREE.SphereGeometry(0.04, 8, 6), mats.chrome); knob.position.set(w * 0.88, 1.0, 0.05);
    const inner = new THREE.Group(); inner.add(panel, knob);
    if (axis === 'z') inner.rotation.y = -PI / 2;
    this.pivot.add(inner); parent.add(this.pivot);
    const a = axis === 'x' ? [Math.min(hx, hx + w), hz - 0.15, Math.max(hx, hx + w), hz + 0.15] : [hx - 0.15, Math.min(hz, hz + w), hx + 0.15, Math.max(hz, hz + w)];
    this.collider = col.addBox(a[0], a[1], a[2], a[3], h);
    this.center = axis === 'x' ? { x: hx + w / 2, z: hz } : { x: hx, z: hz + w / 2 };
    this.swing = swing; this.auto = auto; this.label = label;
    this.open = 0; this.target = 0;
  }
  toggle() { this.target = this.target > 0.5 ? 0 : 1; return this.target > 0.5; }
  update(dt, player) {
    if (this.auto && player) {
      const d = Math.hypot(player.x - this.center.x, player.z - this.center.z);
      if (d < 1.6) this.target = 1; else if (d > 2.6) this.target = 0;
    }
    this.open += Math.sign(this.target - this.open) * Math.min(Math.abs(this.target - this.open), dt * 2.2);
    this.pivot.rotation.y = this.swing * this.open * PI * 0.52;
    this.collider.disabled = this.open > 0.35;
  }
}

class SlideGate {
  constructor(parent, col, mats, { x0, x1, z, h = 2.1, label }) {
    const w = x1 - x0;
    this.mesh = new THREE.Group();
    const frameM = mats.gate;
    const g = [];
    g.push(box(0, 0.05, -0.04, w, 0.15, 0.04), box(0, h - 0.1, -0.04, w, h, 0.04));
    for (let k = 0; k <= Math.round(w / 0.16); k++) g.push(box(k * 0.16, 0.1, -0.02, k * 0.16 + 0.05, h - 0.05, 0.02));
    const m = new THREE.Mesh(mergeGeometries(g.map((q) => q.toNonIndexed())), frameM); m.castShadow = true;
    this.mesh.add(m); this.mesh.position.set(x0, 0, z);
    parent.add(this.mesh);
    this.x0 = x0; this.w = w; this.label = label;
    this.collider = col.addBox(x0, z - 0.15, x1, z + 0.15, h);
    this.center = { x: x0 + w / 2, z };
    this.open = 0; this.target = 0;
  }
  toggle() { this.target = this.target > 0.5 ? 0 : 1; return this.target > 0.5; }
  update(dt) {
    this.open += Math.sign(this.target - this.open) * Math.min(Math.abs(this.target - this.open), dt * 0.5);
    this.mesh.position.x = this.x0 - this.w * 0.96 * this.open; // coulisse derrière le mur
    this.collider.disabled = this.open > 0.92;
  }
}

class GarageDoor {
  constructor(parent, col, mats, { x0, x1, z, h = 2.6 }) {
    const w = x1 - x0;
    this.pivot = new THREE.Group(); this.pivot.position.set(x0, h, z);
    const g = [];
    for (let k = 0; k < 5; k++) g.push(box(0, -h + k * h / 5 + 0.02, -0.03, w, -h + (k + 1) * h / 5 - 0.02, 0.03, 1));
    const m = new THREE.Mesh(mergeGeometries(g.map((q) => q.toNonIndexed())), mats.cabinet); m.castShadow = true;
    this.pivot.add(m); parent.add(this.pivot);
    this.collider = col.addBox(x0, z - 0.15, x1, z + 0.15, h);
    this.center = { x: x0 + w / 2, z }; this.h = h;
    this.open = 0; this.target = 0;
  }
  toggle() { this.target = this.target > 0.5 ? 0 : 1; return this.target > 0.5; }
  update(dt) {
    this.open += Math.sign(this.target - this.open) * Math.min(Math.abs(this.target - this.open), dt * 0.45);
    // le tablier remonte et bascule sous le plafond du garage
    this.pivot.rotation.x = -this.open * PI / 2;
    this.pivot.position.y = this.h + this.open * 0.2;
    this.collider.disabled = this.open > 0.9;
  }
}

// ---------- télévision : chaînes fictives dessinées en direct ----------
export const TV_GUIDE = [
  ['Journal de 20 h', 'Le débat de la Lagune', 'Reportage : l’artisanat de Ouidah'],
  ['Championnat local en direct', 'Magazine du football africain', 'Résumé des matchs'],
  ['Bulletin météo', 'La Marina vue du ciel', 'Prévisions de la semaine'],
  ['Top clips afro', 'Talents de Cotonou', 'Soirée concerts'],
  ['Les animaux de la Pendjari (documentaire fictif)', 'Mangroves et lagunes', 'Jardins du monde'],
];
export const CHANNELS = ['LAGUNE INFO', 'SPORT+ BÉNIN', 'MÉTÉO COTONOU', 'AFRO CLIPS', 'NATURE TV'];
const HEADLINES = ['Les nouvelles halles du marché Dantokpa attirent la foule', 'Soleil et vent marin attendus sur la Marina', 'Football : le championnat local reprend ce week-end', 'Festival des arts : programme de la semaine', 'Circulation fluide sur le Boulevard de la Marina'];
function drawChannel(x, ch, t) {
  const W = 320, H = 180;
  if (ch === 0) {
    const g = x.createLinearGradient(0, 0, W, H); g.addColorStop(0, '#0b2a5a'); g.addColorStop(1, '#1f4e9c'); x.fillStyle = g; x.fillRect(0, 0, W, H);
    x.fillStyle = '#e8eef8'; x.fillRect(200, 30, 90, 70); x.fillStyle = '#0b6e4f'; x.fillRect(206, 36, 78, 58);
    x.fillStyle = '#3d2618'; x.beginPath(); x.arc(120, 70, 20, 0, 7); x.fill(); x.fillStyle = '#1a1a1a'; x.fillRect(90, 92, 60, 60);
    x.fillStyle = '#c8102e'; x.fillRect(0, 128, W, 22); x.fillStyle = '#fff'; x.font = 'bold 13px Arial'; x.fillText('JOURNAL', 8, 144);
    x.fillStyle = '#f2f2f2'; x.fillRect(0, 150, W, 30); x.fillStyle = '#111'; x.font = '13px Arial';
    const msg = HEADLINES.join('   •   '), off = (t * 60) % (msg.length * 7 + W); x.fillText(msg, W - off, 170);
  } else if (ch === 1) {
    for (let i = 0; i < 8; i++) { x.fillStyle = i % 2 ? '#2f8a3a' : '#38a046'; x.fillRect(i * 40, 0, 40, H); }
    x.strokeStyle = '#fff'; x.lineWidth = 2; x.strokeRect(10, 10, W - 20, H - 20); x.beginPath(); x.moveTo(W / 2, 10); x.lineTo(W / 2, H - 10); x.stroke(); x.beginPath(); x.arc(W / 2, H / 2, 22, 0, 7); x.stroke();
    const bx = W / 2 + Math.sin(t * 0.9) * 120, by = H / 2 + Math.sin(t * 1.7) * 55;
    for (let k = 0; k < 22; k++) { const px = W / 2 + Math.sin(t * 0.5 + k * 1.7) * 130 * (0.3 + (k % 5) / 6), py = H / 2 + Math.cos(t * 0.6 + k) * 60; x.fillStyle = k < 11 ? '#f2c200' : '#c8102e'; x.beginPath(); x.arc(px * 0.7 + bx * 0.3, py, 4, 0, 7); x.fill(); }
    x.fillStyle = '#fff'; x.beginPath(); x.arc(bx, by, 3, 0, 7); x.fill();
    x.fillStyle = 'rgba(0,0,0,0.65)'; x.fillRect(8, 8, 196, 20); x.fillStyle = '#fff'; x.font = 'bold 12px Arial'; x.fillText(`LES LAGUNES 1 – 0 LES COCOTIERS   ${String(Math.floor(t / 4) % 90).padStart(2, '0')}'`, 14, 22);
  } else if (ch === 2) {
    x.fillStyle = '#5fa8d8'; x.fillRect(0, 0, W, H);
    x.fillStyle = '#e8d8a8'; x.beginPath(); x.moveTo(140, 10); x.lineTo(185, 25); x.lineTo(190, 90); x.lineTo(175, 160); x.lineTo(150, 168); x.lineTo(132, 120); x.lineTo(128, 50); x.closePath(); x.fill();
    const city = [['Cotonou', 158, 160, 31], ['Porto-Novo', 176, 150, 32], ['Parakou', 165, 90, 34], ['Natitingou', 145, 40, 33]];
    x.font = 'bold 11px Arial';
    for (const [n, px, py, temp] of city) {
      const s = 1 + Math.sin(t * 2 + px) * 0.08;
      x.fillStyle = '#f2c200'; x.beginPath(); x.arc(px, py - 8, 7 * s, 0, 7); x.fill();
      x.fillStyle = '#111'; x.fillText(`${n} ${temp}°`, px + 10, py - 4);
    }
    x.fillStyle = '#0b2a5a'; x.fillRect(0, 0, 120, 26); x.fillStyle = '#fff'; x.font = 'bold 13px Arial'; x.fillText('MÉTÉO', 10, 18);
  } else if (ch === 3) {
    x.fillStyle = `hsl(${(t * 40) % 360},70%,18%)`; x.fillRect(0, 0, W, H);
    for (let i = 0; i < 24; i++) { const hgt = (Math.sin(t * 6 + i * 0.7) * 0.5 + 0.5) * 110 + 10; x.fillStyle = `hsl(${(i * 15 + t * 60) % 360},85%,55%)`; x.fillRect(10 + i * 12.5, H - 20 - hgt, 9, hgt); }
    x.strokeStyle = 'rgba(255,255,255,0.6)'; x.lineWidth = 3; x.beginPath(); x.arc(W / 2, 60, 30 + Math.sin(t * 3) * 6, 0, 7); x.stroke();
    x.fillStyle = '#fff'; x.font = 'bold 13px Arial'; x.fillText('♪ AFRO CLIPS — le clip de la semaine', 10, H - 4);
  } else {
    const g = x.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#f08a3a'); g.addColorStop(0.55, '#f8c86a'); g.addColorStop(0.56, '#1f6f86'); g.addColorStop(1, '#0b3a4a'); x.fillStyle = g; x.fillRect(0, 0, W, H);
    x.fillStyle = '#fff2c0'; x.beginPath(); x.arc(W / 2, 95, 22, 0, 7); x.fill();
    x.strokeStyle = 'rgba(255,255,255,0.4)'; for (let k = 0; k < 6; k++) { x.beginPath(); for (let i = 0; i <= W; i += 8) x.lineTo(i, 110 + k * 12 + Math.sin(i * 0.05 + t * 2 + k) * 3); x.stroke(); }
    x.fillStyle = '#1a1a1a'; for (let k = 0; k < 2; k++) { const px = ((t * 15 + k * 160) % (W + 60)) - 30; x.fillRect(px, 104 + k * 10, 26, 4); }
  }
  x.fillStyle = 'rgba(0,0,0,0.5)'; x.fillRect(W - 92, 4, 88, 16); x.fillStyle = '#fff'; x.font = 'bold 10px Arial'; x.fillText(`${ch + 1} • ${CHANNELS[ch]}`, W - 88, 15);
}

// =====================================================================
export class Home {
  constructor({ scene, col, palms, trees, bushes, tufts, nightMats }) {
    this.scene = scene; this.col = col;
    const mats = this.mats = makeMaterials();
    nightMats.push({ mat: mats.lampOut, max: 2.2 });
    this.group = new THREE.Group(); this.upper = new THREE.Group();
    scene.add(this.group, this.upper);
    const S = new Batch(mats), U = new Batch(mats);
    const H = HOME.house, G = HOME.garage, L = HOME.lot;
    const WH = 3.3, WT = 0.25;

    // ---- murs avec ouvertures ----
    // ops : { a, b, y0, y1 } ; y0 = 0 => porte (passage), sinon fenêtre (vitrée)
    const solid = (B, key, x0, y0, z0, x1, y1, z1) => B.add(key, box(x0, y0, z0, x1, y1, z1, 2));
    const glassPane = (alongX, c, a, b, y0, y1) => {
      if (alongX) { S.add('glass', box(a, y0, c - 0.02, b, y1, c + 0.02), false); S.add('frame', box(a, y0 - 0.05, c - 0.07, b, y0, c + 0.07)); S.add('frame', box(a, y1, c - 0.07, b, y1 + 0.05, c + 0.07)); S.add('frame', box(a - 0.05, y0, c - 0.07, a, y1, c + 0.07)); S.add('frame', box(b, y0, c - 0.07, b + 0.05, y1, c + 0.07)); S.add('frame', box((a + b) / 2 - 0.025, y0, c - 0.05, (a + b) / 2 + 0.025, y1, c + 0.05)); }
      else { S.add('glass', box(c - 0.02, y0, a, c + 0.02, y1, b), false); S.add('frame', box(c - 0.07, y0 - 0.05, a, c + 0.07, y0, b)); S.add('frame', box(c - 0.07, y1, a, c + 0.07, y1 + 0.05, b)); S.add('frame', box(c - 0.07, y0, a - 0.05, c + 0.07, y1, a)); S.add('frame', box(c - 0.07, y0, b, c + 0.07, y1, b + 0.05)); }
    };
    const wall = (alongX, c, a0, a1, ops, key, t = WT, h = WH, collide = true) => {
      const P = (a, b, y0, y1) => alongX ? solid(S, key, a, y0, c - t / 2, b, y1, c + t / 2) : solid(S, key, c - t / 2, y0, a, c + t / 2, y1, b);
      ops = [...ops].sort((p, q) => p.a - q.a);
      let cur = a0;
      const solidRuns = [];
      let runStart = a0;
      for (const o of ops) {
        if (o.a > cur) P(cur, o.a, 0, h);
        if (o.y0 > 0) P(o.a, o.b, 0, o.y0);
        if (o.y1 < h) P(o.a, o.b, o.y1, h);
        if (o.y0 > 0.3) glassPane(alongX, c, o.a, o.b, o.y0, o.y1);
        else { solidRuns.push([runStart, o.a]); runStart = o.b; }
        cur = o.b;
      }
      if (cur < a1) P(cur, a1, 0, h);
      solidRuns.push([runStart, a1]);
      if (collide) for (const [a, b] of solidRuns) if (b - a > 0.05) {
        if (alongX) col.addBox(a, c - t / 2, b, c + t / 2, h); else col.addBox(c - t / 2, a, c + t / 2, b, h);
      }
    };

    // ---- terrain, clôture, jardin ----
    S.add('grass', floorPlane(L.x0, L.z0, L.x1, L.z1, 0.06, 4), false);
    S.add('pavers', floorPlane(-35.2, L.z0, -28.8, H.z0, 0.075, 4), false);          // allée du garage
    S.add('pavers', floorPlane(-45.6, L.z0, -43.4, H.z0, 0.075, 4), false);          // allée piétonne
    S.add('pavers', floorPlane(-56, H.z1, -40, H.z1 + 4, 0.075, 4), false);          // terrasse arrière
    const fence = (alongX, c, a0, a1, ops) => wall(alongX, c, a0, a1, ops, 'wallC', 0.25, 2.3);
    fence(true, L.z0, L.x0, L.x1, [{ a: -45.6, b: -43.4, y0: 0, y1: 2.3 }, { a: -35.4, b: -28.6, y0: 0, y1: 2.3 }]);
    fence(true, L.z1, L.x0, L.x1, []);
    fence(false, L.x0, L.z0, L.z1, []); fence(false, L.x1, L.z0, L.z1, []);
    for (const px of [-45.85, -43.15, -35.65, -28.35]) S.add('stoneBase', box(px - 0.25, 0, L.z0 - 0.25, px + 0.25, 2.7, L.z0 + 0.25, 1));
    for (const [x, z] of [[-60, 112], [-24, 112], [-60, 140], [-24, 140], [-50, 113], [-24, 126]]) palms.push({ x, z, s: 0.9, r: x });
    for (let k = 0; k < 7; k++) bushes.push({ x: -60.5 + k * 2.4, z: 111, s: 1, r: k, y: 0.5 });
    for (let k = 0; k < 5; k++) bushes.push({ x: -26.5 + k * 0.01, z: 131 + k * 2.2, s: 1, r: k, y: 0.5 });
    trees.push({ x: -28, z: 136, s: 1.0, r: 1 }, { x: -60, z: 128, s: 0.9, r: 2, flamboyant: true });
    for (let k = 0; k < 40; k++) tufts.push({ x: L.x0 + 1 + Math.random() * 38, z: 136 + Math.random() * 5, s: 0.6, r: k });
    // mobilier de terrasse
    S.add('furniture', box(-50.6, 0.7, 135.4, -49.0, 0.75, 136.6)); S.add('furniture', box(-49.85, 0, 135.95, -49.75, 0.7, 136.05));
    S.add('cushion', new THREE.ConeGeometry(1.4, 0.4, 10, 1, true).translate(-49.8, 2.3, 136));
    S.add('metal' in mats ? 'metal' : 'frame', box(-49.83, 0.7, 135.98, -49.77, 2.2, 136.02));
    col.addCircle(-49.8, 136, 0.9, 1);

    // ---- maison : dalle, murs extérieurs ----
    S.add('tile', floorPlane(H.x0, H.z0, -42, 127, 0.07, 0.6), false);          // salon + couloir + cuisine
    S.add('tile', floorPlane(-46, H.z0, -36, H.z1, 0.071, 0.6), false);
    S.add('parquet', floorPlane(H.x0, 127, -46, H.z1, 0.072, 1.2), false);      // chambre
    S.add('bathTile', floorPlane(-42, 126, -36, 130, 0.073, 0.5), false);       // salle de bain
    S.add('parquet', floorPlane(-42, 130, -36, H.z1, 0.073, 1.2), false);       // dressing
    S.add('stoneBase', floorPlane(G.x0, G.z0, G.x1, G.z1, 0.07, 1), false);     // garage
    // façade nord (rue) : baie du salon, porte d'entrée, fenêtre de cuisine
    wall(true, H.z0, H.x0, H.x1, [{ a: -54, b: -48.5, y0: 0.5, y1: 2.6 }, { a: -45.2, b: -43.8, y0: 0, y1: 2.3 }, { a: -41, b: -37.6, y0: 1.1, y1: 2.4 }], 'plaster');
    wall(true, H.z1, H.x0, H.x1, [{ a: -52, b: -48, y0: 0.9, y1: 2.4 }, { a: -40.2, b: -38.6, y0: 1.5, y1: 2.3 }], 'plaster');
    wall(false, H.x0, H.z0, H.z1, [{ a: 131.6, b: 133.4, y0: 1.0, y1: 2.3 }], 'plaster');
    wall(false, H.x1, 128, H.z1, [{ a: 128.4, b: 129.6, y0: 1.6, y1: 2.3 }], 'plaster');
    wall(false, H.x1, H.z0, 128, [{ a: 119.4, b: 120.6, y0: 0, y1: 2.2 }], 'paint', 0.2);   // cuisine | garage
    // garage
    wall(true, G.z0, G.x0, G.x1, [{ a: -35.2, b: -28.8, y0: 0, y1: 2.6 }], 'wood');
    wall(true, G.z1, G.x0, G.x1, [], 'plaster');
    wall(false, G.x1, G.z0, G.z1, [{ a: 122, b: 124, y0: 1.6, y1: 2.3 }], 'plaster');
    // cloisons intérieures
    const PT = 0.12;
    wall(false, -46, H.z0, H.z1, [{ a: 119.8, b: 121.0, y0: 0, y1: 2.3 }, { a: 129.4, b: 130.6, y0: 0, y1: 2.2 }], 'paint', PT);
    wall(false, -42, H.z0, H.z1, [{ a: 119.6, b: 121.2, y0: 0, y1: 2.4 }, { a: 127.4, b: 128.4, y0: 0, y1: 2.2 }, { a: 131.4, b: 132.4, y0: 0, y1: 2.2 }], 'paint', PT);
    wall(true, 127, H.x0, -46, [], 'paint', PT);
    wall(true, 126, -42, H.x1, [], 'paint', PT);
    wall(true, 130, -42, H.x1, [], 'paint', PT);
    // mur d'accent du salon (derrière la télévision)
    S.add('accentWall', box(H.x0 + 0.13, 0.1, 119.6, H.x0 + 0.16, WH - 0.2, 125.4));
    // soubassement en pierre et bardage bois de façade
    S.add('stoneBase', box(H.x0 - 0.15, 0, H.z0 - 0.15, H.x1 + 0.15, 0.45, H.z0 - 0.12, 1));
    S.add('wood', box(-48.3, 0.45, H.z0 - 0.2, -45.4, 3.3, H.z0 - 0.13, 1));
    // auvent d'entrée, marche, appliques murales
    S.add('plaster', box(-46.6, 2.65, 116.2, -42.4, 2.85, H.z0, 2));
    S.add('stoneBase', box(-45.6, 0, 116.9, -43.4, 0.12, H.z0, 1), false);
    for (const lx of [-45.6, -43.4, -35.6, -28.4]) S.add('lampOut', box(lx - 0.1, 2.3, H.z0 - 0.22, lx + 0.1, 2.5, H.z0 - 0.12), false);
    for (const [lx, lz] of [[-50, 113], [-38, 113], [-58, 138], [-30, 138]]) { S.add('frame', box(lx - 0.05, 0, lz - 0.05, lx + 0.05, 0.9, lz + 0.05)); S.add('lampOut', box(lx - 0.12, 0.9, lz - 0.12, lx + 0.12, 1.1, lz + 0.12), false); }
    S.add('cabinet', box(-44.25, 2.35, H.z0 - 0.3, -43.6, 2.62, H.z0 - 0.26));     // plaque « M »
    // ---- étage (volume extérieur, non visitable) et toitures : masqués quand le joueur est à l'intérieur ----
    U.add('plaster', box(H.x0, WH, H.z0, H.x1, WH + 0.3, H.z1, 2));                                  // dalle
    U.add('plaster', box(G.x0, 2.9, G.z0, G.x1, 3.15, G.z1, 2));                                     // toit du garage
    U.add('plaster', box(H.x0, WH + 0.3, H.z0 + 1.2, -44.5, WH + 3.3, H.z1 - 1, 2));                  // étage
    U.add('glass', box(-55, WH + 0.6, H.z0 + 1.17, -46, WH + 2.9, H.z0 + 1.21), false);               // grande baie
    U.add('frame', box(-55.05, WH + 0.55, H.z0 + 1.12, -45.95, WH + 0.62, H.z0 + 1.26));
    U.add('wood', box(-46, WH + 0.3, H.z0 + 1.1, -44.5, WH + 3.3, H.z0 + 1.25, 1));
    U.add('glass', box(H.x0 + 0.5, WH + 0.35, H.z0 - 0.05, -44.6, WH + 1.35, H.z0 + 0.01), false);   // garde-corps vitré du balcon
    U.add('plaster', box(H.x0 - 0.2, WH + 3.3, H.z0 + 1.0, -44.3, WH + 3.6, H.z1 - 0.8, 2));          // toit-terrasse
    for (const [a, b, c, d] of [[-44.5, WH + 0.3, H.z0, H.x1], [-44.5, WH + 0.3, H.z1 - 0.12, H.x1]]) U.add('plaster', box(a, b, c, d, b + 1.0, c + 0.12, 2));
    U.add('plaster', box(H.x1 - 0.12, WH + 0.3, H.z0, H.x1, WH + 1.3, H.z1, 2));
    U.add('tank', box(-39, WH + 0.3, 131, -38, WH + 1.6, 132));
    mats.tank = mats.black;
    U.add('glass', box(H.x0 - 0.01, WH + 0.9, 124, H.x0 + 0.01, WH + 2.6, 128), false);
    U.add('frame', box(-28.2, 3.15, G.z0, -28, 3.6, G.z1));

    // ---- mobilier ----
    const F = (key, x0, y0, z0, x1, y1, z1, collide = false, cast = true) => { S.add(key, box(x0, y0, z0, x1, y1, z1, 1), cast); if (collide) col.addBox(x0, z0, x1, z1, y1); };
    // salon
    F('black', -55.85, 0.07, 120.8, -55.4, 0.55, 124.2, true);                  // meuble TV
    F('black', -55.75, 0.85, 121.5, -55.7, 2.0, 123.5);                          // téléviseur (cadre)
    F('sofa', -52.1, 0.07, 121.0, -51.0, 0.45, 124.6, true);                     // assise
    F('sofa', -51.25, 0.45, 121.0, -50.95, 1.0, 124.6);                          // dossier
    F('sofa', -52.1, 0.45, 120.8, -50.95, 0.7, 121.0); F('sofa', -52.1, 0.45, 124.6, -50.95, 0.7, 124.8);
    for (let k = 0; k < 3; k++) F('cushion', -51.3, 0.45, 121.4 + k * 1.05, -51.1, 0.85, 122.2 + k * 1.05);
    F('furniture', -54.0, 0.32, 121.9, -53.0, 0.4, 123.3, true); for (const [a, b] of [[-53.95, 121.95], [-53.1, 121.95], [-53.95, 123.2], [-53.1, 123.2]]) F('frame', a, 0.07, b, a + 0.05, 0.32, b + 0.05);
    S.add('rug', floorPlane(-55, 120.4, -51.4, 124.8, 0.08, 4), false);
    F('furniture', -50, 0.07, 126.6, -47, 2.0, 126.95, true);                    // bibliothèque
    for (let k = 0; k < 4; k++) F(['cushion', 'bedding', 'sofa', 'pot'][k], -49.8 + k * 0.7, 0.9, 126.65, -49.5 + k * 0.7, 1.25, 126.9);
    for (const [px, pz] of [[-55.5, 119], [-46.6, 126.4], [-36.6, 118.6]]) { S.add('pot', new THREE.CylinderGeometry(0.22, 0.18, 0.5, 10).translate(px, 0.32, pz)); S.add('plant', new THREE.IcosahedronGeometry(0.42, 1).translate(px, 0.95, pz)); col.addCircle(px, pz, 0.3, 1); }
    // cuisine
    F('cabinet', -41.6, 0.07, 125.3, -36.4, 0.88, 125.94, true); F('worktop', -41.65, 0.88, 125.25, -36.35, 0.93, 125.94);
    // (placards hauts : remplacés par des placards à portes ouvrantes, voir home-plus.js)
    F('black', -38.8, 0.93, 125.35, -37.6, 0.95, 125.85);                        // plaque de cuisson
    for (const [bx, bz] of [[-38.5, 125.5], [-37.9, 125.5], [-38.5, 125.72], [-37.9, 125.72]]) S.add('burner', new THREE.CircleGeometry(0.09, 12).rotateX(-PI / 2).translate(bx, 0.955, bz), false);
    F('chrome', -40.6, 0.93, 125.4, -39.8, 0.94, 125.85);                        // évier
    F('chrome', -40.22, 0.94, 125.82, -40.18, 1.25, 125.86);
    F('fridge', -36.95, 0.07, 123.1, -36.25, 1.95, 124.2, true);                 // réfrigérateur
    F('chrome', -36.98, 1.0, 123.2, -36.95, 1.6, 123.25);
    F('furniture', -40.4, 0.72, 120.75, -38.8, 0.78, 121.65, true);              // table à manger
    for (const [a, b] of [[-40.35, 120.8], [-38.9, 120.8], [-40.35, 121.55], [-38.9, 121.55]]) F('furniture', a, 0.07, b, a + 0.06, 0.72, b + 0.06);
    for (const [cx, cz, back] of [[-40.0, 120.25, -1], [-39.2, 120.25, -1], [-40.0, 122.15, 1], [-39.2, 122.15, 1]]) { F('furniture', cx - 0.22, 0.44, cz - 0.22, cx + 0.22, 0.48, cz + 0.22); F('furniture', cx - 0.22, 0.48, cz + back * 0.2, cx + 0.22, 0.95, cz + back * 0.24); F('frame', cx - 0.02, 0.07, cz - 0.02, cx + 0.02, 0.44, cz + 0.02); }
    // chambre
    F('furniture', -55.85, 0.07, 129.5, -53.6, 0.4, 131.7, true);                // lit
    F('linen', -55.8, 0.4, 129.55, -53.65, 0.58, 131.65);
    F('bedding', -54.9, 0.58, 129.5, -53.6, 0.62, 131.7);
    for (const pz of [129.75, 130.7]) F('linen', -55.75, 0.58, pz, -55.25, 0.72, pz + 0.8);
    F('furniture', -55.85, 0.07, 129.5, -55.75, 1.3, 131.7);                     // tête de lit
    for (const pz of [128.8, 132.0]) { F('furniture', -55.8, 0.07, pz, -55.3, 0.55, pz + 0.5, true); S.add('lampIn', new THREE.SphereGeometry(0.13, 10, 8).translate(-55.55, 0.75, pz + 0.25), false); }
    // (bureau : remplacé par l'espace informatique complet, voir home-plus.js)
    // salle de bain
    F('porcelain', -39.8, 0.07, 126.08, -38.6, 0.85, 126.55, true);             // meuble lavabo
    F('chrome', -39.25, 0.85, 126.2, -39.15, 1.05, 126.3);
    F('porcelain', -37.5, 0.07, 126.1, -36.9, 0.45, 126.75, true);              // WC
    F('porcelain', -37.5, 0.45, 126.1, -36.9, 0.85, 126.25);
    F('bathTile', -37.75, 0.07, 128.35, -36.2, 0.12, 129.85, false, false);     // receveur de douche
    S.add('glass', box(-37.8, 0.12, 128.3, -37.75, 2.1, 129.3), false); S.add('glass', box(-37.8, 0.12, 128.3, -36.3, 2.1, 128.35), false);
    F('chrome', -37.0, 2.05, 129.6, -36.95, 2.4, 129.65); S.add('chrome', new THREE.CylinderGeometry(0.12, 0.12, 0.03, 12).translate(-37.0, 2.05, 129.2));
    // dressing
    F('furniture', -36.75, 0.07, 130.3, -36.15, 2.3, 133.75, true);             // armoire (côté est)
    F('furniture', -41.6, 0.07, 133.25, -38.0, 2.3, 133.85, true);              // penderie (côté sud)
    for (let k = 0; k < 5; k++) F(['bedding', 'cushion', 'linen', 'sofa', 'accentWall'][k], -41.3 + k * 0.62, 0.9, 133.2, -40.9 + k * 0.62, 1.9, 133.24);
    F('chrome', -40.2, 0.4, 130.13, -39.4, 2.0, 130.16);                         // grand miroir (décoratif)
    F('sofa', -39.6, 0.07, 131.6, -38.6, 0.45, 132.4, true);                     // pouf
    // garage
    F('frame', -35.9, 0.07, 127.4, -33, 2.2, 127.9, true);                       // étagères
    for (let k = 0; k < 3; k++) F(['pot', 'cushion', 'fridge'][k], -35.6 + k * 0.9, 0.9 + (k % 2) * 0.6, 127.45, -35.0 + k * 0.9, 1.25 + (k % 2) * 0.6, 127.85);
    F('furniture', -29.0, 1.2, 127.75, -28.4, 1.8, 127.85);                      // tableau à clés
    S.add('lampIn', box(-32.5, 2.75, 122.5, -31.5, 2.8, 124.5), false);
    // plafonniers (allumés avec l'interrupteur)
    for (const [lx, lz] of [[-51, 122.5], [-44, 122], [-44, 131], [-39, 122.5], [-39, 128], [-39, 132], [-51, 130.5]]) S.add('lampIn', new THREE.CylinderGeometry(0.25, 0.25, 0.05, 14).translate(lx, 3.25, lz), false);

    S.build(this.group); U.build(this.upper);

    // ---- portes et portails (animés) ----
    const g = this.group;
    this.frontDoor = new Door(g, col, mats, { hx: -45.2, hz: H.z0, axis: 'x', w: 1.4, h: 2.3, swing: -1, mat: 'wood', auto: false, label: 'la porte d\'entrée' });
    this.doors = [
      this.frontDoor,
      new Door(g, col, mats, { hx: -46, hz: 129.4, axis: 'z', w: 1.2, swing: 1, mat: 'cabinet' }),     // chambre
      new Door(g, col, mats, { hx: -42, hz: 127.4, axis: 'z', w: 1.0, swing: -1, mat: 'cabinet' }),    // salle de bain
      new Door(g, col, mats, { hx: -42, hz: 131.4, axis: 'z', w: 1.0, swing: -1, mat: 'cabinet' }),    // dressing
      new Door(g, col, mats, { hx: -36, hz: 119.4, axis: 'z', w: 1.2, swing: 1, mat: 'cabinet' }),     // cuisine → garage
    ];
    this.pedGate = new SlideGate(g, col, mats, { x0: -45.6, x1: -43.4, z: L.z0, label: 'le portillon' });
    this.carGate = new SlideGate(g, col, mats, { x0: -35.4, x1: -28.6, z: L.z0, label: 'le portail' });
    this.garageDoor = new GarageDoor(g, col, mats, { x0: -35.2, x1: -28.8, z: G.z0 });

    // ---- éclairage intérieur ----
    this.lights = [[-50.5, 122.5], [-40, 124], [-50.5, 130.5]].map(([x, z]) => { const l = new THREE.PointLight(0xffe8c8, 0, 9, 1.6); l.position.set(x, 3.0, z); scene.add(l); return l; });
    this.lightsOn = true;

    // ---- téléviseur ----
    this.tvCanvas = document.createElement('canvas'); this.tvCanvas.width = 320; this.tvCanvas.height = 180;
    this.tvCtx = this.tvCanvas.getContext('2d');
    this.tvTex = new THREE.CanvasTexture(this.tvCanvas); this.tvTex.colorSpace = THREE.SRGBColorSpace;
    this.tvScreen = new THREE.Mesh(new THREE.PlaneGeometry(1.92, 1.08), new THREE.MeshBasicMaterial({ map: this.tvTex, toneMapped: false }));
    this.tvScreen.position.set(-55.68, 1.43, 122.5); this.tvScreen.rotation.y = PI / 2;
    scene.add(this.tvScreen);
    this.tvOn = false; this.channel = 0; this.tvAcc = 0; this.drawTV(0);

    // ---- miroir de la salle de bain (réflexion réelle, active seulement dans la pièce) ----
    this.mirror = new Reflector(new THREE.PlaneGeometry(1.0, 0.8), { textureWidth: 256, textureHeight: 256, color: 0xb8c4c8 });
    this.mirror.position.set(-39.2, 1.65, 126.08); this.mirror.visible = false;
    scene.add(this.mirror);

    // ---- particules : eau de la douche, vapeur de cuisson ----
    const pts = (n, color, size) => { const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(n * 3), 3)); const p = new THREE.Points(geo, new THREE.PointsMaterial({ color, size, transparent: true, opacity: 0.7, depthWrite: false })); p.visible = false; p.frustumCulled = false; scene.add(p); return p; };
    this.water = pts(220, 0xbfe4ff, 0.04);
    this.steam = pts(40, 0xf0f0f0, 0.25); this.steam.material.map = T.smokePuff(); this.steam.material.size = 0.35;
    // assiette servie
    this.plate = new THREE.Group();
    this.plate.add(new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.12, 0.03, 16), mats.porcelain));
    this.plateFood = new THREE.Mesh(new THREE.SphereGeometry(0.11, 12, 8, 0, PI * 2, 0, PI / 2), mats.food); this.plateFood.position.y = 0.015;
    this.plate.add(this.plateFood); this.plate.position.set(-39.6, 0.8, 120.95); this.plate.visible = false;
    scene.add(this.plate);

    // ---- état (sauvegardé) ----
    this.food = null; // { id, stage: 'raw' | 'served' }
    this.fridgeStock = Object.fromEntries(FOODS.map((f) => [f.id, 3]));
    this.interactables = this.buildInteractables();
    this.activity = null;
    this.indoor = false;
    this.water.userData.base = new Float32Array(220 * 3);
  }

  drawTV(t) {
    const x = this.tvCtx;
    if (!this.tvOn) {
      const g = x.createLinearGradient(0, 0, 320, 180); g.addColorStop(0, '#0a0a0c'); g.addColorStop(0.5, '#1a1c20'); g.addColorStop(1, '#050506');
      x.fillStyle = g; x.fillRect(0, 0, 320, 180);
    } else drawChannel(x, this.channel, t);
    this.tvTex.needsUpdate = true;
  }

  isInside(x, z) {
    const H = HOME.house, G = HOME.garage;
    return (x > H.x0 && x < H.x1 && z > H.z0 && z < H.z1) || (x > G.x0 && x < G.x1 && z > G.z0 && z < G.z1);
  }
  inGarage(x, z) { const G = HOME.garage; return x > G.x0 + 0.5 && x < G.x1 - 0.5 && z > G.z0 + 1.5 && z < G.z1 - 0.3; }
  inBathroom(x, z) { return x > -42 && x < -36 && z > 126 && z < 130; }

  // ---- liste des points d'interaction (E) ----
  buildInteractables() {
    const h = this, I = [];
    const add = (x, z, r, label, action, when = () => true) => I.push({ x, z, r, label, action, when });
    add(-44.5, 117.2, 1.4, () => (h.frontDoor.target > 0.5 ? 'Fermer la porte d\'entrée' : 'Ouvrir la porte d\'entrée'), () => { h.frontDoor.toggle(); h.game.audio.door(); });
    add(-44.5, 118.9, 1.0, () => (h.frontDoor.target > 0.5 ? 'Fermer la porte d\'entrée' : 'Ouvrir la porte d\'entrée'), () => { h.frontDoor.toggle(); h.game.audio.door(); });
    add(-44.5, 109.3, 1.6, () => (h.pedGate.target > 0.5 ? 'Fermer le portillon' : 'Ouvrir le portillon'), () => { h.pedGate.toggle(); h.game.audio.door(); });
    add(-44.5, 110.8, 1.3, () => (h.pedGate.target > 0.5 ? 'Fermer le portillon' : 'Ouvrir le portillon'), () => { h.pedGate.toggle(); h.game.audio.door(); });
    add(-32, 109.2, 2.2, () => (h.carGate.target > 0.5 ? 'Fermer le portail' : 'Ouvrir le portail'), () => { h.carGate.toggle(); h.game.audio.door(); });
    add(-32, 111.0, 2.2, () => (h.carGate.target > 0.5 ? 'Fermer le portail' : 'Ouvrir le portail'), () => { h.carGate.toggle(); h.game.audio.door(); });
    add(-32, 116.9, 2.4, () => (h.garageDoor.target > 0.5 ? 'Fermer la porte du garage' : 'Ouvrir la porte du garage'), () => h.toggleGarage());
    add(-30.5, 119.6, 1.6, () => (h.garageDoor.target > 0.5 ? 'Fermer la porte du garage' : 'Ouvrir la porte du garage'), () => h.toggleGarage());
    add(-45.6, 119.0, 1.1, () => (h.lightsOn ? 'Éteindre les lumières' : 'Allumer les lumières'), () => { h.lightsOn = !h.lightsOn; h.game.audio.click(); });
    add(-37.4, 123.6, 1.2, () => 'Ouvrir le réfrigérateur', () => (h.game.kitchen ? h.game.kitchen.toggle(true) : h.openFridge()));
    add(-38.2, 124.8, 1.1, () => (h.game.kitchen ? h.game.kitchen.stoveLabel() : 'Cuisinière'), () => (h.game.kitchen ? h.game.kitchen.useStove() : h.cook()));
    add(-39.6, 122.9, 1.2, () => (h.game.kitchen ? h.game.kitchen.tableLabel() : 'Table à manger'), () => (h.game.kitchen ? h.game.kitchen.eat() : h.eat()));
    add(-54.2, 122.5, 1.5, () => (h.tvOn ? 'Télévision : chaînes / éteindre' : 'Allumer la télévision'), () => h.tvMenu());
    add(-50.4, 122.8, 1.3, () => 'S\'asseoir sur le canapé', () => h.sitSofa());
    add(-53.0, 130.6, 1.6, () => 'Se coucher (dormir)', () => h.bedMenu());
    add(-37.2, 129.0, 0.9, () => 'Prendre une douche', () => h.shower());
    add(-39.2, 127.0, 0.9, () => 'Se laver le visage et les mains', () => h.washFace());
    add(-37.3, 132.0, 1.3, () => 'Ouvrir l\'armoire (tenues)', () => h.wardrobe());
    add(-46.9, 132.2, 0.9, () => 'Se changer devant le miroir (garde-robe)', () => h.wardrobe(true));
    add(-29.4, 127.0, 1.3, () => 'Tableau à clés : rapatrier ma voiture', () => h.recallCar());
    return I;
  }

  // ---- branchement au jeu (joueur, environnement, interface, son, besoins, voiture) ----
  attach(game) { this.game = game; }

  toggleGarage() { const o = this.garageDoor.toggle(); if (this.game.audio.ctx) this.game.audio.tone(140, 1.2, 0.08, 'sawtooth'); return o; }

  openFridge() {
    const { ui } = this.game;
    this.fridgeOpen = true;
    ui.openMenu('Réfrigérateur', 'Choisis un plat à préparer (stock rechargé chaque matin)', FOODS.map((f) => ({
      label: `${f.name} (${this.fridgeStock[f.id]})`, desc: `${f.desc} • faim +${f.hunger}`, disabled: this.fridgeStock[f.id] <= 0 || (this.food && !f.drink),
      action: () => {
        this.fridgeStock[f.id]--;
        if (f.drink) this.startActivity('drink', 2.5, { food: f });
        else { this.food = { id: f.id, stage: 'raw' }; ui.toast(`${f.name} sorti du frigo : va à la cuisinière (E)`, 3); }
        this.game.save();
      },
    })), () => { this.fridgeOpen = false; });
  }
  cook() {
    if (!this.food || this.food.stage !== 'raw') { this.game.ui.toast('Choisis d\'abord un plat dans le réfrigérateur', 2); return; }
    const f = FOODS.find((q) => q.id === this.food.id);
    this.startActivity('cook', f.cook, { food: f });
  }
  eat() {
    if (!this.food || this.food.stage !== 'served') { this.game.ui.toast('Rien n\'est servi : prépare d\'abord un plat', 2); return; }
    this.startActivity('eat', 5, { food: FOODS.find((q) => q.id === this.food.id) });
  }
  tvMenu() {
    const { ui } = this.game;
    ui.openMenu('Télévision', 'Chaînes fictives de BENIN LIFE', [
      { label: this.tvOn ? 'Éteindre' : 'Allumer', action: () => { this.tvOn = !this.tvOn; this.game.audio.click(); this.game.save(); } },
      ...CHANNELS.map((c, i) => ({ label: `${i + 1}. ${c}`, desc: this.tvOn && this.channel === i ? 'en cours' : '', action: () => { this.tvOn = true; this.channel = i; this.game.audio.click(); this.game.save(); } })),
      { label: '📺 Programme TV du jour', desc: 'émissions fictives', action: () => setTimeout(() => this.tvGuide(), 0) },
    ]);
  }
  tvGuide() {
    const h = this.game.env.time, slot = (k) => `${String((Math.floor(h) + k) % 24).padStart(2, '0')} h`;
    this.game.ui.openMenu('Programme TV', 'Émissions fictives de BENIN LIFE', CHANNELS.map((c, i) => ({
      label: c, desc: TV_GUIDE[i].map((t, k) => `${slot(k)} ${t}`).join(' • '),
      action: () => { this.tvOn = true; this.channel = i; this.game.save(); this.game.ui.toast(`${c} : ${TV_GUIDE[i][0]}`, 2.5); },
    })));
  }
  sitSofa() { this.startActivity('sofa', Infinity); }
  bedMenu() {
    const { ui, env } = this.game;
    const toMorning = ((7 - env.time) + 24) % 24 || 24;
    ui.openMenu('Lit', `Énergie : ${Math.round(this.game.needs.energy)} %`, [
      { label: 'Faire une sieste (2 h)', desc: 'Énergie +30', action: () => this.startActivity('sleep', 6, { hours: 2, energy: 30 }) },
      { label: `Dormir jusqu'à 7 h (${toMorning.toFixed(1)} h)`, desc: 'Énergie au maximum • allocation du matin', action: () => this.startActivity('sleep', 7, { hours: toMorning, energy: 100, morning: true }) },
    ]);
  }
  shower() { this.startActivity('shower', 7); }
  washFace() { this.startActivity('wash', 3); }
  wardrobe(atMirror = false) {
    if (this.game.openWardrobe) return this.game.openWardrobe(atMirror); // garde-robe de 200 vêtements (mission 016)
    const { ui, player } = this.game;
    const list = OUTFITS[player.kind === 'female' ? 'female' : 'male'];
    this.wardrobeOpen = true;
    const cats = [...new Set(list.map((o) => o.cat))];
    ui.openMenu('Armoire', 'Tenues : quotidien, élégant, décontracté', cats.flatMap((c) => list.filter((o) => o.cat === c).map((o) => ({
      label: `${c} — ${o.name}`, desc: this.game.outfitId === o.id ? 'portée actuellement' : '',
      action: () => { this.game.setOutfit(o.id); ui.toast(`Tenue : ${o.name}`, 2); },
    }))), () => { this.wardrobeOpen = false; });
  }
  recallCar() {
    const car = this.game.personalCar;
    if (!car) return;
    if (car.occupied) { this.game.ui.toast('Ta voiture est occupée', 2); return; }
    if (this.inGarage(car.pos.x, car.pos.z)) { this.game.ui.toast('Ta voiture est déjà au garage', 2); return; }
    car.pos.set(HOME.carSpot.x, 0, HOME.carSpot.z); car.heading = HOME.carSpot.h; car.speed = 0; car.sync();
    this.game.ui.toast('Ta voiture a été ramenée au garage', 2.5); this.game.save();
  }

  // ---- activités (le joueur ne se déplace pas pendant l'activité ; E ou Échap pour arrêter celles qui le permettent) ----
  startActivity(type, dur, data = {}) {
    const p = this.game.player;
    this.activity = { type, t: 0, dur, data, phase: 0 };
    p.busy = type;
    const c = p.char, place = (x, y, z, ry) => { p.pos.set(x, 0, z); p.mesh.position.set(x, y, z); p.mesh.rotation.set(0, ry, 0); p.facing = ry; };
    if (type === 'sofa') { c.sit && c.sit(false); place(-51.55, -0.5, 122.8, -PI / 2); }
    else if (type === 'eat') { c.sit && c.sit(false); place(-39.6, -0.47, 120.2, 0); }
    else if (type === 'sleep') { c.stand && c.stand(); p.pos.set(-54, 0, 130.6); p.mesh.position.set(-53.9, 0.72, 130.6); p.mesh.rotation.set(-PI / 2, PI / 2, 0, 'YXZ'); }
    else if (type === 'shower') { c.stand && c.stand(); place(-36.95, 0.05, 129.1, PI); this.water.visible = true; this.game.audio.startLoop('shower'); }
    else if (type === 'wash') { c.stand && c.stand(); place(-39.2, 0, 126.95, PI); }
    else if (type === 'cook') { c.stand && c.stand(); place(-38.2, 0, 124.75, 0); this.steam.visible = true; this.game.audio.startLoop('sizzle'); }
    else if (type === 'drink') { c.stand && c.stand(); }
    else if (data.seat) { c.sit && c.sit(false); place(...data.seat); }
    this.game.ui.setActivity(this.activityLabel());
  }
  activityLabel() {
    const a = this.activity; if (!a) return null;
    const left = a.dur === Infinity ? '' : ` — ${Math.max(0, Math.ceil(a.dur - a.t))} s`;
    switch (a.type) {
      case 'sofa': return `Assis sur le canapé • ${this.tvOn ? '← → chaîne • Espace : éteindre' : 'Espace : allumer la TV'} • E : se lever`;
      case 'eat': return `Repas : ${a.data.food.name}${left}`;
      case 'drink': return `Tu bois : ${a.data.food.name}${left}`;
      case 'cook': return `Préparation : ${a.data.food.name}${left}`;
      case 'sleep': return 'Sommeil…';
      case 'shower': return `Douche${left} • E : arrêter`;
      case 'wash': return `Toilette du visage${left}`;
      default: return a.data.label || '';
    }
  }
  endActivity(completed = true) {
    const a = this.activity, g = this.game, p = g.player, n = g.needs;
    if (!a) return;
    this.activity = null;
    p.busy = null;
    p.char.stand && p.char.stand();
    p.mesh.rotation.set(0, p.facing, 0, 'XYZ');
    this.water.visible = false; this.steam.visible = false;
    g.audio.stopLoop();
    if (completed && a.data.onDone) a.data.onDone(); // cuisine de la mission 013 (réfrigérateur, recettes, assiettes)
    else if (completed) {
      if (a.type === 'eat') { n.hunger = Math.min(100, n.hunger + a.data.food.hunger); this.food = null; this.plate.visible = false; g.ui.toast(`Délicieux ! Faim +${a.data.food.hunger}`, 2.5); }
      if (a.type === 'drink') { n.hunger = Math.min(100, n.hunger + a.data.food.hunger); g.ui.toast('Rafraîchissant !', 2); }
      if (a.type === 'cook') { this.food.stage = 'served'; this.plateFood.material.color.setHex(a.data.food.color); this.plate.visible = true; g.ui.toast('Le plat est servi sur la table : assieds-toi pour manger (E)', 3); }
      if (a.type === 'shower') { n.hygiene = 100; g.ui.toast('Propreté : 100 %', 2); }
      if (a.type === 'wash') { n.hygiene = Math.min(100, n.hygiene + 20); g.ui.toast('Propreté +20', 2); }
    }
    if (a.type === 'eat' && !completed) this.plate.visible = !!this.food;
    if (a.type === 'sleep') p.pos.set(-52.6, 0, 130.6);
    if (a.type === 'sofa') p.pos.set(-50.3, 0, 122.8);
    if (a.type === 'eat') p.pos.set(-39.6, 0, 119.6);
    if (a.type === 'shower') p.pos.set(-38.4, 0, 128.6);
    if (a.data.exit) p.pos.set(a.data.exit[0], 0, a.data.exit[1]);
    if (a.data.onEnd) a.data.onEnd();
    p.mesh.position.copy(p.pos);
    g.ui.setActivity(null);
    g.save();
  }

  // touches spéciales pendant une activité (renvoie true si la touche est consommée)
  handleActivityKeys(input) {
    const a = this.activity; if (!a) return false;
    if (a.type === 'sofa') {
      if (input.hit('ArrowRight')) { this.tvOn = true; this.channel = (this.channel + 1) % CHANNELS.length; }
      if (input.hit('ArrowLeft')) { this.tvOn = true; this.channel = (this.channel + CHANNELS.length - 1) % CHANNELS.length; }
      if (input.hit('Space')) this.tvOn = !this.tvOn;
      if (input.hit('KeyE') || input.hit('Escape')) { this.endActivity(); return true; }
      this.game.ui.setActivity(this.activityLabel());
      return true;
    }
    if ((a.type === 'shower' || a.type === 'eat') && input.hit('KeyE')) { this.endActivity(a.type === 'shower' && a.t > 2); return true; }
    if (a.data.seat && (input.hit('KeyE') || input.hit('Escape'))) { this.endActivity(false); return true; }
    return true;
  }

  update(dt, ctx) {
    const { playerPos, player, personalCar, realTime } = ctx;
    // portes automatiques intérieures (seulement pour le joueur à pied)
    for (const d of this.doors) d.update(dt, player.inCar || player.busy ? null : playerPos);
    this.pedGate.update(dt); this.carGate.update(dt); this.garageDoor.update(dt);
    // télécommande : la voiture personnelle ouvre portail et garage à l'approche
    if (personalCar && personalCar.occupied) {
      const dg = Math.hypot(personalCar.pos.x + 32, personalCar.pos.z - 115);
      if (dg < 10) { if (this.carGate.target < 0.5) this.carGate.toggle(); if (this.garageDoor.target < 0.5) this.garageDoor.toggle(); }
    }
    // intérieur : toit et étage masqués pour voir le joueur, miroir actif dans la salle de bain
    this.indoor = !player.inCar && this.isInside(playerPos.x, playerPos.z);
    this.upper.visible = !this.indoor;
    this.mirror.visible = this.indoor && this.inBathroom(playerPos.x, playerPos.z);
    this.garageDoor.pivot.visible = !(this.indoor && this.garageDoor.open > 0.9); // la porte relevée masquerait la vue plongeante
    const near = Math.hypot(playerPos.x + 44, playerPos.z - 126) < 45;
    const on = this.lightsOn && near;
    for (const l of this.lights) l.intensity = on ? 7 : 0;
    this.mats.lampIn.emissiveIntensity = this.lightsOn ? 1.4 : 0;
    // téléviseur (~12 images/s, uniquement à proximité)
    this.tvAcc += dt;
    if (near && this.tvAcc > 1 / 12) { this.tvAcc = 0; this.drawTV(realTime); }
    // activité en cours
    const a = this.activity;
    this.mats.burner.emissiveIntensity = a && a.type === 'cook' ? 1.6 + Math.sin(realTime * 8) * 0.3 : 0;
    if (a) {
      a.t += dt;
      const b = player.char.bones || null;
      if (a.type === 'sleep') {
        player.char.animate(dt, 0);
        // fondu au noir, avance de l'heure, réveil
        if (a.phase === 0 && a.t > 1.2) { a.phase = 1; this.game.ui.fade(true); }
        if (a.phase === 1 && a.t > 2.6) {
          a.phase = 2;
          const n = this.game.needs, hrs = a.data.hours;
          this.game.env.time = (this.game.env.time + hrs) % 24;
          n.energy = Math.min(100, a.data.energy === 100 ? 100 : n.energy + a.data.energy);
          n.hunger = Math.max(0, n.hunger - hrs * 1.5); n.hygiene = Math.max(0, n.hygiene - hrs * 1.0);
          this.game.ui.fade(false);
          this.game.ui.toast(a.data.morning ? `Bonjour ! Il est ${this.game.env.clock}. Énergie : 100 %` : `Sieste terminée (${this.game.env.clock}). Énergie +${a.data.energy}`, 3.5);
        }
      } else if (a.type === 'eat' || a.type === 'drink') {
        if (a.type === 'drink') player.char.animate(dt, 0);
        const k = Math.max(0, Math.sin(a.t * 3.2));
        if (b) { b.armR.rotation.x = -0.9 - k * 0.9; b.foreR.rotation.x = -0.6 - k * 1.2; }
      } else if (a.type === 'shower' || a.type === 'wash') {
        player.char.animate(dt, 0);
        const k = Math.sin(a.t * 5);
        if (b) { b.armL.rotation.x = -2.2 + k * 0.4; b.armR.rotation.x = -2.2 - k * 0.4; b.foreL.rotation.x = b.foreR.rotation.x = -1.4; }
        if (b && a.type === 'wash') { b.armL.rotation.x = b.armR.rotation.x = -1.1 + k * 0.2; b.spine.rotation.x = 0.35; }
        if (a.type === 'shower') {
          const pos = this.water.geometry.attributes.position, arr = pos.array;
          for (let i = 0; i < arr.length; i += 3) {
            const ph = ((realTime * 2.2 + (i * 0.618) % 1) % 1);
            arr[i] = -37.0 + Math.sin(i * 12.9898) * 0.35; arr[i + 1] = 2.0 - ph * 2.0; arr[i + 2] = 129.2 + Math.cos(i * 78.233) * 0.35;
          }
          pos.needsUpdate = true;
        }
      } else if (a.type === 'cook') {
        player.char.animate(dt, 0);
        const k = Math.sin(a.t * 4);
        if (b) { b.armR.rotation.x = -0.9 + k * 0.25; b.foreR.rotation.x = -0.8; b.armL.rotation.x = -0.6; b.foreL.rotation.x = -0.5; }
        const pos = this.steam.geometry.attributes.position, arr = pos.array;
        for (let i = 0; i < arr.length; i += 3) { const ph = ((realTime * 0.6 + (i * 0.37) % 1) % 1); arr[i] = -38.2 + Math.sin(i + realTime) * 0.15; arr[i + 1] = 1.0 + ph * 1.2; arr[i + 2] = 125.6 + Math.cos(i) * 0.1; }
        pos.needsUpdate = true;
      }
      if (a.t >= a.dur) this.endActivity(true);
      else this.game.ui.setActivity(this.activityLabel());
    }
  }

  // ---- interaction la plus proche du joueur ----
  nearest(x, z) {
    let best = null, bd = Infinity;
    for (const it of this.interactables) {
      const d = Math.hypot(it.x - x, it.z - z);
      if (d < it.r && d < bd && it.when()) { bd = d; best = it; }
    }
    return best ? { it: best, d: bd } : null;
  }

  // ---- sauvegarde ----
  serialize() {
    return { lightsOn: this.lightsOn, tvOn: this.tvOn, channel: this.channel, garageOpen: this.garageDoor.target > 0.5, gateOpen: this.carGate.target > 0.5, food: this.food, fridge: this.fridgeStock };
  }
  restore(s) {
    if (!s) return;
    this.lightsOn = s.lightsOn ?? true; this.tvOn = !!s.tvOn; this.channel = s.channel || 0;
    if (s.garageOpen) { this.garageDoor.target = this.garageDoor.open = 1; this.garageDoor.update(0); }
    if (s.gateOpen) { this.carGate.target = this.carGate.open = 1; this.carGate.update(0); }
    if (s.fridge) Object.assign(this.fridgeStock, s.fridge);
    if (s.food && s.food.stage === 'served') { this.food = s.food; this.plate.visible = true; const f = FOODS.find((q) => q.id === s.food.id); if (f) this.plateFood.material.color.setHex(f.color); }
    else if (s.food) this.food = s.food;
  }
}
