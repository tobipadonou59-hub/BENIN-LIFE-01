// Mission 014, étape 4 — groupe de sociétés NOVA et banque.
// Chaque société (hors NOVA BOOK, gérée par company.js) a sa trésorerie, ses employés, son directeur, ses locaux,
// ses équipements, ses recettes et ses charges. La banque gère les comptes (personnel + un par société), les
// virements, les relevés, des prêts facultatifs et le bilan mensuel. Tous les montants sont des valeurs du jeu.
import { JOBS } from './nova-data.js';
import { fcfa } from './food-data.js';

export const SUBS = [
  { id: 'digital', name: 'NOVA DIGITAL', sector: 'Informatique et développement', jobs: ['developpeur', 'developpeur', 'graphiste', 'commercial'], rate: 80000, create: 5000000, buy: 14000000, activity: ['application de gestion livrée', 'site web mis en ligne', 'maintenance informatique facturée'] },
  { id: 'media', name: 'NOVA MEDIA', sector: 'Audiovisuel et production vidéo', jobs: ['monteur', 'monteur', 'graphiste', 'commercial'], rate: 78000, create: 4500000, buy: 13000000, activity: ['spot publicitaire livré', 'reportage monté', 'captation d’un concert facturée'] },
  { id: 'immo', name: 'NOVA IMMOBILIER', sector: 'Location et gestion de bâtiments', jobs: ['agent_immo', 'agent_immo', 'comptable', 'entretien'], rate: 85000, create: 6000000, buy: 16000000, activity: ['loyers encaissés', 'mandat de gestion signé', 'appartement loué'] },
  { id: 'transport', name: 'NOVA TRANSPORT', sector: 'Transport et logistique', jobs: ['chauffeur', 'chauffeur', 'chauffeur', 'logisticien'], rate: 70000, create: 5500000, buy: 15000000, activity: ['livraisons Cotonou–Porto-Novo', 'transport de marchandises vers Ouidah', 'tournée de livraison terminée'] },
  { id: 'distribution', name: 'NOVA DISTRIBUTION', sector: 'Commerce et distribution', jobs: ['vendeur', 'vendeur', 'vendeur', 'logisticien'], rate: 72000, create: 5000000, buy: 14000000, activity: ['commande d’une boutique livrée', 'stock vendu au marché', 'contrat de distribution signé'] },
];
const FIRST = ['Aurélien', 'Sika', 'Mawuli', 'Estelle', 'Désiré', 'Akouavi', 'Parfait', 'Ornella', 'Wilfrid', 'Nadia', 'Crépin', 'Yolande', 'Bertin', 'Huguette', 'Fiacre', 'Rachelle'];
const LAST = ['Adjahossou', 'Hounsou', 'Gbaguidi', 'Kossi', 'Aholou', 'Doussou', 'Akpo', 'Vodounon', 'Zinsou', 'Adanlé', 'Sossou', 'Tchanhoun'];
const pick = (a) => a[Math.floor(Math.random() * a.length)];
const r5 = (n) => Math.round(n / 5000) * 5000;
const RENT = 300000, PREMISES = 9000000, FIXED = 150000;
// consignes du PDG au directeur (téléphone ou visite) : effets réels sur la production, le moral et les frais fixes
export const INSTR = {
  cadence: { label: 'Accélérer la production', rate: 1.1, morale: -1, fixed: 1, effect: 'production +10 %, moral −1/jour' },
  qualite: { label: 'Priorité à la qualité', rate: 0.95, morale: 1, fixed: 1, effect: 'production −5 %, moral +1/jour' },
  economies: { label: 'Réduire les dépenses', rate: 0.95, morale: 0, fixed: 0.8, effect: 'frais fixes −20 %, production −5 %' },
};

export class Group {
  constructor({ company, economy, onSave }) {
    Object.assign(this, { company, economy, onSave });
    this.subs = {}; this.loans = []; this.uid = 1000; this.months = [];
    this.persoLedger = []; // relevé bancaire personnel : on s'appuie sur l'historique du portefeuille
    company.group = this;
    if (company.savedGroup) this.restore(company.savedGroup);
  }
  note(m) { this.company.note(m); }
  stamp() { return this.company.stamp(); }
  emp(job, skill = 45 + Math.random() * 35) { const J = JOBS[job]; return { id: this.uid++, name: `${pick(FIRST)} ${pick(LAST)}`, job, salary: r5(J.salary * (0.9 + skill / 400)), skill: Math.round(skill), morale: 75 }; }
  // ---- création / rachat ----
  start(id, mode, from) {
    const def = SUBS.find((d) => d.id === id); if (!def || this.subs[id]) return;
    const price = mode === 'buy' ? def.buy : def.create, capital = mode === 'buy' ? 1500000 : 2000000;
    if (!this.debit(from, price, `${mode === 'buy' ? 'Rachat' : 'Création'} de ${def.name}`, false, 'invest')) return;
    const n = mode === 'buy' ? 8 : 4, staff = [];
    for (let i = 0; i < n; i++) staff.push(this.emp(def.jobs[i % def.jobs.length], mode === 'buy' ? 60 + Math.random() * 25 : undefined));
    this.subs[id] = { id, name: def.name, cash: capital, staff, director: null, premises: 'loués', equip: 1, ledger: [{ d: this.stamp(), label: mode === 'buy' ? 'Trésorerie reprise au rachat' : 'Capital initial', amount: capital, cat: 'capital' }], cur: this.blank(), months: [], payDue: null, autoPay: true, since: this.stamp(), mode };
    this.note(`🏢 ${def.name} ${mode === 'buy' ? 'rachetée' : 'créée'} ! ${n} employés • trésorerie ${fcfa(capital)}`);
    this.updatePlaces(); this.onSave && this.onSave();
  }
  blank() { return { ca: 0, salaires: 0, loyers: 0, invest: 0, frais: 0, credit: 0 }; }
  post(s, label, amount, cat) { s.cash += amount; s.ledger.unshift({ d: this.stamp(), label, amount, cat }); s.ledger.length = Math.min(s.ledger.length, 120); s.cur[cat] = (s.cur[cat] || 0) + amount; }
  // comptes : 'perso', 'book' (NOVA BOOK) ou l'id d'une société
  balance(acc) { return acc === 'perso' ? this.economy.balance : acc === 'book' ? this.company.cash : (this.subs[acc] ? this.subs[acc].cash : 0); }
  accName(acc) { return acc === 'perso' ? 'Compte personnel' : acc === 'book' ? 'NOVA BOOK' : this.subs[acc] ? this.subs[acc].name : acc; }
  debit(acc, amount, label, force = false, cat = 'frais') {
    if (!force && this.balance(acc) < amount) { this.note(`❌ Solde insuffisant sur ${this.accName(acc)} (${fcfa(this.balance(acc))}) pour ${label}`); return false; }
    if (acc === 'perso') { if (force && this.economy.balance < amount) { this.economy.balance -= amount; this.economy.history.unshift({ t: this.economy.stamp(), label, amount: -amount, place: 'Banque' }); this.economy.renderHud(); } else this.economy.pay(amount, label, 'Banque'); }
    else if (acc === 'book') this.company.post(label, -amount, cat);
    else this.post(this.subs[acc], label, -amount, cat);
    return true;
  }
  credit(acc, amount, label) {
    if (acc === 'perso') this.economy.earn(amount, label, 'Banque');
    else if (acc === 'book') this.company.post(label, amount, 'virement');
    else this.post(this.subs[acc], label, amount, 'virement');
  }
  transfer(from, to, amount) {
    if (from === to || amount <= 0) return;
    if (!this.debit(from, amount, `Virement vers ${this.accName(to)}`, false, 'virement')) return;
    this.credit(to, amount, `Virement de ${this.accName(from)}`);
    this.note(`🏦 Virement de ${fcfa(amount)} : ${this.accName(from)} → ${this.accName(to)}`); this.onSave && this.onSave();
  }
  // ---- gestion d'une société ----
  hire(id, job) { const s = this.subs[id]; if (!s) return; const e = this.emp(job); s.staff.push(e); this.note(`🤝 ${e.name} rejoint ${s.name} (${JOBS[job].label})`); this.onSave && this.onSave(); }
  fire(id, eid) { const s = this.subs[id], e = s && s.staff.find((q) => q.id === eid); if (!e) return; this.post(s, `Indemnité — ${e.name}`, -e.salary, 'salaires'); s.staff = s.staff.filter((q) => q !== e); if (s.director === eid) s.director = null; this.onSave && this.onSave(); }
  setDirector(id, eid) { const s = this.subs[id], e = s && s.staff.find((q) => q.id === eid); if (!e) return; s.director = eid; e.salary = r5(e.salary * 1.4); this.note(`👔 ${e.name} nommé(e) directeur/directrice de ${s.name}`); this.onSave && this.onSave(); }
  upgrade(id) { const s = this.subs[id]; if (!s || s.equip >= 3) return; const c = [0, 1200000, 2500000][s.equip]; if (s.cash < c) return this.note(`❌ Trésorerie de ${s.name} insuffisante`); this.post(s, `Équipements niveau ${s.equip + 1}`, -c, 'invest'); s.equip++; this.onSave && this.onSave(); }
  buyPremises(id) { const s = this.subs[id]; if (!s || s.premises === 'achetés') return; if (s.cash < PREMISES) return this.note(`❌ Il faut ${fcfa(PREMISES)} sur le compte de ${s.name}`); this.post(s, 'Achat des locaux', -PREMISES, 'invest'); s.premises = 'achetés'; this.note(`🏬 ${s.name} est propriétaire de ses locaux (plus de loyer)`); this.onSave && this.onSave(); }
  payroll(id) { const s = this.subs[id]; if (!s || !s.payDue) return; if (s.cash < s.payDue) return this.note(`⚠️ ${s.name} : trésorerie insuffisante pour les salaires (${fcfa(s.payDue)})`); this.post(s, 'Salaires du mois', -s.payDue, 'salaires'); s.payDue = null; for (const e of s.staff) e.morale = Math.min(100, e.morale + 4); this.onSave && this.onSave(); }
  rate(s) { const def = SUBS.find((d) => d.id === s.id), dir = s.staff.find((e) => e.id === s.director); return s.staff.reduce((a, e) => a + (e.status === 'repos' ? 0 : (e.skill / 100) * (0.7 + e.morale / 330) * (e.boost && e.boost.until >= this.company.day ? e.boost.k : 1)), 0) * def.rate * (1 + (s.equip - 1) * 0.25) * (dir ? 1 + dir.skill / 500 : 0.9) * (INSTR[s.instruction] ? INSTR[s.instruction].rate : 1); }
  // ---- temps ----
  newDay() {
    for (const s of Object.values(this.subs)) {
      const def = SUBS.find((d) => d.id === s.id), market = 0.85 + Math.random() * 0.3, rev = r5(this.rate(s) * market);
      if (rev > 0) this.post(s, `Activité : ${pick(def.activity)}`, rev, 'ca');
      if (s.payDue) for (const e of s.staff) e.morale = Math.max(10, e.morale - 5);
      const ins = INSTR[s.instruction]; if (ins && ins.morale) for (const e of s.staff) e.morale = Math.max(10, Math.min(100, e.morale + ins.morale));
    }
  }
  monthEnd() {
    const sheet = { m: this.company.month - 1, rows: [] };
    for (const s of Object.values(this.subs)) {
      if (s.premises === 'loués') this.post(s, 'Loyer des bureaux', -RENT, 'loyers');
      this.post(s, 'Charges fixes', -Math.round(FIXED * (INSTR[s.instruction] ? INSTR[s.instruction].fixed : 1)), 'frais');
      s.payDue = (s.payDue || 0) + s.staff.reduce((a, e) => a + e.salary, 0);
      if (s.autoPay) this.payroll(s.id);
      const c = s.cur, net = c.ca + c.salaires + c.loyers + c.invest + c.frais + (c.credit || 0);
      s.months.unshift({ m: sheet.m, ...c, cash: s.cash }); s.months.length = Math.min(s.months.length, 12);
      sheet.rows.push({ name: s.name, ca: c.ca, charges: c.salaires + c.loyers + c.invest + c.frais + c.credit, net, cash: s.cash });
      s.cur = this.blank();
      if (s.cash < 0) this.note(`🚨 ${s.name} est à découvert (${fcfa(s.cash)}) : renfloue-la par un virement.`);
    }
    // échéances des prêts
    for (const L of this.loans) {
      if (L.left <= 0) continue;
      this.debit(L.acc, L.monthly, `Échéance du prêt (${L.left} restante(s))`, true, 'credit');
      L.left--; if (L.left === 0) this.note(`🏦 Prêt de ${fcfa(L.principal)} entièrement remboursé`);
    }
    this.loans = this.loans.filter((L) => L.left > 0);
    const b = this.company.months[0]; if (b) sheet.rows.unshift({ name: 'NOVA BOOK', ca: b.ca, charges: b.salaires + b.invest + b.frais, net: b.net, cash: this.company.cash });
    this.months.unshift(sheet); this.months.length = Math.min(this.months.length, 12);
    this.note(`📊 Bilan mensuel du groupe disponible (Banque → Bilan)`);
  }
  // ---- prêts (facultatifs) ----
  loan(acc, amount, months) {
    const rate = 0.012; // 1,2 % par mois (taux du jeu)
    const monthly = r5(amount * (rate / (1 - Math.pow(1 + rate, -months))));
    this.credit(acc, amount, `Prêt bancaire (${months} mois)`);
    this.loans.push({ acc, principal: amount, monthly, left: months, months, since: this.stamp() });
    this.note(`🏦 Prêt accordé : ${fcfa(amount)} sur ${months} mois • mensualité ${fcfa(monthly)}`); this.onSave && this.onSave();
  }
  repay(i) { const L = this.loans[i]; if (!L) return; const rest = L.monthly * L.left; if (!this.debit(L.acc, rest, 'Remboursement anticipé du prêt', false, 'credit')) return; this.loans.splice(i, 1); this.onSave && this.onSave(); }
  accounts() { return ['perso', 'book', ...Object.keys(this.subs)]; }
  statement(acc) {
    if (acc === 'perso') return this.economy.history.map((h) => ({ d: h.t, label: `${h.label} • ${h.place}`, amount: h.amount }));
    if (acc === 'book') return this.company.ledger.map((l) => ({ d: l.d, label: l.label, amount: l.amount }));
    return (this.subs[acc] ? this.subs[acc].ledger : []).map((l) => ({ d: l.d, label: l.label, amount: l.amount }));
  }
  setInstruction(id, k) {
    const s = this.subs[id]; if (!s) return false;
    s.instruction = INSTR[k] ? k : null;
    this.note(s.instruction ? `📋 Consigne transmise à ${s.name} : ${INSTR[k].label} (${INSTR[k].effect})` : `📋 ${s.name} : consignes levées, fonctionnement normal`);
    this.onSave && this.onSave(); return true;
  }
  updatePlaces() {
    if (!this.pois) return;
    for (const p of this.pois) { const s = Object.values(this.subs).find((q) => q.name === p.name); if (s) { p.reserved = false; p.note = `${SUBS.find((d) => d.id === s.id).sector} • société active (${s.staff.length} employés) • bureaux visitables : entrée signalée par l’enseigne lumineuse`; } }
  }
  serialize() { return { subs: this.subs, loans: this.loans, uid: this.uid, months: this.months }; }
  restore(s) { if (!s) return; this.subs = s.subs || {}; for (const q of Object.values(this.subs)) q.cur = q.cur || this.blank(); this.loans = s.loans || []; this.uid = s.uid || this.uid; this.months = s.months || []; this.updatePlaces(); }
}
