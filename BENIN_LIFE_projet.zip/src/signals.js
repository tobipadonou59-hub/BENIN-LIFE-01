// Feux tricolores des carrefours : cycle vert / orange / rouge par axe, lampes réellement allumées.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

const GREEN = 11, YELLOW = 2.5, ALLRED = 1.5;
const CYCLE = 2 * (GREEN + YELLOW + ALLRED);


export class TrafficLights {
  constructor(scene, intersections, collision) {
    this.list = intersections.map((it) => ({ ...it, t: it.offset || 0 }));
    const poleMat = new THREE.MeshStandardMaterial({ color: 0x1e2022, metalness: 0.5, roughness: 0.5 });
    const parts = [];
    const bulbPos = { red: [], yellow: [], green: [] };
    const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(), one = new THREE.Vector3(1, 1, 1);
    this.heads = [];
    for (const it of this.list) {
      // une tête par sens d'arrivée, au coin droit avant le carrefour, tournée vers les véhicules
      const approaches = [
        { axis: 'ns', x: it.x - 8.6, z: it.z - 8.6, ry: Math.PI },      // véhicules allant vers +z
        { axis: 'ns', x: it.x + 8.6, z: it.z + 8.6, ry: 0 },            // vers -z
        { axis: 'ew', x: it.x - 8.6, z: it.z + 8.6, ry: -Math.PI / 2 }, // vers +x
        { axis: 'ew', x: it.x + 8.6, z: it.z - 8.6, ry: Math.PI / 2 },  // vers -x
      ];
      for (const a of approaches) {
        m4.compose(new THREE.Vector3(a.x, 0, a.z), q.setFromEuler(e.set(0, a.ry, 0)), one);
        const L = (g) => { parts.push(g.applyMatrix4(m4)); };
        L(new THREE.CylinderGeometry(0.07, 0.09, 3.2, 8).translate(0, 1.6, 0));
        L(new THREE.BoxGeometry(0.34, 0.95, 0.25).translate(0, 3.5, 0));
        const head = { it, axis: a.axis, idx: {}, shown: null };
        ['red', 'yellow', 'green'].forEach((c, k) => {
          const v = new THREE.CylinderGeometry(0.14, 0.14, 0.14, 12, 1, true, -Math.PI / 2, Math.PI); v.rotateX(Math.PI / 2); v.translate(0, 3.86 - k * 0.3, 0.2);
          L(v);
          const p = new THREE.Vector3(0, 3.8 - k * 0.3, 0.13).applyMatrix4(m4);
          head.idx[c] = bulbPos[c].length;
          bulbPos[c].push({ p, ry: a.ry });
        });
        if (collision) collision.addCircle(a.x, a.z, 0.15, 3);
        this.heads.push(head);
      }
    }
    const merged = mergeGeometries(parts.map((g) => (g.index ? g.toNonIndexed() : g)));
    const mesh = new THREE.Mesh(merged, poleMat); mesh.castShadow = true; mesh.receiveShadow = true;
    scene.add(mesh);
    // lampes : un maillage instancié par couleur, allumé/éteint via la couleur d'instance (rendu non éclairé => halo)
    this.bulbs = {};
    const COL = { red: 0xff2a10, yellow: 0xffb000, green: 0x20f070 };
    const geo = new THREE.CircleGeometry(0.11, 14);
    for (const c of ['red', 'yellow', 'green']) {
      const im = new THREE.InstancedMesh(geo, new THREE.MeshBasicMaterial({ color: 0xffffff, toneMapped: false }), bulbPos[c].length);
      bulbPos[c].forEach(({ p, ry }, i) => { m4.compose(p, q.setFromEuler(e.set(0, ry, 0)), one); im.setMatrixAt(i, m4); im.setColorAt(i, new THREE.Color(0x111111)); });
      im.userData.noAO = true;
      scene.add(im);
      this.bulbs[c] = { im, on: new THREE.Color(COL[c]).multiplyScalar(2.2), off: new THREE.Color(0x141414) };
    }
  }

  // état du feu pour un axe ('ns' : véhicules circulant selon z, 'ew' : selon x)
  state(it, axis) {
    const t = it.t % CYCLE;
    const p = axis === 'ns' ? t : (t + CYCLE / 2) % CYCLE;
    if (p < GREEN) return 'green';
    if (p < GREEN + YELLOW) return 'yellow';
    return 'red';
  }

  update(dt) {
    for (const it of this.list) it.t += dt;
    let dirty = false;
    for (const h of this.heads) {
      const st = this.state(h.it, h.axis);
      if (st === h.shown) continue;
      h.shown = st; dirty = true;
      for (const c of ['red', 'yellow', 'green']) this.bulbs[c].im.setColorAt(h.idx[c], c === st ? this.bulbs[c].on : this.bulbs[c].off);
    }
    if (dirty) for (const c of ['red', 'yellow', 'green']) this.bulbs[c].im.instanceColor.needsUpdate = true;
  }
}
