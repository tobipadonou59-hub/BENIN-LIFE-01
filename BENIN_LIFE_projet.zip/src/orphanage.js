// Mission 019, étape 5 — NOVA SOLIDARITÉ – CENTRE D'ACCUEIL POUR ENFANTS (établissement fictif, capacité 60).
// Bâtiment existant de Cotonou (inoccupé) doté d'une entrée, d'une enseigne et d'une fresque ; intérieur isolé autour
// d'une grande cour : accueil et administration, infirmerie, bibliothèque, salle d'étude, salle informatique, salle à
// manger, cuisine, salle de jeux, espace détente, dortoirs (petits, filles, garçons), chambres des grands, sanitaires
// filles et garçons, cour avec jeux, terrain et jardin potager. Personnel fictif (direction, éducateurs, enseignants,
// cuisinier, entretien, infirmière, protection de l'enfance), enfants accueillis (registre fictif, jamais de données
// réelles), planning des repas et activités selon l'heure, besoins du centre, 7 types de dons enregistrés dans
// l'historique, projets, journées de visite encadrées. Toujours dans l'intérêt des enfants.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { colorize } from './vehicles.js';
import { createCharacter, SKINS } from './character.js';
import { fcfa } from './food-data.js';
import { mulberry32 } from './util.js';

const PI = Math.PI;
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const pick = (a) => a[Math.floor(Math.random() * a.length)];
export const CENTRE = { name: 'NOVA SOLIDARITÉ – CENTRE D’ACCUEIL POUR ENFANTS', LV: 160, Y: 560, CAP: 60, FP: [-135, 129, -117, 141] };
const ROOMS = [ // [id, nom, x0, z0, x1, z1, type] — la cour occupe x −22…22, z −14…14
  ['accueil', 'Accueil et administration', -30, 14, -18, 22, 'admin'], ['infirmerie', 'Infirmerie', -18, 14, -8, 22, 'infirmerie'], ['biblio', 'Bibliothèque', -8, 14, 4, 22, 'biblio'], ['etude', 'Salle d’étude', 4, 14, 16, 22, 'etude'], ['info', 'Salle informatique', 16, 14, 30, 22, 'info'],
  ['dort_p', 'Dortoir des petits', -30, -22, -18, -14, 'dortoir'], ['dort_f', 'Dortoir des filles', -18, -22, -6, -14, 'dortoir'], ['dort_g', 'Dortoir des garçons', -6, -22, 6, -14, 'dortoir'], ['grands', 'Chambres des grands', 6, -22, 18, -14, 'chambres'], ['san_f', 'Sanitaires filles', 18, -22, 24, -14, 'sanitaires'], ['san_g', 'Sanitaires garçons', 24, -22, 30, -14, 'sanitaires'],
  ['repas', 'Salle à manger', -30, -14, -22, 2, 'repas'], ['cuisine', 'Cuisine', -30, 2, -22, 14, 'cuisine'], ['jeux', 'Salle de jeux', 22, -14, 30, 0, 'jeux'], ['detente', 'Espace détente', 22, 0, 30, 14, 'detente'],
];
export const STAFF = [
  ['dir', 'Mme Théodora Hounsou', 'Directrice', true, 'accueil'], ['pro1', 'M. Fidèle Ahyi', 'Responsable de la protection de l’enfance', false, 'accueil'], ['pro2', 'Mme Carine Zossou', 'Responsable de la protection de l’enfance', true, 'accueil'],
  ['edu1', 'Mme Pélagie Adjovi', 'Éducatrice', true, 'cour'], ['edu2', 'M. Romuald Tossou', 'Éducateur', false, 'jeux'], ['ens1', 'M. Hilaire Gbaguidi', 'Enseignant', false, 'etude'], ['ens2', 'Mme Rosine Akpovi', 'Enseignante', true, 'biblio'],
  ['cuis', 'Mme Bernadette Kiki', 'Cuisinière', true, 'cuisine'], ['ent1', 'M. Constant Dossou', 'Agent d’entretien', false, 'repas'], ['ent2', 'Mme Odile Sossa', 'Agente d’entretien', true, 'detente'], ['inf', 'Mme Estelle Lawani', 'Infirmière (personnel médical fictif)', true, 'infirmerie'],
];
const F_N = ['Afi', 'Sèna', 'Mariam', 'Nadège', 'Grâce', 'Fifamè', 'Aïcha', 'Inès', 'Ornella', 'Sika', 'Prisca', 'Laura', 'Merveille', 'Divine', 'Esther'];
const M_N = ['Koffi', 'Sèdjro', 'Ibrahim', 'Josué', 'David', 'Fiacre', 'Wilfried', 'Ange', 'Prince', 'Gédéon', 'Rachad', 'Emmanuel', 'Junior', 'Rodrigue', 'Samuel'];
const HOBBY = ['le football', 'le dessin', 'la lecture', 'la danse', 'les mathématiques', 'la musique', 'les jeux de société', 'l’informatique', 'le chant', 'les sciences'];
const TRAIT = ['curieux·se', 'calme', 'joyeux·se', 'timide', 'bavard·e', 'appliqué·e', 'créatif·ve', 'sportif·ve'];
export const LEVELS = (age) => (age < 6 ? 'maternelle' : age < 12 ? `CI–CM2 (${['CI', 'CP', 'CE1', 'CE2', 'CM1', 'CM2'][Math.min(5, age - 6)]})` : age < 16 ? `collège (${['6e', '5e', '4e', '3e'][Math.min(3, age - 12)]})` : `lycée (${age === 16 ? 'seconde' : 'première'})`);
export const DONS = {
  financier: { label: 'Don financier', icon: '💶', amounts: [100000, 500000, 2000000], need: null },
  nourriture: { label: 'Nourriture', icon: '🍚', amounts: [150000, 600000], need: 'nutrition', unit: 'semaines de repas' },
  vetements: { label: 'Vêtements', icon: '👕', amounts: [100000, 400000], need: 'vetements', unit: 'tenues' },
  fournitures: { label: 'Fournitures scolaires', icon: '✏️', amounts: [100000, 300000], need: 'fournitures', unit: 'kits' },
  informatique: { label: 'Matériel informatique', icon: '💻', amounts: [350000, 1750000], need: 'informatique', unit: 'ordinateurs' },
  mobilier: { label: 'Mobilier', icon: '🛏️', amounts: [200000, 800000], need: 'mobilier', unit: 'lits et meubles' },
  travaux: { label: 'Travaux d’aménagement', icon: '🧱', amounts: [500000, 2500000], need: 'batiment', unit: 'travaux' },
};
export const NEEDS = { nutrition: 'Nutrition', vetements: 'Vêtements', fournitures: 'Fournitures scolaires', informatique: 'Informatique', mobilier: 'Mobilier et literie', batiment: 'Bâtiment' };
const PROJ = [
  { id: 'dortoirs', name: 'Rénovation des dortoirs', goal: 3000000, type: 'travaux' }, { id: 'salle_info', name: 'Salle informatique complète (20 postes)', goal: 7000000, type: 'informatique' },
  { id: 'livres', name: 'Bibliothèque : 1 000 livres de plus', goal: 1500000, type: 'fournitures' }, { id: 'potager', name: 'Potager pédagogique', goal: 600000, type: 'travaux' }, { id: 'terrain', name: 'Terrain de sport rénové', goal: 2000000, type: 'travaux' },
];
const ACT = [ // [heure début, fin, lieu des enfants, libellé]
  [0, 6.5, 'dortoirs', 'Nuit — les enfants dorment'], [6.5, 7.5, 'sanitaires', 'Toilette et réveil'], [7.5, 8.2, 'repas', 'Petit-déjeuner'], [8.2, 12, 'etude', 'École et soutien scolaire'], [12, 13, 'repas', 'Déjeuner'],
  [13, 14.5, 'dortoirs', 'Temps calme'], [14.5, 17.5, 'cour', 'Jeux, sport et ateliers'], [17.5, 19, 'etude', 'Devoirs et lecture'], [19, 20, 'repas', 'Dîner'], [20, 21, 'detente', 'Veillée et contes'], [21, 24, 'dortoirs', 'Coucher'],
];

export class Orphanage {
  constructor(ctx) {
    Object.assign(this, ctx); // scene, world, player, ui, audio, env, economy, needs, tpc, home, solidarity, events, onSave
    this.inside = false; this.points = []; this.kids = []; this.staffC = []; this.history = []; this.fund = 0; this.projects = {}; this.visitBooked = null; this.lastWeek = null; this.wellbeing = 70;
    this.need = { nutrition: 60, vetements: 45, fournitures: 40, informatique: 25, mobilier: 55, batiment: 50 }; this.computers = 5;
    this.roster = this.makeRoster(); this.present = 38;
    this.buildOutside(); this.buildInside();
  }
  // ------------------------------------------------------------------ registre fictif des enfants (60 places)
  makeRoster() {
    const R = mulberry32(2026), out = [];
    for (let i = 0; i < CENTRE.CAP; i++) { const f = R() < 0.5, age = 3 + Math.floor(R() * 15); out.push({ id: `e${i + 1}`, first: (f ? F_N : M_N)[Math.floor(R() * 15)], female: f, age, trait: TRAIT[Math.floor(R() * TRAIT.length)].replace(/(\w+)·(\w+)/, (m, a, b) => (f ? (b === 've' ? a.replace(/f$/, 've') : b === 'se' ? a.replace(/x$/, 'se') : a + b) : a)), hobby: HOBBY[Math.floor(R() * HOBBY.length)], dream: pick(['devenir médecin', 'devenir enseignante', 'jouer au football en équipe nationale', 'devenir ingénieur', 'écrire des livres', 'devenir pilote', 'ouvrir un restaurant', 'devenir avocate', 'construire des maisons', 'devenir infirmier']), since: 2018 + Math.floor(R() * 8) }); }
    return out;
  }
  kidsPresent() { return this.roster.filter((k) => !(this.family && this.family.isChild(k.id))).slice(0, this.present); }
  // ------------------------------------------------------------------ extérieur : bâtiment existant, entrée, enseigne, fresque
  buildOutside() {
    const fp = CENTRE.FP, cx = (fp[0] + fp[2]) / 2, cz = (fp[1] + fp[3]) / 2, col = this.world.collision;
    const faces = [[cx, fp[3], 0, 1], [cx, fp[1], 0, -1], [fp[2], cz, 1, 0], [fp[0], cz, -1, 0]]; let best = null;
    for (const [fx, fz, nx, nz] of faces) { let sc = 0; for (const d of [1.4, 3, 5, 7]) if (!col.pointBlocked(fx + nx * d, 0.5, fz + nz * d)) sc++; if (!best || sc > best.sc) best = { fx, fz, nx, nz, sc }; }
    const ry = Math.atan2(best.nx, best.nz); this.out = { x: best.fx + best.nx * 1.6, z: best.fz + best.nz * 1.6, ry }; this.cx = cx; this.cz = cz;
    const g = new THREE.Group(); g.name = 'NOVA_SOLIDARITE'; this.scene.add(g);
    const wx = best.fx + best.nx * 0.12, wz = best.fz + best.nz * 0.12, lx = Math.cos(ry), lz = -Math.sin(ry);
    const sign = this.label('NOVA SOLIDARITÉ', 'Centre d’accueil pour enfants', 6, 1.2, '#0b6e4f'); sign.position.set(wx, 4.2, wz); sign.rotation.y = ry; g.add(sign);
    const mural = new THREE.Mesh(new THREE.PlaneGeometry(5.5, 1.6), new THREE.MeshBasicMaterial({ map: this.muralTex() })); mural.position.set(wx + lx * 0.1, 1.6, wz + lz * 0.1); mural.rotation.y = ry; g.add(mural);
    const door = new THREE.Mesh(new THREE.PlaneGeometry(1.8, 2.3), new THREE.MeshBasicMaterial({ color: 0xe46a1f })); door.position.set(wx + lx * -3.6 + best.nx * 0.02, 1.15, wz + lz * -3.6 + best.nz * 0.02); door.rotation.y = ry; g.add(door);
    this.doorPt = { x: wx + lx * -3.6 + best.nx * 1.6, z: wz + lz * -3.6 + best.nz * 1.6 };
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 6, 6), new THREE.MeshStandardMaterial({ color: 0xd8dde2 })); pole.position.set(wx + lx * 4 + best.nx * 2, 3, wz + lz * 4 + best.nz * 2); g.add(pole);
    const flag = this.label('NOVA', 'SOLIDARITÉ', 1.4, 0.8, '#e46a1f'); flag.position.set(pole.position.x + lx * 0.72, 5.4, pole.position.z + lz * 0.72); flag.rotation.y = ry; g.add(flag);
  }
  label(a, b, w, h, bg) { const c = document.createElement('canvas'); c.width = 512; c.height = Math.round(512 * h / w); const x = c.getContext('2d'); x.fillStyle = bg; x.fillRect(0, 0, c.width, c.height); x.fillStyle = '#fff'; x.textAlign = 'center'; x.font = `900 ${Math.round(c.height * 0.36)}px Arial`; x.fillText(a, c.width / 2, c.height * 0.48); x.font = `700 ${Math.round(c.height * 0.2)}px Arial`; x.fillText(b, c.width / 2, c.height * 0.82); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ map: t, toneMapped: false })); }
  muralTex() { const c = document.createElement('canvas'); c.width = 512; c.height = 150; const x = c.getContext('2d'); x.fillStyle = '#fcd116'; x.fillRect(0, 0, 512, 150); const cols = ['#0b6e4f', '#e8112d', '#1f4e9c', '#e46a1f', '#7a2a8a']; for (let i = 0; i < 9; i++) { const px = 30 + i * 55; x.fillStyle = cols[i % 5]; x.beginPath(); x.arc(px, 55, 16, 0, 7); x.fill(); x.fillRect(px - 14, 72, 28, 50); x.strokeStyle = cols[(i + 2) % 5]; x.lineWidth = 6; x.beginPath(); x.moveTo(px + 14, 85); x.lineTo(px + 41, 85); x.stroke(); } x.fillStyle = '#0b0c0e'; x.font = '900 18px Arial'; x.fillText('Ensemble, grandir en sécurité', 140, 145); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t; }
  // ------------------------------------------------------------------ intérieur (niveau isolé)
  buildInside() {
    const { LV, Y } = CENTRE, O = { x: this.cx, z: this.cz }; this.O = O;
    const g = new THREE.Group(); g.position.set(O.x, Y, O.z); g.visible = false; this.scene.add(g); this.inGroup = g;
    const parts = [], col = this.world.collision, H = 3.2, T = 0.18;
    const box = (x0, y0, z0, x1, y1, z1, c) => parts.push(colorize(new THREE.BoxGeometry(Math.abs(x1 - x0), Math.abs(y1 - y0), Math.abs(z1 - z0)).translate((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), c));
    const solid = (x0, z0, x1, z1, h = H) => { const o = col.addBox(O.x + Math.min(x0, x1), O.z + Math.min(z0, z1), O.x + Math.max(x0, x1), O.z + Math.max(z0, z1), Y + h); o.lv = LV; };
    const wallX = (z, x0, x1, gaps = []) => { let a = x0; for (const [g0, g1] of [...gaps, [x1, x1]]) { if (g0 > a) { box(a, 0, z - T / 2, g0, H, z + T / 2, 0xf6eedc); solid(a, z - T / 2, g0, z + T / 2); } a = g1; } };
    const wallZ = (x, z0, z1, gaps = []) => { let a = z0; for (const [g0, g1] of [...gaps, [z1, z1]]) { if (g0 > a) { box(x - T / 2, 0, a, x + T / 2, H, g0, 0xf6eedc); solid(x - T / 2, a, x + T / 2, g0); } a = g1; } };
    box(-31, -0.1, -23, 31, 0, 23, 0xe0d6c2);
    // cour : sable, pelouse, potager, terrain, jeux, arbres
    box(-22, 0, -14, 22, 0.02, 14, 0xd8c08a); box(-20, 0.02, -12, -4, 0.03, 12, 0x5aa04a); box(4, 0.02, -10, 20, 0.03, 4, 0x3f8a3a);
    for (const x of [4.2, 19.8]) { box(x - 0.05, 0, -4, x + 0.05, 1.2, -3.95, 0xffffff); box(x - 0.05, 0, -0.05, x + 0.05, 1.2, 0, 0xffffff); box(x - 0.05, 1.15, -4, x + 0.05, 1.2, 0, 0xffffff); }
    for (let k = 0; k < 4; k++) box(-19 + k * 3, 0.03, 8, -17.6 + k * 3, 0.25, 11, 0x6a4a22); for (let k = 0; k < 16; k++) box(-18.9 + (k % 4) * 3 + Math.floor(k / 4) * 0.3, 0.25, 8.3 + Math.floor(k / 4) * 0.7, -18.5 + (k % 4) * 3 + Math.floor(k / 4) * 0.3, 0.55, 8.6 + Math.floor(k / 4) * 0.7, 0x2f9a3a);
    box(-12, 0, 2, -11.8, 2.4, 2.2, 0xe8112d); box(-9, 0, 2, -8.8, 2.4, 2.2, 0xe8112d); box(-12, 2.4, 2, -8.8, 2.5, 2.2, 0xe8112d); box(-10.8, 0.6, 2.05, -10.2, 0.65, 2.15, 0x1f4e9c); // balançoire
    box(10, 0, 8, 11, 2, 9, 0xfcd116); box(11, 0, 8.3, 14, 0.1, 8.7, 0xfcd116); // toboggan
    for (const [x, z] of [[-14, -10], [16, 10], [0, 12]]) { box(x - 0.2, 0, z - 0.2, x + 0.2, 2.6, z + 0.2, 0x6a4a32); box(x - 1.4, 2.6, z - 1.4, x + 1.4, 3.6, z + 1.4, 0x2f7a3a); solid(x - 0.25, z - 0.25, x + 0.25, z + 0.25, 3); }
    // murs extérieurs, ailes
    wallX(22.5, -30.5, 30.5); wallX(-22.5, -30.5, 30.5); wallZ(-30.5, -22.5, 22.5); wallZ(30.5, -22.5, 22.5);
    const R = (id) => ROOMS.find((r) => r[0] === id), doorX = (r) => [(r[2] + r[4]) / 2 - 0.8, (r[2] + r[4]) / 2 + 0.8], doorZ = (r) => [(r[3] + r[5]) / 2 - 0.8, (r[3] + r[5]) / 2 + 0.8];
    wallX(14, -30.3, 30.3, ROOMS.filter((r) => r[3] === 14).map(doorX)); wallX(-14, -30.3, 30.3, ROOMS.filter((r) => r[5] === -14).map(doorX));
    wallZ(-22, -13.8, 13.8, ROOMS.filter((r) => r[4] === -22).map(doorZ)); wallZ(22, -13.8, 13.8, ROOMS.filter((r) => r[2] === 22).map(doorZ));
    for (const r of ROOMS) { if (r[3] === 14 || r[5] === -14) { if (r[2] > -30) wallZ(r[2], r[3] + 0.1, r[5] - 0.1); } else { if (r[3] > -14) wallX(r[3], r[2] + 0.1, r[4] - 0.1); } }
    this.rooms = {}; const P = (x, z, r, label, action) => this.points.push({ x, z, r, label, action });
    for (const [id, name, x0, z0, x1, z1, type] of ROOMS) {
      const cx = (x0 + x1) / 2, cz = (z0 + z1) / 2; this.rooms[id] = { id, name, type, x0, z0, x1, z1, cx, cz };
      const pl = this.label(name, '', 2.6, 0.4, '#0b6e4f'); const onN = z0 === 14, onS = z1 === -14, onW = x1 === -22; pl.position.set(onW ? -21.88 : x0 === 22 ? 21.88 : cx, 2.6, onN ? 13.88 : onS ? -13.88 : cz); pl.rotation.y = onN ? PI : onS ? 0 : onW ? PI / 2 : -PI / 2; g.add(pl);
      this.furnish(type, id, x0, z0, x1, z1, cx, cz, box, solid, P);
    }
    P(-28.6, 20.6, 1.6, 'Ressortir du centre', () => this.exit());
    const m = new THREE.Mesh(mergeGeometries(parts), new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.75 })); m.receiveShadow = true; g.add(m);
    this.spawnPeople();
  }
  furnish(type, id, x0, z0, x1, z1, cx, cz, box, solid, P) {
    const w = x1 - x0, d = z1 - z0;
    if (type === 'dortoir' || type === 'chambres') { const n = type === 'chambres' ? 4 : 6; for (let k = 0; k < n; k++) { const bx = x0 + 1 + k * ((w - 2) / n) + 0.4; box(bx - 0.45, 0, z0 + 0.4, bx + 0.45, 0.5, z0 + 2.2, 0x6a4a32); box(bx - 0.42, 0.5, z0 + 0.45, bx + 0.42, 0.62, z0 + 2.15, [0x2f80ed, 0xe8112d, 0xfcd116, 0x0b6e4f][k % 4]); if (type === 'dortoir') { box(bx - 0.45, 1.3, z0 + 0.4, bx + 0.45, 1.4, z0 + 2.2, 0x6a4a32); box(bx - 0.42, 1.4, z0 + 0.45, bx + 0.42, 1.5, z0 + 2.15, [0x7a2a8a, 0xe46a1f][k % 2]); } } P(cx, z1 - 1.5, 2, `${this.rooms[id].name} — ${type === 'dortoir' ? '12 lits superposés' : '4 chambres de 2'}`, () => this.ui.toast(`🛏️ ${this.rooms[id].name} : literie en état ${Math.round(this.need.mobilier)} %. ${this.need.mobilier < 50 ? 'Des lits neufs seraient utiles (dons › Mobilier).' : 'Lits propres et bien rangés.'}`, 3)); }
    else if (type === 'repas') { for (let k = 0; k < 4; k++) { box(x0 + 1, 0.7, z0 + 1.5 + k * 3.5, x1 - 1, 0.78, z0 + 2.7 + k * 3.5, 0x8a6a42); solid(x0 + 1, z0 + 1.5 + k * 3.5, x1 - 1, z0 + 2.7 + k * 3.5, 0.8); } P(x1 - 1.4, cz, 2, 'Salle à manger (60 places)', () => this.ui.toast(`🍽️ ${this.schedule().label}. Nutrition : ${Math.round(this.need.nutrition)} %.`, 3)); }
    else if (type === 'cuisine') { box(x0 + 0.3, 0, z0 + 0.3, x0 + 1.1, 0.92, z1 - 0.3, 0xd8dde2); box(cx - 0.4, 0, cz - 2, cx + 0.8, 0.92, cz + 2, 0x2a2d33); solid(x0 + 0.3, z0 + 0.3, x0 + 1.1, z1 - 0.3, 1); P(x1 - 1.4, cz, 2, 'Cuisine : menu de la semaine', () => this.ui.toast('🍲 Menu de la semaine : bouillie et akara le matin ; pâte, sauce et poisson à midi ; riz, haricots et légumes le soir ; fruits chaque jour.', 4)); }
    else if (type === 'biblio') { for (let k = 0; k < 5; k++) box(x0 + 0.5 + k * 2.3, 0, z1 - 0.7, x0 + 2.4 + k * 2.3, 2.2, z1 - 0.3, 0x6a4a32); for (let k = 0; k < 5; k++) for (let j = 0; j < 4; j++) box(x0 + 0.6 + k * 2.3, 0.3 + j * 0.5, z1 - 0.65, x0 + 2.3 + k * 2.3, 0.6 + j * 0.5, z1 - 0.35, [0xe8112d, 0x1f4e9c, 0xfcd116, 0x0b6e4f][(k + j) % 4]); P(cx, cz, 2.2, 'Bibliothèque', () => this.ui.toast(`📚 ${1200 + (this.projects.livres && this.projects.livres.done ? 1000 : 0)} livres, coin lecture pour les petits. ${this.visitOk() ? 'Vous pouvez lire une histoire aux enfants.' : ''}`, 3)); }
    else if (type === 'etude') { for (let r = 0; r < 2; r++) for (let k = 0; k < 4; k++) { const tx = x0 + 1.5 + k * 2.6, tz = z0 + 2 + r * 2.8; box(tx - 0.8, 0.7, tz - 0.4, tx + 0.8, 0.75, tz + 0.4, 0xd8c08a); } box(x0 + 2, 1, z1 - 0.15, x1 - 2, 2.2, z1 - 0.1, 0x1a3a2a); P(cx, cz, 2.2, 'Salle d’étude', () => this.ui.toast(`✏️ Soutien scolaire avec les enseignants. Fournitures : ${Math.round(this.need.fournitures)} %.`, 3)); }
    else if (type === 'info') { const n = Math.min(10, this.computers); for (let k = 0; k < 10; k++) { const tx = x0 + 1.2 + (k % 5) * 2.6, tz = z0 + 2 + Math.floor(k / 5) * 3; box(tx - 0.6, 0.72, tz - 0.35, tx + 0.6, 0.76, tz + 0.35, 0xd8dde2); } this.pcs = []; P(cx, cz, 2.2, 'Salle informatique', () => this.ui.toast(`💻 ${this.computers} ordinateur(s) pour ${this.present} enfants. Objectif : 20 postes (dons › Matériel informatique).`, 3.5)); }
    else if (type === 'infirmerie') { box(x0 + 0.5, 0, z0 + 0.5, x0 + 1.4, 0.7, z0 + 2.5, 0xf6f6f6); box(x1 - 1.4, 0, z1 - 1, x1 - 0.4, 1.8, z1 - 0.4, 0xd8dde2); P(cx, cz, 2, 'Infirmerie', () => this.ui.toast('🩺 Infirmerie : visites médicales régulières, vaccins à jour, trousse d’urgence. Les dossiers de santé restent confidentiels.', 3.5)); }
    else if (type === 'admin') { box(cx - 1.2, 0.72, cz - 0.6, cx + 1.2, 0.78, cz + 0.6, 0x6a4a32); box(x0 + 0.4, 0, z1 - 0.8, x0 + 3, 1.8, z1 - 0.3, 0x8a8f96); }
    else if (type === 'jeux') { box(cx - 1, 0, cz - 1.5, cx + 1, 0.5, cz + 1.5, 0x1f4e9c); box(x1 - 1, 0, z0 + 1, x1 - 0.3, 1.6, z1 - 1, 0xfcd116); P(cx - 1.5, cz, 2, 'Salle de jeux', () => this.ui.toast('🧸 Jeux de société, coin dessin, instruments de musique.', 2.5)); }
    else if (type === 'detente') { for (let k = 0; k < 3; k++) box(x0 + 0.5, 0, z0 + 1 + k * 4, x0 + 1.5, 0.5, z0 + 3 + k * 4, 0xe9dcc0); box(x1 - 0.3, 1, cz - 1, x1 - 0.2, 2, cz + 1, 0x111111); P(cx, cz, 2, 'Espace détente', () => this.ui.toast('🛋️ Coussins, contes du soir, télévision éducative.', 2.5)); }
    else if (type === 'sanitaires') { for (let k = 0; k < 3; k++) box(x0 + 0.4 + k * 1.8, 0, z0 + 0.4, x0 + 1.6 + k * 1.8, 2, z0 + 1.6, 0x9ab8c4); P(cx, z1 - 1.5, 1.8, `${this.rooms[id].name}`, () => this.ui.toast('🚿 Sanitaires adaptés aux enfants, entretenus chaque jour.', 2.5)); }
  }
  // ------------------------------------------------------------------ personnel et enfants
  spawnPeople() {
    STAFF.forEach(([id, name, role, female, room], i) => {
      const c = createCharacter({ female, skin: SKINS[i % SKINS.length], shirtColor: role.startsWith('Infirm') ? 0xf6f6f6 : role.startsWith('Cuis') ? 0xf6f6f6 : role.includes('protection') ? 0x0b6e4f : role === 'Directrice' ? 0x6a1a2a : 0x1f4e9c, pants: 0x2a2d33, skirt: false, headwrap: female && role.startsWith('Cuis'), hat: role.startsWith('Cuis') ? 'toque' : undefined });
      const r = room === 'cour' ? { cx: -6, cz: -2 } : this.rooms[room]; const x = r.cx + (i % 2 ? 1.2 : -1.2), z = r.cz + 0.6; c.group.position.set(x, 0, z); this.inGroup.add(c.group);
      this.staffC.push({ id, name, role, female, c, x, z, room });
    });
    // enfants visibles (16 au maximum ; le registre compte tous les enfants accueillis)
    for (let i = 0; i < 16; i++) { const k = this.roster[i], c = createCharacter({ female: k.female, skin: SKINS[(i + 2) % SKINS.length], shirtColor: [0xfcd116, 0x2f80ed, 0xe8112d, 0x0b6e4f, 0xe46a1f, 0x7a2a8a][i % 6], pants: 0x1f3a5a, skirt: k.female, headwrap: false, shorts: !k.female }); c.group.scale.setScalar(0.55 + Math.min(14, k.age) * 0.03); this.inGroup.add(c.group); this.kids.push({ k, c, x: 0, z: 0, tx: 0, tz: 0, t: Math.random() * 4 }); }
  }
  schedule() { const h = this.env.time; return ACT.map(([a, b, where, label]) => ({ a, b, where, label })).find((q) => h >= q.a && h < q.b) || { where: 'cour', label: 'Temps libre' }; }
  areaFor(where, i) {
    const rm = (id) => this.rooms[id], j = (r, s = 0.35) => [r.cx + (Math.random() - 0.5) * (r.x1 - r.x0) * s * 2, r.cz + (Math.random() - 0.5) * (r.z1 - r.z0) * s * 2];
    if (where === 'cour') return [(Math.random() - 0.5) * 36, (Math.random() - 0.5) * 22];
    if (where === 'dortoirs') return j(rm(['dort_p', 'dort_f', 'dort_g', 'grands'][i % 4]), 0.3);
    if (where === 'sanitaires') return j(rm(i % 2 ? 'san_f' : 'san_g'), 0.2);
    return j(rm(where), 0.3);
  }
  // ------------------------------------------------------------------ entrer / sortir
  enter() {
    const { Y, LV } = CENTRE, pl = this.player; this.inside = true; this.inGroup.visible = true; this.world.collision.level = LV; pl.floorY = Y; pl.vy = 0;
    pl.pos.set(this.O.x - 23.5, Y, this.O.z + 17.5); pl.facing = PI; pl.mesh.position.copy(pl.pos); if (this.tpc && this.tpc.snap) this.tpc.snap(pl.pos);
    this.lightRig(true); this.placeKids(true);
    this.ui.toast(`🏫 ${CENTRE.name} — ${this.present} enfants accueillis, ${CENTRE.CAP - this.present} places disponibles. ${this.schedule().label}.`, 3.5);
    if (this.audio && this.audio.ctx) this.audio.door();
  }
  exit(silent) { const pl = this.player; this.inside = false; this.inGroup.visible = false; this.world.collision.level = 0; pl.floorY = 0; pl.pos.set(this.doorPt.x, 0, this.doorPt.z); pl.mesh.position.copy(pl.pos); if (this.tpc && this.tpc.snap) this.tpc.snap(pl.pos); this.lightRig(false); if (!silent) this.ui.toast('Tu sors du centre NOVA SOLIDARITÉ.', 1.6); }
  lightRig(on) { const ls = this.home && this.home.lights; if (!ls) return; if (!this._orig) this._orig = ls.map((l) => ({ p: l.position.clone(), d: l.distance })); if (on) { this._lit = true; } else if (this._lit) { this._lit = false; ls.forEach((l, i) => { l.position.copy(this._orig[i].p); l.distance = this._orig[i].d; l.intensity = 0; }); } }
  roomAt(x, z) { return Object.values(this.rooms).find((R) => x >= R.x0 && x <= R.x1 && z >= R.z0 && z <= R.z1) || null; }
  doorPts(R) { return R.z0 === 14 ? [[R.cx, 14.7], [R.cx, 13.2]] : R.z1 === -14 ? [[R.cx, -14.7], [R.cx, -13.2]] : R.x1 === -22 ? [[-22.7, R.cz], [-21.2, R.cz]] : [[22.7, R.cz], [21.2, R.cz]]; }
  pathTo(K, x, z) { // par les portes, en passant par la cour (jamais à travers les murs)
    const A = this.roomAt(K.x, K.z), B = this.roomAt(x, z), pts = [];
    if (A && A === B) return [[x, z]];
    if (A) { const [inn, out] = this.doorPts(A); pts.push(inn, out); }
    if (B) { const [inn, out] = this.doorPts(B); pts.push(out, inn); }
    pts.push([x, z]); return pts;
  }
  placeKids(snap) { const S = this.schedule(); this.kids.forEach((K, i) => { const [x, z] = this.areaFor(S.where, i); if (snap) { K.x = x; K.z = z; K.path = []; } else K.path = this.pathTo(K, x, z); K.tx = x; K.tz = z; K.where = S.where; }); }
  // ------------------------------------------------------------------ interactions
  visitOk() { const day = this.economy.day; return day % 7 === 6 || this.visitBooked === day; }
  nearest(x, z) {
    if (!this.inside) { const d = Math.hypot(x - this.doorPt.x, z - this.doorPt.z); return d < 2.2 ? { d, it: { label: () => `Entrer : ${CENTRE.name}`, action: () => this.enter() } } : null; }
    const O = this.O; let best = null;
    for (const p of this.points) { const d = Math.hypot(x - (O.x + p.x), z - (O.z + p.z)); if (d < p.r && (!best || d < best.d)) best = { d, it: { label: () => p.label, action: p.action } }; }
    for (const s of this.staffC) { const d = Math.hypot(x - (O.x + s.x), z - (O.z + s.z)); if (d < 1.8 && (!best || d < best.d + 0.3)) best = { d, it: { label: () => `Parler à ${s.name} (${s.role.toLowerCase()})`, action: () => this.staffMenu(s) } }; }
    for (const K of this.kids) { if (!K.c.group.visible) continue; const d = Math.hypot(x - (O.x + K.x), z - (O.z + K.z)); if (d < 1.4 && (!best || d < best.d)) best = { d, it: { label: () => `Dire bonjour à ${K.k.first} (${K.k.age} ans)`, action: () => this.kidTalk(K) } }; }
    return best;
  }
  staffMenu(s) {
    const items = [{ label: '💬 Présentez-moi votre travail', action: () => this.ui.toast(`${s.name} : « ${this.staffLine(s)} »`, 4.5) }];
    if (s.id === 'dir') items.push({ label: '📋 Quels sont les besoins du centre ?', action: () => this.ui.toast(`${s.name} : « ${this.needsText()} »`, 5) }, { label: '📅 Organiser une visite', action: () => this.bookVisit() }, { label: '🎁 Faire un don (application)', action: () => this.openApp('dons') });
    if (this.family) items.push(...this.family.officerItems(s));
    if (s.id.startsWith('pro')) items.push({ label: '🛡️ Quelles sont les règles des visites ?', action: () => this.ui.toast(`${s.name} : « Les visites sont encadrées par un éducateur. On ne prend pas de photos des enfants sans accord, on n’échange pas de coordonnées, et on respecte leur rythme. L’intérêt de l’enfant passe avant tout. »`, 6) });
    this.ui.openMenu(`🏫 ${s.name}`, `${s.role} • ${CENTRE.name} (personnage fictif)`, items);
  }
  staffLine(s) { const r = s.role; return r === 'Directrice' ? `Nous accueillons ${this.present} enfants de 3 à 17 ans. Ils vont à l’école du quartier ou suivent le soutien scolaire ici. Notre priorité : leur sécurité, leur santé et leurs études.` : r.includes('protection') ? 'Je veille à ce que chaque enfant soit protégé et écouté. Je suis aussi chargé·e des démarches avec les services sociaux et les familles.'.replace('chargé·e', s.female ? 'chargée' : 'chargé') : r.startsWith('Édu') ? 'J’accompagne les enfants au quotidien : réveil, jeux, devoirs, repas, coucher. Ils ont besoin de repères et d’affection.' : r.startsWith('Ens') ? 'Je fais le soutien scolaire et la lecture. Les plus grands préparent le BEPC cette année !' : r.startsWith('Cuis') ? `Je prépare trois repas par jour pour ${this.present} enfants. Nutrition : ${Math.round(this.need.nutrition)} % de nos besoins couverts.` : r.startsWith('Infirm') ? 'Je suis la santé des enfants : vaccins, visites, petits bobos. Les dossiers médicaux sont confidentiels.' : 'Je garde le centre propre et sûr : dortoirs, sanitaires, cour.'; }
  needsText() { const low = Object.entries(this.need).sort((a, b) => a[1] - b[1]).slice(0, 3); return `Nos besoins les plus urgents : ${low.map(([k, v]) => `${NEEDS[k].toLowerCase()} (${Math.round(v)} %)`).join(', ')}. Chaque don est enregistré et nous vous en rendons compte.`; }
  kidTalk(K) {
    const k = K.k, s = this.schedule(), lines = k.age < 7 ? [`Bonjour ! Moi c’est ${k.first}. Tu veux voir mon dessin ?`, `Bonjour ! J’ai ${k.age} ans. On joue ?`] : k.age < 13 ? [`Bonjour monsieur ! Je m’appelle ${k.first}. J’aime ${k.hobby}.`, `Bonjour ! Plus tard, je veux ${k.dream}.`] : [`Bonjour monsieur. Je suis ${k.first}, je suis en ${LEVELS(k.age)}.`, `Bonjour. J’aime ${k.hobby}, et je veux ${k.dream}.`];
    const items = [{ label: '👋 Dire bonjour', action: () => this.ui.toast(`${k.first} : « ${pick(lines)} »`, 3.5) }, ...(this.family ? this.family.kidItems(K) : [])];
    if (this.visitOk()) {
      items.push({ label: '📖 Lire une histoire (avec l’éducatrice)', action: () => this.activity(K, 'Lecture d’une histoire', 'Les enfants écoutent l’histoire du lièvre et de l’hyène, puis applaudissent !') },
        { label: '✏️ Aider aux devoirs', action: () => this.activity(K, 'Aide aux devoirs', `${k.first} a terminé ses exercices et a tout compris.`) },
        { label: '⚽ Jouer au football dans la cour', action: () => this.activity(K, 'Match de football', 'Grand match dans la cour : tout le monde a couru et rigolé !') });
    } else items.push({ label: 'ℹ️ Activités avec les enfants', action: () => this.ui.toast('Les activités avec les enfants ont lieu pendant les journées de visite encadrées (chaque 7e jour, ou sur rendez-vous avec la directrice).', 4) });
    this.ui.openMenu(`🧒 ${k.first}, ${k.age} ans`, `${LEVELS(k.age)} • ${s.label} • échange encadré par l’équipe éducative`, items);
  }
  activity(K, label, msg) { if (this.actDay === this.economy.day && this.actCount >= 3) return this.ui.toast('Les enfants ont besoin de repos : revenez à la prochaine visite !', 3); this.actCount = this.actDay === this.economy.day ? (this.actCount || 0) + 1 : 1; this.actDay = this.economy.day; this.wellbeing = Math.min(100, this.wellbeing + 2); if (this.events) this.events.repAdd('generosite', 0.6); if (this.solidarity) this.solidarity.hum = Math.min(100, this.solidarity.hum + 0.5); this.env.time = (this.env.time + 0.75) % 24; this.ui.toast(`🌟 ${label} : ${msg}`, 4); this.onSave && this.onSave(); }
  bookVisit() { const d = this.economy.day + 1; this.visitBooked = d; this.ui.toast(`📅 Visite encadrée confirmée pour demain (J${d}), de 9 h à 18 h. Merci de votre engagement.`, 3.5); this.onSave && this.onSave(); }
  openApp(view) { if (this.solidarity) this.solidarity.view = view; this.economy.togglePhone(true); this.economy.app = 'soli'; this.economy.renderPhone(); }
  // ------------------------------------------------------------------ dons et projets
  donate(type, amount, project) {
    const D = DONS[type]; if (!D) return;
    if (!this.economy.pay(amount, `NOVA SOLIDARITÉ — ${D.label}${project ? ` (projet : ${project.name})` : ''}`, 'NOVA SOLIDARITÉ')) return this.ui.toast('Solde personnel insuffisant.', 2);
    let detail = '';
    if (type === 'financier') { this.fund += amount; detail = `fonds de fonctionnement : ${fcfa(this.fund)}`; }
    else if (type === 'informatique') { const n = Math.floor(amount / 350000); this.computers = Math.min(40, this.computers + n); this.need.informatique = Math.min(100, (this.computers / 20) * 100); detail = `${n} ordinateur(s) — ${this.computers} au total`; }
    else { const k = D.need, gain = Math.min(100 - this.need[k], amount / ({ nutrition: 9000, vetements: 7000, fournitures: 6000, mobilier: 12000, batiment: 30000 }[k])); this.need[k] = Math.min(100, this.need[k] + gain); detail = `${NEEDS[k]} : ${Math.round(this.need[k])} %`; }
    if (project) { const st = this.projects[project.id] || (this.projects[project.id] = { got: 0, done: false }); st.got += amount; if (st.got >= project.goal && !st.done) { st.done = true; detail += ` • projet réalisé : ${project.name}`; if (project.id === 'salle_info') this.computers = Math.max(this.computers, 20); this.economy.notify(`🎉 NOVA SOLIDARITÉ : projet « ${project.name} » réalisé. Les enfants vous remercient !`); } }
    this.history.unshift({ t: this.economy.stamp(), type, label: D.label, amount, detail }); this.history.length = Math.min(this.history.length, 120);
    this.wellbeing = Math.min(100, this.wellbeing + Math.min(6, amount / 300000)); if (this.events) this.events.repAdd('generosite', Math.min(4, amount / 500000)); if (this.solidarity) this.solidarity.hum = Math.min(100, this.solidarity.hum + Math.min(3, amount / 600000));
    this.ui.toast(`${D.icon} Don enregistré : ${D.label}, ${fcfa(amount)} (${detail}).`, 3); this.onSave && this.onSave();
  }
  // ------------------------------------------------------------------ boucle
  update(dt) {
    // semaine : consommation des stocks, fonds utilisé pour les besoins, arrivées et retours en famille
    const wk = Math.floor((this.economy.day || 1) / 7); if (this.lastWeek === null) this.lastWeek = wk;
    if (wk > this.lastWeek) { this.lastWeek = wk; for (const k of ['nutrition', 'vetements', 'fournitures']) this.need[k] = Math.max(0, this.need[k] - 12); this.need.mobilier = Math.max(0, this.need.mobilier - 3); this.need.batiment = Math.max(0, this.need.batiment - 2);
      if (this.fund > 0) { const spend = Math.min(this.fund, 600000); this.fund -= spend; this.need.nutrition = Math.min(100, this.need.nutrition + spend / 9000); this.history.unshift({ t: this.economy.stamp(), type: 'gestion', label: 'Fonds de fonctionnement utilisé (repas)', amount: -spend, detail: '' }); }
      if (this.present < 52 && this.need.batiment > 45 && Math.random() < 0.6) { this.present++; this.economy.notify(`🏫 NOVA SOLIDARITÉ : une nouvelle enfant de ${this.roster[this.present - 1].age} ans a été confiée au centre par les services sociaux (fictifs). Places disponibles : ${CENTRE.CAP - this.present}.`); }
      this.wellbeing = Math.max(20, Math.min(100, (Object.values(this.need).reduce((a, b) => a + b, 0) / 6) * 0.6 + this.wellbeing * 0.4)); this.onSave && this.onSave(); }
    if (!this.inside) return;
    const P = this.player.pos; if (Math.abs((P.y || CENTRE.Y) - CENTRE.Y) > 6 || Math.hypot(P.x - this.O.x, P.z - this.O.z) > 45) { this.inside = false; this.inGroup.visible = false; this.world.collision.level = 0; this.player.floorY = 0; this.lightRig(false); return; }
    const ls = this.home && this.home.lights; if (ls) ls.forEach((l, i) => { l.position.set(P.x - 6 + i * 6, CENTRE.Y + 3, P.z + (i === 1 ? 4 : -2)); l.distance = 18; l.decay = 1.1; l.intensity = 10 * Math.min(1, 0.4 + this.env.lightsOn); });
    const S = this.schedule(); if (S.where !== this._where) { this._where = S.where; this.placeKids(false); }
    this.kids.forEach((K, i) => {
      K.c.group.visible = i < Math.min(16, this.present) && !(this.family && this.family.awayFromCentre(K.k.id)); if (K.path && K.path.length) { const [px, pz] = K.path[0]; if (Math.hypot(px - K.x, pz - K.z) < 0.25) K.path.shift(); } const tgt = K.path && K.path.length ? K.path[0] : [K.tx, K.tz]; const dx = tgt[0] - K.x, dz = tgt[1] - K.z, d = Math.hypot(dx, dz) + (K.path && K.path.length > 1 ? 1 : 0); let sp = 0;
      if (d > 0.2) { const dd = Math.hypot(dx, dz) || 1; sp = Math.min(S.where === 'cour' ? 2.4 : 1.2, d); K.x += dx / dd * sp * dt; K.z += dz / dd * sp * dt; K.h = Math.atan2(dx, dz); }
      else if (S.where === 'cour') { K.t -= dt; if (K.t < 0) { K.t = 2 + Math.random() * 4; [K.tx, K.tz] = this.areaFor('cour', i); K.path = []; } }
      K.c.group.position.set(K.x, 0, K.z); K.c.group.rotation.y = K.h || 0;
      if (S.where === 'dortoirs' && d <= 0.2) { K.c.group.rotation.set(-PI / 2, 0, 0); K.c.group.position.y = 0.62; } else { K.c.group.rotation.x = 0; K.c.animate(dt, sp); }
    });
    for (const s of this.staffC) s.c.animate(dt, 0);
  }
  // ------------------------------------------------------------------ application (onglets ajoutés à « NOVA Solidarité »)
  render(view) {
    const S = this.schedule();
    if (view === 'centre') return `<div class="ph-row"><span><b>🏫 ${esc(CENTRE.name)}</b><small>Établissement fictif • Cotonou (quartier ouest, boulevard de la Marina) • directrice : Mme Théodora Hounsou</small></span></div>
      <div class="ph-list"><div class="ph-row"><span><b>Enfants accueillis</b></span><em>${this.present}</em></div><div class="ph-row"><span><b>Places disponibles</b></span><em>${CENTRE.CAP - this.present} / ${CENTRE.CAP}</em></div><div class="ph-row"><span><b>Bien-être des enfants</b></span><em>${Math.round(this.wellbeing)} %</em></div><div class="ph-row"><span><b>Personnel</b><small>${STAFF.map((s) => s[2]).filter((v, i, a) => a.indexOf(v) === i).join(' • ')}</small></span><em>${STAFF.length}</em></div></div>
      <h5>Planning du jour (en ce moment : ${esc(S.label)})</h5>${ACT.filter(([a]) => a >= 6.5 && a < 21).map(([a, b, , l]) => `<p class="ph-note">${Math.floor(a)} h${a % 1 ? Math.round((a % 1) * 60) : ''} – ${Math.floor(b)} h${b % 1 ? Math.round((b % 1) * 60) : ''} : ${esc(l)}</p>`).join('')}
      <h5>Enfants (registre fictif, prénoms seulement)</h5><p class="ph-note">${this.kidsPresent().slice(0, 30).map((k) => `${esc(k.first)} (${k.age} ans)`).join(', ')}${this.present > 30 ? '…' : ''}</p>`;
    if (view === 'dons') return `<p class="ph-note">Chaque don (monnaie virtuelle, compte personnel) est enregistré dans l’historique de NOVA SOLIDARITÉ.</p>${Object.entries(DONS).map(([k, D]) => `<div class="ph-row"><span><b>${D.icon} ${D.label}</b><small>${D.need ? `${NEEDS[D.need]} : ${Math.round(this.need[D.need])} %` : `Fonds de fonctionnement : ${fcfa(this.fund)}`}</small></span><span class="pp-acts">${D.amounts.map((a) => `<button class="ph-mini" data-so="odon:${k}|${a}">${fcfa(a)}</button>`).join('')}</span></div>`).join('')}
      <h5>Historique des dons</h5>${this.history.slice(0, 12).map((h) => `<p class="ph-note">${h.t} • ${esc(h.label)} • ${fcfa(Math.abs(h.amount))}${h.detail ? ` • ${esc(h.detail)}` : ''}</p>`).join('') || '<p class="ph-note">Aucun don pour le moment.</p>'}`;
    if (view === 'besoins') return `<div class="ev-rep">${Object.entries(NEEDS).map(([k, l]) => `<div><span>${l}</span><i><b style="width:${this.need[k]}%"></b></i><em>${Math.round(this.need[k])} %</em></div>`).join('')}</div><p class="ph-note">Ordinateurs : ${this.computers} / 20 visés.</p><h5>Projets du centre</h5>${PROJ.map((p) => { const st = this.projects[p.id] || { got: 0 }; return `<div class="ph-row"><span><b>${esc(p.name)}</b><small>${fcfa(st.got)} / ${fcfa(p.goal)}${st.done ? ' • ✅ réalisé' : ''}</small></span>${st.done ? '' : `<button class="ph-mini" data-so="oproj:${p.id}">Financer 500 000</button>`}</div>`; }).join('')}`;
    if (view === 'visites') return `<p class="ph-note">Journées de visite encadrées : chaque 7e jour de jeu (prochaine : J${this.economy.day + ((6 - this.economy.day % 7) + 7) % 7}), ou sur rendez-vous avec la directrice. Activités : lecture, aide aux devoirs, sport — toujours avec un éducateur.</p>${this.visitOk() ? '<p class="ph-note">✅ Aujourd’hui est une journée de visite.</p>' : ''}<button class="ph-go" data-so="ovisit:1">📅 Demander une visite pour demain</button><button class="ph-mini" data-so="olimo:1">🚘 M’y conduire (chauffeur)</button>`;
    return '';
  }
  onPhone(a, arg) {
    if (a === 'odon') { const [k, amt] = arg.split('|'); this.donate(k, +amt); }
    else if (a === 'oproj') { const p = PROJ.find((q) => q.id === arg); if (p) this.donate(p.type, 500000, p); }
    else if (a === 'ovisit') this.bookVisit();
    else if (a === 'olimo' && this.driver) { this.economy.togglePhone(false); this.driver.toDest({ id: 'orphelinat', label: 'NOVA SOLIDARITÉ (centre d’accueil)', x: this.doorPt.x, z: this.doorPt.z }); }
  }
  serialize() { return { present: this.present, need: this.need, computers: this.computers, fund: this.fund, history: this.history, projects: this.projects, visitBooked: this.visitBooked, lastWeek: this.lastWeek, wellbeing: this.wellbeing }; }
  restore(s) { if (!s) return; Object.assign(this, { present: Math.min(CENTRE.CAP, s.present || 38), need: { ...this.need, ...(s.need || {}) }, computers: s.computers || 5, fund: s.fund || 0, history: s.history || [], projects: s.projects || {}, visitBooked: s.visitBooked ?? null, lastWeek: s.lastWeek ?? null, wellbeing: s.wellbeing || 70 }); }
}
