// Mission 013, étape 2 / Mission 016, phase 2 — marché Dantokpa interactif : 60 étals tenus par des vendeurs fictifs (12 allées),
// stocks limités réapprovisionnés chaque matin, clients fidèles, répertoire dans le téléphone,
// prix en FCFA, négociation (offre / contre-offre / dernier prix), achats rangés dans le sac
// (aliments → réfrigérateur de la maison) ou dans « Mes articles » (objets non alimentaires).
import * as THREE from 'three';
import { FOOD_BY_ID, fcfa } from './food-data.js';
import { VENDORS, ARTICLE_BY_ID, TALK, SECTIONS, vendorSpots } from './market-data.js';

const OPEN_H = 6, CLOSE_H = 20, REACH = 3.3, TAG_DIST = 26;
const pick = (a) => a[Math.floor(Math.random() * a.length)];
const hash = (str) => { let h = 2166136261; for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };
const r25 = (n) => Math.max(25, Math.round(n / 25) * 25);

export class Market {
  constructor(ctx) {
    Object.assign(this, ctx); // scene, world, economy, kitchen, audio, ui, env, onSave
    this.open = false; this.v = null; this.sel = null; this.qty = 1; this.deals = {};
    this.spots = [];
    const spots = vendorSpots(this.world);
    this.stock = {}; this.stockDay = -1; this.loyal = {}; this.restock();
    VENDORS.forEach((v, i) => { if (spots[i]) this.spots.push({ v, x: spots[i].x, z: spots[i].z, ry: spots[i].ry }); });
    this.tags = new THREE.Group(); this.tags.visible = false; this.scene.add(this.tags);
    for (const s of this.spots) {
      const sp = this.makeTag(s.v); sp.position.set(s.x, 2.75, s.z); this.tags.add(sp); s.tag = sp;
    }
    this.callT = 3;
    this.dom = document.querySelector('#market');
    this.dom.addEventListener('click', (e) => this.onClick(e));
  }

  // stock de chaque étal : plats cuisinés limités, produits secs plus abondants, articles en petite quantité
  maxStock(id) { const f = FOOD_BY_ID[id]; if (!f) return 4; return f.kind === 'base' || f.kind === 'dish' || f.kind === 'sauce' || f.kind === 'protein' ? 10 : f.kind === 'ingredient' ? 16 : 12; }
  restock() { for (const v of VENDORS) for (const id of v.items) this.stock[`${v.id}:${id}`] = this.maxStock(id); }
  left(v, id) { return this.stock[`${v.id}:${id}`] ?? 0; }
  loyalty(v) { return Math.min(8, this.loyal[v.id] || 0); } // 1 % de remise par achat, jusqu'à 8 %
  serialize() { return { stock: { ...this.stock }, day: this.stockDay, loyal: { ...this.loyal } }; }
  restore(s) {
    if (!s) return;
    if (s.stock) for (const [k, v] of Object.entries(s.stock)) if (k in this.stock) this.stock[k] = Math.max(0, v | 0);
    this.stockDay = s.day ?? -1; this.loyal = { ...(s.loyal || {}) };
  }
  isOpenHour() { const h = this.env.time; return h >= OPEN_H && h < CLOSE_H; }

  makeTag(v) {
    const cv = document.createElement('canvas'); cv.width = 256; cv.height = 64; const c = cv.getContext('2d');
    c.fillStyle = 'rgba(12,16,20,0.78)'; c.beginPath(); c.roundRect(4, 4, 248, 56, 14); c.fill();
    c.fillStyle = v.color; c.fillRect(4, 4, 10, 56);
    c.fillStyle = '#fff'; c.font = 'bold 22px sans-serif'; c.textAlign = 'center'; c.fillText(v.name, 132, 29);
    c.fillStyle = '#f2c200'; c.font = 'bold 16px sans-serif'; c.fillText(v.spec, 132, 50);
    const tex = new THREE.CanvasTexture(cv); tex.colorSpace = THREE.SRGBColorSpace;
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, depthWrite: false, fog: false }));
    sp.scale.set(2.2, 0.55, 1); sp.renderOrder = 5; return sp;
  }

  // ---- interaction (même format que garage / aéroport) ----
  nearest(x, z) {
    let best = null;
    for (const s of this.spots) {
      const d = Math.hypot(x - s.x, z - s.z);
      if (d < REACH && (!best || d < best.d)) best = { d, s };
    }
    if (!best) return null;
    const s = best.s;
    return { d: best.d, it: { label: () => `Parler à ${s.v.name} (${s.v.spec})`, action: () => this.toggle(true, s.v) } };
  }

  update(dt, playerPos) {
    if (this.economy && this.economy.day !== this.stockDay) { if (this.stockDay !== -1) this.restock(); this.stockDay = this.economy.day; }
    const d = Math.hypot(playerPos.x + 50, playerPos.z - 50);
    this.tags.visible = d < 90;
    if (this.tags.visible) for (const s of this.spots) { const d2 = Math.hypot(playerPos.x - s.x, playerPos.z - s.z); s.tag.visible = d2 < TAG_DIST && d2 > 3.6; }
    // appels de vendeurs au loin (ambiance), de jour seulement
    const a = this.audio;
    if (a && a.ctx && d < 70 && this.isOpenHour() && !this.open) {
      this.callT -= dt;
      if (this.callT <= 0) {
        this.callT = 3 + Math.random() * 6;
        const g = (1 - d / 70) * 0.05, f = Math.random() < 0.7 ? 260 + Math.random() * 80 : 150 + Math.random() * 40;
        a.tone(f, 0.22, g, 'triangle', a.amb, 0, f * 1.18); a.tone(f * 1.12, 0.32, g, 'triangle', a.amb, 0.24, f * 0.82);
      }
    }
  }

  // petite « voix » stylisée quand le vendeur parle
  speak(v) {
    const a = this.audio; if (!a || !a.ctx) return;
    const base = v.female ? 250 : 140;
    for (let k = 0; k < 4; k++) { const f = base * (0.9 + Math.random() * 0.35); a.tone(f, 0.08, 0.05, 'triangle', a.sfx, k * 0.09, f * (0.85 + Math.random() * 0.3)); }
  }

  // ---- négociation ----
  itemInfo(id) {
    const f = FOOD_BY_ID[id];
    if (f) return { id, name: f.name, price: f.price, desc: f.desc, food: true };
    const a = ARTICLE_BY_ID[id];
    return a ? { id, name: a.name, price: a.price, desc: a.desc, icon: a.icon, food: false } : null;
  }
  deal(id) {
    const key = `${this.v.id}:${id}`;
    if (!this.deals[key]) {
      const it = this.itemInfo(id);
      const fid = 1 - this.loyalty(this.v) / 100;
      const h = hash(`${key}:${this.economy ? this.economy.day : 1}`); // prix stable dans la journée pour un étal donné
      const ask = r25(it.price * this.v.markup * (0.95 + (h % 1000) / 1000 * 0.12) * fid);
      const floor = Math.min(ask, r25(it.price * (0.82 + (Math.floor(h / 1000) % 1000) / 1000 * 0.12) * fid));
      this.deals[key] = { ask, start: ask, floor, offer: r25(ask * 0.8), patience: 3 + Math.floor(Math.random() * 2), agreed: null, last: false };
    }
    return this.deals[key];
  }
  propose() {
    const d = this.deal(this.sel), o = d.offer;
    if (d.agreed) return;
    if (o >= d.ask) { d.agreed = d.ask; this.say(pick(TALK.accept)); return; }
    if (d.last) { this.say(pick(TALK.last).replace('{p}', fcfa(d.ask))); return; }
    if (o < d.floor * 0.65) {
      d.patience -= 2; this.say(pick(TALK.offended));
    } else if (o >= d.floor && Math.random() < 0.35 + 0.65 * (o - d.floor) / Math.max(25, d.ask - d.floor)) {
      d.agreed = o; this.say(pick(TALK.accept));
    } else {
      d.patience--;
      d.ask = Math.max(d.floor, r25(o + (d.ask - o) * (0.45 + Math.random() * 0.25)));
      if (d.ask <= o) { d.agreed = o; this.say(pick(TALK.accept)); }
      else this.say(pick(TALK.counter).replace('{p}', fcfa(d.ask)));
    }
    if (!d.agreed && d.patience <= 0) { d.last = true; this.say(pick(TALK.last).replace('{p}', fcfa(d.ask))); }
    if (!d.agreed && d.offer >= d.ask) d.offer = d.ask;
  }
  say(txt) { this.line = txt; this.speak(this.v); }
  buy() {
    const d = this.deal(this.sel), it = this.itemInfo(this.sel), unit = d.agreed || d.ask, total = unit * this.qty;
    if (this.busy) return;
    const left = this.left(this.v, this.sel);
    if (left < this.qty) { this.say(left ? `Il ne m’en reste que ${left}.` : pick(TALK.empty)); return; }
    this.busy = true; setTimeout(() => { this.busy = false; }, 300); // anti double-clic
    if (!this.economy.pay(total, `${it.name} ×${this.qty}`, `Marché Dantokpa • ${this.v.name}`)) { this.say('Il te manque de l’argent, mon client…'); return; }
    if (it.food) this.economy.addToBag(it.id, this.qty); else this.economy.addItem(it.id, this.qty);
    this.stock[`${this.v.id}:${this.sel}`] = left - this.qty; if (this.peds) this.peds.vendorSale(VENDORS.indexOf(this.v)); this.loyal[this.v.id] = (this.loyal[this.v.id] || 0) + 1;
    delete this.deals[`${this.v.id}:${this.sel}`];
    this.say(pick(TALK.thanks));
    this.economy.notify(it.food ? `🧺 ${it.name} ×${this.qty} dans ton sac (à ranger au frigo)` : `🛍️ ${it.name} ×${this.qty} ajouté à « Mes articles »`);
    this.qty = 1; this.onSave && this.onSave();
  }

  // ---- interface ----
  toggle(on = !this.open, v = this.v) {
    if (on && !this.isOpenHour()) { this.ui.toast(`Le marché est fermé. Les étals ouvrent de ${OPEN_H} h à ${CLOSE_H} h.`, 2.5); return; }
    this.open = on; this.dom.classList.toggle('show', on);
    if (on) {
      this.v = v; this.sel = v.items.find((id) => this.left(v, id) > 0) || v.items[0]; this.qty = 1; this.line = pick(this.loyal[v.id] >= 3 ? TALK.loyal : TALK.hello); this.speak(v);
      if (this.kitchen && !this.kitchen.icons) this.kitchen.makeIcons();
      this.renderUI(); this._poll = setInterval(() => { if (this.open) this.renderUI(); else clearInterval(this._poll); }, 400);
    } else clearInterval(this._poll);
  }
  icon(id) {
    const it = this.itemInfo(id);
    if (!it.food) return `<span class="mk-emo">${it.icon}</span>`;
    const k = this.kitchen && this.kitchen.icons && this.kitchen.icons[id];
    return k ? `<img src="${k}" alt="">` : '<img alt="" style="visibility:hidden">';
  }
  renderUI() {
    const v = this.v, d = this.deal(this.sel), it = this.itemInfo(this.sel), unit = d.agreed || d.ask;
    const saved = d.start - unit, pct = Math.round(100 * saved / d.start);
    const html = `<div class="mk-box">
      <div class="mk-head"><span class="mk-av" style="background:${v.color}">${v.female ? '👩🏿' : '👨🏿'}</span>
        <div><h2>${v.name}</h2><small>${v.spec} • Allée ${SECTIONS.find((q) => q.id === v.sec).label} • Marché Dantokpa${this.loyalty(v) ? ` • client fidèle −${this.loyalty(v)} %` : ''}</small></div>
        <span class="mk-bal">💰 ${fcfa(this.economy.balance)}</span><button class="mk-x" data-mk="close">✕</button></div>
      <div class="mk-say">« ${this.line} »</div>
      <div class="mk-main">
        <div class="mk-grid">${v.items.map((id) => { const i = this.itemInfo(id), dd = this.deals[`${v.id}:${id}`]; const n = this.left(v, id); return `<button class="mk-card${id === this.sel ? ' sel' : ''}${n ? '' : ' dim'}" data-it="${id}">${this.icon(id)}<b>${i.name}</b><i>${n ? fcfa(dd ? dd.agreed || dd.ask : this.deal(id).ask) : 'Épuisé'}</i></button>`; }).join('')}</div>
        <div class="mk-detail">${this.icon(this.sel)}<h3>${it.name}</h3><p>${it.desc}</p>
          <p class="mk-price">${d.agreed ? `Prix conclu : <b>${fcfa(d.agreed)}</b>` : `Prix demandé : <b>${fcfa(d.ask)}</b>`}${saved > 0 ? ` <em>(−${pct} %)</em>` : ''}</p>
          ${d.agreed ? '' : `<div class="mk-offer"><span>Ton offre</span><button data-off="-50">−50</button><b>${fcfa(d.offer)}</b><button data-off="50">+50</button></div>
          <div class="mk-quick"><button data-pct="0.9">−10 %</button><button data-pct="0.8">−20 %</button><button data-pct="0.7">−30 %</button></div>
          <button class="mk-neg" data-mk="propose" ${d.last ? 'disabled' : ''}>${d.last ? 'DERNIER PRIX ATTEINT' : '🤝 PROPOSER CE PRIX'}</button>`}
          <div class="mk-offer"><span>Quantité</span><button data-q="-1">−</button><b>${this.qty}</b><button data-q="1">+</button></div>
          <p class="mk-note">Reste à l’étal : <b>${this.left(v, this.sel)}</b></p>
          <button class="mk-buy" data-mk="buy" ${this.economy.balance >= unit * this.qty && this.left(v, this.sel) >= this.qty ? '' : 'disabled'}>${this.left(v, this.sel) ? `ACHETER • ${fcfa(unit * this.qty)}` : 'ÉPUISÉ — RÉASSORT DEMAIN'}</button>
          <p class="mk-note">${it.food ? 'Les aliments vont dans ton sac : range-les au réfrigérateur de ta maison.' : 'Rangé dans « Mes articles » (téléphone, touche N).'}</p>
        </div></div></div>`;
    // ne pas reconstruire inutilement (le minuteur rafraîchit les icônes en cours de génération)
    if (html !== this._last) { const sc = this.dom.querySelector('.mk-grid'); const st = sc ? sc.scrollTop : 0; this.dom.innerHTML = html; this._last = html; const g = this.dom.querySelector('.mk-grid'); if (g) g.scrollTop = st; }
  }
  onClick(e) {
    const b = e.target.closest('[data-mk],[data-it],[data-off],[data-pct],[data-q]');
    if (!b) { if (e.target === this.dom) this.toggle(false); return; }
    e.stopPropagation();
    if (this.audio && this.audio.ctx) this.audio.click();
    const d = this.deal(this.sel);
    if (b.dataset.mk === 'close') return this.toggle(false);
    if (b.dataset.mk === 'propose') this.propose();
    else if (b.dataset.mk === 'buy') this.buy();
    else if (b.dataset.it) { this.sel = b.dataset.it; this.qty = 1; }
    else if (b.dataset.off) d.offer = Math.min(d.ask, r25(d.offer + (+b.dataset.off)));
    else if (b.dataset.pct) d.offer = r25(d.ask * +b.dataset.pct);
    else if (b.dataset.q) this.qty = Math.max(1, Math.min(20, Math.max(1, this.left(this.v, this.sel)), this.qty + (+b.dataset.q)));
    this.renderUI();
  }
  // ---- répertoire du marché (application du téléphone) ----
  renderApp(b) {
    const sec = this.appSec || SECTIONS[0].id, list = this.spots.filter((s) => s.v.sec === sec);
    b.innerHTML = `<h4>🏪 Marché Dantokpa</h4><p class="ph-note">${this.spots.length} étals • 12 allées • ouvert de ${OPEN_H} h à ${CLOSE_H} h${this.isOpenHour() ? ' (ouvert)' : ' (fermé)'}. Vendeurs fictifs.</p>
      <div class="ph-chips">${SECTIONS.map((q) => `<button data-mksec="${q.id}" class="${q.id === sec ? 'on' : ''}">${q.icon} ${q.label}</button>`).join('')}</div>
      <div class="ph-list">${list.map((s) => `<div class="ph-row"><span><b>${s.v.name}</b><small>${s.v.spec} • ${s.v.items.length} produits${this.loyal[s.v.id] ? ` • fidélité −${this.loyalty(s.v)} %` : ''}</small></span><button class="ph-mini" data-mkgo="${s.v.id}">Y aller</button></div>`).join('')}</div>`;
  }
  guide(vid) {
    const s = this.spots.find((q) => q.v.id === vid); if (!s || !this.ui.setRoute) return;
    this.ui.setRoute({ id: `stall_${vid}`, name: `${s.v.name} (${s.v.spec})`, x: s.x, z: s.z, cat: 'marche' });
  }
  handleKeys(input) { if (input.hit('Escape') || input.hit('KeyE')) this.toggle(false); }
}
