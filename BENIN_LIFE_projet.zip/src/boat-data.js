// Mission 012 — étape 4 : les 10 bateaux (noms fictifs inspirés de catégories de navires réels, dimensions
// approximatives en mètres). Vitesses en m/s (pilotage arcade). kind : cruise | liner | ferry | yacht | sport | fishing | speed | shuttle.
export const BOATS = [
  { id: 'symphonie', name: 'Symphonie des Mers', type: 'Grand navire de croisière', kind: 'cruise', len: 362, beam: 47, decks: 16, hull: 0xf2f2f2, accent: 0x1f4e9c, funnel: 0x1f4e9c, vMax: 11.5, acc: 0.25, turn: 0.05, pax: 6680, cabins: 2759, slides: true },
  { id: 'merveille', name: 'Merveille des Mers', type: 'Navire de croisière', kind: 'cruise', len: 362, beam: 47, decks: 16, hull: 0xf2f2f2, accent: 0x2aa0a0, funnel: 0x0b6e4f, vMax: 11.5, acc: 0.25, turn: 0.05, pax: 6988, cabins: 2867, slides: true },
  { id: 'euromonde', name: 'Euromonde', type: 'Navire de croisière', kind: 'cruise', len: 333, beam: 47, decks: 15, hull: 0xf2f2f2, accent: 0x1a1a1a, funnel: 0x1a2a4a, vMax: 11.8, acc: 0.26, turn: 0.055, pax: 6762, cabins: 2626 },
  { id: 'reinemarine', name: 'Reine Marine 2', type: 'Paquebot transatlantique', kind: 'liner', len: 345, beam: 41, decks: 13, hull: 0x14161a, accent: 0xc8102e, funnel: 0xc8302a, vMax: 15.5, acc: 0.3, turn: 0.055, pax: 2691, cabins: 1310 },
  { id: 'perle', name: 'Perle du Golfe', type: 'Yacht de luxe', kind: 'yacht', len: 80, beam: 13, decks: 4, hull: 0xf8f8f8, accent: 0x2a3440, funnel: null, vMax: 9.5, acc: 0.6, turn: 0.18, pax: 16, cabins: 8 },
  { id: 'fleche', name: 'Flèche d’Ouidah', type: 'Yacht sportif', kind: 'sport', len: 24, beam: 5.6, decks: 2, hull: 0x1a1a1a, accent: 0xc8102e, funnel: null, vMax: 19, acc: 2.2, turn: 0.55, pax: 10, cabins: 3 },
  { id: 'espoir', name: 'Espoir de la Lagune', type: 'Bateau de pêche', kind: 'fishing', len: 18, beam: 5.2, decks: 1, hull: 0x2f80ed, accent: 0xf2c200, funnel: null, vMax: 5.5, acc: 0.7, turn: 0.45, pax: 6, cabins: 0 },
  { id: 'eclair', name: 'Éclair', type: 'Vedette rapide', kind: 'speed', len: 10, beam: 2.8, decks: 1, hull: 0xf2f2f2, accent: 0xe46a1f, funnel: null, vMax: 24, acc: 3.5, turn: 0.9, pax: 6, cabins: 0 },
  { id: 'navette', name: 'Navette de la Lagune', type: 'Bateau de transport de passagers', kind: 'shuttle', len: 22, beam: 6, decks: 1, hull: 0xf2f2f2, accent: 0x0b6e4f, funnel: null, vMax: 8.5, acc: 0.9, turn: 0.4, pax: 60, cabins: 0 },
  { id: 'ferry', name: 'Ferry du Golfe', type: 'Ferry maritime (passagers et véhicules)', kind: 'ferry', len: 120, beam: 22, decks: 6, hull: 0xf2f2f2, accent: 0xf2c200, funnel: 0xf2c200, vMax: 10.5, acc: 0.4, turn: 0.12, pax: 900, cabins: 40 },
];
export const BOAT_BY_ID = Object.fromEntries(BOATS.map((b) => [b.id, b]));
