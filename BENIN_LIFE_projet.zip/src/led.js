// Mission 016, phase 5 — décoration LED de la maison et des entreprises : zones réglables (style, couleur RGB,
// intensité, extinction) depuis l'application « Décoration LED » du téléphone. Rubans discrets (fins, intégrés au
// plafond, aux meubles et aux murs), matériaux émissifs sans lumière dynamique ajoutée.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

export const LED_STYLES = { chaud: ['Blanc chaud', 0xffc27a], froid: ['Blanc froid', 0xdcefff], bleu: ['Bleu', 0x2f7fff], violet: ['Violet', 0x9a4aff], rgb: ['RGB personnalisé', null] };
export const RGB = [0xff3a3a, 0xff8a1a, 0xf2e02a, 0x3aff6a, 0x2ae0ff, 0x2f6aff, 0xb04aff, 0xff4ab0];
export const ZONES = {
  maison: [['tv', 'Salon — derrière la télévision'], ['murs', 'Salon — LED murales'], ['plafond', 'Plafonds — éclairage indirect'], ['chambre', 'Chambre — ambiance'], ['bureau', 'Bureau informatique'], ['cuisine', 'Cuisine']],
  entreprises: [['hall', 'NOVA BOOK — hall d’accueil'], ['couloirs', 'NOVA BOOK — couloirs'], ['reunion', 'Salles de réunion'], ['travail', 'Espaces de travail'], ['pdg', 'Bureau du PDG'], ['enseignes', 'Enseignes NOVA'], ['filiales', 'Sociétés du groupe']],
};
const DEFAULT = { tv: 'chaud', murs: 'chaud', plafond: 'chaud', chambre: 'violet', bureau: 'bleu', cuisine: 'froid', hall: 'froid', couloirs: 'froid', reunion: 'bleu', travail: 'froid', pdg: 'chaud', enseignes: 'bleu', filiales: 'froid' };

export class Leds {
  constructor({ homePlus, nova }) {
    this.homePlus = homePlus; this.nova = nova;
    this.cfg = {}; this.touched = {};
    for (const z of Object.keys(DEFAULT)) this.cfg[z] = { style: DEFAULT[z], rgb: 5, int: 0.8, on: true };
    this.mats = {};
    for (const z of Object.keys(DEFAULT)) this.mats[z] = new THREE.MeshBasicMaterial({ color: 0xffffff, toneMapped: false });
    // les rubans existants de la maison (mission 010) sont pilotés par la même interface
    const hm = homePlus && homePlus.home && homePlus.home.mats; if (hm) { if (hm.ledLiving) this.mats.tv = hm.ledLiving; if (hm.ledBed) this.mats.chambre = hm.ledBed; }
    this.zone = 'maison'; this.sel = 'tv';
    this.buildHome(); this.buildNova();
    for (const z of Object.keys(DEFAULT)) if (z !== 'tv' && z !== 'chambre') this.apply(z);
  }
  color(z) { const c = this.cfg[z], hex = c.style === 'rgb' ? RGB[c.rgb] : LED_STYLES[c.style][1]; return new THREE.Color(hex); }
  apply(z) {
    const c = this.cfg[z], m = this.mats[z]; if (!m) return;
    if (!c.on) { m.color.setRGB(0.07, 0.07, 0.08); return; }
    const col = this.color(z), k = 0.25 + c.int * 0.75; m.color.setRGB(col.r * k, col.g * k, col.b * k);
  }
  set(z, patch) { Object.assign(this.cfg[z], patch); this.touched[z] = true; this.apply(z); this.onSave && this.onSave(); }
  // ---- rubans : boîtes fines fusionnées par zone ----
  strips(list, parent) {
    const byZone = {};
    for (const [z, x0, y0, z0, x1, y1, z1] of list) (byZone[z] || (byZone[z] = [])).push(new THREE.BoxGeometry(Math.abs(x1 - x0) || 0.02, Math.abs(y1 - y0) || 0.02, Math.abs(z1 - z0) || 0.02).translate((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2));
    for (const [z, geos] of Object.entries(byZone)) { const m = new THREE.Mesh(mergeGeometries(geos), this.mats[z]); m.renderOrder = 2; parent.add(m); }
  }
  buildHome() {
    const scene = this.homePlus && this.homePlus.scene; if (!scene) return;
    const g = new THREE.Group(); scene.add(g); this.homeGroup = g;
    this.strips([
      // plafond du salon et de la cuisine : gorges lumineuses (éclairage indirect)
      ['plafond', -55.8, 2.9, 119.15, -46.3, 2.93, 119.2], ['plafond', -55.8, 2.9, 126.45, -50.3, 2.93, 126.5], ['plafond', -41.5, 2.9, 119.15, -36.5, 2.93, 119.2],
      // LED murales du salon (verticales, de part et d'autre du mur d'accent)
      ['murs', -55.87, 0.6, 120.55, -55.84, 2.1, 120.58], ['murs', -55.87, 0.6, 124.42, -55.84, 2.1, 124.45],
      // cuisine : ruban sous les placards hauts, au-dessus du plan de travail
      ['cuisine', -41.55, 1.48, 125.9, -36.45, 1.5, 125.94],
      // bureau informatique : sous le plateau et derrière l'écran
      ['bureau', -49.65, 0.75, 133.84, -47.35, 0.77, 133.87], ['bureau', -49.1, 1.48, 133.68, -47.9, 1.5, 133.7],
    ], g);
  }
  buildNova() {
    const N = this.nova; if (!N || !N.floors) return;
    const fh = 4.2;
    N.floors.forEach((f, lv) => {
      const y = lv * fh, L = [];
      L.push(['couloirs', 55, y + 3.95, 35.0, 68.5, y + 3.97, 35.06], ['couloirs', 42.3, y + 3.95, 33.15, 54.3, y + 3.97, 33.2]);
      if (lv >= 1 && lv <= 4) for (const zz of [19.5, 23.5, 27.5]) L.push(['travail', 56, y + 3.95, zz, 74.5, y + 3.97, zz + 0.06]);
      if (lv === 0) {
        L.push(['hall', 55.0, y + 3.42, 27.42, 63.0, y + 3.45, 27.44], ['hall', 55.0, y + 0.08, 27.42, 63.0, y + 0.11, 27.44], ['hall', 55.0, y + 0.08, 27.42, 55.03, y + 3.45, 27.44], ['hall', 62.97, y + 0.08, 27.42, 63.0, y + 3.45, 27.44]);
        L.push(['hall', 56.0, y + 0.1, 21.57, 62.0, y + 0.13, 21.6]);
        L.push(['reunion', 45.8, y + 3.0, 27.3, 50.8, y + 3.02, 27.33], ['reunion', 45.8, y + 3.0, 29.07, 50.8, y + 3.02, 29.1]);
        for (const zz of [19.5, 23.5]) L.push(['travail', 64, y + 3.95, zz, 75, y + 3.97, zz + 0.06]);
      }
      if (lv === 5) {
        L.push(['pdg', 60.5, y + 3.85, 16.55, 75.4, y + 3.87, 16.58], ['pdg', 60.5, y + 3.85, 32.7, 75.4, y + 3.87, 32.73], ['pdg', 75.37, y + 3.85, 16.6, 75.4, y + 3.87, 32.7], ['pdg', 66.4, y + 0.08, 22.88, 69.6, y + 0.1, 22.91]);
        L.push(['reunion', 47.4, y + 3.0, 23.6, 54.4, y + 3.02, 23.63], ['reunion', 47.4, y + 3.0, 25.37, 54.4, y + 3.02, 25.4]);
      }
      this.strips(L, f.group);
    });
  }
  // ---- application du téléphone ----
  renderApp(b) {
    const z = this.sel, c = this.cfg[z], list = ZONES[this.zone], sw = (hex) => `#${hex.toString(16).padStart(6, '0')}`;
    b.innerHTML = `<h4>💡 Décoration LED</h4><div class="ph-chips"><button data-pp="led:zone:maison" class="${this.zone === 'maison' ? 'on' : ''}">🏠 Maison</button><button data-pp="led:zone:entreprises" class="${this.zone === 'entreprises' ? 'on' : ''}">🏢 Entreprises</button></div>
      <div class="ph-chips">${list.map(([k, l]) => `<button data-pp="led:sel:${k}" class="${k === z ? 'on' : ''}"><i class="pp-dot" style="background:${this.cfg[k].on ? '#' + this.color(k).getHexString() : '#222'}"></i>${l}</button>`).join('')}</div>
      <h5>${list.find((q) => q[0] === z)[1]}</h5>
      <div class="ph-chips">${Object.entries(LED_STYLES).map(([k, [l, hx]]) => `<button data-pp="led:style:${k}" class="${c.style === k ? 'on' : ''}">${hx ? `<i class="pp-dot" style="background:${sw(hx)}"></i>` : '🌈 '}${l}</button>`).join('')}</div>
      ${c.style === 'rgb' ? `<div class="ph-chips">${RGB.map((hx, i) => `<button data-pp="led:rgb:${i}" class="${c.rgb === i ? 'on' : ''}"><i class="pp-dot" style="background:${sw(hx)}"></i></button>`).join('')}</div>` : ''}
      <div class="pp-acts"><button class="ph-mini" data-pp="led:int:-0.1">− Intensité</button><b class="pp-int">${Math.round(c.int * 100)} %</b><button class="ph-mini" data-pp="led:int:0.1">+ Intensité</button><button class="ph-mini" data-pp="led:on">${c.on ? 'Éteindre' : 'Allumer'}</button></div>
      <p class="ph-note">Réglages enregistrés. Les LED sont visibles sur place (maison, NOVA BOOK, sociétés du groupe).</p>`;
  }
  onApp(a, v) {
    if (a === 'zone') { this.zone = v; this.sel = ZONES[v][0][0]; return; }
    if (a === 'sel') { this.sel = v; return; }
    const z = this.sel, c = this.cfg[z];
    if (a === 'style') this.set(z, { style: v });
    if (a === 'rgb') this.set(z, { rgb: +v, style: 'rgb' });
    if (a === 'int') this.set(z, { int: Math.max(0.1, Math.min(1, Math.round((c.int + (+v)) * 10) / 10)), on: true });
    if (a === 'on') this.set(z, { on: !c.on });
  }
  serialize() { const out = {}; for (const z of Object.keys(this.touched)) out[z] = { ...this.cfg[z] }; return out; }
  restore(s) { if (!s) return; for (const [z, c] of Object.entries(s)) if (this.cfg[z]) { Object.assign(this.cfg[z], c); this.touched[z] = true; this.apply(z); } }
}
