// Mission 013, étape 1 — réfrigérateur, recettes, réchauffage, assiettes composées et modèles 3D des plats béninois.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { FOOD, FOOD_BY_ID, FOOD_CATS, RECIPES, GASTRO_CATS, fcfa } from './food-data.js';

const PI = Math.PI;
const col = (geo, hex, jitter = 0) => {
  const g = geo.index ? geo.toNonIndexed() : geo;
  const c = new THREE.Color(hex), n = g.attributes.position.count, a = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { const j = jitter ? 1 - jitter + Math.abs(Math.sin(i * 12.9898) * 43758.5453 % 1) * jitter * 2 : 1; a[i * 3] = c.r * j; a[i * 3 + 1] = c.g * j; a[i * 3 + 2] = c.b * j; }
  g.setAttribute('color', new THREE.BufferAttribute(a, 3));
  for (const k of Object.keys(g.attributes)) if (!['position', 'normal', 'color'].includes(k)) g.deleteAttribute(k);
  return g;
};
const MATS = {};
const mat = (k) => MATS[k] || (MATS[k] = k === 'glass' ? new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.05, metalness: 0.1, transparent: true, opacity: 0.7 })
  : k === 'shiny' ? new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.25, metalness: 0.05 }) : new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.7 }));

// pièces élémentaires (unités : mètres, échelle de table)
function partsFor(id, P, G) {
  const f = FOOD_BY_ID[id]; if (!f) return;
  const c = f.c, add = (g, hex = c, j = 0.08) => P.push(col(g, hex, j)), glass = (g, hex) => G.push(col(g, hex, 0));
  switch (f.m) {
    case 'pate': { add(new THREE.SphereGeometry(0.07, 16, 10, 0, PI * 2, 0, PI / 2).scale(1, 0.75, 1).translate(0, 0.012, 0), c, 0.05); if (f.extra === 'chicken') partsFor('poulet_grille', P, G); break; }
    case 'grain': {
      const g = new THREE.SphereGeometry(0.075, 18, 10, 0, PI * 2, 0, PI / 2).scale(1.1, 0.5, 1.1); const p = g.attributes.position;
      for (let i = 0; i < p.count; i++) p.setY(i, p.getY(i) + Math.sin(i * 7.1) * 0.003);
      add(g.translate(0, 0.012, 0), c, 0.12);
      if (f.speck) for (let k = 0; k < 14; k++) { const a = k * 2.4, r = 0.02 + (k % 5) * 0.012; add(new THREE.SphereGeometry(0.006, 5, 4).translate(Math.cos(a) * r, 0.03 - r * 0.25, Math.sin(a) * r), f.speck, 0.1); }
      if (f.sauce) add(new THREE.CylinderGeometry(0.05, 0.055, 0.008, 18).translate(0.01, 0.045, 0), f.sauce, 0.05);
      break; }
    case 'akassa': { add(new THREE.SphereGeometry(0.06, 14, 10).scale(1.2, 0.55, 0.85).translate(0, 0.035, 0), 0x6a9a3a, 0.15); add(new THREE.BoxGeometry(0.03, 0.03, 0.09).translate(0, 0.065, 0), 0x4a7a2a, 0.1); break; }
    case 'ablo': for (let k = 0; k < 4; k++) add(new THREE.CylinderGeometry(0.025, 0.028, 0.025, 12).translate(Math.cos(k * 1.57) * 0.035, 0.022, Math.sin(k * 1.57) * 0.035), c, 0.05); break;
    case 'alloco': for (let k = 0; k < 7; k++) add(new THREE.BoxGeometry(0.035, 0.012, 0.022).rotateY(k * 0.9).translate(Math.cos(k * 0.9) * 0.04, 0.018 + (k % 2) * 0.008, Math.sin(k * 0.9) * 0.04), c, 0.15); break;
    case 'sauce': {
      add(new THREE.CylinderGeometry(0.055, 0.04, 0.045, 18, 1, true).translate(0, 0.025, 0), 0xe8e2d4, 0);
      add(new THREE.CircleGeometry(0.052, 18).rotateX(-PI / 2).translate(0, 0.044, 0), c, 0.08);
      add(new THREE.CircleGeometry(0.04, 16).rotateX(PI / 2).translate(0, 0.003, 0), 0xe8e2d4, 0);
      break; }
    case 'wagashi': for (let k = 0; k < 3; k++) { add(new THREE.CylinderGeometry(0.028, 0.028, 0.02, 14).translate(-0.035 + k * 0.035, 0.014, 0.01 * k), c, 0.03); add(new THREE.CylinderGeometry(0.0285, 0.0285, 0.006, 14).translate(-0.035 + k * 0.035, 0.024, 0.01 * k), 0xc0301a, 0.05); } break;
    case 'fish': { add(new THREE.SphereGeometry(0.05, 14, 8).scale(1.9, 0.5, 0.6).translate(0, 0.022, 0), c, 0.18); add(new THREE.ConeGeometry(0.035, 0.05, 6).rotateZ(PI / 2).scale(1, 1, 0.3).translate(-0.11, 0.022, 0), c, 0.1); for (let k = 0; k < 4; k++) add(new THREE.BoxGeometry(0.004, 0.003, 0.04).translate(-0.04 + k * 0.025, 0.046, 0), 0x2a1a0a, 0); break; }
    case 'chicken': for (let k = 0; k < 2; k++) { const s = k ? 1 : -1; add(new THREE.SphereGeometry(0.032, 12, 8).scale(1.3, 0.8, 1).translate(s * 0.03, 0.03, s * 0.015), c, 0.15); add(new THREE.CylinderGeometry(0.007, 0.007, 0.05, 6).rotateZ(PI / 2).translate(s * 0.07, 0.025, s * 0.015), 0xf2e8d8, 0); } break;
    case 'bottle': { glass(new THREE.CylinderGeometry(0.03, 0.03, 0.16, 14).translate(0, 0.08, 0), 0xdde8ec); add(new THREE.CylinderGeometry(0.027, 0.027, 0.12, 14).translate(0, 0.064, 0), c, 0.02); glass(new THREE.CylinderGeometry(0.012, 0.028, 0.05, 12).translate(0, 0.185, 0), 0xdde8ec); add(new THREE.CylinderGeometry(0.013, 0.013, 0.015, 10).translate(0, 0.215, 0), 0xc8102e, 0); break; }
    case 'cup': { add(new THREE.CylinderGeometry(0.04, 0.032, 0.08, 16, 1, true).translate(0, 0.04, 0), 0xf8f8f8, 0); add(new THREE.CircleGeometry(0.038, 16).rotateX(-PI / 2).translate(0, 0.072, 0), c, 0.04); add(new THREE.CircleGeometry(0.032, 14).rotateX(PI / 2).translate(0, 0.001, 0), 0xf8f8f8, 0); break; }
    case 'mango': add(new THREE.SphereGeometry(0.045, 14, 10).scale(1.25, 0.9, 0.85).translate(0, 0.04, 0), c, 0.12); add(new THREE.SphereGeometry(0.02, 8, 6).translate(0.045, 0.06, 0), 0x6a9a2a, 0.1); break;
    case 'pineapple': { add(new THREE.CylinderGeometry(0.045, 0.05, 0.12, 12).translate(0, 0.06, 0), c, 0.3); for (let k = 0; k < 7; k++) add(new THREE.ConeGeometry(0.012, 0.09, 4).rotateZ((k - 3) * 0.25).rotateY(k * 0.9).translate(0, 0.16, 0), 0x3a7a2a, 0.1); break; }
    case 'banana': for (let k = 0; k < 4; k++) add(new THREE.TorusGeometry(0.06, 0.013, 6, 10, PI * 0.7).rotateX(PI / 2).rotateY(k * 0.25 - 0.4).translate(0, 0.015 + k * 0.012, 0), c, 0.08); break;
    case 'orange': for (let k = 0; k < 3; k++) add(new THREE.SphereGeometry(0.032, 12, 8).translate(-0.035 + k * 0.035, 0.032, (k % 2) * 0.03), c, 0.08); break;
    case 'papaya': add(new THREE.SphereGeometry(0.05, 14, 10).scale(1.6, 0.85, 0.85).translate(0, 0.042, 0), c, 0.12); add(new THREE.SphereGeometry(0.05, 14, 10).scale(1.6, 0.85, 0.85).translate(0, 0.042, 0).scale(0.98, 0.3, 0.98).translate(0, 0.055, 0), 0x6a9a2a, 0.2); break;
    case 'coco': add(new THREE.SphereGeometry(0.055, 12, 10).translate(0, 0.055, 0), c, 0.25); add(new THREE.CircleGeometry(0.02, 8).translate(0, 0.07, 0.054), 0x3a2a1a, 0); break;
    case 'sack': add(new THREE.BoxGeometry(0.11, 0.14, 0.07).translate(0, 0.07, 0), c, 0.1); add(new THREE.BoxGeometry(0.112, 0.04, 0.072).translate(0, 0.08, 0), 0x0b6e4f, 0); add(new THREE.ConeGeometry(0.03, 0.03, 4).translate(0, 0.155, 0), c, 0.1); break;
    case 'yam': for (let k = 0; k < 2; k++) add(new THREE.SphereGeometry(0.04, 10, 8).scale(3, 0.9, 0.9).rotateY(k * 0.5).translate(0, 0.035 + k * 0.05, 0), c, 0.25); break;
    case 'heap': for (let k = 0; k < 6; k++) add(new THREE.SphereGeometry(0.026, 10, 8).translate(Math.cos(k * 1.2) * (k < 5 ? 0.035 : 0), 0.024 + (k === 5 ? 0.035 : 0), Math.sin(k * 1.2) * (k < 5 ? 0.035 : 0)), c, 0.1); break;
    case 'chili': for (let k = 0; k < 8; k++) add(new THREE.ConeGeometry(0.008, 0.04, 6).rotateZ(PI / 2).rotateY(k * 0.8).translate(Math.cos(k) * 0.025, 0.01 + (k % 3) * 0.008, Math.sin(k) * 0.025), c, 0.1); break;
    case 'okra': for (let k = 0; k < 7; k++) add(new THREE.ConeGeometry(0.012, 0.075, 5).rotateZ(PI / 2).rotateY(k * 0.9).translate(Math.cos(k * 0.9) * 0.02, 0.014 + (k % 2) * 0.012, Math.sin(k * 0.9) * 0.02), c, 0.1); break;
    case 'leaves': for (let k = 0; k < 8; k++) add(new THREE.SphereGeometry(0.035, 8, 6).scale(1.4, 0.15, 0.7).rotateY(k * 0.8).translate(Math.cos(k) * 0.02, 0.01 + k * 0.006, Math.sin(k) * 0.02), c, 0.2); break;
    case 'oil': glass(new THREE.CylinderGeometry(0.035, 0.035, 0.17, 14).translate(0, 0.085, 0), 0xe8e0d0); add(new THREE.CylinderGeometry(0.032, 0.032, 0.13, 14).translate(0, 0.067, 0), c, 0.02); add(new THREE.CylinderGeometry(0.015, 0.015, 0.03, 10).translate(0, 0.185, 0), 0xf2c200, 0); break;
    case 'jar': glass(new THREE.CylinderGeometry(0.04, 0.04, 0.09, 14).translate(0, 0.045, 0), 0xe8e0d0); add(new THREE.CylinderGeometry(0.037, 0.037, 0.075, 14).translate(0, 0.04, 0), c, 0.05); add(new THREE.CylinderGeometry(0.042, 0.042, 0.02, 14).translate(0, 0.1, 0), 0xc8102e, 0); break;
    case 'carton': add(new THREE.BoxGeometry(0.07, 0.15, 0.07).translate(0, 0.075, 0), c, 0.03); add(new THREE.BoxGeometry(0.072, 0.05, 0.072).translate(0, 0.05, 0), 0xffffff, 0); add(new THREE.CylinderGeometry(0.008, 0.008, 0.015, 8).translate(0.02, 0.157, 0), 0xf2f2f2, 0); break;
    case 'can': add(new THREE.CylinderGeometry(0.03, 0.03, 0.11, 16).translate(0, 0.055, 0), c, 0.02); add(new THREE.CylinderGeometry(0.027, 0.03, 0.006, 16).translate(0, 0.113, 0), 0xc8ccd0, 0); add(new THREE.CylinderGeometry(0.0305, 0.0305, 0.03, 16).translate(0, 0.06, 0), 0xffffff, 0); break;
    case 'box': add(new THREE.BoxGeometry(0.12, 0.17, 0.04).translate(0, 0.085, 0), c, 0.03); add(new THREE.BoxGeometry(0.1, 0.06, 0.042).translate(0, 0.09, 0), 0xffffff, 0); break;
    case 'bar': add(new THREE.BoxGeometry(0.15, 0.012, 0.07).translate(0, 0.006, 0), c, 0.04); add(new THREE.BoxGeometry(0.08, 0.013, 0.071).translate(0.02, 0.006, 0), 0xc8102e, 0); break;
    case 'tin': add(new THREE.CylinderGeometry(0.04, 0.04, 0.035, 16).translate(0, 0.0175, 0), 0xc8ccd0, 0.02); add(new THREE.CylinderGeometry(0.0405, 0.0405, 0.022, 16).translate(0, 0.018, 0), c, 0.03); break;
    case 'bread': add(new THREE.CapsuleGeometry(0.028, 0.22, 4, 10).rotateZ(PI / 2).translate(0, 0.028, 0), c, 0.12); for (let k = 0; k < 4; k++) add(new THREE.BoxGeometry(0.03, 0.006, 0.012).rotateY(0.5).translate(-0.08 + k * 0.055, 0.054, 0), 0xf0d8a0, 0); break;
    case 'pasta': add(new THREE.SphereGeometry(0.07, 16, 10, 0, PI * 2, 0, PI / 2).scale(1, 0.45, 1).translate(0, 0.01, 0), c, 0.1); for (let k = 0; k < 10; k++) add(new THREE.TorusGeometry(0.03 + (k % 3) * 0.012, 0.0035, 4, 14).rotateX(PI / 2 + (k % 2) * 0.3).rotateY(k).translate(Math.cos(k) * 0.012, 0.03 + (k % 4) * 0.004, Math.sin(k) * 0.012), c, 0.06); add(new THREE.SphereGeometry(0.035, 12, 8, 0, PI * 2, 0, PI / 2).scale(1, 0.35, 1).translate(0, 0.04, 0), 0xc8301a, 0.1); break;
    case 'eggs': add(new THREE.BoxGeometry(0.13, 0.02, 0.09).translate(0, 0.01, 0), 0xb8a888, 0.05); for (let k = 0; k < 6; k++) add(new THREE.SphereGeometry(0.018, 10, 8).scale(1, 1.3, 1).translate(-0.04 + (k % 3) * 0.04, 0.035, k < 3 ? -0.02 : 0.02), c, 0.04); break;
  }
}

// modèle d'un aliment seul (icônes, frigo) ou d'une assiette composée (table)
export function buildFoodModel(ids, plate = false) {
  const P = [], G = [];
  const list = Array.isArray(ids) ? ids : [ids];
  if (plate) P.push(col(new THREE.CylinderGeometry(0.16, 0.12, 0.02, 24).translate(0, 0.01, 0), 0xf8f6f0, 0));
  list.forEach((id, i) => {
    const before = P.length; partsFor(id, P, G);
    if (plate && i > 0) { // sauce et garniture posées à côté de la base
      const a = i === 1 ? 0.7 : -0.9, m = new THREE.Matrix4().makeTranslation(Math.cos(a) * 0.075, 0.012, Math.sin(a) * 0.075).multiply(new THREE.Matrix4().makeScale(0.75, 0.75, 0.75));
      for (let k = before; k < P.length; k++) P[k].applyMatrix4(m);
    }
  });
  const g = new THREE.Group();
  if (P.length) { const m = new THREE.Mesh(mergeGeometries(P), mat('n')); m.castShadow = true; g.add(m); }
  if (G.length) g.add(new THREE.Mesh(mergeGeometries(G), mat('glass')));
  return g;
}

// =====================================================================
// Cuisine : réfrigérateur (stock), recettes, réchauffage, service à table
// =====================================================================
const STOVE = { x: -38.2, y: 0.92, z: 125.35 }, TABLE = { x: -39.6, y: 0.8, z: 120.95 };
export const FRIDGE_CAPACITY = 80;

export class Kitchen {
  constructor(ctx) {
    Object.assign(this, ctx); // scene, renderer, home, ui, economy, needs, audio, onSave
    // stock de départ (le joueur commence avec de quoi manger quelques jours)
    this.stock = { pate_rouge: 2, sauce_arachide: 1, akassa: 2, sauce_tomate: 2, amiwo: 1, atassi: 2, bissap: 3, eau: 4, mangue: 2, banane: 2, wagashi: 1, poisson_grille: 1, tomate: 2, oignon: 2, farine_mais: 1, riz: 1, piment: 1 };
    this.pending = null;  // { kind: 'reheat'|'recipe', items | recipe } — en attente à la cuisinière
    this.served = null;   // { items: [...] } — sur la table
    this.open = false; this.onlyStock = true; this.cat = 'plats'; this.sel = 'pate_rouge'; this.compose = null;
    this.plate = new THREE.Group(); this.plate.position.set(TABLE.x, TABLE.y, TABLE.z); this.plate.visible = false; this.scene.add(this.plate);
    this.pot = new THREE.Group(); this.pot.position.set(STOVE.x, STOVE.y, STOVE.z); this.pot.visible = false; this.scene.add(this.pot);
    const potMesh = new THREE.Mesh(col(new THREE.CylinderGeometry(0.14, 0.12, 0.14, 18, 1, true).translate(0, 0.07, 0), 0x3a3c40, 0), new THREE.MeshStandardMaterial({ vertexColors: true, metalness: 0.7, roughness: 0.35, side: THREE.DoubleSide }));
    this.pot.add(potMesh); this.potFill = null;
    this.icons = null;
    this.buildDom();
  }
  count() { return Object.values(this.stock).reduce((a, b) => a + b, 0); }
  add(id, n = 1) { this.stock[id] = (this.stock[id] || 0) + n; }
  take(id, n = 1) { if ((this.stock[id] || 0) < n) return false; this.stock[id] -= n; if (!this.stock[id]) delete this.stock[id]; return true; }

  // ---- interactions de la maison ----
  stoveLabel() {
    if (this.pending) return this.pending.kind === 'recipe' ? `Cuisiner : ${FOOD_BY_ID[this.pending.recipe.out].name}` : `Réchauffer : ${this.plateName(this.pending.items)}`;
    return 'Cuisinière (prépare d’abord quelque chose au réfrigérateur)';
  }
  tableLabel() { return this.served ? `S’asseoir et manger : ${this.plateName(this.served.items)}` : 'Table à manger (rien n’est servi)'; }
  plateName(items) { return items.map((i) => FOOD_BY_ID[i].name).join(' + '); }
  useStove() {
    const p = this.pending;
    if (!p) { this.ui.toast('Ouvre le réfrigérateur pour choisir un plat à réchauffer ou une recette', 2.5); return; }
    const time = p.kind === 'recipe' ? p.recipe.time : 3 + p.items.length;
    this.showPot(p.kind === 'recipe' ? [p.recipe.out] : p.items);
    this.home.startActivity('cook', time, { food: { name: p.kind === 'recipe' ? FOOD_BY_ID[p.recipe.out].name : this.plateName(p.items) }, onDone: () => this.stoveDone() });
  }
  stoveDone() {
    const p = this.pending; this.pending = null; this.pot.visible = false;
    if (!p) return;
    if (p.kind === 'recipe') {
      this.add(p.recipe.out, p.recipe.n);
      this.ui.toast(`${FOOD_BY_ID[p.recipe.out].name} prêt : ${p.recipe.n} portions rangées au réfrigérateur`, 3);
      this.notify(`🍲 Recette réussie : ${FOOD_BY_ID[p.recipe.out].name} ×${p.recipe.n}`);
    } else this.serve(p.items, 'Le plat chaud est servi sur la table : assieds-toi pour manger (E)');
    this.onSave && this.onSave();
  }
  serve(items, msg) {
    this.served = { items };
    this.plate.clear(); this.plate.add(buildFoodModel(items, true)); this.plate.visible = true;
    if (msg) this.ui.toast(msg, 3);
  }
  showPot(items) {
    if (this.potFill) this.pot.remove(this.potFill);
    const f = FOOD_BY_ID[items[0]];
    this.potFill = new THREE.Mesh(col(new THREE.CircleGeometry(0.125, 18).rotateX(-PI / 2).translate(0, 0.11, 0), f ? f.c : 0xc85a2a, 0.1), mat('n'));
    this.pot.add(this.potFill); this.pot.visible = true;
  }
  eat() {
    if (!this.served) { this.ui.toast('Rien n’est servi : prépare d’abord un plat au réfrigérateur', 2); return; }
    const items = this.served.items, hunger = items.reduce((a, i) => a + (FOOD_BY_ID[i].hunger || 0), 0);
    this.home.startActivity('eat', 4 + items.length, { food: { name: this.plateName(items), hunger }, onDone: () => {
      this.served = null; this.plate.visible = false;
      this.needs.hunger = Math.min(100, this.needs.hunger + hunger);
      this.ui.toast(`Délicieux ! Faim +${hunger}`, 2.5);
      this.onSave && this.onSave();
    } });
  }
  // aliment consommé tout de suite (boisson, fruit)
  quick(id) {
    const f = FOOD_BY_ID[id]; if (!this.take(id)) return;
    this.toggle(false);
    this.home.startActivity('drink', f.kind === 'drink' ? 2.5 : 3.5, { food: { name: f.name, hunger: f.hunger }, onDone: () => { this.needs.hunger = Math.min(100, this.needs.hunger + f.hunger); this.ui.toast(f.kind === 'drink' ? `Rafraîchissant ! Faim +${f.hunger}` : `Miam ! Faim +${f.hunger}`, 2); this.onSave && this.onSave(); } });
  }
  // composer une assiette : base / plat (+ sauce) (+ garniture) → réchauffer, ou servir froid si tout est froid
  prepare(items) {
    for (const i of items) if (!this.take(i)) { this.ui.toast('Il manque un aliment dans le réfrigérateur', 2); return; }
    this.toggle(false);
    if (items.some((i) => FOOD_BY_ID[i].hot)) { this.pending = { kind: 'reheat', items }; this.ui.toast(`${this.plateName(items)} : va à la cuisinière pour réchauffer (E)`, 3.5); }
    else this.serve(items, 'Assiette servie sur la table : assieds-toi pour manger (E)');
    this.onSave && this.onSave();
  }
  startRecipe(r) {
    for (const [k, n] of Object.entries(r.need)) if ((this.stock[k] || 0) < n) { this.ui.toast('Ingrédients insuffisants', 2); return; }
    if (this.pending) { this.ui.toast('La cuisinière est déjà occupée : termine d’abord la préparation en cours', 2.5); return; }
    for (const [k, n] of Object.entries(r.need)) this.take(k, n);
    this.pending = { kind: 'recipe', recipe: r };
    this.toggle(false);
    this.ui.toast(`Ingrédients sortis : va à la cuisinière pour préparer ${FOOD_BY_ID[r.out].name} (E)`, 3.5);
    this.onSave && this.onSave();
  }
  storeBag() {
    const bag = this.economy.bag, room = FRIDGE_CAPACITY - this.count();
    let moved = 0;
    for (const [id, n] of Object.entries(bag)) { if (!FOOD_BY_ID[id]) continue; const k = Math.min(n, room - moved); if (k <= 0) break; this.add(id, k); bag[id] -= k; if (!bag[id]) delete bag[id]; moved += k; }
    if (moved) this.notify(`🧺 ${moved} article${moved > 1 ? 's' : ''} rangé${moved > 1 ? 's' : ''} au réfrigérateur`);
    else this.ui.toast(room <= 0 ? 'Le réfrigérateur est plein' : 'Ton sac de courses est vide', 2);
    this.renderUI(); this.onSave && this.onSave();
  }
  notify(msg) { this.economy ? this.economy.notify(msg) : this.ui.toast(msg, 2.5); }

  // ---- interface du réfrigérateur ----
  buildDom() {
    const r = document.querySelector('#fridge'); this.dom = r;
    r.innerHTML = `<div class="fr-box"><div class="fr-head"><h2>RÉFRIGÉRATEUR</h2><span class="fr-cap"></span><button class="fr-bag"></button><button class="fr-x">✕</button></div>
      <div class="fr-tabs">${FOOD_CATS.map((c) => `<button data-fc="${c.id}">${c.label}</button>`).join('')}<button data-fc="recettes">🍲 Recettes</button><button class="fr-only" data-fonly>Tout afficher</button></div>
      <div class="fr-main"><div class="fr-grid"></div><div class="fr-detail"></div></div></div>`;
    r.querySelector('.fr-x').addEventListener('click', (e) => { e.stopPropagation(); this.toggle(false); });
    r.querySelector('.fr-bag').addEventListener('click', (e) => { e.stopPropagation(); this.storeBag(); });
    r.querySelectorAll('[data-fc]').forEach((b) => b.addEventListener('click', (e) => { e.stopPropagation(); this.cat = b.dataset.fc; this.compose = null; this.sel = null; this.renderUI(); }));
    r.querySelector('[data-fonly]').addEventListener('click', (e) => { e.stopPropagation(); this.onlyStock = !this.onlyStock; this.renderUI(); });
    r.querySelector('.fr-grid').addEventListener('click', (e) => { const c = e.target.closest('[data-id]'); if (!c) return; e.stopPropagation(); this.sel = c.dataset.id; this.compose = null; this.renderUI(); });
    r.querySelector('.fr-detail').addEventListener('click', (e) => {
      const b = e.target.closest('[data-act]'); if (!b) return; e.stopPropagation();
      const a = b.dataset.act, v = b.dataset.v;
      if (a === 'quick') this.quick(this.sel);
      if (a === 'compose') { this.compose = { base: this.sel, sauce: null, prot: null }; this.renderUI(); }
      if (a === 'sauce') { this.compose.sauce = this.compose.sauce === v ? null : v; this.renderUI(); }
      if (a === 'prot') { this.compose.prot = this.compose.prot === v ? null : v; this.renderUI(); }
      if (a === 'serve') { const c = this.compose; this.prepare([c.base, c.sauce, c.prot].filter(Boolean)); }
      if (a === 'recipe') this.startRecipe(RECIPES.find((x) => x.id === v));
    });
  }
  toggle(on = !this.open) {
    this.open = on; this.dom.classList.toggle('show', on);
    if (on) { this.makeIcons(); this.renderUI(); }
  }
  // icônes rendues progressivement (quelques-unes par image) pour ne jamais bloquer l'écran
  makeIcons() {
    if (this.icons) return;
    this.icons = {};
    const size = 96, sc = new THREE.Scene();
    sc.add(new THREE.HemisphereLight(0xffffff, 0x6a5040, 1.7)); const d = new THREE.DirectionalLight(0xffffff, 2.2); d.position.set(1, 3, 2); sc.add(d);
    const lut = new Uint8ClampedArray(256); for (let i = 0; i < 256; i++) { const v = i / 255; lut[i] = Math.round(255 * (v <= 0.0031308 ? v * 12.92 : 1.055 * Math.pow(v, 1 / 2.4) - 0.055)); }
    const cv = document.createElement('canvas'); cv.width = cv.height = size;
    const st = { sc, cam: new THREE.PerspectiveCamera(30, 1, 0.01, 5), rt: new THREE.WebGLRenderTarget(size, size), px: new Uint8Array(size * size * 4), lut, cv, cx: cv.getContext('2d'), size };
    st.img = st.cx.createImageData(size, size);
    const queue = FOOD.map((f) => f.id);
    const step = () => {
      const r = this.renderer, prevRT = r.getRenderTarget(), pc = r.getClearColor(new THREE.Color()), pa = r.getClearAlpha();
      sc.environment = this.scene.environment;
      for (let k = 0; k < 3 && queue.length; k++) { const id = queue.shift(); this.icons[id] = this.renderIcon(st, id); }
      r.setRenderTarget(prevRT); r.setClearColor(pc, pa);
      if (this.open) this.renderUI();
      if (queue.length) setTimeout(step, 16); else st.rt.dispose();
    };
    this._iconQueue = queue; this._st = st;
    step();
  }
  renderIcon(st, id) {
    const f = FOOD_BY_ID[id], r = this.renderer, { sc, cam, rt, px, lut, img, cx, size } = st;
    const m = buildFoodModel(f.id, ['base', 'dish', 'sauce', 'protein'].includes(f.kind) && f.m !== 'sauce' && f.m !== 'cup' && f.m !== 'tin');
    const box = new THREE.Box3().setFromObject(m), c = box.getCenter(new THREE.Vector3()), sz = box.getSize(new THREE.Vector3());
    m.position.sub(c); const g = new THREE.Group(); g.add(m); g.rotation.set(0.75, -0.5, 0); sc.add(g);
    const R = Math.max(sz.x, sz.y, sz.z) * 0.65 + 0.005, dist = R / Math.tan(15 * PI / 180);
    cam.position.set(0, 0, dist); cam.near = dist * 0.2; cam.far = dist * 3; cam.updateProjectionMatrix();
    r.setRenderTarget(rt); r.setClearColor(0, 0); r.clear(); r.render(sc, cam); r.readRenderTargetPixels(rt, 0, 0, size, size, px);
    sc.remove(g);
    for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) { const s = ((size - 1 - y) * size + x) * 4, o = (y * size + x) * 4, a = px[s + 3], un = a ? 255 / a : 0; img.data[o] = lut[Math.min(255, (px[s] * un) | 0)]; img.data[o + 1] = lut[Math.min(255, (px[s + 1] * un) | 0)]; img.data[o + 2] = lut[Math.min(255, (px[s + 2] * un) | 0)]; img.data[o + 3] = a; }
    cx.putImageData(img, 0, 0);
    return st.cv.toDataURL('image/png');
  }
  renderUI() {
    const r = this.dom, bagN = Object.values(this.economy.bag).reduce((a, b) => a + b, 0);
    r.querySelector('.fr-cap').textContent = `Contenu : ${this.count()} / ${FRIDGE_CAPACITY}`;
    const bagB = r.querySelector('.fr-bag'); bagB.textContent = `🧺 Ranger mes courses (${bagN})`; bagB.disabled = !bagN;
    r.querySelectorAll('[data-fc]').forEach((b) => b.classList.toggle('on', b.dataset.fc === this.cat));
    const grid = r.querySelector('.fr-grid'), det = r.querySelector('.fr-detail');
    const ic = (id) => (this.icons[id] ? `<img src="${this.icons[id]}" alt="">` : '<img alt="" style="visibility:hidden">');
    if (this.cat === 'recettes') {
      grid.innerHTML = RECIPES.map((rc) => { const ok = Object.entries(rc.need).every(([k, n]) => (this.stock[k] || 0) >= n); return `<button class="fr-card${rc.id === this.sel ? ' sel' : ''}${ok ? '' : ' dim'}" data-id="${rc.id}">${ic(rc.out)}<b>${FOOD_BY_ID[rc.out].name}</b><i>×${rc.n}</i></button>`; }).join('');
      const rc = RECIPES.find((x) => x.id === this.sel) || RECIPES[0]; this.sel = rc.id;
      const ok = Object.entries(rc.need).every(([k, n]) => (this.stock[k] || 0) >= n);
      det.innerHTML = `${ic(rc.out)}<h3>${FOOD_BY_ID[rc.out].name}</h3><p>${FOOD_BY_ID[rc.out].desc}</p>
        <div class="fr-need">${Object.entries(rc.need).map(([k, n]) => `<span class="${(this.stock[k] || 0) >= n ? 'ok' : 'ko'}">${(this.stock[k] || 0) >= n ? '✔' : '✘'} ${FOOD_BY_ID[k].name} (${this.stock[k] || 0}/${n})</span>`).join('')}</div>
        <p class="fr-meta">Cuisson ${rc.time} s à la cuisinière • donne ${rc.n} portion${rc.n > 1 ? 's' : ''}</p>
        <button class="fr-go" data-act="recipe" data-v="${rc.id}" ${ok && !this.pending ? '' : 'disabled'}>${this.pending ? 'CUISINIÈRE OCCUPÉE' : ok ? 'SORTIR LES INGRÉDIENTS' : 'INGRÉDIENTS MANQUANTS'}</button>`;
      return;
    }
    const kinds = FOOD_CATS.find((c) => c.id === this.cat).kinds;
    const list = FOOD.filter((f) => kinds.includes(f.kind));
    const have = list.filter((f) => this.stock[f.id] > 0), none = this.onlyStock ? [] : list.filter((f) => !this.stock[f.id]);
    const ob = r.querySelector('[data-fonly]'); ob.textContent = this.onlyStock ? '☑ En stock seulement' : '☐ En stock seulement'; ob.classList.toggle('on', !!this.onlyStock);
    if (!this.sel || !list.some((f) => f.id === this.sel) || (this.onlyStock && have.length && !this.stock[this.sel])) this.sel = (have[0] || list[0]).id;
    if (this.onlyStock && !have.length) { grid.innerHTML = '<p class="fr-meta">Rien de cette catégorie au réfrigérateur.</p>'; det.innerHTML = '<p class="fr-meta">Décoche « En stock seulement » pour voir tout le catalogue.</p>'; return; }
    grid.innerHTML = [...have, ...none].map((f) => `<button class="fr-card${f.id === this.sel ? ' sel' : ''}${this.stock[f.id] ? '' : ' dim'}" data-id="${f.id}">${ic(f.id)}<b>${f.name}</b><i>×${this.stock[f.id] || 0}</i></button>`).join('');
    const f = FOOD_BY_ID[this.sel], n = this.stock[f.id] || 0;
    let acts = '';
    if (n > 0) {
      if (f.kind === 'drink' || f.kind === 'fruit' || f.kind === 'snack') acts = `<button class="fr-go" data-act="quick">${f.kind === 'drink' ? 'BOIRE' : 'MANGER'}</button>`;
      else if (f.kind === 'base' || f.kind === 'dish') {
        if (!this.compose) acts = `<button class="fr-go" data-act="compose" ${this.pending || this.served ? 'disabled' : ''}>${this.pending ? 'CUISINIÈRE OCCUPÉE' : this.served ? 'UNE ASSIETTE EST DÉJÀ SERVIE' : 'PRÉPARER UNE ASSIETTE'}</button>`;
        else {
          const sauces = FOOD.filter((x) => x.kind === 'sauce' && this.stock[x.id] > 0), prots = FOOD.filter((x) => x.kind === 'protein' && this.stock[x.id] > 0);
          const C = this.compose, items = [C.base, C.sauce, C.prot].filter(Boolean), hot = items.some((i) => FOOD_BY_ID[i].hot), hun = items.reduce((a, i) => a + FOOD_BY_ID[i].hunger, 0);
          acts = `<div class="fr-comp"><span>Sauce :</span>${sauces.length ? sauces.map((s) => `<button data-act="sauce" data-v="${s.id}" class="${C.sauce === s.id ? 'on' : ''}">${s.name}</button>`).join('') : '<em>aucune en stock</em>'}</div>
            <div class="fr-comp"><span>Garniture :</span>${prots.length ? prots.map((s) => `<button data-act="prot" data-v="${s.id}" class="${C.prot === s.id ? 'on' : ''}">${s.name}</button>`).join('') : '<em>aucune en stock</em>'}</div>
            <button class="fr-go" data-act="serve">${hot ? 'SORTIR ET RÉCHAUFFER' : 'SERVIR'} (faim +${hun})</button>`;
        }
      } else if (f.kind === 'sauce' || f.kind === 'protein') acts = '<p class="fr-meta">S’ajoute à une assiette : choisis un plat dans l’onglet « Plats ».</p>';
      else acts = '<p class="fr-meta">Ingrédient : utilise-le dans l’onglet « Recettes ».</p>';
    } else acts = '<p class="fr-meta">Plus en stock : achète-en avec le téléphone (Courses à domicile).</p>';
    det.innerHTML = `${ic(f.id)}<h3>${f.name}</h3><p>${f.desc}</p><p class="fr-meta">${GASTRO_CATS[f.cat] ? `${GASTRO_CATS[f.cat]} • ` : ''}${f.hunger ? `Faim +${f.hunger} • ` : ''}${f.hot ? 'Se mange chaud • ' : ''}Prix indicatif ${fcfa(f.price)} • En stock : ${n}</p>${acts}`;
  }
  handleKeys(input) { if (input.hit('Escape') || input.hit('KeyE')) this.toggle(false); }

  serialize() { return { stock: { ...this.stock }, pending: this.pending ? (this.pending.kind === 'recipe' ? { kind: 'recipe', id: this.pending.recipe.id } : this.pending) : null, served: this.served }; }
  restore(s) {
    if (!s) return;
    if (s.stock) this.stock = Object.fromEntries(Object.entries(s.stock).filter(([k, v]) => FOOD_BY_ID[k] && v > 0));
    if (s.pending) this.pending = s.pending.kind === 'recipe' ? { kind: 'recipe', recipe: RECIPES.find((r) => r.id === s.pending.id) } : s.pending;
    if (this.pending && this.pending.kind === 'recipe' && !this.pending.recipe) this.pending = null;
    if (s.served && Array.isArray(s.served.items) && s.served.items.every((i) => FOOD_BY_ID[i])) this.serve(s.served.items, '');
  }
}
