// Végétation instanciée : cocotiers, manguiers, flamboyants, bougainvilliers, bananiers, herbes.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import * as T from './textures.js';
import { addWind } from './shaderfx.js';
import { mulberry32 } from './util.js';

const PI = Math.PI;

function sphericalNormals(geo, cx, cy, cz, mix = 0.75) {
  const p = geo.attributes.position, n = geo.attributes.normal;
  const v = new THREE.Vector3(), m = new THREE.Vector3();
  for (let i = 0; i < p.count; i++) {
    v.set(p.getX(i) - cx, p.getY(i) - cy, p.getZ(i) - cz).normalize();
    m.set(n.getX(i), n.getY(i), n.getZ(i));
    m.lerp(v, mix).normalize();
    n.setXYZ(i, m.x, m.y, m.z);
  }
}

function palmGeometries() {
  const R = mulberry32(5);
  const trunk = new THREE.CylinderGeometry(0.16, 0.25, 8, 10, 16);
  trunk.translate(0, 4, 0);
  {
    const p = trunk.attributes.position, uv = trunk.attributes.uv;
    for (let i = 0; i < p.count; i++) {
      const y = p.getY(i), k = y / 8;
      const swell = y < 0.7 ? 1 + (0.7 - y) * 0.6 : 1;
      p.setX(i, p.getX(i) * swell + k * k * 1.1);
      p.setZ(i, p.getZ(i) * swell);
    }
    for (let i = 0; i < uv.count; i++) uv.setY(i, uv.getY(i) * 4);
    trunk.computeVertexNormals();
  }
  const top = new THREE.Vector3(1.1, 8, 0);
  const fronds = [];
  const N = 16;
  for (let i = 0; i < N; i++) {
    const tier = i % 3; // 0 jeunes (dressées), 2 anciennes (retombantes)
    const len = 4.2 + R() * 0.8;
    const g = new THREE.PlaneGeometry(len, 1.4, 12, 2);
    g.translate(len / 2, 0, 0);
    g.rotateX(-PI / 2);
    const p = g.attributes.position;
    const up = [1.0, 0.55, 0.15][tier] + R() * 0.15;
    const droop = [0.09, 0.15, 0.24][tier];
    for (let k = 0; k < p.count; k++) {
      const x = p.getX(k), z = p.getZ(k);
      p.setY(k, x * up - x * x * droop + Math.abs(z) * 0.35);
    }
    g.rotateY((i / N) * PI * 2 + R() * 0.3);
    g.translate(top.x, top.y, top.z);
    fronds.push(g);
  }
  const crown = mergeGeometries(fronds);
  crown.computeVertexNormals();
  sphericalNormals(crown, top.x, top.y - 0.5, top.z, 0.35);
  const dead = [];
  for (let i = 0; i < 3; i++) {
    const g = new THREE.PlaneGeometry(2.6, 0.7, 4, 1);
    g.translate(1.3, 0, 0);
    g.rotateZ(-1.25 - R() * 0.2);
    g.rotateY(i * 2.1 + 0.5);
    g.translate(top.x, top.y - 0.1, top.z);
    dead.push(g);
  }
  const deadGeo = mergeGeometries(dead);
  const cocos = [];
  for (let k = 0; k < 7; k++) {
    const g = new THREE.SphereGeometry(0.15, 7, 5);
    const a = k * 0.9;
    g.translate(top.x + Math.cos(a) * 0.28, top.y - 0.35 - (k % 2) * 0.12, top.z + Math.sin(a) * 0.28);
    cocos.push(g);
  }
  return { trunk, crown, dead: deadGeo, coco: mergeGeometries(cocos) };
}

function treeGeometries(kind) {
  const R = mulberry32(kind === 'flamboyant' ? 9 : 7);
  const flat = kind === 'flamboyant';
  const trunkParts = [];
  const t = new THREE.CylinderGeometry(0.2, 0.34, flat ? 2.6 : 3.2, 8, 4);
  t.translate(0, flat ? 1.3 : 1.6, 0);
  trunkParts.push(t);
  const crownY = flat ? 4.0 : 4.6, rad = flat ? 4.2 : 2.9, ry = flat ? 1.1 : 2.3;
  for (let b = 0; b < 4; b++) {
    const a = b * PI / 2 + R() * 0.6;
    const g = new THREE.CylinderGeometry(0.08, 0.16, 2.6, 6);
    g.translate(0, 1.3, 0);
    g.rotateZ(flat ? 1.0 : 0.6);
    g.rotateY(a);
    g.translate(0, flat ? 2.4 : 2.8, 0);
    trunkParts.push(g);
  }
  const trunk = mergeGeometries(trunkParts);
  // cartes de feuillage disposées sur un ellipsoïde
  const cards = [];
  const n = flat ? 46 : 40;
  for (let i = 0; i < n; i++) {
    const u = R() * 2 * PI, v = Math.acos(2 * R() - 1);
    const r = 0.55 + R() * 0.45;
    const px = Math.sin(v) * Math.cos(u) * rad * r, py = Math.cos(v) * ry * r, pz = Math.sin(v) * Math.sin(u) * rad * r;
    const size = flat ? 2.4 : 2.0;
    const g = new THREE.PlaneGeometry(size, size);
    g.rotateX(R() * PI); g.rotateY(R() * PI); g.rotateZ(R() * PI);
    g.translate(px, crownY + py, pz);
    cards.push(g);
  }
  const canopy = mergeGeometries(cards);
  sphericalNormals(canopy, 0, crownY, 0, 0.85);
  const core = new THREE.IcosahedronGeometry(1, 1);
  core.scale(rad * 0.48, ry * 0.55, rad * 0.48);
  core.translate(0, crownY, 0);
  return { trunk, canopy, core };
}

function tuftGeometry() {
  const parts = [];
  for (let k = 0; k < 3; k++) {
    const g = new THREE.PlaneGeometry(0.7, 0.55);
    g.translate(0, 0.27, 0);
    g.rotateY(k * PI / 3);
    parts.push(g, g.clone().rotateY(PI)); // double face réelle (normales vers le haut des deux côtés)
  }
  const g = mergeGeometries(parts);
  const n = g.attributes.normal;
  for (let i = 0; i < n.count; i++) n.setXYZ(i, 0, 1, 0);
  return g;
}

function bushGeometry() {
  const R = mulberry32(13), parts = [];
  for (let k = 0; k < 10; k++) {
    const g = new THREE.PlaneGeometry(1.3, 1.3);
    g.rotateX(R() * PI); g.rotateY(R() * PI);
    g.translate((R() - 0.5) * 1.6, 0.7 + R() * 0.9, (R() - 0.5) * 1.0);
    parts.push(g);
  }
  const g = mergeGeometries(parts);
  sphericalNormals(g, 0, 0.6, 0, 0.8);
  return g;
}

function bananaGeometry() {
  const R = mulberry32(17), leaves = [];
  for (let k = 0; k < 8; k++) {
    const g = new THREE.PlaneGeometry(2.3, 0.85, 8, 1);
    g.translate(1.15, 0, 0);
    g.rotateX(-PI / 2 + (R() - 0.5) * 0.6);
    const p = g.attributes.position;
    for (let i = 0; i < p.count; i++) { const x = p.getX(i); p.setY(i, p.getY(i) + x * 0.9 - x * x * 0.32); }
    g.rotateY(k * 0.8 + R() * 0.4);
    g.translate(0, 2.2 + R() * 0.5, 0);
    leaves.push(g);
  }
  const leavesG = mergeGeometries(leaves);
  leavesG.computeVertexNormals();
  const stem = new THREE.CylinderGeometry(0.12, 0.18, 2.5, 7);
  stem.translate(0, 1.25, 0);
  return { leaves: leavesG, stem };
}

export function buildVegetation(scene, veg, col, quality) {
  const dummy = new THREE.Object3D();
  const color = new THREE.Color();
  let drawCalls = 0;
  const meshes = [];
  function inst(geo, mat, list, colorFn, shadow = true) {
    if (!list.length) return null;
    const m = new THREE.InstancedMesh(geo, mat, list.length);
    list.forEach((it, i) => {
      dummy.position.set(it.x, it.y || 0, it.z);
      dummy.rotation.set(0, it.r || 0, 0);
      dummy.scale.setScalar(it.s || 1);
      dummy.updateMatrix();
      m.setMatrixAt(i, dummy.matrix);
      if (colorFn) m.setColorAt(i, colorFn(i, color));
    });
    m.castShadow = shadow; m.receiveShadow = true;
    if (mat.alphaTest > 0) m.userData.noAO = true;
    m.computeBoundingSphere();
    scene.add(m);
    meshes.push(m);
    drawCalls++;
    return m;
  }

  // ---- Cocotiers ----
  const pg = palmGeometries();
  const bark = T.palmBark();
  const trunkMat = new THREE.MeshStandardMaterial({ map: bark.map, normalMap: bark.normalMap, roughness: 0.95 });
  const frondMat = addWind(new THREE.MeshStandardMaterial({ map: T.palmFrond(), alphaTest: 0.45, side: THREE.DoubleSide, roughness: 0.75 }), 0.9, 7.5);
  const deadMat = new THREE.MeshStandardMaterial({ map: T.deadFrond(), alphaTest: 0.45, side: THREE.DoubleSide, roughness: 1 });
  const cocoMat = new THREE.MeshStandardMaterial({ color: 0x6a7a2a, roughness: 0.7 });
  inst(pg.trunk, trunkMat, veg.palms);
  inst(pg.crown, frondMat, veg.palms, (i, c) => c.setHSL(0.2 + Math.sin(i * 3.7) * 0.03, 0.35, 0.55 + Math.sin(i * 1.3) * 0.08));
  inst(pg.dead, deadMat, veg.palms);
  inst(pg.coco, cocoMat, veg.palms, null, false);
  for (const p of veg.palms) if (!p.noCol) col.addCircle(p.x, p.z, 0.3 * (p.s || 1), 8);

  // ---- Arbres feuillus ----
  const trunkTex = T.bark();
  const woodMat = new THREE.MeshStandardMaterial({ map: trunkTex, color: 0x8a7a66, roughness: 1 });
  for (const kind of ['mango', 'flamboyant']) {
    const list = veg.trees.filter((t) => (kind === 'flamboyant') === !!t.flamboyant);
    if (!list.length) continue;
    const tg = treeGeometries(kind);
    const leafTex = kind === 'mango' ? T.leafCluster(95, 61) : flamboyantTex();
    const leafMat = addWind(new THREE.MeshStandardMaterial({ map: leafTex, alphaTest: 0.5, side: THREE.DoubleSide, roughness: 0.85 }), 0.35, 3);
    const coreMat = new THREE.MeshStandardMaterial({ color: kind === 'mango' ? 0x1f3a14 : 0x4a3a18, roughness: 1 });
    inst(tg.trunk, woodMat, list);
    inst(tg.core, coreMat, list, null, false);
    inst(tg.canopy, leafMat, list, (i, c) => c.setHSL(0.25 + Math.sin(i * 12.9) * 0.03, 0.25, 0.62 + Math.sin(i * 7.3) * 0.08));
    for (const t of list) if (!t.noCol) col.addCircle(t.x, t.z, 0.4 * (t.s || 1), 4);
  }

  // ---- Bougainvilliers ----
  if (veg.bushes.length) {
    const mat = addWind(new THREE.MeshStandardMaterial({ map: T.bougainvillea(), alphaTest: 0.5, side: THREE.DoubleSide, roughness: 0.8 }), 0.4, 0.5);
    inst(bushGeometry(), mat, veg.bushes, (i, c) => c.setHSL(0, 0, 0.85 + Math.sin(i * 5.1) * 0.15));
  }
  // ---- Bananiers ----
  if (veg.bananas.length) {
    const bg = bananaGeometry();
    const mat = addWind(new THREE.MeshStandardMaterial({ map: T.bananaLeaf(), alphaTest: 0.5, side: THREE.DoubleSide, roughness: 0.7 }), 0.6, 1.8);
    inst(bg.leaves, mat, veg.bananas, (i, c) => c.setHSL(0.25, 0.3, 0.6 + Math.sin(i) * 0.1));
    inst(bg.stem, new THREE.MeshStandardMaterial({ color: 0x6f7a3a, roughness: 0.9 }), veg.bananas);
  }
  // ---- Herbes ----
  const tufts = quality === 'low' ? veg.tufts.slice(0, Math.floor(veg.tufts.length / 3)) : veg.tufts;
  if (tufts.length) {
    const mat = addWind(new THREE.MeshStandardMaterial({ map: T.grassTuft(), alphaTest: 0.4, side: THREE.FrontSide, roughness: 1 }), 0.8, 0.05);
    inst(tuftGeometry(), mat, tufts, (i, c) => c.setHSL(0.18 + Math.sin(i * 1.7) * 0.05, 0.3, 0.8 + Math.sin(i * 2.3) * 0.12), false);
  }
  return { drawCalls, meshes };
}

function flamboyantTex() {
  // feuillage fin + grappes de fleurs rouge-orangé du flamboyant
  const base = T.leafCluster(85, 67);
  const c = base.image, x = c.getContext('2d'), R = mulberry32(68);
  // grappes de petites fleurs rouge-orangé
  for (let k = 0; k < 70; k++) {
    const a = R() * 6.28, r = Math.sqrt(R()) * 100;
    const cx = 128 + Math.cos(a) * r, cy = 128 + Math.sin(a) * r;
    const n = 6 + Math.floor(R() * 10);
    for (let j = 0; j < n; j++) {
      x.fillStyle = `hsl(${4 + R() * 16},${82 + R() * 15}%,${40 + R() * 16}%)`;
      x.beginPath(); x.ellipse(cx + (R() - 0.5) * 16, cy + (R() - 0.5) * 16, 1.6 + R() * 2.2, 1.2 + R() * 1.5, R() * 3, 0, 7); x.fill();
    }
  }
  base.needsUpdate = true;
  return base;
}
