// Textures PBR générées par IA (Scenario / PATINA) et intégrées au jeu.
// Elles sont incluses en data-URL dans BENIN_LIFE.html : le jeu reste jouable hors-ligne.
import * as THREE from 'three';
import latC from '../assets/textures/laterite_color.jpg';
import latN from '../assets/textures/laterite_normal.jpg';
import aspC from '../assets/textures/asphalt_color.jpg';
import aspN from '../assets/textures/asphalt_normal.jpg';
import swC from '../assets/textures/sidewalk_color.jpg';
import swN from '../assets/textures/sidewalk_normal.jpg';

const loader = new THREE.TextureLoader();
function load(url, srgb) {
  const t = loader.load(url);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.anisotropy = 8;
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  return t;
}
// la carte de rugosité IA est trop brillante pour un sol poussiéreux : on garde couleur + relief
function pbr(c, n) { return { map: load(c, true), normalMap: load(n, false) }; }

export const AI = {
  laterite: () => pbr(latC, latN),
  asphalt: () => pbr(aspC, aspN),
  sidewalk: () => pbr(swC, swN),
};
