// Interface : menu principal, pause, options, commandes, HUD et mini-carte.
import { LINES_X, LINES_Z, ROAD_HALF, BEACH_Z, SEA_Z, ROUND_R, ISLAND_R } from './world.js';
import { HOME } from './home.js';
import { REGION, TOWNS, coastZ } from './region-geo.js';
import { CATS, STATUS } from './places.js';
import { planRoute } from './transport.js';

// carte de la région (mission 013, étape 6) : 0,16 pixel par mètre du jeu
const RG = { X0: -9100, Z0: -3950, X1: 6300, Z1: 1500, S: 0.16 };
const inCityMap = (x, z) => x > -200 && x < 200 && z > -200 && z < 220;

const $ = (s) => document.querySelector(s);

export class UI {
  constructor(settings, handlers, world = null) {
    this.world = world;
    this.settings = settings;
    this.h = handlers;
    this.el = {
      menu: $('#menu'), pause: $('#pause'), hud: $('#hud'), controls: $('#panel-controls'), options: $('#panel-options'),
      zone: $('#zone'), clock: $('#clock'), speedo: $('#speedo'), speedVal: $('#speed-val'), prompt: $('#prompt'),
      help: $('#help'), fps: $('#fps'), toast: $('#toast'), mini: $('#minimap'), stamina: $('#stamina > i'),
      mode: $('#mode'),
      needs: { hunger: $('#need-hunger > i'), energy: $('#need-energy > i'), hygiene: $('#need-hygiene > i') },
      homeDist: $('#home-dist'), activity: $('#activity'), imenu: $('#imenu'), fade: $('#fade'),
      bigmap: $('#bigmap'), bigCanvas: $('#bigmap canvas'), dest: $('#bm-dest'), bmInfo: $('#bm-info'),
    };
    this.destination = false;
    this.el.dest.addEventListener('click', (e) => { e.stopPropagation(); this.destination = !this.destination; this.syncDest(); });
    $('#bm-close').addEventListener('click', (e) => { e.stopPropagation(); this.toggleMap(false); });
    this.bmRegion = false;
    this.pois = []; this.filters = new Set(['ville', 'entreprise', 'visitable', 'marche', 'monument', 'loisirs', 'transport', 'maison', 'services', 'restaurant']); this.search = ''; this.selPoi = null; this.route = null; this.disc = new Set();
    const side = $('#bm-side');
    if (side) {
      side.innerHTML = `<input id="bm-q" type="search" placeholder="🔎 Rechercher un lieu…"><div class="bm-chips">${Object.entries(CATS).map(([k, c]) => `<button data-cat="${k}">${c.icon} ${c.label}</button>`).join('')}</div><div class="bm-list"></div><div class="bm-card"></div>`;
      side.querySelector('#bm-q').addEventListener('input', (e) => { this.search = e.target.value.trim().toLowerCase(); this.renderSide(); });
      side.querySelector('#bm-q').addEventListener('keydown', (e) => e.stopPropagation());
      side.addEventListener('click', (e) => {
        const b = e.target.closest('[data-cat],[data-poi],[data-route],[data-clear]'); if (!b) return; e.stopPropagation();
        if (b.dataset.cat) { const k = b.dataset.cat; if (this.filters.has(k)) this.filters.delete(k); else this.filters.add(k); }
        else if (b.dataset.poi) { this.selPoi = this.pois.find((p) => p.id === b.dataset.poi) || null; if (this.selPoi) this.bmRegion = !(Math.abs(this.selPoi.x) < 200 && this.selPoi.z > -200 && this.selPoi.z < 220); this.syncDest(); }
        else if (b.dataset.route !== undefined && this.selPoi) this.setRoute(this.selPoi);
        else if (b.dataset.clear !== undefined) { this.route = null; this.h.onMapChange && this.h.onMapChange(); }
        this.renderSide();
      });
    }
    $('#bm-mode').addEventListener('click', (e) => { e.stopPropagation(); this.bmRegion = !this.bmRegion; this.syncDest(); });
    this.el.bigCanvas.addEventListener('click', (e) => {
      const r = this.el.bigCanvas.getBoundingClientRect(), p = this._bmProj;
      if (!p) return;
      const mx = (e.clientX - r.left) * (this.el.bigCanvas.width / r.width), my = (e.clientY - r.top) * (this.el.bigCanvas.height / r.height);
      let best = null;
      for (const q of this.visiblePois()) { const qx = p.ox + (q.x - p.x0) * p.s, qy = p.oy + (q.z - p.z0) * p.s, d = Math.hypot(mx - qx, my - qy); if (d < 26 * Math.min(2, devicePixelRatio) && (!best || d < best.d)) best = { d, q }; }
      if (best) { this.selPoi = best.q; this.renderSide(); return; }
      const hx = p.ox + (HOME.marker.x - p.x0) * p.s, hy = p.oy + (HOME.marker.z - p.z0) * p.s;
      if (Math.hypot(mx - hx, my - hy) < 30) { this.destination = !this.destination; this.syncDest(); }
    });
    document.querySelectorAll('[data-act]').forEach((b) => b.addEventListener('click', (e) => {
      e.stopPropagation();
      this.action(b.dataset.act, b);
    }));
    // options
    const q = $('#opt-quality'), s = $('#opt-sens'), inv = $('#opt-invert'), fps = $('#opt-fps');
    q.value = settings.quality; s.value = settings.sensitivity; inv.checked = settings.invertY; fps.checked = settings.showFps;
    q.addEventListener('change', () => { settings.quality = q.value; this.h.onSettings(); });
    s.addEventListener('input', () => { settings.sensitivity = parseFloat(s.value); this.h.onSettings(); });
    inv.addEventListener('change', () => { settings.invertY = inv.checked; this.h.onSettings(); });
    fps.addEventListener('change', () => { settings.showFps = fps.checked; this.h.onSettings(); });
    const charBtns = document.querySelectorAll('[data-char]');
    const syncChar = () => charBtns.forEach((b) => b.classList.toggle('on', b.dataset.char === (settings.character || 'male')));
    charBtns.forEach((b) => b.addEventListener('click', (e) => { e.stopPropagation(); settings.character = b.dataset.char; syncChar(); this.h.onSettings(); }));
    syncChar();
    const dens = $('#opt-density'); if (dens) { dens.value = settings.density || 'medium'; dens.addEventListener('change', () => { settings.density = dens.value; this.h.onSettings(); }); }
    const tc = $('#opt-tc');
    const applyTc = () => document.documentElement.style.setProperty('--tc', settings.touchScale ?? 0.75);
    tc.value = settings.touchScale ?? 0.75; applyTc();
    tc.addEventListener('input', () => { settings.touchScale = parseFloat(tc.value); applyTc(); this.h.onSettings(); });
    const vol = $('#opt-volume'), mus = $('#opt-music');
    vol.value = settings.volume ?? 0.8; mus.checked = settings.music !== false;
    vol.addEventListener('input', () => { settings.volume = parseFloat(vol.value); settings.muted = false; this.h.onSettings(); });
    mus.addEventListener('change', () => { settings.music = mus.checked; this.h.onSettings(); });
    this.miniCtx = this.el.mini.getContext('2d');
    this.mapCanvas = this.renderMap();
    this._toastT = 0;
    this._zone = '';
  }

  action(a, btn) {
    if (a === 'play' || a === 'resume') this.h.onPlay();
    else if (a === 'controls') this.showPanel('controls');
    else if (a === 'options') this.showPanel('options');
    else if (a === 'close') this.hidePanels();
    else if (a === 'menu') this.h.onMainMenu();
    else if (a === 'newgame') this.h.onNewGame && this.h.onNewGame(btn);
  }

  showPanel(name) {
    this.hidePanels();
    this.el[name].classList.add('show');
  }
  hidePanels() { this.el.controls.classList.remove('show'); this.el.options.classList.remove('show'); }
  panelOpen() { return this.el.controls.classList.contains('show') || this.el.options.classList.contains('show'); }

  setState(state) {
    this.el.menu.classList.toggle('show', state === 'menu');
    this.el.pause.classList.toggle('show', state === 'paused');
    this.el.hud.classList.toggle('show', state === 'playing');
    if (state === 'playing') this.hidePanels();
  }

  // ---- menu d'interaction (réfrigérateur, armoire, lit, télévision…) ----
  openMenu(title, sub, items, onClose = null) {
    const m = this.el.imenu;
    m.innerHTML = `<h3>${title}</h3><p>${sub || ''}</p><div class="im-list"></div><button class="im-close">Fermer (Échap)</button>`;
    const list = m.querySelector('.im-list');
    this._menuItems = items;
    items.forEach((it, i) => {
      const b = document.createElement('button');
      b.className = 'im-item'; b.disabled = !!it.disabled;
      b.innerHTML = `<b>${i + 1}</b><span>${it.label}${it.desc ? `<small>${it.desc}</small>` : ''}</span>`;
      b.addEventListener('click', (e) => { e.stopPropagation(); this.closeMenu(); it.action(); });
      list.appendChild(b);
    });
    m.querySelector('.im-close').addEventListener('click', (e) => { e.stopPropagation(); this.closeMenu(); });
    this._menuClose = onClose;
    m.classList.add('show');
  }
  closeMenu() {
    if (!this.menuOpen()) return;
    this.el.imenu.classList.remove('show');
    const f = this._menuClose; this._menuClose = null; if (f) f();
  }
  menuOpen() { return this.el.imenu.classList.contains('show'); }
  menuKey(input) {
    for (let i = 0; i < 9; i++) if (input.hit('Digit' + (i + 1)) || input.hit('Numpad' + (i + 1))) {
      const it = this._menuItems && this._menuItems[i];
      if (it && !it.disabled) { this.closeMenu(); it.action(); }
      return;
    }
    if (input.hit('Escape') || input.hit('KeyE')) this.closeMenu();
  }
  setActivity(text) { this.el.activity.textContent = text || ''; this.el.activity.classList.toggle('show', !!text); }
  fade(on) { this.el.fade.classList.toggle('show', on); }

  // ---- carte générale ----
  mapOpen() { return this.el.bigmap.classList.contains('show'); }
  // ---- lieux, filtres, itinéraires (complément mission 015) ----
  setPOIs(list, saved) { this.pois = list; if (saved) { for (const id of saved.disc || []) this.disc.add(id); if (saved.route) { const p = list.find((q) => q.id === saved.route); if (p) this.setRoute(p, true); } } this.renderSide(); }
  mapState() { return { disc: [...this.disc], route: this.route ? this.route.poi.id : null }; }
  visiblePois() {
    const reg = this.bmRegion, inCity = (q) => Math.abs(q.x) < 200 && q.z > -200 && q.z < 220;
    return this.pois.filter((q) => this.filters.has(q.cat) && (!this.search || q.name.toLowerCase().includes(this.search) || CATS[q.cat].label.toLowerCase().includes(this.search)) && (reg ? (!inCity(q) || q.star || q.cat === 'maison') && q.cat !== 'quartier' && !q.small : inCity(q)));
  }
  renderSide() {
    const side = document.querySelector('#bm-side'); if (!side) return;
    side.querySelectorAll('[data-cat]').forEach((b) => b.classList.toggle('on', this.filters.has(b.dataset.cat)));
    const list = this.pois.filter((q) => this.filters.has(q.cat) && (!this.search || q.name.toLowerCase().includes(this.search)) && !q.small).sort((a, b) => (b.star ? 1 : 0) - (a.star ? 1 : 0) || a.name.localeCompare(b.name)).slice(0, 60);
    side.querySelector('.bm-list').innerHTML = list.map((q) => `<button data-poi="${q.id}" class="${this.selPoi === q ? 'on' : ''}${q.star ? ' star' : ''}"><i>${q.star ? '⭐' : CATS[q.cat].icon}</i><span>${q.name}<small>${CATS[q.cat].label}${this.disc.has(q.id) ? ' • ✓ découvert' : ''}</small></span></button>`).join('') || '<p>Aucun lieu.</p>';
    const q = this.selPoi;
    side.querySelector('.bm-card').innerHTML = q ? `<b>${q.star ? '⭐ ' : CATS[q.cat].icon + ' '}${q.name}</b><small>${CATS[q.cat].label} • ${q.address}</small><p>${q.note || ''}</p><em class="st-${q.status}">${STATUS[q.status]}</em>
      ${q.access === false ? `<p class="bm-warn">${q.reserved ? 'Société pas encore créée.' : 'Bâtiment non visitable.'}</p>` : ''}
      <div class="bm-act"><button data-route>🧭 Itinéraire</button>${this.route ? '<button data-clear>✕ Effacer l’itinéraire</button>' : ''}</div>` : (this.route ? `<b>🧭 Itinéraire vers ${this.route.poi.name}</b><div class="bm-act"><button data-clear>✕ Effacer l’itinéraire</button></div>` : '<p>Touche un marqueur ou un lieu de la liste.</p>');
  }
  setRoute(p, silent) {
    const from = this._last ? { x: this._last.x, z: this._last.z } : { x: 0, z: 0 };
    let pts;
    try { const r = planRoute(from, p); pts = [[from.x, from.z], ...r.axis, [p.x, p.z]]; } catch (e) { pts = [[from.x, from.z], [p.x, p.z]]; }
    this.route = { poi: p, pts }; this.destination = false; this.syncDest();
    if (!silent) this.toast(`Itinéraire vers ${p.name} : suis le tracé jaune sur la carte et la mini-carte`, 3);
    this.h.onMapChange && this.h.onMapChange();
  }
  routeLen(info) { if (!this.route) return 0; let L = Math.hypot(this.route.pts[1][0] - info.x, this.route.pts[1][1] - info.z); for (let i = 1; i < this.route.pts.length - 1; i++) L += Math.hypot(this.route.pts[i + 1][0] - this.route.pts[i][0], this.route.pts[i + 1][1] - this.route.pts[i][1]); return L; }
  drawRoute(x, P, w) { if (!this.route) return; x.strokeStyle = 'rgba(0,0,0,0.5)'; x.lineWidth = w + 3; x.lineJoin = 'round'; x.beginPath(); this.route.pts.forEach((p, i) => { const [a, b] = P(p[0], p[1]); if (i) x.lineTo(a, b); else x.moveTo(a, b); }); x.stroke(); x.strokeStyle = '#fcd116'; x.lineWidth = w; x.stroke(); }
  drawPois(x, P, k) {
    for (const q of this.visiblePois()) {
      const [a, b] = P(q.x, q.z), r = (q.star ? 15 : q.small ? 8 : 11) * k, sel = this.selPoi === q, ok = this.disc.has(q.id) || q.cat === 'ville' || q.star || q.cat === 'maison';
      if (q.cat === 'quartier') { x.font = `bold ${11 * k}px sans-serif`; x.textAlign = 'center'; x.textBaseline = 'middle'; x.lineWidth = 3 * k; x.strokeStyle = 'rgba(0,0,0,0.6)'; x.strokeText(q.name, a, b); x.fillStyle = 'rgba(255,255,255,0.85)'; x.fillText(q.name, a, b); continue; }
      x.globalAlpha = ok ? 1 : 0.6;
      x.fillStyle = q.star ? '#0b1220' : q.cat === 'entreprise' ? '#1f4e9c' : '#ffffff'; x.beginPath(); x.arc(a, b, r, 0, 7); x.fill();
      x.lineWidth = (sel ? 4 : 2) * k; x.strokeStyle = sel ? '#fcd116' : q.star ? '#f2c200' : q.status === 'reel' ? '#0b6e4f' : '#333'; x.stroke();
      x.font = `${(q.small ? 10 : 13) * k}px sans-serif`; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillStyle = '#fff';
      if (q.star) { x.font = `900 ${11 * k}px Arial`; x.fillStyle = '#f2c200'; x.fillText('NB', a, b + 1); } else x.fillText(CATS[q.cat].icon, a, b + 1);
      x.globalAlpha = 1;
      if (sel || (q.star && !this.bmRegion) || q.cat === 'visitable' || (q.cat === 'entreprise' && k > 1.2) || (this.bmRegion && (q.cat === 'ville' || q.cat === 'entreprise' || q.cat === 'transport'))) { x.font = `bold ${(q.star ? 14 : 11) * k}px sans-serif`; x.textBaseline = 'top'; x.lineWidth = 3 * k; x.strokeStyle = 'rgba(0,0,0,0.75)'; x.strokeText(q.name, a, b + r + 2); x.fillStyle = q.star ? '#f2c200' : '#fff'; x.fillText(q.name, a, b + r + 2); }
    }
  }
  toggleMap(on = !this.mapOpen()) { if (on && this._last) this.bmRegion = !inCityMap(this._last.x, this._last.z); this.el.bigmap.classList.toggle('show', on); this.syncDest(); }
  // (la classe « reg » agrandit le cadre en mode région)
  syncDest() { const mb = document.querySelector('#bm-mode'); if (mb) mb.textContent = this.bmRegion ? 'Voir Cotonou' : 'Voir la région'; this.el.bigmap.classList.toggle('reg', this.bmRegion); this.el.dest.textContent = this.destination ? 'Annuler l\'itinéraire vers M' : 'Définir M (ma maison) comme destination'; this.el.dest.classList.toggle('on', this.destination); }
  drawBigMap(info) {
    const cv = this.el.bigCanvas, W = cv.clientWidth * Math.min(2, devicePixelRatio), H = cv.clientHeight * Math.min(2, devicePixelRatio);
    if (cv.width !== Math.round(W)) { cv.width = Math.round(W); cv.height = Math.round(H); }
    const x = cv.getContext('2d'), reg = this.bmRegion, mc = reg ? this.regionMap() : this.mapCanvas;
    const MW = reg ? RG.X1 - RG.X0 : 400, MH = reg ? RG.Z1 - RG.Z0 : 420, x0 = reg ? RG.X0 : -200, z0 = reg ? RG.Z0 : -200;
    const s = Math.min(cv.width / MW, cv.height / MH) * 0.98, ox = (cv.width - MW * s) / 2, oy = (cv.height - MH * s) / 2;
    this._bmProj = { s, ox, oy, x0, z0 };
    x.fillStyle = '#1a1512'; x.fillRect(0, 0, cv.width, cv.height);
    x.drawImage(mc, ox, oy, MW * s, MH * s);
    const P = (wx, wz) => [ox + (wx - x0) * s, oy + (wz - z0) * s];
    for (const c of info.cars) { const [a, b] = P(c.x, c.z); x.fillStyle = '#3ab0ff'; x.beginPath(); x.arc(a, b, 5, 0, 7); x.fill(); }
    const kk = Math.max(0.75, Math.min(2, cv.width / 900)); this.drawRoute(x, P, 4 * kk); this.drawPois(x, P, kk); // taille adaptée à la carte (iPhone : plus petit)
    // marqueur M (maison)
    const [hx, hy] = P(HOME.marker.x, HOME.marker.z);
    if (this.destination) { const [px, py] = P(info.x, info.z); x.strokeStyle = '#fcd116'; x.setLineDash([10, 8]); x.lineWidth = 4; x.beginPath(); x.moveTo(px, py); x.lineTo(hx, hy); x.stroke(); x.setLineDash([]); }
    x.fillStyle = '#008751'; x.beginPath(); x.arc(hx, hy, 16, 0, 7); x.fill(); x.strokeStyle = '#fff'; x.lineWidth = 3; x.stroke();
    x.fillStyle = '#fff'; x.font = 'bold 18px sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('M', hx, hy + 1);
    // joueur
    const [px, py] = P(info.x, info.z);
    x.save(); x.translate(px, py); x.rotate(Math.PI - info.heading);
    x.fillStyle = '#fcd116'; x.strokeStyle = '#111'; x.lineWidth = 2;
    x.beginPath(); x.moveTo(0, -14); x.lineTo(10, 11); x.lineTo(0, 5); x.lineTo(-10, 11); x.closePath(); x.fill(); x.stroke(); x.restore();
    if (reg) {
      const k = Math.min(2, devicePixelRatio), lab = (wx, wz, txt, big) => { const [a, b] = P(wx, wz); x.font = `bold ${(big ? 17 : 14) * k}px sans-serif`; x.textAlign = 'center'; x.textBaseline = 'bottom'; x.lineWidth = 4; x.strokeStyle = 'rgba(0,0,0,0.75)'; x.strokeText(txt, a, b - 7); x.fillStyle = '#fff'; x.fillText(txt, a, b - 7); };
      lab(0, -190, 'Cotonou', true); lab(-3000, 900, 'Océan Atlantique', false); // villes, aéroport, lac : marqueurs de la carte
    }
    this.el.bmInfo.textContent = this.route ? `🧭 ${this.route.poi.name} : ${this.fmt(this.routeLen(info))} par la route • ` + (reg ? 'vue région' : 'vue Cotonou') : reg ? `Région à l’échelle 1:5 (OpenStreetMap) • ${TOWNS.map((t) => `${t.name} ${(Math.hypot(t.x - info.x, t.z - info.z) / 1000).toFixed(1).replace('.', ',')} km`).join(' • ')} • M : ${this.distText(info)}`
      : `Ma maison (M) : ${this.distText(info)} • Toi : flèche jaune • Véhicules : points bleus`;
  }
  fmt(d) { return d < 1000 ? `${Math.round(d)} m` : `${(d / 1000).toFixed(1).replace('.', ',')} km`; }
  distText(info) {
    const d = Math.hypot(HOME.marker.x - info.x, HOME.marker.z - info.z);
    return d < 1000 ? `${Math.round(d)} m` : `${(d / 1000).toFixed(1)} km`;
  }

  toast(msg, t = 3) {
    this.el.toast.textContent = msg;
    this.el.toast.classList.add('show');
    this._toastT = t;
  }

  toggleHelp() { this.el.help.classList.toggle('show'); }

  update(dt, info) {
    if (info.zone !== this._zone) {
      this._zone = info.zone;
      this.el.zone.textContent = info.zone;
      this.el.zone.classList.remove('flash'); void this.el.zone.offsetWidth; this.el.zone.classList.add('flash');
    }
    const ck = info.clock + '|' + (info.clockSub || '');
    if (ck !== this._ck) { this._ck = ck; this.el.clock.innerHTML = `${info.clock}${info.clockSub ? `<small>${info.clockSub}</small>` : ''}`; }
    this.el.speedo.classList.toggle('show', !!info.driving);
    if (info.driving) this.el.speedVal.textContent = Math.round(Math.abs(info.speed) * 3.6);
    this.el.mode.textContent = info.vehicle === 'passager' ? 'PASSAGER' : info.vehicle === 'moto' ? 'À MOTO' : info.vehicle === 'plane' ? 'EN AVION' : info.vehicle === 'heli' ? 'EN HÉLICOPTÈRE' : info.vehicle === 'boat' ? 'EN BATEAU' : info.driving ? 'EN VOITURE' : 'À PIED';
    this.el.stamina.style.width = (info.stamina * 100).toFixed(0) + '%';
    if (info.prompt) { this.el.prompt.innerHTML = info.prompt; this.el.prompt.classList.add('show'); }
    else this.el.prompt.classList.remove('show');
    this.el.fps.style.display = this.settings.showFps ? 'block' : 'none';
    if (this.settings.showFps) this.el.fps.textContent = info.fpsText;
    if (this._toastT > 0) { this._toastT -= dt; if (this._toastT <= 0) this.el.toast.classList.remove('show'); }
    // jauges de vie et distance à la maison
    if (info.needs) for (const k of ['hunger', 'energy', 'hygiene']) {
      const v = info.needs[k]; this.el.needs[k].style.width = v.toFixed(0) + '%';
      this.el.needs[k].parentElement.classList.toggle('low', v < 20);
    }
    if (this.route) {
      const p = this.route.poi, d = Math.hypot(p.x - info.x, p.z - info.z);
      this.el.homeDist.innerHTML = `<b>📍</b> ${p.name.replace(' — siège social', '')} • ${this.fmt(this.routeLen(info))}`; this.el.homeDist.classList.add('dest');
      if (d < 18) { this.toast(`Arrivé : ${p.name}`, 3); this.route = null; this.h.onMapChange && this.h.onMapChange(); }
    } else {
      this.el.homeDist.innerHTML = `<b>M</b> ${info.atHome ? 'Chez toi' : this.distText(info)}`;
      this.el.homeDist.classList.toggle('dest', this.destination);
    }
    // découvertes : lieux approchés à moins de 45 m
    this._discT = (this._discT || 0) - dt;
    if (this._discT <= 0) { this._discT = 1; for (const q of this.pois) if (!this.disc.has(q.id) && Math.hypot(q.x - info.x, q.z - info.z) < (q.cat === 'ville' ? q.r || 300 : 45)) { this.disc.add(q.id); if (!q.small && q.cat !== 'quartier') this.toast(`📍 Lieu découvert : ${q.name}`, 2.5); this.h.onMapChange && this.h.onMapChange(); } }
    if (this.mapOpen()) this.drawBigMap(info);
    this.drawMini(info);
  }

  // Carte complète pré-dessinée (1 px = 0,5 m) : sols, routes, bâtiments, lieux
  regionMap() {
    if (this._regionCanvas) return this._regionCanvas;
    const S = RG.S, c = document.createElement('canvas'); c.width = Math.round((RG.X1 - RG.X0) * S); c.height = Math.round((RG.Z1 - RG.Z0) * S);
    const x = c.getContext('2d'), T = (wx, wz) => [(wx - RG.X0) * S, (wz - RG.Z0) * S];
    x.fillStyle = '#c9b98a'; x.fillRect(0, 0, c.width, c.height);
    // mer
    x.fillStyle = '#2f7f9a'; x.beginPath(); x.moveTo(...T(RG.X0, RG.Z1));
    for (let wx = RG.X0; wx <= RG.X1; wx += 50) x.lineTo(...T(wx, coastZ(wx)));
    x.lineTo(...T(RG.X1, RG.Z1)); x.closePath(); x.fill();
    // lacs
    x.fillStyle = '#4d93ad'; for (const l of REGION.lakes) { x.beginPath(); l.pts.forEach((p, i) => (i ? x.lineTo(...T(p[0], p[1])) : x.moveTo(...T(p[0], p[1])))); x.closePath(); x.fill(); }
    // aéroport et ville du jeu
    x.fillStyle = '#9aa06a'; x.fillRect(...T(-2150, -75), 1720 * S, 227 * S);
    x.fillStyle = '#4d4f55'; x.fillRect(...T(-2050, -42), 1500 * S, Math.max(2, 45 * S));
    x.fillStyle = '#b3734e'; x.fillRect(...T(-175, -175), 350 * S, 335 * S);
    // RNIE 1
    x.strokeStyle = '#2a2b30'; x.lineWidth = 6; x.lineJoin = 'round';
    for (const r of REGION.roads) { x.beginPath(); r.pts.forEach((p, i) => (i ? x.lineTo(...T(p[0], p[1])) : x.moveTo(...T(p[0], p[1])))); x.stroke(); }
    x.strokeStyle = '#f2c200'; x.lineWidth = 2.5;
    for (const r of REGION.roads) { x.beginPath(); r.pts.forEach((p, i) => (i ? x.lineTo(...T(p[0], p[1])) : x.moveTo(...T(p[0], p[1])))); x.stroke(); }
    // villes (les noms sont écrits à l'affichage, à taille fixe)
    for (const t of TOWNS) { const [a, b] = T(t.x, t.z); x.fillStyle = 'rgba(200,16,46,0.25)'; x.beginPath(); x.arc(a, b, t.r * S, 0, 7); x.fill(); x.fillStyle = '#c8102e'; x.beginPath(); x.arc(a, b, 5, 0, 7); x.fill(); x.strokeStyle = '#fff'; x.lineWidth = 1.5; x.stroke(); }
    this._regionCanvas = c; return c;
  }
  renderMap() {
    const S = 2, X0 = -200, Z0 = -200, W = 400, H = 420;
    const c = document.createElement('canvas');
    c.width = W * S; c.height = H * S;
    const x = c.getContext('2d');
    const tx = (v) => (v - X0) * S, tz = (v) => (v - Z0) * S;
    x.fillStyle = '#b3734e'; x.fillRect(0, 0, c.width, c.height);
    // îlots (trottoirs)
    x.fillStyle = '#c9bfae';
    const ix = [[-175, -107], [-93, -7], [7, 93], [107, 175]], iz = [[-175, -107], [-93, -7], [7, 93], [107, 145]];
    for (const [a, b] of ix) for (const [p, q] of iz) { x.fillRect(tx(a), tz(p), (b - a) * S, (q - p) * S); x.fillStyle = '#b97a52'; x.fillRect(tx(a + 3), tz(p + 3), (b - a - 6) * S, (q - p - 6) * S); x.fillStyle = '#c9bfae'; }
    const sea = x.createLinearGradient(0, tz(SEA_Z), 0, c.height);
    sea.addColorStop(0, '#3c9ab0'); sea.addColorStop(1, '#1d5f7a');
    x.fillStyle = '#e8d6a8'; x.fillRect(0, tz(BEACH_Z), c.width, c.height);
    x.fillStyle = sea; x.fillRect(0, tz(SEA_Z), c.width, c.height);
    x.fillStyle = '#7d9a4e'; x.fillRect(tx(10), tz(-90), 80 * S, 80 * S); // jardin
    x.fillStyle = '#e2c99a'; x.fillRect(tx(23), tz(-63), 44 * S, 26 * S);  // terrain de foot
    x.fillStyle = '#d9a46a'; x.fillRect(tx(-90), tz(10), 80 * S, 80 * S); // marché
    // routes
    x.fillStyle = '#4d4f55';
    for (const z of LINES_Z) x.fillRect(0, tz(z - ROAD_HALF), c.width, ROAD_HALF * 2 * S);
    for (const l of LINES_X) x.fillRect(tx(l - ROAD_HALF), 0, ROAD_HALF * 2 * S, tz(BEACH_Z));
    x.beginPath(); x.arc(tx(0), tz(0), ROUND_R * S, 0, 7); x.fill();
    x.strokeStyle = 'rgba(255,255,255,0.35)'; x.lineWidth = 1; x.setLineDash([6, 6]);
    for (const z of LINES_Z) { x.beginPath(); x.moveTo(0, tz(z)); x.lineTo(c.width, tz(z)); x.stroke(); }
    for (const l of LINES_X) { x.beginPath(); x.moveTo(tx(l), 0); x.lineTo(tx(l), tz(BEACH_Z)); x.stroke(); }
    x.setLineDash([]);
    x.fillStyle = '#7d9a4e'; x.beginPath(); x.arc(tx(0), tz(0), ISLAND_R * S, 0, 7); x.fill();
    // bâtiments
    if (this.world) for (const [a, b, p, q, k] of this.world.footprints) {
      x.fillStyle = k === 2 ? '#d8c7a6' : '#efe6d6';
      x.fillRect(tx(a), tz(b), (p - a) * S, (q - b) * S);
      x.strokeStyle = 'rgba(60,40,30,0.55)'; x.lineWidth = 1;
      x.strokeRect(tx(a) + 0.5, tz(b) + 0.5, (p - a) * S - 1, (q - b) * S - 1);
    }
    // lieux
    const poi = (wx, wz, color, label) => {
      x.fillStyle = 'rgba(0,0,0,0.35)'; x.beginPath(); x.arc(tx(wx), tz(wz) + 2, 13, 0, 7); x.fill();
      x.fillStyle = color; x.beginPath(); x.arc(tx(wx), tz(wz), 13, 0, 7); x.fill();
      x.strokeStyle = '#fff'; x.lineWidth = 2; x.stroke();
      x.fillStyle = '#fff'; x.font = 'bold 14px sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle';
      x.fillText(label, tx(wx), tz(wz) + 1);
    };
    poi(-50, 50, '#e46a1f', 'D');
    poi(50, -50, '#0b8a4f', 'J');
    poi(0, 176, '#1f8ab0', 'P');
    poi(0, 0, '#c8102e', '★');
    if (this.world && this.world.martyrs && this.world.martyrs.x !== undefined) {
      const P = this.world.martyrs;
      x.fillStyle = '#a9a39a'; x.fillRect(tx(P.x0), tz(P.z0), (P.x1 - P.x0) * S, (P.z1 - P.z0) * S);
      x.fillStyle = '#7d9a4e'; for (const sx of [-1, 1]) for (const sz of [-1, 1]) x.fillRect(tx(P.x + sx * 30 - 9), tz(P.z + sz * 9 - 4), 18 * S, 8 * S);
      poi(P.x, P.z, '#5a5a5a', '✦');
    }
    // maison du joueur
    { const L = HOME.lot; x.fillStyle = '#6f9a4a'; x.fillRect(tx(L.x0), tz(L.z0), (L.x1 - L.x0) * S, (L.z1 - L.z0) * S);
      x.fillStyle = '#f4efe6'; x.fillRect(tx(-56), tz(118), 20 * S, 16 * S); x.fillRect(tx(-36), tz(118), 8 * S, 10 * S);
      x.strokeStyle = '#008751'; x.lineWidth = 3; x.strokeRect(tx(L.x0), tz(L.z0), (L.x1 - L.x0) * S, (L.z1 - L.z0) * S); }
    // terre-plein de la Marina
    x.fillStyle = '#7d9a4e';
    for (const [a, b] of [[-175, -109.5], [-90.5, -9.5], [9.5, 90.5], [109.5, 175]]) x.fillRect(tx(a), tz(151.2), (b - a) * S, 1.6 * S);
    if (this.world && this.world.amazone) {
      const A = this.world.amazone;
      x.fillStyle = '#b9b2a6'; x.fillRect(tx(A.x0), tz(A.z0), (A.x1 - A.x0) * S, (A.z1 - A.z0) * S);
      x.fillStyle = '#7d9a4e'; for (const sx of [-1, 1]) for (const [z0, z1] of [[A.z0 + 1, A.z0 + 9], [A.z1 - 9, A.z1 - 1.5]]) x.fillRect(tx(sx * 25 - 8), tz(z0), 16 * S, (z1 - z0) * S);
      x.fillStyle = '#d8d2c4'; x.beginPath(); x.arc(tx(A.x), tz(A.z), 10.5 * S, 0, 7); x.fill();
      poi(A.x, A.z, '#7a5a32', 'A');
    }
    return c;
  }

  drawMini(info) {
    this._last = info;
    const reg = !inCityMap(info.x, info.z);
    const ctx = this.miniCtx, cv = this.el.mini, S = reg ? RG.S * 2.2 : 2, X0 = reg ? RG.X0 : -200, Z0 = reg ? RG.Z0 : -200;
    const size = cv.width, r = size / 2;
    this._zoom = (this._zoom || 1.1) + ((info.driving ? 0.6 + 0.4 / (1 + Math.abs(info.speed) * 0.08) : 1.1) - (this._zoom || 1.1)) * 0.05;
    const zoom = this._zoom, yaw = info.camYaw || 0;
    ctx.save();
    ctx.clearRect(0, 0, size, size);
    ctx.beginPath(); ctx.arc(r, r, r - 3, 0, 7); ctx.clip();
    ctx.fillStyle = '#2a201b'; ctx.fillRect(0, 0, size, size);
    ctx.translate(r, r);
    ctx.rotate(yaw); // la carte tourne avec la caméra : l'avant est toujours en haut
    ctx.scale(zoom, zoom);
    if (reg) { const rc = this.regionMap(); ctx.drawImage(rc, -(info.x - X0) * S, -(info.z - Z0) * S, rc.width * 2.2, rc.height * 2.2); }
    else ctx.drawImage(this.mapCanvas, -(info.x - X0) * S, -(info.z - Z0) * S);
    for (const car of info.cars) {
      const px = (car.x - info.x) * S, pz = (car.z - info.z) * S;
      ctx.fillStyle = 'rgba(0,0,0,0.4)'; ctx.beginPath(); ctx.arc(px, pz + 1, 6 / zoom, 0, 7); ctx.fill();
      ctx.fillStyle = car.occupied ? '#ffffff' : '#3ab0ff';
      ctx.beginPath(); ctx.arc(px, pz, 5 / zoom, 0, 7); ctx.fill();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5 / zoom; ctx.stroke();
    }
    if (this.route) {
      const Pm = (wx, wz) => [(wx - info.x) * S, (wz - info.z) * S];
      this.drawRoute(ctx, Pm, 3 / zoom);
      const [a, b] = Pm(this.route.poi.x, this.route.poi.z); ctx.fillStyle = '#c8102e'; ctx.beginPath(); ctx.arc(a, b, 7 / zoom, 0, 7); ctx.fill(); ctx.strokeStyle = '#fff'; ctx.lineWidth = 2 / zoom; ctx.stroke();
    }
        ctx.rotate(Math.PI - info.heading);
    ctx.scale(1 / zoom, 1 / zoom);
    ctx.fillStyle = '#fcd116'; ctx.strokeStyle = '#1a1a1a'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(0, -10); ctx.lineTo(7, 8); ctx.lineTo(0, 4); ctx.lineTo(-7, 8); ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.restore();
    // marqueur M de la maison (ou flèche sur le bord si hors de vue)
    {
      const dx = (HOME.marker.x - info.x) * S * zoom, dz = (HOME.marker.z - info.z) * S * zoom;
      const c = Math.cos(yaw), sn = Math.sin(yaw);
      let rx = dx * c - dz * sn, ry = dx * sn + dz * c;
      const len = Math.hypot(rx, ry), lim = r - 14, out = len > lim;
      if (out) { rx *= lim / len; ry *= lim / len; }
      ctx.fillStyle = this.destination ? '#fcd116' : '#008751';
      ctx.beginPath(); ctx.arc(r + rx, r + ry, out ? 8 : 10, 0, 7); ctx.fill();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.stroke();
      ctx.fillStyle = this.destination ? '#111' : '#fff'; ctx.font = 'bold 11px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText('M', r + rx, r + ry + 0.5);
    }
    // anneau + nord
    ctx.strokeStyle = 'rgba(255,255,255,0.85)'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.arc(r, r, r - 3, 0, 7); ctx.stroke();
    const nx = r + Math.sin(yaw) * (r - 3), ny = r - Math.cos(yaw) * (r - 3);
    ctx.fillStyle = '#c8102e'; ctx.beginPath(); ctx.arc(nx, ny, 9, 0, 7); ctx.fill();
    ctx.fillStyle = '#fff'; ctx.font = 'bold 11px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('N', nx, ny + 0.5);
  }
}
