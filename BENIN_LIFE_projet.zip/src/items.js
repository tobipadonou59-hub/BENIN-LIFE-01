// Mission 009 — catalogue des 50 équipements de BENIN LIFE.
// Objets imaginaires de jeu : aucun n'est une arme réelle, les effets sont purement visuels ou liés aux mécaniques du jeu.
// Chaque modèle 3D est construit à partir de formes simples (procédural, gratuit, ~100 à 900 triangles par objet).
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

export const CATEGORIES = [
  { id: 'protection', label: 'Protection', icon: '🛡' },
  { id: 'gadget', label: 'Gadgets', icon: '📡' },
  { id: 'outil', label: 'Outils', icon: '🔧' },
  { id: 'energie', label: 'Énergie', icon: '⚡' },
  { id: 'special', label: 'Spéciaux', icon: '★' },
];
export const RARITIES = {
  commun: { label: 'Commun', color: '#b9b4a8', rank: 0 },
  peu: { label: 'Peu commun', color: '#3fbf6a', rank: 1 },
  rare: { label: 'Rare', color: '#3a8eea', rank: 2 },
  epique: { label: 'Épique', color: '#a75ee8', rank: 3 },
  legendaire: { label: 'Légendaire', color: '#fcb316', rank: 4 },
};
export const SLOTS = { head: 'Tête', body: 'Corps', hand: 'Main', back: 'Dos' };

// Couleurs
const G = 0x008751, Y = 0xfcd116, R = 0xe8112d, W = 0xf2f0ea, K = 0x1c1c1e, BR = 0x6b4426, GO = 0xd8a520, SI = 0xb8bec6, CY = 0x46e0ff, OR = 0xff7a1a, ST = 0xcfa860;

// Formes : [type, ...dimensions, x, y, z, rx, ry, rz, couleur, options]
//  b = boîte (l, h, p) · c = cylindre (r haut, r bas, h) · s = sphère (r) · e = ellipsoïde (rx, ry, rz)
//  t = tore (R, r) · k = cône (r, h) · d = demi-sphère (r)
//  options : 'g' lumineux, 'm' métal, 'v' verre/brillant
// Repères : objets tenus en main → poignée à l'origine, l'objet pointe vers +Z ;
// tête → repère de l'os de la tête (centre du crâne ≈ y 0.11) ; corps / dos → repère de l'os de la poitrine (dos = z négatif).
const I = (o) => o;
export const ITEMS = [
  // ---------------- PROTECTION ----------------
  I({ id: 'casque_zem', name: 'Casque de zémidjan', cat: 'protection', rarity: 'commun', slot: 'head',
    desc: 'Le casque jaune des conducteurs de zémidjan, renforcé et aéré pour la chaleur de Cotonou.',
    parts: [['d', 0.15, 0, 0.12, 0, 0, 0, 0, Y], ['b', 0.26, 0.02, 0.1, 0, 0.12, 0.13, 0.2, 0, 0, Y], ['b', 0.2, 0.05, 0.02, 0, 0.1, 0.14, 0, 0, 0, K, 'v'], ['t', 0.15, 0.012, 0, 0.12, 0, Math.PI / 2, 0, 0, G]] }),
  I({ id: 'gilet', name: 'Gilet réfléchissant', cat: 'protection', rarity: 'commun', slot: 'body',
    desc: 'Gilet orange à bandes argentées : on te voit de loin, même la nuit sur la route des pêches.',
    parts: [['c', 0.2, 0.19, 0.34, 0, -0.08, 0, 0, 0, 0, OR, { sc: [1, 1, 0.74] }], ['c', 0.205, 0.195, 0.04, 0, -0.03, 0, 0, 0, 0, SI, { sc: [1, 1, 0.75], f: 'g' }], ['c', 0.2, 0.2, 0.04, 0, -0.17, 0, 0, 0, 0, SI, { sc: [1, 1, 0.75], f: 'g' }]] }),
  I({ id: 'bouclier_raphia', name: 'Bouclier en raphia tressé', cat: 'protection', rarity: 'peu', slot: 'hand', effect: 'block',
    desc: 'Bouclier décoratif tressé à la main. G : posture de garde.',
    parts: [['c', 0.26, 0.26, 0.03, 0, 0.05, 0.08, Math.PI / 2, 0, 0, ST], ['t', 0.26, 0.022, 0, 0.05, 0.08, 0, 0, 0, BR], ['s', 0.05, 0, 0.05, 0.1, 0, 0, 0, BR], ['t', 0.15, 0.008, 0, 0.05, 0.095, 0, 0, 0, G], ['t', 0.08, 0.008, 0, 0.05, 0.095, 0, 0, 0, R]] }),
  I({ id: 'impermeable', name: 'Imperméable des pluies', cat: 'protection', rarity: 'peu', slot: 'body',
    desc: 'Long imperméable bleu avec capuche, taillé pour les averses de juin.',
    parts: [['c', 0.21, 0.27, 0.62, 0, -0.22, 0, 0, 0, 0, 0x2a6fb5, { sc: [1, 1, 0.78], f: 'v' }], ['d', 0.13, 0, 0.17, -0.12, -0.6, 0, 0, 0x2a6fb5], ['c', 0.03, 0.03, 0.02, 0, -0.05, 0.155, Math.PI / 2, 0, 0, Y]] }),
  I({ id: 'lunettes_harmattan', name: 'Lunettes anti-harmattan', cat: 'protection', rarity: 'commun', slot: 'head',
    desc: 'Lunettes enveloppantes contre la poussière de l’harmattan.',
    parts: [['e', 0.042, 0.03, 0.012, 0.04, 0.11, 0.11, 0, 0, 0, 0x3a2a10, 'v'], ['e', 0.042, 0.03, 0.012, -0.04, 0.11, 0.11, 0, 0, 0, 0x3a2a10, 'v'], ['t', 0.112, 0.007, 0, 0.11, 0, Math.PI / 2, 0, 0, K]] }),
  I({ id: 'casque_chantier', name: 'Casque de chantier', cat: 'protection', rarity: 'commun', slot: 'head',
    desc: 'Casque blanc des chantiers de la Haie Vive, avec visière.',
    parts: [['d', 0.14, 0, 0.13, 0, 0, 0, 0, W], ['c', 0.17, 0.17, 0.012, 0, 0.13, 0.01, 0, 0, 0, W], ['b', 0.03, 0.05, 0.25, 0, 0.25, 0, 0, 0, 0, W], ['b', 0.06, 0.03, 0.005, 0, 0.17, 0.138, -0.2, 0, 0, G]] }),
  I({ id: 'plastron_calebasse', name: 'Plastron en calebasse', cat: 'protection', rarity: 'rare', slot: 'body',
    desc: 'Plastron sculpté dans une calebasse, gravé de motifs géométriques.',
    parts: [['e', 0.16, 0.15, 0.06, 0, -0.04, 0.1, 0, 0, 0, 0xb07a3a], ['t', 0.09, 0.008, 0, -0.04, 0.155, 0, 0, 0, BR], ['t', 0.05, 0.008, 0, -0.04, 0.16, 0, 0, 0, BR], ['b', 0.32, 0.02, 0.02, 0, 0.08, 0.06, 0, 0, 0.0, BR]] }),
  I({ id: 'sac_renforce', name: 'Sac à dos renforcé', cat: 'protection', rarity: 'peu', slot: 'back',
    desc: 'Sac rigide aux couleurs nationales pour transporter tout ton équipement.',
    parts: [['b', 0.26, 0.34, 0.13, 0, -0.06, -0.19, 0, 0, 0, G], ['b', 0.26, 0.06, 0.135, 0, 0.1, -0.19, 0, 0, 0, Y], ['b', 0.2, 0.12, 0.04, 0, -0.12, -0.27, 0, 0, 0, R], ['b', 0.03, 0.3, 0.02, 0.08, -0.02, -0.12, 0, 0, 0, K], ['b', 0.03, 0.3, 0.02, -0.08, -0.02, -0.12, 0, 0, 0, K]] }),
  I({ id: 'bouclier_prisme', name: 'Bouclier prismatique', cat: 'protection', rarity: 'epique', slot: 'hand', effect: 'shield',
    desc: 'Disque imaginaire qui projette un dôme de lumière. G : dôme lumineux (effet visuel, 4 s).',
    parts: [['c', 0.2, 0.2, 0.02, 0, 0.05, 0.08, Math.PI / 2, 0, 0, CY, { f: 'g', seg: 6 }], ['t', 0.2, 0.018, 0, 0.05, 0.08, 0, 0, 0, SI, { f: 'm' }], ['s', 0.04, 0, 0.05, 0.1, 0, 0, 0, W, 'g']] }),
  I({ id: 'cape_pagne', name: 'Cape en pagne wax', cat: 'protection', rarity: 'rare', slot: 'back',
    desc: 'Cape légère cousue dans un pagne wax aux motifs vifs.',
    parts: [['b', 0.36, 0.7, 0.012, 0, -0.32, -0.15, -0.12, 0, 0, 0xc0392b], ['b', 0.36, 0.08, 0.014, 0, -0.08, -0.13, -0.12, 0, 0, Y], ['b', 0.36, 0.08, 0.014, 0, -0.32, -0.163, -0.12, 0, 0, G], ['b', 0.36, 0.08, 0.014, 0, -0.56, -0.193, -0.12, 0, 0, 0x1f4e9c], ['t', 0.04, 0.012, 0, 0.12, 0.05, Math.PI / 2, 0, 0, GO, 'm']] }),

  // ---------------- GADGETS ----------------
  I({ id: 'drone_colibri', name: 'Drone-colibri', cat: 'gadget', rarity: 'rare', slot: 'hand', effect: 'drone',
    desc: 'Mini-drone imaginaire en forme de colibri. G : il tourne autour de toi pendant 15 s.',
    parts: [['e', 0.05, 0.035, 0.09, 0, 0.04, 0.06, 0, 0, 0, G], ['k', 0.012, 0.07, 0, 0.04, 0.17, Math.PI / 2, 0, 0, K], ['b', 0.22, 0.004, 0.04, 0, 0.07, 0.05, 0, 0, 0.2, CY, 'g'], ['s', 0.012, 0.025, 0.06, 0.13, 0, 0, 0, Y, 'g'], ['s', 0.012, -0.025, 0.06, 0.13, 0, 0, 0, Y, 'g']] }),
  I({ id: 'radio_kpakpato', name: 'Radio Kpakpato', cat: 'gadget', rarity: 'peu', slot: 'hand', effect: 'music',
    desc: 'Petite radio de marché qui diffuse les nouvelles du quartier. G : joue un air (son réel du jeu).',
    parts: [['b', 0.22, 0.13, 0.07, 0, 0.07, 0.06, 0, 0, 0, 0x8a2a1a], ['c', 0.04, 0.04, 0.01, -0.05, 0.07, 0.1, Math.PI / 2, 0, 0, K], ['b', 0.07, 0.04, 0.01, 0.055, 0.09, 0.1, 0, 0, 0, Y, 'g'], ['c', 0.004, 0.004, 0.25, 0.09, 0.25, 0.04, 0, 0, -0.3, SI, 'm'], ['b', 0.16, 0.015, 0.015, 0, 0.145, 0.06, 0, 0, 0, SI, 'm']] }),
  I({ id: 'montre_holo', name: 'Montre-carte holographique', cat: 'gadget', rarity: 'rare', slot: 'hand', effect: 'map',
    desc: 'Montre qui projette la carte de la ville. G : ouvre la carte générale.',
    parts: [['c', 0.045, 0.045, 0.02, 0, 0.03, 0.03, Math.PI / 2, 0, 0, K, 'm'], ['c', 0.038, 0.038, 0.004, 0, 0.03, 0.042, Math.PI / 2, 0, 0, CY, 'g'], ['t', 0.05, 0.012, 0, 0, 0.03, 0, 0, 0, K], ['e', 0.08, 0.002, 0.08, 0, 0.12, 0.04, 0, 0, 0, CY, 'g']] }),
  I({ id: 'scanner_marche', name: 'Scanner de quartier', cat: 'gadget', rarity: 'rare', slot: 'hand', effect: 'scan',
    desc: 'Compte les passants et les véhicules autour de toi. G : onde de détection (35 m) et résultat réel.',
    parts: [['b', 0.09, 0.16, 0.03, 0, 0.08, 0.04, 0, 0, 0, 0x2a2d33], ['b', 0.075, 0.08, 0.005, 0, 0.11, 0.057, 0, 0, 0, 0x2fd17a, 'g'], ['c', 0.006, 0.006, 0.08, 0.03, 0.2, 0.04, 0, 0, 0, SI, 'm'], ['s', 0.012, 0.03, 0.24, 0.04, 0, 0, 0, R, 'g']] }),
  I({ id: 'lance_bulles', name: 'Lance-bulles', cat: 'gadget', rarity: 'commun', slot: 'hand', effect: 'bubbles',
    desc: 'Jouet coloré qui souffle des bulles de savon. G : nuée de bulles.',
    parts: [['b', 0.04, 0.1, 0.05, 0, 0, 0.0, 0.25, 0, 0, 0x2fb4ff], ['c', 0.045, 0.04, 0.18, 0, 0.06, 0.1, Math.PI / 2, 0, 0, Y], ['t', 0.05, 0.012, 0, 0.06, 0.2, 0, 0, 0, R], ['s', 0.04, 0, 0.13, 0.04, 0, 0, 0, 0x9fe0ff, 'v']] }),
  I({ id: 'canne_confettis', name: 'Canne à confettis', cat: 'gadget', rarity: 'peu', slot: 'hand', effect: 'confetti',
    desc: 'Canne de fête des carnavals de Cotonou. G : pluie de confettis.',
    parts: [['c', 0.012, 0.012, 0.5, 0, 0.0, 0.18, Math.PI / 2, 0, 0, W], ['c', 0.013, 0.013, 0.06, 0, 0, 0.1, Math.PI / 2, 0, 0, R], ['c', 0.013, 0.013, 0.06, 0, 0, 0.22, Math.PI / 2, 0, 0, G], ['k', 0.05, 0.1, 0, 0, 0.47, Math.PI / 2, 0, 0, Y], ['s', 0.03, 0, 0, 0.52, 0, 0, 0, 0xff4fa0, 'g']] }),
  I({ id: 'disque_lumineux', name: 'Disque-boomerang lumineux', cat: 'gadget', rarity: 'epique', slot: 'hand', effect: 'boomerang',
    desc: 'Disque de lumière imaginaire qui revient toujours. G : lancer et retour (effet visuel).',
    parts: [['t', 0.1, 0.018, 0, 0.03, 0.08, 0, 0, 0, 0xff3df2, 'g'], ['c', 0.085, 0.085, 0.01, 0, 0.03, 0.08, Math.PI / 2, 0, 0, K, 'v'], ['s', 0.025, 0, 0.03, 0.08, 0, 0, 0, W, 'g']] }),
  I({ id: 'projecteur_holo', name: 'Projecteur d’hologrammes', cat: 'gadget', rarity: 'epique', slot: 'hand', effect: 'hologram',
    desc: 'Projette un drapeau du Bénin lumineux au-dessus de toi. G : hologramme (6 s).',
    parts: [['c', 0.05, 0.06, 0.06, 0, 0.03, 0.05, 0, 0, 0, 0x30343a, 'm'], ['c', 0.03, 0.05, 0.01, 0, 0.065, 0.05, 0, 0, 0, CY, 'g'], ['k', 0.06, 0.12, 0, 0.13, 0.05, Math.PI, 0, 0, CY, 'g']] }),
  I({ id: 'talkie', name: 'Talkie-walkie zém', cat: 'gadget', rarity: 'commun', slot: 'hand', effect: 'call',
    desc: 'Talkie des zémidjans pour s’appeler entre carrefours. G : signal sonore et ondes.',
    parts: [['b', 0.06, 0.15, 0.035, 0, 0.07, 0.04, 0, 0, 0, Y], ['b', 0.045, 0.05, 0.005, 0, 0.1, 0.058, 0, 0, 0, K], ['c', 0.008, 0.008, 0.1, 0.018, 0.19, 0.04, 0, 0, 0, K], ['s', 0.006, -0.015, 0.14, 0.06, 0, 0, 0, R, 'g']] }),
  I({ id: 'lunettes_ambre', name: 'Lunettes à vision ambrée', cat: 'gadget', rarity: 'rare', slot: 'head', effect: 'tint',
    desc: 'Verres teintés qui donnent à la ville une lumière dorée. Équipées : filtre ambré à l’écran.',
    parts: [['b', 0.17, 0.04, 0.012, 0, 0.11, 0.115, 0, 0, 0, 0xffa82a, 'g'], ['t', 0.112, 0.006, 0, 0.12, 0, Math.PI / 2, 0, 0, GO, 'm']] }),

  // ---------------- OUTILS & ACCESSOIRES ----------------
  I({ id: 'lampe_torche', name: 'Lampe torche', cat: 'outil', rarity: 'commun', slot: 'hand', effect: 'torch',
    desc: 'Lampe robuste pour les rues sans éclairage. G : allumer / éteindre le faisceau.',
    parts: [['c', 0.025, 0.025, 0.16, 0, 0.02, 0.07, Math.PI / 2, 0, 0, K, 'm'], ['c', 0.04, 0.026, 0.05, 0, 0.02, 0.17, Math.PI / 2, 0, 0, SI, 'm'], ['c', 0.036, 0.036, 0.005, 0, 0.02, 0.196, Math.PI / 2, 0, 0, 0xfff2c0, 'g']] }),
  I({ id: 'cle_molette', name: 'Clé à molette géante', cat: 'outil', rarity: 'commun', slot: 'hand', effect: 'sparks',
    desc: 'L’outil favori des mécaniciens de rue. G : coup de clé et étincelles.',
    parts: [['b', 0.035, 0.018, 0.36, 0, 0.0, 0.16, 0, 0, 0, SI, 'm'], ['c', 0.055, 0.055, 0.02, 0, 0, 0.36, 0, 0, 0, SI, 'm'], ['b', 0.04, 0.025, 0.07, 0, 0, 0.405, 0, 0, 0, 0x30343a]] }),
  I({ id: 'parapluie', name: 'Parapluie tricolore', cat: 'outil', rarity: 'peu', slot: 'hand', effect: 'umbrella',
    desc: 'Grand parapluie vert, jaune, rouge. G : ouvrir / fermer.',
    parts: [['c', 0.008, 0.008, 0.85, 0, 0.0, 0.42, Math.PI / 2, 0, 0, SI, 'm'], ['t', 0.03, 0.008, 0, 0, 0.0, 0, Math.PI / 2, 0, BR], ['k', 0.07, 0.6, 0, 0, 0.55, -Math.PI / 2, 0, 0, G], ['k', 0.055, 0.4, 0, 0, 0.64, -Math.PI / 2, 0, 0, Y]] }),
  I({ id: 'cabas', name: 'Cabas « Ghana Must Go »', cat: 'outil', rarity: 'commun', slot: 'hand', effect: 'swing',
    desc: 'Le grand sac à carreaux des marchés. G : balancer le sac.',
    parts: [['b', 0.36, 0.3, 0.16, 0, -0.22, 0.02, 0, 0, 0, 0x2a55a8], ['b', 0.362, 0.04, 0.162, 0, -0.14, 0.02, 0, 0, 0, R], ['b', 0.362, 0.04, 0.162, 0, -0.26, 0.02, 0, 0, 0, W], ['t', 0.05, 0.008, 0, -0.04, 0.02, 0, 0, 0, K]] }),
  I({ id: 'gourde', name: 'Gourde isotherme', cat: 'outil', rarity: 'commun', slot: 'hand', effect: 'drink',
    desc: 'Eau fraîche toute la journée. G : boire (+8 énergie, une fois par minute).',
    parts: [['c', 0.04, 0.04, 0.2, 0, 0.08, 0.04, 0, 0, 0, 0x1f7ad1, 'm'], ['c', 0.025, 0.035, 0.03, 0, 0.195, 0.04, 0, 0, 0, K], ['b', 0.082, 0.04, 0.082, 0, 0.05, 0.04, 0, 0, 0, W]] }),
  I({ id: 'calebasse_eau', name: 'Calebasse d’eau', cat: 'outil', rarity: 'peu', slot: 'hand', effect: 'splash',
    desc: 'Calebasse remplie d’eau fraîche. G : s’asperger (+10 propreté, une fois par minute).',
    parts: [['e', 0.11, 0.08, 0.11, 0, 0.0, 0.06, 0, 0, 0, 0xc8964a], ['t', 0.09, 0.006, 0, 0.03, 0.06, Math.PI / 2, 0, 0, BR], ['c', 0.085, 0.085, 0.004, 0, 0.045, 0.06, 0, 0, 0, 0x4fb6e8, 'v']] }),
  I({ id: 'jumelles', name: 'Jumelles', cat: 'outil', rarity: 'commun', slot: 'hand', effect: 'zoom',
    desc: 'Pour observer le port et la plage. G : zoom de la caméra (activer / désactiver).',
    parts: [['c', 0.03, 0.03, 0.12, 0.04, 0.03, 0.06, Math.PI / 2, 0, 0, K], ['c', 0.03, 0.03, 0.12, -0.04, 0.03, 0.06, Math.PI / 2, 0, 0, K], ['b', 0.05, 0.03, 0.05, 0, 0.03, 0.06, 0, 0, 0, 0x30343a], ['c', 0.026, 0.026, 0.004, 0.04, 0.03, 0.122, Math.PI / 2, 0, 0, 0x6aa8ff, 'v'], ['c', 0.026, 0.026, 0.004, -0.04, 0.03, 0.122, Math.PI / 2, 0, 0, 0x6aa8ff, 'v']] }),
  I({ id: 'appareil_photo', name: 'Appareil photo', cat: 'outil', rarity: 'peu', slot: 'hand', effect: 'photo',
    desc: 'Pour garder des souvenirs de Cotonou. G : prendre une vraie capture d’écran du jeu.',
    parts: [['b', 0.14, 0.09, 0.06, 0, 0.05, 0.04, 0, 0, 0, K], ['c', 0.032, 0.035, 0.05, 0, 0.05, 0.09, Math.PI / 2, 0, 0, 0x30343a, 'm'], ['c', 0.025, 0.025, 0.004, 0, 0.05, 0.116, Math.PI / 2, 0, 0, 0x5a7aff, 'v'], ['b', 0.03, 0.015, 0.015, 0.04, 0.1, 0.04, 0, 0, 0, R], ['b', 0.03, 0.02, 0.01, -0.04, 0.08, 0.072, 0, 0, 0, W, 'g']] }),
  I({ id: 'boussole', name: 'Boussole côtière', cat: 'outil', rarity: 'peu', slot: 'hand', effect: 'compass',
    desc: 'Boussole en laiton des pêcheurs. G : direction et distance réelles vers ta maison (M) et la mer.',
    parts: [['c', 0.06, 0.06, 0.02, 0, 0.03, 0.05, 0, 0, 0, GO, 'm'], ['c', 0.052, 0.052, 0.004, 0, 0.042, 0.05, 0, 0, 0, W], ['b', 0.008, 0.004, 0.08, 0, 0.046, 0.05, 0, 0.6, 0, R], ['t', 0.015, 0.004, 0, 0.03, 0.115, 0, 0, 0, GO, 'm']] }),
  I({ id: 'balai', name: 'Balai en paille', cat: 'outil', rarity: 'commun', slot: 'hand', effect: 'dust',
    desc: 'Balai traditionnel des cours de maison. G : un coup de balai (poussière).',
    parts: [['c', 0.012, 0.012, 0.7, 0, 0, 0.3, Math.PI / 2, 0, 0, BR], ['k', 0.07, 0.3, 0, 0, 0.74, -Math.PI / 2, 0, 0, ST], ['t', 0.03, 0.008, 0, 0, 0.6, 0, 0, 0, R]] }),

  // ---------------- ÉNERGIE (fictive) ----------------
  I({ id: 'pile_solaire', name: 'Pile solaire de poche', cat: 'energie', rarity: 'peu', slot: 'back', passive: { stamina: 0.25, dayOnly: true },
    desc: 'Panneau pliant accroché au dos. Passif : endurance +25 % de récupération le jour.',
    parts: [['b', 0.3, 0.22, 0.015, 0, -0.04, -0.17, 0.15, 0, 0, 0x1a2a5a, 'v'], ['b', 0.31, 0.012, 0.02, 0, 0.07, -0.18, 0.15, 0, 0, SI, 'm'], ['b', 0.31, 0.012, 0.02, 0, -0.15, -0.155, 0.15, 0, 0, SI, 'm'], ['b', 0.006, 0.22, 0.017, 0, -0.04, -0.168, 0.15, 0, 0, SI, 'm']] }),
  I({ id: 'cellule_eclair', name: 'Cellule-éclair', cat: 'energie', rarity: 'rare', slot: 'back', passive: { stamina: 0.4 },
    desc: 'Réservoir d’énergie imaginaire. Passif : endurance +40 % de récupération.',
    parts: [['c', 0.06, 0.06, 0.26, 0, -0.06, -0.17, 0, 0, 0, 0x22262c, 'm'], ['c', 0.045, 0.045, 0.2, 0, -0.06, -0.17, 0, 0, 0, Y, 'g'], ['c', 0.065, 0.065, 0.02, 0, 0.07, -0.17, 0, 0, 0, SI, 'm'], ['c', 0.065, 0.065, 0.02, 0, -0.19, -0.17, 0, 0, 0, SI, 'm']] }),
  I({ id: 'baton_impulsion', name: 'Bâton à impulsion', cat: 'energie', rarity: 'rare', slot: 'hand', effect: 'pulse',
    desc: 'Bâton imaginaire et inoffensif qui émet un anneau de lumière. G : onde lumineuse (visuel).',
    parts: [['c', 0.015, 0.015, 0.55, 0, 0, 0.2, Math.PI / 2, 0, 0, 0x30343a, 'm'], ['s', 0.045, 0, 0, 0.5, 0, 0, 0, CY, 'g'], ['t', 0.05, 0.008, 0, 0, 0.44, 0, 0, 0, SI, 'm'], ['t', 0.05, 0.008, 0, 0, 0.0, 0, 0, 0, SI, 'm']] }),
  I({ id: 'gant_cinetique', name: 'Gant cinétique', cat: 'energie', rarity: 'epique', slot: 'hand', effect: 'gust',
    desc: 'Gant imaginaire qui crée un souffle d’air. G : rafale de vent (visuel).',
    parts: [['e', 0.06, 0.05, 0.09, 0, 0.0, 0.02, 0, 0, 0, 0x7a1f8a], ['c', 0.05, 0.055, 0.06, 0, 0, -0.06, Math.PI / 2, 0, 0, K], ['s', 0.022, 0, 0.03, 0.06, 0, 0, 0, 0xff4fff, 'g'], ['t', 0.055, 0.006, 0, 0, -0.03, 0, 0, 0, GO, 'm']] }),
  I({ id: 'noyau_plasma', name: 'Noyau plasma (jouet)', cat: 'energie', rarity: 'rare', slot: 'hand', effect: 'orb',
    desc: 'Boule lumineuse en verre, simple jouet. G : la boule s’élève et tourbillonne.',
    parts: [['s', 0.07, 0, 0.09, 0.05, 0, 0, 0, 0x8a5aff, 'g'], ['s', 0.09, 0, 0.09, 0.05, 0, 0, 0, 0xc0b0ff, 'v'], ['c', 0.05, 0.06, 0.05, 0, 0.0, 0.05, 0, 0, 0, K, 'm']] }),
  I({ id: 'canon_harmattan', name: 'Canon à vent « Harmattan »', cat: 'energie', rarity: 'epique', slot: 'hand', effect: 'sand',
    desc: 'Souffleur imaginaire qui soulève un nuage de sable doré. G : bourrasque de sable (visuel).',
    parts: [['c', 0.05, 0.08, 0.3, 0, 0.04, 0.15, Math.PI / 2, 0, 0, 0xc8963a, 'm'], ['t', 0.08, 0.01, 0, 0.04, 0.3, 0, 0, 0, BR], ['b', 0.035, 0.1, 0.05, 0, -0.02, 0.0, 0.2, 0, 0, BR], ['c', 0.06, 0.06, 0.004, 0, 0.04, 0.302, Math.PI / 2, 0, 0, OR, 'g']] }),
  I({ id: 'orbe_lumiere', name: 'Orbe de lumière', cat: 'energie', rarity: 'rare', slot: 'back', effect: 'float',
    desc: 'Petite sphère lumineuse qui flotte au-dessus de ton épaule et éclaire la nuit.',
    parts: [['s', 0.06, 0.22, 0.32, -0.05, 0, 0, 0, 0xfff0a0, 'g'], ['t', 0.085, 0.006, 0.22, 0.32, -0.05, Math.PI / 2, 0, 0, GO, 'g']] }),
  I({ id: 'batterie_secours', name: 'Batterie de secours', cat: 'energie', rarity: 'commun', slot: 'back', passive: { stamina: 0.15 },
    desc: 'Batterie de sac à dos. Passif : endurance +15 % de récupération.',
    parts: [['b', 0.16, 0.22, 0.08, 0, -0.06, -0.17, 0, 0, 0, 0x2a2d33], ['b', 0.12, 0.03, 0.005, 0, 0.0, -0.212, 0, 0, 0, 0x2fd17a, 'g'], ['b', 0.04, 0.03, 0.03, 0.04, 0.07, -0.17, 0, 0, 0, R]] }),
  I({ id: 'bobine_statique', name: 'Bobine statique', cat: 'energie', rarity: 'peu', slot: 'hand', effect: 'zap',
    desc: 'Bobine de cuivre imaginaire. G : petits arcs bleus (visuel, sans danger).',
    parts: [['c', 0.035, 0.035, 0.16, 0, 0.03, 0.08, Math.PI / 2, 0, 0, 0xc86a2a, 'm'], ['t', 0.04, 0.008, 0, 0.03, 0.05, 0, 0, 0, 0xc86a2a, 'm'], ['t', 0.04, 0.008, 0, 0.03, 0.1, 0, 0, 0, 0xc86a2a, 'm'], ['s', 0.03, 0, 0.03, 0.18, 0, 0, 0, 0x7ad7ff, 'g']] }),
  I({ id: 'reacteur_poche', name: 'Réacteur de poche', cat: 'energie', rarity: 'legendaire', slot: 'back', passive: { stamina: 0.6 },
    desc: 'Le module d’énergie imaginaire ultime. Passif : endurance +60 % de récupération, tuyères lumineuses.',
    parts: [['b', 0.24, 0.3, 0.1, 0, -0.06, -0.18, 0, 0, 0, 0x30343a, 'm'], ['c', 0.04, 0.03, 0.08, 0.07, -0.25, -0.18, 0, 0, 0, SI, 'm'], ['c', 0.04, 0.03, 0.08, -0.07, -0.25, -0.18, 0, 0, 0, SI, 'm'], ['k', 0.03, 0.1, 0.07, -0.34, -0.18, Math.PI, 0, 0, OR, 'g'], ['k', 0.03, 0.1, -0.07, -0.34, -0.18, Math.PI, 0, 0, OR, 'g'], ['s', 0.04, 0, 0.0, -0.235, 0, 0, 0, CY, 'g']] }),

  // ---------------- SPÉCIAUX ----------------
  I({ id: 'recade', name: 'Récade royale (réplique)', cat: 'special', rarity: 'legendaire', slot: 'hand', effect: 'royal',
    desc: 'Réplique décorative d’une récade, bâton de messager des rois d’Abomey. G : lever la récade (étincelles dorées).',
    parts: [['c', 0.014, 0.016, 0.5, 0, 0, 0.2, Math.PI / 2, 0, 0, BR], ['b', 0.03, 0.12, 0.16, 0, 0.05, 0.48, 0, 0, 0, BR], ['b', 0.032, 0.03, 0.06, 0, 0.1, 0.53, 0, 0, 0, GO, 'm'], ['t', 0.018, 0.006, 0, 0, 0.1, 0, 0, 0, GO, 'm'], ['t', 0.018, 0.006, 0, 0, 0.3, 0, 0, 0, GO, 'm']] }),
  I({ id: 'masque_carnaval', name: 'Masque de carnaval', cat: 'special', rarity: 'rare', slot: 'head',
    desc: 'Masque de fête peint de couleurs vives pour les carnavals de Cotonou.',
    parts: [['e', 0.11, 0.13, 0.04, 0, 0.11, 0.1, 0, 0, 0, 0xe8c040], ['b', 0.035, 0.012, 0.01, 0.04, 0.13, 0.14, 0, 0, 0, K], ['b', 0.035, 0.012, 0.01, -0.04, 0.13, 0.14, 0, 0, 0, K], ['b', 0.16, 0.02, 0.01, 0, 0.18, 0.13, 0, 0, 0, R], ['b', 0.12, 0.015, 0.01, 0, 0.05, 0.135, 0, 0, 0, G], ['k', 0.03, 0.1, 0, 0.27, 0.08, 0, 0, 0, 0xff4fa0]] }),
  I({ id: 'tamtam_dore', name: 'Tam-tam doré', cat: 'special', rarity: 'epique', slot: 'hand', effect: 'drum',
    desc: 'Tambour décoré de fils dorés. G : joue un rythme (son réel du jeu).',
    parts: [['c', 0.11, 0.07, 0.3, 0, -0.08, 0.1, 0, 0, 0, BR], ['c', 0.112, 0.112, 0.01, 0, 0.075, 0.1, 0, 0, 0, 0xe8dcc0], ['t', 0.112, 0.008, 0, 0.065, 0.1, Math.PI / 2, 0, 0, GO, 'm'], ['t', 0.09, 0.008, 0, -0.08, 0.1, Math.PI / 2, 0, 0, GO, 'm']] }),
  I({ id: 'couronne_cauris', name: 'Couronne de cauris', cat: 'special', rarity: 'epique', slot: 'head',
    desc: 'Couronne ornée de cauris, coquillages longtemps utilisés comme monnaie et parure.',
    parts: [['c', 0.12, 0.12, 0.05, 0, 0.17, 0, 0, 0, 0, R, { open: true }], ...Array.from({ length: 10 }, (_, i) => { const a = (i / 10) * Math.PI * 2; return ['e', 0.016, 0.022, 0.01, Math.sin(a) * 0.125, 0.17, Math.cos(a) * 0.125, 0, a, 0, 0xf6efe0]; })] }),
  I({ id: 'pirogue_mini', name: 'Pirogue de Ganvié (miniature)', cat: 'special', rarity: 'rare', slot: 'hand', effect: 'show',
    desc: 'Miniature sculptée des pirogues de la cité lacustre. G : la montrer fièrement.',
    parts: [['e', 0.05, 0.03, 0.22, 0, 0.03, 0.08, 0, 0, 0, BR], ['b', 0.08, 0.004, 0.32, 0, 0.055, 0.08, 0, 0, 0, 0x4a2e18], ['c', 0.004, 0.004, 0.2, 0, 0.12, 0.12, 0.4, 0, 0, ST]] }),
  I({ id: 'trophee_dantokpa', name: 'Trophée de Dantokpa', cat: 'special', rarity: 'epique', slot: 'hand', effect: 'trophy',
    desc: 'Trophée du meilleur négociateur du grand marché. G : le brandir (confettis).',
    parts: [['b', 0.08, 0.04, 0.08, 0, 0.02, 0.0, 0, 0, 0, K], ['c', 0.015, 0.02, 0.1, 0, 0.09, 0, 0, 0, 0, GO, 'm'], ['c', 0.07, 0.025, 0.1, 0, 0.19, 0, 0, 0, 0, GO, 'm'], ['t', 0.04, 0.008, 0.07, 0.19, 0, 0, Math.PI / 2, 0, GO, 'm'], ['t', 0.04, 0.008, -0.07, 0.19, 0, 0, Math.PI / 2, 0, GO, 'm']] }),
  I({ id: 'cle_ville', name: 'Clé de la ville', cat: 'special', rarity: 'legendaire', slot: 'hand', effect: 'gold',
    desc: 'Clé dorée d’honneur de Cotonou, objet de collection. G : éclat doré.',
    parts: [['t', 0.05, 0.012, 0, 0.0, 0.02, 0, 0, 0, GO, 'm'], ['c', 0.012, 0.012, 0.25, 0, 0, 0.19, Math.PI / 2, 0, 0, GO, 'm'], ['b', 0.012, 0.05, 0.03, 0, -0.025, 0.28, 0, 0, 0, GO, 'm'], ['b', 0.012, 0.035, 0.02, 0, -0.018, 0.23, 0, 0, 0, GO, 'm'], ['s', 0.015, 0, 0.0, 0.02, 0, 0, 0, R, 'v']] }),
  I({ id: 'carte_tresor', name: 'Carte ancienne de la côte', cat: 'special', rarity: 'rare', slot: 'hand', effect: 'map',
    desc: 'Vieille carte décorative de la côte des Esclaves. G : ouvre la carte générale de la ville.',
    parts: [['c', 0.02, 0.02, 0.24, 0, 0.06, 0.06, 0, 0, Math.PI / 2, 0xe8d8a8], ['b', 0.22, 0.004, 0.16, 0, 0.04, 0.14, 0.2, 0, 0, 0xe8d8a8], ['c', 0.022, 0.022, 0.03, 0, 0.06, 0.06, 0, 0, Math.PI / 2, R]] }),
  I({ id: 'chapeau_plume', name: 'Chapeau à plume', cat: 'special', rarity: 'peu', slot: 'head',
    desc: 'Chapeau de cérémonie en feutre avec une longue plume.',
    parts: [['c', 0.11, 0.12, 0.1, 0, 0.21, 0, 0, 0, 0, 0x5a2a1a], ['c', 0.19, 0.19, 0.012, 0, 0.165, 0, 0, 0, 0, 0x5a2a1a], ['c', 0.122, 0.122, 0.025, 0, 0.18, 0, 0, 0, 0, Y], ['e', 0.012, 0.13, 0.03, 0.09, 0.3, -0.04, 0, 0, -0.5, R]] }),
  I({ id: 'drapeau', name: 'Drapeau du Bénin', cat: 'special', rarity: 'rare', slot: 'back', effect: 'flag',
    desc: 'Le drapeau national porté fièrement dans le dos. Il flotte au vent.',
    parts: [['c', 0.008, 0.008, 1.0, 0.1, 0.2, -0.17, 0, 0, 0, SI, 'm'], ['b', 0.14, 0.3, 0.004, 0.18, 0.55, -0.17, 0, 0, 0, G], ['b', 0.24, 0.15, 0.004, 0.37, 0.625, -0.17, 0, 0, 0, Y], ['b', 0.24, 0.15, 0.004, 0.37, 0.475, -0.17, 0, 0, 0, R]] }),
];

// ---------- construction des modèles 3D ----------
const SHAPE_ARGS = { b: 3, c: 3, s: 1, e: 3, t: 2, k: 2, d: 1 };
const MATS = {};
function mat(kind) {
  if (MATS[kind]) return MATS[kind];
  if (kind === 'g') MATS.g = new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false });
  else if (kind === 'm') MATS.m = new THREE.MeshStandardMaterial({ vertexColors: true, metalness: 0.75, roughness: 0.32 });
  else if (kind === 'v') MATS.v = new THREE.MeshStandardMaterial({ vertexColors: true, metalness: 0.1, roughness: 0.08, transparent: true, opacity: 0.82 });
  else MATS.n = new THREE.MeshStandardMaterial({ vertexColors: true, metalness: 0, roughness: 0.62 });
  return MATS[kind];
}
const _m = new THREE.Matrix4(), _q = new THREE.Quaternion(), _e = new THREE.Euler(), _p = new THREE.Vector3(), _s = new THREE.Vector3();

function shapeGeo(type, a, opt) {
  const seg = opt.seg || 14;
  switch (type) {
    case 'b': return new THREE.BoxGeometry(a[0], a[1], a[2]);
    case 'c': return new THREE.CylinderGeometry(a[0], a[1], a[2], seg, 1, !!opt.open);
    case 's': return new THREE.SphereGeometry(a[0], 14, 10);
    case 'e': return new THREE.SphereGeometry(1, 14, 10).scale(a[0], a[1], a[2]);
    case 't': return new THREE.TorusGeometry(a[0], a[1], 8, 20);
    case 'k': return new THREE.ConeGeometry(a[0], a[1], seg);
    case 'd': return new THREE.SphereGeometry(a[0], 16, 8, 0, Math.PI * 2, 0, Math.PI / 2);
  }
  return null;
}

// Renvoie un THREE.Group (un maillage par matériau) — les modèles sont mis en cache et clonés.
const cache = new Map();
export function buildItemModel(item) {
  if (!cache.has(item.id)) {
    const groups = {};
    for (const p of item.parts) {
      const type = p[0], n = SHAPE_ARGS[type];
      const a = p.slice(1, 1 + n), rest = p.slice(1 + n);
      const [x, y, z, rx, ry, rz, color] = rest;
      let opt = rest[7];
      opt = typeof opt === 'string' ? { f: opt } : opt || {};
      const g = shapeGeo(type, a, opt).toNonIndexed();
      if (opt.sc) g.scale(...opt.sc);
      _m.compose(_p.set(x, y, z), _q.setFromEuler(_e.set(rx || 0, ry || 0, rz || 0)), _s.set(1, 1, 1));
      g.applyMatrix4(_m);
      const c = new THREE.Color(color), cnt = g.attributes.position.count, col = new Float32Array(cnt * 3);
      for (let i = 0; i < cnt; i++) { col[i * 3] = c.r; col[i * 3 + 1] = c.g; col[i * 3 + 2] = c.b; }
      g.setAttribute('color', new THREE.BufferAttribute(col, 3));
      g.deleteAttribute('uv');
      const k = opt.f || 'n';
      (groups[k] = groups[k] || []).push(g);
    }
    const root = new THREE.Group();
    let tris = 0;
    for (const k in groups) {
      const geo = mergeGeometries(groups[k]);
      tris += geo.attributes.position.count / 3;
      const mesh = new THREE.Mesh(geo, mat(k));
      mesh.castShadow = k !== 'g';
      root.add(mesh);
    }
    root.userData.tris = tris;
    cache.set(item.id, root);
  }
  const src = cache.get(item.id);
  const clone = src.clone();
  clone.userData.tris = src.userData.tris;
  return clone;
}

export const ITEM_BY_ID = Object.fromEntries(ITEMS.map((it) => [it.id, it]));

// Ligne d'effet affichée dans la fiche (uniquement ce que le jeu fait réellement)
export function effectText(it) {
  if (it.passive) return `Passif : endurance +${Math.round(it.passive.stamina * 100)} % de récupération${it.passive.dayOnly ? ' (le jour)' : ''}`;
  if (it.slot === 'hand' && it.effect) return 'Touche G (ou bouton ✦) : utiliser';
  if (it.effect === 'tint') return 'Équipé : filtre ambré à l’écran';
  if (it.effect === 'float' || it.effect === 'flag') return 'Équipé : animation visible sur le personnage';
  return 'Objet porté : visible sur le personnage';
}
