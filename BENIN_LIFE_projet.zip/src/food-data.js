// Mission 013, étape 1 — catalogue alimentaire béninois (prix indicatifs du jeu en FCFA).
// kind : base (pâte, igname, riz… à servir avec une sauce), dish (plat complet), sauce, protein (accompagnement),
//        drink (boisson), fruit, snack (en-cas à manger tout de suite), ingredient (produit cru pour les recettes). hot = à réchauffer avant de manger.
// m = modèle 3D (voir buildFoodModel), c = couleur(s).
import { FOOD_MORE, CAT_OF, GASTRO_CATS, RECIPES_MORE } from './food-more.js';
export const FOOD_CATS = [
  { id: 'plats', label: 'Plats', kinds: ['base', 'dish'] },
  { id: 'sauces', label: 'Sauces & garnitures', kinds: ['sauce', 'protein'] },
  { id: 'boissons', label: 'Boissons', kinds: ['drink'] },
  { id: 'fruits', label: 'Fruits', kinds: ['fruit'] },
  { id: 'snacks', label: 'Pain & en-cas', kinds: ['snack'] },
  { id: 'ingredients', label: 'Produits frais & ingrédients', kinds: ['ingredient'] },
];

const FOOD_BASE = [
  // ---- bases (servies avec une sauce et une garniture au choix) ----
  { id: 'pate_rouge', name: 'Pâte rouge', kind: 'base', hot: true, hunger: 30, price: 300, m: 'pate', c: 0xc8562a, desc: 'Pâte de maïs à la tomate et à l’huile rouge.' },
  { id: 'pate_blanche', name: 'Pâte blanche', kind: 'base', hot: true, hunger: 30, price: 250, m: 'pate', c: 0xf2ecd8, desc: 'Pâte de farine de maïs, nature.' },
  { id: 'igname_pilee', name: 'Igname pilée (agoun)', kind: 'base', hot: true, hunger: 40, price: 500, m: 'pate', c: 0xf4f0e4, desc: 'Igname cuite puis pilée au mortier ; appelée agoun.' },
  { id: 'akassa', name: 'Akassa', kind: 'base', hot: false, hunger: 25, price: 100, m: 'akassa', c: 0xf0ead8, desc: 'Pâte de maïs fermentée, enveloppée dans une feuille.' },
  { id: 'gari', name: 'Gari', kind: 'base', hot: false, hunger: 20, price: 150, m: 'grain', c: 0xf2e6c4, desc: 'Semoule de manioc, à mouiller ou à mélanger à la sauce.' },
  { id: 'riz_blanc', name: 'Riz blanc', kind: 'base', hot: true, hunger: 30, price: 250, m: 'grain', c: 0xf6f4ee, desc: 'Riz nature, à servir avec une sauce.' },
  { id: 'ablo', name: 'Ablo', kind: 'base', hot: false, hunger: 20, price: 300, m: 'ablo', c: 0xfaf6ea, desc: 'Petites galettes vapeur de riz ou de maïs fermenté.' },
  // ---- plats complets ----
  { id: 'amiwo', name: 'Amiwo au poulet', kind: 'dish', hot: true, hunger: 55, price: 1500, m: 'pate', c: 0xc04a22, extra: 'chicken', desc: 'Pâte rouge de maïs cuite dans un bouillon de tomate, avec du poulet.' },
  { id: 'watche', name: 'Watché', kind: 'dish', hot: true, hunger: 45, price: 500, m: 'grain', c: 0x8a5a44, speck: 0x5a2a1a, desc: 'Riz et haricots cuits ensemble, à l’huile rouge.' },
  { id: 'atassi', name: 'Atassi', kind: 'dish', hot: true, hunger: 45, price: 500, m: 'grain', c: 0x9a6a4a, speck: 0xc8402a, desc: 'Riz-haricot servi avec piment et huile rouge.' },
  { id: 'riz_gras', name: 'Riz au gras', kind: 'dish', hot: true, hunger: 45, price: 700, m: 'grain', c: 0xd88a3a, speck: 0x6aa04a, desc: 'Riz cuit dans une sauce tomate, oignons et légumes.' },
  { id: 'riz_tomate', name: 'Riz sauce tomate', kind: 'dish', hot: true, hunger: 40, price: 600, m: 'grain', c: 0xf6f4ee, sauce: 0xc8301a, desc: 'Riz blanc nappé de sauce tomate.' },
  { id: 'haricots', name: 'Haricots préparés', kind: 'dish', hot: true, hunger: 35, price: 400, m: 'grain', c: 0x7a4a32, speck: 0x5a3020, desc: 'Haricots cuits aux oignons et à l’huile.' },
  { id: 'gari_sauce', name: 'Gari avec sauce', kind: 'dish', hot: false, hunger: 35, price: 300, m: 'grain', c: 0xf2e6c4, sauce: 0xc8402a, desc: 'Gari mélangé à une sauce tomate pimentée.' },
  { id: 'alloco', name: 'Alloco', kind: 'dish', hot: true, hunger: 25, price: 300, m: 'alloco', c: 0xe0962a, desc: 'Banane plantain frite.' },
  { id: 'akpan', name: 'Akpan', kind: 'drink', hot: false, hunger: 15, price: 300, m: 'cup', c: 0xf4ecd0, desc: 'Préparation fraîche et sucrée à base de maïs fermenté, servie froide.' },
  // ---- sauces ----
  { id: 'sauce_arachide', name: 'Sauce arachide', kind: 'sauce', hot: true, hunger: 12, price: 500, m: 'sauce', c: 0xb8722e, desc: 'Sauce à la pâte d’arachide.' },
  { id: 'sauce_tomate', name: 'Sauce tomate', kind: 'sauce', hot: true, hunger: 8, price: 300, m: 'sauce', c: 0xc8301a, desc: 'Tomates, oignons et piment.' },
  { id: 'sauce_legumes', name: 'Sauce légumes', kind: 'sauce', hot: true, hunger: 10, price: 400, m: 'sauce', c: 0x4a7a2a, desc: 'Sauce aux légumes verts.' },
  { id: 'sauce_gombo', name: 'Sauce gombo', kind: 'sauce', hot: true, hunger: 10, price: 400, m: 'sauce', c: 0x5a8a2a, desc: 'Sauce gluante au gombo.' },
  { id: 'sauce_feuille', name: 'Sauce feuille', kind: 'sauce', hot: true, hunger: 10, price: 500, m: 'sauce', c: 0x2f5a20, desc: 'Sauce aux feuilles vertes et à l’huile rouge.' },
  { id: 'sauce_pimentee', name: 'Sauce pimentée', kind: 'sauce', hot: false, hunger: 4, price: 200, m: 'sauce', c: 0xa81a10, desc: 'Piment écrasé, pour relever le plat.' },
  // ---- garnitures ----
  { id: 'wagashi', name: 'Fromage wagashi', kind: 'protein', hot: false, hunger: 12, price: 500, m: 'wagashi', c: 0xf4eedc, desc: 'Fromage peul à la croûte rouge.' },
  { id: 'poisson_grille', name: 'Poisson grillé', kind: 'protein', hot: true, hunger: 18, price: 1000, m: 'fish', c: 0x8a5a2a, desc: 'Poisson braisé au feu de bois.' },
  { id: 'poulet_grille', name: 'Poulet grillé', kind: 'protein', hot: true, hunger: 20, price: 1500, m: 'chicken', c: 0xa8602a, desc: 'Cuisses de poulet braisées.' },
  // ---- boissons ----
  { id: 'bissap', name: 'Jus de bissap', kind: 'drink', hot: false, hunger: 8, price: 200, m: 'bottle', c: 0x8a1030, desc: 'Infusion de fleurs d’hibiscus, servie très fraîche.' },
  { id: 'baobab', name: 'Jus de baobab', kind: 'drink', hot: false, hunger: 10, price: 300, m: 'bottle', c: 0xe8dcc0, desc: 'Boisson au fruit du baobab.' },
  { id: 'gingembre', name: 'Jus de gingembre', kind: 'drink', hot: false, hunger: 6, price: 200, m: 'bottle', c: 0xe8c860, desc: 'Gingembre frais pressé, bien relevé.' },
  { id: 'eau', name: 'Eau minérale', kind: 'drink', hot: false, hunger: 3, price: 250, m: 'bottle', c: 0xd8eef8, desc: 'Bouteille d’eau fraîche.' },
  // ---- produits de supermarché (mission 013, étape 3) ----
  { id: 'lait', name: 'Lait (brique)', kind: 'drink', hot: false, hunger: 10, price: 900, m: 'carton', c: 0x2f80ed, desc: 'Brique de lait UHT d’un litre.' },
  { id: 'jus_orange', name: 'Jus d’orange (brique)', kind: 'drink', hot: false, hunger: 8, price: 1200, m: 'carton', c: 0xf08a20, desc: 'Pur jus d’orange.' },
  { id: 'soda', name: 'Soda (canette)', kind: 'drink', hot: false, hunger: 4, price: 400, m: 'can', c: 0xc8102e, desc: 'Boisson gazeuse bien fraîche.' },
  { id: 'yaourt', name: 'Yaourt à boire', kind: 'drink', hot: false, hunger: 8, price: 350, m: 'cup', c: 0xf6e8f0, desc: 'Yaourt sucré à boire frais.' },
  { id: 'pain', name: 'Pain (baguette)', kind: 'snack', hot: false, hunger: 15, price: 200, m: 'bread', c: 0xd8a050, desc: 'Baguette du jour.' },
  { id: 'biscuits', name: 'Biscuits', kind: 'snack', hot: false, hunger: 8, price: 500, m: 'box', c: 0xf2c200, desc: 'Paquet de biscuits secs.' },
  { id: 'chocolat', name: 'Tablette de chocolat', kind: 'snack', hot: false, hunger: 6, price: 800, m: 'bar', c: 0x5a3a1a, desc: 'Chocolat au lait.' },
  { id: 'sardines', name: 'Sardines (boîte)', kind: 'protein', hot: false, hunger: 15, price: 600, m: 'tin', c: 0x9aa4ac, desc: 'Sardines à l’huile, à ajouter à une assiette.' },
  { id: 'spaghetti_sauce', name: 'Spaghetti sauce tomate', kind: 'dish', hot: true, hunger: 40, price: 900, m: 'pasta', c: 0xf2d890, desc: 'Spaghetti à la sauce tomate et aux oignons.' },
  // ---- fruits ----
  { id: 'mangue', name: 'Mangue', kind: 'fruit', hunger: 8, price: 200, m: 'mango', c: 0xf0a020, desc: 'Mangue bien mûre.' },
  { id: 'ananas', name: 'Ananas', kind: 'fruit', hunger: 12, price: 500, m: 'pineapple', c: 0xd8a030, desc: 'Ananas du Bénin, très sucré.' },
  { id: 'banane', name: 'Bananes', kind: 'fruit', hunger: 8, price: 150, m: 'banana', c: 0xf2d230, desc: 'Un petit régime de bananes douces.' },
  { id: 'orange', name: 'Oranges', kind: 'fruit', hunger: 6, price: 100, m: 'orange', c: 0xf08a20, desc: 'Oranges à presser ou à manger.' },
  { id: 'papaye', name: 'Papaye', kind: 'fruit', hunger: 10, price: 400, m: 'papaya', c: 0xe89a30, desc: 'Papaye fraîche.' },
  { id: 'coco', name: 'Noix de coco', kind: 'fruit', hunger: 8, price: 300, m: 'coco', c: 0x6a4a2a, desc: 'Eau et chair de coco.' },
  // ---- produits frais et ingrédients ----
  { id: 'farine_mais', name: 'Farine de maïs', kind: 'ingredient', price: 500, m: 'sack', c: 0xf2e2a0, desc: 'Pour les pâtes et l’amiwo.' },
  { id: 'riz', name: 'Riz (sac)', kind: 'ingredient', price: 600, m: 'sack', c: 0xf6f4ee, desc: 'Riz long grain.' },
  { id: 'haricots_secs', name: 'Haricots secs', kind: 'ingredient', price: 500, m: 'sack', c: 0x8a5a3a, desc: 'Niébé, pour le watché et les haricots.' },
  { id: 'igname', name: 'Igname', kind: 'ingredient', price: 800, m: 'yam', c: 0x6a4a2a, desc: 'Tubercule à cuire puis piler.' },
  { id: 'plantain', name: 'Bananes plantain', kind: 'ingredient', price: 300, m: 'banana', c: 0x9ab82a, desc: 'À frire pour l’alloco.' },
  { id: 'tomate', name: 'Tomates', kind: 'ingredient', price: 300, m: 'heap', c: 0xd82a1a, desc: 'Un tas de tomates fraîches.' },
  { id: 'oignon', name: 'Oignons', kind: 'ingredient', price: 200, m: 'heap', c: 0xc89a6a, desc: 'Oignons rouges.' },
  { id: 'piment', name: 'Piments', kind: 'ingredient', price: 100, m: 'chili', c: 0xd81a10, desc: 'Petits piments forts.' },
  { id: 'gombo', name: 'Gombo', kind: 'ingredient', price: 300, m: 'okra', c: 0x5a9a2a, desc: 'Gombo frais pour la sauce.' },
  { id: 'feuilles', name: 'Légumes feuilles', kind: 'ingredient', price: 200, m: 'leaves', c: 0x2f7a2a, desc: 'Feuilles vertes pour la sauce feuille.' },
  { id: 'huile_rouge', name: 'Huile rouge', kind: 'ingredient', price: 600, m: 'oil', c: 0xd8461a, desc: 'Huile de palme.' },
  { id: 'arachide', name: 'Pâte d’arachide', kind: 'ingredient', price: 400, m: 'jar', c: 0xb8722e, desc: 'Pour la sauce arachide.' },
  { id: 'poisson_frais', name: 'Poisson frais', kind: 'ingredient', price: 1500, m: 'fish', c: 0x9aa4ac, desc: 'À griller ou à mettre dans la sauce.' },
  { id: 'poulet_frais', name: 'Poulet', kind: 'ingredient', price: 3000, m: 'chicken', c: 0xf0d0b8, desc: 'Poulet entier découpé.' },
  { id: 'spaghetti', name: 'Spaghetti (paquet)', kind: 'ingredient', price: 450, m: 'box', c: 0x1f4e9c, desc: 'Paquet de 500 g.' },
  { id: 'concentre_tomate', name: 'Concentré de tomate', kind: 'ingredient', price: 250, m: 'tin', c: 0xd82a1a, desc: 'Petite boîte de concentré.' },
  { id: 'sucre', name: 'Sucre (sachet)', kind: 'ingredient', price: 600, m: 'sack', c: 0xffffff, desc: 'Sucre en poudre.' },
  { id: 'oeufs', name: 'Œufs (6)', kind: 'ingredient', price: 600, m: 'eggs', c: 0xf2e8d8, desc: 'Une demi-plaquette d’œufs.' },
];
const RENAME = { pate_blanche: 'Wɔ̌ (pâte blanche)', poisson_grille: 'Poisson braisé', haricots: 'Haricots préparés' };
export const FOOD = [...FOOD_BASE.map((f) => ({ ...f, name: RENAME[f.id] || f.name, cat: CAT_OF[f.id] || 'transfo' })), ...FOOD_MORE];
export const FOOD_BY_ID = Object.fromEntries(FOOD.map((f) => [f.id, f]));
export { GASTRO_CATS };
// stock disponible en magasin (unités, réassort chaque matin) : produits secs abondants, plats et produits frais limités
export const stockOf = (f) => (f.kind === 'ingredient' ? (f.cat === 'mer' || f.cat === 'viande' ? 8 : 20) : f.kind === 'drink' ? 24 : f.kind === 'fruit' ? 16 : f.kind === 'snack' ? 18 : 10);

// Recettes réalisables à la cuisinière : ingrédients consommés → portions ajoutées au réfrigérateur.
export const RECIPES = [
  { id: 'r_pate_rouge', out: 'pate_rouge', n: 3, time: 7, need: { farine_mais: 1, tomate: 1, huile_rouge: 1 } },
  { id: 'r_pate_blanche', out: 'pate_blanche', n: 3, time: 6, need: { farine_mais: 1 } },
  { id: 'r_amiwo', out: 'amiwo', n: 3, time: 9, need: { farine_mais: 1, tomate: 1, poulet_frais: 1 } },
  { id: 'r_igname', out: 'igname_pilee', n: 3, time: 8, need: { igname: 1 } },
  { id: 'r_riz', out: 'riz_blanc', n: 3, time: 6, need: { riz: 1 } },
  { id: 'r_riz_gras', out: 'riz_gras', n: 3, time: 8, need: { riz: 1, tomate: 1, oignon: 1 } },
  { id: 'r_watche', out: 'watche', n: 3, time: 9, need: { riz: 1, haricots_secs: 1, huile_rouge: 1 } },
  { id: 'r_atassi', out: 'atassi', n: 3, time: 9, need: { riz: 1, haricots_secs: 1, piment: 1 } },
  { id: 'r_haricots', out: 'haricots', n: 3, time: 7, need: { haricots_secs: 1, oignon: 1 } },
  { id: 'r_sauce_tomate', out: 'sauce_tomate', n: 3, time: 5, need: { tomate: 1, oignon: 1 } },
  { id: 'r_sauce_arachide', out: 'sauce_arachide', n: 3, time: 6, need: { arachide: 1, tomate: 1 } },
  { id: 'r_sauce_gombo', out: 'sauce_gombo', n: 3, time: 6, need: { gombo: 1, tomate: 1 } },
  { id: 'r_sauce_feuille', out: 'sauce_feuille', n: 3, time: 6, need: { feuilles: 1, huile_rouge: 1 } },
  { id: 'r_sauce_legumes', out: 'sauce_legumes', n: 3, time: 6, need: { feuilles: 1, tomate: 1, oignon: 1 } },
  { id: 'r_sauce_pimentee', out: 'sauce_pimentee', n: 4, time: 3, need: { piment: 1, tomate: 1 } },
  { id: 'r_poisson', out: 'poisson_grille', n: 1, time: 5, need: { poisson_frais: 1 } },
  { id: 'r_poulet', out: 'poulet_grille', n: 3, time: 7, need: { poulet_frais: 1 } },
  { id: 'r_spaghetti', out: 'spaghetti_sauce', n: 3, time: 7, need: { spaghetti: 1, concentre_tomate: 1, oignon: 1 } },
  { id: 'r_alloco', out: 'alloco', n: 2, time: 4, need: { huile_rouge: 1, plantain: 1 } },
  ...RECIPES_MORE,
];

export const fcfa = (n) => `${Math.round(n).toLocaleString('fr-FR').replace(/ | /g, ' ')} FCFA`;
