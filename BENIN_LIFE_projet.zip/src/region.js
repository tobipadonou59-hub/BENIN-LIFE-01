// Mission 013, étape 6 — région de Cotonou : RNIE 1 vers Cocotomey, Pahou, Ouidah et vers Porto-Novo (tracés
// OpenStreetMap), villes générées autour de leur centre réel, panneaux d'entrée, habitations et cocotiers le long
// de la route. Les villes et le bord de route sont chargés à l'approche et libérés au loin (streaming).
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { MAP } from './world.js';
import { REGION, TOWNS, coastZ, inLake, nearRoad, nearestOnRoad } from './region-geo.js';

const PI = Math.PI;
function mulberry(a) { return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
function colored(geo, hex) {
  const g = geo.index ? geo.toNonIndexed() : geo, c = new THREE.Color(hex), n = g.attributes.position.count, a = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { a[i * 3] = c.r; a[i * 3 + 1] = c.g; a[i * 3 + 2] = c.b; }
  g.setAttribute('color', new THREE.BufferAttribute(a, 3)); if (g.attributes.uv) g.deleteAttribute('uv'); return g;
}
const WALLS = [0xe8dcc8, 0xd8c8a8, 0xf0e0d0, 0xc8d8c8, 0xe0c8b8, 0xd0d8e0, 0xf2eee6, 0xe8c8a0, 0xf0d8b0];
const ROOFS = [0x9a4a32, 0x7a7a78, 0xa85a3a, 0x5a6a7a, 0x8a8a86, 0xb0b4b8];
const okLand = (x, z, m = 8) => z < coastZ(x) - m && !inLake(x, z) && !inLake(x + m, z) && !inLake(x - m, z) && !inLake(x, z + m) && !inLake(x, z - m);
const inCity = (x, z) => x > -320 && x < 320 && z > -320 && z < 220;
const inAirport = (x, z) => x > -2280 && x < -370 && z > -140 && z < 230;

export class Region {
  constructor({ scene, world, quality }) {
    this.scene = scene; this.world = world; this.quality = quality;
    this.mat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.85 });
    this.openCityWalls();
    this.buildRoads();
    this.towns = TOWNS.map((t, i) => this.planTown(t, i));
    this.side = this.planRoadside();
    this.live = new Map(); // id → mesh
  }

  // la région entoure maintenant la ville : les murs invisibles nord, est et ouest sont retirés
  // (le mur de la mer est conservé ; la mer et les lacs sont gérés par landClamp)
  openCityWalls() {
    for (const o of this.world.collision.objects) if (o.invisible && !o.disabled && o.t === 0 && o.maxZ < 500 && !(o.minZ >= 180)) o.disabled = true;
  }

  // ---- RNIE 1 : chaussée, bandes de rive, pointillés ----
  buildRoads() {
    const parts = [], marks = [];
    const ribbon = (pts, half, y, hex, arr, dash = 0) => {
      const n = pts.length, nx = [], nz = [];
      for (let i = 0; i < n; i++) {
        const a = pts[Math.max(0, i - 1)], b = pts[Math.min(n - 1, i + 1)], dx = b[0] - a[0], dz = b[1] - a[1], l = Math.hypot(dx, dz) || 1;
        nx.push(-dz / l); nz.push(dx / l);
      }
      for (let i = 0; i < n - 1; i++) {
        const [ax, az] = pts[i], [bx, bz] = pts[i + 1], L = Math.hypot(bx - ax, bz - az);
        const seg = (u0, u1) => {
          const p0 = [ax + (bx - ax) * u0, az + (bz - az) * u0], p1 = [ax + (bx - ax) * u1, az + (bz - az) * u1];
          const n0 = [nx[i] + (nx[i + 1] - nx[i]) * u0, nz[i] + (nz[i + 1] - nz[i]) * u0], n1 = [nx[i] + (nx[i + 1] - nx[i]) * u1, nz[i] + (nz[i + 1] - nz[i]) * u1];
          const g = new THREE.BufferGeometry();
          const v = [p0[0] - n0[0] * half, y, p0[1] - n0[1] * half, p0[0] + n0[0] * half, y, p0[1] + n0[1] * half, p1[0] + n1[0] * half, y, p1[1] + n1[1] * half,
            p0[0] - n0[0] * half, y, p0[1] - n0[1] * half, p1[0] + n1[0] * half, y, p1[1] + n1[1] * half, p1[0] - n1[0] * half, y, p1[1] - n1[1] * half];
          g.setAttribute('position', new THREE.Float32BufferAttribute(v, 3)); g.computeVertexNormals();
          if (g.attributes.normal.array[1] < 0) { for (let k = 0; k < v.length; k += 9) { const t = [v[k + 3], v[k + 4], v[k + 5]]; v[k + 3] = v[k + 6]; v[k + 4] = v[k + 7]; v[k + 5] = v[k + 8]; v[k + 6] = t[0]; v[k + 7] = t[1]; v[k + 8] = t[2]; } g.setAttribute('position', new THREE.Float32BufferAttribute(v, 3)); g.computeVertexNormals(); }
          arr.push(colored(g, hex));
        };
        if (!dash) seg(0, 1);
        else for (let s = 0; s < L; s += dash * 2) seg(s / L, Math.min(1, (s + dash) / L));
      }
    };
    const shift = (pts, off) => pts.map((p, i) => { const a = pts[Math.max(0, i - 1)], b = pts[Math.min(pts.length - 1, i + 1)], dx = b[0] - a[0], dz = b[1] - a[1], l = Math.hypot(dx, dz) || 1; return [p[0] - dz / l * off, p[1] + dx / l * off]; });
    for (const r of REGION.roads) {
      ribbon(r.pts, 8.5, 0.025, 0xb89a6a, parts);          // accotements en terre
      ribbon(r.pts, 6.2, 0.045, 0x3c3e42, parts);          // chaussée
      for (const s of [-5.6, 5.6]) ribbon(shift(r.pts, s), 0.14, 0.055, 0xe8e8e8, marks);
      ribbon(r.pts, 0.12, 0.056, 0xf0f0f0, marks, 4);      // ligne médiane discontinue
    }
    const road = new THREE.Mesh(mergeGeometries(parts), new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.95 }));
    const mk = new THREE.Mesh(mergeGeometries(marks), new THREE.MeshBasicMaterial({ vertexColors: true, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -4 }));
    road.receiveShadow = true; road.frustumCulled = false; mk.frustumCulled = false;
    this.roadMeshes = [road, mk]; this.scene.add(road, mk);
  }

  // ---- villes : quartiers en damier orientés comme la route, autour du centre réel ----
  planTown(t, idx) {
    const R = mulberry(9100 + idx * 77), np = nearestOnRoad(t.x, t.z), ang = np ? np.h : 0, c = Math.cos(ang), s = Math.sin(ang);
    const houses = [], streets = [], step = 34;
    const col = this.world.collision;
    for (let u = -t.r; u <= t.r; u += step) for (let v = -t.r; v <= t.r; v += step) {
      // repère local (u le long de la route, v en travers)
      const bx = t.x + u * s + v * c, bz = t.z + u * c - v * s, dc = Math.hypot(u, v);
      if (dc > t.r) continue;
      if (dc < t.r * 0.95 && okLand(bx, bz, 4)) streets.push({ x: bx, z: bz });
      const dens = dc < t.r * 0.35 ? 0.95 : dc < t.r * 0.7 ? 0.75 : 0.45;
      for (const [du, dv] of [[-8, -8], [8, -8], [-8, 8], [8, 8]]) {
        if (R() > dens) continue;
        const x = bx + (du * s + dv * c), z = bz + (du * c - dv * s);
        if (!okLand(x, z, 10) || nearRoad(x, z) || inCity(x, z) || inAirport(x, z)) continue;
        const w = 7 + R() * 6, d = 7 + R() * 6, center = dc < t.r * 0.3;
        const h = center && R() < 0.5 ? 6 + Math.floor(R() * 3) * 3 : 3 + R() * 1.5;
        const hh = { x, z, w, d, h, ry: ang + (R() - 0.5) * 0.06, wall: WALLS[(R() * WALLS.length) | 0], roof: ROOFS[(R() * ROOFS.length) | 0], shop: center && R() < 0.4 };
        const e = Math.max(w, d) * 0.5; hh.col = col.addBox(x - e * 0.8, z - e * 0.8, x + e * 0.8, z + e * 0.8, h); houses.push(hh);
      }
    }
    const palms = [];
    for (let k = 0; k < t.r / 6; k++) { const a = R() * PI * 2, rr = t.r * (0.3 + R() * 0.9), x = t.x + Math.cos(a) * rr, z = t.z + Math.sin(a) * rr; if (okLand(x, z, 4) && !nearRoad(x, z) && !inCity(x, z)) palms.push({ x, z, h: 7 + R() * 6 }); }
    // panneaux d'entrée : là où la route traverse le cercle de la ville
    const signs = [];
    for (const r of REGION.roads) for (let i = 0; i < r.pts.length - 1; i++) {
      const [ax, az] = r.pts[i], [bx, bz] = r.pts[i + 1], da = Math.hypot(ax - t.x, az - t.z), db = Math.hypot(bx - t.x, bz - t.z);
      if ((da > t.r) !== (db > t.r)) { const k = (t.r - da) / (db - da); signs.push({ x: ax + (bx - ax) * k, z: az + (bz - az) * k, h: Math.atan2(bx - ax, bz - az), inward: da > t.r }); }
    }
    return { ...t, id: 'town:' + t.name, houses, streets, palms, signs, ang };
  }
  // habitations et cocotiers épars le long de la route, par tronçons de 600 m
  planRoadside() {
    const R = mulberry(4242), chunks = [];
    REGION.roads.forEach((r, ri) => {
      let acc = 0, cur = null;
      for (let i = 0; i < r.pts.length - 1; i++) {
        const [ax, az] = r.pts[i], [bx, bz] = r.pts[i + 1], L = Math.hypot(bx - ax, bz - az), nx = -(bz - az) / L, nz = (bx - ax) / L;
        for (let s = 0; s < L; s += 22) {
          const px = ax + (bx - ax) * s / L, pz = az + (bz - az) * s / L;
          if (!cur || acc + s - cur.s0 > 600) { cur = { id: `side:${ri}:${chunks.length}`, s0: acc + s, x: px, z: pz, items: [] }; chunks.push(cur); }
          if (TOWNS.some((t) => Math.hypot(px - t.x, pz - t.z) < t.r + 40) || inCity(px, pz)) continue;
          for (const sd of [-1, 1]) {
            const k = R();
            const off = sd * (20 + R() * 70), x = px + nx * off, z = pz + nz * off;
            if (!okLand(x, z, 6) || nearRoad(x, z) || inAirport(x, z) || inCity(x, z)) continue;
            if (k < 0.22) cur.items.push({ t: 'h', x, z, w: 6 + R() * 6, d: 6 + R() * 6, h: 3 + R() * 1.5, ry: Math.atan2(bx - ax, bz - az), wall: WALLS[(R() * WALLS.length) | 0], roof: ROOFS[(R() * ROOFS.length) | 0] });
            else if (k < 0.6) cur.items.push({ t: 'p', x, z, h: 7 + R() * 7, palm: R() < 0.75 });
          }
        }
        acc += L;
      }
    });
    return chunks;
  }

  // ---- construction des maillages (à la demande) ----
  houseParts(h, parts) {
    const m = new THREE.Matrix4().makeRotationY(h.ry).setPosition(h.x, 0, h.z);
    parts.push(colored(new THREE.BoxGeometry(h.w, h.h, h.d).translate(0, h.h / 2, 0).applyMatrix4(m), h.wall));
    parts.push(colored(new THREE.BoxGeometry(h.w + 0.6, 0.35, h.d + 0.6).translate(0, h.h + 0.17, 0).applyMatrix4(m), h.roof));
    parts.push(colored(new THREE.BoxGeometry(1.1, 2.1, 0.1).translate(0, 1.05, h.d / 2 + 0.03).applyMatrix4(m), 0x5a3a22)); // porte
    for (const sx of [-h.w / 4, h.w / 4]) parts.push(colored(new THREE.BoxGeometry(1.1, 1.0, 0.1).translate(sx, 1.7, h.d / 2 + 0.03).applyMatrix4(m), 0x2a3a44));
    if (h.h > 5.5) for (let f = 1; f * 3 < h.h - 1; f++) for (const sx of [-h.w / 4, h.w / 4]) parts.push(colored(new THREE.BoxGeometry(1.1, 1.0, 0.1).translate(sx, 1.7 + f * 3, h.d / 2 + 0.03).applyMatrix4(m), 0x2a3a44));
    if (h.shop) parts.push(colored(new THREE.BoxGeometry(h.w * 0.8, 0.12, 1.6).translate(0, 2.6, h.d / 2 + 0.8).applyMatrix4(m), [0xc8102e, 0x0b6e4f, 0xf2c200, 0x1f4e9c][(h.x * 7 | 0) & 3]));
  }
  palmParts(p, parts) {
    parts.push(colored(new THREE.CylinderGeometry(0.18, 0.3, p.h, 5).translate(p.x, p.h / 2, p.z), 0x6a5236));
    parts.push(colored(p.palm === false ? new THREE.SphereGeometry(2.6, 7, 5).translate(p.x, p.h + 0.8, p.z) : new THREE.ConeGeometry(3.2, 1.6, 7).translate(p.x, p.h + 0.3, p.z), p.palm === false ? 0x2f6a2a : 0x3f7a2a));
  }
  signTex(t) {
    const c = document.createElement('canvas'); c.width = 512; c.height = 192; const x = c.getContext('2d');
    x.fillStyle = '#f4f4f0'; x.fillRect(0, 0, 512, 192); x.strokeStyle = '#c8102e'; x.lineWidth = 14; x.strokeRect(7, 7, 498, 178);
    x.fillStyle = '#111'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.font = '900 70px Arial'; x.fillText(t.name.toUpperCase(), 256, 80);
    x.font = '700 26px Arial'; x.fillStyle = '#333'; x.fillText(t.sub, 256, 145);
    const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace; return tex;
  }
  buildTown(t) {
    const parts = [];
    for (const h of t.houses) this.houseParts(h, parts);
    for (const p of t.palms) this.palmParts(p, parts);
    for (const st of t.streets) parts.push(colored(new THREE.PlaneGeometry(34, 34).rotateX(-PI / 2).rotateY(t.ang).translate(st.x, 0.015, st.z), 0xb08050));
    const g = new THREE.Group();
    const mesh = new THREE.Mesh(mergeGeometries(parts), this.mat); mesh.castShadow = true; mesh.receiveShadow = true; g.add(mesh);
    const mat = new THREE.MeshBasicMaterial({ map: this.signTex(t), toneMapped: false });
    for (const sg of t.signs) {
      const side = 9.5, nx = Math.cos(sg.h), nz = -Math.sin(sg.h), x = sg.x + nx * side, z = sg.z + nz * side;
      const p = new THREE.Mesh(new THREE.PlaneGeometry(4, 1.5), mat); p.position.set(x, 2.6, z); p.rotation.y = sg.h + (sg.inward ? PI : 0); g.add(p);
      const back = new THREE.Mesh(new THREE.PlaneGeometry(4, 1.5), new THREE.MeshStandardMaterial({ color: 0x8a8f96 })); back.position.set(x, 2.6, z); back.rotation.y = sg.h + (sg.inward ? 0 : PI); g.add(back);
      const rot = sg.h + (sg.inward ? PI : 0);
      for (const k of [-1.6, 1.6]) { const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 2.6, 6), back.material); pole.position.set(x + Math.cos(rot) * k, 1.3, z - Math.sin(rot) * k); g.add(pole); }
    }
    return g;
  }
  buildSide(ch) {
    const parts = [];
    for (const it of ch.items) { if (it.t === 'h') this.houseParts(it, parts); else this.palmParts(it, parts); }
    if (!parts.length) return new THREE.Group();
    const m = new THREE.Mesh(mergeGeometries(parts), this.mat); m.castShadow = true; m.receiveShadow = true; return m;
  }

  // ---- chargement / libération selon la distance ----
  update(focus) {
    const want = (id, x, z, rIn, rOut, make) => {
      const d = Math.hypot(focus.x - x, focus.z - z), has = this.live.get(id);
      if (!has && d < rIn) { const m = make(); this.scene.add(m); this.live.set(id, m); }
      else if (has && d > rOut) { this.scene.remove(has); has.traverse((o) => { if (o.geometry) o.geometry.dispose(); if (o.material && o.material !== this.mat) { if (o.material.map) o.material.map.dispose(); o.material.dispose(); } }); this.live.delete(id); }
    };
    for (const t of this.towns) want(t.id, t.x, t.z, t.r + 1300, t.r + 1700, () => this.buildTown(t));
    for (const ch of this.side) want(ch.id, ch.x, ch.z, 1200, 1600, () => this.buildSide(ch));
  }
}
