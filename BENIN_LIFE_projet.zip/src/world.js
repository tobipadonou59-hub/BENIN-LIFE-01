// Construction procédurale d'un quartier inspiré de Cotonou.
// Toutes les géométries statiques sont fusionnées par matériau (peu d'appels de rendu).
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import * as T from './textures.js';
import { mulberry32, pick } from './util.js';
import { CollisionWorld } from './collision.js';
import { AI } from './assets.js';
import { addMacroVariation } from './shaderfx.js';
import { buildVegetation } from './vegetation.js';
import { createAmazoneStatue, amazoneSigns } from './monuments.js';
import { Home } from './home.js';

export const LINES_X = [-100, 0, 100];
export const LINES_Z = [-100, 0, 100, 152];
export const ROAD_HALF = 7;
export const SIDEWALK = 3;
export const MAP = { minX: -160, maxX: 160, minZ: -160, maxZ: 159 };
// limites de déplacement au sol (la ville + la route et l'aéroport à l'ouest ; les murs invisibles font le reste)
export const BOUNDS = { minX: -9000, maxX: 6200, minZ: -3900, maxZ: 159 }; // mission 013 étape 6 : toute la région (voir region-geo.js)
export const BEACH_Z = 159;
// Mission 012 : parcelle du garage AUTO CONCEPT (Quartier Jéricho, au bord du boulevard)
export const GARAGE_LOT = { x0: -62, x1: -22, z0: -142, z1: -110 };
// Mission 013, étape 3 : parcelle du supermarché fictif LAGUNA (même boulevard, côté est)
export const SUPER_LOT = { x0: 22, x1: 62, z0: -142, z1: -110 };
// Mission 014 : siège de NOVA BOOK (quartier d'affaires, au bord du boulevard central z = 0)
export const NOVA_LOT = { x0: 38, x1: 90, z0: 10, z1: 58 };
export const SEA_Z = 192;
export const ROUND_R = 21;
export const ISLAND_R = 8;

const PI = Math.PI;
const _m = new THREE.Matrix4(), _q = new THREE.Quaternion(), _e = new THREE.Euler(), _v = new THREE.Vector3(), _s = new THREE.Vector3();

function M(x, y, z, ry = 0, rx = 0, rz = 0, sx = 1, sy = 1, sz = 1) {
  _e.set(rx, ry, rz, 'YXZ');
  return new THREE.Matrix4().compose(_v.set(x, y, z).clone(), _q.setFromEuler(_e).clone(), _s.set(sx, sy, sz).clone());
}

// Boîte dont les UV sont exprimés en mètres / taille de tuile (pour façades raccordées)
function boxUV(w, h, d, su, sv) {
  const g = new THREE.BoxGeometry(w, h, d);
  const uv = g.attributes.uv;
  const dims = [[d, h], [d, h], [w, d], [w, d], [w, h], [w, h]];
  for (let f = 0; f < 6; f++) for (let k = 0; k < 4; k++) {
    const i = f * 4 + k;
    uv.setXY(i, uv.getX(i) * dims[f][0] / su, uv.getY(i) * dims[f][1] / sv);
  }
  return g;
}

function planeUV(w, d, su, sv) {
  const g = new THREE.PlaneGeometry(w, d);
  g.rotateX(-PI / 2);
  const uv = g.attributes.uv;
  for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * w / su, uv.getY(i) * d / sv);
  return g;
}

export function buildWorld(scene, quality) {
  const R = mulberry32(1960);
  const col = new CollisionWorld(16);
  const batches = new Map();
  const nightMats = []; // matériaux dont l'émission s'allume la nuit
  const dyn = { flags: [] };

  // ---------- Matériaux ----------
  const std = (o) => new THREE.MeshStandardMaterial({ roughness: 0.9, metalness: 0, ...o });
  const paveT = T.paveHD(), sandT = T.sandHD();
  const mats = {
    asphalt: addMacroVariation(std({ ...AI.asphalt(), color: 0xb8b4ae, roughness: 0.95, envMapIntensity: 0.35 }), 0.012, 0.22, null, 1),
    pave: addMacroVariation(std({ ...paveT, roughness: 0.95 }), 0.015, 0.2, 0xb0623a, 0.85),
    laterite: addMacroVariation(std({ ...AI.laterite(), color: 0xc9a48c, roughness: 1, envMapIntensity: 0.4 }), 0.01, 0.28, 0x8a5a3a, 0.7),
    sidewalk: addMacroVariation(std({ ...AI.sidewalk(), color: 0xcfc4b0, roughness: 1, envMapIntensity: 0.4 }), 0.02, 0.2, 0xb8714a, 0.85),
    grass: addMacroVariation(std({ map: T.grassHD(), roughness: 1 }), 0.015, 0.3, 0xb0a050, 0.25),
    sand: addMacroVariation(std({ ...sandT, color: 0xfff0d8, roughness: 1, envMapIntensity: 0.4 }), 0.01, 0.15, null, 0.2),
    curb: std({ color: 0xc9c3b8 }),
    gutter: std({ map: T.gutter(), roughness: 1 }),
    sandEdge: new THREE.MeshStandardMaterial({ map: T.sandEdge(), transparent: true, depthWrite: false, roughness: 1, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -2 }),
    curbRW: std({ map: T.stripes('#c8102e', '#f2f2f2', 16) }),
    markW: std({ color: 0xe8e6de, roughness: 0.75 }),
    markY: std({ color: 0xe8b800, roughness: 0.75 }),
    roofConcrete: std({ map: T.roofConcrete() }),
    roofTin: std({ map: T.roofTin(), metalness: 0.5, roughness: 0.55 }),
    tinRed: std({ map: T.roofTin(), color: 0xb04a32, metalness: 0.35, roughness: 0.6 }),
    tinGreen: std({ map: T.roofTin(), color: 0x4f8a5a, metalness: 0.35, roughness: 0.6 }),
    tinBlue: std({ map: T.roofTin(), color: 0x4a6a9a, metalness: 0.35, roughness: 0.6 }),
    rebar: std({ color: 0x3a2a22, metalness: 0.6, roughness: 0.6 }),
    concrete: std({ color: 0xa8a39a }),
    trim: std({ color: 0xf1ece2, roughness: 0.8 }),
    tank: std({ color: 0x1b1b1b, roughness: 0.5 }),
    railing: std({ color: 0xe8e4dc, roughness: 0.6 }),
    claustra: std({ map: T.claustra(), color: 0xe6dccb, alphaTest: 0.5, side: THREE.DoubleSide }),
    balustrade: std({ map: T.balustrade(), alphaTest: 0.5, side: THREE.DoubleSide }),
    acUnit: std({ map: T.acUnit(), roughness: 0.6 }),
    mural: std({ map: T.muralAtlas(), roughness: 0.9 }),
    door: std({ color: 0x4a3322, roughness: 0.8 }),
    wood: std({ color: 0x7b5a3a }),
    plastic: std({ color: 0xf2f2ee, roughness: 0.5 }),
    plasticR: std({ color: 0xc8202a, roughness: 0.5 }),
    pole: std({ color: 0x5a4632 }),
    metal: std({ color: 0x55585c, metalness: 0.6, roughness: 0.45 }),
    lampHead: std({ color: 0xdddddd, emissive: new THREE.Color(0xffd9a0), emissiveIntensity: 0 }),
    bottle: new THREE.MeshStandardMaterial({ color: 0xe0a800, roughness: 0.15, transparent: true, opacity: 0.8 }),
    bronze: std({ color: 0x8a6a3a, metalness: 0.8, roughness: 0.35 }),
    stone: std({ color: 0xd8d2c4 }),
    white: std({ color: 0xf2f2f0 }),
    trunk: std({ map: T.bark() }),
    sign: std({ map: null, roughness: 0.6, emissive: new THREE.Color(0xffffff), emissiveIntensity: 0 }),
  };
  const atlas = T.signAtlas();
  mats.sign.map = atlas.texture;
  mats.sign.emissiveMap = atlas.texture;
  nightMats.push({ mat: mats.sign, max: 0.35 });
  nightMats.push({ mat: mats.lampHead, max: 3.0 });

  const FACADES = [
    ['#e9dfc8', '#2f6fa7'], ['#e7b95a', '#3a6b3a'], ['#9fc4d6', '#ffffff'], ['#e59a7f', '#2b4f7a'],
    ['#f1efe9', '#3f7f6a'], ['#a8d3a4', '#7a4a2a'], ['#c96a45', '#efe6d4'], ['#c9b8d8', '#2f5f8f'],
    ['#f3d9a0', '#a33a2a'], ['#d6d1c4', '#1f5b9c'],
  ];
  FACADES.forEach(([b, s], i) => {
    const f = T.facade(b, s, 100 + i);
    mats['facade' + i] = std({ map: f.map, normalMap: f.normalMap, normalScale: new THREE.Vector2(1.2, 1.2), roughness: 0.92, emissiveMap: f.emissive, emissive: new THREE.Color(0xffffff), emissiveIntensity: 0 });
    nightMats.push({ mat: mats['facade' + i], max: 0.55 });
  });
  const WALLS = ['#e8e0cc', '#d9c27a', '#b9cfd6', '#e6b8a2'];
  WALLS.forEach((c, i) => (mats['wall' + i] = std({ map: T.wall(c) })));
  const GATES = [0x1f5b9c, 0x2e7d4f, 0x9c2b2b, 0x6a4a2a];
  GATES.forEach((c, i) => (mats['gate' + i] = std({ color: c, metalness: 0.4, roughness: 0.5 })));
  const AWN = [0xc8102e, 0x1f4e9c, 0x0b8a4f, 0xf2b400, 0xe46a1f];
  const tinTex = mats.roofTin.map;
  AWN.forEach((c, i) => (mats['awn' + i] = std({ map: tinTex, color: c, metalness: 0.3, roughness: 0.6 })));
  for (let i = 0; i < 3; i++) mats['shop' + i] = std({ map: T.shopfront(200 + i), emissive: new THREE.Color(0xffc080), emissiveMap: null, emissiveIntensity: 0 });
  for (let i = 0; i < 3; i++) nightMats.push({ mat: mats['shop' + i], max: 0.25 });
  const PLINTHS = ['#6b5a4a', '#8a3a2a', '#3f5a6a', '#4a6a3a'];
  PLINTHS.forEach((c, i) => (mats['plinth' + i] = std({ map: T.plinth(c) })));
  const GOODS = [0xd23a2a, 0xf0c020, 0x2f8a3a, 0xe87a20, 0x7a3a9a, 0x2a6ac0];
  GOODS.forEach((c, i) => (mats['goods' + i] = std({ color: c })));
  const TARPS = [0x1f6fd0, 0xd03030, 0xe8b020, 0x2a9a5a, 0xffffff];
  TARPS.forEach((c, i) => (mats['tarp' + i] = std({ color: c, side: THREE.DoubleSide, roughness: 0.8 })));
  for (let i = 0; i < 4; i++) mats['boat' + i] = std({ map: T.boat(300 + i) });
  mats.far = std({ vertexColors: true });
  ['#3d6f86', '#4d7a6a'].forEach((tint, i) => {
    const g = T.glassFacade(tint, 300 + i);
    mats['glass' + i] = std({ map: g.map, emissiveMap: g.emissive, emissive: new THREE.Color(0xffffff), emissiveIntensity: 0, metalness: 0.55, roughness: 0.15, envMapIntensity: 1.4 });
    nightMats.push({ mat: mats['glass' + i], max: 0.7 });
  });
  mats.net = std({ map: T.fishingNet(), alphaTest: 0.4, side: THREE.DoubleSide, roughness: 0.9 });
  mats.straw = std({ map: T.straw(), roughness: 1, side: THREE.DoubleSide });
  const plates = T.plateAtlas();
  mats.plate = std({ map: plates.texture, roughness: 0.5, emissive: new THREE.Color(0xffffff), emissiveMap: plates.texture, emissiveIntensity: 0 });
  nightMats.push({ mat: mats.plate, max: 0.35 });
  mats.flame = std({ color: 0xffa020, emissive: new THREE.Color(0xff7a10), emissiveIntensity: 0.8, roughness: 0.4 });
  nightMats.push({ mat: mats.flame, max: 2.5 });
  const idleSpots = [];
  // panneau de texte (plaque de rue / enseigne) : plan + dos métallique
  function plateSign(k, x, y, z, ry, w = 2.4, h = 0.3, both = false) {
    const base = M(x, y, z, ry), r = plates.row(k);
    const mk = () => { const g = new THREE.PlaneGeometry(w, h); const uv = g.attributes.uv; for (let i = 0; i < uv.count; i++) uv.setXY(i, r[0] + uv.getX(i) * (r[2] - r[0]), r[1] + uv.getY(i) * (r[3] - r[1])); return g; };
    add('plate', mk().applyMatrix4(M(0, 0, 0.03)).applyMatrix4(base), { cast: false });
    if (both) add('plate', mk().applyMatrix4(M(0, 0, -0.03, PI)).applyMatrix4(base), { cast: false });
    add('metal', new THREE.BoxGeometry(w + 0.06, h + 0.06, 0.04).applyMatrix4(base));
  }

  function add(key, geo, matrix, opts = {}) {
    if (matrix && !matrix.isMatrix4) { opts = matrix; matrix = null; }
    if (matrix) geo.applyMatrix4(matrix);
    let g = geo.index ? geo.toNonIndexed() : geo;
    for (const name of Object.keys(g.attributes)) if (!['position', 'normal', 'uv', 'color'].includes(name)) g.deleteAttribute(name);
    let b = batches.get(key);
    if (!b) batches.set(key, (b = { geos: [], cast: opts.cast !== false, receive: opts.receive !== false }));
    b.geos.push(g);
  }

  // ---------- Sol, routes, trottoirs ----------
  add('laterite', planeUV(900, 900, 6, 6), M(0, -0.02, 0));

  const isAsphaltZ = () => true;
  const isAsphaltX = (x) => x === 0;
  // routes horizontales (le long de X)
  for (const z of LINES_Z) {
    add('asphalt', planeUV(480, ROAD_HALF * 2, 8, 8), M(0, 0.025, z));
  }
  // routes verticales (le long de Z) : boulevard central goudronné, rues pavées ailleurs
  for (const x of LINES_X) {
    const z0 = -240, z1 = BEACH_Z;
    add(isAsphaltX(x) ? 'asphalt' : 'pave', planeUV(ROAD_HALF * 2, z1 - z0, isAsphaltX(x) ? 8 : 4, isAsphaltX(x) ? 8 : 4), M(x, 0.02, (z0 + z1) / 2));
  }
  // marquages
  const nearCross = (v, lines) => lines.some((l) => Math.abs(v - l) < ROAD_HALF + 2);
  for (const z of LINES_Z) {
    for (let x = -236; x < 236; x += 6) {
      if (nearCross(x, LINES_X) || (z === 0 && Math.abs(x) < ROUND_R + 2)) continue;
      add('markW', new THREE.PlaneGeometry(3, 0.15).rotateX(-PI / 2), M(x, 0.035, z), { cast: false });
    }
    for (const s of [-1, 1]) add('markW', new THREE.PlaneGeometry(480, 0.12).rotateX(-PI / 2), M(0, 0.033, z + s * (ROAD_HALF - 0.4)), { cast: false });
  }
  for (let z = -236; z < BEACH_Z; z += 6) {
    if (nearCross(z, LINES_Z) || Math.abs(z) < ROUND_R + 2) continue;
    add('markY', new THREE.PlaneGeometry(0.15, 3).rotateX(-PI / 2), M(0, 0.035, z), { cast: false });
  }
  // rond-point central
  const disk = new THREE.CircleGeometry(ROUND_R, 48).rotateX(-PI / 2);
  { const uv = disk.attributes.uv; for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * ROUND_R / 4, uv.getY(i) * ROUND_R / 4); }
  add('asphalt', disk, M(0, 0.06, 0), { cast: false });
  const ring = new THREE.RingGeometry(ROUND_R - 0.5, ROUND_R - 0.35, 64).rotateX(-PI / 2);
  add('markW', ring, M(0, 0.07, 0), { cast: false });
  // passages piétons autour du rond-point
  for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
    for (let k = -5; k <= 5; k++) {
      const along = ROUND_R + 3;
      const geo = new THREE.PlaneGeometry(dx ? 2.6 : 0.6, dx ? 0.6 : 2.6).rotateX(-PI / 2);
      add('markW', geo, M(dx * along + (dz ? k * 1.2 : 0), 0.04, dz * along + (dx ? k * 1.2 : 0)), { cast: false });
    }
  }

  // blocs
  const intervals = (lines, min, max) => {
    const out = []; let a = min;
    for (const l of lines) { out.push([a, l - ROAD_HALF]); a = l + ROAD_HALF; }
    out.push([a, max]);
    return out.filter(([p, q]) => q - p > 8);
  };
  const IX = intervals(LINES_X, -175, 175);
  const IZ = intervals(LINES_Z, -175, BEACH_Z);

  const palms = [], trees = [], bushes = [], bananas = [], tufts = [];
  const parkedCars = [];
  const pedPaths = [];
  const lamps = [], seats = [];
  const plazaSpots = [], martyrs = {};
  const blocks = [];
  const blockModes = [];
  // terrain de la maison du joueur (Mission 010) : aucun bâtiment généré dessus
  const HOME_LOT = { x0: -62, x1: -22, z0: 110, z1: 142 };
  const inBox = (L, x, z, r) => x + r > L.x0 - 0.5 && x - r < L.x1 + 0.5 && z + r > L.z0 - 0.5 && z - r < L.z1 + 0.5;
  const reserved = (x, z, r) => inBox(HOME_LOT, x, z, r) || inBox(GARAGE_LOT, x, z, r) || inBox(SUPER_LOT, x, z, r) || inBox(NOVA_LOT, x, z, r);
  const stallSpots = [];
  const zones = [];

  const edgePos = [], edgeUv = [];
  function sandStrip(ax, az, bx, bz, nx, nz, wdt = 1.7) {
    const L = Math.hypot(bx - ax, bz - az), u = L / 8;
    const cx = ax + nx * wdt, cz = az + nz * wdt, dx = bx + nx * wdt, dz = bz + nz * wdt;
    edgePos.push(ax, 0.045, az, bx, 0.045, bz, dx, 0.045, dz, ax, 0.045, az, dx, 0.045, dz, cx, 0.045, cz);
    edgeUv.push(0, 1, u, 1, u, 0, 0, 1, u, 0, 0, 0);
  }
  // nx,nz : normale vers la route. Caniveau couvert de dalles + bordure, puis sable qui déborde sur la chaussée.
  function curbLine(x0, z0, x1, z1, nx, nz) {
    const len = Math.hypot(x1 - x0, z1 - z0);
    const segs = Math.ceil(len / 6);
    for (let i = 0; i < segs; i++) {
      const t0 = i / segs, t1 = (i + 1) / segs;
      const ax = x0 + (x1 - x0) * t0, az = z0 + (z1 - z0) * t0, bx = x0 + (x1 - x0) * t1, bz = z0 + (z1 - z0) * t1;
      const mx = (ax + bx) / 2, mz = (az + bz) / 2;
      if (Math.hypot(mx, mz) < ROUND_R + 1.5) continue;
      const horiz = Math.abs(z1 - z0) < 0.01;
      const L = len / segs;
      const g = boxUV(horiz ? L : 0.9, 0.16, horiz ? 0.9 : L, horiz ? 4 : 0.9, horiz ? 0.9 : 4);
      if (!horiz) { const uv = g.attributes.uv; for (let k = 8; k < 12; k++) uv.setXY(k, uv.getY(k), uv.getX(k)); }
      add('gutter', g, M(mx - nx * 0.45, 0.08, mz - nz * 0.45), { cast: false });
      add('curb', new THREE.BoxGeometry(horiz ? L : 0.18, 0.2, horiz ? 0.18 : L), M(mx + nx * 0.02, 0.1, mz + nz * 0.02), { cast: false });
      if (R() < 0.85) sandStrip(ax + nx * 0.1, az + nz * 0.1, bx + nx * 0.1, bz + nz * 0.1, nx, nz, 1.2 + R() * 1.2);
    }
  }

  function addBlockGround(x0, x1, z0, z1) {
    const w = x1 - x0, d = z1 - z0;
    add('sidewalk', planeUV(w, d, 2, 2), M((x0 + x1) / 2, 0.03, (z0 + z1) / 2), { cast: false });
    curbLine(x0, z0, x1, z0, 0, -1); curbLine(x0, z1, x1, z1, 0, 1); curbLine(x0, z0, x0, z1, -1, 0); curbLine(x1, z0, x1, z1, 1, 0);
  }

  // ---------- Bâtiments (architecture inspirée de Cotonou) ----------
  let signIdx = 0, lastSign = 0;
  const footprints = [];
  const namedPlaces = []; // mission 015 : enseignes nommées (fictives) pour la carte
  const shopFronts = [];
  const TINS = ['roofTin', 'tinRed', 'tinGreen', 'tinBlue'];

  function signPlane(sw, sh) {
    const g = new THREE.PlaneGeometry(sw, sh);
    lastSign = signIdx % atlas.rects.length; const r = atlas.rects[signIdx++ % atlas.rects.length];
    const uv = g.attributes.uv;
    for (let i = 0; i < uv.count; i++) uv.setXY(i, r[0] + uv.getX(i) * (r[2] - r[0]), r[1] + uv.getY(i) * (r[3] - r[1]));
    return g;
  }
  function balustradeRun(loc, len, x, y, z, alongX = true) {
    const g = new THREE.PlaneGeometry(len, 0.95);
    const uv = g.attributes.uv; for (let i = 0; i < uv.count; i++) uv.setX(i, uv.getX(i) * len / 2);
    if (!alongX) g.rotateY(PI / 2);
    add('balustrade', loc(g, x, y, z));
  }

  let officeSign = 0;
  function officeTower(cx, cz, ry, w, d, floors) {
    const h = floors * 3.2 + 0.6;
    const base = M(cx, 0, cz, ry);
    const loc = (g, x, y, z) => g.applyMatrix4(M(x, y, z)).applyMatrix4(base);
    const gk = 'glass' + Math.floor(R() * 2);
    // socle commercial en pierre, tour vitrée au-dessus
    add('stone', loc(boxUV(w + 0.2, 3.6, d + 0.2, 4, 4), 0, 1.8, 0));
    add(gk, loc(boxUV(w, h - 3.6, d, 12 * 1.0, 6.4), 0, 3.6 + (h - 3.6) / 2, 0));
    for (let f = 2; f < floors; f += 2) add('trim', loc(new THREE.BoxGeometry(w + 0.16, 0.22, d + 0.16), 0, f * 3.2 + 0.4, 0));
    add('roofConcrete', loc(boxUV(w + 0.4, 0.4, d + 0.4, 6, 6), 0, h + 0.2, 0));
    add('trim', loc(new THREE.BoxGeometry(w + 0.4, 0.9, 0.2), 0, h + 0.8, d / 2 + 0.1));
    // auvent d'entrée + porte vitrée
    add('metal', loc(new THREE.BoxGeometry(Math.min(w - 2, 6), 0.15, 2.2), 0, 3.0, d / 2 + 1.1));
    add('glass1', loc(boxUV(3, 2.6, 0.1, 3, 3), 0, 1.3, d / 2 + 0.12), { cast: false });
    // enseigne lumineuse en toiture (banque, hôtel, centre d'affaires : noms fictifs)
    if (officeSign < 6) { namedPlaces.push({ name: T.PLATES[4 + (officeSign % 3)], x: cx, z: cz, kind: 'office', door: { x: cx + Math.sin(ry) * (d / 2 + 1.6), z: cz + Math.cos(ry) * (d / 2 + 1.6), ry } }); plateSign(4 + (officeSign++ % 3), cx + Math.sin(ry) * (d / 2 + 0.25), h + 1.1, cz + Math.cos(ry) * (d / 2 + 0.25), ry, Math.min(w - 1, 8), Math.min(w - 1, 8) / 8); }
    if (R() < 0.6) add('tank', loc(new THREE.CylinderGeometry(0.7, 0.7, 1.5, 14), w / 2 - 1.5, h + 1.1, -d / 2 + 1.5));
    footprint(cx, cz, ry, w, d, h + 1, 1);
  }

  function building(cx, cz, ry, w, d, floors, opts = {}) {
    const h = floors * 3 + 0.4;
    const fi = opts.facade ?? Math.floor(R() * FACADES.length);
    const fk = 'facade' + fi;
    const base = M(cx, 0, cz, ry);
    const loc = (g, x, y, z, rx = 0, rz = 0) => g.applyMatrix4(M(x, y, z, 0, rx, rz)).applyMatrix4(base);
    const arcade = opts.shop && floors >= 2 && R() < 0.45;
    add(fk, loc(boxUV(w, h, d, 12, 6), 0, h / 2, 0));
    // soubassement coloré
    add('plinth' + (fi % 4), loc(boxUV(w + 0.08, 0.85, d + 0.08, 2, 0.85), 0, 0.425, 0), { cast: false });
    // corniches à chaque dalle
    for (let f = 1; f < floors; f++) add('trim', loc(new THREE.BoxGeometry(w + 0.22, 0.18, d + 0.22), 0, f * 3, 0));
    const tin = floors === 1 && R() < 0.5;
    if (tin) {
      add(TINS[Math.floor(R() * TINS.length)], loc(boxUV(w + 0.9, 0.08, d + 1.2, 3, 3), 0, h + 0.3, 0, 0.1));
    } else {
      add('roofConcrete', loc(boxUV(w + 0.3, 0.35, d + 0.3, 6, 6), 0, h + 0.17, 0));
      const claus = R() < 0.35;
      add(claus ? 'claustra' : 'trim', loc(boxUV(w + 0.3, 0.8, 0.15, 1, 0.8), 0, h + 0.7, d / 2 + 0.07));
      add('trim', loc(new THREE.BoxGeometry(w + 0.3, 0.8, 0.15), 0, h + 0.7, -d / 2 - 0.07));
      add('trim', loc(new THREE.BoxGeometry(0.15, 0.8, d + 0.3), w / 2 + 0.07, h + 0.7, 0));
      add('trim', loc(new THREE.BoxGeometry(0.15, 0.8, d + 0.3), -w / 2 - 0.07, h + 0.7, 0));
      add('trim', loc(new THREE.BoxGeometry(w + 0.5, 0.12, d + 0.5), 0, h + 1.12, 0));
      if (R() < 0.45) {
        // poteaux « en attente » pour un futur étage
        for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
          const px = sx * (w / 2 - 0.3), pz = sz * (d / 2 - 0.3);
          add('concrete', loc(new THREE.BoxGeometry(0.35, 0.6, 0.35), px, h + 0.65, pz));
          for (let k = 0; k < 4; k++) add('rebar', loc(new THREE.CylinderGeometry(0.02, 0.02, 1.4, 4), px + ((k & 1) - 0.5) * 0.2, h + 1.5, pz + ((k >> 1) - 0.5) * 0.2), { cast: false });
        }
      }
      if (R() < 0.45) add('tank', loc(new THREE.CylinderGeometry(0.6, 0.6, 1.3, 14), w / 2 - 1.2, h + 1.0, -d / 2 + 1.2));
      if (R() < 0.35) {
        // antenne parabolique
        const dish = new THREE.SphereGeometry(0.45, 10, 6, 0, PI * 2, 0, PI / 3.2);
        dish.rotateX(-1.1);
        add('white', loc(dish, -w / 2 + 1.2, h + 1.0, -d / 2 + 1.5));
        add('metal', loc(new THREE.CylinderGeometry(0.03, 0.03, 0.8, 5), -w / 2 + 1.2, h + 0.6, -d / 2 + 1.3));
      }
    }
    // cage d'escalier en claustras, en saillie sur la façade
    if (floors >= 2 && w >= 9 && !arcade && R() < 0.35) {
      const sx = (R() < 0.5 ? -1 : 1) * (w / 2 - 1.3);
      add('claustra', loc(boxUV(2.2, h + 0.8, 1.6, 1, 1), sx, (h + 0.8) / 2, d / 2 + 0.8));
      add('trim', loc(new THREE.BoxGeometry(2.4, 0.15, 1.8), sx, h + 0.85, d / 2 + 0.8));
    }
    // balcons à balustres
    if (floors >= 2 && !arcade && R() < 0.6) {
      const bw = Math.min(w - 1, 3 * Math.max(1, Math.floor((w - 1) / 3)));
      for (let f = 1; f < floors; f++) {
        add('trim', loc(new THREE.BoxGeometry(bw, 0.18, 1.3), 0, f * 3, d / 2 + 0.65));
        balustradeRun(loc, bw, 0, f * 3 + 0.55, d / 2 + 1.27);
        balustradeRun(loc, 1.3, bw / 2, f * 3 + 0.55, d / 2 + 0.65, false);
        balustradeRun(loc, 1.3, -bw / 2, f * 3 + 0.55, d / 2 + 0.65, false);
      }
    }
    // climatiseurs en façade
    for (let f = 1; f < floors; f++) {
      if (R() < 0.5) {
        const bays = Math.floor(w / 3), b = Math.floor(R() * bays);
        add('acUnit', loc(new THREE.BoxGeometry(0.8, 0.55, 0.35), -w / 2 + 1.5 + b * 3, f * 3 + 0.45, d / 2 + 0.18));
      }
    }
    // fresque publicitaire peinte sur un pignon
    if (floors >= 2 && R() < 0.22) {
      const mw = Math.min(d - 1, 7), mh = mw / 2;
      const g = new THREE.PlaneGeometry(mw, mh);
      const k = Math.floor(R() * 4), u0 = (k % 2) * 0.5, v0 = k < 2 ? 0.5 : 0;
      const uv = g.attributes.uv; for (let i = 0; i < uv.count; i++) uv.setXY(i, u0 + uv.getX(i) * 0.5, v0 + uv.getY(i) * 0.5);
      g.rotateY(PI / 2);
      add('mural', loc(g, w / 2 + 0.03, Math.min(h - mh / 2 - 0.5, 2 + mh / 2 + 1.2), 0), { cast: false });
    }
    if (arcade) {
      // galerie commerçante à piliers (rez-de-chaussée couvert)
      const depth = 2.4;
      add('trim', loc(new THREE.BoxGeometry(w, 0.3, depth), 0, 3.0, d / 2 + depth / 2));
      const n = Math.max(2, Math.round(w / 3.2));
      for (let k = 0; k <= n; k++) {
        const px = -w / 2 + 0.25 + (k * (w - 0.5)) / n;
        add('trim', loc(new THREE.BoxGeometry(0.4, 2.9, 0.4), px, 1.45, d / 2 + depth - 0.2));
        const wp = new THREE.Vector3(px, 0, d / 2 + depth - 0.2).applyMatrix4(base);
        col.addCircle(wp.x, wp.z, 0.3, 3);
      }
      balustradeRun(loc, w, 0, 3.6, d / 2 + depth - 0.05);
      add('shop' + Math.floor(R() * 3), loc(boxUV(w - 0.8, 2.8, 0.12, 4, 2.8), 0, 1.4, d / 2 + 0.06), { cast: false });
      const sw = Math.min(w - 1.2, 6), sh = sw / 4;
      add('sign', loc(signPlane(sw, sh), 0, 3.6 + sh / 2 + 0.1, d / 2 + depth - 0.02), { cast: false });
    } else if (opts.shop) {
      add('shop' + Math.floor(R() * 3), loc(boxUV(w - 0.8, 2.8, 0.12, 4, 2.8), 0, 1.4, d / 2 + 0.06), { cast: false });
      add('awn' + Math.floor(R() * AWN.length), loc(boxUV(w - 0.4, 0.08, 2.0, 3, 3), 0, 3.05, d / 2 + 1.0, 0.18));
      for (const sx of [-1, 1]) add('metal', loc(new THREE.CylinderGeometry(0.05, 0.05, 2.9, 6), sx * (w / 2 - 0.5), 1.45, d / 2 + 1.9));
      const sw = Math.min(w - 1.2, 7), sh = sw / 4;
      add('sign', loc(signPlane(sw, sh), 0, 3.35 + sh / 2, d / 2 + 0.04), { cast: false });
      if (R() < 0.3) streetCafe(loc, w, d);
    } else {
      add('gate' + Math.floor(R() * GATES.length), loc(new THREE.BoxGeometry(1.3, 2.3, 0.12), 0, 1.15, d / 2 + 0.05));
      add('trim', loc(new THREE.BoxGeometry(1.8, 0.15, 0.8), 0, 2.55, d / 2 + 0.4));
      add('concrete', loc(new THREE.BoxGeometry(1.8, 0.16, 0.7), 0, 0.08, d / 2 + 0.35), { cast: false });
    }
    footprint(cx, cz, ry, w, d, h + 1, 1);
    if (opts.shop) {
      const f = new THREE.Vector3(0, 0, d / 2 + (arcade ? 1.2 : 2.2)).applyMatrix4(base);
      shopFronts.push({ x: f.x, z: f.z, ry, name: T.SIGN_TEXTS[lastSign] ? T.SIGN_TEXTS[lastSign][0] : null });
    }
  }

  // table de maquis sous parasol, chaises plastiques
  function streetCafe(loc, w, d) {
    const z = d / 2 + 2.9;
    const tk = 'tarp' + Math.floor(R() * TARPS.length);
    add('wood', loc(new THREE.CylinderGeometry(0.035, 0.035, 2.3, 5), 0, 1.15, z));
    add(tk, loc(new THREE.ConeGeometry(1.5, 0.45, 10, 1, true), 0, 2.4, z));
    add('plastic', loc(new THREE.CylinderGeometry(0.45, 0.45, 0.05, 12), 0, 0.72, z));
    add('plastic', loc(new THREE.CylinderGeometry(0.05, 0.05, 0.72, 6), 0, 0.36, z));
    for (let k = 0; k < 3; k++) {
      const a = k * 2.1 + 0.4, px = Math.sin(a) * 0.85, pz = z + Math.cos(a) * 0.85;
      const mk = R() < 0.5 ? 'plastic' : 'plasticR';
      add(mk, loc(new THREE.BoxGeometry(0.45, 0.05, 0.45), px, 0.45, pz));
      add(mk, loc(new THREE.BoxGeometry(0.45, 0.45, 0.05), px - Math.sin(a) * 0.22, 0.68, pz - Math.cos(a) * 0.22).applyMatrix4(new THREE.Matrix4()));
      add(mk, loc(new THREE.BoxGeometry(0.4, 0.45, 0.4), px, 0.22, pz), { cast: false });
    }
  }

  function footprint(cx, cz, ry, w, d, h, kind = 1) {
    const rot = Math.abs(Math.sin(ry)) > 0.5;
    const hx = (rot ? d : w) / 2, hz = (rot ? w : d) / 2;
    col.addBox(cx - hx, cz - hz, cx + hx, cz + hz, h);
    footprints.push([cx - hx, cz - hz, cx + hx, cz + hz, kind]);
  }

  function compound(cx, cz, ry, w, d) {
    const base = M(cx, 0, cz, ry);
    const loc = (g, x, y, z) => g.applyMatrix4(M(x, y, z)).applyMatrix4(base);
    const wp = (x, z) => new THREE.Vector3(x, 0, z).applyMatrix4(base);
    const wk = 'wall' + Math.floor(R() * WALLS.length);
    const gw = 3, seg = (w - gw) / 2;
    for (const s2 of [-1, 1]) add(wk, loc(boxUV(seg, 2.3, 0.25, 4, 2), s2 * (gw / 2 + seg / 2), 1.15, d / 2));
    add(wk, loc(boxUV(w, 2.3, 0.25, 4, 2), 0, 1.15, -d / 2));
    for (const s2 of [-1, 1]) add(wk, loc(boxUV(0.25, 2.3, d, 4, 2), s2 * w / 2, 1.15, 0));
    // chaperon du mur
    add('trim', loc(new THREE.BoxGeometry(w + 0.1, 0.1, 0.4), 0, 2.35, d / 2));
    // portail métallique + piliers
    add('gate' + Math.floor(R() * GATES.length), loc(new THREE.BoxGeometry(gw, 2.1, 0.08), 0, 1.1, d / 2));
    for (const s2 of [-1, 1]) {
      add('trim', loc(new THREE.BoxGeometry(0.5, 2.8, 0.5), s2 * (gw / 2 + 0.22), 1.4, d / 2));
      add('trim', loc(new THREE.BoxGeometry(0.62, 0.12, 0.62), s2 * (gw / 2 + 0.22), 2.86, d / 2));
    }
    // villa basse avec toit en tôle à quatre pans et véranda
    const hw = Math.max(6, 3 * Math.floor((w * 0.7) / 3)), hd = Math.max(6, 3 * Math.floor((d * 0.5) / 3));
    const hz = -d / 2 + hd / 2 + 1;
    const fi = Math.floor(R() * FACADES.length);
    add('facade' + fi, loc(boxUV(hw, 3.4, hd, 12, 6), 0, 1.7, hz));
    add('plinth' + (fi % 4), loc(boxUV(hw + 0.08, 0.8, hd + 0.08, 2, 0.8), 0, 0.4, hz), { cast: false });
    const roof = new THREE.ConeGeometry(1, 1.6, 4, 1);
    roof.rotateY(PI / 4);
    roof.scale((hw / 2 + 0.7) / 0.7071, 1, (hd / 2 + 1.6) / 0.7071);
    add(TINS[Math.floor(R() * TINS.length)], loc(roof, 0, 3.4 + 0.8, hz + 0.45));
    for (const s2 of [-1, 1]) add('trim', loc(new THREE.BoxGeometry(0.3, 3.3, 0.3), s2 * (hw / 2 - 0.3), 1.65, hz + hd / 2 + 1.6));
    // végétation de la cour
    const p = wp(R() < 0.5 ? -w / 4 : w / 4, d / 4);
    (R() < 0.5 ? palms : trees).push({ x: p.x, z: p.z, s: 0.7 + R() * 0.3, r: R() * 6.28, noCol: true });
    for (const s2 of [-1, 1]) if (R() < 0.6) { const b2 = wp(s2 * (w / 2 - 1.2), d / 2 - 0.9); bushes.push({ x: b2.x, z: b2.z, s: 1 + R() * 0.4, r: R() * 6, y: 0.6 }); }
    if (R() < 0.5) { const b3 = wp(-s2sign() * (w / 2 - 1.8), -d / 2 + 1.6); bananas.push({ x: b3.x, z: b3.z, s: 0.8 + R() * 0.4, r: R() * 6 }); }
    for (let k = 0; k < 4; k++) { const t = wp((R() - 0.5) * (w + 1), d / 2 + 0.4 + R() * 0.4); tufts.push({ x: t.x, z: t.z, s: 0.6 + R() * 0.6, r: R() * 6 }); }
    footprint(cx, cz, ry, w, d, 3, 2);
  }
  function s2sign() { return R() < 0.5 ? -1 : 1; }

  function kpayo(x, z, ry) {
    // vendeur d'essence au bord de la route : table et bouteilles
    const base = M(x, 0, z, ry);
    add('wood', new THREE.BoxGeometry(1.4, 0.08, 0.7).applyMatrix4(M(0, 0.8, 0)).applyMatrix4(base));
    for (const sx of [-0.6, 0.6]) for (const sz of [-0.28, 0.28]) add('wood', new THREE.BoxGeometry(0.06, 0.8, 0.06).applyMatrix4(M(sx, 0.4, sz)).applyMatrix4(base));
    for (let i = 0; i < 10; i++) {
      add('bottle', new THREE.CylinderGeometry(0.06, 0.07, 0.3, 6).applyMatrix4(M(-0.55 + (i % 5) * 0.27, 0.99, (i < 5 ? -0.15 : 0.15))).applyMatrix4(base), { cast: false });
    }
    add('bottle', new THREE.CylinderGeometry(0.22, 0.22, 0.6, 8).applyMatrix4(M(0.9, 0.3, 0)).applyMatrix4(base), { cast: false });
    col.addCircle(x, z, 0.8, 1);
  }

  function genSide(a, b, place, d0, mode = 'mixed') {
    let u = a;
    while (u < b - 6) {
      let w = 3 * Math.round((9 + R() * 8) / 3);
      if (u + w > b) w = 3 * Math.floor((b - u) / 3);
      if (w < 6) break;
      const d = 3 * Math.round((d0 - R() * 3) / 3);
      const set = 0.3 + R() * 0.9;
      const p = place(u, w, d, set);
      if (Math.hypot(p.cx, p.cz) > 32 && !reserved(p.cx, p.cz, Math.max(w, d) / 2)) {
        const r = R();
        if (mode === 'business' && r < 0.45 && w >= 9) {
          officeTower(p.cx, p.cz, p.ry, w, d, 5 + Math.floor(R() * 3));
        } else if (mode === 'business' && r < 0.9) {
          building(p.cx, p.cz, p.ry, w, d, 3 + Math.floor(R() * 2), { shop: true });
        } else if (r < (mode === 'residential' ? 0.3 : 0.64)) {
          let floors = 1 + (R() < 0.75 ? 1 : 0) + (R() < 0.45 ? 1 : 0) + (R() < 0.15 ? 1 : 0) + (R() < 0.05 ? 1 : 0);
          if (mode === 'residential') floors = Math.min(floors, 2);
          building(p.cx, p.cz, p.ry, w, d, floors, { shop: mode === 'residential' ? R() < 0.2 : R() < 0.6 });
        } else if (r < (mode === 'residential' ? 0.92 : 0.88)) {
          compound(p.cx, p.cz, p.ry, w, d);
        } else {
          trees.push({ x: p.cx, z: p.cz, s: 0.9 + R() * 0.4, r: R() * 6.28, flamboyant: R() < 0.3 });
          for (let k = 0; k < 14; k++) tufts.push({ x: p.cx + (R() - 0.5) * w, z: p.cz + (R() - 0.5) * d, s: 0.6 + R() * 0.8, r: R() * 6 });
          const fx = Math.sin(p.ry), fz = Math.cos(p.ry);
          kpayo(p.cx + fx * (d / 2 + set + 0.6), p.cz + fz * (d / 2 + set + 0.6), p.ry);
        }
      }
      u += w + (R() < 0.3 ? 1 + R() * 2 : 0.4);
    }
  }

  function cityBlock(x0, x1, z0, z1) {
    const ix0 = x0 + SIDEWALK, ix1 = x1 - SIDEWALK, iz0 = z0 + SIDEWALK, iz1 = z1 - SIDEWALK;
    add('laterite', planeUV(ix1 - ix0, iz1 - iz0, 8, 8), M((ix0 + ix1) / 2, 0.04, (iz0 + iz1) / 2), { cast: false });
    const DMAX = Math.min(13, (iz1 - iz0) / 2 - 1);
    // quartier d'affaires le long des boulevards centraux, quartiers résidentiels en périphérie
    const bcx = (x0 + x1) / 2, bcz = (z0 + z1) / 2;
    const mode = (x0 === 7 || x1 === -7 || z0 === 7 || z1 === -7) && Math.abs(bcx) < 100 && Math.abs(bcz) < 100 ? 'business'
      : (Math.abs(bcx) > 110 || bcz < -110) ? 'residential' : 'mixed';
    blockModes.push({ x0, x1, z0, z1, mode });
    genSide(ix0, ix1, (u, w, d, set) => ({ cx: u + w / 2, cz: iz0 + set + d / 2, ry: PI }), DMAX, mode);
    genSide(ix0, ix1, (u, w, d, set) => ({ cx: u + w / 2, cz: iz1 - set - d / 2, ry: 0 }), DMAX, mode);
    const za = iz0 + DMAX + 1.5, zb = iz1 - DMAX - 1.5;
    const DX = Math.min(13, (ix1 - ix0) / 2 - 1);
    if (zb - za > 9) {
      genSide(za, zb, (u, w, d, set) => ({ cx: ix0 + set + d / 2, cz: u + w / 2, ry: -PI / 2 }), DX, mode);
      genSide(za, zb, (u, w, d, set) => ({ cx: ix1 - set - d / 2, cz: u + w / 2, ry: PI / 2 }), DX, mode);
    }
    // cour intérieure : arbres
    const cx0 = ix0 + DX + 2, cx1 = ix1 - DX - 2, cz0 = za + 0.5, cz1 = zb - 0.5;
    if (cx1 - cx0 > 4 && cz1 - cz0 > 4) {
      const n = 2 + Math.floor(R() * 4);
      for (let i = 0; i < n; i++) {
        const x = cx0 + R() * (cx1 - cx0), z = cz0 + R() * (cz1 - cz0);
        if (Math.hypot(x, z) < 30 || reserved(x, z, 2)) continue;
        const k = R();
        if (k < 0.4) palms.push({ x, z, s: 0.8 + R() * 0.5, r: R() * 6.28 });
        else if (k < 0.8) trees.push({ x, z, s: 0.8 + R() * 0.5, r: R() * 6.28, flamboyant: R() < 0.25 });
        else bananas.push({ x, z, s: 0.8 + R() * 0.4, r: R() * 6 });
      }
      for (let i = 0; i < 25; i++) tufts.push({ x: cx0 + R() * (cx1 - cx0), z: cz0 + R() * (cz1 - cz0), s: 0.6 + R() * 0.8, r: R() * 6 });
    }
  }

  function marketBlock(x0, x1, z0, z1) {
    add('laterite', planeUV(x1 - x0 - 6, z1 - z0 - 6, 8, 8), M((x0 + x1) / 2, 0.04, (z0 + z1) / 2), { cast: false });
    // --- bâtiment du marché (3 niveaux à galeries) le long de la rue nord ---
    const HX0 = x0 + 4, HX1 = x0 + 40;
    {
      const bx = (HX0 + HX1) / 2, bw = HX1 - HX0, bz = z0 + 10, bd = 12;
      building(bx, bz, PI, 3 * Math.floor(bw / 3), bd, 3, { shop: true, facade: 4 });
      plateSign(2, bx, 10.2, bz - bd / 2 - 0.35, PI, 10, 1.25);
    }
    // --- halles couvertes (hangars en tôle sur poteaux) avec étals serrés ---
    for (const [hz0, hz1] of [[z0 + 22, z0 + 48], [z0 + 54, z1 - 8]]) {
      const hx = (HX0 + HX1) / 2, hz = (hz0 + hz1) / 2, hw = HX1 - HX0, hd = hz1 - hz0;
      for (let px = HX0; px <= HX1 + 0.1; px += hw / 6) for (const pz of [hz0, hz1]) {
        add('metal', new THREE.CylinderGeometry(0.12, 0.12, 5.2, 8), M(px, 2.6, pz));
        col.addCircle(px, pz, 0.2, 5);
      }
      for (const s2 of [-1, 1]) add(s2 < 0 ? 'roofTin' : 'tinRed', boxUV(hw + 2, 0.1, hd / 2 + 1.2, 3, 3), M(hx, 5.6, hz + s2 * hd / 4, 0, s2 * 0.18));
      for (let x = HX0 + 3; x < HX1 - 2; x += 5) for (let z = hz0 + 3; z < hz1 - 2; z += 4.2) {
        add('wood', new THREE.BoxGeometry(3.4, 0.1, 1.5), M(x, 0.85, z));
        add('wood', new THREE.BoxGeometry(3.2, 0.85, 0.1), M(x, 0.42, z + 0.7));
        for (let k = 0; k < 6; k++) add('goods' + Math.floor(R() * GOODS.length), (R() < 0.5 ? new THREE.SphereGeometry(0.17, 6, 4) : new THREE.BoxGeometry(0.35, 0.25, 0.3)), M(x - 1.3 + k * 0.52, 1.0, z + (R() - 0.5) * 0.7), { cast: false });
        col.addBox(x - 1.7, z - 0.75, x + 1.7, z + 0.75, 2);
        if (R() < 0.45) stallSpots.push({ x, z: z - 1.1, ry: 0 });
      }
    }
    for (let x = x0 + 8; x < x1 - 6; x += 6.5) for (let z = z0 + 8; z < z1 - 6; z += 7) {
      if (Math.hypot(x, z) < 34) continue;
      if (x < HX1 + 3) continue; // zone occupée par le bâtiment et les halles
      if (R() < 0.12) continue;
      const base = M(x, 0, z, (R() < 0.5 ? 0 : PI));
      const loc = (g, a, b, c, rx = 0) => g.applyMatrix4(M(a, b, c, 0, rx)).applyMatrix4(base);
      add('wood', loc(new THREE.BoxGeometry(3.2, 0.1, 1.6), 0, 0.85, 0));
      add('wood', loc(new THREE.BoxGeometry(3.0, 0.85, 0.1), 0, 0.42, 0.75));
      if (R() < 0.6) {
        for (const sx of [-1.6, 1.6]) for (const sz of [-1.2, 1.2]) add('wood', loc(new THREE.CylinderGeometry(0.05, 0.05, 2.6, 5), sx, 1.3, sz));
        add('tarp' + Math.floor(R() * TARPS.length), loc(new THREE.BoxGeometry(4, 0.04, 3.2), 0, 2.6, 0, 0.12));
      } else {
        // grand parasol
        add('wood', loc(new THREE.CylinderGeometry(0.04, 0.04, 2.6, 5), 0, 1.3, -0.9));
        add('tarp' + Math.floor(R() * TARPS.length), loc(new THREE.ConeGeometry(2.2, 0.6, 10, 1, true), 0, 2.75, -0.9));
      }
      for (let k = 0; k < 7; k++) {
        const gk = 'goods' + Math.floor(R() * GOODS.length);
        const g = R() < 0.5 ? new THREE.SphereGeometry(0.16 + R() * 0.08, 6, 4) : new THREE.BoxGeometry(0.35, 0.18 + R() * 0.2, 0.3);
        add(gk, loc(g, -1.3 + k * 0.43, 1.0, (R() - 0.5) * 0.8), { cast: false });
      }
      col.addBox(x - 1.7, z - 0.9, x + 1.7, z + 0.9, 2.6);
      { const rot = new THREE.Vector3(0, 0, -1.2).applyMatrix4(base); const fr = new THREE.Vector3(0, 0, 1).applyMatrix4(base); stallSpots.push({ x: rot.x, z: rot.z, ry: Math.atan2(fr.x - x, fr.z - z) }); }
    }
    // arche d'entrée « GRAND MARCHÉ »
    const ax = (x0 + x1) / 2, az = z1 - 1.5;
    for (const s of [-1, 1]) {
      add('stone', new THREE.BoxGeometry(0.8, 5, 0.8), M(ax + s * 5, 2.5, az));
      col.addBox(ax + s * 5 - 0.4, az - 0.4, ax + s * 5 + 0.4, az + 0.4, 5);
    }
    add('gate1', new THREE.BoxGeometry(11, 1.2, 0.5), M(ax, 5.4, az));
    plateSign(2, ax, 5.4, az + 0.27, 0, 9.6, 1.2, false);
    plateSign(2, ax, 5.4, az - 0.27, PI, 9.6, 1.2, false);
    dyn.marketArch = { x: ax, y: 5.4, z: az + 0.27 };
    // porteurs et clients dans les allées
    for (let k = 0; k < 10; k++) idleSpots.push({ x: HX1 + 6 + R() * 30, z: z0 + 12 + R() * 70, ry: R() * 6.28, carry: R() < 0.5 });
    zones.push({ x0, x1, z0, z1, name: 'Marché Dantokpa' });
  }

  function martyrsBlock(x0, x1, z0, z1) {
    const ix0 = x0 + SIDEWALK, ix1 = x1 - SIDEWALK, iz0 = z0 + SIDEWALK, iz1 = z1 - SIDEWALK;
    const cx = (x0 + x1) / 2, cz = (z0 + z1) / 2;
    add('pave', planeUV(ix1 - ix0, iz1 - iz0, 4, 4), M(cx, 0.045, cz), { cast: false });
    add('sidewalk', planeUV(ix1 - ix0, 5, 2, 2), M(cx, 0.05, cz), { cast: false });
    add('sidewalk', planeUV(5, iz1 - iz0, 2, 2), M(cx, 0.05, cz), { cast: false });
    // mémorial (interprétation libre) : stèle sur gradins, flamme, murs de plaques, drapeaux
    for (const [r, y] of [[8, 0.06], [6.8, 0.12], [5.6, 0.18]]) add('stone', new THREE.CylinderGeometry(r, r, 0.06, 8), M(cx, y, cz), { cast: false });
    add('stone', new THREE.BoxGeometry(3.2, 1.2, 3.2), M(cx, 0.8, cz));
    const ob = new THREE.CylinderGeometry(0.55, 1.15, 13, 4, 1); ob.rotateY(PI / 4);
    add('white', ob, M(cx, 7.9, cz));
    add('bronze', new THREE.CylinderGeometry(0.5, 0.35, 0.5, 12), M(cx, 14.6, cz));
    add('flame', new THREE.ConeGeometry(0.4, 1.2, 10), M(cx, 15.4, cz), { cast: false });
    col.addBox(cx - 1.7, cz - 1.7, cx + 1.7, cz + 1.7, 16);
    for (const [wx, wz, ry] of [[cx, cz - 11, 0], [cx, cz + 11, PI], [cx - 16, cz, PI / 2], [cx + 16, cz, -PI / 2]]) {
      add('stone', new THREE.BoxGeometry(7, 1.4, 0.6), M(wx, 0.7, wz, ry));
      add('bronze', new THREE.BoxGeometry(5.6, 0.7, 0.05), M(wx - Math.sin(ry) * 0.33, 0.85, wz - Math.cos(ry) * 0.33, ry));
      const n = Math.abs(Math.sin(ry)) > 0.5; col.addBox(wx - (n ? 0.3 : 3.5), wz - (n ? 3.5 : 0.3), wx + (n ? 0.3 : 3.5), wz + (n ? 3.5 : 0.3), 1.4);
    }
    plateSign(3, cx, 2.0, cz - 1.65, PI, 3, 0.38);
    const flagTex = T.benFlag();
    for (const [fx, fz] of [[cx - 22, cz - 12], [cx, cz - 15], [cx + 22, cz - 12]]) {
      add('metal', new THREE.CylinderGeometry(0.07, 0.09, 10, 8), M(fx, 5, fz)); col.addCircle(fx, fz, 0.25, 10);
      const g = new THREE.PlaneGeometry(2.4, 1.6, 10, 5); g.translate(1.2, 0, 0);
      const flag = new THREE.Mesh(g, new THREE.MeshStandardMaterial({ map: flagTex, side: THREE.DoubleSide, roughness: 0.8 }));
      flag.position.set(fx + 0.07, 9.1, fz); flag.castShadow = true; scene.add(flag);
      dyn.flags.push({ mesh: flag, base: g.attributes.position.array.slice() });
    }
    // jardins et flamboyants aux quatre coins, bancs
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
      const gx = cx + sx * 30, gz = cz + sz * 9;
      add('trim', new THREE.BoxGeometry(18.3, 0.22, 8.3), M(gx, 0.06, gz), { cast: false });
      add('grass', planeUV(18, 8, 4, 4), M(gx, 0.18, gz), { cast: false });
      trees.push({ x: gx - 4, z: gz, s: 0.9, r: R() * 6, flamboyant: true });
      trees.push({ x: gx + 4.5, z: gz, s: 0.8, r: R() * 6, flamboyant: R() < 0.5 });
      for (let k = 0; k < 10; k++) tufts.push({ x: gx + (R() - 0.5) * 17, z: gz + (R() - 0.5) * 7, s: 0.7, r: R() * 6 });
      const bx = cx + sx * 12, bz = cz + sz * 6, ry = Math.atan2(cx - bx, cz - bz), base = M(bx, 0, bz, ry);
      add('wood', new THREE.BoxGeometry(1.8, 0.06, 0.45).applyMatrix4(M(0, 0.46, 0)).applyMatrix4(base));
      add('wood', new THREE.BoxGeometry(1.8, 0.4, 0.05).applyMatrix4(M(0, 0.75, -0.22)).applyMatrix4(base));
      col.addCircle(bx, bz, 0.8, 1);
      const p = new THREE.Vector3(0.4, 0, 0).applyMatrix4(base); seats.push({ x: p.x, z: p.z, ry, y: -0.48, kind: 'bench' });
    }
    for (const [lx, lz] of [[cx - 12, cz - 12], [cx + 12, cz - 12], [cx - 12, cz + 12], [cx + 12, cz + 12]]) {
      add('metal', new THREE.CylinderGeometry(0.06, 0.09, 4.6, 8), M(lx, 2.3, lz));
      add('lampHead', new THREE.SphereGeometry(0.28, 12, 8), M(lx, 4.7, lz), { cast: false });
      col.addCircle(lx, lz, 0.15, 5); lamps.push([lx, lz, 0, 0]);
    }
    for (const a of [0.6, 2.2, 3.8, 5.2]) plazaSpots.push({ x: cx + Math.cos(a) * 10, z: cz + Math.sin(a) * 7, target: [cx, cz] });
    martyrs.x = cx; martyrs.z = cz; martyrs.x0 = ix0; martyrs.x1 = ix1; martyrs.z0 = iz0; martyrs.z1 = iz1;
    zones.push({ x0, x1, z0, z1, name: 'Place des Martyrs' });
  }

  function parkBlock(x0, x1, z0, z1) {
    add('grass', planeUV(x1 - x0 - 6, z1 - z0 - 6, 6, 6), M((x0 + x1) / 2, 0.045, (z0 + z1) / 2), { cast: false });
    // terrain de foot en sable
    const fx = (x0 + x1) / 2 + 8, fz = (z0 + z1) / 2 - 6, fw = 44, fd = 26;
    add('sand', planeUV(fw, fd, 6, 6), M(fx, 0.05, fz), { cast: false });
    for (const s of [-1, 1]) {
      const gx = fx + s * (fw / 2 - 1);
      for (const pz of [-3.6, 3.6]) add('white', new THREE.CylinderGeometry(0.07, 0.07, 2.4, 6), M(gx, 1.2, fz + pz));
      add('white', new THREE.CylinderGeometry(0.07, 0.07, 7.2, 6), M(gx, 2.4, fz, 0, PI / 2));
    }
    add('markW', new THREE.PlaneGeometry(0.15, fd - 2).rotateX(-PI / 2), M(fx, 0.06, fz), { cast: false });
    // bancs et arbres
    for (let i = 0; i < 14; i++) {
      const x = x0 + 8 + R() * (x1 - x0 - 16), z = z0 + 8 + R() * (z1 - z0 - 16);
      if (Math.abs(x - fx) < fw / 2 + 3 && Math.abs(z - fz) < fd / 2 + 3) continue;
      if (Math.hypot(x, z) < 32) continue;
      (R() < 0.4 ? palms : trees).push({ x, z, s: 0.9 + R() * 0.5, r: R() * 6.28, flamboyant: R() < 0.4 });
    }
    for (let i = 0; i < 500; i++) {
      const x = x0 + 4 + R() * (x1 - x0 - 8), z = z0 + 4 + R() * (z1 - z0 - 8);
      if (Math.abs(x - fx) < fw / 2 + 1 && Math.abs(z - fz) < fd / 2 + 1) continue;
      if (Math.hypot(x, z) < 26) continue;
      tufts.push({ x, z, s: 0.7 + R() * 0.9, r: R() * 6 });
    }
    for (let i = 0; i < 8; i++) bushes.push({ x: x0 + 6 + R() * (x1 - x0 - 12), z: z1 - 5 - R() * 3, s: 1 + R() * 0.5, r: R() * 6 });
    for (let i = 0; i < 6; i++) {
      const x = fx - fw / 2 + 4 + i * 7, z = fz + fd / 2 + 2.5;
      add('wood', new THREE.BoxGeometry(2, 0.08, 0.5), M(x, 0.5, z));
      add('wood', new THREE.BoxGeometry(2, 0.5, 0.06), M(x, 0.8, z + 0.25));
      col.addBox(x - 1, z - 0.3, x + 1, z + 0.3, 1);
    }
    zones.push({ x0, x1, z0, z1, name: 'Jardin de Cadjèhoun' });
  }

  const QUARTERS = [
    ['Zongo', 'Jéricho', 'Gbégamey', 'Haie Vive'],
    ['Missèbo', 'Ganhi', 'Akpakpa', 'Cadjèhoun'],
    ['Fidjrossè', 'Agla', 'Vèdoko', 'Sikècodji'],
    ['Avotrou', 'Tokpa-Hoho', 'Houéyiho', 'Gbèdjromèdé'],
  ];

  IX.forEach(([x0, x1], i) => IZ.forEach(([z0, z1], j) => {
    addBlockGround(x0, x1, z0, z1);
    const inMap = x1 > MAP.minX && x0 < MAP.maxX && z1 > MAP.minZ;
    if (x0 === -93 && z0 === 7) marketBlock(x0, x1, z0, z1);
    else if (x0 === 7 && z0 === -93) parkBlock(x0, x1, z0, z1);
    else if (x0 === 7 && z0 === 107) martyrsBlock(x0, x1, z0, z1);
    else cityBlock(x0, x1, z0, z1);
    if (inMap) zones.push({ x0, x1, z0, z1, name: 'Quartier ' + QUARTERS[j % 4][i % 4] });
    // chemins de piétons sur les trottoirs
    pedPaths.push([[x0 + 1.5, z0 + 1.5], [x1 - 1.5, z0 + 1.5], [x1 - 1.5, z1 - 1.5], [x0 + 1.5, z1 - 1.5]]);
    blocks.push({ x0: x0 + 1.8, x1: x1 - 1.8, z0: z0 + 1.8, z1: z1 - 1.8 });
  }));

  // ---------- Îlot central et monument ----------
  add('curbRW', new THREE.CylinderGeometry(ISLAND_R, ISLAND_R, 0.35, 48, 1, true), M(0, 0.17, 0), { cast: false });
  add('grass', new THREE.CircleGeometry(ISLAND_R, 48).rotateX(-PI / 2), M(0, 0.35, 0), { cast: false });
  add('stone', new THREE.CylinderGeometry(3.2, 3.6, 1.2, 8), M(0, 0.9, 0));
  add('stone', new THREE.CylinderGeometry(2.4, 2.6, 0.5, 8), M(0, 1.7, 0));
  for (let k = 0; k < 3; k++) {
    const a = k * 2 * PI / 3;
    add('bronze', new THREE.BoxGeometry(0.6, 13, 0.9), M(Math.sin(a) * 1.3, 8.1, Math.cos(a) * 1.3, a, -0.1, 0).multiply(new THREE.Matrix4()), {});
  }
  add('bronze', new THREE.OctahedronGeometry(1.0, 0), M(0, 15.2, 0, 0, 0, 0, 1, 1.6, 1));
  col.addCircle(0, 0, ISLAND_R + 0.2, 20);
  for (let k = 0; k < 10; k++) {
    const a = k * 2 * PI / 10 + 0.3;
    palms.push({ x: Math.sin(a) * 6, z: Math.cos(a) * 6, s: 0.55 + R() * 0.15, r: R() * 6, noCol: true, y: 0.35 });
  }
  // drapeau du Bénin au bord du rond-point
  {
    const fx = 13.5, fz = 13.5;
    add('metal', new THREE.CylinderGeometry(0.08, 0.1, 11, 8), M(fx, 5.5, fz));
    col.addCircle(fx, fz, 0.3, 11);
    const g = new THREE.PlaneGeometry(3, 2, 12, 6);
    g.translate(1.5, 0, 0);
    const flag = new THREE.Mesh(g, new THREE.MeshStandardMaterial({ map: T.benFlag(), side: THREE.DoubleSide, roughness: 0.8 }));
    flag.position.set(fx + 0.08, 9.8, fz);
    flag.castShadow = true;
    scene.add(flag);
    dyn.flags.push({ mesh: flag, base: g.attributes.position.array.slice() });
  }
  zones.unshift({ x0: -ROUND_R - 6, x1: ROUND_R + 6, z0: -ROUND_R - 6, z1: ROUND_R + 6, name: 'Rond-point de l\'Indépendance' });

  // ---------- Plage et océan ----------
  add('sand', planeUV(900, 60, 6, 6), M(0, 0.03, BEACH_Z + 30), { cast: false });
  const seaMat = new THREE.MeshStandardMaterial({ color: 0x1b6f86, roughness: 0.12, metalness: 0.15, normalMap: T.water(), transparent: true, opacity: 0.93 });
  seaMat.normalMap.repeat.set(22, 30);
  seaMat.normalScale.set(0.6, 0.6);
  const sea = new THREE.Mesh(new THREE.PlaneGeometry(900, 1200).rotateX(-PI / 2), seaMat); // au-delà : océan de la région (littoral réel)
  sea.position.set(0, 0.12, SEA_Z + 600);
  sea.receiveShadow = true;
  scene.add(sea);
  const foamMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.45, depthWrite: false });
  const foam = new THREE.Mesh(new THREE.PlaneGeometry(900, 2.2).rotateX(-PI / 2), foamMat);
  foam.position.set(0, 0.14, SEA_Z + 0.6);
  scene.add(foam);
  dyn.sea = sea; dyn.foam = foam;
  for (let i = 0; i < 18; i++) {
    const x = -150 + R() * 300, z = 172 + R() * 14;
    if (Math.abs(x) < 44) continue; // la Place de l'Amazone occupe le front de mer
    const k = 'boat' + Math.floor(R() * 4);
    const rot = (R() - 0.5) * 0.5;
    const hull = new THREE.SphereGeometry(1, 16, 6, 0, PI * 2, PI / 2, PI / 2);
    add(k, hull, M(x, 0.62, z, rot, 0, 0, 0.75, 0.6, 4.2));
    add('wood', new THREE.BoxGeometry(1.2, 0.06, 0.25), M(x, 0.6, z, rot));
    col.addCircle(x + Math.sin(rot) * 2, z + Math.cos(rot) * 2, 0.9, 1);
    col.addCircle(x - Math.sin(rot) * 2, z - Math.cos(rot) * 2, 0.9, 1);
  }
  for (let i = 0; i < 40; i++) palms.push({ x: -170 + R() * 340, z: 161 + R() * 10, s: 0.9 + R() * 0.4, r: R() * 6 });
  for (let i = 0; i < 260; i++) tufts.push({ x: -170 + R() * 340, z: 160 + R() * 9, s: 0.6 + R() * 0.7, r: R() * 6 });
  zones.unshift({ x0: -400, x1: 400, z0: BEACH_Z - 2, z1: 400, name: 'Plage de Fidjrossè' });

  // =================== Mission 006 : Boulevard de la Marina (terre-plein planté) ===================
  {
    const MZ = 152;
    const segs = [[-175, -109.5], [-90.5, -9.5], [9.5, 90.5], [109.5, 175]];
    for (const [a, b] of segs) {
      const L = b - a, mx = (a + b) / 2;
      add('trim', new THREE.BoxGeometry(L, 0.2, 1.7), M(mx, 0.1, MZ), { cast: false });
      add('grass', planeUV(L, 1.4, 4, 4), M(mx, 0.21, MZ), { cast: false });
      col.addBox(a, MZ - 0.85, b, MZ + 0.85, 0.4);
      for (let x = a + 6; x < b - 3; x += 12) palms.push({ x, z: MZ + (Math.round(x) % 2 ? 0.2 : -0.2), s: 0.9 + R() * 0.25, r: R() * 6, noCol: true });
      for (let x = a + 12; x < b - 3; x += 24) {
        add('metal', new THREE.CylinderGeometry(0.08, 0.11, 7.5, 8), M(x, 3.75, MZ));
        for (const s2 of [-1, 1]) {
          add('metal', new THREE.BoxGeometry(0.08, 0.08, 1.7), M(x, 7.35, MZ + s2 * 0.8));
          add('lampHead', new THREE.BoxGeometry(0.35, 0.15, 0.7), M(x, 7.3, MZ + s2 * 1.55), { cast: false });
          lamps.push([x, MZ + s2 * 2.6, 0, 0]);
        }
      }
      for (let k = 0; k < Math.floor(L / 3); k++) bushes.push({ x: a + 1.5 + k * 3, z: MZ, s: 0.55, r: R() * 6, y: 0.1 });
    }
    // plaques de rue (côté ville)
    for (const x of [-120, -50, 50, 120]) { add('metal', new THREE.CylinderGeometry(0.04, 0.04, 2.6, 6), M(x, 1.3, 145.3)); plateSign(0, x, 2.75, 145.3, 0, 2.4, 0.3, true); col.addCircle(x, 145.3, 0.1, 3); }
    for (const z of [-60, 60]) { add('metal', new THREE.CylinderGeometry(0.04, 0.04, 2.6, 6), M(9.6, 1.3, z)); plateSign(1, 9.6, 2.75, z, -PI / 2, 2.4, 0.3, true); col.addCircle(9.6, z, 0.1, 3); }
  }

  // =================== Zone côtière : paillotes, maquis de plage, filets, pêcheurs ===================
  {
    for (const px of [-130, -100, -70, 70, 100, 130]) {
      const pz = 166, base = M(px, 0, pz, 0);
      for (const sx of [-2, 2]) for (const sz of [-2, 2]) add('wood', new THREE.CylinderGeometry(0.1, 0.12, 2.7, 6), M(px + sx, 1.35, pz + sz));
      const roof = new THREE.ConeGeometry(4, 1.8, 10, 1, true); add('straw', roof, M(px, 3.5, pz));
      add('wood', new THREE.BoxGeometry(2.2, 0.08, 1.0), M(px, 0.95, pz - 1.0));
      add('wood', new THREE.BoxGeometry(2.2, 0.95, 0.08), M(px, 0.48, pz - 1.45));
      for (let k = 0; k < 4; k++) add('bottle', new THREE.CylinderGeometry(0.05, 0.05, 0.28, 6), M(px - 0.8 + k * 0.5, 1.13, pz - 1.0), { cast: false });
      col.addBox(px - 1.2, pz - 1.6, px + 1.2, pz - 0.5, 1.2);
      for (const [tx, tz] of [[px - 4.5, pz + 3], [px + 4.5, pz + 3]]) {
        add('plastic', new THREE.CylinderGeometry(0.45, 0.45, 0.05, 12), M(tx, 0.72, tz)); add('plastic', new THREE.CylinderGeometry(0.05, 0.05, 0.72, 6), M(tx, 0.36, tz));
        col.addCircle(tx, tz, 0.5, 1);
        for (const a of [0.5, 3.6]) {
          const sx2 = tx + Math.sin(a) * 0.85, sz2 = tz + Math.cos(a) * 0.85;
          add('plasticR', new THREE.BoxGeometry(0.45, 0.45, 0.45), M(sx2, 0.22, sz2, a), { cast: false });
          if (R() < 0.7) seats.push({ x: sx2, z: sz2, ry: a + PI, y: -0.52, kind: 'beach' });
        }
      }
      idleSpots.push({ x: px, z: pz - 2.1, ry: 0 }); // tenancière derrière le comptoir
    }
    // filets de pêche qui sèchent, pêcheurs près des pirogues
    for (const nx of [-120, -84, 84, 120]) {
      for (const k of [-3, 3]) add('wood', new THREE.CylinderGeometry(0.06, 0.06, 2.2, 6), M(nx + k, 1.1, 180));
      add('net', new THREE.PlaneGeometry(6, 1.8), M(nx, 1.2, 180));
      col.addBox(nx - 3.1, 179.8, nx + 3.1, 180.2, 2);
      for (let k = 0; k < 2; k++) idleSpots.push({ x: nx - 2 + k * 3.5, z: 181.5, ry: PI + (R() - 0.5) });
    }
    add('metal', new THREE.CylinderGeometry(0.05, 0.05, 2.4, 6), M(-55, 1.2, 163)); plateSign(7, -55, 2.6, 163, PI, 2.6, 0.32, true); col.addCircle(-55, 163, 0.1, 3);
  }

  // =================== Mission 006 : Place de l'Amazone (front de mer, au bout du boulevard nord-sud) ===================
  const AMZ = { x: 0, z: 174, x0: -36, x1: 36, z0: BEACH_Z + 0.5, z1: 188 };
  const statueLights = [];
  {
    const cx = AMZ.x, cz = AMZ.z, W = AMZ.x1 - AMZ.x0, D = AMZ.z1 - AMZ.z0, mz = (AMZ.z0 + AMZ.z1) / 2;
    add('pave', planeUV(W, D, 4, 4), M(cx, 0.05, mz), { cast: false });
    // bordures de l'esplanade
    add('trim', new THREE.BoxGeometry(W, 0.18, 0.3), M(cx, 0.09, AMZ.z0), { cast: false });
    for (const sx of [AMZ.x0, AMZ.x1]) add('trim', new THREE.BoxGeometry(0.3, 0.18, D), M(sx, 0.09, mz), { cast: false });
    // allée centrale en dalles claires depuis la route
    add('sidewalk', planeUV(8, D, 2, 2), M(cx, 0.055, mz), { cast: false });
    // socle à gradins
    for (const [r, y] of [[10.5, 0.06], [9.2, 0.12], [7.9, 0.18]]) add('stone', new THREE.CylinderGeometry(r, r, 0.06, 48), M(cx, y, cz), { cast: false });
    add('markY', new THREE.RingGeometry(10.5, 10.7, 64).rotateX(-PI / 2), M(cx, 0.1, cz), { cast: false });
    // piédestal
    add('stone', new THREE.BoxGeometry(5.2, 1.0, 5.2), M(cx, 0.7, cz));
    add('stone', new THREE.BoxGeometry(3.8, 5.0, 3.8), M(cx, 3.7, cz));
    add('trim', new THREE.BoxGeometry(4.4, 0.4, 4.4), M(cx, 6.4, cz));
    add('bronze', new THREE.BoxGeometry(4.0, 0.12, 4.0), M(cx, 6.66, cz));
    col.addBox(cx - 2.7, cz - 2.7, cx + 2.7, cz + 2.7, 20);
    // plaque et panneau d'information
    const signTex = amazoneSigns();
    mats.amzSign = std({ map: signTex, roughness: 0.5, metalness: 0.2 });
    { const g = new THREE.PlaneGeometry(3.2, 0.62); const uv = g.attributes.uv; for (let i = 0; i < uv.count; i++) uv.setY(i, 1 - (1 - uv.getY(i)) * (200 / 512)); add('amzSign', g, M(cx, 3.4, cz - 1.91, PI), { cast: false }); }
    { const g = new THREE.PlaneGeometry(3.0, 0.9); const uv = g.attributes.uv; for (let i = 0; i < uv.count; i++) uv.setY(i, uv.getY(i) * (302 / 512)); add('amzSign', g, M(7, 1.45, 162.4, PI), { cast: false });
      add('metal', new THREE.BoxGeometry(3.1, 1.0, 0.06), M(7, 1.45, 162.45)); for (const sx of [-1.4, 1.4]) add('metal', new THREE.CylinderGeometry(0.04, 0.04, 1.9, 6), M(7 + sx, 0.95, 162.45)); col.addBox(5.4, 162.2, 8.6, 162.7, 2); }
    // statue (provisoire, procédurale) tournée vers la ville
    const statue = createAmazoneStatue(9.5);
    statue.position.set(cx, 6.72, cz); statue.rotation.y = PI;
    scene.add(statue);
    // éclairage de la statue la nuit
    for (const sx of [-1, 1]) {
      const l = new THREE.SpotLight(0xffe2b0, 0, 40, 0.22, 0.7, 1.0);
      l.position.set(cx + sx * 7, 0.4, cz - 11); l.target.position.set(cx, 12.5, cz);
      scene.add(l, l.target);
      nightMats.push({ mat: l, max: 110, prop: 'intensity' });
      add('metal', new THREE.BoxGeometry(0.4, 0.3, 0.4), M(cx + sx * 6, 0.2, cz - 6), { cast: false });
    }
    // drapeaux du Bénin
    const flagTex = T.benFlag();
    for (const fx of [-14, 14]) {
      const fz = AMZ.z0 + 4;
      add('metal', new THREE.CylinderGeometry(0.08, 0.1, 12, 8), M(fx, 6, fz));
      col.addCircle(fx, fz, 0.3, 12);
      const g = new THREE.PlaneGeometry(3, 2, 12, 6); g.translate(1.5, 0, 0);
      const flag = new THREE.Mesh(g, new THREE.MeshStandardMaterial({ map: flagTex, side: THREE.DoubleSide, roughness: 0.8 }));
      flag.position.set(fx + 0.08, 10.8, fz); flag.castShadow = true; scene.add(flag);
      dyn.flags.push({ mesh: flag, base: g.attributes.position.array.slice() });
    }
    // jardins tropicaux aux quatre coins
    for (const sx of [-1, 1]) for (const [z0, z1] of [[AMZ.z0 + 1, AMZ.z0 + 9], [AMZ.z1 - 9, AMZ.z1 - 1.5]]) {
      const gx = sx * 25, gz = (z0 + z1) / 2;
      add('trim', new THREE.BoxGeometry(16.3, 0.22, z1 - z0 + 0.3), M(gx, 0.06, gz), { cast: false });
      add('grass', planeUV(16, z1 - z0, 4, 4), M(gx, 0.18, gz), { cast: false });
      for (let k = 0; k < 3; k++) palms.push({ x: gx - 6 + k * 6, z: gz + (k % 2 ? 1 : -1), s: 0.9 + R() * 0.3, r: R() * 6 });
      for (let k = 0; k < 3; k++) bushes.push({ x: gx - 5 + k * 5, z: gz + (k % 2 ? -2 : 2), s: 1.1, r: R() * 6 });
      for (let k = 0; k < 14; k++) tufts.push({ x: gx + (R() - 0.5) * 15, z: gz + (R() - 0.5) * (z1 - z0 - 1), s: 0.7 + R() * 0.5, r: R() * 6 });
    }
    // bancs tournés vers la statue
    for (const [bx, bz] of [[-14, 168], [14, 168], [-14, 180], [14, 180], [-6, 186], [6, 186]]) {
      const ry = Math.atan2(cx - bx, cz - bz);
      const base = M(bx, 0, bz, ry);
      add('wood', new THREE.BoxGeometry(1.8, 0.06, 0.45).applyMatrix4(M(0, 0.46, 0)).applyMatrix4(base));
      add('wood', new THREE.BoxGeometry(1.8, 0.4, 0.05).applyMatrix4(M(0, 0.75, -0.22)).applyMatrix4(base));
      for (const px of [-0.8, 0.8]) add('metal', new THREE.BoxGeometry(0.05, 0.46, 0.42).applyMatrix4(M(px, 0.23, 0)).applyMatrix4(base));
      col.addCircle(bx, bz, 0.8, 1);
      const p = new THREE.Vector3(0.4, 0, 0).applyMatrix4(base);
      seats.push({ x: p.x, z: p.z, ry, y: -0.48, kind: 'bench' });
    }
    // lampadaires de l'esplanade
    for (const [lx, lz] of [[-30, 163], [30, 163], [-30, 185], [30, 185], [-10, 163], [10, 163], [-18, 174], [18, 174]]) {
      add('metal', new THREE.CylinderGeometry(0.06, 0.09, 4.6, 8), M(lx, 2.3, lz));
      add('lampHead', new THREE.SphereGeometry(0.28, 12, 8), M(lx, 4.7, lz), { cast: false });
      col.addCircle(lx, lz, 0.15, 5);
      lamps.push([lx, lz, 0, 0]);
    }
    // garde-corps côté mer
    { const g = new THREE.PlaneGeometry(W, 0.95); const uv = g.attributes.uv; for (let i = 0; i < uv.count; i++) uv.setX(i, uv.getX(i) * W / 2); add('balustrade', g, M(cx, 0.55, AMZ.z1 + 0.1)); }
    col.addBox(AMZ.x0, AMZ.z1, AMZ.x1, AMZ.z1 + 0.4, 1.2);
    // visiteurs qui regardent la statue
    for (const a of [-2.4, -1.2, 1.2, 2.4]) plazaSpots.push({ x: cx + Math.sin(a + PI) * 13, z: cz + Math.cos(a + PI) * 13 * 0.7, target: [cx, cz] });
    zones.unshift({ x0: AMZ.x0 - 2, x1: AMZ.x1 + 2, z0: BEACH_Z - 0.5, z1: AMZ.z1 + 3, name: 'Place de l\'Amazone' });
  }

  // ---------- Poteaux électriques, câbles, lampadaires ----------
  const wirePts = [];
  for (const z of LINES_Z) {
    const pz = z - ROAD_HALF - 1.2;
    let prev = null;
    for (let x = -168; x <= 168; x += 28) {
      if (nearCross(x, LINES_X.map((l) => l)) || Math.hypot(x, pz) < ROUND_R + 6) { prev = null; continue; }
      add('pole', new THREE.CylinderGeometry(0.12, 0.17, 8.5, 6), M(x, 4.25, pz));
      add('pole', new THREE.BoxGeometry(1.6, 0.12, 0.12), M(x, 7.9, pz));
      col.addCircle(x, pz, 0.25, 8);
      if (prev !== null) {
        for (const off of [-0.7, 0, 0.7]) {
          const N = 8;
          for (let k = 0; k < N; k++) {
            const t0 = k / N, t1 = (k + 1) / N;
            const sag = (t) => 7.95 - Math.sin(t * PI) * 0.9;
            wirePts.push(prev + (x - prev) * t0 + off, sag(t0), pz, prev + (x - prev) * t1 + off, sag(t1), pz);
          }
        }
      }
      prev = x;
    }
  }
  const wireGeo = new THREE.BufferGeometry();
  wireGeo.setAttribute('position', new THREE.Float32BufferAttribute(wirePts, 3));
  scene.add(new THREE.LineSegments(wireGeo, new THREE.LineBasicMaterial({ color: 0x1a1a1a })));

  for (let t = -150; t <= 150; t += 30) {
    for (const s of [-1, 1]) {
      // boulevard nord-sud (x = 0) et est-ouest (z = 0)
      for (const [x, z, ry] of [[s * (ROAD_HALF + 1.0), t, s > 0 ? -PI / 2 : PI / 2], [t, s * (ROAD_HALF + 1.0), s > 0 ? PI : 0]]) {
        if (Math.hypot(x, z) < ROUND_R + 4) continue;
        if (nearCross(Math.abs(x) < 10 ? z : x, Math.abs(x) < 10 ? LINES_Z : LINES_X)) continue;
        add('metal', new THREE.CylinderGeometry(0.07, 0.1, 7, 6), M(x, 3.5, z));
        const base = M(x, 0, z, ry);
        add('metal', new THREE.BoxGeometry(0.08, 0.08, 1.8).applyMatrix4(M(0, 6.9, 0.85)).applyMatrix4(base));
        add('lampHead', new THREE.BoxGeometry(0.35, 0.15, 0.7).applyMatrix4(M(0, 6.85, 1.7)).applyMatrix4(base), { cast: false });
        col.addCircle(x, z, 0.2, 7);
        lamps.push([x, z, Math.abs(x) < 12 ? -Math.sign(x) * 1.7 : 0, Math.abs(x) < 12 ? 0 : -Math.sign(z) * 1.7]);
      }
    }
  }
  // flamboyants le long du boulevard nord-sud
  for (let t = -145; t <= 145; t += 30) {
    for (const s2 of [-1, 1]) {
      const x = s2 * (ROAD_HALF + 2.55), z = t + 15;
      if (Math.hypot(x, z) < ROUND_R + 8 || nearCross(z, LINES_Z)) continue;
      trees.push({ x, z, s: 0.85, r: z, flamboyant: true });
    }
  }
  // =================== Mission 005 : mobilier urbain, passages piétons, feux ===================
  const tmpP = new THREE.Vector3();
  const free = (x, z, r) => { tmpP.set(x, 0, z); col.resolve(tmpP, r); return Math.hypot(tmpP.x - x, tmpP.z - z) < 0.01; };
  const atlasR = T.roadSignAtlas();
  mats.roadSign = std({ map: atlasR.texture, roughness: 0.5 });
  mats.binG = std({ color: 0x2e7d4f, roughness: 0.6 });
  mats.binB = std({ color: 0x1f5b9c, roughness: 0.6 });
  mats.coals = std({ color: 0x3a1a0a, emissive: new THREE.Color(0xff5a10), emissiveIntensity: 0.6 });
  nightMats.push({ mat: mats.coals, max: 1.6 });
  function signPost(x, z, ry, uvRect, size = 0.75, h = 2.3, board = false) {
    const base = M(x, 0, z, ry);
    add('metal', new THREE.CylinderGeometry(0.04, 0.04, h + (board ? 0.3 : 0), 6).applyMatrix4(M(0, (h + (board ? 0.3 : 0)) / 2, 0)).applyMatrix4(base));
    const w = board ? 2.4 : size, hh = board ? 0.3 : size;
    const g = new THREE.PlaneGeometry(w, hh);
    const uv = g.attributes.uv; for (let i = 0; i < uv.count; i++) uv.setXY(i, uvRect[0] + uv.getX(i) * (uvRect[2] - uvRect[0]), uvRect[1] + uv.getY(i) * (uvRect[3] - uvRect[1]));
    add('roadSign', g.applyMatrix4(M(0, h, 0.03)).applyMatrix4(base), { cast: false });
    add('metal', new THREE.BoxGeometry(w, hh, 0.03).applyMatrix4(M(0, h, 0)).applyMatrix4(base));
    col.addCircle(x, z, 0.12, 3);
  }
  // --- intersections : feux, passages piétons, panneaux ---
  const lightIntersections = [], crosswalks = [];
  const inMapPt = (x, z) => x > MAP.minX + 5 && x < MAP.maxX - 5 && z > MAP.minZ + 5 && z < BEACH_Z;
  for (const X of LINES_X) for (const Z of LINES_Z) {
    if (X === 0 && Z === 0) continue; // rond-point
    const T = Z === 152;              // jonctions en T avec la route de la plage
    if (!T) lightIntersections.push({ x: X, z: Z, offset: Math.random() * 20 });
    // passages piétons sur chaque branche
    const arms = [[0, -1], [0, 1], [-1, 0], [1, 0]].filter(([ax, az]) => !(T && az > 0));
    for (const [ax, az] of arms) {
      const d = ROAD_HALF + 2.0;
      const cx = X + ax * d, cz = Z + az * d;
      if (!inMapPt(cx, cz)) continue;
      // la branche est une route verticale si az != 0 : on traverse selon x
      const alongX = az !== 0;
      const a = alongX ? [X - 8.8, cz] : [cx, Z - 8.8], b = alongX ? [X + 8.8, cz] : [cx, Z + 8.8];
      crosswalks.push({ a, b, cx, cz, alongX });
      for (let k = -2; k <= 2; k++) {
        const g = new THREE.PlaneGeometry(alongX ? 0.55 : 2.4, alongX ? 2.4 : 0.55).rotateX(-PI / 2);
        add('markW', g, M(alongX ? X + k * 1.25 * 2.2 : cx, 0.04, alongX ? cz : Z + k * 1.25 * 2.2), { cast: false });
      }
      // ligne d'arrêt
      add('markW', new THREE.PlaneGeometry(alongX ? ROAD_HALF : 0.3, alongX ? 0.3 : ROAD_HALF).rotateX(-PI / 2),
        M(alongX ? X + az * ROAD_HALF / 2 : cx + ax * 1.6, 0.04, alongX ? cz + az * 1.6 : Z - ax * ROAD_HALF / 2), { cast: false });
      // panneau « passage piétons » ou STOP (jonction en T, sur la branche secondaire)
      const sx = alongX ? X + az * 8.3 : cx + ax * 1.2, sz = alongX ? cz + az * 1.2 : Z - ax * 8.3;
      const face = alongX ? (az > 0 ? 0 : PI) : (ax > 0 ? PI / 2 : -PI / 2);
      if (free(sx, sz, 0.3)) signPost(sx, sz, face, atlasR.icon(T && az < 0 ? 0 : 3));
    }
  }
  // cédez le passage à l'entrée du rond-point, panneau de feux avant les carrefours, limitation à 50
  for (const [x, z, ry] of [[-8.4, -29, PI], [8.4, 29, 0], [-29, 8.4, -PI / 2], [29, -8.4, PI / 2]]) if (free(x, z, 0.3)) signPost(x, z, ry, atlasR.icon(1));
  for (const [x, z, ry] of [[-8.4, -60, PI], [8.4, 60, 0], [-60, 8.4, -PI / 2], [60, -8.4, PI / 2], [-8.4, 125, PI]]) if (free(x, z, 0.3)) signPost(x, z, ry, atlasR.icon(2));
  for (const [x, z, ry] of [[-8.4, -82, PI], [8.4, 82, 0], [82, -8.4, PI / 2], [-82, 8.4, -PI / 2]]) if (free(x, z, 0.3)) signPost(x, z, ry, atlasR.icon(6));
  // panneaux directionnels autour du rond-point
  for (const [x, z, ry, k] of [[9.2, -33, PI, 0], [-9.2, 33, 0, 1], [33, 9.2, PI / 2, 2], [-33, -9.2, -PI / 2, 3]]) if (free(x, z, 0.4)) signPost(x, z, ry, atlasR.board(k), 0.75, 2.8, true);

  // --- abribus (arrêts de transport) ---
  const busStops = [[9.6, -52, -PI / 2], [-9.6, 52, PI / 2], [9.6, 120, -PI / 2], [52, -9.6, 0], [-52, 9.6, PI], [-120, -9.6, 0]];
  for (const [x, z, ry] of busStops) {
    if (!free(x, z, 1.4)) continue;
    const base = M(x, 0, z, ry);
    const L = (g, a, b, c) => g.applyMatrix4(M(a, b, c)).applyMatrix4(base);
    add('tinBlue', L(new THREE.BoxGeometry(3.4, 0.08, 1.5), 0, 2.45, 0.05));
    for (const px of [-1.55, 1.55]) for (const pz of [-0.55, 0.55]) add('metal', L(new THREE.CylinderGeometry(0.04, 0.04, 2.45, 6), px, 1.22, pz));
    add('mural', (() => { const g = new THREE.PlaneGeometry(3.1, 1.5); const uv = g.attributes.uv; for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * 0.5, 0.5 + uv.getY(i) * 0.5); return L(g, 0, 1.35, -0.6); })(), { cast: false });
    add('metal', L(new THREE.BoxGeometry(3.2, 1.6, 0.04), 0, 1.35, -0.63));
    add('wood', L(new THREE.BoxGeometry(2.6, 0.06, 0.42), 0, 0.46, -0.32));
    for (const px of [-1.1, 1.1]) add('metal', L(new THREE.BoxGeometry(0.05, 0.46, 0.38), px, 0.23, -0.32));
    const sp = new THREE.Vector3(2.0, 0, 0.5).applyMatrix4(base);
    signPost(sp.x, sp.z, ry, atlasR.icon(4), 0.6, 2.5);
    const back = new THREE.Vector3(0, 0, -0.5).applyMatrix4(base);
    col.addCircle(back.x, back.z, 0.9, 2.6);
    for (const px of [-0.7, 0.6]) { const p = new THREE.Vector3(px, 0, -0.32).applyMatrix4(base); seats.push({ x: p.x, z: p.z, ry, y: -0.48, kind: 'bus' }); }
  }

  // --- stations de zémidjans (motos garées au bord de la chaussée) ---
  const zemSpots = [];
  for (const [x0, z, dir] of [[-46, 5.9, 1], [24, -5.9, -1], [-60, 146.2, 1], [60, 94.1, -1]]) {
    for (let k = 0; k < 5; k++) zemSpots.push({ x: x0 + k * 1.25, z, h: dir > 0 ? 0 : PI });
    const sx = x0 - 1.5, sz = z + dir * 2.8;
    if (free(sx, sz, 0.3)) signPost(sx, sz, dir > 0 ? PI : 0, atlasR.icon(7), 0.6, 2.2);
  }

  // --- poubelles et bancs le long des trottoirs ---
  const sideSpots = [];
  for (let t = -140; t <= 140; t += 24) {
    for (const sgn of [-1, 1]) {
      sideSpots.push([sgn * 9.7, t + 7, sgn > 0 ? -PI / 2 : PI / 2]);
      sideSpots.push([t + 7, sgn * 9.7, sgn > 0 ? PI : 0]);
    }
  }
  let nb = 0;
  for (const [x, z, ry] of sideSpots) {
    if (Math.hypot(x, z) < 30 || !inMapPt(x, z)) continue;
    if (z > 5 && z < 12 && ((x > 52 && x < 66) || (x > 76 && x < 91))) continue; // entrée et parking de NOVA BOOK dégagés
    if (nearCross(Math.abs(x) < 12 ? z : x, Math.abs(x) < 12 ? LINES_Z : LINES_X)) continue;
    if (!free(x, z, 1.0)) continue;
    const base = M(x, 0, z, ry);
    if (nb++ % 3 === 2) {
      // banc public
      add('wood', new THREE.BoxGeometry(1.8, 0.06, 0.45).applyMatrix4(M(0, 0.46, 0)).applyMatrix4(base));
      add('wood', new THREE.BoxGeometry(1.8, 0.4, 0.05).applyMatrix4(M(0, 0.75, -0.22)).applyMatrix4(base));
      for (const px of [-0.8, 0.8]) add('metal', new THREE.BoxGeometry(0.05, 0.46, 0.42).applyMatrix4(M(px, 0.23, 0)).applyMatrix4(base));
      col.addBox(x - 0.5, z - 0.5, x + 0.5, z + 0.5, 1);
      const p = new THREE.Vector3(0.4, 0, 0).applyMatrix4(base);
      seats.push({ x: p.x, z: p.z, ry, y: -0.48, kind: 'bench' });
    } else {
      // poubelle
      add(nb % 2 ? 'binG' : 'binB', new THREE.CylinderGeometry(0.3, 0.26, 0.9, 12).applyMatrix4(M(0, 0.45, 0)).applyMatrix4(base));
      add('metal', new THREE.CylinderGeometry(0.33, 0.33, 0.06, 12).applyMatrix4(M(0, 0.92, 0)).applyMatrix4(base));
      col.addCircle(x, z, 0.33, 1);
    }
  }

  // --- grillades de rue (petits restaurants) : brasero, tabourets, fumée ---
  const smokeSpots = [];
  const grillSpots = [[9.6, 22, -PI / 2], [-9.6, -38, PI / 2], [38, 9.6, PI], [-22, -9.6, 0], [9.6, 108, -PI / 2], [-30, 143.6, 0]];
  for (const [x, z, ry] of grillSpots) {
    if (!free(x, z, 1.3)) continue;
    const base = M(x, 0, z, ry);
    const L = (g, a, b, c) => g.applyMatrix4(M(a, b, c)).applyMatrix4(base);
    add('metal', L(new THREE.BoxGeometry(1.0, 0.18, 0.5), 0, 0.82, 0));
    add('coals', L(new THREE.BoxGeometry(0.9, 0.04, 0.42), 0, 0.92, 0), { cast: false });
    for (const px of [-0.45, 0.45]) for (const pz of [-0.2, 0.2]) add('metal', L(new THREE.CylinderGeometry(0.02, 0.02, 0.8, 4), px, 0.4, pz));
    for (let k = 0; k < 5; k++) add('goods' + (k % 2 ? 0 : 3), L(new THREE.BoxGeometry(0.12, 0.05, 0.3), -0.35 + k * 0.17, 0.96, 0), { cast: false });
    const tk = 'tarp' + (Math.abs(Math.round(x + z)) % 5);
    add('wood', L(new THREE.CylinderGeometry(0.035, 0.035, 2.3, 5), 0.9, 1.15, -0.2));
    add(tk, L(new THREE.ConeGeometry(1.6, 0.45, 10, 1, true), 0.9, 2.4, -0.2));
    for (const [px, pz] of [[-0.6, 1.0], [0.6, 1.0]]) {
      add('plasticR', L(new THREE.CylinderGeometry(0.17, 0.15, 0.42, 10), px, 0.21, pz));
      const p = new THREE.Vector3(px, 0, pz).applyMatrix4(base);
      seats.push({ x: p.x, z: p.z, ry: ry + PI, y: -0.52, kind: 'stool' });
    }
    col.addCircle(x, z, 0.65, 1);
    const sp = new THREE.Vector3(0, 1.0, 0).applyMatrix4(base);
    smokeSpots.push([sp.x, sp.z]);
  }

  // --- lampadaires sur les autres rues (alternés de part et d'autre) ---
  for (const Z of [-100, 100, 152]) for (let t = -135; t <= 135; t += 30) {
    const side = (Math.round(t / 30) % 2 === 0) ? 1 : -1;
    if (Z === 152 && side > 0) continue;
    const x = t, z = Z + side * (ROAD_HALF + 1.6);
    if (nearCross(x, LINES_X) || !free(x, z, 0.5)) continue;
    const ry = side > 0 ? PI : 0, base = M(x, 0, z, ry);
    add('metal', new THREE.CylinderGeometry(0.07, 0.1, 7, 6), M(x, 3.5, z));
    add('metal', new THREE.BoxGeometry(0.08, 0.08, 1.8).applyMatrix4(M(0, 6.9, 0.85)).applyMatrix4(base));
    add('lampHead', new THREE.BoxGeometry(0.35, 0.15, 0.7).applyMatrix4(M(0, 6.85, 1.7)).applyMatrix4(base), { cast: false });
    col.addCircle(x, z, 0.2, 7);
    lamps.push([x, z, 0, -side * 1.7]);
  }
  for (const X of [-100, 100]) for (let t = -135; t <= 135; t += 30) {
    const side = (Math.round(t / 30) % 2 === 0) ? 1 : -1;
    const x = X + side * (ROAD_HALF + 1.0), z = t;
    if (nearCross(z, LINES_Z) || !free(x, z, 0.5)) continue;
    const ry = side > 0 ? -PI / 2 : PI / 2, base = M(x, 0, z, ry);
    add('metal', new THREE.CylinderGeometry(0.07, 0.1, 7, 6), M(x, 3.5, z));
    add('metal', new THREE.BoxGeometry(0.08, 0.08, 1.8).applyMatrix4(M(0, 6.9, 0.85)).applyMatrix4(base));
    add('lampHead', new THREE.BoxGeometry(0.35, 0.15, 0.7).applyMatrix4(M(0, 6.85, 1.7)).applyMatrix4(base), { cast: false });
    col.addCircle(x, z, 0.2, 7);
    lamps.push([x, z, -side * 1.7, 0]);
  }

  // halos lumineux au sol sous les lampadaires (éclairage nocturne simulé, très économique)
  {
    const c = document.createElement('canvas'); c.width = c.height = 128;
    const x = c.getContext('2d'), g = x.createRadialGradient(64, 64, 0, 64, 64, 64);
    g.addColorStop(0, 'rgba(255,214,150,1)'); g.addColorStop(0.5, 'rgba(255,190,120,0.45)'); g.addColorStop(1, 'rgba(255,170,100,0)');
    x.fillStyle = g; x.fillRect(0, 0, 128, 128);
    const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace;
    const poolMat = new THREE.MeshBasicMaterial({ map: tex, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, fog: true });
    const pool = new THREE.InstancedMesh(new THREE.PlaneGeometry(13, 13).rotateX(-PI / 2), poolMat, lamps.length);
    const dm = new THREE.Object3D();
    lamps.forEach(([lx, lz, ox, oz], i) => {
      dm.position.set(lx + ox, 0.07, lz + oz); dm.updateMatrix(); pool.setMatrixAt(i, dm.matrix);
    });
    pool.renderOrder = 2; pool.userData.noAO = true;
    scene.add(pool);
    nightMats.push({ mat: poolMat, max: 0.55, prop: 'opacity' });
  }

  // palmiers le long de la route de la plage
  for (let x = -160; x <= 160; x += 16) {
    if (nearCross(x, LINES_X)) continue;
    palms.push({ x: x + 4, z: 152 + ROAD_HALF + 1.6, s: 1.0, r: x });
  }

  // ---------- Voitures garées (conduisibles) ----------
  parkedCars.push({ x: 5.7, z: 44, h: PI, color: 0xf2f2f2 });
  parkedCars.push({ x: -5.7, z: 60, h: 0, color: 0xc8102e, model: 'pickup' });
  parkedCars.push({ x: 40, z: 158.0, h: -PI / 2, color: 0xf2c200, model: 'minibus' });
  parkedCars.push({ x: -60, z: -4.5, h: PI / 2, color: 0x1f4e9c });
  // Mission 004 : citadines, moto et voitures garées le long des rues (côté droit de la chaussée)
  parkedCars.push({ x: -5.8, z: 48, h: 0, color: 0x7fb8d8, model: 'citadine' });
  parkedCars.push({ x: 9.6, z: 50.5, h: PI * 0.92, color: 0xc8102e, model: 'moto' });
  parkedCars.push({ x: 5.8, z: 72, h: PI, color: 0xe8e2d0, model: 'citadine' });
  parkedCars.push({ x: 30, z: -4.6, h: PI / 2, color: 0xf2f2f2, model: 'sedan' });
  parkedCars.push({ x: 60, z: 5.8, h: -PI / 2, color: 0xd8643a, model: 'citadine' });
  parkedCars.push({ x: -94.0, z: 40, h: 0, color: 0x2e6b3a, model: 'citadine' });
  parkedCars.push({ x: -30, z: 105.8, h: -PI / 2, color: 0x1a1a1a, model: 'sedan' });
  parkedCars.push({ x: 70, z: 146.0, h: PI / 2, color: 0x1f4e9c, model: 'moto' });

  // ---------- Horizon : silhouettes lointaines ----------
  {
    const color = new THREE.Color();
    const pal = [0xe9dfc8, 0xe7b95a, 0x9fc4d6, 0xe59a7f, 0xf1efe9, 0xc96a45, 0xd6d1c4];
    for (let i = 0; i < 260; i++) {
      const a = R() * PI * 2, rr = 185 + R() * 140;
      const x = Math.cos(a) * rr, z = Math.sin(a) * rr;
      if (z > BEACH_Z - 20) continue;
      if (Math.abs(x) < 175 && Math.abs(z) < 175) continue;
      const g = new THREE.BoxGeometry(6 + R() * 10, 3 + R() * 10, 6 + R() * 10);
      g.translate(0, g.parameters.height / 2, 0);
      color.setHex(pick(R, pal)).multiplyScalar(0.8 + R() * 0.2);
      const cols = new Float32Array(g.attributes.position.count * 3);
      for (let k = 0; k < cols.length; k += 3) { cols[k] = color.r; cols[k + 1] = color.g; cols[k + 2] = color.b; }
      g.setAttribute('color', new THREE.BufferAttribute(cols, 3));
      add('far', g, M(x, 0, z, R() * PI), { cast: false });
      if (R() < 0.6) trees.push({ x: x + 8, z: z + 4, s: 1 + R() * 0.6, r: R() * 6, noCol: true });
    }
  }

  {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(edgePos, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(edgeUv, 2));
    g.computeVertexNormals();
    const n = g.attributes.normal; for (let i = 0; i < n.count; i++) n.setXYZ(i, 0, 1, 0);
    const m = new THREE.Mesh(g, mats.sandEdge);
    m.receiveShadow = true; m.renderOrder = 1; m.userData.noAO = true;
    scene.add(m);
  }

  // ---------- Fusion des lots de géométrie ----------
  let drawCalls = 0;
  for (const [key, b] of batches) {
    const mat = mats[key];
    if (!mat) { console.warn('matériau manquant', key); continue; }
    const merged = mergeGeometries(b.geos, false);
    if (!merged) { console.warn('fusion impossible', key); continue; }
    merged.computeBoundingSphere();
    const mesh = new THREE.Mesh(merged, mat);
    mesh.castShadow = b.cast && !key.startsWith('far') && !['laterite', 'asphalt', 'pave', 'sidewalk', 'sand', 'grass'].includes(key);
    mesh.receiveShadow = b.receive;
    mesh.matrixAutoUpdate = false;
    if (mat.alphaTest > 0 || mat.transparent) mesh.userData.noAO = true;
    mesh.updateMatrix();
    scene.add(mesh);
    drawCalls++;
  }

  // ---------- Végétation instanciée ----------
  {
    const inPlaza = (o) => o.x > AMZ.x0 - 1 && o.x < AMZ.x1 + 1 && o.z > AMZ.z0 && o.z < AMZ.z1 + 1 && !(Math.abs(Math.abs(o.x) - 25) < 8.5);
    for (const arr of [palms, tufts]) for (let i = arr.length - 1; i >= 0; i--) if (inPlaza(arr[i])) arr.splice(i, 1);
  }
  // ---- Mission 010 : maison du joueur (terrain réservé, végétation aléatoire retirée de la parcelle) ----
  {
    const inLot = (o) => [HOME_LOT, GARAGE_LOT, SUPER_LOT, NOVA_LOT].some((L) => o.x > L.x0 - 0.8 && o.x < L.x1 + 0.8 && o.z > L.z0 - 0.8 && o.z < L.z1 + 0.8);
    for (const arr of [palms, trees, bushes, bananas, tufts]) for (let i = arr.length - 1; i >= 0; i--) if (inLot(arr[i])) arr.splice(i, 1);
  }
  const home = new Home({ scene, col, palms, trees, bushes, tufts, nightMats });
  zones.unshift({ x0: HOME_LOT.x0, x1: HOME_LOT.x1, z0: HOME_LOT.z0, z1: HOME_LOT.z1, name: 'Ma maison' });
  zones.unshift({ x0: NOVA_LOT.x0, x1: NOVA_LOT.x1, z0: NOVA_LOT.z0, z1: NOVA_LOT.z1, name: 'Siège de NOVA BOOK' });
  footprints.push([42, 16, 76, 40, 2]);
  zones.unshift({ x0: SUPER_LOT.x0, x1: SUPER_LOT.x1, z0: SUPER_LOT.z0, z1: SUPER_LOT.z1, name: 'Supermarché LAGUNA' });
  zones.unshift({ x0: GARAGE_LOT.x0, x1: GARAGE_LOT.x1, z0: GARAGE_LOT.z0, z1: GARAGE_LOT.z1, name: 'Garage AUTO CONCEPT' });
  const vegetation = buildVegetation(scene, { palms, trees, bushes, bananas, tufts }, col, quality);

  // Limites invisibles de la carte
  for (const o of [col.addBox(-400, -400, MAP.minX - 1, 400, 50), col.addBox(MAP.maxX + 1, -400, 400, 400, 50), col.addBox(-400, -400, 400, MAP.minZ - 1, 50), col.addBox(-400, SEA_Z - 2, 400, 600, 50)]) o.invisible = true; // murs invisibles (ignorés par les avions)

  function zoneName(x, z) {
    for (const zn of zones) if (x >= zn.x0 && x <= zn.x1 && z >= zn.z0 && z <= zn.z1) return zn.name;
    if (Math.abs(z - 152) < ROAD_HALF + 1) return 'Boulevard de la Marina';
    if (Math.abs(x) < ROAD_HALF + 1 || Math.abs(z) < ROAD_HALF + 1) return 'Boulevard central';
    return 'Cotonou';
  }

  // fumée : particules recyclées au-dessus des braseros
  const smoke = [];
  {
    const N = 14, pos = new Float32Array(smokeSpots.length * N * 3);
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    const m = new THREE.PointsMaterial({ map: T.smokePuff(), size: 1.3, transparent: true, opacity: 0.35, depthWrite: false, color: 0xd8d8d8 });
    const pts = new THREE.Points(g, m); pts.frustumCulled = false; pts.userData.noAO = true;
    scene.add(pts);
    smokeSpots.forEach(([x, z], i) => { for (let k = 0; k < N; k++) smoke.push({ x, z, i: (i * N + k) * 3, t: k / N * 3, ox: 0, oz: 0 }); });
    smoke.geo = g;
  }

  function update(t) {
    {
      const a = smoke.geo.attributes.position.array, dt = Math.min(0.05, t - (smoke.last || t)); smoke.last = t;
      for (const p of smoke) {
        p.t += dt; if (p.t > 3) { p.t -= 3; p.ox = (Math.random() - 0.5) * 0.3; p.oz = (Math.random() - 0.5) * 0.3; }
        a[p.i] = p.x + p.ox + p.t * 0.25; a[p.i + 1] = 1.1 + p.t * 0.9; a[p.i + 2] = p.z + p.oz + Math.sin(p.t * 2 + p.i) * 0.15;
      }
      smoke.geo.attributes.position.needsUpdate = true;
    }
    for (const f of dyn.flags) {
      const pos = f.mesh.geometry.attributes.position;
      const a = pos.array, b = f.base;
      for (let i = 0; i < a.length; i += 3) {
        const x = b[i];
        a[i + 2] = Math.sin(x * 2.2 - t * 6) * 0.12 * x / 3 + Math.sin(b[i + 1] * 3 + t * 4) * 0.03 * x;
      }
      pos.needsUpdate = true;
      f.mesh.geometry.computeVertexNormals();
    }
    seaMat.normalMap.offset.set(t * 0.004, t * 0.009);
    foamMat.opacity = 0.3 + Math.sin(t * 1.3) * 0.15;
    dyn.foam.position.z = SEA_Z + 0.6 + Math.sin(t * 1.3) * 0.8;
  }

  return {
    collision: col, nightMats, parkedCars, pedPaths, zoneName, update, lamps, footprints, shopFronts, namedPlaces,
    blocks, crosswalks, lightIntersections, seats, zemSpots, stallSpots, plazaSpots, amazone: AMZ, martyrs, idleSpots, blockModes, home,
    stats: { drawCalls: drawCalls + vegetation.drawCalls, colliders: col.objects.length },
  };
}

