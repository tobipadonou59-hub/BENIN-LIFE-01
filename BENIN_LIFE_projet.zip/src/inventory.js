// Mission 009 — inventaire, équipement porté par le personnage, effets visuels et sauvegarde.
// Tous les effets sont des effets de jeu (particules, lumière, sons synthétiques) ; rien n'imite une arme réelle.
import * as THREE from 'three';
import { ITEMS, ITEM_BY_ID, CATEGORIES, RARITIES, SLOTS, buildItemModel, effectText } from './items.js';
import { HOME } from './home.js';
import { SEA_Z } from './world.js';

const SLOT_BONE = { head: 'head', body: 'chest', back: 'chest', hand: 'handR' };
const UPRIGHT = new Set(['parapluie', 'recade', 'canne_confettis', 'baton_impulsion']); // tenus verticalement
const PARTICLE_N = 700;

// ---------- particules (un seul objet Points pour tous les effets) ----------
function dotTexture() {
  const c = document.createElement('canvas'); c.width = c.height = 64;
  const x = c.getContext('2d'), g = x.createRadialGradient(32, 32, 0, 32, 32, 32);
  g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(0.45, 'rgba(255,255,255,0.9)'); g.addColorStop(1, 'rgba(255,255,255,0)');
  x.fillStyle = g; x.fillRect(0, 0, 64, 64);
  return new THREE.CanvasTexture(c);
}
export class Particles {
  constructor(scene) {
    const n = PARTICLE_N;
    this.pos = new Float32Array(n * 3); this.col = new Float32Array(n * 3);
    this.vel = new Float32Array(n * 3); this.life = new Float32Array(n); this.grav = new Float32Array(n); this.drag = new Float32Array(n);
    this.base = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) this.pos[i * 3 + 1] = -999;
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(this.pos, 3));
    g.setAttribute('color', new THREE.BufferAttribute(this.col, 3));
    this.points = new THREE.Points(g, new THREE.PointsMaterial({ size: 0.13, map: dotTexture(), vertexColors: true, transparent: true, depthWrite: false, toneMapped: false }));
    this.points.frustumCulled = false;
    scene.add(this.points);
    this.next = 0; this.alive = 0;
  }
  emit(n, o, f) {
    for (let k = 0; k < n; k++) {
      const i = this.next; this.next = (this.next + 1) % PARTICLE_N;
      const p = f(k);
      this.pos.set([o.x + (p.ox || 0), o.y + (p.oy || 0), o.z + (p.oz || 0)], i * 3);
      this.vel.set(p.v, i * 3);
      this.base.set(p.c, i * 3); this.col.set(p.c, i * 3);
      this.life[i] = p.life || 1.5; this.grav[i] = p.g ?? 9.8; this.drag[i] = p.drag ?? 0.4;
    }
    this.alive = 3;
  }
  update(dt) {
    if (this.alive <= 0) { this.points.visible = false; return; }
    this.points.visible = true;
    let any = false;
    for (let i = 0; i < PARTICLE_N; i++) {
      if (this.life[i] <= 0) continue;
      any = true;
      this.life[i] -= dt;
      const i3 = i * 3;
      if (this.life[i] <= 0) { this.pos[i3 + 1] = -999; continue; }
      const d = Math.exp(-this.drag[i] * dt);
      this.vel[i3] *= d; this.vel[i3 + 2] *= d; this.vel[i3 + 1] = this.vel[i3 + 1] * d - this.grav[i] * dt;
      this.pos[i3] += this.vel[i3] * dt; this.pos[i3 + 1] += this.vel[i3 + 1] * dt; this.pos[i3 + 2] += this.vel[i3 + 2] * dt;
      if (this.pos[i3 + 1] < 0.02) { this.pos[i3 + 1] = 0.02; this.vel[i3 + 1] *= -0.3; this.vel[i3] *= 0.5; this.vel[i3 + 2] *= 0.5; }
      const fade = Math.min(1, this.life[i] / 0.5);
      this.col[i3] = this.base[i3] * fade; this.col[i3 + 1] = this.base[i3 + 1] * fade; this.col[i3 + 2] = this.base[i3 + 2] * fade;
    }
    this.points.geometry.attributes.position.needsUpdate = true;
    this.points.geometry.attributes.color.needsUpdate = true;
    if (!any) this.alive -= dt;
  }
}

const rnd = (a, b) => a + Math.random() * (b - a);
const C = (hex) => { const c = new THREE.Color(hex); return [c.r, c.g, c.b]; };
const PALETTE = { confetti: [0xe8112d, 0xfcd116, 0x008751, 0x2fb4ff, 0xff4fa0, 0xffffff].map(C), gold: [0xffd75a, 0xffb000, 0xfff2b0].map(C) };

export class Inventory {
  constructor(ctx) {
    Object.assign(this, ctx); // scene, renderer, player, ui, audio, needs, env, camera, peds, traffic, cars, onMap, onSave
    this.equipped = { head: null, body: null, hand: null, back: null };
    this.seen = new Set();
    this.open = false;
    this.cat = 'all';
    this.sel = ITEMS[0].id;
    this.att = {}; // slot -> { obj, id, pop }
    this.charRef = null;
    this.useT = 0; this.useKind = null;
    this.cool = {};
    this.toggles = { torch: false, umbrella: false, zoom: false };
    this.fx = [];
    this.particles = new Particles(this.scene);
    this.icons = null;
    this.buildDom();
  }

  // ---------- équipement ----------
  equip(id) {
    const it = ITEM_BY_ID[id]; if (!it) return;
    if (this.equipped[it.slot] === id) return this.unequip(it.slot);
    if (this.equipped[it.slot]) this.detach(it.slot);
    this.equipped[it.slot] = id;
    this.attach(it.slot, true);
    if (this.audio && this.audio.ctx) { this.audio.tone(660, 0.12, 0.08, 'triangle'); this.audio.tone(990, 0.15, 0.06, 'triangle', undefined, 0.08); }
    this.afterChange();
  }
  unequip(slot) {
    if (!this.equipped[slot]) return;
    this.detach(slot);
    this.equipped[slot] = null;
    if (this.audio && this.audio.ctx) this.audio.tone(520, 0.12, 0.06, 'triangle', undefined, 0, 330);
    this.afterChange();
  }
  afterChange() {
    if (this.equipped.hand !== 'lampe_torche') this.toggles.torch = false;
    if (this.equipped.hand !== 'parapluie') this.toggles.umbrella = false;
    if (this.equipped.hand !== 'jumelles') this.toggles.zoom = false;
    document.body.classList.toggle('amber', this.equipped.head === 'lunettes_ambre');
    this.renderHud(); if (this.open) this.renderUI();
    if (this.onSave) this.onSave();
  }
  boneFor(slot) {
    const ch = this.player.char, b = ch && ch.bones;
    return (b && b[SLOT_BONE[slot]]) || ch.group;
  }
  attach(slot, pop = false) {
    const id = this.equipped[slot]; if (!id) return;
    const it = ITEM_BY_ID[id];
    const obj = new THREE.Group();
    const model = buildItemModel(it);
    obj.add(model);
    if (slot === 'hand') {
      obj.position.set(0, -0.07, 0.02);
      obj.rotation.x = Math.PI / 2;
      if (UPRIGHT.has(id)) model.rotation.x = -Math.PI / 2;
    }
    if (id === 'orbe_lumiere') { obj.userData.float = model; }
    if (id === 'drapeau') { obj.userData.flag = model; }
    this.boneFor(slot).add(obj);
    obj.scale.setScalar(pop ? 0.01 : 1);
    this.att[slot] = { obj, id, pop: pop ? 0 : 1, model };
    if (pop) this.sparkleAt(obj);
  }
  detach(slot) {
    const a = this.att[slot]; if (!a) return;
    a.obj.parent && a.obj.parent.remove(a.obj);
    delete this.att[slot];
  }
  reattachAll() {
    for (const s of Object.keys(this.att)) this.detach(s);
    for (const s of Object.keys(SLOTS)) this.attach(s);
  }
  sparkleAt(obj) {
    obj.updateWorldMatrix(true, false);
    const p = new THREE.Vector3().setFromMatrixPosition(obj.matrixWorld);
    this.particles.emit(18, p, () => ({ v: [rnd(-1, 1), rnd(0.5, 2), rnd(-1, 1)], c: PALETTE.gold[(Math.random() * 3) | 0], life: rnd(0.4, 0.8), g: 1, drag: 2 }));
  }

  get staminaMul() {
    let m = 1;
    for (const s of Object.keys(SLOTS)) {
      const it = this.equipped[s] && ITEM_BY_ID[this.equipped[s]];
      if (it && it.passive) { if (!it.passive.dayOnly || this.env.night < 0.5) m += it.passive.stamina; }
    }
    return m;
  }

  // ---------- utilisation (touche G) ----------
  handPos(out = new THREE.Vector3()) {
    const a = this.att.hand;
    if (!a) return out.copy(this.player.pos).setY(1.2);
    a.obj.updateWorldMatrix(true, false);
    return out.setFromMatrixPosition(a.obj.matrixWorld);
  }
  forward() { const f = this.player.facing; return new THREE.Vector3(Math.sin(f), 0, Math.cos(f)); }

  use() {
    const id = this.equipped.hand;
    if (!id) { this.ui.toast('Aucun objet en main — ouvre l’inventaire (I) pour en équiper un', 2.2); return; }
    if (this.player.inCar) { this.ui.toast('Descends du véhicule pour utiliser cet objet', 1.6); return; }
    const it = ITEM_BY_ID[id], e = it.effect, P = this.particles, h = this.handPos(), fw = this.forward(), A = this.audio && this.audio.ctx ? this.audio : null;
    this.useT = 0.7; this.useKind = e;
    const cone = (n, speed, colors, opts = {}) => P.emit(n, h, () => ({ v: [fw.x * speed + rnd(-1.2, 1.2), rnd(0.2, 2.2) + (opts.up || 0), fw.z * speed + rnd(-1.2, 1.2)], c: colors[(Math.random() * colors.length) | 0], life: rnd(0.8, opts.life || 1.8), g: opts.g ?? 3, drag: opts.drag ?? 0.8 }));
    const burst = (n, colors, opts = {}) => P.emit(n, h, () => { const a = Math.random() * 6.28, s = rnd(1, opts.s || 3.5); return { v: [Math.cos(a) * s, rnd(1, 4) + (opts.up || 0), Math.sin(a) * s], c: colors[(Math.random() * colors.length) | 0], life: rnd(0.6, opts.life || 1.6), g: opts.g ?? 5, drag: 1 }; });
    const cooldown = (k, s) => { const now = performance.now() / 1000; if ((this.cool[k] || 0) > now) { this.ui.toast(`Encore ${Math.ceil(this.cool[k] - now)} s avant de pouvoir recommencer`, 1.5); return false; } this.cool[k] = now + s; return true; };
    switch (e) {
      case 'bubbles': P.emit(40, h, () => ({ v: [fw.x * rnd(1, 3) + rnd(-0.6, 0.6), rnd(0.3, 1.2), fw.z * rnd(1, 3) + rnd(-0.6, 0.6)], c: C([0xbfeaff, 0xffffff, 0xd0c0ff][(Math.random() * 3) | 0]), life: rnd(2, 4), g: -0.15, drag: 1.2 })); A && A.burst(0.4, 'bandpass', 2500, 2, 0.05); break;
      case 'confetti': burst(80, PALETTE.confetti, { up: 3, g: 2.5, life: 2.6 }); A && A.burst(0.25, 'highpass', 1500, 1, 0.12); break;
      case 'sparks': burst(30, [C(0xffd060), C(0xff8a20), C(0xffffff)], { s: 3, g: 9, life: 0.7 }); A && A.tone(1800, 0.25, 0.08, 'square', undefined, 0, 900); break;
      case 'dust': cone(40, 1.5, [C(0xc8a878), C(0xa88a60)], { g: -0.05, drag: 1.5, life: 2 }); A && A.burst(0.5, 'bandpass', 900, 0.8, 0.08); break;
      case 'zap': for (let k = 0; k < 4; k++) setTimeout(() => P.emit(10, this.handPos(), () => ({ v: [rnd(-3, 3), rnd(-1, 3), rnd(-3, 3)], c: C(0x9fe8ff), life: rnd(0.15, 0.35), g: 0, drag: 3 })), k * 90); A && A.burst(0.35, 'highpass', 3500, 1, 0.1); break;
      case 'gust': cone(60, 7, [C(0xe0d0ff), C(0xffffff)], { g: 0, drag: 0.6, life: 1.2 }); A && A.burst(0.8, 'bandpass', 600, 0.7, 0.15); break;
      case 'sand': cone(90, 6, [C(0xe8c27a), C(0xd8a85a), C(0xf2dcae)], { g: 0.3, drag: 0.7, life: 2 }); A && A.burst(1.1, 'bandpass', 800, 0.6, 0.16); break;
      case 'gold': case 'royal': burst(50, PALETTE.gold, { up: 2, g: 1.5, life: 2 }); A && [880, 1108, 1320].forEach((f, i) => A.tone(f, 0.4, 0.06, 'sine', undefined, i * 0.1)); break;
      case 'trophy': burst(70, PALETTE.confetti, { up: 3, g: 2.5, life: 2.5 }); A && [523, 659, 784, 1046].forEach((f, i) => A.tone(f, 0.3, 0.07, 'triangle', undefined, i * 0.12)); break;
      case 'show': burst(20, PALETTE.gold, { s: 1, up: 0.5, g: 0.5 }); break;
      case 'block': case 'swing': break;
      case 'music': {
        if (!A) break; const notes = [392, 440, 523, 587, 523, 440, 392, 330];
        notes.forEach((f, i) => A.tone(f, 0.22, 0.07, 'triangle', undefined, i * 0.18));
        P.emit(10, h, (k) => ({ v: [rnd(-0.4, 0.4), rnd(0.6, 1.1), rnd(-0.4, 0.4)], c: C(k % 2 ? 0xff4fa0 : 0xfcd116), life: 2.2, g: -0.1, drag: 0.5 }));
        break;
      }
      case 'drum': {
        if (!A) break; const beat = [1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 0];
        beat.forEach((b, i) => { if (b) { A.tone(i % 3 ? 180 : 110, 0.25, 0.25, 'sine', undefined, i * 0.13, 60); A.burst(0.08, 'bandpass', 1200, 1, 0.05, undefined, i * 0.13); } });
        break;
      }
      case 'call': A && [1200, 0, 1200, 0, 1600].forEach((f, i) => f && A.tone(f, 0.12, 0.06, 'square', undefined, i * 0.14)); this.addRing(h, 0x2fd17a, 6, 1.0); break;
      case 'pulse': this.addRing(new THREE.Vector3(this.player.pos.x, 0.1, this.player.pos.z), 0x46e0ff, 9, 0.9); A && A.tone(220, 0.6, 0.12, 'sine', undefined, 0, 880); break;
      case 'shield': this.addDome(); A && A.tone(330, 0.8, 0.08, 'sine', undefined, 0, 660); break;
      case 'drone': this.addDrone(); A && A.burst(1, 'bandpass', 3000, 3, 0.04); break;
      case 'boomerang': this.addBoomerang(h, fw); A && A.tone(500, 1.4, 0.05, 'sawtooth', undefined, 0, 900); break;
      case 'hologram': this.addHologram(); A && A.tone(1320, 0.5, 0.04, 'sine'); break;
      case 'orb': this.addOrb(h); break;
      case 'torch': this.toggles.torch = !this.toggles.torch; A && A.tone(2000, 0.04, 0.05, 'square'); break;
      case 'umbrella': this.toggles.umbrella = !this.toggles.umbrella; A && A.burst(0.3, 'bandpass', 700, 0.8, 0.12); break;
      case 'zoom': this.toggles.zoom = !this.toggles.zoom; this.ui.toast(this.toggles.zoom ? 'Jumelles : zoom activé (G pour revenir)' : 'Jumelles rangées', 1.5); break;
      case 'map': this.onMap && this.onMap(); break;
      case 'photo': this.photoPending = true; A && A.burst(0.12, 'highpass', 3000, 1, 0.2); break;
      case 'drink': if (cooldown('drink', 60)) { this.needs.energy = Math.min(100, this.needs.energy + 8); this.ui.toast('Gorgée d’eau fraîche : +8 énergie', 1.8); A && A.burst(0.5, 'lowpass', 600, 1, 0.1); } break;
      case 'splash': if (cooldown('splash', 60)) { this.needs.hygiene = Math.min(100, this.needs.hygiene + 10); P.emit(50, h.clone().setY(h.y + 0.6), () => ({ v: [rnd(-1.2, 1.2), rnd(0, 1.5), rnd(-1.2, 1.2)], c: C(0x8fd8ff), life: rnd(0.6, 1.2), g: 9, drag: 0.3 })); this.ui.toast('Rafraîchi : +10 propreté', 1.8); A && A.burst(0.6, 'bandpass', 1500, 0.7, 0.15); } break;
      case 'scan': this.scan(); break;
      case 'compass': this.compass(); break;
      default: this.ui.toast('Cet objet se porte simplement', 1.4);
    }
  }

  scan() {
    const px = this.player.pos.x, pz = this.player.pos.z, R2 = 35 * 35;
    const near = (x, z) => (x - px) ** 2 + (z - pz) ** 2 < R2;
    let peds = 0, veh = 0, motos = 0;
    for (const p of (this.peds && this.peds.list) || []) { const g = p.c.group.position; if (near(g.x, g.z)) peds++; }
    for (const v of (this.traffic && this.traffic.vehicles) || []) { const g = v.pos || (v.mesh && v.mesh.position) || v.group?.position; if (g && near(g.x, g.z)) { if (v.isMoto || v.kind === 'moto' || v.moto) motos++; else veh++; } }
    for (const c of this.cars || []) if (near(c.pos.x, c.pos.z)) { if (c.isMoto) motos++; else veh++; }
    this.addRing(new THREE.Vector3(px, 0.15, pz), 0x2fd17a, 35, 1.6);
    if (this.audio && this.audio.ctx) this.audio.tone(1500, 0.3, 0.05, 'sine', undefined, 0, 600);
    this.ui.toast(`Scan (35 m) : ${peds} passant${peds > 1 ? 's' : ''}, ${veh} voiture${veh > 1 ? 's' : ''}, ${motos} moto${motos > 1 ? 's' : ''}`, 3);
  }
  compass() {
    const p = this.player.pos, f = this.player.facing;
    const rel = (dx, dz) => {
      let a = Math.atan2(dx, dz) - f; while (a > Math.PI) a -= 2 * Math.PI; while (a < -Math.PI) a += 2 * Math.PI;
      const d = Math.abs(a);
      return d < 0.6 ? 'devant toi' : d > 2.5 ? 'derrière toi' : a > 0 ? 'à ta gauche' : 'à ta droite';
    };
    const hx = HOME.marker.x - p.x, hz = HOME.marker.z - p.z;
    const dh = Math.round(Math.hypot(hx, hz)), ds = Math.max(0, Math.round(SEA_Z - p.z));
    this.ui.toast(`Maison (M) : ${dh} m, ${rel(hx, hz)} • Mer : ${ds} m, ${ds < 3 ? 'tu y es' : rel(0, 1)}`, 3.5);
  }

  // ---------- objets d'effet ----------
  addRing(pos, color, radius, dur) {
    const m = new THREE.Mesh(new THREE.RingGeometry(0.85, 1, 48), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.8, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false }));
    m.rotation.x = -Math.PI / 2; m.position.copy(pos); this.scene.add(m);
    this.fx.push({ t: 0, dur, upd: (k) => { m.scale.setScalar(0.3 + k * radius); m.material.opacity = 0.8 * (1 - k); }, done: () => { this.scene.remove(m); m.geometry.dispose(); m.material.dispose(); } });
  }
  addDome() {
    const m = new THREE.Mesh(new THREE.IcosahedronGeometry(1.15, 2), new THREE.MeshBasicMaterial({ color: 0x46e0ff, transparent: true, opacity: 0.22, wireframe: true, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false }));
    this.scene.add(m);
    this.fx.push({ t: 0, dur: 4, upd: (k) => { m.position.set(this.player.pos.x, 0.9, this.player.pos.z); m.rotation.y += 0.02; const s = Math.min(1, k * 8); m.scale.setScalar(s); m.material.opacity = 0.25 * (k > 0.85 ? (1 - k) / 0.15 : 1); }, done: () => this.scene.remove(m) });
  }
  addDrone() {
    const d = buildItemModel(ITEM_BY_ID.drone_colibri); d.scale.setScalar(1.8); this.scene.add(d);
    this.fx.push({ t: 0, dur: 15, upd: (k, t) => { const a = t * 1.6; d.position.set(this.player.pos.x + Math.cos(a) * 1.6, 2.1 + Math.sin(t * 3) * 0.15, this.player.pos.z + Math.sin(a) * 1.6); d.rotation.y = -a; }, done: () => this.scene.remove(d) });
  }
  addBoomerang(h, fw) {
    const d = buildItemModel(ITEM_BY_ID.disque_lumineux); d.scale.setScalar(1.6); this.scene.add(d);
    const o = h.clone(), side = new THREE.Vector3(fw.z, 0, -fw.x);
    this.fx.push({ t: 0, dur: 1.8, upd: (k) => { const s = Math.sin(k * Math.PI); d.position.copy(o).addScaledVector(fw, s * 12).addScaledVector(side, Math.sin(k * Math.PI * 2) * 2.5); d.rotation.y += 0.5; d.rotation.x = Math.PI / 2; if (Math.random() < 0.5) this.particles.emit(1, d.position, () => ({ v: [0, 0, 0], c: C(0xff3df2), life: 0.4, g: 0 })); }, done: () => this.scene.remove(d) });
  }
  addHologram() {
    const c = document.createElement('canvas'); c.width = 96; c.height = 64; const x = c.getContext('2d');
    x.fillStyle = '#008751'; x.fillRect(0, 0, 38, 64); x.fillStyle = '#fcd116'; x.fillRect(38, 0, 58, 32); x.fillStyle = '#e8112d'; x.fillRect(38, 32, 58, 32);
    const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace;
    const m = new THREE.Mesh(new THREE.PlaneGeometry(1.5, 1), new THREE.MeshBasicMaterial({ map: tex, transparent: true, opacity: 0.7, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false }));
    this.scene.add(m);
    this.fx.push({ t: 0, dur: 6, upd: (k, t) => { m.position.set(this.player.pos.x, 2.9 + Math.sin(t * 2) * 0.08, this.player.pos.z); m.rotation.y = t * 0.8; m.material.opacity = (0.55 + Math.random() * 0.2) * Math.min(1, k * 10, (1 - k) * 8); }, done: () => this.scene.remove(m) });
  }
  addOrb(h) {
    const o = buildItemModel(ITEM_BY_ID.noyau_plasma); this.scene.add(o);
    const p0 = h.clone();
    this.fx.push({ t: 0, dur: 3, upd: (k, t) => { const up = Math.sin(k * Math.PI) * 1.4; o.position.set(p0.x + Math.cos(t * 6) * 0.3 * k, p0.y + up, p0.z + Math.sin(t * 6) * 0.3 * k); o.rotation.y = t * 5; if (Math.random() < 0.6) this.particles.emit(1, o.position, () => ({ v: [rnd(-0.3, 0.3), rnd(-0.2, 0.3), rnd(-0.3, 0.3)], c: C(0xb090ff), life: 0.6, g: 0 })); }, done: () => this.scene.remove(o) });
  }
  ensureTorch() {
    if (this.beam) return;
    const g = new THREE.ConeGeometry(1.4, 7, 24, 1, true); g.translate(0, -3.5, 0); g.rotateX(-Math.PI / 2);
    this.beam = new THREE.Mesh(g, new THREE.MeshBasicMaterial({ color: 0xfff0b8, transparent: true, opacity: 0.12, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, toneMapped: false }));
    this.spot = new THREE.Mesh(new THREE.CircleGeometry(1.6, 32), new THREE.MeshBasicMaterial({ color: 0xfff0b8, transparent: true, opacity: 0.35, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false }));
    this.spot.rotation.x = -Math.PI / 2;
    this.scene.add(this.beam, this.spot);
  }
  ensureCanopy() {
    if (this.canopy) return;
    const g = new THREE.ConeGeometry(0.62, 0.28, 12, 1, true).toNonIndexed();
    const col = new Float32Array(g.attributes.position.count * 3), cs = [C(0x008751), C(0xfcd116), C(0xe8112d)];
    for (let i = 0; i < g.attributes.position.count; i++) col.set(cs[Math.floor(i / 3) % 3], i * 3);
    g.setAttribute('color', new THREE.BufferAttribute(col, 3));
    this.canopy = new THREE.Mesh(g, new THREE.MeshStandardMaterial({ vertexColors: true, side: THREE.DoubleSide, roughness: 0.7 }));
    this.canopy.castShadow = true;
    this.scene.add(this.canopy);
  }

  // ---------- mise à jour par image ----------
  update(dt, t, inMenu) {
    const ch = this.player.char;
    if (ch !== this.charRef) { this.charRef = ch; this.reattachAll(); }
    for (const s in this.att) {
      const a = this.att[s];
      if (a.pop < 1) { a.pop = Math.min(1, a.pop + dt * 3); const k = a.pop, c = 1.70158; a.obj.scale.setScalar(Math.max(0.01, 1 + (c + 1) * (k - 1) ** 3 + c * (k - 1) ** 2)); } // apparition élastique
      if (a.id === 'orbe_lumiere') { a.model.position.y = Math.sin(t * 2) * 0.05; a.model.rotation.y = t; }
      if (a.id === 'drapeau') a.model.rotation.y = Math.sin(t * 2.2) * 0.12;
    }
    // posture : objet tenu devant soi, geste à l'utilisation
    const hand = this.att.hand;
    if (hand && ch.bones && !this.player.inCar && !inMenu) {
      const b = ch.bones;
      this.useT = Math.max(0, this.useT - dt);
      const u = this.useT > 0 ? Math.sin((this.useT / 0.7) * Math.PI) : 0;
      const raise = ['royal', 'trophy', 'gold', 'show', 'confetti', 'hologram', 'orb'].includes(this.useKind) ? 1 : 0.4;
      const umb = this.toggles.umbrella ? 1 : 0;
      b.armR.rotation.x = b.armR.rotation.x * 0.25 - 0.35 - u * 1.1 * raise - umb * 0.5;
      b.foreR.rotation.x = -1.0 + u * 0.6 * raise + umb * 0.55;
      b.armR.rotation.z = -0.12;
      if (this.useKind === 'swing' && u > 0) b.armR.rotation.x += Math.sin(this.useT * 20) * 0.5;
      if (this.useKind === 'block' && this.useT > 0) { b.armR.rotation.x = -1.3; b.foreR.rotation.x = -0.4; }
      ch.mesh && ch.mesh.updateMatrixWorld && ch.group.updateMatrixWorld(true);
    }
    // lampe torche
    const torchOn = this.toggles.torch && hand && !this.player.inCar;
    if (torchOn) this.ensureTorch();
    if (this.beam) {
      this.beam.visible = this.spot.visible = !!torchOn;
      if (torchOn) {
        const h = this.handPos(), fw = this.forward();
        this.beam.position.copy(h); this.beam.lookAt(h.x + fw.x * 6, 0.2, h.z + fw.z * 6); this.beam.rotateY(Math.PI);
        this.spot.position.set(this.player.pos.x + fw.x * 5.5, 0.04, this.player.pos.z + fw.z * 5.5);
        const k = 0.3 + 0.7 * this.env.night; this.beam.material.opacity = 0.13 * k; this.spot.material.opacity = 0.4 * k;
      }
    }
    // parapluie ouvert
    const umbOn = this.toggles.umbrella && hand && !this.player.inCar;
    if (umbOn) this.ensureCanopy();
    if (this.canopy) {
      this.canopy.visible = !!umbOn;
      if (umbOn) { const h = this.handPos(); this.canopy.position.set(h.x, h.y + 0.8, h.z); }
    }
    // jumelles
    const fov = this.toggles.zoom && !this.player.inCar ? 24 : 62;
    if (Math.abs(this.camera.fov - fov) > 0.05) { this.camera.fov += (fov - this.camera.fov) * Math.min(1, dt * 6); this.camera.updateProjectionMatrix(); }
    // effets temporaires
    for (let i = this.fx.length - 1; i >= 0; i--) {
      const f = this.fx[i]; f.t += dt;
      const k = Math.min(1, f.t / f.dur);
      f.upd(k, f.t);
      if (k >= 1) { f.done(); this.fx.splice(i, 1); }
    }
    this.particles.update(dt);
    if (this.open) this.renderPreview(t);
    this.renderHudUse();
  }

  // capture d'écran après le rendu (appareil photo)
  afterRender(canvas) {
    if (!this.photoPending) return;
    this.photoPending = false;
    let url = '';
    try { url = canvas.toDataURL('image/jpeg', 0.9); } catch (e) { url = ''; }
    const flash = document.getElementById('photo-flash');
    flash.classList.remove('show'); void flash.offsetWidth; flash.classList.add('show');
    if (!url || url.length < 2000) { this.ui.toast('Photo impossible dans ce navigateur', 2); return; }
    const box = document.getElementById('photo');
    box.querySelector('img').src = url;
    const a = box.querySelector('a'); a.href = url; a.download = `benin-life-${Date.now()}.jpg`;
    box.classList.add('show');
    clearTimeout(this._photoT); this._photoT = setTimeout(() => box.classList.remove('show'), 5000);
  }

  // ---------- icônes et aperçu 3D (rendus une fois avec le moteur du jeu) ----------
  setupStudio() {
    if (this.studio) return;
    const sc = new THREE.Scene();
    sc.add(new THREE.HemisphereLight(0xffffff, 0x6a5040, 1.6));
    const d = new THREE.DirectionalLight(0xffffff, 2.2); d.position.set(2, 3, 4); sc.add(d);
    const cam = new THREE.PerspectiveCamera(30, 1, 0.01, 20);
    const lut = new Uint8ClampedArray(256);
    for (let i = 0; i < 256; i++) { const v = i / 255; lut[i] = Math.round(255 * (v <= 0.0031308 ? v * 12.92 : 1.055 * Math.pow(v, 1 / 2.4) - 0.055)); }
    this.studio = { sc, cam, lut, rts: {} };
  }
  shoot(item, size, angle, holder) {
    this.setupStudio();
    const { sc, cam, lut, rts } = this.studio, r = this.renderer;
    if (!rts[size]) rts[size] = new THREE.WebGLRenderTarget(size, size, { samples: 0 });
    const rt = rts[size];
    let m = holder && holder.id === item.id ? holder.m : null;
    if (!m) {
      if (holder && holder.m) sc.remove(holder.m);
      m = new THREE.Group(); const inner = buildItemModel(item); m.add(inner);
      const box = new THREE.Box3().setFromObject(inner), c = box.getCenter(new THREE.Vector3()), sz = box.getSize(new THREE.Vector3());
      inner.position.sub(c);
      m.userData.radius = Math.max(sz.x, sz.y, sz.z) * 0.62 + 0.01;
      sc.add(m);
      if (holder) { holder.id = item.id; holder.m = m; }
    }
    m.rotation.set(0.35, angle, 0);
    const dist = m.userData.radius / Math.tan((cam.fov * Math.PI) / 360);
    cam.position.set(0, 0, dist * 1.08); cam.lookAt(0, 0, 0); cam.near = dist * 0.2; cam.far = dist * 3; cam.updateProjectionMatrix();
    sc.environment = this.scene.environment;
    const prevRT = r.getRenderTarget(), prevC = r.getClearColor(new THREE.Color()), prevA = r.getClearAlpha();
    r.setRenderTarget(rt); r.setClearColor(0x000000, 0); r.clear(); r.render(sc, cam);
    const px = new Uint8Array(size * size * 4);
    r.readRenderTargetPixels(rt, 0, 0, size, size, px);
    r.setRenderTarget(prevRT); r.setClearColor(prevC, prevA);
    if (!holder) sc.remove(m);
    const img = new ImageData(size, size);
    for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
      const s = ((size - 1 - y) * size + x) * 4, o = (y * size + x) * 4, a = px[s + 3];
      // les canaux sont prémultipliés par l'alpha : on les remet à l'échelle avant la conversion sRGB
      const un = a ? 255 / a : 0;
      img.data[o] = lut[Math.min(255, (px[s] * un) | 0)]; img.data[o + 1] = lut[Math.min(255, (px[s + 1] * un) | 0)]; img.data[o + 2] = lut[Math.min(255, (px[s + 2] * un) | 0)]; img.data[o + 3] = a;
    }
    return img;
  }
  makeIcons() {
    if (this.icons) return;
    this.icons = {};
    const c = document.createElement('canvas'); c.width = c.height = 96; const x = c.getContext('2d');
    for (const it of ITEMS) {
      x.clearRect(0, 0, 96, 96); x.putImageData(this.shoot(it, 96, it.slot === 'hand' ? -1.15 : -0.5), 0, 0);
      this.icons[it.id] = c.toDataURL('image/png');
    }
  }
  renderPreview(t) {
    const cv = this.dom.preview, it = ITEM_BY_ID[this.sel];
    if (!cv || !it) return;
    this._pv = this._pv || {};
    cv.getContext('2d').putImageData(this.shoot(it, 192, t * 0.8, this._pv), 0, 0);
  }

  // ---------- interface ----------
  buildDom() {
    const $ = (s) => document.querySelector(s);
    this.dom = { root: $('#inv'), hud: $('#equip-hud') };
    const r = this.dom.root;
    r.innerHTML = `
      <div class="inv-box">
        <div class="inv-head"><div><h2>INVENTAIRE</h2><span class="inv-count"></span></div>
          <select class="inv-rar"><option value="">Toutes raretés</option>${Object.entries(RARITIES).map(([k, v]) => `<option value="${k}">${v.label}</option>`).join('')}</select>
          <button class="inv-x" title="Fermer (I)">✕</button></div>
        <div class="inv-tabs"><button data-cat="all">Tout</button>${CATEGORIES.map((c) => `<button data-cat="${c.id}">${c.icon} ${c.label}</button>`).join('')}</div>
        <div class="inv-main">
          <div class="inv-grid"></div>
          <div class="inv-detail">
            <canvas class="inv-pv" width="192" height="192"></canvas>
            <div class="inv-name"></div><div class="inv-rarity"></div><div class="inv-meta"></div>
            <p class="inv-desc"></p><p class="inv-eff"></p>
            <button class="inv-equip"></button>
          </div>
        </div>
        <div class="inv-slots">${Object.entries(SLOTS).map(([k, v]) => `<button class="inv-slot" data-slot="${k}"><span>${v}</span><img alt=""></button>`).join('')}</div>
        <div class="inv-help">Flèches : sélectionner • Entrée : équiper / retirer • Tab : catégorie • I ou Échap : fermer • G en jeu : utiliser l’objet en main</div>
      </div>`;
    this.dom.grid = r.querySelector('.inv-grid'); this.dom.preview = r.querySelector('.inv-pv');
    r.querySelector('.inv-x').addEventListener('click', (e) => { e.stopPropagation(); this.toggle(false); });
    r.querySelector('.inv-rar').addEventListener('change', (e) => { this.rar = e.target.value; this.renderUI(); });
    r.querySelectorAll('[data-cat]').forEach((b) => b.addEventListener('click', (e) => { e.stopPropagation(); this.cat = b.dataset.cat; this.renderUI(); }));
    r.querySelector('.inv-equip').addEventListener('click', (e) => { e.stopPropagation(); this.equip(this.sel); });
    r.querySelectorAll('.inv-slot').forEach((b) => b.addEventListener('click', (e) => { e.stopPropagation(); const id = this.equipped[b.dataset.slot]; if (id) { this.sel = id; this.renderUI(); } }));
    this.dom.grid.addEventListener('click', (e) => {
      const card = e.target.closest('[data-id]'); if (!card) return;
      e.stopPropagation();
      if (this.sel === card.dataset.id && e.detail >= 2) this.equip(card.dataset.id);
      this.sel = card.dataset.id; this.seen.add(this.sel); this.renderUI();
    });
    this.dom.grid.addEventListener('dblclick', (e) => { const card = e.target.closest('[data-id]'); if (card) this.equip(card.dataset.id); });
  }
  filtered() { return ITEMS.filter((it) => (this.cat === 'all' || it.cat === this.cat) && (!this.rar || it.rarity === this.rar)); }
  toggle(on = !this.open) {
    this.open = on;
    if (on) { this.makeIcons(); this.seen.add(this.sel); this.renderUI(); }
    this.dom.root.classList.toggle('show', on);
    if (!on && this.onSave) this.onSave();
  }
  renderUI() {
    const list = this.filtered();
    if (list.length && !list.some((i) => i.id === this.sel)) this.sel = list[0].id;
    const r = this.dom.root;
    r.querySelector('.inv-count').textContent = `${ITEMS.length} objets • ${Object.values(this.equipped).filter(Boolean).length}/4 équipés`;
    r.querySelectorAll('[data-cat]').forEach((b) => b.classList.toggle('on', b.dataset.cat === this.cat));
    this.dom.grid.innerHTML = list.map((it) => {
      const rr = RARITIES[it.rarity], eq = this.equipped[it.slot] === it.id;
      return `<button class="inv-card${it.id === this.sel ? ' sel' : ''}${eq ? ' eq' : ''}" data-id="${it.id}" style="--rc:${rr.color}">
        <img src="${this.icons ? this.icons[it.id] : ''}" alt="">${eq ? '<i class="tag">ÉQUIPÉ</i>' : !this.seen.has(it.id) ? '<i class="new"></i>' : ''}<b>${it.name}</b></button>`;
    }).join('') || '<p class="inv-empty">Aucun objet dans ce filtre.</p>';
    const it = ITEM_BY_ID[this.sel];
    if (it) {
      const rr = RARITIES[it.rarity], cat = CATEGORIES.find((c) => c.id === it.cat);
      r.querySelector('.inv-name').textContent = it.name;
      const rEl = r.querySelector('.inv-rarity'); rEl.textContent = '◆ ' + rr.label.toUpperCase(); rEl.style.color = rr.color;
      r.querySelector('.inv-meta').textContent = `${cat.icon} ${cat.label} • Emplacement : ${SLOTS[it.slot]} • ${this.trisOf(it)} triangles`;
      r.querySelector('.inv-desc').textContent = it.desc;
      r.querySelector('.inv-eff').textContent = effectText(it);
      const eq = this.equipped[it.slot] === it.id, b = r.querySelector('.inv-equip');
      b.textContent = eq ? 'RETIRER' : this.equipped[it.slot] ? `ÉQUIPER (remplace ${ITEM_BY_ID[this.equipped[it.slot]].name})` : 'ÉQUIPER';
      b.classList.toggle('on', eq);
      r.querySelector('.inv-detail').style.setProperty('--rc', rr.color);
      requestAnimationFrame(() => { r.querySelector('.inv-detail').scrollTop = 0; });
    }
    r.querySelectorAll('.inv-slot').forEach((b) => {
      const id = this.equipped[b.dataset.slot], img = b.querySelector('img');
      b.classList.toggle('full', !!id);
      img.src = id && this.icons ? this.icons[id] : ''; img.style.visibility = id ? 'visible' : 'hidden';
      b.title = id ? ITEM_BY_ID[id].name : 'Vide';
    });
    const sel = this.dom.grid.querySelector('.sel'), g = this.dom.grid;
    if (sel) { const top = sel.offsetTop - g.offsetTop; if (top < g.scrollTop) g.scrollTop = top - 4; else if (top + sel.offsetHeight > g.scrollTop + g.clientHeight) g.scrollTop = top + sel.offsetHeight - g.clientHeight + 4; }
  }
  trisOf(it) { this._tris = this._tris || {}; if (!(it.id in this._tris)) this._tris[it.id] = Math.round(buildItemModel(it).userData.tris); return this._tris[it.id]; }
  // navigation clavier dans le menu
  handleKeys(input) {
    if (input.hit('Escape') || input.hit('KeyI')) { this.toggle(false); return; }
    const list = this.filtered(); if (!list.length) return;
    let i = list.findIndex((x) => x.id === this.sel);
    const cols = Math.max(1, Math.round(this.dom.grid.clientWidth / 104));
    if (input.hit('ArrowRight') || input.hit('KeyD')) i++;
    if (input.hit('ArrowLeft') || input.hit('KeyA') || input.hit('KeyQ')) i--;
    if (input.hit('ArrowDown') || input.hit('KeyS')) i += cols;
    if (input.hit('ArrowUp') || input.hit('KeyW') || input.hit('KeyZ')) i -= cols;
    i = Math.max(0, Math.min(list.length - 1, i));
    if (list[i].id !== this.sel) { this.sel = list[i].id; this.seen.add(this.sel); this.renderUI(); }
    if (input.hit('Enter') || input.hit('KeyE') || input.hit('Space')) this.equip(this.sel);
    if (input.hit('Tab')) { const cats = ['all', ...CATEGORIES.map((c) => c.id)]; this.cat = cats[(cats.indexOf(this.cat) + 1) % cats.length]; this.renderUI(); }
  }

  // HUD : objets équipés + rappel de la touche G
  renderHud() {
    const h = this.dom.hud; if (!h) return;
    const ids = Object.entries(this.equipped).filter(([, v]) => v);
    if (!ids.length) { h.innerHTML = ''; h.style.display = 'none'; return; }
    if (!this.icons) this.makeIcons();
    h.style.display = 'flex';
    h.innerHTML = ids.map(([s, id]) => `<span class="eh" title="${SLOTS[s]} : ${ITEM_BY_ID[id].name}" style="--rc:${RARITIES[ITEM_BY_ID[id].rarity].color}"><img src="${this.icons[id]}" alt=""></span>`).join('')
      + (this.equipped.hand && ITEM_BY_ID[this.equipped.hand].effect ? `<span class="eh-use"><kbd>G</kbd> ${ITEM_BY_ID[this.equipped.hand].name}</span>` : '');
  }
  renderHudUse() { /* réservé : état des bascules affiché via les toasts */ }

  serialize() { return { equipped: { ...this.equipped }, seen: [...this.seen] }; }
  restore(s) {
    if (!s) return;
    for (const k of Object.keys(SLOTS)) { const id = s.equipped && s.equipped[k]; this.equipped[k] = id && ITEM_BY_ID[id] && ITEM_BY_ID[id].slot === k ? id : null; }
    this.seen = new Set((s.seen || []).filter((id) => ITEM_BY_ID[id]));
    this.charRef = null; // réattache au prochain update
    this.afterChange();
  }
}
