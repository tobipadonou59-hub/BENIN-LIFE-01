// Commandes tactiles (iPhone, iPad, Android) : joystick virtuel, caméra au doigt, boutons d'action.
// Elles alimentent les mêmes « touches » que le clavier, donc tout le jeu fonctionne au toucher.
export function isTouchDevice() {
  return (typeof window !== 'undefined') && (('ontouchstart' in window) || navigator.maxTouchPoints > 0) && matchMedia('(pointer: coarse)').matches;
}

export class TouchControls {
  constructor(input, root) {
    this.input = input;
    this.el = root;
    root.innerHTML = `
      <div class="tc-stick"><div class="tc-knob"></div></div>
      <div class="tc-btns">
        <button class="tc-b tc-e" data-k="KeyE">E</button>
        <button class="tc-b tc-jump" data-k="Space">⤒</button>
        <button class="tc-b tc-run" data-k="ShiftLeft" data-toggle="1">🏃</button>
        <button class="tc-b tc-horn" data-k="KeyK">📯</button>
        <button class="tc-b tc-use" data-k="KeyG">✦</button>
        <button class="tc-b tc-cam" data-k="KeyV">👁</button>
      </div>
      <div class="tc-top">
        <button class="tc-s" data-k="KeyN">📱</button>
        <button class="tc-s" data-k="KeyU">✧</button>
        <button class="tc-s" data-k="KeyI">🎒</button>
        <button class="tc-s" data-k="KeyC">CARTE</button>
        <button class="tc-s" data-k="KeyP">❚❚</button>
      </div>`;
    this.stick = root.querySelector('.tc-stick'); this.knob = root.querySelector('.tc-knob');
    this.stickId = null; this.lookId = null; this.lx = 0; this.ly = 0; this.runOn = false;
    const opt = { passive: false };
    this.stick.addEventListener('touchstart', (e) => this.stickStart(e), opt);
    root.addEventListener('touchmove', (e) => this.move(e), opt);
    root.addEventListener('touchend', (e) => this.end(e), opt);
    root.addEventListener('touchcancel', (e) => this.end(e), opt);
    root.querySelectorAll('[data-k]').forEach((b) => {
      const k = b.dataset.k;
      b.addEventListener('touchstart', (e) => {
        e.preventDefault(); e.stopPropagation();
        if (b.dataset.toggle) { this.runOn = !this.runOn; b.classList.toggle('on', this.runOn); input.setVirtual(k, this.runOn); }
        else { input.setVirtual(k, true); b.classList.add('on'); }
      }, opt);
      b.addEventListener('touchend', (e) => { e.preventDefault(); if (!b.dataset.toggle) { input.setVirtual(k, false); b.classList.remove('on'); } }, opt);
    });
    // caméra : glisser n'importe où ailleurs sur l'écran
    this.lookArea = document.getElementById('game');
    this.lookArea.addEventListener('touchstart', (e) => this.lookStart(e), opt);
    this.lookArea.addEventListener('touchmove', (e) => this.move(e), opt);
    this.lookArea.addEventListener('touchend', (e) => this.end(e), opt);
  }
  show(on) { this.el.style.display = on ? 'block' : 'none'; }
  setCam(on) { const b = this.el.querySelector('.tc-cam'); if (b) b.style.display = on ? 'flex' : 'none'; }
  setUse(on) { const b = this.el.querySelector('.tc-use'); if (b) b.style.display = on ? 'flex' : 'none'; }
  setHorn(on) { this.el.querySelector('.tc-horn').style.display = on ? 'flex' : 'none'; }
  stickStart(e) {
    e.preventDefault();
    const t = e.changedTouches[0]; this.stickId = t.identifier;
    const r = this.stick.getBoundingClientRect(); this.cx = r.left + r.width / 2; this.cy = r.top + r.height / 2; this.rad = r.width / 2;
    this.stickMove(t);
  }
  lookStart(e) {
    e.preventDefault();
    for (const t of e.changedTouches) if (this.lookId === null) { this.lookId = t.identifier; this.lx = t.clientX; this.ly = t.clientY; }
  }
  stickMove(t) {
    let dx = (t.clientX - this.cx) / this.rad, dy = (t.clientY - this.cy) / this.rad;
    const l = Math.hypot(dx, dy); if (l > 1) { dx /= l; dy /= l; }
    const m = this.rad * 0.55; // amplitude du bouton proportionnelle à la taille du joystick
    this.knob.style.transform = `translate(${dx * m}px, ${dy * m}px)`;
    const I = this.input, th = 0.3;
    I.setVirtual('KeyW', dy < -th); I.setVirtual('KeyS', dy > th); I.setVirtual('KeyA', dx < -th); I.setVirtual('KeyD', dx > th);
    if (!this.runOn) I.setVirtual('ShiftLeft', Math.hypot(dx, dy) > 0.95);
  }
  move(e) {
    for (const t of e.changedTouches) {
      if (t.identifier === this.stickId) { e.preventDefault(); this.stickMove(t); }
      else if (t.identifier === this.lookId) {
        e.preventDefault();
        this.input.mouseDX += (t.clientX - this.lx) * 1.6; this.input.mouseDY += (t.clientY - this.ly) * 1.6;
        this.lx = t.clientX; this.ly = t.clientY;
      }
    }
  }
  end(e) {
    for (const t of e.changedTouches) {
      if (t.identifier === this.stickId) {
        this.stickId = null; this.knob.style.transform = '';
        for (const k of ['KeyW', 'KeyS', 'KeyA', 'KeyD']) this.input.setVirtual(k, false);
        if (!this.runOn) this.input.setVirtual('ShiftLeft', false);
      }
      if (t.identifier === this.lookId) this.lookId = null;
    }
  }
}
