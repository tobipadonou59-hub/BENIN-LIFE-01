// Mission 012 — étape 3 : hélicoptères (8 modèles procéduraux) — démarrage/arrêt du moteur, montée en régime du rotor,
// décollage et atterrissage verticaux, montée, descente, rotation, avance, recul et translation latérale, pales et rotor
// de queue animés, son de rotor, vue extérieure et cockpit (V), héliport à l'aéroport, hélisurfaces (NOVA BOOK,
// plage, Ouidah, Porto-Novo) et vols de passagers fictifs rémunérés (monnaie du jeu).
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { HELIS, HELI_BY_ID, PAX } from './heli-data.js';
import { solidAt } from './airport.js';
import { isWater } from './region-geo.js';
import { TOWNS } from './region-geo.js';
import { fcfa } from './food-data.js';
import { clamp, damp } from './util.js';

const PI = Math.PI;
const KIOSK = { x: -449, z: 113 }; // comptoir de l'héliport, à côté du comptoir des vols
function colored(geo, hex) {
  const g = geo.index ? geo.toNonIndexed() : geo, c = new THREE.Color(hex), n = g.attributes.position.count, a = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { a[i * 3] = c.r; a[i * 3 + 1] = c.g; a[i * 3 + 2] = c.b; }
  g.setAttribute('color', new THREE.BufferAttribute(a, 3)); if (g.attributes.uv) g.deleteAttribute('uv'); return g;
}
const MATS = {};
const mat = (k) => MATS[k] || (MATS[k] = k === 'glass' ? new THREE.MeshStandardMaterial({ color: 0x2a3a48, roughness: 0.05, metalness: 0.5, transparent: true, opacity: 0.72 })
  : k === 'shiny' ? new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.3, metalness: 0.4 }) : new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.55, metalness: 0.15 }));

// ------------------------------------------------------------------ modèle 3D
export function buildHeliMesh(sp) {
  const P = [], S = [], G = [], g = new THREE.Group();
  const [w, h, L] = sp.body, add = (geo, c, arr = P) => arr.push(colored(geo, c)), gy = sp.gear === 'wheels' ? 0.75 : 0.65;
  const cy = gy + h / 2;
  // cabine (fuselage arrondi), verrière, poutre de queue, dérive
  add(new THREE.SphereGeometry(1, 20, 14).scale(w / 2, h / 2, L / 2).translate(0, cy, 0), sp.color);
  add(new THREE.SphereGeometry(1, 16, 10, 0, PI * 2, 0, PI * 0.5).scale(w / 2 * 0.98, h * 0.42, L * 0.28).rotateX(PI / 2.6).translate(0, cy + h * 0.08, L * 0.28), 0x2a3a48, G);
  add(new THREE.BoxGeometry(w * 1.01, h * 0.12, L * 0.6).translate(0, cy - h * 0.12, -L * 0.05), sp.stripe);
  if (!sp.tandem) {
    const tl = sp.len - L * 0.5;
    add(new THREE.CylinderGeometry(0.22, 0.42, tl, 10).rotateX(PI / 2).translate(0, cy + h * 0.15, -L / 2 - tl / 2 + 0.6), sp.color);
    add(new THREE.BoxGeometry(0.12, 1.5, 1.1).rotateX(-0.25).translate(0, cy + h * 0.15 + 0.6, -sp.len + L / 2 + 0.5), sp.color);
    add(new THREE.BoxGeometry(1.8, 0.08, 0.5).translate(0, cy + h * 0.1, -sp.len + L / 2 + 1.6), sp.color);
    if (sp.tail === 'fenestron') add(new THREE.TorusGeometry(0.55, 0.12, 8, 16).rotateY(PI / 2).translate(0, cy + h * 0.15 + 0.3, -sp.len + L / 2 + 0.4), sp.color);
  } else { // gros porteur : pylônes avant/arrière
    add(new THREE.BoxGeometry(1.2, 1.4, 2.4).translate(0, cy + h / 2 + 0.3, L / 2 - 1.6), sp.color);
    add(new THREE.BoxGeometry(1.4, 2.6, 3.2).translate(0, cy + h / 2 + 0.9, -L / 2 + 1.8), sp.color);
  }
  // patins ou roues
  if (sp.gear === 'skids') for (const s of [-1, 1]) { add(new THREE.CylinderGeometry(0.07, 0.07, L * 0.85, 8).rotateX(PI / 2).translate(s * w * 0.48, 0.08, 0), 0x2a2d33, S); for (const z of [L * 0.22, -L * 0.22]) add(new THREE.CylinderGeometry(0.05, 0.05, gy, 6).rotateZ(s * 0.35).translate(s * w * 0.43, gy / 2, z), 0x2a2d33, S); }
  else for (const [x, z] of [[w * 0.42, L * 0.3], [-w * 0.42, L * 0.3], [w * 0.42, -L * 0.3], [-w * 0.42, -L * 0.3]]) { add(new THREE.CylinderGeometry(0.32, 0.32, 0.22, 12).rotateZ(PI / 2).translate(x, 0.32, z), 0x1a1a1a); add(new THREE.BoxGeometry(0.1, gy - 0.3, 0.1).translate(x, gy / 2 + 0.2, z), 0x2a2d33, S); }
  // feux de navigation
  add(new THREE.SphereGeometry(0.09, 6, 4).translate(w / 2, cy, 0), 0x2fd05a, S); add(new THREE.SphereGeometry(0.09, 6, 4).translate(-w / 2, cy, 0), 0xff3a2a, S);
  const body = new THREE.Mesh(mergeGeometries(P), mat('n')); body.castShadow = true; g.add(body);
  g.add(new THREE.Mesh(mergeGeometries(S), mat('shiny'))); g.add(new THREE.Mesh(mergeGeometries(G), mat('glass')));
  // rotors (groupes animés)
  const rotors = [], mk = (x, y, z, r, n, small = false, axis = 'y') => {
    const rg = new THREE.Group(); rg.position.set(x, y, z);
    const blades = []; for (let k = 0; k < n; k++) blades.push(colored(new THREE.BoxGeometry(small ? 0.12 : 0.32, 0.05, r).translate(0, 0, r / 2).rotateY(k * PI * 2 / n), 0x1a1c20));
    blades.push(colored(new THREE.CylinderGeometry(small ? 0.1 : 0.25, small ? 0.1 : 0.25, 0.3, 10), 0x3a3d42));
    const m = new THREE.Mesh(mergeGeometries(blades), mat('n')); if (axis === 'x') m.rotation.z = PI / 2; rg.add(m);
    // disque flou (rotor en rotation rapide)
    const disc = new THREE.Mesh(new THREE.CircleGeometry(r, 32).rotateX(-PI / 2), new THREE.MeshBasicMaterial({ color: 0x202428, transparent: true, opacity: 0, depthWrite: false })); if (axis === 'x') disc.rotation.z = PI / 2; rg.add(disc);
    g.add(rg); rotors.push({ g: rg, m, disc, axis, small }); return rg;
  };
  if (sp.tandem) { mk(0, cy + h / 2 + 1.1, L / 2 - 1.6, sp.rotor, sp.blades); mk(0, cy + h / 2 + 2.3, -L / 2 + 1.8, sp.rotor, sp.blades); }
  else {
    mk(0, cy + h / 2 + 0.45, 0, sp.rotor, sp.blades);
    if (sp.tail === 'rotor') mk(0.25, cy + h * 0.15 + 0.6, -sp.len + L / 2 + 0.5, sp.rotor * 0.18, 2, true, 'x');
  }
  return { group: g, rotors, eye: new THREE.Vector3(0.35, cy + h * 0.15, L * 0.32), door: new THREE.Vector3(w / 2 + 1.3, 0, L * 0.1), centerY: cy };
}

// ------------------------------------------------------------------ pilotage
export class Helicopter {
  constructor(scene, spec, rec) {
    this.isAircraft = true; this.isHeli = true; this.spec = null; this.id = spec.id; this.hspec = spec;
    this.parts = buildHeliMesh(spec); this.mesh = this.parts.group;
    // interface commune avec les avions (tableau de bord de vol, caméra, sortie du véhicule)
    this.pspec = { name: spec.name, len: spec.len, span: spec.rotor * 2, centerY: this.parts.centerY, vRot: 9999, vMax: spec.vMax };
    this.pos = new THREE.Vector3(rec.x, rec.y || 0, rec.z); this.heading = rec.h || 0; this.pitch = 0; this.roll = 0;
    this.speed = 0; this.vf = 0; this.vl = 0; this.vs = 0; this.throttle = 0; this.rpm = 0; this.engine = false; this.airborne = false;
    this.gearDown = true; this.gearT = 1; this.flaps = 0; this.flapsAuto = false; this.stall = false; this.occupied = false; this.ground = 0;
    this.sound = { type: 'heli', mul: 1 }; this.hornFreqs = [600, 760]; this.model = { wheelR: 0.3 };
    scene.add(this.mesh); this.sync(0);
  }
  get forward() { return { x: Math.sin(this.heading), z: Math.cos(this.heading) }; }
  enableHeadlight() {}
  circles() { return []; }
  exitPoint() { this.mesh.updateMatrixWorld(true); const d = this.parts.door.clone(); this.mesh.localToWorld(d); d.y = 0; return d; }
  toggleEngine() {
    if (this.engine && this.airborne) return this.onMsg && this.onMsg('Impossible de couper le moteur en vol');
    this.engine = !this.engine; this.onMsg && this.onMsg(this.engine ? 'Moteur démarré : le rotor monte en régime…' : 'Moteur coupé');
  }
  update(dt, input, world) {
    const S = this.hspec;
    let col = 0, fwd = 0, yaw = 0, side = 0;
    if (this.occupied && input) {
      col = (input.down('ShiftLeft') || input.down('ShiftRight') ? 1 : 0) - (input.down('Space') ? 1 : 0);
      fwd = (input.down('KeyW') || input.down('ArrowUp') ? 1 : 0) - (input.down('KeyS') || input.down('ArrowDown') ? 1 : 0);
      yaw = (input.down('KeyA') ? 1 : 0) - (input.down('KeyD') ? 1 : 0);
      side = (input.down('ArrowRight') ? 1 : 0) - (input.down('ArrowLeft') ? 1 : 0); // translation latérale (flèches gauche/droite)
      if (input.hit('KeyG')) this.toggleEngine();
    }
    this.rpm = damp(this.rpm, this.engine ? 1 : 0, this.engine ? 0.55 : 0.35, dt);
    this.throttle = this.rpm * (0.55 + Math.max(0, col) * 0.45);
    const ready = this.rpm > 0.92, g = this.groundAt(this.pos.x, this.pos.z);
    // vertical
    if (!this.airborne) {
      this.vs = 0; this.pos.y = g;
      if (ready && col > 0) { this.airborne = true; this.vs = 1.5; this.onMsg && this.onMsg('Décollage vertical !'); }
      else if (col > 0 && this.engine) this.onMsg && this._msgT !== 1 && (this._msgT = 1, this.onMsg('Attends que le rotor soit à plein régime'));
    } else {
      let target = ready ? col * S.climb : -7; // moteur coupé : descente en autorotation
      if (ready && this.pos.y - g < 10 && target < -2.5) target = -2.5; // effet de sol : descente amortie près du sol
      this.vs = damp(this.vs, target, 1.6, dt);
      this.pos.y += this.vs * dt;
      if (this.pos.y > 1500) { this.pos.y = 1500; this.vs = Math.min(0, this.vs); }
    }
    // horizontal (repère de l'appareil)
    const air = this.airborne ? 1 : 0;
    this.vf = damp(this.vf, air * (fwd > 0 ? fwd * S.vMax : fwd * S.vMax * 0.25), fwd ? 0.45 : 0.6, dt);
    this.vl = damp(this.vl, air * side * 14, 1.2, dt);
    this.heading += yaw * S.yaw * this.rpm * dt * (this.airborne ? 1 : 0.15);
    const f = this.forward, rx = Math.cos(this.heading), rz = -Math.sin(this.heading);
    this.pos.x += (f.x * this.vf + rx * -this.vl) * dt; this.pos.z += (f.z * this.vf + rz * -this.vl) * dt;
    this.speed = Math.hypot(this.vf, this.vl);
    this.pitch = damp(this.pitch, -this.vf / S.vMax * 0.22 * air, 2.5, dt);
    this.roll = damp(this.roll, (this.vl / 14 * 0.25 + yaw * 0.12 * this.vf / S.vMax) * air, 2.5, dt);
    // limites du monde
    if (Math.abs(this.pos.x + 400) > 6200 || Math.abs(this.pos.z) > 6200) { const want = Math.atan2(-400 - this.pos.x, -this.pos.z); this.heading += clamp(want - this.heading, -1, 1) * dt; this.onMsg && this.onMsg('Limite de la zone de vol : retour vers Cotonou'); }
    // atterrissage, eau, bâtiments
    let crash = null;
    if (this.airborne && this.pos.y <= g && this.vs <= 0) {
      if (isWater(this.pos.x, this.pos.z)) crash = 'Amerrissage forcé : l’hélicoptère est ramené à l’héliport';
      else if (this.vs < -6.5 || this.speed > 16) crash = 'Atterrissage trop brutal : l’hélicoptère est ramené à l’héliport';
      else { this.airborne = false; this.pos.y = g; this.vs = 0; this.vf *= 0.2; this.vl = 0; this.onMsg && this.onMsg('Posé ! Coupe le moteur avec G pour descendre'); this.onLand && this.onLand(this); }
    }
    if (!crash && this.airborne && this.pos.y < 60) {
      const cy = this.pos.y + this.pspec.centerY;
      for (const k of [0, this.hspec.len * 0.45, -this.hspec.len * 0.4]) if (solidAt(world.collision, this.pos.x + f.x * k, cy, this.pos.z + f.z * k)) { crash = 'Collision avec un bâtiment : l’hélicoptère est ramené à l’héliport'; break; }
    }
    if (crash && this.onCrash) this.onCrash(this, crash);
    this.sync(dt);
    return 0;
  }
  groundAt(x, z) { let y = 0; for (const p of this.pads || []) if (p.y && Math.hypot(x - p.x, z - p.z) < 9) y = Math.max(y, p.y); return y; }
  sync(dt) {
    this.mesh.position.copy(this.pos);
    this.mesh.rotation.set(-this.pitch, this.heading, this.roll, 'YXZ');
    for (const r of this.parts.rotors) {
      const sp = this.rpm * (r.small ? 60 : 28);
      if (r.axis === 'x') r.m.rotation.x += dt * sp; else r.m.rotation.y += dt * sp;
      r.disc.material.opacity = Math.max(0, (this.rpm - 0.45) * 0.45); r.m.visible = this.rpm < 0.85 || (Math.floor(performance.now() / 40) % 2 === 0);
    }
  }
}

// ------------------------------------------------------------------ héliport, hélisurfaces, menu, missions
export class Heliport {
  constructor(ctx) {
    Object.assign(this, ctx); // scene, world, player, ui, audio, economy, tpc, airport, board(heli), onSave
    this.homes = HELIS.map((sp, i) => ({ x: -1470 - (i % 4) * 32, z: i < 4 ? 82 : 124, h: PI }));
    this.recs = HELIS.map((sp, i) => ({ id: sp.id, ...this.homes[i], moved: false }));
    this.helis = new Map(); this.open = false; this.sel = HELIS[0].id; this.mission = null; this.dest = null;
    this.pads = [];
    this.homes.forEach((h, i) => this.pads.push({ id: `hp${i}`, name: 'Héliport de l’aéroport', x: h.x, z: h.z, y: 0, home: true }));
    this.findPads();
    this.buildPads();
    this.dom = document.querySelector('#heli');
    this.dom.addEventListener('click', (e) => this.onClick(e));
  }
  // hélisurfaces de destination : emplacements libres vérifiés (aucun obstacle dans un rayon de 9 m, pas d'eau)
  findPads() {
    const col = this.world.collision, free = (x, z) => { if (isWater(x, z)) return false; for (let a = 0; a < 8; a++) for (const r of [0, 4.5, 9]) if (col.pointBlocked(x + Math.cos(a * PI / 4) * r, 0.5, z + Math.sin(a * PI / 4) * r)) return false; return true; };
    const lv = col.level; col.level = 0;
    const tryNear = (name, cands) => { for (const [x, z] of cands) if (free(x, z)) { this.pads.push({ id: name, name, x, z, y: 0 }); return; } };
    tryNear('Hélisurface de NOVA BOOK', [[83.5, 56], [64, 54], [50, 54], [86, 4], [30, 50]]);
    tryNear('Hélisurface de la plage de Cotonou', [[0, 152], [20, 152], [-20, 150], [40, 150]]);
    for (const t of TOWNS) if (t.name === 'Ouidah' || t.name === 'Porto-Novo') { const c = []; for (let k = 0; k < 24; k++) { const a = k * 0.9, r = t.r * (0.2 + (k % 6) * 0.12); c.push([t.x + Math.cos(a) * r, t.z + Math.sin(a) * r]); } tryNear(`Hélisurface de ${t.name}`, c); }
    col.level = lv;
  }
  buildPads() {
    const P = [], L = [];
    for (const p of this.pads) {
      P.push(colored(new THREE.CircleGeometry(9, 32).rotateX(-PI / 2).translate(p.x, p.y + 0.05, p.z), 0x3a3d42));
      P.push(colored(new THREE.RingGeometry(7.6, 8.1, 32).rotateX(-PI / 2).translate(p.x, p.y + 0.06, p.z), 0xf2f2f2));
      for (const [w, d, x, z] of [[0.8, 5, -1.6, 0], [0.8, 5, 1.6, 0], [2.4, 0.8, 0, 0]]) P.push(colored(new THREE.PlaneGeometry(w, d).rotateX(-PI / 2).translate(p.x + x, p.y + 0.07, p.z + z), 0xf2c200));
      for (let k = 0; k < 8; k++) L.push(colored(new THREE.SphereGeometry(0.18, 6, 4).translate(p.x + Math.cos(k * PI / 4) * 9, p.y + 0.15, p.z + Math.sin(k * PI / 4) * 9), 0x2fd05a));
    }
    const g = new THREE.Group();
    g.add(new THREE.Mesh(mergeGeometries(P), new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.9, polygonOffset: true, polygonOffsetFactor: -1 })));
    this.lmat = new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false }); g.add(new THREE.Mesh(mergeGeometries(L), this.lmat));
    // comptoir de l'héliport (à côté du comptoir des vols)
    const k = new THREE.Mesh(colored(new THREE.BoxGeometry(3, 2.4, 2.4).translate(KIOSK.x, 1.2, KIOSK.z), 0x1f4e9c), new THREE.MeshStandardMaterial({ vertexColors: true })); g.add(k);
    const sg = new THREE.Mesh(new THREE.PlaneGeometry(3, 0.7), new THREE.MeshBasicMaterial({ map: (() => { const c = document.createElement('canvas'); c.width = 256; c.height = 60; const x = c.getContext('2d'); x.fillStyle = '#f2c200'; x.fillRect(0, 0, 256, 60); x.fillStyle = '#111'; x.font = '900 34px Arial'; x.textAlign = 'center'; x.fillText('🚁 HÉLIPORT', 128, 44); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t; })(), toneMapped: false }));
    sg.position.set(KIOSK.x, 2.8, KIOSK.z + 1.25); g.add(sg);
    this.world.collision.addBox(KIOSK.x - 1.5, KIOSK.z - 1.2, KIOSK.x + 1.5, KIOSK.z + 1.2, 2.4);
    this.scene.add(g); this.padGroup = g;
  }
  spawn(rec) {
    if (this.helis.has(rec.id)) return this.helis.get(rec.id);
    const h = new Helicopter(this.scene, HELI_BY_ID[rec.id], rec); h.pads = this.pads;
    h.onMsg = (m) => this.ui.toast(m, 2.2); h.onCrash = (hh, msg) => this.reset(hh, msg); h.onLand = (hh) => this.landed(hh);
    this.helis.set(rec.id, h); return h;
  }
  despawn(id) { const h = this.helis.get(id); if (!h || h.occupied) return; this.scene.remove(h.mesh); this.helis.delete(id); }
  reset(h, msg) {
    this.ui.toast(msg, 3.5); this.ui.fade(true); setTimeout(() => this.ui.fade(false), 700);
    const i = HELIS.findIndex((s) => s.id === h.id), home = this.homes[i];
    Object.assign(h, { airborne: false, vs: 0, vf: 0, vl: 0, pitch: 0, roll: 0, heading: home.h }); h.pos.set(home.x, 0, home.z);
    const rec = this.recs[i]; Object.assign(rec, home, { moved: false });
    if (this.mission) { this.ui.toast('Vol de passagers annulé : les passagers sont débarqués à l’héliport.', 3); this.mission = null; }
    h.sync(0);
  }
  landed(h) {
    const M = this.mission; if (!M || this.player.inCar !== h) return;
    const p = M.to, d = Math.hypot(h.pos.x - p.x, h.pos.z - p.z);
    if (d < 14) {
      this.economy.earn(M.fare, `Vol de passagers : ${M.from} → ${p.name}`, 'Héliport');
      this.economy.notify(`🚁 ${M.pax.length} passager(s) déposé(s) à ${p.name} : ${fcfa(M.fare)} encaissés`);
      if (this.audio && this.audio.ctx) this.audio.tone(988, 0.15, 0.05, 'triangle');
      this.mission = null; this.onSave && this.onSave();
    } else this.ui.toast(`Destination : ${p.name} — à ${Math.round(d)} m (pose-toi au centre de l’hélisurface)`, 2.5);
  }
  nearest(x, z) {
    let best = null;
    const dk = Math.hypot(x - KIOSK.x, z - (KIOSK.z + 2));
    if (dk < 2.6) best = { d: dk, it: { label: () => '🚁 Héliport : choisir un hélicoptère', action: () => this.toggle(true) } };
    for (const h of this.helis.values()) {
      if (h.occupied || h.airborne) continue;
      const dp = h.exitPoint(), d = Math.hypot(x - dp.x, z - dp.z);
      if (d < 3 && (!best || d < best.d)) best = { d, it: { label: () => `Monter à bord du ${h.hspec.name}`, action: () => this.board(h) } };
    }
    return best;
  }
  update(dt) {
    const P = this.player.pos, cur = this.player.inCar && this.player.inCar.isHeli ? this.player.inCar : null;
    for (const rec of this.recs) {
      const h = this.helis.get(rec.id);
      if (h && h.occupied) { rec.x = h.pos.x; rec.z = h.pos.z; rec.h = h.heading; if (h.speed > 0.5 || h.airborne) rec.moved = true; continue; }
      const d = Math.hypot(rec.x - P.x, rec.z - P.z);
      if (!h && d < 900) this.spawn(rec); else if (h && d > 1200) this.despawn(rec.id);
    }
    for (const h of this.helis.values()) if (h !== cur) { if (!h.occupied && h.engine && !h.airborne) h.engine = false; h.rpm = damp(h.rpm, h.engine ? 1 : 0, 0.35, dt); h.sync(dt); }
    this.lmat.color.setScalar(0.4 + (this.env ? this.env.lightsOn : 0) * 0.8);
    this.padGroup.visible = true;
  }
  // ---------- menu de l'héliport ----------
  toggle(on) { this.open = on; this.dom.classList.toggle('show', on); if (on) this.render(); }
  render() {
    const sp = HELI_BY_ID[this.sel], dests = this.pads.filter((p) => !p.home);
    this.dom.innerHTML = `<div class="g-box"><div class="g-head"><h2>HÉLIPORT <span>AÉROPORT DE COTONOU</span></h2><button class="g-x" data-hl="x">✕</button></div>
      <div class="g-main"><div class="g-list">${HELIS.map((h) => `<button class="g-card${h.id === this.sel ? ' sel' : ''}" data-hl="sel:${h.id}"><b>${h.name}</b><small>${h.type}</small><span class="g-mini">${h.seats} places • ${h.engines}</span></button>`).join('')}</div>
      <div class="g-detail"><div class="g-name">${sp.name}</div><div class="g-type">${sp.type}</div>
        <div class="g-stats"><div><span>Vitesse max</span><em class="g-wide">${Math.round(sp.vMax * 3.6)} km/h</em></div><div><span>Montée</span><em class="g-wide">${sp.climb} m/s</em></div><div><span>Rotor</span><em class="g-wide">${sp.blades} pales • Ø ${(sp.rotor * 2).toFixed(1)} m${sp.tandem ? ' • rotors en tandem' : sp.tail === 'fenestron' ? ' • rotor de queue caréné' : ''}</em></div><div><span>Places</span><em class="g-wide">${sp.seats}</em></div></div>
        <h5 class="h-h5">Vol de passagers (facultatif)</h5>
        <div class="h-dest">${dests.map((p) => `<button data-hl="dest:${p.id}" class="${this.dest === p.id ? 'on' : ''}">${p.name}</button>`).join('')}<button data-hl="dest:" class="${!this.dest ? 'on' : ''}">Vol libre</button></div>
        <div class="a-btns"><button class="g-take" data-hl="go">${this.dest ? 'EMBARQUER LES PASSAGERS ET DÉCOLLER' : 'MONTER À BORD'}</button></div>
        <p class="g-note">Appareils fictifs inspirés de catégories d’hélicoptères réels, version civile. Pilotage simplifié : G moteur, Maj monter, Espace descendre, Z/W avancer, S reculer, Q/A-D tourner, flèches ←/→ translation, V cockpit.</p></div></div></div>`;
  }
  onClick(e) {
    const b = e.target.closest('[data-hl]'); if (!b) { if (e.target === this.dom) this.toggle(false); return; }
    e.stopPropagation(); const [a, v] = b.dataset.hl.split(':');
    if (this.audio && this.audio.ctx && this.audio.click) this.audio.click();
    if (a === 'x') return this.toggle(false);
    if (a === 'sel') this.sel = v;
    if (a === 'dest') this.dest = v || null;
    if (a === 'go') return this.prepare(this.sel);
    this.render();
  }
  prepare(id) {
    this.toggle(false);
    const i = HELIS.findIndex((s) => s.id === id), rec = this.recs[i], h = this.spawn(rec);
    if (h.occupied) return;
    if (rec.moved && !h.airborne) { Object.assign(rec, this.homes[i], { moved: false }); h.pos.set(rec.x, 0, rec.z); h.heading = rec.h; h.sync(0); }
    const pad = this.dest && this.pads.find((p) => p.id === this.dest);
    if (pad) {
      const n = 2 + Math.floor(Math.random() * Math.min(4, HELI_BY_ID[id].seats - 1)), pax = [...PAX].sort(() => Math.random() - 0.5).slice(0, n);
      const dist = Math.hypot(pad.x - h.pos.x, pad.z - h.pos.z), fare = Math.round((12000 + dist * 6 + n * 2500) / 500) * 500;
      this.mission = { to: pad, from: 'Héliport de l’aéroport', pax, fare };
      this.ui.toast(`🧳 ${n} passagers à bord (${pax.join(', ')}) → ${pad.name} • ${(dist / 1000).toFixed(1)} km • rémunération ${fcfa(fare)}`, 5);
      if (this.ui.setRoute) this.ui.setRoute({ id: `pad:${pad.id}`, name: pad.name, x: pad.x, z: pad.z }, true);
    } else this.mission = null;
    const dp = h.exitPoint(); this.player.pos.set(dp.x, 0, dp.z);
    this.board(h);
    this.onSave && this.onSave();
  }
  board(h) {
    const P = this.player;
    this.ui.fade(true);
    setTimeout(() => {
      P.inCar = h; h.occupied = true; P.mesh.visible = false;
      if (this.tpc) this.tpc.yaw = h.heading + PI;
      this.ui.fade(false);
      const tch = document.body.classList.contains('touch');
      this.ui.toast(tch ? `${h.hspec.name} : ✦ démarrer le moteur • 🏃 monter • ⤒ descendre • joystick : avancer, reculer, tourner • 👁 cockpit` : `${h.hspec.name} : G démarrer/couper le moteur, Maj monter, Espace descendre, Z/W avancer, S reculer, Q-D (A-D) tourner, flèches ←/→ translation, V cockpit, E descendre (posé)`, 7);
      if (this.audio && this.audio.ctx) this.audio.tone(660, 0.2, 0.05, 'sine');
    }, 400);
  }
  handleKeys(input) { if (input.hit('Escape')) this.toggle(false); }
  serialize() { return { helis: this.recs.filter((r) => r.moved).map((r) => ({ id: r.id, x: Math.round(r.x), z: Math.round(r.z), h: +r.h.toFixed(3) })) }; }
  restore(s) { if (!s || !Array.isArray(s.helis)) return; for (const p of s.helis) { const r = this.recs.find((x) => x.id === p.id); if (r) Object.assign(r, { x: p.x, z: p.z, h: p.h, moved: true }); } }
}
