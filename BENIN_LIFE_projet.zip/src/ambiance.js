// Mission 020, étape 5 — éclairage et ambiance de la VILLA NOVA.
// Chaque pièce (et les couloirs) a son propre réglage : allumé/éteint, intensité, couleur. Le réglage pilote à la fois les
// luminaires de la pièce (lampes, lustres, appliques, suspensions, LED de plafond, spots, éclairage indirect, vitrines,
// LED derrière les TV) et les lumières qui éclairent réellement la pièce où se trouve le joueur. Interrupteurs près des
// portes, application (Ma Villa → Éclairage), scènes prédéfinies (journée, dîner, soirée cinéma, nuit, fête). Sauvegardé.
import { VILLA } from './villa.js';
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
// teinte appliquée aux luminaires (multiplie leur couleur propre) et couleur de la lumière ambiante
export const COLORS = [
  ['chaud', 'Blanc chaud', 0xffffff, 0xffe8c8], ['neutre', 'Blanc neutre', 0xe6eeff, 0xf2f4ff], ['ambre', 'Ambre', 0xffc27a, 0xffc890], ['lagune', 'Bleu lagune', 0x6aaeff, 0x9cc8ff],
  ['violet', 'Violet', 0xb68aff, 0xc8a8ff], ['vert', 'Vert NOVA', 0x7affb4, 0xb0ffd0], ['rose', 'Rose', 0xff92c4, 0xffb8d8], ['rouge', 'Rouge tamisé', 0xff6a52, 0xff9a80],
];
const CBY = Object.fromEntries(COLORS.map((c) => [c[0], c]));
export const SCENES = [
  ['jour', '☀️ Journée', () => ({ all: [true, 100, 'chaud'] })],
  ['diner', '🍽️ Dîner', () => ({ all: [true, 55, 'ambre'], manger: [true, 85, 'chaud'], cuisine: [true, 90, 'neutre'], salon: [true, 60, 'ambre'] })],
  ['cinema', '🎬 Soirée cinéma', () => ({ all: [true, 35, 'ambre'], cinema: [true, 12, 'rouge'], salon: [true, 25, 'lagune'], couloirs: [true, 30, 'ambre'] })],
  ['nuit', '🌙 Nuit', () => ({ all: [true, 12, 'ambre'], couloirs: [true, 25, 'ambre'], suite: [false, 0, 'ambre'], enf1: [true, 8, 'rose'], enf2: [true, 8, 'lagune'], enf3: [true, 8, 'vert'] })],
  ['fete', '🎉 Fête', () => ({ all: [true, 80, 'chaud'], salon: [true, 100, 'violet'], jeux: [true, 100, 'rose'], manger: [true, 90, 'ambre'], couloirs: [true, 70, 'violet'] })],
];
export class Ambiance {
  constructor(ctx) {
    Object.assign(this, ctx); // villa, ui, economy, onSave
    this.zones = [...Object.values(this.villa.rooms).map((R) => ({ id: R.id, name: R.name, R })), { id: 'couloirs', name: 'Couloirs et hall d’entrée' }];
    this.set = {}; for (const z of this.zones) this.set[z.id] = { on: true, lvl: z.R && /chambre|suite/.test(z.R.type) ? 80 : 100, col: 'chaud' };
    this.scene = null; this.applyAll();
  }
  zoneAt(lx, lz) { const R = Object.values(this.villa.rooms).find((q) => lx >= q.x0 && lx <= q.x1 && lz >= q.z0 && lz <= q.z1); return R ? R.id : 'couloirs'; }
  factor(id) { const s = this.set[id] || this.set.couloirs; return s.on ? s.lvl / 100 : 0; }
  apply(id) {
    const s = this.set[id], m = this.villa.luxe && this.villa.luxe.glowByZone && this.villa.luxe.glowByZone[id]; if (!s) return;
    if (!m) { const R0 = this.villa.rooms[id]; if (R0 && R0.lamp) { const k0 = s.on ? 0.08 + 0.92 * (s.lvl / 100) : 0.06; R0.lamp.material.color.setHex(0xfff0c8).multiply(new (R0.lamp.material.color.constructor)(CBY[s.col][2])).multiplyScalar(k0); } return; }
    const k = s.on ? 0.08 + 0.92 * (s.lvl / 100) : 0.06; m.material.color.setHex(CBY[s.col][2]).multiplyScalar(k);
    const R = this.villa.rooms[id]; if (R && R.lamp) R.lamp.material.color.setHex(0xfff0c8).multiply(new (R.lamp.material.color.constructor)(CBY[s.col][2])).multiplyScalar(k);
  }
  applyAll() { for (const z of this.zones) this.apply(z.id); }
  // appelée par la villa à chaque image : lumières réelles de la pièce où se trouve le joueur
  light(P, ls, base) {
    const id = this.zoneAt(P.x - VILLA.O.x, P.z - VILLA.O.z), s = this.set[id];
    const amb = s.on ? 0.18 + 0.82 * (s.lvl / 100) : 0.12; ls.forEach((l) => { l.color.setHex(CBY[s.col][3]); l.intensity = base * amb; });
    if (id !== this._last) { this._last = id; }
  }
  change(id, patch) { this.set[id] = { ...this.set[id], ...patch }; this.scene = null; this.apply(id); this.onSave && this.onSave(); }
  scenario(key) {
    const sc = SCENES.find((q) => q[0] === key); if (!sc) return; const p = sc[2]();
    for (const z of this.zones) { const v = p[z.id] || p.all; this.set[z.id] = { on: v[0], lvl: v[1], col: v[2] }; }
    this.scene = key; this.applyAll(); this.ui.toast(`💡 Ambiance « ${sc[1].replace(/^[^\p{L}]+/u, '')} » appliquée dans toute la villa.`, 2.5); this.onSave && this.onSave();
  }
  // interrupteur mural (près de la porte de chaque pièce)
  switches() {
    if (this._sw) return this._sw; this._sw = [];
    for (const R of Object.values(this.villa.rooms)) { const inz = R.z0 === 10 ? 1 : -1, z = R.door.z + inz * 0.9, x = R.door.x + 1.25; this._sw.push({ id: R.id, x, z }); }
    this._sw.push({ id: 'couloirs', x: -35.4, z: 4.8 }); return this._sw;
  }
  nearest(x, z) {
    if (!this.villa.inside) return null; const O = VILLA.O; let best = null;
    for (const s of this.switches()) { const d = Math.hypot(x - (O.x + s.x), z - (O.z + s.z)); if (d < 0.9 && (!best || d < best.d)) best = { d: d + 0.25, it: { label: () => `Régler l’éclairage (${this.zones.find((q) => q.id === s.id).name.toLowerCase()})`, action: () => this.menu(s.id) } }; }
    return best;
  }
  menu(id) {
    const z = this.zones.find((q) => q.id === id), s = this.set[id], items = [];
    items.push({ label: s.on ? '⏻ Éteindre' : '⏻ Allumer', action: () => { this.change(id, { on: !s.on }); this.menu(id); } });
    for (const v of [15, 40, 70, 100]) items.push({ label: `${s.on && s.lvl === v ? '● ' : ''}Intensité ${v} %`, action: () => { this.change(id, { on: true, lvl: v }); this.menu(id); } });
    const i = COLORS.findIndex((c) => c[0] === s.col), nx = COLORS[(i + 1) % COLORS.length];
    items.push({ label: `🎨 Couleur : ${CBY[s.col][1]} → ${nx[1]}`, action: () => { this.change(id, { on: true, col: nx[0] }); this.menu(id); } });
    items.push({ label: '✨ Ambiances de toute la villa…', action: () => this.ui.openMenu('✨ Ambiances', 'S’appliquent à toutes les pièces (modifiables ensuite pièce par pièce).', SCENES.map(([k, l]) => ({ label: l, action: () => this.scenario(k) }))) });
    this.ui.openMenu(`💡 ${z.name}`, `Éclairage : ${s.on ? `${s.lvl} % • ${CBY[s.col][1]}` : 'éteint'}`, items);
  }
  // ------------------------------------------------------------------ application (Ma Villa → Éclairage)
  renderApp(b) {
    b.innerHTML = `<h4>💡 Éclairage et ambiance</h4><p class="ph-note">Plafonds LED, spots encastrés, éclairage indirect, lustres, suspensions, lampes, vitrines et LED derrière les télévisions. Réglage par pièce ; interrupteurs près des portes.</p>
      <div class="ph-chips">${SCENES.map(([k, l]) => `<button data-amb="scene:${k}" class="${this.scene === k ? 'on' : ''}">${l}</button>`).join('')}</div>
      <div class="ph-list">${this.zones.map((z) => { const s = this.set[z.id]; return `<div class="ph-row"><span><b>${esc(z.name)}</b><small>${s.on ? `${s.lvl} % • ${CBY[s.col][1]}` : 'Éteint'}</small></span><span class="pp-acts"><button class="ph-mini" data-amb="on:${z.id}">${s.on ? '⏻' : '○'}</button><button class="ph-mini" data-amb="minus:${z.id}">−</button><button class="ph-mini" data-amb="plus:${z.id}">+</button><button class="ph-mini" data-amb="col:${z.id}" style="background:#${CBY[s.col][3].toString(16).padStart(6, '0')};color:#111">🎨</button></span></div>`; }).join('')}</div>
      <button class="ph-mini" data-ph="villa">← Ma Villa</button>`;
  }
  onPhone(v) {
    const [a, id] = v.split(':'), s = this.set[id];
    if (a === 'scene') this.scenario(id);
    else if (a === 'on') this.change(id, { on: !s.on });
    else if (a === 'minus') this.change(id, { on: true, lvl: Math.max(5, s.lvl - 15) });
    else if (a === 'plus') this.change(id, { on: true, lvl: Math.min(100, s.lvl + 15) });
    else if (a === 'col') { const i = COLORS.findIndex((c) => c[0] === s.col); this.change(id, { on: true, col: COLORS[(i + 1) % COLORS.length][0] }); }
    this.economy.renderPhone();
  }
  serialize() { return { set: this.set, scene: this.scene }; }
  restore(s) { if (!s) return; for (const [k, v] of Object.entries(s.set || {})) if (this.set[k]) this.set[k] = { ...this.set[k], ...v }; this.scene = s.scene || null; this.applyAll(); }
}
