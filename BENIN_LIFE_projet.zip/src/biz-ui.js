// Mission 014, étape 2 — logiciel de gestion du PDG (« NOVA Gestion ») : tableau de bord, mes entreprises, employés,
// recrutement, salaires, commandes et contrats, comptabilité, investissements, immobilier, statistiques.
import { JOBS } from './nova-data.js';
import { fcfa } from './food-data.js';
import { MONTH_DAYS, SERVICES } from './company.js';
import { SUBS, INSTR } from './group.js';

const TABS = [['dash', '📊 Tableau de bord'], ['projets', '🗂️ Projets'], ['vie', '🎯 Objectifs & événements'], ['groupe', '🏢 Mes entreprises'], ['staff', '👥 Employés'], ['recrut', '🤝 Recrutement'], ['paie', '💰 Salaires'], ['cmd', '📄 Commandes'], ['compta', '📒 Comptabilité'], ['invest', '🛠️ Investissements'], ['immo', '🏬 Immobilier'], ['banque', '🏦 Banque'], ['stats', '📈 Statistiques']];
const GROUP = [['NOVA BOOK', 'Édition, graphisme et impression'], ['NOVA DIGITAL', 'Informatique et développement'], ['NOVA MEDIA', 'Audiovisuel et production vidéo'], ['NOVA IMMOBILIER', 'Location et gestion de bâtiments'], ['NOVA TRANSPORT', 'Transport et logistique'], ['NOVA DISTRIBUTION', 'Commerce et distribution']];

export class BizUI {
  constructor({ company, economy, audio }) {
    Object.assign(this, { company, economy, audio });
    this.tab = 'dash'; this.open = false; this.sub = null; this.from = 'book'; this.to = 'perso'; this.acc = 'perso';
    this.dom = document.querySelector('#biz');
    this.dom.addEventListener('click', (e) => this.onClick(e));
    company.ui = this;
  }
  toggle(on = !this.open, onClose) { this.open = on; this.company.open = on; this.dom.classList.toggle('show', on); this.onClose = on ? onClose : null; if (on) this.render(); else if (onClose) onClose(); }
  close() { const cb = this.onClose; this.open = false; this.company.open = false; this.dom.classList.remove('show'); this.onClose = null; if (cb) cb(); }
  handleKeys(input) { if (input.hit('Escape')) this.close(); }
  onClick(e) {
    const b = e.target.closest('[data-tab],[data-a],[data-x]'); if (!b) { if (e.target === this.dom) this.close(); return; }
    e.stopPropagation(); if (this.audio && this.audio.ctx) this.audio.click();
    if (b.dataset.x !== undefined) return this.close();
    if (b.dataset.tab) { this.tab = b.dataset.tab; return this.render(); }
    const C = this.company, G = C.group, [a, v] = b.dataset.a.split(':');
    if (a.startsWith('pj') && this.projects && this.projects.onAction(a, v)) return this.render();
    if ((a === 'talk' || a === 'tkgrp') && C.talk) { const [acc, id] = v.split('|'); this.close(); if (a === 'talk') C.talk.openKey(`e:${acc}:${id}`); else { const list = acc === 'book' ? C.staff.filter((e) => !id || e.dept === id) : (G.subs[acc] ? G.subs[acc].staff : []); C.talk.openGroup(list.map((e) => `e:${acc}:${e.id}`), acc === 'book' ? `NOVA BOOK${id ? ` • ${id}` : ''}` : G.subs[acc].name); } return; }
    if ((a === 'evt' || a === 'obj') && this.company.life && this.company.life.onAction(a, v)) return this.render();
    if (a === 'hire') C.hire(v); else if (a === 'fire') { if (b.dataset.sure) C.fire(+v); else { b.dataset.sure = '1'; b.textContent = 'Confirmer ?'; return; } }
    else if (a === 'train') C.train(+v); else if (a === 'promote') C.promote(+v);
    else if (a === 'accept') C.accept(v); else if (a === 'decline') C.decline(v);
    else if (a === 'pay') C.payroll(); else if (a === 'auto') C.autoPay = !C.autoPay;
    else if (a === 'upgrade') C.upgrade(v); else if (a === 'newcands') { if (C.cash >= 50000) { C.post('Annonce de recrutement', -50000, 'frais'); C.refreshCandidates(); } }
    else if (a === 'in') C.transfer(+v, true); else if (a === 'out') C.transfer(+v, false);
    else if (G) {
      const [x, y] = (v || '').split('|');
      if (a === 'create') G.start(x, 'create', y); else if (a === 'buy') G.start(x, 'buy', y);
      else if (a === 'sub') this.sub = v; else if (a === 'subback') this.sub = null;
      else if (a === 'shire') G.hire(x, y); else if (a === 'sfire') { if (b.dataset.sure) G.fire(x, +y); else { b.dataset.sure = '1'; b.textContent = 'Confirmer ?'; return; } }
      else if (a === 'sdir') G.setDirector(x, +y); else if (a === 'sup') G.upgrade(v); else if (a === 'sprem') G.buyPremises(v); else if (a === 'spay') G.payroll(v);
      else if (a === 'sauto') G.subs[v].autoPay = !G.subs[v].autoPay;
      else if (a === 'sins') G.setInstruction(x, y);
      else if (a === 'from') this.from = v; else if (a === 'to') this.to = v; else if (a === 'xfer') G.transfer(this.from, this.to, +v);
      else if (a === 'acc') this.acc = v; else if (a === 'loan') G.loan(x, +y, 12); else if (a === 'repay') G.repay(+v);
    }
    this.render();
  }
  kpi(l, v, cls = '') { return `<div class="bz-k ${cls}"><small>${l}</small><b>${v}</b></div>`; }
  render() {
    if (!this.open) return;
    const C = this.company, m = C.cur(), mass = C.massSalary(), dayIn = ((C.day - 1) % MONTH_DAYS) + 1;
    const net = m.ca + m.salaires + m.invest + m.frais;
    let b = '';
    if (this.tab === 'dash') {
      b = `<div class="bz-grid">${this.kpi('Trésorerie de NOVA BOOK', fcfa(C.cash), C.cash < mass ? 'neg' : 'pos')}${this.kpi('Chiffre d’affaires du mois', fcfa(m.ca))}${this.kpi('Dépenses du mois', fcfa(Math.abs(m.frais + m.invest)))}${this.kpi('Salaires versés', fcfa(Math.abs(m.salaires)))}${this.kpi('Bénéfice net du mois', fcfa(net), net < 0 ? 'neg' : 'pos')}${this.kpi('Masse salariale mensuelle', fcfa(mass))}</div>
        <p class="bz-note">Mois ${C.month}, jour ${dayIn}/${MONTH_DAYS} • ${C.staff.length} employés • ${C.orders.length} commande(s) en cours • Compte personnel du PDG : ${fcfa(this.economy.balance)} (séparé)</p>
        ${C.payDue ? `<div class="bz-alert">💰 Salaires à payer : <b>${fcfa(C.payDue.total)}</b> <button data-tab="paie">Voir la paie</button></div>` : ''}
        ${C.cash < mass ? '<div class="bz-alert neg">🚨 La trésorerie ne couvre pas un mois de salaires. Accepte des commandes, réduis les dépenses ou fais un apport personnel (Comptabilité).</div>' : ''}
        <h5>Commandes en cours</h5>${C.orders.map((o) => this.orderRow(o)).join('') || '<p class="bz-note">Aucune commande en cours : va dans « Commandes ».</p>'}`;
    } else if (this.tab === 'vie') {
      b = this.company.life ? this.company.life.view() : '';
    } else if (this.tab === 'projets') {
      b = this.projects ? this.projects.render() : '<p class="bz-note">Projets indisponibles.</p>';
    } else if (this.tab === 'groupe') {
      b = this.groupView();
    } else if (this.tab === 'staff') {
      b = `<p class="bz-note">${C.staff.length} employés • masse salariale ${fcfa(mass)}/mois • formation 150 000 FCFA (1 jour, +10 compétence) • promotion +15 % de salaire • licenciement : indemnité d’un mois</p><div class="bz-row"><span><b>💬 Discussion collective</b><small>Réunir une équipe pour échanger librement (consignes, questions, félicitations)</small></span><span class="bz-btns">${[...new Set(C.staff.map((e) => e.dept))].map((d) => `<button data-a="tkgrp:book|${d}">${d}</button>`).join('')}</span></div>` + C.staff.map((e) => `<div class="bz-row"><span><b>${e.name}</b><small>${JOBS[e.job].label} • ${e.dept} • ${e.lv === 0 ? 'RDC' : e.lv + 'e étage'} • compétence ${e.skill} • ${Math.floor(e.exp)} an(s) d’expérience • échelon ${e.grade} • moral ${Math.round(e.morale)} • productivité ${Math.round(C.prod(e) * 100)} % • ${e.status}</small></span><em>${fcfa(e.salary)}</em>
        <span class="bz-btns"><button data-a="talk:book|${e.id}">💬 Parler</button><button data-a="train:${e.id}" ${e.status !== 'présent' ? 'disabled' : ''}>Former</button><button data-a="promote:${e.id}" ${e.grade >= 3 ? 'disabled' : ''}>Promouvoir</button><button class="red" data-a="fire:${e.id}">Licencier</button></span></div>`).join('');
    } else if (this.tab === 'recrut') {
      b = `<p class="bz-note">Candidats disponibles (renouvelés chaque mois). Nouvelle annonce : 50 000 FCFA. Les recrues s’installent à un poste libre de leur étage.</p>` + C.candidates.map((e) => `<div class="bz-row"><span><b>${e.name}</b><small>${JOBS[e.job].label} • ${e.dept} • compétence ${e.skill} • ${e.exp} an(s) d’expérience</small></span><em>${fcfa(e.salary)}/mois</em><span class="bz-btns"><button data-a="hire:${e.cid}">Recruter</button></span></div>`).join('') + '<button class="bz-go" data-a="newcands">Publier une nouvelle annonce (50 000 FCFA)</button>';
    } else if (this.tab === 'paie') {
      const P = C.payDue;
      b = `<div class="bz-row"><span><b>Paiement automatique des salaires</b><small>Désactivé par défaut : tu valides toi-même chaque fin de mois.</small></span><span class="bz-btns"><button data-a="auto" class="${C.autoPay ? 'on' : ''}">${C.autoPay ? 'Activé' : 'Désactivé'}</button></span></div>`;
      if (P) b += `<h5>Salaires du mois ${P.month}${C.unpaidDays ? ` — en retard de ${C.unpaidDays} jour(s), le moral baisse` : ''}</h5>${P.lines.map((l) => `<div class="bz-row"><span>${l.name}<small>${l.job}</small></span><em>${fcfa(l.salary)}</em></div>`).join('')}
        <div class="bz-row tot"><span><b>Total à payer</b></span><em>${fcfa(P.total)}</em></div>
        ${C.cash >= P.total ? `<button class="bz-go" data-a="pay">✅ Valider le paiement des salaires (${fcfa(P.total)})</button>` : `<div class="bz-alert neg">🚨 Fonds insuffisants (${fcfa(C.cash)}). Décisions possibles : faire un apport personnel (Comptabilité), livrer des commandes en cours, réduire les effectifs.</div>`}`;
      else b += `<p class="bz-note">Aucun salaire en attente. Prochaine paie à la fin du mois ${C.month} (jour ${MONTH_DAYS}). Masse salariale actuelle : ${fcfa(mass)}.</p>`;
    } else if (this.tab === 'cmd') {
      b = `<h5>Propositions de clients</h5>${C.offers.map((o) => `<div class="bz-row"><span><b>${o.label}</b><small>${o.client} • ${o.dept} • charge ${o.work} pts • délai ${o.days} jour(s) • capacité ${C.orders.filter((q) => q.dept === o.dept).length}/${C.capacity(o.dept)}</small></span><em class="pos">${fcfa(o.price)}</em><span class="bz-btns"><button data-a="accept:${o.oid}">Signer le contrat</button><button data-a="decline:${o.oid}">Refuser</button></span></div>`).join('')}
        <h5>En cours</h5>${C.orders.map((o) => this.orderRow(o)).join('') || '<p class="bz-note">Aucune.</p>'}
        <h5>Livrées (factures payées)</h5>${C.done.slice(0, 10).map((o) => `<div class="bz-row"><span>${o.label}<small>${o.client} • ${o.d}${o.late ? ' • en retard' : ''}</small></span><em class="pos">+${fcfa(o.paid)}</em></div>`).join('') || '<p class="bz-note">Aucune.</p>'}
        <p class="bz-note">Les équipes travaillent de 7 h à 19 h. Plus les employés sont compétents, motivés et bien équipés, plus les commandes avancent vite.</p>`;
    } else if (this.tab === 'compta') {
      b = `<div class="bz-grid">${this.kpi('Trésorerie entreprise', fcfa(C.cash))}${this.kpi('Compte personnel', fcfa(this.economy.balance))}</div>
        <div class="bz-row"><span><b>Virements</b><small>Apport du PDG vers l’entreprise, ou dividende de l’entreprise vers ton compte personnel.</small></span><span class="bz-btns"><button data-a="in:100000">Apport 100 000</button><button data-a="in:1000000">Apport 1 000 000</button><button data-a="out:100000">Dividende 100 000</button><button data-a="out:500000">Dividende 500 000</button></span></div>
        <h5>Journal comptable</h5>${C.ledger.slice(0, 40).map((l) => `<div class="bz-row"><span>${l.label}<small>${l.d} • ${l.cat}</small></span><em class="${l.amount < 0 ? 'neg' : 'pos'}">${l.amount < 0 ? '−' : '+'}${fcfa(Math.abs(l.amount))}</em></div>`).join('')}`;
    } else if (this.tab === 'invest') {
      b = `<p class="bz-note">Équipements de production : chaque niveau augmente la production du département de 25 %.</p>` + Object.entries(C.equip).map(([d, lv]) => `<div class="bz-row"><span><b>${d}</b><small>Niveau ${lv}/3 • production ${Math.round(C.deptRate(d) * 12)} pts/jour</small></span><span class="bz-btns">${lv < 3 ? `<button data-a="upgrade:${d}">Améliorer (${fcfa(C.equipCost(d))})</button>` : '<button disabled>Niveau maximal</button>'}</span></div>`).join('');
    } else if (this.tab === 'immo') {
      const G = C.group;
      b = `<div class="bz-row"><span><b>Siège social NOVA BOOK</b><small>Quartier d’affaires de Cotonou • 6 niveaux • parking</small></span><em class="pos">Propriétaire</em></div>` + (G ? Object.values(G.subs).map((q) => `<div class="bz-row"><span><b>Bureaux de ${q.name}</b><small>Immeuble de bureaux de Cotonou (voir la carte) • ${q.premises === 'loués' ? 'loyer 300 000 FCFA/mois' : 'sans loyer'}</small></span><em>${q.premises === 'loués' ? 'Locataire' : 'Propriétaire'}</em><span class="bz-btns">${q.premises === 'loués' ? `<button data-a="sprem:${q.id}">Acheter les locaux (9 000 000)</button>` : ''}</span></div>`).join('') : '') + '<p class="bz-note">Les bureaux des sociétés du groupe sont placés dans des immeubles existants de Cotonou (marqueurs sur la carte). Ils ne sont pas encore aménagés pour la visite.</p>';
    } else if (this.tab === 'banque') {
      b = this.bankView();
    } else if (this.tab === 'stats') {
      const by = {}; for (const e of C.staff) by[e.dept] = (by[e.dept] || 0) + 1;
      b = `<h5>Historique mensuel</h5>${C.months.map((h) => `<div class="bz-row"><span><b>Mois ${h.m}</b><small>CA ${fcfa(h.ca)} • salaires ${fcfa(Math.abs(h.salaires))} • investissements ${fcfa(Math.abs(h.invest))} • frais ${fcfa(Math.abs(h.frais))}</small></span><em class="${h.net < 0 ? 'neg' : 'pos'}">${fcfa(h.net)}</em></div>`).join('') || '<p class="bz-note">Le premier bilan arrivera à la fin du mois 1.</p>'}
        <h5>Effectif par département</h5>${Object.entries(by).map(([d, n]) => `<div class="bz-bar"><span>${d}</span><i style="width:${n * 26}px"></i><b>${n}</b></div>`).join('')}
        <h5>Production par département (pts/jour)</h5>${Object.keys(C.equip).map((d) => `<div class="bz-bar"><span>${d}</span><i style="width:${Math.min(240, C.deptRate(d) * 12 * 3)}px;background:#2f80ed"></i><b>${Math.round(C.deptRate(d) * 12)}</b></div>`).join('')}
        <p class="bz-note">Prestations proposées : ${SERVICES.length} (romans, manuels scolaires, livres éducatifs, mise en page, couvertures, impression, brochures, affiches, supports publicitaires, vidéos, site de commande).</p>`;
    }
    const tabs = TABS.map(([k, l]) => `<button data-tab="${k}" class="${k === this.tab ? 'on' : ''}">${l}</button>`).join('');
    this.dom.innerHTML = `<div class="bz-box"><div class="bz-head"><b>NOVA Gestion — Groupe NOVA</b><span>${fcfa(C.cash)}</span><button data-x>✕</button></div><div class="bz-tabs">${tabs}</div><div class="bz-body">${b}</div></div>`;
  }
  groupView() {
    const C = this.company, G = C.group; if (!G) return '';
    if (this.sub && G.subs[this.sub]) return this.subView(G.subs[this.sub]);
    const rows = [`<div class="bz-row"><span><b>⭐ NOVA BOOK</b><small>Édition, graphisme et impression • siège social visitable</small></span><em class="pos">${fcfa(C.cash)} • ${C.staff.length} employés</em></div>`];
    for (const d of SUBS) {
      const q = G.subs[d.id];
      if (q) { const dir = q.staff.find((e) => e.id === q.director); rows.push(`<div class="bz-row"><span><b>${q.name}</b><small>${d.sector} • ${q.staff.length} employés • directeur : ${dir ? dir.name : 'à nommer'} • CA du mois ${fcfa(q.cur.ca)}</small></span><em class="${q.cash < 0 ? 'neg' : 'pos'}">${fcfa(q.cash)}</em><span class="bz-btns"><button data-a="sub:${d.id}">Gérer</button></span></div>`); }
      else rows.push(`<div class="bz-row"><span><b>${d.name}</b><small>${d.sector} • créer : ${fcfa(d.create)} (4 employés débutants, capital 2 M) • racheter : ${fcfa(d.buy)} (8 employés expérimentés, clients, trésorerie 1,5 M)</small></span><span class="bz-btns"><button data-a="create:${d.id}|book">Créer (NOVA BOOK paie)</button><button data-a="create:${d.id}|perso">Créer (compte perso)</button><button data-a="buy:${d.id}|book">Racheter (NOVA BOOK)</button><button data-a="buy:${d.id}|perso">Racheter (perso)</button></span></div>`);
    }
    return rows.join('') + '<p class="bz-note">Chaque société a sa propre trésorerie, ses employés, ses charges (salaires, loyer, frais) et ses recettes quotidiennes, qui dépendent de la compétence et du moral des équipes, du directeur et des équipements. Les gros revenus demandent des investissements.</p>';
  }
  subView(q) {
    const d = SUBS.find((x) => x.id === q.id), G = this.company.group, mass = q.staff.reduce((a, e) => a + e.salary, 0);
    const jobs = [...new Set(d.jobs)];
    return `<button class="bz-back" data-a="subback">← Mes entreprises</button><h4 class="bz-h">${q.name} <small>${d.sector}</small></h4>
      <div class="bz-grid">${this.kpi('Trésorerie', fcfa(q.cash), q.cash < 0 ? 'neg' : 'pos')}${this.kpi('CA du mois', fcfa(q.cur.ca))}${this.kpi('Recette moyenne / jour', fcfa(Math.round(G.rate(q) / 5000) * 5000))}${this.kpi('Masse salariale', fcfa(mass))}${this.kpi('Locaux', q.premises)}${this.kpi('Équipements', `niveau ${q.equip}/3`)}</div>
      ${q.payDue ? `<div class="bz-alert">💰 Salaires à payer : ${fcfa(q.payDue)} <button data-a="spay:${q.id}">Payer</button></div>` : ''}
      <div class="bz-row"><span><b>Paie automatique</b><small>Activée par défaut pour les filiales (géré par le directeur)</small></span><span class="bz-btns"><button data-a="sauto:${q.id}" class="${q.autoPay ? 'on' : ''}">${q.autoPay ? 'Activée' : 'Désactivée'}</button></span></div>
      <div class="bz-row"><span><b>Investir</b></span><span class="bz-btns">${q.equip < 3 ? `<button data-a="sup:${q.id}">Équipements (${fcfa([0, 1200000, 2500000][q.equip])})</button>` : ''}${q.premises === 'loués' ? `<button data-a="sprem:${q.id}">Acheter les locaux (9 000 000)</button>` : ''}</span></div>
      <div class="bz-row"><span><b>Consigne au directeur</b><small>${q.instruction && INSTR[q.instruction] ? `${INSTR[q.instruction].label} : ${INSTR[q.instruction].effect}` : 'Aucune consigne (fonctionnement normal)'}</small></span><span class="bz-btns">${Object.entries(INSTR).map(([k, v]) => `<button data-a="sins:${q.id}|${k}" class="${q.instruction === k ? 'on' : ''}">${v.label}</button>`).join('')}<button data-a="sins:${q.id}|" class="${q.instruction ? '' : 'on'}">Aucune</button></span></div>
      <div class="bz-row"><span><b>Recruter</b></span><span class="bz-btns">${jobs.map((j) => `<button data-a="shire:${q.id}|${j}">+ ${JOBS[j].label}</button>`).join('')}</span></div>
      <h5>Équipe <button data-a="tkgrp:${q.id}|">💬 Discussion collective</button></h5>${q.staff.map((e) => `<div class="bz-row"><span><b>${e.id === q.director ? '👔 ' : ''}${e.name}</b><small>${JOBS[e.job].label} • compétence ${e.skill} • moral ${Math.round(e.morale)}</small></span><em>${fcfa(e.salary)}</em><span class="bz-btns"><button data-a="talk:${q.id}|${e.id}">💬 Parler</button>${e.id !== q.director ? `<button data-a="sdir:${q.id}|${e.id}">Nommer directeur</button>` : ''}<button class="red" data-a="sfire:${q.id}|${e.id}">Licencier</button></span></div>`).join('')}
      <h5>Derniers mouvements</h5>${q.ledger.slice(0, 10).map((l) => `<div class="bz-row"><span>${l.label}<small>${l.d}</small></span><em class="${l.amount < 0 ? 'neg' : 'pos'}">${l.amount < 0 ? '−' : '+'}${fcfa(Math.abs(l.amount))}</em></div>`).join('')}`;
  }
  bankView() {
    const G = this.company.group; if (!G) return '';
    const accs = G.accounts(), chip = (k, cur, act) => accs.map((x) => `<button data-a="${act}:${x}" class="${x === cur ? 'on' : ''}">${G.accName(x)}</button>`).join('');
    const st = G.statement(this.acc).slice(0, 25);
    const sheet = G.months[0];
    return `<h5>Comptes</h5><div class="bz-grid">${accs.map((x) => this.kpi(G.accName(x), fcfa(G.balance(x)), G.balance(x) < 0 ? 'neg' : '')).join('')}</div>
      <h5>Virement</h5><div class="bz-row"><span><b>De</b></span><span class="bz-btns">${chip('', this.from, 'from')}</span></div><div class="bz-row"><span><b>Vers</b></span><span class="bz-btns">${chip('', this.to, 'to')}</span></div>
      <div class="bz-row"><span><b>Montant</b><small>${G.accName(this.from)} → ${G.accName(this.to)}</small></span><span class="bz-btns">${[50000, 250000, 1000000, 5000000].map((v) => `<button data-a="xfer:${v}">${fcfa(v)}</button>`).join('')}</span></div>
      <h5>Prêts (facultatifs) — taux du jeu 1,2 % par mois, 12 mensualités</h5>
      <div class="bz-row"><span><b>Demander un prêt</b><small>Le montant est versé sur le compte choisi ; les mensualités sont prélevées à chaque fin de mois.</small></span><span class="bz-btns">${['book', 'perso', ...Object.keys(G.subs)].slice(0, 4).map((x) => `<button data-a="loan:${x}|2000000">2 M → ${G.accName(x)}</button>`).join('')}<button data-a="loan:book|10000000">10 M → NOVA BOOK</button></span></div>
      ${G.loans.map((L, i) => `<div class="bz-row"><span><b>Prêt de ${fcfa(L.principal)}</b><small>${G.accName(L.acc)} • ${L.left}/${L.months} mensualités restantes • depuis ${L.since}</small></span><em>${fcfa(L.monthly)}/mois</em><span class="bz-btns"><button data-a="repay:${i}">Rembourser (${fcfa(L.monthly * L.left)})</button></span></div>`).join('') || '<p class="bz-note">Aucun prêt en cours.</p>'}
      <h5>Bilan mensuel ${sheet ? `(mois ${sheet.m})` : ''}</h5>${sheet ? sheet.rows.map((r) => `<div class="bz-row"><span><b>${r.name}</b><small>CA ${fcfa(r.ca)} • charges ${fcfa(Math.abs(r.charges))} • trésorerie ${fcfa(r.cash)}</small></span><em class="${r.net < 0 ? 'neg' : 'pos'}">${fcfa(r.net)}</em></div>`).join('') : '<p class="bz-note">Disponible après la première fin de mois.</p>'}
      <h5>Relevé bancaire</h5><div class="bz-row"><span class="bz-btns">${chip('', this.acc, 'acc')}</span></div>
      ${st.map((l) => `<div class="bz-row"><span>${l.label}<small>${l.d}</small></span><em class="${l.amount < 0 ? 'neg' : 'pos'}">${l.amount < 0 ? '−' : '+'}${fcfa(Math.abs(l.amount))}</em></div>`).join('') || '<p class="bz-note">Aucune opération.</p>'}`;
  }
  orderRow(o) { const pct = Math.round((o.done / o.work) * 100); return `<div class="bz-row"><span><b>${o.label}</b><small>${o.client} • ${o.dept} • ${o.left >= 0 ? `${o.left} jour(s) restant(s)` : 'en retard'}</small><i class="bz-prog"><i style="width:${pct}%"></i></i></span><em>${pct} % • ${fcfa(o.price)}</em></div>`; }
}
