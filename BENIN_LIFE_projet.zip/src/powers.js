// Mission 011 — système de 20 pouvoirs mystiques (univers fantastique inspiré du Bénin).
// Énergie mystique, progression (niveaux, déblocages, améliorations), raccourcis, effets 3D, sons synthétiques,
// créatures imaginaires (feux follets), symboles cachés, pierres-portails et sauvegarde.
// Aucun effet n'ajoute de lumière dynamique (pas de recompilation de shaders) : tout est additif / particules.
import * as THREE from 'three';
import { clone as skClone } from 'three/addons/utils/SkeletonUtils.js';
import { POWERS, POWER_BY_ID, PCATS, XP_LEVELS, MAX_RANK, stats, drawPowerIcon } from './powers-data.js';
import { Particles } from './inventory.js';
import { createCharacter } from './character.js';
import { HOME } from './home.js';
import { SEA_Z, MAP, BOUNDS } from './world.js';
import { isWater } from './region-geo.js';

const rnd = (a, b) => a + Math.random() * (b - a);
const C = (hex) => { const c = new THREE.Color(hex); return [c.r, c.g, c.b]; };
const LATERITE = 0x9a5236, GOLD = 0xf2c230;
const SLOTS_N = 5;

// ---------- matériaux d'effets ----------
const auraVert = /* glsl */`
varying vec2 vUv; varying vec3 vN; varying vec3 vV;
void main() { vUv = uv; vec4 wp = modelMatrix * vec4(position, 1.0); vN = normalize(mat3(modelMatrix) * normal); vV = normalize(cameraPosition - wp.xyz); gl_Position = projectionMatrix * viewMatrix * wp; }`;
const NOISE = /* glsl */`
float h21(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float n2(vec2 p) { vec2 i = floor(p), f = fract(p); vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(mix(h21(i), h21(i + vec2(1, 0)), u.x), mix(h21(i + vec2(0, 1)), h21(i + vec2(1, 1)), u.x), u.y); }`;
const auraFrag = /* glsl */`
uniform float uTime; uniform vec3 uC1; uniform vec3 uC2; uniform float uI; uniform float uRainbow;
varying vec2 vUv; varying vec3 vN; varying vec3 vV;
${NOISE}
void main() {
  float y = vUv.y;
  float f = n2(vec2(vUv.x * 10.0, y * 4.0 - uTime * 2.5)) * 0.6 + n2(vec2(vUv.x * 23.0, y * 8.0 - uTime * 4.2)) * 0.4;
  float edge = 1.0 - abs(dot(normalize(vN), normalize(vV)));
  float a = smoothstep(0.28, 0.95, f + (1.0 - y) * 0.55 - y * 0.35) * (1.0 - y) * (0.3 + edge) * uI;
  vec3 col = mix(uC1, uC2, clamp(f * y * 1.6, 0.0, 1.0));
  if (uRainbow > 0.5) col = 0.6 + 0.4 * cos(6.2831 * (vec3(0.0, 0.33, 0.67) + vUv.x + uTime * 0.3 + y));
  gl_FragColor = vec4(col * 1.5, a);
}`;
const shellFrag = /* glsl */`
uniform float uTime; uniform vec3 uC1; uniform float uI; uniform float uKind;
varying vec2 vUv; varying vec3 vN; varying vec3 vV;
${NOISE}
void main() {
  float fr = pow(1.0 - abs(dot(normalize(vN), normalize(vV))), 2.2);
  float pat;
  if (uKind < 0.5) { // motif de losanges (bouclier)
    vec2 g = vec2(vUv.x * 28.0, vUv.y * 14.0); vec2 q = abs(fract(g) - 0.5);
    pat = smoothstep(0.42, 0.5, q.x + q.y) * (0.6 + 0.4 * sin(uTime * 3.0 + vUv.y * 20.0));
  } else { // eau
    pat = n2(vec2(vUv.x * 18.0 + uTime * 0.6, vUv.y * 9.0 - uTime * 1.3)) * 0.7;
  }
  float band = smoothstep(0.0, 0.04, fract(vUv.y * 3.0 - uTime * 0.4)) * smoothstep(0.1, 0.04, fract(vUv.y * 3.0 - uTime * 0.4));
  float a = (fr * 0.85 + pat * 0.35 + band * 0.25) * uI;
  gl_FragColor = vec4(uC1 * (1.0 + pat), a);
}`;
const swirlFrag = /* glsl */`
uniform float uTime; uniform vec3 uC1; uniform float uI;
varying vec2 vUv;
void main() {
  vec2 p = vUv - 0.5; float r = length(p) * 2.0; float a = atan(p.y, p.x);
  float s = sin(a * 3.0 + r * 9.0 - uTime * 3.0) * 0.5 + 0.5;
  float alpha = smoothstep(1.0, 0.6, r) * (0.35 + 0.65 * s) * uI;
  gl_FragColor = vec4(uC1 * (0.7 + s * 0.8), alpha);
}`;
const swirlVert = /* glsl */`varying vec2 vUv; void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`;
function fxMat(frag, uniforms, vert = auraVert) {
  return new THREE.ShaderMaterial({ vertexShader: vert, fragmentShader: frag, uniforms: { uTime: { value: 0 }, uI: { value: 1 }, ...uniforms },
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, toneMapped: false, fog: false });
}
function glowTexture() {
  const c = document.createElement('canvas'); c.width = c.height = 128;
  const x = c.getContext('2d'), g = x.createRadialGradient(64, 64, 0, 64, 64, 64);
  g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(0.25, 'rgba(255,255,255,0.55)'); g.addColorStop(1, 'rgba(255,255,255,0)');
  x.fillStyle = g; x.fillRect(0, 0, 128, 128);
  return new THREE.CanvasTexture(c);
}

export class Powers {
  constructor(ctx) {
    Object.assign(this, ctx); // scene, camera, player, ui, audio, needs, env, peds, traffic, cars, world, onSave
    this.xp = 0; this.spent = 0; this.ranks = {};
    this.slots = ['feu', 'vent', 'aura', 'vision', null]; this.sel = 0;
    this.energy = 100;
    this.glyphsFound = new Set(); this.portalsFound = new Set(); this.used = new Set(); this.wispsRepelled = 0;
    this.active = {}; this.cd = {};
    this.open = false; this.portalOpen = false;
    this.menuCat = 'all'; this.menuSel = 'feu';
    this.castT = 0; this.danceT = 0; this.temp = [];
    this.particles = new Particles(this.scene);
    this.glowTex = glowTexture();
    this.icons = {}; this.glyphTex = {};
    for (const p of POWERS) this.icons[p.id] = drawPowerIcon(p, 128).toDataURL('image/png');
    this.buildPortals();
    this.buildGlyphSpots();
    this.buildWisps();
    this.buildDom();
    this.renderBar();
  }

  // ---------- progression ----------
  get level() { let l = 1; for (let i = 0; i < XP_LEVELS.length; i++) if (this.xp >= XP_LEVELS[i]) l = i + 1; return l; }
  get maxEnergy() { return 100 + (this.level - 1) * 10; }
  get points() { return (this.level - 1) * 2 - this.spent; }
  rank(id) { return this.ranks[id] || 1; }
  unlocked(id) { return POWER_BY_ID[id].lvl <= this.level; }
  addXp(n, why) {
    const before = this.level;
    this.xp += n;
    const after = this.level;
    if (after > before) {
      const news = POWERS.filter((p) => p.lvl > before && p.lvl <= after).map((p) => p.name);
      this.energy = this.maxEnergy;
      this.ui.toast(`✧ Niveau mystique ${after} ! +2 points d’amélioration${news.length ? ' • Nouveaux pouvoirs : ' + news.join(', ') : ''}`, 5);
      this.sound('levelup');
      for (const id of POWERS.filter((p) => p.lvl > before && p.lvl <= after).map((p) => p.id)) { const i = this.slots.indexOf(null); if (i >= 0) this.slots[i] = id; }
      this.renderBar();
    }
    if (this.open) this.renderMenu();
    return why;
  }
  upgrade(id) {
    if (!this.unlocked(id) || this.rank(id) >= MAX_RANK || this.points <= 0) return;
    this.ranks[id] = this.rank(id) + 1; this.spent++;
    this.sound('upgrade');
    this.renderMenu(); this.renderBar(); this.onSave && this.onSave();
  }
  assign(id, slot) {
    if (!this.unlocked(id)) return;
    const prev = this.slots.indexOf(id); if (prev >= 0) this.slots[prev] = this.slots[slot] === id ? null : this.slots[slot];
    this.slots[slot] = id; this.sel = slot;
    this.renderBar(); if (this.open) this.renderMenu(); this.onSave && this.onSave();
  }

  // ---------- lancement ----------
  cast(id) {
    const p = POWER_BY_ID[id]; if (!p) return false;
    if (!this.unlocked(id)) { this.ui.toast(`${p.name} se débloque au niveau mystique ${p.lvl}`, 2); return false; }
    if (this.player.inCar) { this.ui.toast('Descends du véhicule pour utiliser un pouvoir', 1.6); return false; }
    if ((this.cd[id] || 0) > 0) { this.ui.toast(`${p.name} : recharge encore ${Math.ceil(this.cd[id])} s`, 1.4); return false; }
    if (this.active[id]) { this.ui.toast(`${p.name} est déjà actif`, 1.2); return false; }
    const st = stats(p, this.rank(id));
    if (this.energy < st.cost) { this.ui.toast(`Énergie mystique insuffisante (${Math.floor(this.energy)}/${st.cost}) — elle se recharge, plus vite la nuit et près des pierres-portails`, 2.6); return false; }
    if (id === 'portail') { if (!this.portalsFound.size) { this.ui.toast('Aucune pierre-portail découverte : approche-toi d’une pierre pour la révéler', 2.4); return false; } this.openPortalChooser(); return true; }
    this.energy -= st.cost;
    this.cd[id] = st.cd;
    this.castT = 0.7;
    const a = { t: 0, dur: st.dur, rank: this.rank(id), st, objs: [] };
    this.active[id] = a;
    FX[id].start.call(this, a);
    this.sound(id);
    this.addXp(this.used.has(id) ? 4 : 25);
    this.used.add(id);
    this.renderBar();
    return true;
  }
  stop(id) {
    const a = this.active[id]; if (!a) return;
    if (FX[id].end) FX[id].end.call(this, a);
    for (const o of a.objs) { o.parent && o.parent.remove(o); o.traverse((m) => { if (m.userData.keepGeo) return; if (m.geometry) m.geometry.dispose(); if (m.material && m.material.dispose) m.material.dispose(); }); }
    delete this.active[id];
    this.renderBar();
  }

  // ---------- aides visuelles ----------
  add(a, o) { this.scene.add(o); a.objs.push(o); return o; }
  aura(a, c1, c2, rainbow = false, r = 0.62, h = 2.4) {
    const m = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.75, r, h, 28, 1, true), fxMat(auraFrag, { uC1: { value: new THREE.Color(c1) }, uC2: { value: new THREE.Color(c2) }, uRainbow: { value: rainbow ? 1 : 0 } }));
    m.userData.follow = h / 2; m.renderOrder = 3;
    return this.add(a, m);
  }
  shell(a, color, r, kind = 0) {
    const m = new THREE.Mesh(new THREE.SphereGeometry(r, 32, 18), fxMat(shellFrag, { uC1: { value: new THREE.Color(color) }, uKind: { value: kind } }));
    m.userData.follow = 0.9; m.renderOrder = 3;
    return this.add(a, m);
  }
  groundGlow(a, color, r) {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(r * 2, r * 2), new THREE.MeshBasicMaterial({ map: this.glowTex, color, transparent: true, opacity: 0.55, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false }));
    m.rotation.x = -Math.PI / 2; m.userData.follow = 0.05; m.userData.ground = true;
    return this.add(a, m);
  }
  glyphTexture(id) {
    if (!this.glyphTex[id]) { const t = new THREE.CanvasTexture(drawPowerIcon(POWER_BY_ID[id], 256, true)); t.colorSpace = THREE.SRGBColorSpace; this.glyphTex[id] = t; }
    return this.glyphTex[id];
  }
  groundSymbol(a, id, r = 1.6, follow = true) {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(r * 2, r * 2), new THREE.MeshBasicMaterial({ map: this.glyphTexture(id), transparent: true, opacity: 0.9, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false }));
    m.rotation.x = -Math.PI / 2; m.userData.spin = 0.6;
    if (follow) { m.userData.follow = 0.06; m.userData.ground = true; }
    return this.add(a, m);
  }
  ring(color, pos, radius, dur, width = 0.15) {
    const m = new THREE.Mesh(new THREE.RingGeometry(1 - width, 1, 64), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.9, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false }));
    m.rotation.x = -Math.PI / 2; m.position.copy(pos); this.scene.add(m);
    this.temp.push({ t: 0, dur, upd: (k) => { m.scale.setScalar(0.3 + k * radius); m.material.opacity = 0.9 * (1 - k); }, done: () => { this.scene.remove(m); m.geometry.dispose(); m.material.dispose(); } });
  }
  bolt(x, z, color = 0xbfe6ff, pushPeds = true) {
    const pts = []; const top = new THREE.Vector3(x + rnd(-3, 3), 26, z + rnd(-3, 3));
    for (let i = 0; i <= 12; i++) { const k = i / 12; pts.push(new THREE.Vector3(top.x + (x - top.x) * k + (i && i < 12 ? rnd(-0.9, 0.9) : 0), top.y * (1 - k), top.z + (z - top.z) * k + (i && i < 12 ? rnd(-0.9, 0.9) : 0))); }
    const g = new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts, false, 'catmullrom', 0.1), 40, 0.09, 4);
    const m = new THREE.Mesh(g, new THREE.MeshBasicMaterial({ color, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false }));
    this.scene.add(m);
    this.temp.push({ t: 0, dur: 0.4, upd: (k) => { m.material.opacity = (Math.random() < 0.7 ? 1 : 0.2) * (1 - k); }, done: () => { this.scene.remove(m); g.dispose(); m.material.dispose(); } });
    const p = new THREE.Vector3(x, 0.1, z);
    this.ring(color, p, 4, 0.6);
    this.particles.emit(26, p, () => ({ v: [rnd(-4, 4), rnd(1, 6), rnd(-4, 4)], c: C(0xdff4ff), life: rnd(0.3, 0.8), g: 9, drag: 1 }));
    this.env.weather.flash = Math.max(this.env.weather.flash, 0.8);
    if (this.audio && this.audio.ctx) this.audio.thunder(0.05 + Math.random() * 0.2);
    if (pushPeds) this.peds.push(x, z, 6, 2.5);
    this.repelWisps(x, z, 6);
  }

  // ---------- pierres-portails ----------
  findFree(x, z) {
    const col = this.world.collision;
    const free = (px, pz) => !col.pointBlocked(px, 0.5, pz) && [[1.6, 0], [-1.6, 0], [0, 1.6], [0, -1.6]].every(([dx, dz]) => !col.pointBlocked(px + dx, 0.5, pz + dz));
    for (let r = 0; r < 20; r += 1) for (let i = 0; i < Math.max(1, r * 6); i++) {
      const a = (i / Math.max(1, r * 6)) * Math.PI * 2, px = x + Math.cos(a) * r, pz = z + Math.sin(a) * r;
      if (free(px, pz) && pz < SEA_Z - 3) return { x: px, z: pz };
    }
    return { x, z };
  }
  buildPortals() {
    const w = this.world, A = w.amazone || { x: 0, z: 174 }, M = w.martyrs && w.martyrs.x != null ? w.martyrs : { x: 60, z: -60 };
    const defs = [
      ['maison', 'Pierre-portail de la Maison', HOME.marker.x - 7, HOME.marker.z - 3],
      ['amazone', 'Pierre-portail de l’Amazone', A.x + 16, A.z - 8],
      ['martyrs', 'Pierre-portail des Martyrs', M.x + 14, M.z + 4],
      ['dantokpa', 'Pierre-portail de Dantokpa', -50, 50],
      ['plage', 'Pierre-portail de la Plage', 45, SEA_Z - 9],
      ['carrefour', 'Pierre-portail du Carrefour', 18, -18],
      ['aeroport', 'Pierre-portail de l’Aéroport', -452, 78],
    ];
    const stone = new THREE.MeshStandardMaterial({ color: LATERITE, roughness: 0.95, flatShading: true });
    const gold = new THREE.MeshStandardMaterial({ color: GOLD, metalness: 0.7, roughness: 0.35, emissive: 0x5a3a00, emissiveIntensity: 0.4 });
    this.portals = defs.map(([id, name, x0, z0]) => {
      const { x, z } = this.findFree(x0, z0);
      const g = new THREE.Group(); g.position.set(x, 0, z);
      const base = new THREE.Mesh(new THREE.CylinderGeometry(1.15, 1.35, 0.35, 8), stone); base.position.y = 0.17; base.receiveShadow = base.castShadow = true;
      const ring = new THREE.Mesh(new THREE.TorusGeometry(1.0, 0.16, 8, 8), stone); ring.position.y = 1.55; ring.castShadow = true;
      const bands = new THREE.Mesh(new THREE.TorusGeometry(1.0, 0.18, 4, 8, Math.PI / 4), gold); bands.position.y = 1.55; bands.rotation.z = Math.PI * 0.375;
      const disc = new THREE.Mesh(new THREE.CircleGeometry(0.86, 32), fxMat(swirlFrag, { uC1: { value: new THREE.Color(0x40e0d0) } }, swirlVert)); disc.position.y = 1.55;
      const sym = new THREE.Mesh(new THREE.PlaneGeometry(1.8, 1.8), new THREE.MeshBasicMaterial({ map: this.glyphTexture('portail'), transparent: true, opacity: 0.8, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false }));
      sym.rotation.x = -Math.PI / 2; sym.position.y = 0.36;
      const pillar = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.9, 40, 16, 1, true), new THREE.MeshBasicMaterial({ color: 0x40e0d0, transparent: true, opacity: 0.12, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, toneMapped: false, fog: false }));
      pillar.position.y = 20;
      g.add(base, ring, bands, disc, sym, pillar);
      g.rotation.y = Math.atan2(-x, -z);
      this.scene.add(g);
      // obstacle pour le joueur et les véhicules
      w.collision.addCircle(x, z, 1.25, 1);
      return { id, name, x, z, g, disc, sym, pillar };
    });
  }

  // ---------- symboles cachés ----------
  buildGlyphSpots() {
    const src = [...(this.world.idleSpots || []), ...(this.world.plazaSpots || [])];
    let seed = 7; const R = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
    const spots = [];
    const pick = src.slice().sort(() => R() - 0.5);
    for (const s of pick) {
      if (spots.length >= 20) break;
      const x = s.x + (R() - 0.5) * 3, z = s.z + (R() - 0.5) * 3;
      if (this.world.collision.pointBlocked(x, 0.3, z) || z > SEA_Z - 3) continue;
      if (spots.some((o) => Math.hypot(o.x - x, o.z - z) < 14)) continue;
      spots.push({ x, z });
    }
    while (spots.length < 20) { const a = spots.length * 1.7, r = 30 + spots.length * 5; const f = this.findFree(Math.cos(a) * r, Math.sin(a) * r); spots.push(f); }
    this.glyphs = spots.map((s, i) => ({ id: 'g' + i, x: s.x, z: s.z, power: POWERS[i].id, mesh: null }));
  }
  glyphMesh(gl) {
    if (gl.mesh) return gl.mesh;
    const g = new THREE.Group();
    const tab = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.75, 0.14), new THREE.MeshStandardMaterial({ color: LATERITE, roughness: 1, flatShading: true }));
    tab.position.y = 0.4; tab.rotation.y = gl.x; tab.castShadow = true;
    const sym = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 0.9), new THREE.MeshBasicMaterial({ map: this.glyphTexture(gl.power), transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, toneMapped: false }));
    sym.position.y = 1.25;
    const pillar = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.4, 14, 12, 1, true), new THREE.MeshBasicMaterial({ color: 0x6ad0ff, transparent: true, opacity: 0.25, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, toneMapped: false, fog: false }));
    pillar.position.y = 7;
    g.add(tab, sym, pillar); g.position.set(gl.x, 0, gl.z); g.userData.sym = sym;
    this.scene.add(g); gl.mesh = g;
    return g;
  }

  // ---------- feux follets (créatures fantastiques inoffensives) ----------
  buildWisps() {
    const homes = this.portals.map((p) => [p.x, p.z]).concat([[0, 150], [-90, -40], [100, 80]]);
    this.wisps = [];
    for (let i = 0; i < 9; i++) {
      const [hx, hz] = homes[i % homes.length];
      const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: this.glowTex, color: i % 2 ? 0x7affd8 : 0xb8a0ff, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false, fog: false }));
      s.scale.setScalar(0.7);
      const core = new THREE.Sprite(new THREE.SpriteMaterial({ map: this.glowTex, color: 0xffffff, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false, fog: false }));
      core.scale.setScalar(0.25); s.add(core);
      this.scene.add(s);
      this.wisps.push({ s, hx: hx + rnd(-8, 8), hz: hz + rnd(-8, 8), x: hx, y: 1.4, z: hz, ph: Math.random() * 6, gone: 0, flee: 0, vx: 0, vy: 0, vz: 0 });
    }
    this.drainToast = 0;
  }
  repelWisps(x, z, r) {
    let n = 0;
    for (const w of this.wisps) {
      if (w.gone > 0 || w.flee > 0) continue;
      const dx = w.x - x, dz = w.z - z, d = Math.hypot(dx, dz);
      if (d > r) continue;
      w.flee = 1.6; w.vx = (dx / (d || 1)) * 9; w.vz = (dz / (d || 1)) * 9; w.vy = 5;
      n++;
    }
    if (n) { this.wispsRepelled += n; this.addXp(15 * n); this.ui.toast(`${n} feu${n > 1 ? 'x' : ''} follet${n > 1 ? 's' : ''} repoussé${n > 1 ? 's' : ''} (+${15 * n} XP)`, 1.8); }
    return n;
  }
  get repelling() { const A = this.active; return !!(A.feu || A.brume || A.bouclier || A.gardiens || A.lumiere || A.eveil || A.terre || A.colosse); }

  // ---------- sons (synthèse : cloche double, tambour parlant, hochet, souffle) ----------
  sound(kind) {
    const A = this.audio; if (!A || !A.ctx) return;
    const bell = (f, w = 0, v = 0.07) => { A.tone(f, 0.5, v, 'sine', undefined, w); A.tone(f * 2.76, 0.25, v * 0.4, 'sine', undefined, w); };
    const drum = (f, w = 0, v = 0.28) => A.tone(f * 1.7, 0.35, v, 'sine', undefined, w, f);
    const shk = (w = 0, v = 0.05) => A.burst(0.06, 'highpass', 6000, 0.7, v, undefined, w);
    const whoosh = (w = 0, v = 0.14, f = 700) => A.burst(0.8, 'bandpass', f, 0.6, v, undefined, w);
    const pad = (fs, w = 0, v = 0.04) => fs.forEach((f) => A.tone(f, 1.6, v, 'triangle', undefined, w));
    const gank = (w = 0) => [0, 0.17, 0.34, 0.42, 0.59, 0.76, 0.93].forEach((t, i) => bell(i === 3 || i === 0 ? 1280 : 1720, w + t, 0.05));
    switch (kind) {
      case 'feu': whoosh(0, 0.18, 400); drum(110); A.burst(1.2, 'lowpass', 900, 0.8, 0.08, undefined, 0.2); break;
      case 'eau': A.burst(1.4, 'lowpass', 700, 0.9, 0.2); A.tone(600, 0.8, 0.05, 'sine', undefined, 0.1, 200); break;
      case 'vent': whoosh(0, 0.2, 900); whoosh(0.25, 0.12, 1400); break;
      case 'terre': A.tone(55, 1.2, 0.3, 'sine', undefined, 0, 35); A.burst(1, 'lowpass', 180, 1, 0.3); break;
      case 'foudre': case 'danse': [0, 0.13, 0.26, 0.52, 0.65, 0.78].forEach((t, i) => drum(i % 3 ? 160 : 100, t)); shk(0.05); shk(0.39); break;
      case 'bouclier': gank(); pad([392, 523, 659], 0.1); break;
      case 'aura': pad([440, 554, 659], 0, 0.035); bell(1760, 0.1, 0.04); break;
      case 'regen': [523, 659, 784, 1046].forEach((f, i) => A.tone(f, 0.5, 0.04, 'sine', undefined, i * 0.12)); break;
      case 'fantome': A.tone(900, 0.35, 0.06, 'sine', undefined, 0, 200); whoosh(0.05, 0.08, 2000); break;
      case 'lumiere': pad([523, 659, 784, 1046], 0, 0.035); bell(2093, 0.2, 0.04); break;
      case 'vision': A.tone(300, 1.2, 0.05, 'sine', undefined, 0, 1200); shk(0.2); shk(0.4); break;
      case 'double': A.tone(700, 0.5, 0.05, 'triangle', undefined, 0, 1400); A.tone(1400, 0.5, 0.03, 'triangle', undefined, 0.06, 700); break;
      case 'brume': A.burst(2, 'bandpass', 500, 0.5, 0.12); pad([220, 277, 330], 0, 0.03); break;
      case 'ancetres': gank(); gank(1.02); pad([196, 247, 294, 392], 0.2, 0.04); break;
      case 'portail': A.tone(200, 1, 0.08, 'sine', undefined, 0, 1600); whoosh(0.3, 0.1, 1200); break;
      case 'colosse': A.tone(45, 1.5, 0.35, 'sine', undefined, 0, 30); drum(70, 0.3, 0.4); drum(70, 0.7, 0.4); break;
      case 'onde': A.tone(180, 0.9, 0.2, 'sine', undefined, 0, 40); whoosh(0, 0.2, 500); break;
      case 'gardiens': [0, 0.3, 0.6].forEach((t) => drum(80, t, 0.35)); gank(0.9); break;
      case 'eveil': gank(); [261, 329, 392, 523, 659].forEach((f, i) => A.tone(f, 1.4, 0.04, 'triangle', undefined, i * 0.1)); whoosh(0.2, 0.15, 900); break;
      case 'levelup': [523, 659, 784, 1046, 1318].forEach((f, i) => bell(f, i * 0.12, 0.06)); break;
      case 'upgrade': bell(1046, 0, 0.06); bell(1568, 0.1, 0.06); break;
      case 'glyph': bell(1318, 0, 0.07); bell(1760, 0.12, 0.06); shk(0.2); break;
      case 'discover': gank(); A.tone(300, 1.2, 0.06, 'sine', undefined, 0, 900); break;
    }
  }

  // ---------- mise à jour ----------
  blockers() {
    const out = [], P = this.player.pos, A = this.active;
    const r = A.eveil || A.bouclier ? 4 : A.terre || A.eau ? 3.2 : A.colosse ? 2.6 : 0;
    if (r) out.push({ x: P.x, z: P.z, r });
    if (A.double && A.double.ghost) out.push({ x: A.double.ghost.position.x, z: A.double.ghost.position.z, r: 0.6 });
    if (A.gardiens) for (const g of A.gardiens.guards || []) out.push({ x: g.position.x, z: g.position.z, r: 1.2 });
    return out;
  }

  update(dt, t, playing) {
    this.temp = this.temp || [];
    const P = this.player.pos, night = this.env.night;
    // énergie mystique : +1,5/s, double la nuit, triple près d'une pierre découverte
    let regen = 1.5 * (1 + night);
    let nearPortal = null;
    for (const p of this.portals) {
      const d = Math.hypot(p.x - P.x, p.z - P.z);
      p.g.visible = d < 170;
      const found = this.portalsFound.has(p.id);
      p.disc.visible = found; p.disc.material.uniforms.uTime.value = t;
      p.pillar.material.opacity = (found ? 0.1 : 0.04) * (0.4 + night) + (this.active.vision ? 0.15 : 0);
      p.sym.rotation.z = t * 0.2;
      if (d < 6 && found) { regen *= 3; nearPortal = p; }
      if (playing && !found && d < 4.5) {
        this.portalsFound.add(p.id); this.sound('discover');
        this.ui.toast(`✧ ${p.name} découverte ! (+80 XP) — le pouvoir Portail Mystique peut t’y ramener`, 3.5);
        this.particles.emit(50, new THREE.Vector3(p.x, 1.5, p.z), () => ({ v: [rnd(-3, 3), rnd(1, 5), rnd(-3, 3)], c: C(0x40e0d0), life: rnd(0.8, 1.6), g: 2, drag: 1 }));
        this.addXp(80); this.onSave && this.onSave();
      }
    }
    this.nearPortal = nearPortal;
    if (playing) this.energy = Math.min(this.maxEnergy, this.energy + regen * dt);
    for (const id in this.cd) { this.cd[id] -= dt; if (this.cd[id] <= 0) delete this.cd[id]; }

    // effets actifs
    const mods = { speed: 1, jump: 1, grav: 1, lock: false, frozen: false, lift: 0 };
    for (const id of Object.keys(this.active)) {
      const a = this.active[id];
      a.t += dt;
      const k = Math.min(1, a.t / a.dur), fade = Math.min(1, a.t * 4, (a.dur - a.t) * 2.5);
      for (const o of a.objs) {
        if (o.userData.follow != null) o.position.set(P.x, (o.userData.ground ? 0 : this.player.mesh.position.y) + o.userData.follow, P.z);
        if (o.userData.spin) o.rotation.z += o.userData.spin * dt;
        const mats = o.material ? [o.material] : [];
        for (const m of mats) { if (m.uniforms && m.uniforms.uTime) { m.uniforms.uTime.value = t; m.uniforms.uI.value = Math.max(0, fade); } else if (m.userData.base == null) m.userData.base = m.opacity; else m.opacity = m.userData.base * Math.max(0, fade); }
      }
      FX[id].update && FX[id].update.call(this, a, dt, k, t, mods);
      if (a.t >= a.dur) this.stop(id);
    }
    this.player.speedMul = mods.speed; this.player.jumpMul = mods.jump; this.player.gravMul = mods.grav;
    this.player.staminaLock = mods.lock; this.player.frozen = mods.frozen;
    if (mods.lift) this.player.mesh.position.y += mods.lift;
    document.body.classList.toggle('vision', !!this.active.vision);

    // geste de lancement (bras levés)
    const ch = this.player.char, b = ch && ch.bones;
    if (this.castT > 0 && b && b.armL && !this.active.danse) {
      this.castT -= dt; const u = Math.sin(Math.max(0, this.castT / 0.7) * Math.PI);
      b.armL.rotation.x = b.armL.rotation.x * (1 - u) - 1.2 * u; b.armR.rotation.x = b.armR.rotation.x * (1 - u) - 1.2 * u;
      b.armL.rotation.z += 0.5 * u; b.armR.rotation.z -= 0.5 * u;
    }

    // feux follets
    const wantPlayer = !this.repelling && playing && !this.player.inCar;
    const vis = this.active.vision ? 1 : 0.35 + night * 0.65;
    for (const w of this.wisps) {
      if (w.gone > 0) { w.gone -= dt; w.s.visible = false; if (w.gone <= 0) { w.x = w.hx; w.z = w.hz; w.y = 1.4; } continue; }
      const d = Math.hypot(P.x - w.x, P.z - w.z);
      w.s.visible = d < 120;
      if (!w.s.visible) continue;
      w.ph += dt;
      if (w.flee > 0) {
        w.flee -= dt; w.x += w.vx * dt; w.y += w.vy * dt; w.z += w.vz * dt;
        w.s.material.opacity = Math.max(0, w.flee / 1.6);
        if (w.flee <= 0) w.gone = 90;
      } else {
        let tx = w.hx + Math.cos(w.ph * 0.4) * 5, tz = w.hz + Math.sin(w.ph * 0.33) * 5, sp = 1.5;
        if (wantPlayer && d < 15) { tx = P.x + Math.cos(w.ph * 2) * 0.6; tz = P.z + Math.sin(w.ph * 2) * 0.6; sp = 2.6; }
        const dx = tx - w.x, dz = tz - w.z, dd = Math.hypot(dx, dz) || 1;
        w.x += (dx / dd) * Math.min(dd, sp * dt); w.z += (dz / dd) * Math.min(dd, sp * dt);
        w.y = 1.3 + Math.sin(w.ph * 2.3) * 0.35;
        w.s.material.opacity = vis * (0.75 + Math.sin(w.ph * 9) * 0.25);
        if (wantPlayer && d < 1.1) {
          this.energy = Math.max(0, this.energy - 4 * dt);
          this.drainToast -= dt;
          if (this.drainToast <= 0) { this.drainToast = 12; this.ui.toast('Un feu follet taquin aspire ton énergie mystique ! (Feu, Lumière Protectrice, Onde… le repoussent)', 3); }
        }
        if (this.active.feu && d < 3) this.repelWisps(P.x, P.z, 3);
        if (Math.random() < dt * 6) this.particles.emit(1, new THREE.Vector3(w.x, w.y, w.z), () => ({ v: [rnd(-0.2, 0.2), rnd(-0.1, 0.3), rnd(-0.2, 0.2)], c: C(0x7affd8), life: 0.8, g: 0, drag: 1 }));
      }
      w.s.position.set(w.x, w.y, w.z);
      w.s.scale.setScalar(this.active.vision ? 1.1 : 0.7);
    }

    // symboles cachés : visibles et récoltables uniquement avec la Vision des Esprits
    const seeing = !!this.active.vision;
    for (const gl of this.glyphs) {
      if (this.glyphsFound.has(gl.id)) { if (gl.mesh) gl.mesh.visible = false; continue; }
      const d = Math.hypot(gl.x - P.x, gl.z - P.z);
      const show = seeing && d < 70;
      if (show) { const m = this.glyphMesh(gl); m.visible = true; m.userData.sym.rotation.y = t * 1.5; m.userData.sym.position.y = 1.25 + Math.sin(t * 2) * 0.08; }
      else if (gl.mesh) gl.mesh.visible = false;
      if (show && d < 1.9 && playing) {
        this.glyphsFound.add(gl.id); this.energy = Math.min(this.maxEnergy, this.energy + 20); this.sound('glyph');
        this.particles.emit(40, new THREE.Vector3(gl.x, 1.2, gl.z), () => ({ v: [rnd(-2, 2), rnd(1, 4), rnd(-2, 2)], c: C(0x6ad0ff), life: rnd(0.6, 1.4), g: 3, drag: 1 }));
        this.ui.toast(`Symbole caché recueilli (${this.glyphsFound.size}/20) : +60 XP, +20 énergie mystique`, 2.5);
        this.addXp(60); this.onSave && this.onSave();
      }
    }

    // effets temporaires
    for (let i = this.temp.length - 1; i >= 0; i--) {
      const f = this.temp[i]; f.t += dt; const k = Math.min(1, f.t / f.dur); f.upd(k, f.t);
      if (k >= 1) { f.done(); this.temp.splice(i, 1); }
    }
    this.particles.update(dt);
    this.dom.bar.style.display = this.player.inCar ? 'none' : '';
    this._barT = (this._barT || 0) - dt;
    if (this._barT <= 0) { this._barT = 0.1; this.updateBar(); }
  }

  // ---------- portails ----------
  openPortalChooser() {
    this.portalOpen = true;
    const el = this.dom.portal, P = this.player.pos;
    const list = this.portals.filter((p) => this.portalsFound.has(p.id));
    el.innerHTML = `<div class="pw-pbox"><h3>PORTAIL MYSTIQUE</h3><p>Choisis une pierre-portail découverte (${list.length}/${this.portals.length})</p>
      ${list.map((p, i) => `<button data-p="${p.id}"><b>${i + 1}</b>${p.name}<small>${Math.round(Math.hypot(p.x - P.x, p.z - P.z))} m</small></button>`).join('')}
      <button class="pw-pclose">Annuler (Échap)</button></div>`;
    el.classList.add('show');
    el.querySelectorAll('[data-p]').forEach((b) => b.addEventListener('click', (e) => { e.stopPropagation(); this.teleportTo(b.dataset.p); }));
    el.querySelector('.pw-pclose').addEventListener('click', (e) => { e.stopPropagation(); this.closePortal(); });
  }
  closePortal() { this.portalOpen = false; this.dom.portal.classList.remove('show'); }
  teleportTo(pid) {
    const p = this.portals.find((x) => x.id === pid); if (!p) return;
    this.closePortal();
    const st = stats(POWER_BY_ID.portail, this.rank('portail'));
    this.energy -= st.cost; this.cd.portail = st.cd; this.sound('portail');
    this.addXp(this.used.has('portail') ? 4 : 25); this.used.add('portail');
    const from = this.player.pos.clone();
    this.particles.emit(60, from.clone().setY(1), () => ({ v: [rnd(-1, 1), rnd(1, 5), rnd(-1, 1)], c: C(0x40e0d0), life: rnd(0.6, 1.4), g: -1, drag: 1 }));
    this.ui.fade(true);
    setTimeout(() => {
      const ang = Math.atan2(-p.x, -p.z);
      this.player.pos.set(p.x + Math.sin(ang) * 2.6, 0, p.z + Math.cos(ang) * 2.6);
      this.player.facing = ang;
      this.ui.fade(false);
      this.ring(0x40e0d0, new THREE.Vector3(this.player.pos.x, 0.1, this.player.pos.z), 6, 1);
      this.ui.toast(`Arrivée : ${p.name}`, 2);
      this.renderBar();
    }, 650);
  }

  // ---------- interface : barre de raccourcis + menu ----------
  buildDom() {
    const $ = (s) => document.querySelector(s);
    this.dom = { bar: $('#pw-bar'), menu: $('#pw'), portal: $('#pw-portal'), mys: $('#need-mystic'), lvl: $('#mys-lvl') };
    this.dom.bar.innerHTML = Array.from({ length: SLOTS_N }, (_, i) => `<button class="pw-s" data-slot="${i}"><img alt=""><i class="pw-cd"></i><b>${i + 1}</b></button>`).join('');
    this.dom.bar.querySelectorAll('.pw-s').forEach((b) => b.addEventListener('click', (e) => {
      e.stopPropagation(); const i = +b.dataset.slot; this.sel = i;
      if (this.slots[i]) this.cast(this.slots[i]); else this.toggleMenu(true);
      this.renderBar();
    }));
    const m = this.dom.menu;
    m.innerHTML = `<div class="pw-box">
      <div class="pw-head"><h2>POUVOIRS MYSTIQUES</h2>
        <div class="pw-prog"><span class="pw-lv"></span><div class="pw-xp"><i></i></div><span class="pw-xpt"></span></div>
        <div class="pw-en"><span>ÉNERGIE MYSTIQUE</span><div class="pw-enb"><i></i></div><span class="pw-ent"></span></div>
        <button class="pw-x" title="Fermer (U)">✕</button></div>
      <div class="pw-tabs"><button data-pc="all">Tous</button>${PCATS.map((c) => `<button data-pc="${c.id}" style="--cc:${c.color}">${c.short}</button>`).join('')}<span class="pw-pts"></span></div>
      <div class="pw-main"><div class="pw-grid"></div>
        <div class="pw-detail"><div class="pw-top"><img class="pw-big" alt=""><div><div class="pw-name"></div><div class="pw-cat"></div></div></div><p class="pw-desc"></p>
          <div class="pw-stats"></div><div class="pw-rank"></div>
          <div class="pw-actions"><button class="pw-up"></button><button class="pw-cast">LANCER</button></div>
          <div class="pw-assign"><span>Raccourci :</span>${Array.from({ length: SLOTS_N }, (_, i) => `<button data-as="${i}">${i + 1}</button>`).join('')}</div></div></div>
      <div class="pw-foot"><span class="pw-found"></span><span>Univers fantastique : ces pouvoirs et symboles sont imaginaires, inspirés des couleurs, motifs et paysages du Bénin. Ils ne représentent pas des divinités, rites ou cérémonies du Vodun, religion vivante que le jeu respecte.</span></div>
    </div>`;
    m.querySelector('.pw-x').addEventListener('click', (e) => { e.stopPropagation(); this.toggleMenu(false); });
    m.querySelectorAll('[data-pc]').forEach((b) => b.addEventListener('click', (e) => { e.stopPropagation(); this.menuCat = b.dataset.pc; this.renderMenu(); }));
    m.querySelector('.pw-grid').addEventListener('click', (e) => { const c = e.target.closest('[data-pw]'); if (!c) return; e.stopPropagation(); this.menuSel = c.dataset.pw; this.renderMenu(); });
    m.querySelector('.pw-up').addEventListener('click', (e) => { e.stopPropagation(); this.upgrade(this.menuSel); });
    m.querySelector('.pw-cast').addEventListener('click', (e) => { e.stopPropagation(); const id = this.menuSel; this.toggleMenu(false); this.cast(id); });
    m.querySelectorAll('[data-as]').forEach((b) => b.addEventListener('click', (e) => { e.stopPropagation(); this.assign(this.menuSel, +b.dataset.as); }));
  }
  toggleMenu(on = !this.open) {
    this.open = on; this.dom.menu.classList.toggle('show', on);
    if (on) this.renderMenu(); else this.onSave && this.onSave();
  }
  renderBar() {
    this.dom.bar.querySelectorAll('.pw-s').forEach((b, i) => {
      const id = this.slots[i], img = b.querySelector('img');
      img.src = id ? this.icons[id] : ''; img.style.visibility = id ? 'visible' : 'hidden';
      b.classList.toggle('sel', i === this.sel); b.classList.toggle('empty', !id);
      b.title = id ? `${POWER_BY_ID[id].name} (${i + 1})` : 'Vide — ouvre le menu des pouvoirs (U)';
    });
    this.updateBar();
  }
  updateBar() {
    this.dom.bar.querySelectorAll('.pw-s').forEach((b, i) => {
      const id = this.slots[i]; if (!id) return;
      const st = stats(POWER_BY_ID[id], this.rank(id)), cd = this.cd[id] || 0;
      b.style.setProperty('--cd', cd > 0 ? (cd / st.cd * 360).toFixed(0) + 'deg' : '0deg');
      b.classList.toggle('act', !!this.active[id]); b.classList.toggle('low', this.energy < st.cost);
    });
    const mx = this.maxEnergy;
    if (this.dom.mys) { this.dom.mys.querySelector('i').style.width = (this.energy / mx * 100).toFixed(0) + '%'; }
    if (this.dom.lvl) this.dom.lvl.textContent = 'MYSTIQUE ' + this.level;
    if (this.open) {
      const m = this.dom.menu; m.querySelector('.pw-enb i').style.width = (this.energy / mx * 100).toFixed(0) + '%'; m.querySelector('.pw-ent').textContent = `${Math.floor(this.energy)} / ${mx}`;
    }
  }
  renderMenu() {
    const m = this.dom.menu, L = this.level;
    const lo = XP_LEVELS[L - 1], hi = XP_LEVELS[L] ?? XP_LEVELS[L - 1];
    m.querySelector('.pw-lv').textContent = `Niveau ${L}`;
    m.querySelector('.pw-xp i').style.width = (hi > lo ? ((this.xp - lo) / (hi - lo)) * 100 : 100).toFixed(0) + '%';
    m.querySelector('.pw-xpt').textContent = hi > lo ? `${this.xp - lo} / ${hi - lo} XP` : `${this.xp} XP (max)`;
    m.querySelector('.pw-pts').textContent = `Points d’amélioration : ${this.points}`;
    m.querySelector('.pw-found').textContent = `Symboles cachés ${this.glyphsFound.size}/20 • Pierres-portails ${this.portalsFound.size}/${this.portals.length} • Feux follets repoussés ${this.wispsRepelled}`;
    m.querySelectorAll('[data-pc]').forEach((b) => b.classList.toggle('on', b.dataset.pc === this.menuCat));
    const list = POWERS.filter((p) => this.menuCat === 'all' || p.cat === this.menuCat);
    if (!list.some((p) => p.id === this.menuSel)) this.menuSel = list[0].id;
    m.querySelector('.pw-grid').innerHTML = list.map((p) => {
      const un = this.unlocked(p.id), r = this.rank(p.id), slot = this.slots.indexOf(p.id);
      return `<button class="pw-card${p.id === this.menuSel ? ' sel' : ''}${un ? '' : ' locked'}" data-pw="${p.id}" style="--cc:${PCATS.find((c) => c.id === p.cat).color}">
        <img src="${this.icons[p.id]}" alt="">${slot >= 0 ? `<i class="pw-key">${slot + 1}</i>` : ''}${un ? '' : `<i class="pw-lock">🔒 Niv. ${p.lvl}</i>`}
        <b>${p.name}</b><span class="pips">${'●'.repeat(r)}${'○'.repeat(MAX_RANK - r)}</span></button>`;
    }).join('');
    const p = POWER_BY_ID[this.menuSel], un = this.unlocked(p.id), r = this.rank(p.id), st = stats(p, r), nx = r < MAX_RANK ? stats(p, r + 1) : null;
    const cat = PCATS.find((c) => c.id === p.cat);
    m.querySelector('.pw-detail').style.setProperty('--cc', cat.color);
    m.querySelector('.pw-big').src = this.icons[p.id];
    m.querySelector('.pw-name').textContent = p.name;
    m.querySelector('.pw-cat').textContent = cat.label.toUpperCase() + (un ? '' : ` • se débloque au niveau ${p.lvl}`);
    m.querySelector('.pw-desc').textContent = p.desc;
    const row = (k, v, n) => `<div><span>${k}</span><b>${v}${n != null && n !== v ? ` <em>→ ${n}</em>` : ''}</b></div>`;
    m.querySelector('.pw-stats').innerHTML = row('Durée', st.dur < 1.5 ? 'instantané' : st.dur + ' s', nx && st.dur >= 1.5 ? nx.dur + ' s' : null)
      + row('Recharge', st.cd + ' s', nx ? nx.cd + ' s' : null) + row('Puissance', '◆'.repeat(st.pow) + '◇'.repeat(5 - st.pow), nx ? '◆'.repeat(nx.pow) + '◇'.repeat(5 - nx.pow) : null) + row('Énergie mystique', st.cost);
    m.querySelector('.pw-rank').textContent = `Rang ${r} / ${MAX_RANK}`;
    const up = m.querySelector('.pw-up');
    up.textContent = r >= MAX_RANK ? 'RANG MAX' : 'AMÉLIORER ✦1';
    up.disabled = !un || r >= MAX_RANK || this.points <= 0;
    m.querySelector('.pw-cast').disabled = !un;
    m.querySelectorAll('[data-as]').forEach((b) => { b.disabled = !un; b.classList.toggle('on', this.slots[+b.dataset.as] === p.id); });
    this.updateBar();
  }
  handleKeys(input) {
    if (this.portalOpen) {
      if (input.hit('Escape')) { this.closePortal(); return; }
      const list = this.portals.filter((p) => this.portalsFound.has(p.id));
      for (let i = 0; i < list.length; i++) if (input.hit('Digit' + (i + 1)) || input.hit('Numpad' + (i + 1))) { this.teleportTo(list[i].id); return; }
      return;
    }
    if (input.hit('Escape') || input.hit('KeyU')) { this.toggleMenu(false); return; }
    const list = POWERS.filter((p) => this.menuCat === 'all' || p.cat === this.menuCat);
    let i = list.findIndex((p) => p.id === this.menuSel);
    const cols = Math.max(1, Math.round(this.dom.menu.querySelector('.pw-grid').clientWidth / 112));
    if (input.hit('ArrowRight') || input.hit('KeyD')) i++;
    if (input.hit('ArrowLeft') || input.hit('KeyA') || input.hit('KeyQ')) i--;
    if (input.hit('ArrowDown') || input.hit('KeyS')) i += cols;
    if (input.hit('ArrowUp') || input.hit('KeyW') || input.hit('KeyZ')) i -= cols;
    i = Math.max(0, Math.min(list.length - 1, i));
    if (list[i].id !== this.menuSel) { this.menuSel = list[i].id; this.renderMenu(); }
    for (let s = 0; s < SLOTS_N; s++) if (input.hit('Digit' + (s + 1)) || input.hit('Numpad' + (s + 1))) this.assign(this.menuSel, s);
    if (input.hit('Enter')) { const id = this.menuSel; this.toggleMenu(false); this.cast(id); }
    if (input.hit('KeyE')) this.upgrade(this.menuSel);
    if (input.hit('Tab')) { const cats = ['all', ...PCATS.map((c) => c.id)]; this.menuCat = cats[(cats.indexOf(this.menuCat) + 1) % cats.length]; this.renderMenu(); }
  }
  // raccourcis en jeu : 1 à 5 lancent, R sélectionne le suivant, X lance le pouvoir sélectionné
  handleGameKeys(input) {
    for (let s = 0; s < SLOTS_N; s++) if (input.hit('Digit' + (s + 1)) || input.hit('Numpad' + (s + 1))) { this.sel = s; if (this.slots[s]) this.cast(this.slots[s]); this.renderBar(); }
    if (input.hit('KeyR')) {
      for (let k = 1; k <= SLOTS_N; k++) { const n = (this.sel + k) % SLOTS_N; if (this.slots[n]) { this.sel = n; break; } }
      this.renderBar(); const id = this.slots[this.sel]; if (id) this.ui.toast(`Pouvoir sélectionné : ${POWER_BY_ID[id].name} (X pour lancer)`, 1.4);
    }
    if (input.hit('KeyX') && this.slots[this.sel]) this.cast(this.slots[this.sel]);
  }

  serialize() {
    return { xp: this.xp, spent: this.spent, ranks: { ...this.ranks }, slots: [...this.slots], sel: this.sel, energy: Math.round(this.energy),
      glyphs: [...this.glyphsFound], portals: [...this.portalsFound], used: [...this.used], wisps: this.wispsRepelled };
  }
  restore(s) {
    if (!s) return;
    this.xp = s.xp || 0; this.spent = s.spent || 0;
    this.ranks = Object.fromEntries(Object.entries(s.ranks || {}).filter(([k, v]) => POWER_BY_ID[k] && v >= 1 && v <= MAX_RANK));
    if (Array.isArray(s.slots)) this.slots = Array.from({ length: SLOTS_N }, (_, i) => (POWER_BY_ID[s.slots[i]] ? s.slots[i] : null));
    this.sel = s.sel || 0; this.energy = Math.min(this.maxEnergy, s.energy ?? 100);
    this.glyphsFound = new Set(s.glyphs || []); this.portalsFound = new Set(s.portals || []); this.used = new Set(s.used || []); this.wispsRepelled = s.wisps || 0;
    this.renderBar();
  }
}

// ---------- les 20 effets ----------
const rock = () => new THREE.MeshStandardMaterial({ color: LATERITE, roughness: 1, flatShading: true });
function ghostMat(color, op = 0.45) { return new THREE.MeshBasicMaterial({ color, transparent: true, opacity: op, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false }); }
function rocksRing(self, a, n, r, size) {
  const mat = rock(); a.rocks = [];
  for (let i = 0; i < n; i++) { const m = new THREE.Mesh(new THREE.DodecahedronGeometry(size * rnd(0.8, 1.2), 0), mat); m.castShadow = true; m.userData.a = (i / n) * Math.PI * 2; m.userData.r = r; self.add(a, m); a.rocks.push(m); }
}
function updRocks(self, a, k, t, rise = true) {
  const P = self.player.pos, up = rise ? Math.min(1, a.t * 2) * Math.min(1, (a.dur - a.t) * 2) : 1;
  for (const m of a.rocks) { const ang = m.userData.a + t * 0.8; m.position.set(P.x + Math.cos(ang) * m.userData.r, -0.6 + up * (1.0 + Math.sin(t * 2 + m.userData.a * 3) * 0.15), P.z + Math.sin(ang) * m.userData.r); m.rotation.x += 0.01; m.rotation.y += 0.02; }
}
function buildGuardian() {
  const g = new THREE.Group(), st = rock();
  const gold = new THREE.MeshBasicMaterial({ color: GOLD, toneMapped: false });
  const base = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.5, 0.25, 6), st); base.position.y = 0.12;
  const body = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.46, 1.3, 4), st); body.position.y = 0.9; body.rotation.y = Math.PI / 4;
  const band = new THREE.Mesh(new THREE.CylinderGeometry(0.37, 0.4, 0.12, 4), gold); band.position.y = 1.2; band.rotation.y = Math.PI / 4;
  const band2 = band.clone(); band2.position.y = 0.6; band2.scale.set(1.12, 1, 1.12);
  const head = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.5, 0.5), st); head.position.y = 1.85;
  const eyes = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.06, 0.02), gold); eyes.position.set(0, 1.9, 0.26);
  const crest = new THREE.Mesh(new THREE.ConeGeometry(0.2, 0.4, 4), gold); crest.position.y = 2.3;
  for (const m of [base, body, head]) m.castShadow = true;
  g.add(base, body, band, band2, head, eyes, crest);
  return g;
}
function setCharMaterial(self, mat) {
  const store = [];
  self.player.char.group.traverse((o) => { if (o.isMesh) { store.push([o, o.material]); o.material = mat; } });
  return store;
}

const FX = {
  feu: {
    start(a) { this.aura(a, 0xff3a00, 0xffd040); this.groundGlow(a, 0xff7a1a, 3.2); this.groundSymbol(a, 'feu', 1.3); },
    update(a, dt) { if (Math.random() < dt * 40) this.particles.emit(2, this.player.pos.clone().setY(rnd(0.2, 1.6)), () => ({ ox: rnd(-0.45, 0.45), oz: rnd(-0.45, 0.45), v: [rnd(-0.2, 0.2), rnd(1.2, 2.6), rnd(-0.2, 0.2)], c: C(Math.random() < 0.5 ? 0xff9a2a : 0xffd060), life: rnd(0.4, 0.9), g: -0.5, drag: 1 })); },
  },
  eau: {
    start(a) {
      const P = this.player.pos;
      this.particles.emit(140, P.clone().setY(0.4), (k) => { const ang = (k / 140) * Math.PI * 2; return { v: [Math.cos(ang) * 7, rnd(2, 4), Math.sin(ang) * 7], c: C(Math.random() < 0.6 ? 0x5ac8ff : 0xd8f4ff), life: rnd(0.8, 1.3), g: 9, drag: 0.6 }; });
      this.ring(0x5ac8ff, P.clone().setY(0.1), 9 + a.st.pow, 1.1, 0.25);
      this.peds.push(P.x, P.z, 9, 3);
      this.shell(a, 0x3aa8ff, 1.35, 1);
    },
    update(a, dt) { if (Math.random() < dt * 12) this.particles.emit(1, this.player.pos.clone().setY(rnd(0.3, 2)), () => ({ ox: rnd(-1.2, 1.2), oz: rnd(-1.2, 1.2), v: [0, -1, 0], c: C(0x9fdcff), life: 0.6, g: 3 })); },
  },
  vent: {
    start(a) { this.groundSymbol(a, 'vent', 1.2); },
    update(a, dt, k, t, mods) {
      const r = a.rank; mods.speed = Math.max(mods.speed, 1.6 + 0.1 * (r - 1)); mods.jump = Math.max(mods.jump, 1.55); mods.grav = Math.min(mods.grav, 0.55);
      if (Math.random() < dt * 30) { const P = this.player.pos, ang = Math.random() * 6.28; this.particles.emit(1, P.clone().setY(rnd(0.2, 1.8)), () => ({ ox: Math.cos(ang) * 0.9, oz: Math.sin(ang) * 0.9, v: [-Math.sin(ang) * 4, rnd(0, 0.6), Math.cos(ang) * 4], c: C(0xe0f6ff), life: 0.5, g: 0, drag: 0.5 })); }
    },
  },
  terre: {
    start(a) { rocksRing(this, a, 8 + a.rank, 1.7, 0.42); this.groundSymbol(a, 'terre', 1.6); this.ring(0xb0582e, this.player.pos.clone().setY(0.1), 4, 0.6); },
    update(a, dt, k, t, mods) { updRocks(this, a, k, t); mods.lock = true; },
  },
  foudre: {
    start(a) { a.next = 0; a.n = 0; a.count = 4 + a.st.pow; },
    update(a) {
      if (a.n < a.count && a.t >= a.next) { const P = this.player.pos, ang = Math.random() * 6.28, r = rnd(3, 10); this.bolt(P.x + Math.cos(ang) * r, P.z + Math.sin(ang) * r); a.n++; a.next = a.t + a.dur / (a.count + 1); }
    },
  },
  bouclier: {
    start(a) { this.shell(a, 0x3fe0a0, 1.5, 0); this.groundSymbol(a, 'bouclier', 1.7); },
    update(a, dt) { const P = this.player.pos; this.peds.push(P.x, P.z, 4.2, 6 * dt); },
  },
  aura: {
    start(a) { this.aura(a, 0xffc040, 0xfff0b0); this.groundSymbol(a, 'aura', 1.5); this.groundGlow(a, 0xffd75a, 2.6); },
    update(a, dt, k, t, mods) { mods.lock = true; if (Math.random() < dt * 14) this.particles.emit(1, this.player.pos.clone().setY(rnd(0.3, 2)), () => ({ ox: rnd(-0.6, 0.6), oz: rnd(-0.6, 0.6), v: [0, rnd(0.4, 1), 0], c: C(0xffe08a), life: 1.2, g: -0.2 })); },
  },
  regen: {
    start(a) { this.groundSymbol(a, 'regen', 1.3); },
    update(a, dt, k, t) {
      this.needs.energy = Math.min(100, this.needs.energy + 1.2 * dt);
      const P = this.player.pos;
      for (let i = 0; i < 2; i++) { const ang = t * 4 + i * Math.PI, y = ((t * 0.9 + i * 0.5) % 1) * 2.2; if (Math.random() < 0.7) this.particles.emit(1, new THREE.Vector3(P.x + Math.cos(ang) * 0.7, y, P.z + Math.sin(ang) * 0.7), () => ({ v: [0, 0.4, 0], c: C(0x7aff8a), life: 0.7, g: 0 })); }
    },
  },
  fantome: {
    start(a) {
      const P = this.player.pos, f = this.player.facing, dx = Math.sin(f), dz = Math.cos(f), max = 8 + (a.rank - 1) * 2, col = this.world.collision;
      let best = 0;
      for (let d = 0.3; d <= max; d += 0.3) {
        const x = P.x + dx * d, z = P.z + dz * d;
        if (col.pointBlocked(x, 0.5, z) || col.pointBlocked(x + dz * 0.35, 0.5, z - dx * 0.35) || col.pointBlocked(x - dz * 0.35, 0.5, z + dx * 0.35)) break;
        if (x < BOUNDS.minX || x > BOUNDS.maxX || z < BOUNDS.minZ || isWater(x, z)) break;
        best = d;
      }
      const from = P.clone();
      const ghost = skClone(this.player.char.group); ghost.traverse((o) => { if (o.isMesh) o.material = ghostMat(0xb090ff, 0.5); });
      ghost.position.copy(this.player.mesh.position); ghost.rotation.copy(this.player.mesh.rotation); this.add(a, ghost);
      ghost.traverse((o) => { o.userData.keepGeo = true; });
      a.ghost = ghost;
      P.x += dx * best; P.z += dz * best;
      for (const p of [from, P]) this.particles.emit(40, p.clone().setY(1), () => ({ v: [rnd(-1.5, 1.5), rnd(-0.5, 2), rnd(-1.5, 1.5)], c: C(0xc0a8ff), life: rnd(0.4, 0.9), g: 0, drag: 2 }));
      if (best < 0.5) this.ui.toast('Pas Fantôme : un obstacle bloque le passage', 1.2);
    },
    update(a) { if (a.ghost) a.ghost.traverse((o) => { if (o.isMesh) o.material.opacity = 0.5 * (1 - a.t / a.dur); }); },
  },
  lumiere: {
    start(a) {
      const P = this.player.pos;
      a.sphere = this.shell(a, 0xfff4c0, 1, 0); a.sphere.userData.follow = 1;
      this.groundGlow(a, 0xfff0c0, 6); this.groundSymbol(a, 'lumiere', 2.2);
      this.repelWisps(P.x, P.z, 20 + (a.rank - 1) * 5);
    },
    update(a, dt, k) { const s = 1 + Math.min(1, a.t * 1.5) * 4; a.sphere.scale.setScalar(s); if (Math.random() < dt * 3) { const P = this.player.pos; this.repelWisps(P.x, P.z, 20); } },
  },
  vision: {
    start(a) { this.groundSymbol(a, 'vision', 1.4); this.ring(0x6ad0ff, this.player.pos.clone().setY(0.1), 70, 2.2, 0.03); },
  },
  double: {
    start(a) {
      const ghost = skClone(this.player.char.group);
      ghost.traverse((o) => { o.userData.keepGeo = true; if (o.isMesh) { o.material = ghostMat(0xb070ff, 0.55); o.frustumCulled = false; } });
      this.add(a, ghost); a.ghost = ghost;
      a.pairs = []; const src = {}; this.player.char.group.traverse((o) => { if (o.isBone) src[o.name] = o; });
      ghost.traverse((o) => { if (o.isBone && src[o.name]) a.pairs.push([src[o.name], o]); });
      this.particles.emit(40, this.player.pos.clone().setY(1), () => ({ v: [rnd(-2, 2), rnd(0, 2), rnd(-2, 2)], c: C(0xb070ff), life: 0.8, g: 0, drag: 2 }));
    },
    update(a, dt, k) {
      const P = this.player.pos, f = this.player.facing, side = 1.5;
      a.ghost.position.set(P.x + Math.cos(f) * side, this.player.mesh.position.y, P.z - Math.sin(f) * side);
      a.ghost.rotation.y = f;
      for (const [s, d] of a.pairs) { d.rotation.copy(s.rotation); d.position.copy(s.position); }
      const fade = Math.min(1, a.t * 3, (a.dur - a.t) * 2);
      a.ghost.traverse((o) => { if (o.isMesh) o.material.opacity = 0.55 * fade * (0.8 + Math.sin(a.t * 12) * 0.2); });
    },
  },
  brume: {
    start(a) { this.groundSymbol(a, 'brume', 1.4); },
    update(a, dt) {
      const f = this.scene.fog, k = Math.min(1, a.t * 0.8, (a.dur - a.t) * 0.8), day = 1 - this.env.night;
      f.near = f.near + (2 - f.near) * k; f.far = f.far + (38 + 10 * a.rank - f.far) * k;
      f.color.lerp(new THREE.Color(0.42 * day + 0.08, 0.34 * day + 0.06, 0.58 * day + 0.12), k * 0.85);
      if (Math.random() < dt * 25) this.particles.emit(1, this.player.pos.clone().setY(rnd(0.2, 2.5)), () => ({ ox: rnd(-6, 6), oz: rnd(-6, 6), v: [rnd(-0.3, 0.3), rnd(-0.05, 0.1), rnd(-0.3, 0.3)], c: C(0xa890d8), life: 2.5, g: 0, drag: 0.2 }));
    },
  },
  ancetres: {
    start(a) {
      const P = this.player.pos.clone(); a.center = P; a.figs = [];
      this.groundSymbol(a, 'ancetres', 4, false).position.set(P.x, 0.06, P.z);
      const n = 4 + a.rank;
      for (let i = 0; i < n; i++) {
        const ang = (i / n) * Math.PI * 2, x = P.x + Math.cos(ang) * 4.2, z = P.z + Math.sin(ang) * 4.2;
        const pil = this.add(a, new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.45, 30, 16, 1, true), ghostMat(0xffe2a0, 0.07)));
        pil.material.side = THREE.DoubleSide; pil.position.set(x, 15, z);
        const c = createCharacter({ female: i % 2 === 1 });
        c.group.traverse((o) => { if (o.isMesh) { o.material = ghostMat(0xffe8b0, 0.4); o.frustumCulled = false; } });
        c.group.position.set(x, -2, z); c.group.rotation.y = Math.atan2(P.x - x, P.z - z);
        this.add(a, c.group); a.figs.push(c);
      }
    },
    update(a, dt, k, t) {
      const rise = Math.min(1, a.t * 0.8), fade = Math.min(1, (a.dur - a.t) * 0.7);
      for (const c of a.figs) {
        c.group.position.y = -2 + rise * 2.15 + Math.sin(t * 1.5 + c.group.position.x) * 0.05;
        c.animate(dt, 0);
        const b = c.bones; if (b && b.armL) { b.armL.rotation.z = 0.5 * rise; b.armR.rotation.z = -0.5 * rise; }
        c.group.traverse((o) => { if (o.isMesh) o.material.opacity = 0.55 * fade * rise; });
      }
      if (Math.random() < dt * 20) this.particles.emit(1, a.center.clone().setY(0.2), () => ({ ox: rnd(-5, 5), oz: rnd(-5, 5), v: [0, rnd(0.8, 1.8), 0], c: C(0xffe2a0), life: 2, g: -0.1 }));
    },
  },
  portail: { start() {}, update() {} },
  colosse: {
    start(a) {
      a.store = setCharMaterial(this, new THREE.MeshStandardMaterial({ color: LATERITE, roughness: 1, flatShading: true, emissive: 0xc04a10, emissiveIntensity: 0.55 }));
      a.scale0 = this.player.mesh.scale.x; a.step = 0;
      rocksRing(this, a, 6, 1.2, 0.25);
      this.ring(0x9a5a36, this.player.pos.clone().setY(0.1), 6, 0.8);
    },
    update(a, dt, k, t, mods) {
      const s = 1 + 0.4 * Math.min(1, a.t * 2, (a.dur - a.t) * 2);
      this.player.mesh.scale.setScalar(s);
      mods.speed = Math.min(mods.speed, 0.85);
      const P = this.player.pos; this.peds.push(P.x, P.z, 2.8, 4 * dt);
      updRocks(this, a, k, t, false);
      for (const m of a.rocks) m.position.y = 0.3 + Math.sin(t * 3 + m.userData.a) * 0.3;
      if (this.player.running || Math.hypot(this.player.vel.x, this.player.vel.z) > 0.5) {
        a.step += dt; if (a.step > 0.45) { a.step = 0; this.camera.position.y += 0.08; if (this.audio && this.audio.ctx) this.audio.tone(60, 0.25, 0.25, 'sine', undefined, 0, 35); this.particles.emit(8, P.clone().setY(0.1), () => ({ v: [rnd(-1.5, 1.5), rnd(0.5, 1.5), rnd(-1.5, 1.5)], c: C(0xb07050), life: 0.6, g: 6 })); }
      }
    },
    end(a) { for (const [o, m] of a.store) o.material = m; this.player.mesh.scale.setScalar(a.scale0 || 1); },
  },
  danse: {
    start(a) { a.next = 0.35; a.n = 0; a.count = 6 + a.rank * 2; a.final = false; this.groundSymbol(a, 'danse', 2.4); this.aura(a, 0x6ab0ff, 0xe0f4ff); },
    update(a, dt, k, t, mods) {
      mods.frozen = true;
      this.player.facing += dt * 2.6;
      const b = this.player.char.bones;
      if (b && b.armL) { const s = Math.sin(t * 7); b.armL.rotation.x = -2.4 + s * 0.4; b.armR.rotation.x = -2.4 - s * 0.4; b.armL.rotation.z = 0.4; b.armR.rotation.z = -0.4; b.spine && (b.spine.rotation.z = s * 0.12); }
      const P = this.player.pos;
      if (a.n < a.count && a.t >= a.next) { const ang = (a.n / a.count) * Math.PI * 2; this.bolt(P.x + Math.cos(ang) * 5.5, P.z + Math.sin(ang) * 5.5, 0xa8dcff, false); a.n++; a.next += (a.dur - 0.9) / a.count; }
      if (!a.final && a.t > a.dur - 0.5) { a.final = true; this.ring(0xa8dcff, P.clone().setY(0.1), 14, 1, 0.2); this.peds.push(P.x, P.z, 12, 3); this.repelWisps(P.x, P.z, 14); this.env.weather.flash = 1; }
    },
  },
  onde: {
    start(a) {
      const P = this.player.pos, R = 10 + (a.rank - 1) * 2;
      this.ring(0xff6ad5, P.clone().setY(0.15), R + 2, 1.0, 0.2); this.ring(0xffffff, P.clone().setY(0.3), R, 0.8, 0.06);
      const sh = this.shell(a, 0xff6ad5, 1, 0); sh.userData.follow = 0.8; a.sh = sh;
      const n = this.peds.push(P.x, P.z, R + 2, 3.5);
      let moved = 0;
      for (const c of this.cars || []) {
        if (c.occupied || c.personal) continue;
        const dx = c.pos.x - P.x, dz = c.pos.z - P.z, d = Math.hypot(dx, dz);
        if (d > R || d < 0.1) continue;
        const push = 2.5 * (1 - d / R), nx = c.pos.x + (dx / d) * push, nz = c.pos.z + (dz / d) * push;
        if (!this.world.collision.pointBlocked(nx, 0.5, nz)) { c.pos.x = nx; c.pos.z = nz; c.heading += rnd(-0.15, 0.15); c.sync(); moved++; }
      }
      this.repelWisps(P.x, P.z, R + 4);
      this.particles.emit(80, P.clone().setY(0.5), (k) => { const ang = (k / 80) * Math.PI * 2; return { v: [Math.cos(ang) * 12, rnd(0.5, 2), Math.sin(ang) * 12], c: C(0xff9ae6), life: 0.8, g: 2, drag: 1.5 }; });
      if (n || moved) this.ui.toast(`Onde Spirituelle : ${n} passant${n > 1 ? 's' : ''} et ${moved} véhicule${moved > 1 ? 's' : ''} repoussés`, 2);
    },
    update(a) { a.sh.scale.setScalar(1 + a.t * 10); },
  },
  gardiens: {
    start(a) {
      a.guards = [];
      const n = 3;
      const P = this.player.pos;
      for (let i = 0; i < n; i++) { const g = buildGuardian(); g.userData.a = (i / n) * Math.PI * 2; g.position.set(P.x + Math.cos(g.userData.a) * 2.8, -2.4, P.z + Math.sin(g.userData.a) * 2.8); this.add(a, g); a.guards.push(g); }
      this.ring(GOLD, this.player.pos.clone().setY(0.1), 5, 0.8);
    },
    update(a, dt, k, t) {
      const P = this.player.pos, rise = Math.min(1, a.t * 1.2), fade = Math.min(1, (a.dur - a.t) * 1.2);
      for (const g of a.guards) {
        const ang = g.userData.a + t * 0.35;
        const tx = P.x + Math.cos(ang) * 2.8, tz = P.z + Math.sin(ang) * 2.8;
        g.position.x += (tx - g.position.x) * Math.min(1, dt * 4); g.position.z += (tz - g.position.z) * Math.min(1, dt * 4);
        g.position.y = -2.4 * (1 - rise) - 2.4 * (1 - fade) + 0.15 + Math.sin(t * 2 + g.userData.a) * 0.08;
        g.rotation.y = Math.atan2(g.position.x - P.x, g.position.z - P.z);
        if (Math.random() < dt * 4) this.particles.emit(1, g.position.clone().setY(2), () => ({ v: [0, 0.6, 0], c: C(GOLD), life: 1, g: 0 }));
      }
      if (Math.random() < dt * 2) this.repelWisps(P.x, P.z, 7);
    },
  },
  eveil: {
    start(a) { this.aura(a, 0xffffff, 0xffd75a, true, 0.75, 2.8); this.groundSymbol(a, 'eveil', 2.2); this.groundGlow(a, 0xffffff, 4); this.shell(a, 0xffe8a0, 1.6, 0); this.repelWisps(this.player.pos.x, this.player.pos.z, 20); },
    update(a, dt, k, t, mods) {
      mods.speed = Math.max(mods.speed, 1.5); mods.jump = Math.max(mods.jump, 1.5); mods.grav = Math.min(mods.grav, 0.6); mods.lock = true;
      mods.lift = 0.35 * Math.min(1, a.t * 2, (a.dur - a.t) * 2) + Math.sin(t * 2) * 0.05;
      this.needs.energy = Math.min(100, this.needs.energy + dt);
      if (Math.random() < dt * 30) { const ang = Math.random() * 6.28, c = new THREE.Color().setHSL(Math.random(), 0.9, 0.65); this.particles.emit(1, this.player.pos.clone().setY(rnd(0.2, 2.4)), () => ({ ox: Math.cos(ang) * 0.9, oz: Math.sin(ang) * 0.9, v: [0, rnd(0.5, 1.5), 0], c: [c.r, c.g, c.b], life: 1, g: -0.3 })); }
      if (Math.random() < dt * 2) this.repelWisps(this.player.pos.x, this.player.pos.z, 10);
    },
  },
};
