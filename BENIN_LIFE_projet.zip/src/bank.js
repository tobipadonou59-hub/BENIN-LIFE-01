// Mission 025 — application « NOVA PRIVATE BANK » (banque privée FICTIVE du jeu) : compte personnel, carte VIP noire
// (numéro et date d'expiration fictifs, générés une seule fois), espèces, transferts compte ↔ carte confirmés (jeton à usage
// unique, anti-doublon, solde vérifié), dépôts et retraits, historique, paiements (moyen de paiement par défaut), relevés
// mensuels. Monnaie virtuelle utilisable UNIQUEMENT dans BENIN LIFE : aucun lien avec un véritable compte bancaire.
// Les comptes des sociétés NOVA restent séparés (application « Épargne & sociétés »).
import { B, abbr, fcfaBig, parseAmount } from './money.js';
import { PAY_METHODS } from './economy.js';

const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const CHIPS = [['1 M', 10n ** 6n], ['100 M', 10n ** 8n], ['1 Md', 10n ** 9n], ['100 Md', 10n ** 11n], ['1 000 Md', 10n ** 12n], ['100 000 Md', 10n ** 14n], ['10 000 billions', 10n ** 16n]];
const DIRS = { c2k: ['compte', 'carte', 'Compte personnel → carte VIP'], k2c: ['carte', 'compte', 'Carte VIP → compte personnel'], dep: ['especes', 'compte', 'Dépôt d’espèces sur le compte'], ret: ['compte', 'especes', 'Retrait d’espèces du compte'] };
const RET_MAX = 10n * 10n ** 9n; // plafond d'un retrait d'espèces (règle du jeu)
const dayOf = (t) => { const m = /^J(\d+)/.exec(t || ''); return m ? +m[1] : 1; };
const monthOf = (t) => Math.ceil(dayOf(t) / 7); // mois de jeu = 7 jours (comme les loyers)
const val = (h) => (h.big !== undefined ? BigInt(h.big) : B(h.amount));

export class NovaBank {
  constructor(ctx) { Object.assign(this, ctx); this.tab = 'accueil'; this.form = null; this.filter = 'tout'; this.month = null; this.stAcc = 'compte'; this.show = false; this.amtStr = ''; this.done = null; }
  get E() { return this.economy; }
  refresh() { if (this.E.phoneOpen) this.E.renderPhone(); }
  // ------------------------------------------------------------------ opérations
  srcOf(dir) { return DIRS[dir][0]; }
  check(dir, a) {
    const E = this.E, [from] = DIRS[dir];
    if (a <= 0n) return 'Indique un montant supérieur à 0.';
    if (a > E.wal[from]) return `Solde insuffisant : ${PAY_METHODS[from][1]} = ${abbr(E.wal[from])}.`;
    if (dir === 'ret' && a > RET_MAX) return `Retrait limité à ${abbr(RET_MAX)} par opération (règle du jeu).`;
    if ((dir === 'c2k' || dir === 'k2c') && E.vip && E.vip.blocked) return 'Ta carte VIP est bloquée : débloque-la dans l’onglet « Ma carte ».';
    return null;
  }
  review() {
    const F = this.form; if (!F) return; F.amount = parseAmount(this.amtStr);
    const err = this.check(F.dir, F.amount); if (err) return this.ui.toast(err, 2.8);
    F.token = `N${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
  }
  exec(token) {
    const F = this.form, E = this.E; if (!F || !F.token || F.token !== token) return; F.token = null; // jeton à usage unique
    const err = this.check(F.dir, F.amount); if (err) return this.ui.toast(err, 2.8); // solde revérifié au moment d'exécuter
    const [from, to, label] = DIRS[F.dir], last = E.xfers[0];
    if (last && last.from === from && last.to === to && last.big === F.amount.toString() && Date.now() - (last.ts || 0) < 4000) return this.ui.toast('Opération identique effectuée à l’instant : bloquée pour éviter un doublon.', 3);
    const rec = E.move(from, to, F.amount, label); if (!rec) return this.ui.toast('Opération refusée.', 2);
    rec.ts = Date.now(); this.done = rec; this.form = null; this.amtStr = '';
    E.notify(`🏛️ ${label} : ${abbr(F.amount)} ✅`); if (this.audio && this.audio.ctx) this.audio.tone(1175, 0.1, 0.05, 'triangle');
  }
  // ------------------------------------------------------------------ rendu
  cardHtml() {
    const V = this.E.vip; if (!V) return '<p class="ph-note">Ouverture du compte en cours…</p>';
    const n = V.number, num = this.show ? n.replace(/(\d{4})(?=\d)/g, '$1 ') : `${n.slice(0, 4)} •••• •••• ${n.slice(-4)}`;
    return `<div style="position:relative;margin:6px 0 10px;padding:14px 16px;border-radius:16px;aspect-ratio:1.586;background:linear-gradient(135deg,#050505 0%,#1b1b1f 45%,#2a2a30 60%,#0a0a0b 100%);color:#f4f1e8;box-shadow:0 6px 18px rgba(0,0,0,.45),inset 0 0 0 1px rgba(216,168,48,.45);font-family:Arial,sans-serif;overflow:hidden">
      <div style="position:absolute;right:-30px;top:-40px;width:160px;height:160px;border-radius:50%;background:radial-gradient(circle,rgba(216,168,48,.18),transparent 70%)"></div>
      <div style="display:flex;justify-content:space-between;align-items:center"><b style="letter-spacing:2px;font-size:12px;color:#d8a830">NOVA PRIVATE BANK</b><span style="font-size:10px;letter-spacing:2px;opacity:.85">VIP BLACK</span></div>
      <div style="width:38px;height:28px;margin:12px 0 8px;border-radius:6px;background:linear-gradient(135deg,#f6d77a,#b8862a);box-shadow:inset 0 0 0 1px rgba(0,0,0,.35)"><div style="margin:6px 8px;height:16px;border:1px solid rgba(90,60,10,.6);border-radius:3px"></div></div>
      <div style="font-family:'Courier New',monospace;font-size:16px;letter-spacing:2px;margin:2px 0 10px">${num}</div>
      <div style="display:flex;justify-content:space-between;font-size:10px;opacity:.9"><span><small style="display:block;opacity:.7">TITULAIRE</small><b style="font-size:12px;letter-spacing:1px">${esc(V.holder)}</b></span><span style="text-align:right"><small style="display:block;opacity:.7">EXPIRE FIN</small><b style="font-size:12px">${esc(V.exp)}</b></span></div>
      <div style="position:absolute;left:16px;bottom:6px;font-size:8px;letter-spacing:1px;opacity:.6">CARTE VIRTUELLE • UTILISABLE UNIQUEMENT DANS BENIN LIFE${V.blocked ? ' • 🔒 BLOQUÉE' : ''}</div></div>`;
  }
  amountForm(dirs) {
    const F = this.form, E = this.E;
    let h = `<div class="ph-chips">${dirs.map((d) => `<button data-nb="dir:${d}" class="${F && F.dir === d ? 'on' : ''}">${DIRS[d][2]}</button>`).join('')}</div>`;
    if (!F) return h + '<p class="ph-note">Choisis le sens de l’opération.</p>';
    const [from, to] = DIRS[F.dir];
    h += `<p class="ph-note">Disponible : ${PAY_METHODS[from][0]} ${abbr(E.wal[from])} • vers ${PAY_METHODS[to][0]} ${PAY_METHODS[to][1]}</p>`;
    if (F.token) {
      const a = F.amount;
      return h + `<div class="pp-sum"><span>Opération</span><b>${DIRS[F.dir][2]}</b><span>Montant</span><b>${abbr(a)}</b><span>Montant exact</span><b style="font-size:11px">${fcfaBig(a)}</b><span>${PAY_METHODS[from][1]} après</span><b>${abbr(E.wal[from] - a)}</b><span>${PAY_METHODS[to][1]} après</span><b>${abbr(E.wal[to] + a)}</b></div>
        <button class="ph-go" data-nb="ok:${F.token}">✅ CONFIRMER L’OPÉRATION</button><button class="ph-mini" data-nb="cancel">Annuler</button>`;
    }
    return h + `<input id="nb-amt" inputmode="numeric" placeholder="Montant en FCFA (chiffres)" value="${esc(this.amtStr)}" style="width:100%;box-sizing:border-box;padding:9px;border-radius:10px;border:0;margin:4px 0;background:#22262e;color:#fff;font-size:15px">
      <p class="ph-note" id="nb-prev">${this.amtStr ? `= ${abbr(parseAmount(this.amtStr))}` : 'Saisis un montant ou choisis un raccourci.'}</p>
      <div class="ph-chips">${CHIPS.map(([l, v]) => `<button data-nb="amt:${v}">${l}</button>`).join('')}<button data-nb="max">Maximum</button></div>
      <button class="ph-go" data-nb="review">VÉRIFIER L’OPÉRATION</button>`;
  }
  rows(list, lim = 60) {
    return list.slice(0, lim).map((h) => { const v = val(h), tr = h.xfer, ic = tr ? '⇄' : (PAY_METHODS[h.via] || ['•'])[0];
      return `<div class="ph-row"><span><b>${ic} ${esc(h.label)}</b><small>${esc(h.place || '')} • ${esc(h.t)}${tr ? ` • ${esc(h.via.split('>').map((k) => PAY_METHODS[k][1]).join(' → '))}` : ''}</small></span><em class="${tr ? '' : v < 0n ? 'neg' : 'pos'}" title="${fcfaBig(v)}">${tr ? '' : v < 0n ? '' : '+'}${abbr(v)}</em></div>`; }).join('') || '<p class="ph-note">Aucune opération.</p>';
  }
  renderApp(b) {
    const E = this.E, tabs = [['accueil', 'Accueil'], ['transfert', 'Transférer'], ['historique', 'Historique'], ['paiements', 'Paiements'], ['releves', 'Relevés'], ['especes', 'Espèces'], ['carte', 'Ma carte']];
    let h = `<h4>🏛️ NOVA PRIVATE BANK</h4><p class="ph-note">Banque privée fictive • monnaie virtuelle utilisable uniquement dans BENIN LIFE • aucun lien avec un vrai compte bancaire.</p>
      <div class="ph-chips">${tabs.map(([k, l]) => `<button data-nb="tab:${k}" class="${k === this.tab ? 'on' : ''}">${l}</button>`).join('')}</div>`;
    const bal = (k) => `<div class="ph-row"><span><b>${PAY_METHODS[k][0]} ${PAY_METHODS[k][1]}${E.method === k ? ' • moyen de paiement' : ''}</b><small>${fcfaBig(E.wal[k])}</small></span><em>${abbr(E.wal[k])}</em></div>`;
    if (this.tab === 'accueil') {
      const real = E.history.filter((x) => !x.xfer && !x.grant), rev = real.filter((x) => val(x) > 0n).slice(0, 4), dep = real.filter((x) => val(x) < 0n).slice(0, 4);
      const go = (ph, ic, l) => `<button data-ph="${ph}"><i>${ic}</i>${l}</button>`;
      h += this.cardHtml() + `<div class="ph-list">${bal('compte')}${bal('carte')}${bal('especes')}</div>
        <div class="ph-apps"><button data-nb="tab:transfert"><i>⇄</i>Transférer</button><button data-nb="tab:historique"><i>📜</i>Historique</button><button data-nb="tab:paiements"><i>💳</i>Paiements</button><button data-nb="tab:releves"><i>📄</i>Relevés</button><button data-nb="tab:especes"><i>💵</i>Dépôt / retrait</button>
        ${this.E.phonePlus ? go('transfers', '💸', 'Virements') : ''}${this.E.fortune ? go('achats', '🛍️', 'Achats & patrimoine') + go('bank', '🏦', 'Épargne & sociétés') : ''}${this.E.terminal ? go('travel', '✈️', 'Voyages') : ''}${this.E.villa ? go('villa', '🏡', 'Villa') : ''}${this.E.chauffeur ? go('drv', '🚘', 'Chauffeur & limousine') : ''}${this.E.solidarity ? go('soli', '❤️', 'Dons & solidarité') : ''}</div>
        <h5>Revenus récents</h5><div class="ph-list">${this.rows(rev, 4)}</div><h5>Dépenses récentes</h5><div class="ph-list">${this.rows(dep, 4)}</div>`;
    } else if (this.tab === 'transfert' || this.tab === 'especes') {
      if (this.done && ((this.tab === 'transfert') === (this.done.from !== 'especes' && this.done.to !== 'especes'))) h += `<div class="pp-ok"><b>✅ Opération effectuée</b><p>${esc(this.done.label)}<br>${abbr(BigInt(this.done.big))} • ${esc(this.done.t)}<br><small>${fcfaBig(BigInt(this.done.big))}</small></p></div>`;
      h += `<div class="ph-list">${this.tab === 'transfert' ? bal('compte') + bal('carte') : bal('especes') + bal('compte')}</div>` + this.amountForm(this.tab === 'transfert' ? ['c2k', 'k2c'] : ['dep', 'ret']);
      const mine = E.xfers.filter((x) => (this.tab === 'especes') === (x.from === 'especes' || x.to === 'especes')).slice(0, 12);
      h += `<h5>Historique des ${this.tab === 'transfert' ? 'transferts' : 'dépôts et retraits'}</h5><div class="ph-list">${mine.map((x) => `<div class="ph-row"><span><b>⇄ ${esc(x.label)}</b><small>${esc(x.t)} • réf. ${esc(x.id)}</small></span><em title="${fcfaBig(BigInt(x.big))}">${abbr(BigInt(x.big))}</em></div>`).join('') || '<p class="ph-note">Aucune opération pour l’instant.</p>'}</div>`;
    } else if (this.tab === 'historique') {
      const F = [['tout', 'Tout'], ['compte', '🏦 Compte'], ['carte', '💳 Carte'], ['especes', '💵 Espèces'], ['xfer', '⇄ Transferts'], ['rev', 'Revenus'], ['dep', 'Dépenses']];
      const list = E.history.filter((x) => { const f = this.filter, v = val(x); if (f === 'tout') return true; if (f === 'xfer') return !!x.xfer; if (f === 'rev') return !x.xfer && v > 0n; if (f === 'dep') return !x.xfer && v < 0n; return x.via === f || (x.xfer && x.via.split('>').includes(f)) || (!x.via && f === 'compte'); });
      h += `<div class="ph-chips">${F.map(([k, l]) => `<button data-nb="flt:${k}" class="${k === this.filter ? 'on' : ''}">${l}</button>`).join('')}</div><p class="ph-note">${list.length} opération(s) • les ${Math.min(300, E.history.length)} dernières sont conservées dans la sauvegarde.</p><div class="ph-list">${this.rows(list, 80)}</div>`;
    } else if (this.tab === 'paiements') {
      h += `<h5>Moyen de paiement par défaut</h5><div class="ph-list">${Object.keys(PAY_METHODS).map((k) => `<div class="ph-row${E.method === k ? ' pp-on' : ''}"><span><b>${PAY_METHODS[k][0]} ${PAY_METHODS[k][1]}</b><small>Disponible : ${abbr(E.wal[k])}${k === 'carte' && E.vip && E.vip.blocked ? ' • carte bloquée' : ''}</small></span>${E.method === k ? '<em class="pos">choisi ✔</em>' : `<button class="ph-mini" data-nb="method:${k}">Choisir</button>`}</div>`).join('')}</div>
        <p class="ph-note">Tous les achats du jeu sont débités du moyen choisi : magasins, restaurants, hôtels, voyages (NOVA TRAVEL, vols régionaux, bus), limousine et chauffeur, villa, véhicules, propriétés, garde-robe, événements, projets et dons. Les revenus personnels (allocation, loyers, dividendes) arrivent sur le compte personnel ; les comptes des sociétés NOVA restent séparés.</p>
        <h5>Derniers paiements</h5><div class="ph-list">${this.rows(E.history.filter((x) => !x.xfer && val(x) < 0n), 30)}</div>`;
    } else if (this.tab === 'releves') {
      const cur = monthOf(E.stamp()), months = [...new Set(E.history.map((x) => monthOf(x.t)))].sort((a, c) => c - a), m = this.month && months.includes(this.month) ? this.month : cur, acc = this.stAcc;
      const flow = (x, k) => { const v = val(x); if (x.xfer) { const [f, t] = x.via.split('>'); return f === k ? -v : t === k ? v : 0n; } return (x.via || 'compte') === k ? v : 0n; };
      let end = E.wal[acc]; for (const x of E.history) { if (monthOf(x.t) <= m) break; end -= flow(x, acc); } // solde de fin du mois choisi
      const ops = E.history.filter((x) => monthOf(x.t) === m && flow(x, acc) !== 0n); let cr = 0n, db = 0n; for (const x of ops) { const f = flow(x, acc); if (f > 0n) cr += f; else db -= f; }
      h += `<div class="ph-chips">${(months.length ? months : [cur]).map((k) => `<button data-nb="month:${k}" class="${k === m ? 'on' : ''}">Mois ${k}</button>`).join('')}</div><div class="ph-chips">${Object.keys(PAY_METHODS).map((k) => `<button data-nb="stacc:${k}" class="${k === acc ? 'on' : ''}">${PAY_METHODS[k][0]} ${PAY_METHODS[k][1]}</button>`).join('')}</div>
        <div class="pp-sum"><span>Relevé</span><b>${PAY_METHODS[acc][1]} — mois ${m} de jeu (jours ${(m - 1) * 7 + 1} à ${m * 7})</b><span>Solde de début</span><b>${abbr(end - cr + db)}</b><span>Crédits</span><b class="pos">+${abbr(cr)}</b><span>Débits</span><b class="neg">−${abbr(db)}</b><span>Solde de fin</span><b>${abbr(end)}</b><span>Opérations</span><b>${ops.length}</b></div>
        <p class="ph-note">Relevé établi à partir des opérations conservées (300 dernières). Montants exacts au survol ou dans l’historique.</p><div class="ph-list">${this.rows(ops, 80)}</div>`;
    } else if (this.tab === 'carte') {
      const V = E.vip;
      h += this.cardHtml() + (V ? `<div class="ph-list"><div class="ph-row"><span><b>Numéro (fictif)</b><small>${this.show ? V.number.replace(/(\d{4})(?=\d)/g, '$1 ') : 'masqué'}</small></span><button class="ph-mini" data-nb="show">${this.show ? 'Masquer' : 'Afficher'}</button></div>
        <div class="ph-row"><span><b>Date d’expiration (fictive)</b><small>${esc(V.exp)} • carte ouverte le ${esc(V.since)}</small></span></div>
        <div class="ph-row"><span><b>Solde de la carte</b><small>${fcfaBig(E.wal.carte)}</small></span><em>${abbr(E.wal.carte)}</em></div>
        <div class="ph-row"><span><b>Statut</b><small>${V.blocked ? '🔒 Bloquée : aucun paiement ni transfert par carte' : '✅ Active'}</small></span><button class="ph-mini" data-nb="block">${V.blocked ? 'Débloquer' : 'Bloquer'}</button></div></div>
        <h5>Nom du titulaire</h5><input id="nb-holder" maxlength="24" value="${esc(V.holder)}" style="width:100%;box-sizing:border-box;padding:9px;border-radius:10px;border:0;margin:4px 0;background:#22262e;color:#fff;text-transform:uppercase"><button class="ph-go" data-nb="holder">ENREGISTRER LE NOM</button>
        <p class="ph-note">Carte exclusivement virtuelle : elle ne fonctionne que dans BENIN LIFE et ne correspond à aucune vraie carte.</p>` : '');
    }
    b.innerHTML = h;
    const inp = b.querySelector('#nb-amt'); if (inp) { const prev = b.querySelector('#nb-prev'); inp.addEventListener('click', (e) => e.stopPropagation()); inp.addEventListener('keydown', (e) => e.stopPropagation()); inp.addEventListener('input', () => { this.amtStr = inp.value; const a = parseAmount(inp.value); if (prev) prev.textContent = inp.value ? (a ? `= ${abbr(a)}` : 'Chiffres uniquement.') : 'Saisis un montant ou choisis un raccourci.'; }); }
    const hn = b.querySelector('#nb-holder'); if (hn) { hn.addEventListener('click', (e) => e.stopPropagation()); hn.addEventListener('keydown', (e) => e.stopPropagation()); }
  }
  onClick(btn) {
    const [a, ...r] = btn.dataset.nb.split(':'), v = r.join(':'), E = this.E;
    if (this.audio && this.audio.ctx && this.audio.click) this.audio.click();
    if (a === 'tab') { this.tab = v; this.form = null; this.done = null; this.amtStr = ''; }
    else if (a === 'dir') { this.form = { dir: v, amount: 0n, token: null }; this.done = null; }
    else if (a === 'amt' && this.form) { this.amtStr = v; this.form.token = null; }
    else if (a === 'max' && this.form) { const from = this.srcOf(this.form.dir); let m = E.wal[from]; if (this.form.dir === 'ret' && m > RET_MAX) m = RET_MAX; this.amtStr = m.toString(); this.form.token = null; }
    else if (a === 'review') this.review();
    else if (a === 'ok') this.exec(v);
    else if (a === 'cancel') { if (this.form) this.form.token = null; }
    else if (a === 'flt') this.filter = v;
    else if (a === 'method' && PAY_METHODS[v]) { E.method = v; E.renderHud(); E.notify(`${PAY_METHODS[v][0]} Moyen de paiement : ${PAY_METHODS[v][1]} (${abbr(E.wal[v])})`); E.onSave && E.onSave(); }
    else if (a === 'month') this.month = +v;
    else if (a === 'stacc' && PAY_METHODS[v]) this.stAcc = v;
    else if (a === 'show') this.show = !this.show;
    else if (a === 'block' && E.vip) { E.vip.blocked = !E.vip.blocked; E.notify(E.vip.blocked ? '🔒 Carte VIP bloquée' : '✅ Carte VIP débloquée'); E.onSave && E.onSave(); }
    else if (a === 'holder' && E.vip) { const el = document.querySelector('#nb-holder'), n = (el ? el.value : '').trim().toUpperCase().replace(/[^A-ZÀ-ÖØ-Ý0-9 '\-.]/g, '').slice(0, 24); if (!n) return this.ui.toast('Indique un nom.', 2); E.vip.holder = n; E.notify(`💳 Titulaire de la carte : ${n}`); E.onSave && E.onSave(); }
    this.refresh();
  }
}
