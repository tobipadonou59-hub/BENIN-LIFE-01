// Mission 018, étape 3 — limousine personnelle (une seule, identifiant « BL-LIMO-1 »), garée dans un garage dédié
// attenant au garage de la résidence. Carrosserie noire brillante allongée (7,2 m), jantes chromées, baguettes chromées,
// plaques personnalisées « BENIN LIFE », vitres teintées (réglables), portières arrière et coffre animés, salon arrière
// (banquettes crème, éclairage LED d'ambiance, ciel étoilé, écran multimédia, mini-bar de boissons sans alcool,
// climatisation), tableau de bord de conduite. Elle se conduit comme les autres voitures (E près de la portière avant).
import * as THREE from 'three';
import { DrivableCar, glassMat } from './vehicles.js';

const PI = Math.PI;
export const LIMO_ID = 'BL-LIMO-1';
export const ANNEX = { x0: -27.6, x1: -22.4, z0: 119, z1: 132 };
export const LIMO_SPOT = { x: -25, z: 125.4, h: PI }; // nez vers la porte du garage (sud)
const LED = { violet: 0x9a4dff, bleu: 0x2f80ed, or: 0xffb020, blanc: 0xf4f0ff, vert: 0x18c070 };
const SCREENS = { off: 'Éteint', musique: 'Musique', infos: 'Infos', film: 'Film', trajet: 'Trajet' };
const DRINKS = [['bissap', 'Bissap frais'], ['ananas', 'Jus d’ananas'], ['eau', 'Eau pétillante']];
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
function canvasTex(w, h, draw) { const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.userData.c = c; return t; }

export class Limousine {
  constructor(ctx) {
    Object.assign(this, ctx); // scene, world, player, ui, audio, env, cars, needs, onSave
    this.st = { led: 'violet', ledOn: true, ac: true, temp: 21, screen: 'musique', tint: true, km: 0 };
    this.doors = { l: { o: 0, t: 0 }, r: { o: 0, t: 0 }, k: { o: 0, t: 0 } }; this.door = { o: 0, t: 0 }; this.open = false; this.cabin = false; this.scrT = 0;
    if (this.scene.getObjectByName(LIMO_ID)) throw new Error('limousine déjà créée'); // jamais deux limousines
    this.buildAnnex();
    const car = this.car = new DrivableCar(this.scene, { x: LIMO_SPOT.x, z: LIMO_SPOT.z, h: LIMO_SPOT.h, color: 0x08090b, model: 'limo' });
    car.isLimo = true; car.personal = true; car.mesh.name = LIMO_ID; car.hornFreqs = 'car';
    this.cars.push(car);
    this.decorate(car.mesh);
    this.dom = document.querySelector('#limo'); this.dom.addEventListener('click', (e) => this.onClick(e));
    this.dash = document.querySelector('#limodash'); this.dash.addEventListener('click', (e) => this.onClick(e));
  }
  // ------------------------------------------------------------------ garage dédié
  buildAnnex() {
    const A = ANNEX, g = new THREE.Group(), col = this.world.collision; this.scene.add(g);
    const wall = new THREE.MeshStandardMaterial({ color: 0xece6da, roughness: 0.7 }), dark = new THREE.MeshStandardMaterial({ color: 0x23262b, roughness: 0.5 });
    const floor = new THREE.MeshStandardMaterial({ color: 0x3a3d42, roughness: 0.25, metalness: 0.2 });
    const add = (w, h, d, x, y, z, m) => { const o = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m); o.position.set(x, y, z); o.castShadow = o.receiveShadow = true; g.add(o); return o; };
    const cx = (A.x0 + A.x1) / 2, cz = (A.z0 + A.z1) / 2, W = A.x1 - A.x0, D = A.z1 - A.z0, H = 3.0;
    add(W, 0.04, D, cx, 0.02, cz, floor).castShadow = false;
    add(0.2, H, D, A.x0 + 0.1, H / 2, cz, wall); add(0.2, H, D, A.x1 - 0.1, H / 2, cz, wall); add(W, H, 0.2, cx, H / 2, A.z1 - 0.1, wall);
    add(W + 0.3, 0.2, D + 0.3, cx, H + 0.1, cz, dark);
    add(W, H - 2.7, 0.2, cx, 2.7 + (H - 2.7) / 2, A.z0 + 0.1, wall);
    for (const x of [A.x0 + 0.2, A.x1 - 0.2]) add(0.4, 2.7, 0.25, x, 1.35, A.z0 + 0.12, wall);
    col.addBox(A.x0, A.z0, A.x0 + 0.2, A.z1, H); col.addBox(A.x1 - 0.2, A.z0, A.x1, A.z1, H); col.addBox(A.x0, A.z1 - 0.2, A.x1, A.z1, H);
    // néons de plafond (émissifs, pas de lumière dynamique ajoutée)
    for (const z of [cz - 3, cz + 3]) { const n = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.05, 0.25), new THREE.MeshBasicMaterial({ color: 0xfff6e6, toneMapped: false })); n.position.set(cx, H - 0.05, z); g.add(n); }
    // enseigne
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(4.6, 0.32), new THREE.MeshBasicMaterial({ map: canvasTex(512, 36, (x, w, h) => { x.fillStyle = '#0b0c0e'; x.fillRect(0, 0, w, h); x.fillStyle = '#d8a830'; x.font = '900 24px Arial'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('BENIN LIFE • GARAGE LIMOUSINE', w / 2, h / 2 + 1); }), toneMapped: false }));
    sign.position.set(cx, 2.86, A.z0 - 0.01); sign.rotation.y = PI; g.add(sign);
    // porte enroulable
    const dg = new THREE.Group(); dg.position.set(cx, 0, A.z0 + 0.02); g.add(dg);
    const dm = new THREE.Mesh(new THREE.BoxGeometry(W - 0.8, 2.7, 0.05).translate(0, 1.35, 0), new THREE.MeshStandardMaterial({ color: 0x2a2d33, metalness: 0.5, roughness: 0.4 }));
    dg.add(dm); this.doorMesh = dm; this.doorCol = col.addBox(A.x0 + 0.4, A.z0, A.x1 - 0.4, A.z0 + 0.15, 2.7);
    for (let k = 1; k < 9; k++) { const l = new THREE.Mesh(new THREE.BoxGeometry(W - 0.8, 0.02, 0.06), dark); l.position.set(0, k * 0.3, 0.01); dm.add(l); }
  }
  // ------------------------------------------------------------------ détails de la limousine (repère local : avant = +z)
  decorate(root) {
    const M = (c, o = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.4, ...o });
    const chrome = M(0xdfe3e8, { metalness: 0.95, roughness: 0.15 }), paint = M(0x08090b, { metalness: 0.6, roughness: 0.18 }), cream = M(0xe9dcc0, { roughness: 0.6 }), wood = M(0x4a2a16, { roughness: 0.35 });
    const box = (w, h, d, x, y, z, m, parent = root) => { const o = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m); o.position.set(x, y, z); parent.add(o); return o; };
    // vitres teintées : matériau propre à la limousine (réglable)
    this.glass = root.children[1]; this.glass.material = glassMat().clone(); this.glass.material.transparent = true;
    this.roof = box(1.82, 0.06, 3.6, 0, 1.48, -0.35, paint); // toit (amovible en vue salon)
    // baguettes chromées, ornement, plaques
    for (const s of [-1, 1]) box(0.02, 0.04, 6.9, s * 0.985, 0.9, 0, chrome);
    box(0.5, 0.05, 0.06, 0, 0.98, 3.62, chrome);
    const orn = new THREE.Mesh(new THREE.SphereGeometry(0.05, 10, 8), chrome); orn.position.set(0, 1.06, 3.0); root.add(orn);
    const plateTex = canvasTex(256, 60, (x, w, h) => { x.fillStyle = '#fff'; x.fillRect(0, 0, w, h); x.fillStyle = '#008751'; x.fillRect(0, 0, 18, h); x.fillStyle = '#fcd116'; x.fillRect(18, 0, 10, h / 2); x.fillStyle = '#e8112d'; x.fillRect(18, h / 2, 10, h / 2); x.strokeStyle = '#111'; x.lineWidth = 3; x.strokeRect(1, 1, w - 2, h - 2); x.fillStyle = '#111'; x.font = '900 36px Arial'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('BENIN LIFE', w / 2 + 12, h / 2 + 2); });
    for (const [z, ry] of [[3.67, 0], [-3.67, PI]]) { const p = new THREE.Mesh(new THREE.PlaneGeometry(0.56, 0.13), new THREE.MeshBasicMaterial({ map: plateTex })); p.position.set(0, 0.5, z); p.rotation.y = ry; root.add(p); }
    // portières arrière (pivot au bord avant) + vue du salon révélée à l'ouverture
    const salonTex = canvasTex(256, 128, (x, w, h) => { const gr = x.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, '#2a1840'); gr.addColorStop(1, '#120a1c'); x.fillStyle = gr; x.fillRect(0, 0, w, h); x.fillStyle = '#e9dcc0'; x.fillRect(10, 70, w - 20, 34); x.fillRect(10, 40, 30, 64); x.fillStyle = '#c9b896'; for (let i = 0; i < 5; i++) x.fillRect(46 + i * 40, 74, 2, 28); x.fillStyle = '#b388ff'; x.fillRect(0, 4, w, 4); x.fillRect(0, h - 10, w, 3); for (let i = 0; i < 18; i++) { x.fillStyle = 'rgba(255,255,255,0.8)'; x.fillRect(Math.random() * w, 10 + Math.random() * 20, 2, 2); } });
    this.sides = {};
    for (const [k, s] of [['l', -1], ['r', 1]]) {
      const piv = new THREE.Group(); piv.position.set(s * 0.975, 0, -0.2); root.add(piv);
      box(0.04, 0.66, 1.3, 0, 0.68, -0.65, paint, piv); box(0.035, 0.4, 1.2, 0, 1.2, -0.62, M(0x0d151c, { roughness: 0.05, metalness: 0.3 }), piv); box(0.03, 0.04, 0.25, s * 0.03, 0.88, -1.1, chrome, piv);
      const view = new THREE.Mesh(new THREE.PlaneGeometry(1.25, 0.9), new THREE.MeshBasicMaterial({ map: salonTex, toneMapped: false })); view.position.set(s * 0.972, 0.95, -0.85); view.rotation.y = s * PI / 2; view.visible = false; root.add(view);
      this.sides[k] = { piv, s, view };
    }
    // coffre
    const tp = new THREE.Group(); tp.position.set(0, 1.0, -2.7); root.add(tp); box(1.84, 0.05, 0.86, 0, 0.02, -0.43, paint, tp); this.trunk = tp;
    const tin = new THREE.Group(); tin.visible = false; root.add(tin); box(1.7, 0.02, 0.8, 0, 0.97, -3.1, M(0x1a1a1a), tin); box(0.6, 0.3, 0.4, -0.4, 1.12, -3.1, M(0x5a3a22), tin); box(0.5, 0.25, 0.35, 0.35, 1.1, -3.05, M(0x1f2a44), tin); this.trunkIn = tin;
    // ---- salon arrière (visible en vue intérieure et vitres claires) ----
    const sal = this.salon = new THREE.Group(); root.add(sal);
    const shellMat = new THREE.MeshStandardMaterial({ color: 0x1c1410, roughness: 0.8, side: THREE.BackSide }), carpet = M(0x2a1a12);
    this.salonMats = [[cream, 0.13], [wood, 0.1], [shellMat, 0.28], [carpet, 0.15]];
    const shell = new THREE.Mesh(new THREE.BoxGeometry(1.78, 1.02, 5.0), shellMat); shell.position.set(0, 0.97, -0.5); sal.add(shell);
    box(1.7, 0.02, 4.8, 0, 0.47, -0.5, carpet, sal);                                   // moquette
    box(1.6, 0.4, 0.6, 0, 0.67, -2.35, cream, sal); box(1.6, 0.55, 0.14, 0, 1.08, -2.68, cream, sal); // banquette arrière
    box(0.5, 0.4, 2.0, -0.6, 0.67, -0.75, cream, sal); box(0.13, 0.5, 2.0, -0.86, 1.05, -0.75, cream, sal); // banquette latérale
    box(1.76, 0.92, 0.08, 0, 0.93, 1.05, wood, sal);                                        // cloison chauffeur
    box(0.45, 0.42, 0.9, 0.62, 0.68, -0.3, wood, sal);                                      // mini-bar
    for (const [i, c] of [[0, 0xa0102a], [1, 0xf0a020], [2, 0xd8f0ff]]) { const b = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.04, 0.2, 8), M(c, { transparent: true, opacity: 0.85, roughness: 0.1 })); b.position.set(0.62, 0.99, -0.55 + i * 0.22); sal.add(b); }
    for (const x of [-0.5, 0.5]) box(0.25, 0.04, 0.03, x, 1.32, 1.0, chrome, sal);           // grilles de climatisation
    // écran multimédia
    this.scr = canvasTex(320, 180, () => {}); const sc = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 0.5), new THREE.MeshBasicMaterial({ map: this.scr, toneMapped: false })); sc.position.set(0, 1.12, 1.0); sc.rotation.y = PI; sal.add(sc);
    // LED d'ambiance + ciel étoilé
    this.ledMat = new THREE.MeshBasicMaterial({ color: LED.violet, toneMapped: false });
    for (const s of [-1, 1]) { box(0.03, 0.025, 4.4, s * 0.84, 1.42, -0.6, this.ledMat, sal); box(0.03, 0.02, 4.4, s * 0.84, 0.5, -0.6, this.ledMat, sal); }
    const starG = []; for (let i = 0; i < 40; i++) starG.push(new THREE.SphereGeometry(0.008, 4, 3).translate((Math.random() - 0.5) * 1.5, 1.47, -2.8 + Math.random() * 3.7));
    this.stars = new THREE.Mesh(starG[0], new THREE.MeshBasicMaterial({ color: 0xffffff, toneMapped: false })); this.starsList = starG.map((geo) => { const m = new THREE.Mesh(geo, this.stars.material); sal.add(m); return m; });
    this.applyState();
  }
  // ------------------------------------------------------------------ états
  applyState() {
    const S = this.st;
    this.ledMat.color.setHex(S.ledOn ? LED[S.led] : 0x111111);
    for (const m of this.starsList) m.visible = S.ledOn;
    for (const [m, k] of this.salonMats) { m.emissive.setHex(S.ledOn ? LED[S.led] : 0xfff2dc); m.emissiveIntensity = S.ledOn ? k : k * 0.5; } // reflet de l'éclairage d'ambiance
    this.glass.material.opacity = S.tint ? 0.94 : 0.42; this.glass.material.color.setHex(S.tint ? 0x05080b : 0x40525e);
    this.drawScreen(true);
  }
  drawScreen(force) {
    const c = this.scr.userData.c, x = c.getContext('2d'), w = c.width, h = c.height, S = this.st, t = performance.now() / 1000;
    x.fillStyle = '#05060a'; x.fillRect(0, 0, w, h);
    if (S.screen !== 'off') {
      x.fillStyle = '#d8a830'; x.font = '700 14px Arial'; x.fillText(`BENIN LIFE • ${SCREENS[S.screen]}`, 10, 20); x.fillStyle = '#9aa6b2'; x.font = '12px Arial'; x.fillText(`${this.env.clock || ''} • ${S.ac ? `Clim ${S.temp} °C` : 'Clim arrêtée'}`, 10, h - 10);
      x.fillStyle = '#fff'; x.font = '700 18px Arial';
      if (S.screen === 'musique') { x.fillText('♪ Rythmes du Golfe (radio fictive)', 10, 60); for (let i = 0; i < 24; i++) { const v = 0.3 + 0.7 * Math.abs(Math.sin(t * 3 + i * 0.7)); x.fillStyle = '#9a4dff'; x.fillRect(12 + i * 12, 150 - v * 60, 8, v * 60); } }
      else if (S.screen === 'infos') { x.fillText('Journal économique (fictif)', 10, 60); x.font = '14px Arial'; x.fillText('Le secteur de l’édition en croissance…', 10, 90); x.fillText('Météo : ' + (this.env.weather ? this.env.weather.current : 'beau temps'), 10, 115); }
      else if (S.screen === 'film') { const gr = x.createLinearGradient(0, 30, w, h); gr.addColorStop(0, `hsl(${(t * 20) % 360},60%,30%)`); gr.addColorStop(1, '#100818'); x.fillStyle = gr; x.fillRect(0, 28, w, h - 50); x.fillStyle = '#fff'; x.fillText('« Les Lumières du Golfe » (film fictif)', 10, 100); }
      else if (S.screen === 'trajet') { x.fillText(this.route || 'Pas de trajet en cours', 10, 60); x.font = '14px Arial'; x.fillText(`Compteur : ${this.st.km.toFixed(1).replace('.', ',')} km`, 10, 90); }
    }
    this.scr.needsUpdate = true;
  }
  // ------------------------------------------------------------------ interactions à pied
  local(lx, lz) { const c = this.car, s = Math.sin(c.heading), co = Math.cos(c.heading); return { x: c.pos.x + lx * co + lz * s, z: c.pos.z - lx * s + lz * co }; }
  nearest(x, z) {
    const out = [];
    const A = ANNEX, dd = Math.hypot(x - (A.x0 + A.x1) / 2, z - (A.z0 - 1.2));
    if (dd < 2.2) out.push({ d: dd, it: { label: () => (this.door.t ? 'Fermer la porte du garage limousine' : 'Ouvrir la porte du garage limousine'), action: () => this.toggleDoor() } });
    if (!this.car.occupied) {
      const pts = [[-1.35, -0.9, 'l'], [1.35, -0.9, 'r'], [0, -4.1, 'k']];
      for (const [lx, lz, k] of pts) { const p = this.local(lx, lz), d = Math.hypot(x - p.x, z - p.z); if (d < 1.4) out.push({ d: Math.max(0, d - 1.2), it: { label: () => (k === 'k' ? (this.doors.k.t ? 'Fermer le coffre de la limousine' : 'Ouvrir le coffre de la limousine') : this.doors[k].t ? 'S’installer dans le salon arrière (limousine)' : `Ouvrir la portière arrière ${k === 'l' ? 'gauche' : 'droite'}`), action: () => (k !== 'k' && this.doors[k].t ? this.enterSalon(k) : this.toggle(k)) } }); }
    }
    return out.sort((a, b) => a.d - b.d)[0] || null;
  }
  toggle(k) { const d = this.doors[k]; d.t = d.t ? 0 : 1; if (this.audio && this.audio.ctx) this.audio.door(); this.onSave && this.onSave(); }
  toggleDoor() { this.door.t = this.door.t ? 0 : 1; if (this.audio && this.audio.ctx) this.audio.tone(150, 1.0, 0.07, 'sawtooth'); }
  // ------------------------------------------------------------------ salon arrière (vue intérieure + panneau)
  enterSalon(side) {
    this.cabin = true; this.open = true; this.side = side || 'l'; this.player.mesh.visible = false; this.glass.visible = false; this.roof.visible = false; this.car.mesh.children[0].visible = false; for (const k of ['l', 'r']) this.sides[k].piv.visible = false; // vue en coupe du salon (toit et vitres retirés) this.doors.l.t = this.doors.r.t = 0;
    this.dom.classList.add('show'); this.render();
    this.ui.toast('Installé dans le salon arrière : éclairage, écran, climatisation et mini-bar à ta disposition.', 3);
  }
  leaveSalon() {
    if (!this.cabin) return; this.cabin = false; this.open = false; this.dom.classList.remove('show'); this.glass.visible = true; this.roof.visible = true; this.car.mesh.children[0].visible = true; for (const k of ['l', 'r']) this.sides[k].piv.visible = true;
    if (this._fov && this.camera) { this.camera.fov = this._fov; this.camera.updateProjectionMatrix(); this._fov = null; }
    const p = this.local((this.side === 'r' ? 1 : -1) * 1.9, -0.9); this.player.pos.set(p.x, 0, p.z); this.player.mesh.visible = true; this.player.mesh.position.copy(this.player.pos);
    if (this.audio && this.audio.ctx) this.audio.door(); this.onSave && this.onSave();
  }
  applyCam(camera) { this.camera = camera; // caméra dans le salon, tournée vers la banquette arrière
    const m = this.car.mesh; m.updateMatrixWorld();
    const sx = this.side === 'r' ? 1 : -1, eye = new THREE.Vector3(sx * 0.55, 2.75, 1.25).applyMatrix4(m.matrixWorld), look = new THREE.Vector3(0, 0.55, -1.2).applyMatrix4(m.matrixWorld);
    camera.position.copy(eye); camera.lookAt(look);
    if (camera.fov !== 64) { this._fov = camera.fov; camera.fov = 64; camera.updateProjectionMatrix(); }
  }
  render() {
    if (!this.open) return; const S = this.st, chip = (k, l, on) => `<button data-lm="${k}" class="${on ? 'on' : ''}">${l}</button>`;
    this.dom.innerHTML = `<div class="lm-box"><div class="tk-head"><h2>🚘 Limousine — salon arrière</h2><button data-lm="out">Descendre</button></div>
      <h5>💡 Éclairage LED</h5><div class="mt-chips">${chip('ledOn', S.ledOn ? 'Allumé' : 'Éteint', S.ledOn)}${Object.keys(LED).map((k) => chip(`led:${k}`, k, S.ledOn && S.led === k)).join('')}</div>
      <h5>📺 Écran multimédia</h5><div class="mt-chips">${Object.entries(SCREENS).map(([k, l]) => chip(`scr:${k}`, l, S.screen === k)).join('')}</div>
      <h5>❄️ Climatisation</h5><div class="mt-chips">${chip('ac', S.ac ? 'Marche' : 'Arrêt', S.ac)}${chip('t:-1', '−')}<button disabled>${S.temp} °C</button>${chip('t:1', '+')}</div>
      <h5>🪟 Vitres</h5><div class="mt-chips">${chip('tint', S.tint ? 'Teintées' : 'Claires', S.tint)}</div>
      <h5>🥤 Mini-bar (sans alcool)</h5><div class="mt-chips">${DRINKS.map(([k, l]) => chip(`drink:${k}`, l)).join('')}</div>
      <p class="tk-note">Limousine ${LIMO_ID} • plaque BENIN LIFE • ${S.km.toFixed(1).replace('.', ',')} km au compteur</p></div>`;
  }
  renderDash() {
    const c = this.car, S = this.st, on = this.player.inCar === c;
    this.dash.classList.toggle('show', on); if (!on) return;
    const html = `<b>🚘 ${LIMO_ID}</b><span>${Math.round(Math.abs(c.speed) * 3.6)} km/h</span><span>${S.km.toFixed(1).replace('.', ',')} km</span><button data-lm="ac" class="${S.ac ? 'on' : ''}">❄️ ${S.ac ? S.temp + ' °C' : 'off'}</button><button data-lm="ledOn" class="${S.ledOn ? 'on' : ''}">💡 LED</button><button data-lm="scrnext">📺 ${SCREENS[S.screen]}</button>`;
    if (html !== this._dash) { this.dash.innerHTML = html; this._dash = html; }
  }
  onClick(ev) {
    const b = ev.target.closest('[data-lm]'); if (!b) return; ev.stopPropagation();
    const [a, v] = b.dataset.lm.split(':'), S = this.st;
    if (a === 'out') return this.leaveSalon();
    if (a === 'ledOn') S.ledOn = !S.ledOn; else if (a === 'led') { S.led = v; S.ledOn = true; }
    else if (a === 'scr') S.screen = v; else if (a === 'scrnext') { const k = Object.keys(SCREENS); S.screen = k[(k.indexOf(S.screen) + 1) % k.length]; }
    else if (a === 'ac') S.ac = !S.ac; else if (a === 't') S.temp = Math.max(16, Math.min(26, S.temp + +v));
    else if (a === 'tint') S.tint = !S.tint;
    else if (a === 'drink') { if (this.needs) { this.needs.hunger = Math.min(100, this.needs.hunger + 4); this.needs.energy = Math.min(100, this.needs.energy + 2); } this.ui.toast(`${DRINKS.find((d) => d[0] === v)[1]} servi bien frais (sans alcool).`, 2); }
    this.applyState(); this.render(); this._dash = null; this.renderDash(); this.onSave && this.onSave();
  }
  handleKeys(input) { if (input.hit('Escape') || input.hit('KeyE')) this.leaveSalon(); }
  // ------------------------------------------------------------------ boucle
  update(dt) {
    const c = this.car;
    for (const [k, d] of Object.entries(this.doors)) {
      d.o += Math.sign(d.t - d.o) * Math.min(Math.abs(d.t - d.o), dt * 1.6);
      if (k === 'k') { this.trunk.rotation.x = d.o * 1.15; this.trunkIn.visible = d.o > 0.05; }
      else { const sd = this.sides[k]; sd.piv.rotation.y = -sd.s * d.o * 1.15; sd.view.visible = d.o > 0.05; }
    }
    // porte du garage : ouverture automatique quand la limousine approche
    const A = ANNEX, dx = c.pos.x - (A.x0 + A.x1) / 2, dz = c.pos.z - A.z0;
    if ((c.occupied || this.autoDoor) && Math.hypot(dx, dz) < 11) this.door.t = 1;
    this.door.o += Math.sign(this.door.t - this.door.o) * Math.min(Math.abs(this.door.t - this.door.o), dt * 0.6);
    this.doorMesh.scale.y = Math.max(0.04, 1 - this.door.o); this.doorMesh.position.y = this.door.o * 2.6; this.doorCol.disabled = this.door.o > 0.85;
    if (c.occupied || this.moving) { this.st.km += Math.abs(c.speed || this.moveSpeed || 0) * dt / 1000; }
    if (this.st.ledOn && this.st.led === 'rgb') this.ledMat.color.setHSL((performance.now() / 4000) % 1, 0.8, 0.55);
    this.scrT -= dt; if (this.scrT <= 0 && (this.cabin || Math.hypot(this.player.pos.x - c.pos.x, this.player.pos.z - c.pos.z) < 15)) { this.scrT = 0.25; this.drawScreen(); }
    this.renderDash();
  }
  // rangement au garage (chargement de partie, retour du chauffeur)
  park() { const c = this.car; c.pos.set(LIMO_SPOT.x, 0, LIMO_SPOT.z); c.heading = LIMO_SPOT.h; c.speed = 0; c.sync(); this.door.t = 0; }
  serialize() { return { ...this.st, doors: { l: this.doors.l.t, r: this.doors.r.t, k: this.doors.k.t } }; }
  restore(s) { if (!s) return; Object.assign(this.st, { led: s.led || 'violet', ledOn: s.ledOn !== false, ac: s.ac !== false, temp: s.temp || 21, screen: s.screen || 'musique', tint: s.tint !== false, km: s.km || 0 }); this.applyState(); this.park(); }
}
