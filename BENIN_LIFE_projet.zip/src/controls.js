// Mission 013, étape 5 — manette, volant et pédalier (API Gamepad du navigateur : aucun pilote ni module payant).
// Modes : automatique, clavier et souris, manette, volant et pédalier. Conduite analogique (accélérateur, frein, direction,
// embrayage pour la boîte manuelle des voitures), détection des axes et des boutons, sensibilité, zone morte, inversion
// des axes, boîte manuelle optionnelle (rapports 1–5, point mort, marche arrière). La manette pilote aussi tout le reste
// du jeu (marche, caméra, menus) en simulant les touches. Réglages enregistrés dans le navigateur.
const KEY = 'beninlife.controls';
const WHEEL_RE = /wheel|volant|racing|driving|g2[79]|g9[02]0|g923|t150|t300|tmx|t248|thrustmaster|fanatec|moza|simagic|logitech g|dfgt|momo/i;
const DEF = {
  mode: 'auto', steerSens: 1, steerDead: 0.03, pedalSens: 1, padDead: 0.18, manual: false, wheelIdx: -1,
  axes: { steer: { a: 0, inv: false }, gas: { a: 2, inv: false, r0: 1, r1: -1 }, brake: { a: 3, inv: false, r0: 1, r1: -1 }, clutch: { a: -1, inv: false, r0: 1, r1: -1 } },
  btn: { interact: 2, hb: 0, up: 4, down: 5, horn: 1, view: 3 },
};
export const GEARS = [-1, 0, 1, 2, 3, 4, 5];
const GEAR_MAX = { '-1': 7, 0: 0, 1: 9, 2: 15, 3: 21, 4: 26, 5: 30 }, GEAR_ACC = { '-1': 6, 0: 0, 1: 14, 2: 11, 3: 9, 4: 7, 5: 5.5 };
const clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));

export class Controls {
  constructor(ctx) {
    Object.assign(this, ctx); // input, ui, audio, player
    this.s = this.load(); this.owned = new Set(); this.prevBtn = {}; this.detect = null; this.last = { pads: [] }; this.gearT = 0;
    this.input.analog = { active: false, gas: 0, brake: 0, clutch: 0, steer: 0, hb: false, src: 'clavier', wheel: false };
    this.input.controls = this;
    addEventListener('gamepadconnected', (e) => { const w = WHEEL_RE.test(e.gamepad.id); this.ui && this.ui.toast(`${w ? '🛞 Volant / pédalier' : '🎮 Manette'} détecté : ${e.gamepad.id.slice(0, 60)}`, 3); this.render(); });
    addEventListener('gamepaddisconnected', (e) => { this.ui && this.ui.toast(`Périphérique débranché : ${e.gamepad.id.slice(0, 50)}`, 2.5); this.render(); });
    this.box = document.getElementById('ctl-config'); if (this.box) { this.box.addEventListener('click', (e) => this.onClick(e)); this.box.addEventListener('input', (e) => this.onInput(e)); this.box.addEventListener('change', (e) => this.onInput(e)); }
    this.gearEl = document.getElementById('gear'); this.render();
  }
  load() { try { const s = JSON.parse(localStorage.getItem(KEY) || '{}'); return { ...DEF, ...s, axes: { ...DEF.axes, ...(s.axes || {}) }, btn: { ...DEF.btn, ...(s.btn || {}) } }; } catch (e) { return JSON.parse(JSON.stringify(DEF)); } }
  save() { try { localStorage.setItem(KEY, JSON.stringify(this.s)); } catch (e) { /* stockage indisponible */ } }
  pads() { let list = []; try { list = Array.from((navigator.getGamepads && navigator.getGamepads()) || []).filter(Boolean); } catch (e) { list = []; } return list; }
  isWheel(p) { return WHEEL_RE.test(p.id) || (p.mapping !== 'standard' && p.axes.length >= 3); }
  device() { // périphérique utilisé selon le mode
    const ps = this.pads(), m = this.s.mode; if (m === 'kbd' || !ps.length) return { kind: 'kbd' };
    const wheel = (this.s.wheelIdx >= 0 && ps.find((p) => p.index === this.s.wheelIdx)) || ps.find((p) => this.isWheel(p)), pad = ps.find((p) => !this.isWheel(p)) || ps[0];
    if (m === 'wheel') return wheel || ps[0] ? { kind: 'wheel', p: wheel || ps[0] } : { kind: 'kbd' };
    if (m === 'pad') return pad ? { kind: 'pad', p: pad } : { kind: 'kbd' };
    return wheel ? { kind: 'wheel', p: wheel } : pad ? { kind: 'pad', p: pad } : { kind: 'kbd' };
  }
  // touches simulées (seulement celles que la manette a elle-même enfoncées)
  vkey(code, on) { if (on) { if (!this.owned.has(code)) { this.owned.add(code); this.input.setVirtual(code, true); } } else if (this.owned.has(code)) { this.owned.delete(code); this.input.setVirtual(code, false); } }
  releaseAll() { for (const c of [...this.owned]) this.vkey(c, false); }
  pedal(p, cfg) { if (cfg.a < 0 || cfg.a >= p.axes.length) return 0; const r = p.axes[cfg.a]; let v = cfg.r1 === cfg.r0 ? 0 : (r - cfg.r0) / (cfg.r1 - cfg.r0); v = clamp(v); if (cfg.inv) v = 1 - v; return clamp(Math.pow(v, 1 / this.s.pedalSens)); }
  steerOf(x, dead, sens, inv) { if (inv) x = -x; const a = Math.abs(x); if (a < dead) return 0; return Math.sign(x) * clamp(((a - dead) / (1 - dead)) * sens); }
  // ------------------------------------------------------------------ lecture à chaque image
  poll(dt) {
    const A = this.input.analog, d = this.device(); this.last.kind = d.kind; this.last.id = d.p ? d.p.id : '';
    if (this.detect) this.detectStep(d);
    if (d.kind === 'kbd') { A.active = false; A.src = 'clavier'; A.wheel = false; this.releaseAll(); this.gearHud(); return; }
    const p = d.p, b = (i) => !!(p.buttons[i] && (p.buttons[i].pressed || p.buttons[i].value > 0.5)), edge = (k, i) => { const now = b(i), was = this.prevBtn[k]; this.prevBtn[k] = now; return now && !was; };
    const car = this.player && this.player.inCar, road = !!(car && !car.isBoat && !car.isAircraft && !car.isHeli); // voitures et motos : valeurs progressives ; bateaux, avions : touches simulées
    if (d.kind === 'pad') {
      const dz = this.s.padDead, lx = Math.abs(p.axes[0] || 0) > dz ? p.axes[0] : 0, ly = Math.abs(p.axes[1] || 0) > dz ? p.axes[1] : 0, rx = Math.abs(p.axes[2] || 0) > dz ? p.axes[2] : 0, ry = Math.abs(p.axes[3] || 0) > dz ? p.axes[3] : 0;
      const rt = p.buttons[7] ? p.buttons[7].value : 0, lt = p.buttons[6] ? p.buttons[6].value : 0;
      A.active = !!car; A.wheel = false; A.src = 'manette'; A.gas = clamp(Math.pow(rt, 1 / this.s.pedalSens)); A.brake = clamp(Math.pow(lt, 1 / this.s.pedalSens)); A.clutch = 0; A.steer = this.steerOf(-(p.axes[0] || 0), dz, this.s.steerSens, false); A.hb = b(2);
      // à pied et dans les autres véhicules : touches simulées
      this.vkey('KeyW', road ? false : car ? rt > 0.35 : ly < -0.5); this.vkey('KeyS', road ? false : car ? lt > 0.35 : ly > 0.5); this.vkey('KeyA', !road && lx < -0.5); this.vkey('KeyD', !road && lx > 0.5);
      this.vkey('KeyE', b(0)); this.vkey('Escape', b(1) || b(9)); this.vkey('Space', b(2)); this.vkey(car ? 'KeyK' : 'KeyC', b(3)); this.vkey(car ? 'KeyC' : 'KeyK', false);
      this.vkey('ShiftLeft', b(10) || (!car && b(5))); this.vkey('KeyV', b(11)); this.vkey('KeyN', b(8));
      this.vkey('ArrowUp', b(12)); this.vkey('ArrowDown', b(13)); this.vkey('ArrowLeft', b(14)); this.vkey('ArrowRight', b(15));
      this.input.mouseDX += rx * 900 * dt; this.input.mouseDY += ry * 600 * dt;
      if (car && this.s.manual) { if (edge('up', 5)) this.shift(car, 1); if (edge('down', 4)) this.shift(car, -1); }
    } else {
      const s = this.s, ax = s.axes, B = s.btn, raw = ax.steer.a >= 0 ? p.axes[ax.steer.a] || 0 : 0;
      A.active = !!car; A.wheel = true; A.src = 'volant'; A.steer = this.steerOf(-raw, s.steerDead, s.steerSens, ax.steer.inv); A.gas = this.pedal(p, ax.gas); A.brake = this.pedal(p, ax.brake); A.clutch = this.pedal(p, ax.clutch); A.hb = b(B.hb);
      this.vkey('KeyW', !road && A.gas > 0.35); this.vkey('KeyS', !road && A.brake > 0.35); this.vkey('KeyA', !road && A.steer > 0.5); this.vkey('KeyD', !road && A.steer < -0.5);
      this.vkey('KeyE', b(B.interact)); this.vkey('Space', b(B.hb)); this.vkey('KeyK', b(B.horn)); this.vkey('KeyV', b(B.view));
      if (car && this.s.manual) { if (edge('up', B.up)) this.shift(car, 1); if (edge('down', B.down)) this.shift(car, -1); }
    }
    this.gearHud(); this.live();
  }
  // ------------------------------------------------------------------ boîte manuelle (voitures)
  compatible(car) { return !!(car && !car.isMoto && !car.isBoat && !car.isAircraft && !car.isHeli); }
  shift(car, dir) {
    if (!this.compatible(car)) return; const A = this.input.analog, hasClutch = A.wheel && this.s.axes.clutch.a >= 0;
    if (hasClutch && A.clutch < 0.6) { if (this.audio && this.audio.ctx) this.audio.tone(140, 0.12, 0.08, 'sawtooth'); this.ui && this.ui.toast('⚙️ Appuie sur l’embrayage pour changer de rapport.', 1.8); return; }
    const i = GEARS.indexOf(car.gear ?? 1), j = Math.max(0, Math.min(GEARS.length - 1, i + dir));
    if (GEARS[j] === -1 && car.speed > 1) { this.ui && this.ui.toast('Arrête-toi avant de passer la marche arrière.', 1.6); return; }
    car.gear = GEARS[j]; this.gearT = 1.2; if (this.audio && this.audio.ctx) this.audio.tone(320, 0.05, 0.05, 'square');
  }
  keyShift(input) { const car = this.player && this.player.inCar; if (!this.s.manual || !this.compatible(car)) return; if (input.hit('ShiftRight') || input.hit('PageUp')) this.shift(car, 1); if (input.hit('ControlRight') || input.hit('PageDown')) this.shift(car, -1); }
  // appliqué par la voiture : limites et force selon le rapport engagé
  manualDrive(car, gas, dt) {
    const g = car.gear ?? 1, A = this.input.analog, clutchIn = A.wheel && this.s.axes.clutch.a >= 0 ? A.clutch > 0.5 : false;
    if (g === 0 || clutchIn) return { drive: 0, cap: 99, g };
    const max = GEAR_MAX[g], acc = GEAR_ACC[g], v = g < 0 ? -car.speed : car.speed;
    const drive = gas > 0 ? acc * gas * clamp(1 - v / max, -0.5, 1) : 0; return { drive: g < 0 ? -drive : drive, cap: max, g };
  }
  gearHud() {
    if (!this.gearEl) return; const car = this.player && this.player.inCar, on = this.s.manual && this.compatible(car);
    this.gearEl.style.display = on ? 'block' : 'none'; if (!on) return; const g = car.gear ?? 1; this.gearEl.textContent = g === -1 ? 'R' : g === 0 ? 'N' : `${g}`;
    this.gearEl.classList.toggle('flash', this.gearT > 0); this.gearT = Math.max(0, this.gearT - 0.016);
  }
  // ------------------------------------------------------------------ détection d'un axe ou d'un bouton
  startDetect(kind, key) { const d = this.device(); if (!d.p) { this.ui && this.ui.toast('Aucun périphérique : branche-le et appuie sur un de ses boutons.', 3); return; } this.detect = { kind, key, rest: d.p.axes.slice(), btn0: d.p.buttons.map((x) => x.pressed), t: 0, best: null }; this.render(); }
  detectStep(d) {
    const D = this.detect; if (!d.p) return; D.t += 1 / 60;
    if (D.kind === 'axis') { let bi = -1, bv = 0; d.p.axes.forEach((v, i) => { const dv = Math.abs(v - (D.rest[i] ?? 0)); if (dv > bv) { bv = dv; bi = i; } }); if (bv > 0.5) { const cfg = this.s.axes[D.key]; cfg.a = bi; if (D.key !== 'steer') { cfg.r0 = D.rest[bi]; cfg.r1 = d.p.axes[bi] > D.rest[bi] ? 1 : -1; cfg.inv = false; /* pédale relâchée = position de repos, enfoncée = butée opposée */ } this.detect = null; this.save(); this.ui && this.ui.toast(`✅ Axe ${bi} associé (${({ steer: 'direction', gas: 'accélérateur', brake: 'frein', clutch: 'embrayage' })[D.key]}).`, 2.2); this.render(); } }
    else { const i = d.p.buttons.findIndex((x, k) => x.pressed && !D.btn0[k]); if (i >= 0) { this.s.btn[D.key] = i; this.detect = null; this.save(); this.ui && this.ui.toast(`✅ Bouton ${i} associé.`, 2); this.render(); } }
    if (this.detect && D.t > 8) { this.detect = null; this.ui && this.ui.toast('Détection annulée (aucun mouvement).', 2); this.render(); }
  }
  // ------------------------------------------------------------------ panneau de configuration (Commandes)
  render() {
    if (!this.box) return; const s = this.s, ps = this.pads(), d = this.device(), A = this.input.analog, lab = { auto: 'Automatique', kbd: 'Clavier et souris', pad: 'Manette', wheel: 'Volant et pédalier' };
    const axisSel = (k) => { const c = s.axes[k], n = Math.max(6, ...ps.map((p) => p.axes.length)); return `<select data-ax="${k}"><option value="-1"${c.a < 0 ? ' selected' : ''}>aucun</option>${Array.from({ length: n }, (_, i) => `<option value="${i}"${c.a === i ? ' selected' : ''}>axe ${i}</option>`).join('')}</select>`; };
    const row = (k, l) => `<div class="ctl-row"><span>${l}</span>${axisSel(k)}<label><input type="checkbox" data-inv="${k}"${s.axes[k].inv ? ' checked' : ''}> inverser</label><button data-det="axis:${k}">${this.detect && this.detect.key === k ? '… bouge-le' : 'Détecter'}</button><i class="ctl-bar"><b data-live="${k}"></b></i></div>`;
    const brow = (k, l) => `<div class="ctl-row"><span>${l}</span><em>bouton ${s.btn[k]}</em><button data-det="btn:${k}">${this.detect && this.detect.key === k ? '… appuie' : 'Détecter'}</button></div>`;
    this.box.innerHTML = `<h3>PÉRIPHÉRIQUES DE JEU</h3>
      <div class="ctl-modes">${Object.entries(lab).map(([k, l]) => `<button data-mode="${k}" class="${s.mode === k ? 'on' : ''}">${l}</button>`).join('')}</div>
      <p class="hint">En cours : <b>${d.kind === 'kbd' ? 'clavier et souris' : d.kind === 'pad' ? 'manette' : 'volant et pédalier'}</b>${d.p ? ` — ${d.p.id.slice(0, 70)}` : ''}. ${ps.length ? `${ps.length} périphérique(s) détecté(s).` : 'Aucun périphérique détecté : branche-le en USB (ou Bluetooth) puis appuie sur un de ses boutons, le navigateur ne le signale qu’après une première action.'}</p>
      <div class="ctl-row"><span>Sensibilité de la direction</span><input type="range" min="0.5" max="2" step="0.05" data-set="steerSens" value="${s.steerSens}"><em>${s.steerSens.toFixed(2)}</em></div>
      <div class="ctl-row"><span>Zone morte du volant</span><input type="range" min="0" max="0.2" step="0.01" data-set="steerDead" value="${s.steerDead}"><em>${s.steerDead.toFixed(2)}</em></div>
      <div class="ctl-row"><span>Sensibilité des pédales / gâchettes</span><input type="range" min="0.5" max="2" step="0.05" data-set="pedalSens" value="${s.pedalSens}"><em>${s.pedalSens.toFixed(2)}</em></div>
      <div class="ctl-row"><span>Zone morte des sticks (manette)</span><input type="range" min="0.05" max="0.4" step="0.01" data-set="padDead" value="${s.padDead}"><em>${s.padDead.toFixed(2)}</em></div>
      <div class="ctl-row"><span>Boîte manuelle (voitures)</span><label><input type="checkbox" data-set="manual"${s.manual ? ' checked' : ''}> rapports R, N, 1–5</label></div>
      <h3>VOLANT ET PÉDALIER — AXES</h3>${row('steer', 'Direction')}${row('gas', 'Accélérateur')}${row('brake', 'Frein')}${row('clutch', 'Embrayage')}
      <h3>VOLANT — BOUTONS</h3>${brow('interact', 'Entrer / sortir (E)')}${brow('hb', 'Frein à main')}${brow('up', 'Rapport +')}${brow('down', 'Rapport −')}${brow('horn', 'Klaxon')}${brow('view', 'Changer de vue')}
      <h3>MANETTE (disposition standard)</h3><p class="hint">Stick gauche : marcher / diriger • Stick droit : caméra • RT : accélérer • LT : freiner / reculer • A : entrer, interagir (E) • B : retour / pause • X : frein à main, sauter • Y : klaxon (en voiture) / carte • LB / RB : rapport − / + (boîte manuelle) • L3 : courir • R3 : changer de vue • Select : téléphone • Croix directionnelle : flèches.</p>
      <p class="hint">Clavier, boîte manuelle : Maj droite / Page haut = rapport +, Ctrl droit / Page bas = rapport −. Embrayage : obligatoire pour changer de rapport si un axe d’embrayage est associé, sinon automatique.</p>
      <button class="btn" data-reset="1">Réglages par défaut</button>`;
    this.live();
  }
  live() { // barres de valeurs en direct quand le panneau est ouvert
    if (!this.box || !this.box.offsetParent) return; const d = this.device(), A = this.input.analog, vals = d.kind === 'wheel' && d.p ? { steer: (A.steer + 1) / 2, gas: A.gas, brake: A.brake, clutch: A.clutch } : { steer: (A.steer + 1) / 2, gas: A.gas, brake: A.brake, clutch: 0 };
    for (const [k, v] of Object.entries(vals)) { const el = this.box.querySelector(`[data-live="${k}"]`); if (el) el.style.width = `${Math.round(clamp(v) * 100)}%`; }
  }
  onClick(e) {
    const b = e.target.closest('button'); if (!b) return; e.stopPropagation();
    if (b.dataset.mode) { this.s.mode = b.dataset.mode; this.releaseAll(); this.save(); this.render(); }
    else if (b.dataset.det) { const [k, key] = b.dataset.det.split(':'); this.startDetect(k === 'axis' ? 'axis' : 'btn', key); }
    else if (b.dataset.reset) { this.s = JSON.parse(JSON.stringify(DEF)); this.save(); this.render(); }
  }
  onInput(e) {
    const t = e.target, s = this.s;
    if (t.dataset.set) { s[t.dataset.set] = t.type === 'checkbox' ? t.checked : +t.value; this.save(); if (t.type !== 'range') this.render(); else { const em = t.parentElement.querySelector('em'); if (em) em.textContent = (+t.value).toFixed(2); } }
    else if (t.dataset.ax) { s.axes[t.dataset.ax].a = +t.value; this.save(); }
    else if (t.dataset.inv) { s.axes[t.dataset.inv].inv = t.checked; this.save(); }
  }
}
