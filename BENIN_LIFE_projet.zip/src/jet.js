// Mission 021, étape 3 — jet privé personnel : achat (modèles 3D existants de l'aéroport, noms fictifs), stationnement à
// l'aviation d'affaires, intérieur de luxe visitable et personnalisable (cuir, bois, moquette, éclairage LED, peinture
// extérieure), poste de pilotage, kitchenette, salon club, espace de réunion, divan, chambre et salle d'eau ; équipage
// (pilote, copilote, hôtesse ou steward) à recruter et rémunérer ; vols privés vers les 12 destinations (villes
// étrangères pas encore jouables : le jeu le dit à l'arrivée) ; inscrit au patrimoine et sauvegardé.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { colorize } from './vehicles.js';
import { createCharacter } from './character.js';
import { fcfa } from './food-data.js';
import { PLANE_BY_ID } from './aircraft-data.js';
import { buildPlaneMesh } from './airport.js';
import { DESTS, DEST_BY_ID, hh } from './travel-data.js';
import { TERM } from './terminal.js';

const PI = Math.PI;
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const pick = (a) => a[Math.floor(Math.random() * a.length)];
const dur = (h) => (h < 1 ? `${Math.round(h * 60)} min` : `${Math.floor(h)} h${Math.round((h % 1) * 60) ? ` ${String(Math.round((h % 1) * 60)).padStart(2, '0')}` : ''}`);
export const JETS = [ // prix fictifs du jeu (monnaie virtuelle)
  { id: 'faucon8x', price: 4500000000, seats: 12, range: 'environ 11 000 km', note: 'Triréacteur d’affaires, cabine de 3 espaces' },
  { id: 'gulfwing', price: 6000000000, seats: 14, range: 'environ 13 000 km', note: 'Biréacteur long-courrier, cabine de 4 espaces' },
];
const JET_BY_ID = Object.fromEntries(JETS.map((j) => [j.id, j]));
export const APRON = { x: -1000, z: 72, h: PI }; // aviation d'affaires (à l'est des postes des jets de l'aéroport)
export const JI = { LV: 200, Y: 720, O: { x: -1000, z: 72 } };
export const FIN = {
  cuir: { label: 'Cuir des sièges', c: { creme: ['Crème', 0xe8dcc0], cognac: ['Cognac', 0x9a5a2a], noir: ['Noir', 0x26262a], blanc: ['Blanc ivoire', 0xf4f0e6] } },
  bois: { label: 'Boiseries', c: { noyer: ['Noyer', 0x5a3a22], erable: ['Érable', 0xc8a070], ebene: ['Ébène', 0x2a1a12] } },
  tapis: { label: 'Moquette', c: { sable: ['Sable', 0xc8b89a], gris: ['Gris perle', 0x8a8a90], bleu: ['Bleu nuit', 0x1f2a44] } },
  led: { label: 'Éclairage LED', c: { chaud: ['Blanc chaud', 0xffc878], bleu: ['Bleu', 0x4aa8ff], violet: ['Violet', 0xa86aff], vert: ['Vert Bénin', 0x2fd08a], or: ['Or', 0xf2c200] } },
  ext: { label: 'Peinture extérieure', c: { blanc: ['Blanc nacré', 0xffffff], noir: ['Noir graphite', 0x55585e], champagne: ['Champagne', 0xeadcb8], vert: ['Vert Bénin', 0xb8e0c8] } },
};
const CUSTOM_FEE = 15000000;
const CREW = { // candidats fictifs ; salaire versé chaque semaine de jeu (7 jours)
  pilote: { label: 'Commandant de bord', list: [['p1', 'Commandant Gérard Akakpo', '18 ans de vol, 9 000 h', 2500000], ['p2', 'Commandante Inès Dossou', '14 ans de vol, 7 200 h', 2400000]] },
  copilote: { label: 'Copilote', list: [['c1', 'Copilote Fabrice Agossou', '6 ans de vol, 3 100 h', 1600000], ['c2', 'Copilote Laure Hounsa', '5 ans de vol, 2 600 h', 1500000]] },
  hotesse: { label: 'Hôtesse ou steward', list: [['h1', 'Hôtesse Carine Sossa', 'Service VIP, 8 ans', 800000], ['h2', 'Steward Romaric Tchibozo', 'Service VIP, 6 ans', 750000]] },
};
const CREW_BY_ID = {}; for (const [role, R] of Object.entries(CREW)) for (const [id, name, xp, pay] of R.list) CREW_BY_ID[id] = { id, role, name, xp, pay };
const COST_H = 3500000; // carburant, redevances et assistance au sol par heure de vol (fictif)

export class Jet {
  constructor(ctx) {
    Object.assign(this, ctx); // T, F, scene, world, player, ui, audio, env, economy, needs, tpc, home, bizUI, fortune, onSave
    this.own = null; this.reg = 'TY-NVA'; this.cfg = { cuir: 'creme', bois: 'noyer', tapis: 'sable', led: 'chaud', ext: 'blanc' }; this.crew = {}; this.lastPay = null; this.trip = null; this.abroad = null; this.flights = 0;
    this.inside = false; this.seated = false; this.points = []; this.people = []; this.view = 'info';
    if (this.fortune) this.fortune.jet = this;
    if (this.T) { this.T.jet = this; if (this.T._jet) this.restore(this.T._jet); this.T.points.push({ x: -45.5, z: 18.6, r: 1.3, label: 'Navette vers mon jet privé (aviation d’affaires)', action: () => this.shuttle() }); }
    this.dom = document.getElementById('sitbar');
    if (this.dom) this.dom.addEventListener('click', (e) => { const b = e.target.closest('[data-jt]'); if (b) { e.stopPropagation(); this.act(b.dataset.jt); } });
    this.ig = new THREE.Group(); this.ig.position.set(JI.O.x, JI.Y, JI.O.z); this.ig.visible = false; this.scene.add(this.ig);
    this.winMat = new THREE.MeshBasicMaterial({ color: 0x9aa6b0, toneMapped: false });
    this.buildExterior(); this.buildInterior(); this.addPoi();
  }
  spec() { return this.own ? PLANE_BY_ID[this.own] : null; }
  value() { return this.own ? Math.round(JET_BY_ID[this.own].price * 0.9) : 0; } // valeur estimée au patrimoine
  abs() { return this.T.abs(); }
  save() { this.onSave && this.onSave(); }
  col(k) { return FIN[k].c[this.cfg[k]][1]; }
  hasPilots() { return !!(this.crew.pilote && this.crew.copilote); }
  // ------------------------------------------------------------------ extérieur : jet garé à l'aviation d'affaires
  buildExterior() {
    if (this.ext) { this.scene.remove(this.ext.group); this.ext = null; } if (this.box) this.box.disabled = true;
    const sp = this.spec(); if (!sp) return;
    const parts = buildPlaneMesh(sp); parts.group.position.set(APRON.x, 0, APRON.z); parts.group.rotation.y = APRON.h; this.scene.add(parts.group); this.ext = parts;
    parts.body.material = parts.body.material.clone(); this.tint();
    const C = this.world.collision; if (!this.box) { this.box = C.addBox(APRON.x - sp.r, APRON.z - sp.len / 2, APRON.x + sp.r, APRON.z + sp.len / 2, sp.centerY + sp.r); }
    else { Object.assign(this.box, { minX: APRON.x - sp.r, minZ: APRON.z - sp.len / 2, maxX: APRON.x + sp.r, maxZ: APRON.z + sp.len / 2 }); }
    parts.group.updateMatrixWorld(true); const d = parts.door.clone(); parts.group.localToWorld(d); this.doorW = { x: d.x, z: d.z };
    this.syncExt();
  }
  tint() { if (this.ext) this.ext.body.material.color.setHex(this.col('ext')); }
  syncExt() { const away = !!(this.trip || this.abroad); if (this.ext) this.ext.group.visible = !away; if (this.box) this.box.disabled = away || !this.own; }
  // ------------------------------------------------------------------ intérieur (reconstruit à chaque personnalisation)
  buildInterior() {
    const g = this.ig; for (const m of [...g.children]) if (m.isMesh && m.userData.jet) { g.remove(m); m.geometry.dispose(); }
    for (const o of this.solids || []) o.disabled = true; this.solids = []; this.points = [];
    const { LV, Y, O } = JI, C = this.world.collision, H = 2.0, parts = [], glow = [], win = [];
    const L = this.col('cuir'), W = this.col('bois'), T = this.col('tapis'), LED = this.col('led'), wall = 0xf2efe8;
    const box = (x0, y0, z0, x1, y1, z1, c, arr = parts) => arr.push(colorize(new THREE.BoxGeometry(Math.abs(x1 - x0) || 0.01, Math.abs(y1 - y0) || 0.01, Math.abs(z1 - z0) || 0.01).translate((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), c));
    const solid = (x0, z0, x1, z1, h = H) => { const o = C.addBox(O.x + Math.min(x0, x1), O.z + Math.min(z0, z1), O.x + Math.max(x0, x1), O.z + Math.max(z0, z1), Y + h); o.lv = LV; this.solids.push(o); return o; };
    const P = (x, z, r, label, action) => this.points.push({ x, z, r, label, action });
    const arm = (x, z, face) => { const b = face > 0 ? -1 : 1; box(x - 0.32, 0.22, z - 0.3, x + 0.32, 0.46, z + 0.3, L); box(x + b * 0.32 - 0.07, 0.22, z - 0.3, x + b * 0.32 + 0.07, 1.05, z + 0.3, L); for (const s of [-1, 1]) box(x - 0.3, 0.46, z + s * 0.3 - 0.05, x + 0.3, 0.62, z + s * 0.3 + 0.05, W); solid(x - 0.38, z - 0.33, x + 0.38, z + 0.33, 1.05); };
    // coque, moquette, bandeaux LED, hublots ovales
    box(-9.2, -0.1, -1.4, 11.2, 0, 1.4, T);
    for (const s of [-1, 1]) { box(-9.2, 0, s * 1.3, 11.2, H, s * 1.42, wall); solid(-9.2, s * 1.3, 11.2, s * 1.42); box(-9, 0, s * 1.22, 9, 0.12, s * 1.3, W); box(-9, 0.12, s * 1.25, 9, 0.15, s * 1.29, LED, glow); }
    box(-9.3, 0, -1.42, -9.2, H, 1.42, wall); solid(-9.3, -1.42, -9.2, 1.42); box(11.1, 0, -1.42, 11.2, H, 1.42, wall); solid(11.1, -1.42, 11.2, 1.42);
    for (let x = -7.8; x <= 8.2; x += 1.15) for (const s of [-1, 1]) if (Math.abs(x - 7.8) > 0.6 || s > 0) box(x - 0.2, 0.85, s * 1.29, x + 0.2, 1.3, s * 1.3, 0xffffff, win);
    // poste de pilotage (x 9,2–11) derrière une cloison avec passage
    for (const s of [-1, 1]) { box(9.15, 0, s * 0.42, 9.25, H, s * 1.3, wall); solid(9.15, s * 0.42, 9.25, s * 1.3); }
    box(10.55, 0, -1.2, 11.1, 0.75, 1.2, 0x2a2d33); box(10.6, 0.75, -1.1, 11.0, 1.05, 1.1, 0x1a2430); solid(10.55, -1.2, 11.1, 1.2, 1.05); box(10.62, 0.8, -1.0, 10.64, 1.0, 1.0, 0x4aa8ff, glow);
    for (const s of [-1, 1]) { box(9.75, 0.2, s * 0.55 - 0.25, 10.25, 0.45, s * 0.55 + 0.25, 0x3a3d42); box(9.62, 0.2, s * 0.55 - 0.25, 9.75, 1.1, s * 0.55 + 0.25, 0x3a3d42); solid(9.6, s * 0.55 - 0.27, 10.25, s * 0.55 + 0.27, 1.1); }
    P(9.6, 0, 0.6, 'Poste de pilotage : plan de vol', () => this.planMenu());
    // porte d'entrée (gauche) et kitchenette (droite)
    box(7.3, 0, -1.43, 8.3, 1.85, -1.41, 0x8a8f96); P(7.8, -0.75, 0.75, 'Porte du jet', () => this.door());
    box(6.0, 0, 0.6, 7.6, 0.95, 1.3, W); box(5.98, 0.95, 0.58, 7.62, 1.0, 1.3, 0xf2f0ea); box(6.3, 1.0, 1.0, 6.6, 1.3, 1.25, 0x1a1a1e); box(7.0, 1.0, 1.05, 7.3, 1.2, 1.22, 0xc8ccd2); solid(6.0, 0.6, 7.6, 1.3, 1.0);
    P(6.8, 0.15, 0.7, 'Kitchenette : boissons et collation', () => this.galley());
    // salon club : 4 fauteuils face à face et tablettes
    for (const s of [-1, 1]) { arm(4.9, s * 0.78, -1); arm(3.3, s * 0.78, 1); box(3.85, 0.62, s * 0.78 - 0.32, 4.35, 0.66, s * 0.78 + 0.32, W); box(4.05, 0, s * 0.78 - 0.05, 4.15, 0.62, s * 0.78 + 0.05, W); solid(3.85, s * 0.78 - 0.32, 4.35, s * 0.78 + 0.32, 0.7); }
    this.mySeat = { x: 3.3, z: -0.78, h: PI / 2 };
    P(3.3, -0.25, 0.55, 'S’asseoir dans le salon club', () => this.sit()); P(3.3, 0.25, 0.55, 'S’asseoir dans le salon club', () => this.sit({ x: 3.3, z: 0.78, h: PI / 2 }));
    // espace de réunion : table et 4 sièges (gauche), crédence et écran (droite)
    box(0.5, 0.7, -1.2, 1.9, 0.76, -0.45, W); box(1.15, 0, -0.9, 1.25, 0.7, -0.8, W); solid(0.5, -1.2, 1.9, -0.45, 0.8);
    arm(-0.05, -0.85, 1); arm(2.45, -0.85, -1);
    box(-0.2, 0, 0.85, 2.6, 0.75, 1.25, W); box(-0.21, 0.75, 0.84, 2.61, 0.78, 1.26, 0xf2f0ea); solid(-0.2, 0.85, 2.6, 1.25, 0.8); box(0.5, 0.95, 1.2, 1.9, 1.75, 1.24, 0x0a0a0c); box(0.55, 1.0, 1.19, 1.85, 1.7, 1.2, 0x16324a, glow);
    P(1.2, -0.2, 0.6, 'Table de réunion (NOVA Gestion)', () => { if (this.bizUI) this.bizUI.toggle(true); });
    // divan et fauteuils
    box(-3.7, 0.22, 0.7, -1.1, 0.48, 1.22, L); box(-3.7, 0.48, 1.05, -1.1, 0.95, 1.22, L); solid(-3.7, 0.7, -1.1, 1.22, 0.95); arm(-2.4, -0.85, 1);
    P(-2.4, 0.25, 0.6, 'Divan : se détendre, regarder un film', () => this.lounge());
    // chambre (cloison avec porte) : lit double, chevets
    for (const [z0, z1] of [[-1.3, -0.42], [0.42, 1.3]]) { box(-4.3, 0, z0, -4.2, H, z1, W); solid(-4.3, z0, -4.2, z1); }
    box(-7.6, 0, -1.25, -5.1, 0.45, 0.3, W); box(-7.55, 0.45, -1.2, -5.15, 0.6, 0.25, 0xf6f4ee); box(-7.6, 0.45, -1.25, -7.4, 1.0, 0.3, L); box(-6.4, 0.6, -1.2, -5.2, 0.63, 0.25, this.col('tapis') === 0xc8b89a ? 0x6a1a2a : 0xd8c8a8); solid(-7.6, -1.25, -5.1, 0.3, 0.65);
    for (const z of [-1.0]) { box(-5.05, 0, z - 0.2, -4.6, 0.5, z + 0.2, W); solid(-5.05, z - 0.2, -4.6, z + 0.2, 0.5); }
    P(-6.3, 0.75, 0.7, 'Chambre : dormir', () => this.bed());
    // salle d'eau
    box(-8.1, 0, -1.3, -8.0, H, 0.4, wall); solid(-8.1, -1.3, -8.0, 0.4); box(-9.1, 0, -1.25, -8.2, 0.85, -0.5, 0xf6f6f6); solid(-9.1, -1.25, -8.2, -0.5, 0.9);
    P(-8.6, 0.8, 0.55, 'Salle d’eau : douche', () => this.shower());
    const mk = (arr, m) => { const ms = new THREE.Mesh(mergeGeometries(arr), m); ms.receiveShadow = true; ms.userData.jet = 1; g.add(ms); };
    mk(parts, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.55 })); mk(glow, new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false })); mk(win, this.winMat);
    for (const o of this.solids) o.disabled = !this.own;
  }
  // ------------------------------------------------------------------ achat, personnalisation, équipage
  buy(id) {
    const J = JET_BY_ID[id], sp = PLANE_BY_ID[id]; if (!J) return; if (this.own === id) return this.ui.toast('Tu possèdes déjà ce jet.', 2);
    if (this.trip || this.abroad) return this.ui.toast('Ton jet est en voyage.', 2);
    const trade = this.own ? this.value() : 0, cost = J.price - trade;
    if (!this.economy.pay(cost, `Achat du jet privé ${sp.name}${trade ? ' (reprise de l’ancien jet déduite)' : ''}`, 'Aviation d’affaires de Cotonou (fictive)')) return this.ui.toast('Solde insuffisant.', 2.5);
    this.own = id; this.buildExterior(); this.buildInterior(); this.T.spend('Jet privé', cost, `Achat ${sp.name}`); this.addPoi();
    this.ui.toast(`✈️ Félicitations ! Ton ${sp.name} immatriculé ${this.reg} t’attend à l’aviation d’affaires. Recrute un pilote et un copilote pour voler.`, 6); this.save();
  }
  addPoi() { const pois = this.ui.pois; if (!pois || !this.own || pois.some((q) => q.id === 'jetprive')) return; pois.push({ id: 'jetprive', name: 'Mon jet privé (aviation d’affaires)', cat: 'transport', x: APRON.x + 6, z: APRON.z + 18, status: 'fictif', access: true, address: 'Aéroport de Cotonou', note: 'Stationnement fictif' }); }
  custom(k, v) {
    if (!FIN[k] || !FIN[k].c[v] || this.cfg[k] === v) return; if (!this.own) return this.ui.toast('Achète d’abord un jet.', 2);
    if (!this.economy.pay(CUSTOM_FEE, `Personnalisation du jet : ${FIN[k].label} ${FIN[k].c[v][0]}`, 'Atelier d’aménagement (fictif)')) return;
    this.cfg[k] = v; this.T.spend('Jet privé', CUSTOM_FEE, `${FIN[k].label} : ${FIN[k].c[v][0]}`); if (k === 'ext') this.tint(); else this.buildInterior();
    this.ui.toast(`🎨 ${FIN[k].label} : ${FIN[k].c[v][0]}.`, 2); this.save();
  }
  hire(id) { const c = CREW_BY_ID[id]; if (!c || !this.own) return; if (this.crew[c.role] === id) return; this.crew[c.role] = id; if (this.lastPay === null) this.lastPay = this.economy.day; this.ui.toast(`🤝 ${c.name} rejoint ton équipage (${fcfa(c.pay)} par semaine).`, 3); if (this.inside) this.spawnCrew(); this.save(); }
  fire(role) { const c = CREW_BY_ID[this.crew[role]]; if (!c) return; if (this.trip) return this.ui.toast('Impossible pendant un vol.', 2); delete this.crew[role]; this.ui.toast(`${c.name} quitte ton équipage.`, 2.5); if (this.inside) this.spawnCrew(); this.save(); }
  payroll() {
    const d = this.economy.day; if (this.lastPay === null || d - this.lastPay < 7) return; this.lastPay = d;
    let tot = 0; for (const id of Object.values(this.crew)) tot += CREW_BY_ID[id].pay; if (tot && this.economy.pay(tot, 'Salaires de l’équipage du jet (semaine)', 'Jet privé')) this.T.spend('Équipage', tot, 'Salaires de la semaine');
  }
  // ------------------------------------------------------------------ monter à bord / descendre
  shuttle() {
    if (!this.own) return this.ui.toast('Tu n’as pas encore de jet privé : NOVA TRAVEL, onglet « Mon jet ».', 3);
    if (this.trip || this.abroad) return this.ui.toast('Ton jet est actuellement en voyage.', 2.5);
    this.ui.fade && this.ui.fade(true); setTimeout(() => { this.T.exit(true); this.outside(); this.ui.fade && this.ui.fade(false); this.ui.toast(`🚐 La navette te dépose au pied de ton ${this.spec().name}.`, 2.5); }, 650);
  }
  outside() { const pl = this.player, d = this.doorW; pl.pos.set(d.x, 0, d.z); pl.floorY = 0; pl.vy = 0; pl.facing = 0; pl.mesh.position.copy(pl.pos); if (this.tpc && this.tpc.snap) this.tpc.snap(pl.pos); }
  enter(seated) {
    const { Y, LV, O } = JI, pl = this.player; this.inside = true; this.ig.visible = true; this.world.collision.level = LV; pl.floorY = Y; pl.vy = 0;
    pl.pos.set(O.x + 7.8, Y, O.z - 0.6); pl.facing = -PI / 2; pl.mesh.position.copy(pl.pos); if (this.tpc) { this.tpc.yaw = PI / 2; this.tpc.snap && this.tpc.snap(pl.pos); }
    this.spawnCrew(); if (this.F) this.F.hum(true); this._ann = {};
    if (seated) this.sit(); else this.ui.toast(`✈️ À bord de ton ${this.spec().name} (${this.reg}).${this.hasPilots() ? ' Plan de vol au poste de pilotage.' : ' Recrute un pilote et un copilote (NOVA TRAVEL, « Mon jet ») pour voler.'}`, 4);
  }
  leave() {
    if (this.seated) this.unsit(true); this.inside = false; this.ig.visible = false; this.world.collision.level = 0; this.player.floorY = 0; this.clearPeople(); if (this.F) this.F.hum(false); this.ui.setActivity && this.ui.setActivity(''); if (this.T) this.T.lightOff();
  }
  door() {
    const ph = this.phase();
    if (ph && ph !== 'landed') return this.ui.toast(ph === 'board' ? '🚪 Porte fermée : préparation du départ.' : '🚪 Porte verrouillée en vol.', 2.5);
    if (this.abroad && !this.trip) return this.arrivalMenu();
    if (this.trip && this.trip.back) { this.trip = null; this.abroad = null; this.syncExt(); this.save(); }
    this.ui.fade && this.ui.fade(true); setTimeout(() => { this.leave(); this.outside(); this.ui.fade && this.ui.fade(false); this.ui.toast('Tu descends la passerelle de ton jet.', 2); }, 500);
  }
  clearPeople() { for (const p of this.people) p.c.group.parent && p.c.group.parent.remove(p.c.group); this.people = []; }
  spawnCrew() {
    this.clearPeople(); const add = (o, d) => { const c = createCharacter(o); this.ig.add(c.group); const p = { c, ...d }; c.group.position.set(p.x, 0, p.z); c.group.rotation.y = p.h; this.people.push(p); return p; };
    for (const [role, z] of [['pilote', -0.55], ['copilote', 0.55]]) { const c = CREW_BY_ID[this.crew[role]]; if (!c) continue; const p = add({ female: /Commandante|Laure/.test(c.name), shirtColor: 0xf6f6f6, jacket: true, pants: 0x0a1a3a, tie: true, collar: true, hat: 'cap', hatColor: 0x0a1a3a }, { x: 10.0, z, h: PI / 2, name: c.name, role }); p.c.sit(false); p.c.group.position.y = -0.1; }
    const h = CREW_BY_ID[this.crew.hotesse]; if (h) add({ female: /Hôtesse/.test(h.name), shirtColor: 0x6a1a2a, jacket: true, collar: true, skirt: /Hôtesse/.test(h.name), pants: 0x1a1d24 }, { x: 6.8, z: 0.3, h: -PI / 2, name: h.name, role: 'hotesse' });
  }
  // ------------------------------------------------------------------ s'asseoir et activités à bord
  sit(s) {
    s = s || this.mySeat; const pl = this.player, { O, Y } = JI; this.seated = s; pl.pos.set(O.x + s.x - 0.06, Y, O.z + s.z); pl.facing = s.h; pl.mesh.position.set(pl.pos.x, Y - 0.12, pl.pos.z); pl.mesh.rotation.set(0, s.h, 0);
    if (pl.char && pl.char.sit) pl.char.sit(false); if (this.tpc) this.tpc.yaw = -PI / 2 + (s.z > 0 ? 0.5 : -0.5); this.bar(true);
  }
  unsit(force) {
    const ph = this.phase(); if (!force && (ph === 'takeoff' || ph === 'descent')) return this.ui.toast('🔔 Ceinture attachée pendant le décollage et la descente.', 2.5);
    const s = this.seated, pl = this.player, { O, Y } = JI; if (!s) return; this.seated = false; if (pl.char && pl.char.stand) pl.char.stand();
    pl.pos.set(O.x + s.x, Y, O.z + Math.sign(s.z) * 0.2); pl.mesh.position.copy(pl.pos); pl.mesh.rotation.set(0, pl.facing, 0); if (this.dom) this.dom.classList.remove('show');
  }
  actions() {
    const ph = this.phase(), out = [];
    if (!this.trip) { if (this.abroad) out.push(['arr', '🛬 Arrivée']); else out.push(['plan', '🗺️ Plan de vol']); }
    else if (ph === 'board') out.push(['wait', '⏳ Décollage']);
    if (ph !== 'landed' && this.trip) out.push(['skip', '⏩ Atterrir']);
    if (ph === 'landed') out.push(['door', this.trip && this.trip.back ? '🚶 Débarquer' : '🛬 Arrivée']);
    out.push(['meal', '🍽️ Service'], ['biz', '📊 Gestion'], ['info', 'ℹ️ Vol']); if (ph !== 'takeoff' && ph !== 'descent') out.push(['up', '🚶 Debout']); return out;
  }
  bar(force) { if (!this.dom || !this.seated) return; const k = this.actions().map((a) => a[0]).join(); if (!force && this._bk === k && this.dom.classList.contains('show')) return; this._bk = k; this.dom.innerHTML = this.actions().map(([a, l]) => `<button data-jt="${a}">${l}</button>`).join(''); this.dom.classList.add('show'); }
  act(k) {
    const t = this.trip;
    if (k === 'up') return this.unsit(); if (k === 'plan') return this.planMenu(); if (k === 'arr') return this.arrivalMenu(); if (k === 'door') return this.door();
    if (k === 'meal') return this.galley(); if (k === 'biz') return this.bizUI && this.bizUI.toggle(true); if (k === 'info') return this.info();
    if (k === 'wait' && t) return this.wait(t.dep, '🛫 Décollage !');
    if (k === 'skip' && t) return this.wait(t.arr + 0.005, null);
  }
  wait(target, msg, after) {
    const hrs = target - this.abs(); if (!(hrs > 0.01)) { after && after(); return; } if (hrs > 20) return;
    this.ui.fade && this.ui.fade(true);
    setTimeout(() => { this.env.time = (this.env.time + hrs) % 24; if (this.economy.update) this.economy.update(0); const n = this.needs; if (n) { n.hunger = Math.max(5, n.hunger - hrs * 1.2); n.hygiene = Math.max(5, n.hygiene - hrs * 0.6); n.energy = Math.min(100, n.energy + hrs * 2); } this.ui.fade && this.ui.fade(false); if (msg) this.ui.toast(msg, 3); after && after(); }, 600);
  }
  galley() { if (this.needs) this.needs.hunger = Math.min(100, this.needs.hunger + 30); const h = CREW_BY_ID[this.crew.hotesse]; this.env.time = (this.env.time + 0.2) % 24; this.ui.toast(h ? `🍽️ ${h.name} te sert un plateau gastronomique et un jus de baobab (sans alcool).` : '🍽️ Tu te sers à la kitchenette : collation et jus de fruits (sans alcool).', 3.5); }
  lounge() { this.wait(this.abs() + (this.trip ? Math.min(2, Math.max(0, this.trip.arr - 0.45 - this.abs())) : 2), '🎬 Film terminé sur l’écran du salon (programme fictif). Détente +', () => { if (this.needs) this.needs.energy = Math.min(100, this.needs.energy + 10); }); }
  bed() { const h = this.trip ? Math.max(0, Math.min(6, this.trip.arr - 0.45 - this.abs())) : 3; if (h < 0.3) return this.ui.toast('Pas le temps de dormir : nous approchons.', 2.5); this.wait(this.abs() + h, '😴 Tu te réveilles reposé dans la chambre de ton jet.', () => { if (this.needs) this.needs.energy = Math.min(100, this.needs.energy + 45); }); }
  shower() { if (this.needs) this.needs.hygiene = 100; this.env.time = (this.env.time + 0.25) % 24; this.ui.toast('🚿 Douche rafraîchissante dans la salle d’eau du jet.', 2.5); }
  info() {
    const t = this.trip, a = this.abs(); if (!t) return this.ui.toast(`ℹ️ ${this.spec().name} ${this.reg} • ${this.abroad ? `au sol à ${DEST_BY_ID[this.abroad].city}` : 'au sol à Cotonou'} • équipage : ${Object.values(this.crew).map((id) => CREW_BY_ID[id].name).join(', ') || 'aucun'}`, 5);
    const D = DEST_BY_ID[t.dest], ph = this.phase(); this.ui.toast(`ℹ️ Vol privé ${this.reg} • ${t.back ? `${D.city} → Cotonou` : `Cotonou → ${D.city}`} • ${{ board: `départ ${hh(t.dep)}`, takeoff: 'décollage', cruise: 'croisière', descent: 'descente', landed: 'au sol' }[ph]}${ph !== 'landed' ? ` • arrivée dans ${dur(Math.max(0, t.arr - a))}` : ''} • heure de Cotonou ${this.env.clock}${!t.back ? ` • heure locale ${hh(this.env.time + D.tz)}${D.dst ? ' (hiver)' : ''}` : ''}`, 6);
  }
  // ------------------------------------------------------------------ vols privés
  cost(D) { return Math.round(D.dur * 0.95 * COST_H / 100000) * 100000; }
  planMenu() {
    if (this.trip) return this.info(); if (this.abroad) return this.arrivalMenu();
    if (!this.hasPilots()) return this.ui.toast('🧑‍✈️ Il faut un commandant de bord et un copilote : recrute-les dans NOVA TRAVEL, onglet « Mon jet ».', 4);
    this.ui.openMenu(`🗺️ Plan de vol — ${this.spec().name} ${this.reg}`, 'Départ 15 min après validation • coûts : carburant, redevances, assistance (fictifs) • villes étrangères pas encore jouables', DESTS.map((D) => ({ label: `${D.city} (${D.country})`, desc: `environ ${dur(D.dur * 0.95)} • ${fcfa(this.cost(D))}`, action: () => this.fly(D, false) })));
  }
  fly(D, back) {
    const c = this.cost(D); if (!this.economy.pay(c, `Vol privé ${back ? `${D.city} → Cotonou` : `Cotonou → ${D.city}`} (carburant, redevances)`, 'Jet privé')) return this.ui.toast('Solde insuffisant.', 2);
    const a = this.abs(); if (back) this.abroad = null; this.trip = { dest: D.id, back, dep: a + 0.25, arr: a + 0.25 + D.dur * 0.95 }; this.flights++; this.T.spend('Jet privé', c, `Vol privé ${back ? 'retour de' : 'vers'} ${D.city}`); this._ann = {}; this.syncExt(); this.save();
    if (!this.seated) this.sit(); this.ui.toast(`🧑‍✈️ ${CREW_BY_ID[this.crew.pilote].name} : « Plan de vol déposé pour ${back ? 'Cotonou' : D.city}, départ à ${hh(this.env.time + 0.25)}. »`, 4);
  }
  arrivalMenu() {
    const D = DEST_BY_ID[this.abroad]; if (!D) return;
    this.ui.openMenu(`🛬 ${D.city} (${D.country}) — jet privé`, `Heure locale ${hh(this.env.time + D.tz)}${D.dst ? ' (hiver)' : ''}. Ville pas encore jouable dans le jeu.`, [
      { label: `🧭 Découvrir ${D.city}`, desc: 'Pas encore jouable', action: () => this.ui.toast(`🧭 ${D.city} n’est pas encore développée dans BENIN LIFE : les séjours à l’étranger arriveront dans une prochaine étape, sous forme d’aperçus annoncés comme tels.`, 6) },
      { label: '✈️ Rentrer à Cotonou en vol privé', desc: `environ ${dur(D.dur * 0.95)} • ${fcfa(this.cost(D))}`, action: () => this.fly(D, true) },
      { label: 'Rester à bord pour le moment', action: () => {} }]);
  }
  phase() { const t = this.trip; if (!t) return null; const a = this.abs(); return a < t.dep ? 'board' : a < t.dep + 0.2 ? 'takeoff' : a < t.arr - 0.35 ? 'cruise' : a < t.arr ? 'descent' : 'landed'; }
  announce(k, m) { if (this._ann[k]) return; this._ann[k] = 1; this.ui.toast(m, 4.5); }
  // ------------------------------------------------------------------ interactions, boucle
  nearest(x, z) {
    if (!this.own) return null;
    if (!this.inside) { if (!this.doorW || this.trip || this.abroad || this.player.floorY > 1) return null; const d = Math.hypot(x - this.doorW.x, z - this.doorW.z); return d < 3 ? { d, it: { label: () => `Monter à bord de mon ${this.spec().name}`, action: () => { this.ui.fade && this.ui.fade(true); setTimeout(() => { this.enter(false); this.ui.fade && this.ui.fade(false); }, 500); } } } : null; }
    if (this.seated) return null; const O = JI.O; let best = null;
    for (const p of this.points) { const d = Math.hypot(x - (O.x + p.x), z - (O.z + p.z)); if (d < p.r && (!best || d < best.d)) best = { d, it: { label: () => p.label, action: p.action } }; }
    for (const p of this.people) { const d = Math.hypot(x - (O.x + p.x), z - (O.z + p.z)); if (d < 1.1 && (!best || d < best.d - 0.2)) best = { d, it: { label: () => `Parler à ${p.name}`, action: () => this.ui.toast(`${p.name} : « ${p.role === 'hotesse' ? pick(['Que puis-je vous servir, monsieur le Président ?', 'Le salon est prêt, bon voyage !']) : pick(['Tout est prêt, nous partons dès que vous le souhaitez.', 'La météo est bonne sur notre route.', 'Check-list terminée.'])} »`, 3) } }; }
    return best;
  }
  handleKeys(input) { if (input.hit('KeyE') || input.hit('Escape')) this.unsit(); }
  zoneLabel() { if (!this.inside) return null; const t = this.trip; return t ? `Vol privé — ${t.back ? `${DEST_BY_ID[t.dest].city} → Cotonou` : `Cotonou → ${DEST_BY_ID[t.dest].city}`}` : this.abroad ? `Mon jet — au sol à ${DEST_BY_ID[this.abroad].city}` : 'Mon jet privé'; }
  update(dt) {
    this._pc = (this._pc || 0) - dt; if (this._pc < 0) { this._pc = 5; this.payroll(); }
    if (!this.inside) { if ((this.trip || this.abroad) && this.resume && !this.T.inside && !(this.F && this.F.inside)) { this.resume = false; this.enter(true); } return; }
    const P = this.player.pos; if (Math.abs((P.y || JI.Y) - JI.Y) > 6 || Math.hypot(P.x - JI.O.x, P.z - JI.O.z) > 30) { this.inside = false; this.ig.visible = false; this.world.collision.level = 0; this.player.floorY = 0; this.seated = false; this.clearPeople(); if (this.F) this.F.hum(false); this.ui.setActivity && this.ui.setActivity(''); return; }
    const t = this.trip, ph = this.phase(), tm = this.env.time, LED = this.col('led');
    const ls = this.home && this.home.lights; if (ls) { if (this.T && !this.T._orig) this.T._orig = ls.map((l) => ({ p: l.position.clone(), d: l.distance })); ls.forEach((l, i) => { l.position.set(P.x - 4 + i * 4, JI.Y + 1.8, JI.O.z + (i === 1 ? 0.6 : -0.6)); l.distance = 10; l.decay = 1.2; l.intensity = 2.2; l.color.setHex(i === 1 ? LED : 0xfff0dc); }); }
    const night = tm > 19.2 || tm < 5.6, dusk = (tm > 17.6 && tm <= 19.2) || (tm >= 5.6 && tm < 7);
    this.winMat.color.setHex(!t || ph === 'board' || ph === 'landed' ? (night ? 0x1a2230 : 0x9aa6b0) : night ? 0x0a1430 : dusk ? 0xf0a060 : 0x8ec8f0);
    if (t) { const D = DEST_BY_ID[t.dest];
      if (ph === 'takeoff') { if (!this.seated) this.sit(); this.announce('t', '🛫 Décollage de ton jet privé : le golfe de Guinée s’éloigne sous les ailes.'); }
      if (ph === 'cruise') this.announce('c', '🔔 Altitude de croisière : tu peux te déplacer dans la cabine.');
      if (ph === 'descent') { if (!this.seated) this.sit(); this.announce('d', `🧑‍✈️ « Nous commençons la descente vers ${t.back ? 'Cotonou' : D.city}. »`); }
      if (ph === 'landed' && !this._ann.l) { this.announce('l', t.back ? '🛬 Atterrissage à Cotonou. Bienvenue à la maison !' : `🛬 Atterrissage à ${D.city} — heure locale ${hh(tm + D.tz)}. ${D.city} n’est pas encore jouable : options à la porte.`);
        if (!t.back) { this.abroad = t.dest; this.trip = null; } this.syncExt(); this.save(); }
      if (this.ui.setActivity && this.trip) this.ui.setActivity(`✈️ ${this.reg} ${t.back ? `${D.city} → Cotonou` : `Cotonou → ${D.city}`} • ${{ board: `départ ${hh(t.dep)}`, takeoff: 'décollage', cruise: `croisière • arrivée dans ${dur(Math.max(0, t.arr - this.abs()))}`, descent: 'descente', landed: 'au sol' }[ph]}`);
    } else if (this.ui.setActivity) this.ui.setActivity('');
    if (this.seated) { if (this.ui.menuOpen && this.ui.menuOpen()) { if (this.dom) this.dom.classList.remove('show'); } else this.bar(); }
    for (const p of this.people) if (p.role === 'hotesse') p.c.animate(dt, 0);
  }
  // ------------------------------------------------------------------ application NOVA TRAVEL, onglet « Mon jet »
  renderApp() {
    let h = '<p class="ph-note">Modèles, prix, immatriculation et équipage fictifs (monnaie virtuelle). Les villes étrangères ne sont pas encore jouables.</p>';
    if (!this.own) return h + `<h5>Acheter un jet privé</h5>${JETS.map((J) => { const sp = PLANE_BY_ID[J.id]; return `<div class="ph-row"><span><b>${sp.name}</b><small>${J.note} • ${J.seats} places • ${J.range} • ${sp.engines}</small></span><button class="ph-mini" data-tr="jet:buy:${J.id}">${fcfa(J.price)}</button></div>`; }).join('')}`;
    const sp = this.spec(), loc = this.trip ? 'en vol' : this.abroad ? `au sol à ${DEST_BY_ID[this.abroad].city}` : 'aviation d’affaires de Cotonou';
    const tabs = [['info', 'Mon jet'], ['deco', 'Personnaliser'], ['crew', 'Équipage']];
    h += `<div class="ph-row"><span><b>✈️ ${sp.name} • ${this.reg}</b><small>${loc} • valeur estimée ${fcfa(this.value())} • ${this.flights} vol${this.flights > 1 ? 's' : ''} privé${this.flights > 1 ? 's' : ''}</small></span></div><div class="ph-chips">${tabs.map(([k, l]) => `<button data-tr="jet:view:${k}" class="${k === this.view ? 'on' : ''}">${l}</button>`).join('')}</div>`;
    if (this.view === 'deco') h += `<p class="ph-note">${fcfa(CUSTOM_FEE)} par modification (atelier fictif).</p>${Object.entries(FIN).map(([k, F]) => `<p class="ph-note"><b>${F.label}</b></p><div class="ph-chips">${Object.entries(F.c).map(([v, [l]]) => `<button data-tr="jet:fin:${k}:${v}" class="${this.cfg[k] === v ? 'on' : ''}">${l}</button>`).join('')}</div>`).join('')}`;
    else if (this.view === 'crew') h += Object.entries(CREW).map(([role, R]) => `<h5>${R.label}</h5>${R.list.map(([id, name, xp, pay]) => `<div class="ph-row"><span><b>${esc(name)}</b><small>${xp} • ${fcfa(pay)} / semaine</small></span>${this.crew[role] === id ? `<button class="ph-mini" data-tr="jet:fire:${role}">Remercier</button>` : `<button class="ph-mini" data-tr="jet:hire:${id}">Recruter</button>`}</div>`).join('')}`).join('') + '<p class="ph-note">Pilote et copilote obligatoires pour voler ; l’hôtesse ou le steward assure le service à bord.</p>';
    else h += `<div class="ph-list"><div class="ph-row"><span><b>Rejoindre mon jet</b><small>Navette depuis le salon privé du PDG au terminal, ou en voiture avec chauffeur.</small></span>${this.driver ? '<button class="ph-mini" data-tr="jet:go:1">🚘 M’y conduire</button>' : ''}</div>
      <div class="ph-row"><span><b>Équipage</b><small>${Object.values(this.crew).map((id) => CREW_BY_ID[id].name).join(' • ') || 'aucun membre recruté'}</small></span></div>
      <div class="ph-row"><span><b>Vols privés</b><small>Plan de vol au poste de pilotage ou depuis ton siège : 12 destinations, départ 15 min après validation, coût selon la durée (environ ${fcfa(COST_H)} par heure).</small></span></div></div>
      <h5>Changer de modèle</h5>${JETS.filter((J) => J.id !== this.own).map((J) => `<div class="ph-row"><span><b>${PLANE_BY_ID[J.id].name}</b><small>Reprise de ton jet déduite : ${fcfa(J.price - this.value())} à payer</small></span><button class="ph-mini" data-tr="jet:buy:${J.id}">Échanger</button></div>`).join('')}`;
    return h;
  }
  onPhone(a, b, c) {
    if (a === 'buy') this.buy(b); else if (a === 'view') this.view = b; else if (a === 'fin') this.custom(b, c); else if (a === 'hire') this.hire(b); else if (a === 'fire') this.fire(b);
    else if (a === 'go' && this.driver) { this.economy.togglePhone(false); this.driver.toDest({ id: 'jetprive', label: 'Mon jet privé (aviation d’affaires)', x: APRON.x + 6, z: APRON.z + 18 }); return false; }
    return true;
  }
  serialize() { return { own: this.own, reg: this.reg, cfg: this.cfg, crew: this.crew, lastPay: this.lastPay, trip: this.trip, abroad: this.abroad, flights: this.flights }; }
  restore(s) {
    if (!s) return; Object.assign(this, { own: s.own || null, reg: s.reg || 'TY-NVA', crew: s.crew || {}, lastPay: s.lastPay ?? null, trip: s.trip || null, abroad: s.abroad || null, flights: s.flights || 0 }); Object.assign(this.cfg, s.cfg || {});
    this.resume = !!(this.trip || this.abroad); if (this.ig) { this.buildExterior(); this.buildInterior(); this.addPoi(); }
  }
}
