// BENIN LIFE : COTONOU OPEN WORLD — point d'entrée du prototype.
import * as THREE from 'three';
import { buildWorld } from './world.js';
import { setTextureBudget } from './textures.js';
import { WEATHERS, WEATHER_MODES } from './weather.js';
import { Inventory } from './inventory.js';
import { Powers } from './powers.js';
import { Garage } from './garage.js';
import { Airport } from './airport.js';
import { Economy } from './economy.js';
import { Kitchen } from './food.js';
import { Market } from './market.js';
import { Supermarket } from './supermarket.js';
import { Transport } from './transport.js';
import { Region } from './region.js';
import { NovaBook } from './nova.js';
import { NovaPlus } from './nova-plus.js';
import { Venues } from './venues.js';
import { PhonePlus } from './phone-plus.js';
import { Leds } from './led.js';
import { Offices } from './offices.js';
import { Projects } from './projects.js';
import { Wardrobe } from './wardrobe.js';
import { CeoLife } from './ceo-life.js';
import { Talk } from './talk.js';
import { Interiors } from './interiors.js';
import { Heliport } from './heliport.js';
import { Port } from './port.js';
import { Fortune } from './fortune.js';
import { HomePlus } from './home-plus.js';
import { CityLife } from './population.js';
import { TownLife, RoadTraffic } from './towns-life.js';
import { buildPlaces } from './places.js';
import { Company } from './company.js';
import { BizUI } from './biz-ui.js';
import { Group } from './group.js';
import { regionZone } from './region-geo.js';
import { Environment } from './environment.js';
import { Player } from './player.js';
import { DrivableCar, DrivableMoto, Traffic, loadGLBVehicleBody } from './vehicles.js';
import { TrafficLights } from './signals.js';
import { Pedestrians } from './pedestrians.js';
import { ThirdPersonCamera } from './camera.js';
import { Input } from './input.js';
import { UI } from './ui.js';
import { PostFX } from './post.js';
import { globalUniforms } from './shaderfx.js';
import { AudioSystem } from './audio.js';
import { loadGLBCharacter } from './glbCharacter.js';
import { CHARACTER_GLB } from './characterAssets.gen.js';
import { HOME, OUTFITS } from './home.js';
import { Needs, SaveGame } from './life.js';
import { TouchControls, isTouchDevice } from './touch.js';
import { createCharacter } from './character.js';

const DEFAULTS = { quality: 'medium', sensitivity: 1, invertY: false, showFps: false, volume: 0.8, music: true, muted: false, character: 'male', weatherMode: 'auto', timeSpeed: 1 };
const TOUCH = isTouchDevice() || /[?&]touch/.test(location.search);
function loadSettings() {
  const d = { ...DEFAULTS, quality: TOUCH ? 'low' : DEFAULTS.quality };
  // si le chargement précédent n'a pas abouti (onglet tué par manque de mémoire, fréquent sur iPhone), on repasse en qualité basse
  let crashed = false;
  try { crashed = localStorage.getItem('beninlife.booting') === '1'; localStorage.setItem('beninlife.booting', '1'); } catch (e) { /* stockage indisponible */ }
  if (crashed) { try { const s = JSON.parse(localStorage.getItem('beninlife.settings') || '{}'); return { ...d, ...s, quality: 'low' }; } catch (e) { return d; } }
  try { return { ...d, ...JSON.parse(localStorage.getItem('beninlife.settings') || '{}') }; } catch (e) { return d; }
}
function saveSettings(s) { try { localStorage.setItem('beninlife.settings', JSON.stringify(s)); } catch (e) { /* stockage indisponible */ } }

function boot() {
  const settings = loadSettings();
  if (!settings.density) settings.density = TOUCH ? 'medium' : 'high'; // mission 015 : densité de population et de circulation
  const container = document.getElementById('game');
  const renderer = new THREE.WebGLRenderer({ antialias: !TOUCH, powerPreference: TOUCH ? 'default' : 'high-performance' });
  renderer.domElement.addEventListener('webglcontextlost', (e) => { e.preventDefault(); showFatal('Le téléphone a manqué de mémoire graphique. Recharge la page : le jeu redémarrera en qualité basse.'); try { localStorage.setItem('beninlife.booting', '1'); } catch (_) {} });
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  container.appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(62, innerWidth / innerHeight, 0.1, 2500);

  const t0 = performance.now();
  if (TOUCH || settings.quality === 'low') setTextureBudget(512);
  const world = buildWorld(scene, settings.quality);
  const env = new Environment(scene, renderer, world);
  const player = new Player(scene);
  const cars = world.parkedCars.map((p) => (p.model === 'moto' ? new DrivableMoto(scene, p) : new DrivableCar(scene, p)));
  // ---- Mission 010 : maison, voiture personnelle, besoins, sauvegarde ----
  const home = world.home;
  const needs = new Needs();
  const saved = SaveGame.load();
  let homePlusRef = null, companyRef = null; // aménagement de la maison, entreprise (créés plus bas)
  const personalCar = new DrivableCar(scene, { x: HOME.carSpot.x, z: HOME.carSpot.z, h: HOME.carSpot.h, color: 0x1d4d3a, model: 'sedan' });
  personalCar.personal = true;
  cars.push(personalCar);
  const lights = new TrafficLights(scene, world.lightIntersections, world.collision);
  const traffic = new Traffic(scene, lights);
  const superm = new Supermarket({ scene, world }); // avant les piétons : caissières et clients
  const peds = new Pedestrians(scene, world, TOUCH ? 36 : 64); // mission 015 : réserve de passants (pooling, densité selon l'heure)
  const post = new PostFX(renderer, scene, camera);
  const audio = new AudioSystem(settings);
  // les navigateurs n'autorisent le son qu'après une action de l'utilisateur
  const unlock = () => audio.init();
  addEventListener('pointerdown', unlock); addEventListener('keydown', unlock);
  player.onStep = (v) => audio.footstep(player.pos.x, player.pos.z, v);
  player.onLand = () => audio.land();
  document.querySelectorAll('.btn').forEach((b) => { b.addEventListener('mouseenter', () => audio.hover()); b.addEventListener('click', () => audio.click()); });
  const tpc = new ThirdPersonCamera(camera, settings);
  const input = new Input(renderer.domElement);
  console.log(`[BENIN LIFE] monde généré en ${(performance.now() - t0).toFixed(0)} ms`, world.stats);

  let state = 'menu';
  const ui = new UI(settings, {
    onPlay: () => startPlaying(),
    onMainMenu: () => setState('menu'),
    onSettings: () => { applySettings(); applyCharacter(); audio.applyVolume(); saveSettings(settings); },
    onNewGame: (btn) => {
      // confirmation dans la page (les boîtes confirm() sont bloquées dans certains navigateurs intégrés)
      if (btn && btn.dataset.armed === '1') { SaveGame.clear(); saveNow = () => false; location.reload(); return; }
      if (btn) { btn.dataset.armed = '1'; const t = btn.textContent; btn.textContent = 'TOUCHER À NOUVEAU POUR EFFACER'; setTimeout(() => { btn.dataset.armed = ''; btn.textContent = t; }, 4000); }
    },
  }, world);

  function applySettings() {
    const pr = settings.quality === 'high' ? Math.min(devicePixelRatio, 1.5) : settings.quality === 'medium' ? Math.min(devicePixelRatio, 1.0) : 0.8;
    renderer.setPixelRatio(pr);
    renderer.setSize(innerWidth, innerHeight);
    env.setShadows(settings.quality);
    renderer.shadowMap.enabled = settings.quality !== 'low';
    scene.fog.far = env.fogFar = settings.quality === 'low' ? 320 : settings.quality === 'high' ? 560 : 480;
    camera.far = settings.quality === 'low' ? 1200 : 2500;
    post.setQuality(settings.quality);
    post.setSize(innerWidth, innerHeight);
    camera.updateProjectionMatrix();
    scene.traverse((o) => { if (o.material && o.material.needsUpdate !== undefined) o.material.needsUpdate = true; });
  }
  applySettings();

  // ---- personnage principal : modèle GLB (Tripo) s'il est présent, sinon personnage procédural ----
  let appliedChar = null, charLoad = 0;
  function applyCharacter() {
    const kind = settings.character === 'female' ? 'female' : 'male';
    if (kind === appliedChar) return;
    appliedChar = kind;
    const id = ++charLoad;
    const onStep = (v) => player.onStep && player.onStep(v);
    if (CHARACTER_GLB[kind]) {
      loadGLBCharacter(CHARACTER_GLB[kind], { female: kind === 'female', onStep })
        .then((c) => { if (id === charLoad) { player.setCharacter(kind, c); console.log('[BENIN LIFE] personnage GLB', c.report); } })
        .catch((e) => { console.warn('[BENIN LIFE] GLB illisible, personnage procédural utilisé', e); if (id === charLoad) player.setCharacter(kind); });
    } else player.setCharacter(kind, makeOutfitChar(kind));
  }
  // ---- tenues (armoire du dressing) ----
  let outfitId = (saved && saved.outfit && saved.outfit.id) || null;
  // ---- mission 016, phase 6 : garde-robe de 200 vêtements (prioritaire sur les tenues de base si des pièces sont portées) ----
  const wardrobe = new Wardrobe({ ui, audio, player, tpc, onSave: () => saveNow(), legacyId: () => outfitId });
  if (saved && saved.wardrobe) wardrobe.restore(saved.wardrobe);
  wardrobe.rebuild = () => { const kind = player.kind === 'female' ? 'female' : 'male'; if (CHARACTER_GLB[kind]) return; player.setCharacter(kind, makeOutfitChar(kind)); };
  wardrobe.legacy = (id) => setOutfit(id);
  function outfitFor(kind) {
    const list = OUTFITS[kind];
    return list.find((o) => o.id === outfitId) || list[0];
  }
  function makeOutfitChar(kind) {
    const o = outfitFor(kind); outfitId = o.id;
    const base = kind === 'female' ? { skin: 0x5a3a26 } : { skin: 0x4e3122 };
    if (wardrobe.active()) return createCharacter({ ...base, ...wardrobe.opts(kind === 'female'), onStep: (v) => player.onStep && player.onStep(v) });
    return createCharacter({ ...base, ...o.opts, onStep: (v) => player.onStep && player.onStep(v) });
  }
  function setOutfit(id) {
    const kind = player.kind === 'female' ? 'female' : 'male';
    if (CHARACTER_GLB[kind]) { ui.toast('Les tenues s\'appliquent au personnage procédural (pas au modèle GLB)', 3); return; }
    outfitId = id; wardrobe.cur = { haut: null, bas: null, veste: null, tenue: null, pieds: null, acc: [] };
    player.setCharacter(kind, makeOutfitChar(kind));
    saveNow();
  }
  applyCharacter();

  // ---- sauvegarde ----
  let novaPlusRef = null, venuesRef = null, phonePlusRef = null, ledsRef = null, projectsRef = null, ceoLifeRef = null, talkRef = null, interiorsRef = null, heliportRef = null, portRef = null, fortuneRef = null;
  let saveNow = function () {
    const c = personalCar;
    return SaveGame.save({
      house: { x: HOME.marker.x, z: HOME.marker.z },
      outfit: { kind: player.kind, id: outfitId },
      home: home.serialize(),
      car: { x: c.pos.x, z: c.pos.z, h: c.heading, inGarage: home.inGarage(c.pos.x, c.pos.z) },
      needs: needs.serialize(),
      time: env.time,
      weather: env.weather.serialize(),
      inventory: inventory.serialize(),
      powers: powers.serialize(),
      garage: garage.serialize(),
      airport: airport.serialize(),
      economy: economy.serialize(),
      kitchen: kitchen.serialize(),
      superm: superm.serialize(),
      market: market.serialize(),
      wardrobe: wardrobe.serialize(),
      venues: venuesRef ? venuesRef.serialize() : (saved && saved.venues),
      phonePlus: phonePlusRef ? phonePlusRef.serialize() : (saved && saved.phonePlus),
      leds: ledsRef ? ledsRef.serialize() : (saved && saved.leds),
      projects: projectsRef ? projectsRef.serialize() : (saved && saved.projects),
      ceoLife: ceoLifeRef ? ceoLifeRef.serialize() : (saved && saved.ceoLife),
      talk: talkRef ? talkRef.serialize() : (saved && saved.talk),
      interiors: interiorsRef ? interiorsRef.serialize() : (saved && saved.interiors),
      heliport: heliportRef ? heliportRef.serialize() : (saved && saved.heliport),
      port: portRef ? portRef.serialize() : (saved && saved.port),
      fortune: fortuneRef ? fortuneRef.serialize() : (saved && saved.fortune),
      novaPlus: novaPlusRef ? novaPlusRef.serialize() : (saved && saved.novaPlus),
      company: companyRef ? companyRef.serialize() : (saved && saved.company),
      map: ui.mapState ? ui.mapState() : undefined,
      homePlus: homePlusRef ? homePlusRef.serialize() : (saved && saved.homePlus),
      player: player.inCar ? null : { x: player.pos.x, z: player.pos.z, facing: player.facing },
    });
  };
  // ---- Mission 009 : inventaire et équipement ----
  const inventory = new Inventory({ scene, renderer, player, ui, audio, needs, env, camera, peds, traffic, cars,
    onMap: () => { ui.toggleMap(true); input.releaseLock(); }, onSave: () => saveNow() });
  // ---- Mission 011 : pouvoirs mystiques ----
  const powers = new Powers({ scene, camera, player, ui, audio, needs, env, peds, traffic, cars, world, onSave: () => saveNow() });
  // ---- Mission 012 : garage et véhicules ----
  const garage = new Garage({ scene, renderer, world, player, ui, audio, env, cars, particles: inventory.particles, onSave: () => saveNow() });
  // ---- Mission 012 (étape 2) : monde agrandi, aéroport et avions ----
  const airport = new Airport({ scene, renderer, world, camera, player, ui, audio, env, settings, tpc, onSave: () => saveNow() });
  const region = new Region({ scene, world, quality: settings.quality }); // après l'aéroport (murs de la ville)
  // ---- Mission 013 (étape 1) : économie en FCFA, téléphone, réfrigérateur et cuisine béninoise ----
  const economy = new Economy({ ui, env, audio, onSave: () => saveNow() });
  const port = new Port({ scene, world, player, ui, audio, economy, needs, env, tpc, camera, home, onSave: () => saveNow() }); portRef = port; if (saved && saved.port) port.restore(saved.port); // mission 012, étape 4
  const heliport = new Heliport({ scene, world, player, ui, audio, economy, env, tpc, onSave: () => saveNow() }); heliportRef = heliport; if (saved && saved.heliport) heliport.restore(saved.heliport); // mission 012, étape 3
  const kitchen = new Kitchen({ scene, renderer, home, ui, economy, needs, audio, onSave: () => saveNow() });
  economy.kitchen = kitchen;
  const market = new Market({ scene, world, economy, kitchen, audio, ui, env, onSave: () => saveNow() });
  market.peds = peds; economy.market = market; if (saved && saved.market) market.restore(saved.market);
  const transport = new Transport({ scene, world, economy, ui, audio, env, player, traffic, tpc, onSave: () => saveNow() });
  economy.transport = transport;
  const nova = new NovaBook({ scene, world, player, ui, audio, env, home, needs, onSave: () => saveNow() });
  const company = new Company({ nova, economy, env, ui, audio, onSave: () => saveNow() }); // mission 014, étape 2
  if (saved && saved.company) company.restore(saved.company);
  companyRef = company;
  const group = new Group({ company, economy, onSave: () => saveNow() }); // mission 014, étape 4 : groupe et banque
  const bizUI = new BizUI({ company, economy, audio });
  nova.company = company;
  const novaPlus = new NovaPlus({ nova, world, ui, audio, needs, player, economy, company, kitchen, onSave: () => saveNow() }); // mission 016 : toilettes H/F, frigo du PDG
  novaPlusRef = novaPlus;
  if (saved && saved.novaPlus) novaPlus.restore(saved.novaPlus);
  nova.onDesk = () => bizUI.toggle(true, () => { if (nova.seated) nova.stand(); });
  nova.onMeeting = () => { bizUI.tab = 'stats'; bizUI.toggle(true); ui.toast('Réunion de direction : bilan et statistiques de NOVA BOOK', 2.5); };
  const homePlus = new HomePlus({ scene, home, world, economy, nova, ui, audio, onSave: () => saveNow() });
  if (saved && saved.homePlus) homePlus.restore(saved.homePlus);
  homePlusRef = homePlus;
  homePlus.openBiz = (onClose) => bizUI.toggle(true, onClose);
  const life = new CityLife({ world, peds, traffic, env, ui, audio, economy, settings, player, scene });
  const townLife = new TownLife({ scene, region, settings, touch: TOUCH }); // mission 015, phase 2 : villes de la région
  const roadTraffic = new RoadTraffic({ scene, settings, touch: TOUCH });
  // mission 016, phase 3 : lieux de vie des 5 villes et carburant
  const venues = new Venues({ scene, world, region, ui, audio, economy, needs, env, player, cars, garage, bizUI, group, company, onSave: () => saveNow() });
  venuesRef = venues; if (saved && saved.venues) venues.restore(saved.venues);
  const interiors = new Interiors({ scene, world, ui, audio, player, venues, needs, env, home, tpc, onSave: () => saveNow() }); interiorsRef = interiors; if (saved && saved.interiors) interiors.restore(saved.interiors); // restaurants, hôtels, banques
  // mission 016, phase 4 : contacts, appels, messages et virements aux employés
  const phonePlus = new PhonePlus({ economy, company, group, market, env, ui, audio, onSave: () => saveNow() });
  phonePlusRef = phonePlus; economy.phonePlus = phonePlus; if (saved && saved.phonePlus) phonePlus.restore(saved.phonePlus);
  phonePlus.bindInputs(document.querySelector('#phone'));
  phonePlus.canRing = () => state === 'playing' && !home.activity && !economy.phoneOpen && !bizUI.open && !venues.sleep && !transport.riding && !player.inCar;
  // mission 016, phase 5 : LED, sociétés visitables, projets du PDG
  const leds = new Leds({ homePlus, nova }); leds.onSave = () => saveNow(); phonePlus.leds = leds; ledsRef = leds; if (saved && saved.leds) leds.restore(saved.leds);
  const offices = new Offices({ scene, world, ui, audio, player, group, bizUI, home, env, leds, tpc, pois: ui.pois, onSave: () => saveNow() });
  const projects = new Projects({ company, economy, env, needs, ui, onSave: () => saveNow() }); projectsRef = projects; bizUI.projects = projects; if (saved && saved.projects) projects.restore(saved.projects);
  // mission 014, étape 5 : vie quotidienne du PDG (visites, événements, objectifs)
  const ceoLife = new CeoLife({ company, group, projects, nova, phonePlus, economy, env, ui, audio, world, bizUI, onSave: () => saveNow() }); ceoLifeRef = ceoLife; if (saved && saved.ceoLife) ceoLife.restore(saved.ceoLife);
  // mission 017, étape 2 : conversations libres avec les employés (moteur local gratuit, voix facultative du navigateur)
  const talk = new Talk({ company, group, projects, economy, env, ui, audio, onSave: () => saveNow() }); talkRef = talk; if (saved && saved.talk) talk.restore(saved.talk);
  nova.talk = talk; phonePlus.talk = talk; offices.talk = talk; company.talk = talk;
  { const vp = venues.pois(), hostNear = (q) => vp.some((v) => Math.hypot(v.x - q.x, v.z - q.z) < 25 && v.name.toUpperCase().startsWith(q.name.toUpperCase().slice(0, 8)));
    ui.setPOIs([...buildPlaces(world).filter((q) => !hostNear(q)), ...vp, ...port.pois()], saved && saved.map); }
  offices.init(ui.pois);
  // mission 017, étape 1 : compte personnel de 10 milliards (monnaie fictive), banque personnelle, achats, patrimoine
  const fortune = new Fortune({ scene, region, economy, venues, group, company, garage, wardrobe, ui, audio, env, needs, onSave: () => saveNow() }); fortuneRef = fortune;
  if (saved && saved.fortune) fortune.restore(saved.fortune);
  garage.fortune = fortune; wardrobe.buyFn = (it) => fortune.payCloth(it); economy.fortune = fortune;
  group.pois = ui.pois; group.updatePlaces(); ui.renderSide(); // complément mission 015 : lieux de la carte, découvertes, itinéraire
  ui.h.onMapChange = () => saveNow();
  Object.assign(superm, { home, economy, kitchen, audio, ui, env, onSave: () => saveNow() }); superm.bindDom(); if (saved && saved.superm) superm.restore(saved.superm);
  const game = { player, env, ui, audio, needs, personalCar, setOutfit, openWardrobe: (m) => wardrobe.show(m), kitchen, economy, save: saveNow, get outfitId() { return outfitId; } };
  home.attach(game);
  if (saved) {
    needs.restore(saved.needs);
    if (typeof saved.time === 'number') env.time = saved.time;
    env.weather.restore(saved.weather);
    inventory.restore(saved.inventory);
    powers.restore(saved.powers);
    garage.restore(saved.garage);
    airport.restore(saved.airport);
    economy.restore(saved.economy);
    if (saved.kitchen) kitchen.restore(saved.kitchen);
    else if (saved.home && saved.home.fridge) { // ancienne sauvegarde : reprise du stock du réfrigérateur
      const map = { amiwo: 'amiwo', gombo: 'pate_blanche', atassi: 'atassi', akassa: 'akassa', alloco: 'alloco', bissap: 'bissap' };
      for (const [k, n] of Object.entries(saved.home.fridge)) if (map[k] && n > 0) kitchen.add(map[k], n);
      if (saved.home.fridge.gombo > 0) kitchen.add('sauce_gombo', saved.home.fridge.gombo);
    }
    home.restore(saved.home);
    if (saved.car) { personalCar.pos.set(saved.car.x, 0, saved.car.z); personalCar.heading = saved.car.h; personalCar.sync(); }
    if (saved.player && !world.collision.pointBlocked(saved.player.x, 1, saved.player.z)) { player.pos.set(saved.player.x, 0, saved.player.z); player.facing = saved.player.facing || 0; }
  }
  // ---- Mission 008 : heure et météo réglables ----
  const weatherModeLabel = (m) => (m === 'auto' ? 'Automatique' : `${WEATHERS[m].icon} ${WEATHERS[m].label}`);
  function setWeatherMode(m) { settings.weatherMode = m; env.weather.setMode(m); saveSettings(settings); const sel = document.getElementById('opt-weather'); if (sel) sel.value = m; }
  env.weather.mode = WEATHER_MODES.includes(settings.weatherMode) ? settings.weatherMode : 'auto';
  if (env.weather.mode !== 'auto') env.weather.current = env.weather.mode;
  env.timeScale = settings.timeSpeed ?? 1;
  env.weather.onThunder = (delay) => audio.thunder && audio.thunder(delay);
  const optHour = document.getElementById('opt-hour'), optHourV = document.getElementById('opt-hour-v');
  const optWeather = document.getElementById('opt-weather'), optSpeed = document.getElementById('opt-timespeed');
  function syncTimeUI() { if (optHour) { optHour.value = env.time.toFixed(2); optHourV.textContent = `${env.clock} — ${env.period}`; } }
  if (optHour) {
    syncTimeUI();
    optHour.addEventListener('input', () => { env.time = parseFloat(optHour.value) % 24; syncTimeUI(); });
    optWeather.value = env.weather.mode;
    optWeather.addEventListener('change', () => setWeatherMode(optWeather.value));
    optSpeed.value = String(env.timeScale);
    optSpeed.addEventListener('change', () => { settings.timeSpeed = env.timeScale = parseFloat(optSpeed.value); saveSettings(settings); });
    document.querySelectorAll('[data-act="options"]').forEach((b) => b.addEventListener('click', syncTimeUI));
  }
  addEventListener('pagehide', () => saveNow());
  document.addEventListener('visibilitychange', () => { if (document.hidden) saveNow(); });
  let autosave = 0;

  // ---- commandes tactiles ----
  let touch = null;
  if (TOUCH) { document.body.classList.add('touch'); touch = new TouchControls(input, document.getElementById('touch')); touch.show(false); }

  // ---- balise 3D au-dessus de la maison (quand M est la destination) ----
  const beacon = new THREE.Mesh(new THREE.CylinderGeometry(0.6, 0.6, 60, 16, 1, true), new THREE.MeshBasicMaterial({ color: 0xfcd116, transparent: true, opacity: 0.35, depthWrite: false, side: THREE.DoubleSide, fog: false }));
  beacon.position.set(HOME.marker.x, 30, HOME.marker.z); beacon.visible = false; scene.add(beacon);
  addEventListener('resize', () => { camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); renderer.setSize(innerWidth, innerHeight); post.setSize(innerWidth, innerHeight); });

  function setState(s) {
    state = s;
    ui.setState(s);
    if (s !== 'playing') { input.releaseLock(); if (garage.open) garage.toggle(false); if (airport.open) airport.toggle(false); if (kitchen.open) kitchen.toggle(false); if (economy.phoneOpen) economy.togglePhone(false); if (market.open) market.toggle(false); if (superm.open) superm.toggle(false); if (nova.open) nova.toggle(false); if (novaPlus.open) novaPlus.toggle(false); if (venues.open) venues.toggle(false); if (heliport.open) heliport.toggle(false); if (port.open) port.toggle(false); if (wardrobe.open) wardrobe.close(true); if (ceoLife.open) ceoLife.toggle(false); if (talk.open) talk.close(); if (inventory.open) inventory.toggle(false); if (powers.open) powers.toggleMenu(false); if (powers.portalOpen) powers.closePortal(); }
    if (touch) touch.show(s === 'playing');
    if (s !== 'playing') saveNow();
  }
  let firstPlay = true;
  function startPlaying() {
    audio.init();
    setState('playing');
    if (!TOUCH) input.requestLock();
    if (firstPlay) {
      firstPlay = false;
      tpc.yaw = player.facing + Math.PI;
      tpc.target.set(player.pos.x, 1.55, player.pos.z);
      ui.toast(saved ? 'Partie reprise. Ta maison est indiquée par le marqueur M (touche C pour la carte).' : 'Bienvenue à Cotonou ! Ta maison est marquée M sur la carte (touche C). Une voiture blanche est garée devant toi.', 6);
    }
  }
  renderer.domElement.addEventListener('click', () => { if (!TOUCH && state === 'playing' && !input.locked && !ui.menuOpen() && !ui.mapOpen()) input.requestLock(); });
  document.addEventListener('pointerlockchange', () => {
    // Échap libère la souris : on met le jeu en pause
    if (!document.pointerLockElement && state === 'playing' && input._hadLock) setState('paused');
    input._hadLock = !!document.pointerLockElement;
  });

  // --------- boucle principale ---------
  let last = performance.now(), fpsAcc = 0, fpsN = 0, fpsText = '';
  const focus = new THREE.Vector3();
  let menuAngle = 0.6;

  function nearestCar() {
    let best = null, bd = 3.6;
    for (const c of cars) {
      const d = Math.hypot(c.pos.x - player.pos.x, c.pos.z - player.pos.z);
      if (d < bd) { bd = d; best = c; }
    }
    return best;
  }

  function enterCar(car) {
    player.inCar = car;
    car.occupied = true;
    car.enableHeadlight(scene);
    player.mesh.visible = false;
    if (car.onEnter) car.onEnter();
    if (car.isMoto) car.setRider(player.kind);
    tpc.yaw = car.heading + Math.PI;
    ui.toast(`Z/W accélérer • S freiner / ${car.isMoto ? 'pousser' : 'reculer'} • Q-D / A-D tourner • Espace frein${car.isMoto ? '' : ' à main'} • E descendre (à l'arrêt)`, 4);
  }
  function exitCar() {
    const car = player.inCar;
    const f = car.forward;
    const cands = [[f.z, -f.x], [-f.z, f.x], [-f.x, -f.z], [f.x, f.z]];
    let placed = false;
    if (car.exitPoint) { const ep = car.exitPoint(); player.pos.set(ep.x, 0, ep.z); placed = true; }
    if (!placed) for (const [lx, lz] of cands) {
      const x = car.pos.x + lx * 2.2, z = car.pos.z + lz * 2.2;
      if (!world.collision.pointBlocked(x, 1, z)) { player.pos.set(x, 0, z); placed = true; break; }
    }
    if (!placed) player.pos.set(car.pos.x, 0, car.pos.z + 3);
    car.occupied = false;
    car.speed = 0; // véhicule immobilisé (frein de stationnement)
    if (car.vel) { car.vel.set(0, 0); car.lat = 0; }
    if (car.onExit) car.onExit();
    if (car.spec) { garage.interior = false; garage.sync(car); }
    if (car.isAircraft) { airport.cockpit = false; car.throttle = 0; if (car.isHeli) car.engine = false; }
    player.inCar = null;
    player.mesh.visible = true;
    player.facing = car.heading;
  }

  let slowT = 0, slowF = 0; const autoDowngraded = new Set();
  function frame(now) {
    requestAnimationFrame(frame);
    let dt = (now - last) / 1000; last = now;
    if (dt > 0.05) dt = 0.05;
    // mode « tournage » (enregistrement de la bande-annonce) : une image calculée par demande, pas de temps fixe
    if (window.__manual) { if (!window.__stepReq) return; window.__stepReq--; dt = window.__manualDt || 1 / 24; now = (window.__mt = (window.__mt || 0) + dt) * 1000; }
    fpsAcc += dt; fpsN++;
    // qualité automatique : si le jeu rame plusieurs secondes, on baisse d'un cran
    if (state === 'playing' && dt > 0 && !window.__manual) {
      slowT += dt; slowF++;
      if (slowT > 6) {
        const fps = slowF / slowT; slowT = 0; slowF = 0;
        if (fps < 24 && settings.quality !== 'low' && !autoDowngraded.has(settings.quality)) {
          autoDowngraded.add(settings.quality);
          settings.quality = settings.quality === 'high' ? 'medium' : 'low';
          saveSettings(settings); applySettings();
          ui.toast(`Le jeu ralentissait : qualité réglée sur ${settings.quality === 'low' ? 'Basse' : 'Moyenne'} (modifiable dans Options)`, 3);
        }
      }
    }
    if (fpsAcc > 0.5) { fpsText = `${Math.round(fpsN / fpsAcc)} FPS • ${renderer.info.render.calls} draw calls • ${(renderer.info.render.triangles / 1000).toFixed(0)}k tris`; fpsAcc = 0; fpsN = 0; }
    const time = now / 1000;
    globalUniforms.uTime.value = time;

    // touches globales
    const menuOpen = ui.menuOpen(), mapOpen = ui.mapOpen();
    if (menuOpen) { ui.menuKey(input); input.releaseLock(); }
    else if (wardrobe.open) { wardrobe.handleKeys(input); input.releaseLock(); }
    else if (ceoLife.open) { ceoLife.handleKeys(input); input.releaseLock(); }
    else if (talk.open) { talk.handleKeys(input); input.releaseLock(); }
    else if (interiors.seated && !venues.open && state === 'playing' && (input.hit('KeyE') || input.hit('Escape'))) interiors.stand();
    else if (bizUI.open) { bizUI.handleKeys(input); input.releaseLock(); }
    else if (homePlus.open) { homePlus.handleKeys(input); input.releaseLock(); }
    else if (kitchen.open) { kitchen.handleKeys(input); input.releaseLock(); }
    else if (market.open) { market.handleKeys(input); input.releaseLock(); }
    else if (superm.open) { superm.handleKeys(input); input.releaseLock(); }
    else if (novaPlus.open) { novaPlus.handleKeys(input); input.releaseLock(); }
    else if (venues.open) { venues.handleKeys(input); input.releaseLock(); }
    else if (heliport.open) { heliport.handleKeys(input); input.releaseLock(); }
    else if (port.open) { port.handleKeys(input); input.releaseLock(); }
    else if (nova.open) { nova.handleKeys(input); input.releaseLock(); }
    else if (nova.seated && state === 'playing' && (input.hit('KeyE') || input.hit('Escape'))) nova.stand();
    else if (economy.phoneOpen) { economy.handleKeys(input); input.releaseLock(); }
    else if (state === 'playing' && input.hit('KeyN') && !home.activity) { economy.togglePhone(true); input.releaseLock(); }
    else if (garage.open) { garage.handleKeys(input); input.releaseLock(); }
    else if (airport.open) { airport.handleKeys(input); input.releaseLock(); }
    else if (inventory.open) { inventory.handleKeys(input); input.releaseLock(); }
    else if (powers.open || powers.portalOpen) { powers.handleKeys(input); input.releaseLock(); }
    else if (state === 'playing' && input.hit('KeyU') && !mapOpen && !home.activity) { powers.toggleMenu(true); input.releaseLock(); }
    else if (state === 'playing' && input.hit('KeyI') && !mapOpen && !home.activity) { if (player.inCar) ui.toast('Descends du véhicule pour ouvrir l’inventaire', 1.6); else { inventory.toggle(true); input.releaseLock(); } }
    else if (state === 'playing' && input.hit('KeyC')) { ui.toggleMap(); if (ui.mapOpen()) input.releaseLock(); }
    else if (mapOpen && input.hit('Escape')) ui.toggleMap(false);
    else if (home.activity && state === 'playing') home.handleActivityKeys(input);
    else if (input.hit('Escape') || input.hit('KeyP')) {
      if (ui.panelOpen()) ui.hidePanels();
      else if (state === 'playing') setState('paused');
      else if (state === 'paused') startPlaying();
    }

    const playing = state === 'playing';
    const blocked = ui.menuOpen() || ui.mapOpen() || !!home.activity || inventory.open || powers.open || powers.portalOpen || garage.open || airport.open || kitchen.open || economy.phoneOpen || market.open || superm.open || transport.riding || nova.open || !!nova.seated || !!homePlus.open || bizUI.open || novaPlus.open || !!novaPlus.act || venues.open || !!venues.sleep || wardrobe.open || ceoLife.open || talk.open || !!interiors.seated || heliport.open || port.open;
    const simDt = state === 'paused' ? 0 : dt;

    if (playing) {
      if (input.hit('KeyH')) ui.toggleHelp();
      if (input.hit('F3') || input.hit('KeyF')) { settings.showFps = !settings.showFps; saveSettings(settings); }
      if (input.hit('KeyT')) {
        const back = input.down('ShiftLeft') || input.down('ShiftRight');
        env.time = (env.time + (back ? 23 : 1)) % 24; syncTimeUI();
        ui.toast(`Heure ${back ? 'reculée' : 'avancée'} : ${env.clock} — ${env.period}`, 1.5);
      }
      if (input.hit('KeyY')) {
        const i = WEATHER_MODES.indexOf(env.weather.mode);
        setWeatherMode(WEATHER_MODES[(i + 1) % WEATHER_MODES.length]);
        ui.toast(`Météo : ${weatherModeLabel(settings.weatherMode)}`, 2);
      }
      const hi0 = !player.inCar && !blocked ? home.nearest(player.pos.x, player.pos.z) : null;
      const gi = !player.inCar && !blocked ? garage.nearest(player.pos.x, player.pos.z) : null;
      const ai = !player.inCar && !blocked ? (airport.nearest(player.pos.x, player.pos.z) || heliport.nearest(player.pos.x, player.pos.z)) : null;
      const mi = !player.inCar && !blocked ? market.nearest(player.pos.x, player.pos.z) : null;
      const si = !player.inCar && !blocked ? superm.nearest(player.pos.x, player.pos.z) : null;
      const ti = !player.inCar && !blocked ? transport.nearest(player.pos.x, player.pos.z) : null;
      const ni = !player.inCar && !blocked ? nova.nearest(player.pos.x, player.pos.z) : null;
      const vi = !player.inCar && !blocked ? venues.nearest(player.pos.x, player.pos.z) : null;
      const oi = !player.inCar && !blocked ? offices.nearest(player.pos.x, player.pos.z) : null;
      const li = !player.inCar && !blocked ? (life.nearest(player.pos.x, player.pos.z) || (life.talking ? null : life.townItem(townLife.nearest(player.pos.x, player.pos.z)))) : null;
      const ii = !player.inCar && !blocked ? interiors.nearest(player.pos.x, player.pos.z) : null;
      const pi = !player.inCar && !blocked ? port.nearest(player.pos.x, player.pos.z) : null;
      const hi = port.cruise ? pi : interiors.inside ? ii : offices.inside >= 0 ? oi : [hi0, gi, ai, mi, si, ti, ni, vi, oi, pi, li].filter(Boolean).sort((a, b) => a.d - b.d)[0] || null;
      const ncar = !player.inCar && !blocked ? nearestCar() : null;
      const useHome = hi && (!ncar || hi.d < Math.hypot(ncar.pos.x - player.pos.x, ncar.pos.z - player.pos.z));
      if (blocked) { /* menu, carte ou activité en cours */ }
      else if (input.hit('KeyE') && useHome) { hi.it.action(); }
      else if (input.hit('KeyE')) {
        if (player.inCar) {
          if (player.inCar.isAircraft && player.inCar.airborne) ui.toast('Impossible de sortir en vol : atterris d’abord', 1.8);
          else if (Math.abs(player.inCar.speed) > 2.5) ui.toast('Arrête-toi d\'abord pour descendre (S ou Espace)', 1.8);
          else if (player.inCar.isBoat && !port.canExit(player.inCar)) ui.toast('Approche-toi d’un quai, d’une jetée ou du rivage pour débarquer', 2.2);
          else { const bt = player.inCar.isBoat ? player.inCar : null; exitCar(); audio.door(); if (bt) port.onExit(bt); }
        }
        else { const c = nearestCar(); if (c) { enterCar(c); audio.door(); } }
      }
      if (input.hit('KeyB') && player.inCar && player.inCar.isBoat && player.inCar.bspec.len > 60) { if (Math.abs(player.inCar.speed) > 1) ui.toast('Arrête le navire (Espace) avant d’explorer les ponts', 1.8); else { const bt = player.inCar; bt.occupied = false; player.inCar = null; player.mesh.visible = true; port.visit(bt); } }
      if (input.hit('KeyK') && player.inCar) audio.horn(player.pos.x, player.pos.z, player.inCar.hornFreqs || 'car', true);
      if (input.hit('KeyV') && player.inCar && player.inCar.isAircraft) { airport.cockpit = !airport.cockpit; ui.toast(airport.cockpit ? 'Vue cockpit (V pour revenir)' : 'Vue extérieure', 1.4); }
      if (input.hit('KeyV') && player.inCar && player.inCar.spec) { garage.interior = !garage.interior; ui.toast(garage.interior ? 'Vue intérieure (V pour revenir)' : 'Vue extérieure', 1.4); }
      if (!blocked && !player.inCar && input.hit('KeyG')) inventory.use();
      if (!blocked && !player.inCar) powers.handleGameKeys(input);
      if (input.hit('KeyM') || input.hit('Semicolon')) {
        settings.muted = !settings.muted; audio.applyVolume(); saveSettings(settings);
        ui.toast(settings.muted ? 'Son coupé (M)' : 'Son activé', 1.5);
      }
      if (transport.riding) transport.handleRideKeys(input);
      if (!ui.menuOpen()) tpc.handleInput(input);
      game._prompt = useHome ? `<b>E</b> ${hi.it.label()}` : null;
    }

    // obstacles dynamiques
    const trafficObs = traffic.obstacles().concat(roadTraffic.obstacles());
    const carObs = cars.filter((c) => c !== player.inCar).flatMap((c) => c.circles());

    let hs = 0;
    if (simDt > 0) {
      if (player.inCar) {
        const impact = player.inCar.update(simDt, venues.carInput(player.inCar, input), world, trafficObs.concat(carObs));
        if (impact > 12) ui.toast('Aïe ! Attention à la carrosserie…', 1.5);
        if (impact > 3) audio.impact(impact);
        player.pos.set(player.inCar.pos.x, 0, player.inCar.pos.z);
      } else if (playing && !blocked) {
        player.canRun = needs.canRun;
        player.staminaMul = inventory.staminaMul;
        hs = player.update(simDt, input, tpc.yaw, world, trafficObs.concat(carObs, peds.obstacles()));
      } else if (transport.riding) {
        /* passager : pose assise (zem) ou caché dans le véhicule */
      } else if (playing && !home.activity) {
        player.char.animate(simDt, 0);
      } else {
        player.char.animate(simDt, 0);
      }
      for (const c of cars) if (c !== player.inCar) c.update(simDt, null, world, trafficObs);
      transport.update(simDt);
      const blockers = [{ x: player.pos.x, z: player.pos.z, r: player.inCar || transport.riding ? 1.2 : 0.4 }];
      for (const c of cars) blockers.push({ x: c.pos.x, z: c.pos.z, r: c.occupied || Math.abs(c.speed) > 0.5 ? 1.2 : 0.3 });
      for (const b of peds.blockers()) blockers.push(b);
      for (const b of powers.blockers()) blockers.push(b);
      lights.update(simDt);
      traffic.update(simDt, blockers, state === 'menu' ? null : player.pos);
      peds.update(simDt, player.pos, traffic, lights, player.inCar);
      world.update(time);
      home.update(simDt, { playerPos: player.pos, player, personalCar, realTime: time });
      env.weather.indoor = home.indoor || superm.inside || nova.inside || offices.inside >= 0 || !!interiors.inside;
      if (playing) {
        needs.update(simDt * env.rate, player.inCar ? 0.1 : home.activity ? 0 : player.running ? 1 : hs > 0.5 ? 0.3 : 0);
        autosave += simDt; if (autosave > 15) { autosave = 0; saveNow(); }
      }
    }

    if (state === 'menu') {
      // caméra de présentation autour du rond-point
      menuAngle += dt * 0.05;
      camera.position.set(Math.sin(menuAngle) * 55, 22, Math.cos(menuAngle) * 55);
      camera.lookAt(0, 6, 0);
      focus.set(0, 0, 0);
      env.update(dt * 0.3, focus, camera, time);
    } else {
      const car = player.inCar;
      focus.set(player.pos.x, car ? (car.isAircraft ? car.pos.y + car.pspec.centerY : car.isBoat ? car.parts.H + (car.bspec.len > 60 ? 8 : 1) : 1.6) : player.pos.y + 1.55, player.pos.z);
      tpc.indoor = home.indoor || superm.inside || nova.inside || offices.inside >= 0 || !!interiors.inside;
      tpc.indoorMax = nova.inside || offices.inside >= 0 ? 7 : 3.8; tpc.indoorPitch = nova.inside || offices.inside >= 0 ? 0.9 : 1.1; // grands plateaux de bureaux
      tpc.update(dt, focus, world, transport.riding ? transport.camInfo() : car ? { heading: car.heading, speed: car.speed, dist: car.isMoto ? 5 : car.isBoat ? Math.max(9, car.bspec.len * 0.75) : car.isAircraft ? Math.max(13, car.pspec.len * 1.15 + car.pspec.span * 0.35) : car.spec ? 5.2 + car.spec.len * 0.55 : 7.5 } : null);
      garage.applyInterior(camera, tpc);
      if (wardrobe.open) wardrobe.applyMirror(camera, TOUCH); // vue « miroir » : caméra face au personnage
      airport.applyCockpit(camera, tpc);
      env.update(simDt, player.pos, camera, time);
      for (const c of cars) if (c.headlight) c.headlight.intensity = c.occupied ? env.lightsOn * 60 : 0;
    }

    if (playing) {
      const nc = !player.inCar && nearestCar();
      ui.update(dt, {
        zone: airport.zoneName(player.pos.x, player.pos.z) || regionZone(player.pos.x, player.pos.z) || world.zoneName(player.pos.x, player.pos.z),
        clock: env.clock,
        clockSub: `${env.period} · ${env.weather.label}`,
        driving: !!player.inCar,
        speed: player.inCar ? player.inCar.speed : hs,
        stamina: player.stamina,
        prompt: home.activity || ui.menuOpen() ? '' : game._prompt ? game._prompt : player.inCar ? (Math.abs(player.inCar.speed) < 2.5 ? `<b>E</b> Descendre ${player.inCar.isMoto ? 'de la moto' : 'du véhicule'}` : '') : nc ? `<b>E</b> ${nc.personal ? 'Monter dans ma voiture' : nc.isMoto ? 'Monter sur la moto' : 'Monter dans le véhicule'}` : '',
        needs: needs.serialize(), atHome: home.isInside(player.pos.x, player.pos.z),
        vehicle: transport.riding ? 'passager' : player.inCar ? (player.inCar.isMoto ? 'moto' : player.inCar.isBoat ? 'boat' : player.inCar.isHeli ? 'heli' : player.inCar.isAircraft ? 'plane' : 'car') : null,
        fpsText,
        x: player.pos.x, z: player.pos.z,
        heading: player.inCar ? player.inCar.heading : player.facing,
        camYaw: tpc.yaw,
        cars: cars.map((c) => ({ x: c.pos.x, z: c.pos.z, occupied: c.occupied })),
      });
    }

    inventory.update(dt, time, blocked && !inventory.open);
    powers.update(state === 'paused' ? 0 : dt, time, state === 'playing');
    garage.update(state === 'paused' ? 0 : dt, time);
    airport.update(state === 'paused' ? 0 : dt, time);
    if (state === 'playing') economy.update(dt);
    if (state !== 'menu') { market.update(dt, player.pos); if (state === 'playing') company.update();
    if (state !== 'menu') { life.update(dt); townLife.update(dt, player.inCar ? player.inCar.pos : player.pos, env); roadTraffic.update(dt, player.inCar ? player.inCar.pos : player.pos, env, townLife.blockers(), player.inCar); if (roadTraffic.horns.length) { const hn = roadTraffic.horns.shift(); roadTraffic.horns.length = 0; if (audio.ctx) audio.horn(hn.x, hn.z, hn.kind); } } homePlus.update(dt); superm.update(dt, player.pos, player); nova.update(dt, player.pos, player); novaPlus.update(dt, player.pos); venues.update(dt, player.pos); interiors.update(dt, player.pos); heliport.update(dt); port.update(dt); fortune.update(); phonePlus.update(dt); offices.update(dt, player.pos); if (state === 'playing') { projects.update(); ceoLife.update(); } venues.updateFuel(dt, player.inCar); region.update(player.inCar ? player.inCar.pos : player.pos); }
    if (touch) touch.setCam(!!(player.inCar && (player.inCar.spec || player.inCar.isAircraft)));
    if (touch) { touch.setHorn(!!player.inCar); touch.setUse((!!inventory.equipped.hand && !player.inCar) || !!(player.inCar && player.inCar.isAircraft)); }
    beacon.visible = playing && ui.destination && Math.hypot(player.pos.x - HOME.marker.x, player.pos.z - HOME.marker.z) > 15;
    if (ui.destination && Math.hypot(player.pos.x - HOME.marker.x, player.pos.z - HOME.marker.z) < 6) { ui.destination = false; ui.toast('Tu es arrivé chez toi (M)', 2.5); }
    audio.update(dt, { crowd: life.crowd || 0,
      state, night: env.night, x: player.pos.x, z: player.pos.z, camera, rain: env.weather.p.rain, indoor: home.indoor || superm.inside || nova.inside,
      car: player.inCar, throttle: player.inCar && (input.down('KeyW') || input.down('ArrowUp')) ? 1 : 0,
      handbrake: input.down('Space'), traffic: traffic.vehicles,
    });
    if (window.__cine) window.__cine(dt, time);
    post.render(env.night, Math.max(0, 1 - Math.abs(Math.sin(((env.time - 6.25) / 12.5) * Math.PI)) * 3.5));
    inventory.afterRender(renderer.domElement);
    if (window.__manual) window.__rendered = (window.__rendered || 0) + 1;
    input.endFrame();
  }

  document.getElementById('loading').classList.add('hide');
  setState('menu');
  requestAnimationFrame((t) => { last = t; frame(t); });
  booted = true;
  setTimeout(() => { try { localStorage.removeItem('beninlife.booting'); } catch (e) { /* stockage indisponible */ } }, 4000);

  // accès debug / tests automatisés
  window.__BL = { talk, fortune, port, heliport, interiors, ceoLife, wardrobe, offices, leds, projects, phonePlus, venues, novaPlus, group, company, bizUI, townLife, roadTraffic, life, homePlus, nova, region, transport, superm, market, economy, kitchen, airport, garage, powers, inventory, home, needs, personalCar, saveNow, SaveGame, ui, input, setOutfit, lights, loadGLBVehicleBody, applyCharacter, settings, audio, post, peds, player, cars, env, world, traffic, renderer, tpc, scene, camera, state: () => state, startPlaying, enterCar, exitCar };
}

function showFatal(msg) {
  const l = document.getElementById('loading');
  if (!l) return;
  l.classList.remove('hide'); l.style.zIndex = 100;
  l.querySelector('p').textContent = msg;
}
let booted = false;
window.addEventListener('error', (e) => !booted && showFatal('Erreur : ' + (e.message || e) + ' — recharge la page.'));
window.addEventListener('unhandledrejection', (e) => console.warn('[BENIN LIFE]', e.reason));

// laisse le navigateur afficher l'écran de chargement avant la génération de la ville
setTimeout(() => {
  try {
    boot();
  } catch (err) {
    console.error(err);
    showFatal('Erreur de démarrage : ' + err.message + ' — vérifie que ton navigateur prend en charge WebGL 2.');
  }
}, 50);
