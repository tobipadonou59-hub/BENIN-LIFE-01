// Post-traitement adapté à la qualité choisie :
// Basse = rendu direct ; Moyenne = halo (bloom) + étalonnage ; Haute = + occlusion ambiante (GTAO).
import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { GTAOPass } from 'three/addons/postprocessing/GTAOPass.js';

const GradeShader = {
  uniforms: { tDiffuse: { value: null }, uSat: { value: 1.1 }, uContrast: { value: 1.05 }, uVignette: { value: 0.5 }, uWarm: { value: 0.0 } },
  vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
  fragmentShader: `uniform sampler2D tDiffuse; uniform float uSat, uContrast, uVignette, uWarm; varying vec2 vUv;
    void main(){
      vec3 c = texture2D(tDiffuse, vUv).rgb;
      float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
      c = mix(vec3(l), c, uSat);
      c = (c - 0.5) * uContrast + 0.5;
      c *= vec3(1.0 + uWarm * 0.05, 1.0, 1.0 - uWarm * 0.05);
      vec2 d = vUv - 0.5; c *= 1.0 - dot(d, d) * uVignette;
      gl_FragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
    }`,
};

export class PostFX {
  constructor(renderer, scene, camera) {
    this.renderer = renderer; this.scene = scene; this.camera = camera;
    this.composer = null; this.quality = null;
  }

  setQuality(q) {
    if (q === this.quality) return;
    this.quality = q;
    if (this.composer) { this.composer.dispose(); this.composer = null; }
    if (q === 'low') return;
    const r = this.renderer, size = r.getDrawingBufferSize(new THREE.Vector2());
    const rt = new THREE.WebGLRenderTarget(size.x, size.y, { type: THREE.HalfFloatType, samples: 4 });
    const c = new EffectComposer(r, rt);
    c.addPass(new RenderPass(this.scene, this.camera));
    if (q === 'high') {
      const ao = new GTAOPass(this.scene, this.camera, size.x, size.y);
      ao.blendIntensity = 0.85;
      ao.updateGtaoMaterial({ radius: 0.6, distanceExponent: 1.5, thickness: 1.5, scale: 1.0 });
      // la végétation transparente est exclue du calcul (évite les halos carrés)
      const orig = ao._overrideVisibility.bind(ao);
      const scene = this.scene;
      ao._overrideVisibility = function () {
        orig();
        scene.traverse((o) => { if (o.userData.noAO && o.visible) { o.visible = false; this._visibilityCache.push(o); } });
      };
      c.addPass(ao);
    }
    this.bloom = new UnrealBloomPass(new THREE.Vector2(size.x / 2, size.y / 2), 0.22, 0.55, 0.9);
    c.addPass(this.bloom);
    c.addPass(new OutputPass());
    this.grade = new ShaderPass(GradeShader);
    c.addPass(this.grade);
    this.composer = c;
  }

  setSize(w, h) { if (this.composer) { this.composer.setPixelRatio(this.renderer.getPixelRatio()); this.composer.setSize(w, h); } }

  render(night = 0, golden = 0) {
    if (!this.composer) { this.renderer.render(this.scene, this.camera); return; }
    this.bloom.strength = 0.16 + night * 0.22;
    this.bloom.threshold = night > 0.5 ? 0.8 : 0.92;
    this.grade.uniforms.uWarm.value = golden;
    this.composer.render();
  }
}
