// Mission 012 — étape 2 : monde agrandi (savane, banlieues, lagune, océan), aéroport de Cotonou (fictif dans sa
// disposition : piste, voies de circulation, aire de stationnement, terminal, tour, hangars, balisage lumineux)
// et 8 avions pilotables (modèles 3D procéduraux, pilotage arcade, vue cockpit, train, volets, hélices, réacteurs).
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { PLANES, PLANE_BY_ID } from './aircraft-data.js';
import { addMacroVariation } from './shaderfx.js';
import { clamp, damp, mulberry32 } from './util.js';
import { MAP, SEA_Z, BEACH_Z } from './world.js';
import { REGION, coastZ, inLake, nearRoad, isWater } from './region-geo.js';

const PI = Math.PI;
// disposition de l'aéroport (à l'ouest de la ville, le long de la côte)
export const AIRPORT = { x0: -2150, x1: -430, z0: -75, z1: 152, rwZ: -20, rwX0: -2050, rwX1: -550, rwW: 45, twZ: 40 };
const KIOSK = { x: -462, z: 113 };
const STANDS = {
  aeria380: { x: -520, h: 0 }, jumbo747: { x: -612, h: 0 }, aeria320: { x: -684, h: 0 }, skyliner737: { x: -735, h: 0 },
  gulfwing: { x: -1060, z: 70, h: PI }, faucon8x: { x: -1150, z: 72, h: PI }, atlantis72: { x: -1240, z: 70, h: PI }, cesla172: { x: -1300, z: 76, h: PI },
};
function standOf(spec) { const s = STANDS[spec.id]; return { x: s.x, z: s.z != null ? s.z : 130 - spec.len / 2, h: s.h }; }
// eau réelle (mission 013, étape 6) : littoral et lacs issus de src/region-data.js (remplace l'ancienne lagune rectangulaire)
export function overWater(x, z) { return isWater(x, z); }

const colorize = (geo, hex) => {
  const g = geo.index ? geo.toNonIndexed() : geo;
  const c = new THREE.Color(hex), n = g.attributes.position.count, a = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { a[i * 3] = c.r; a[i * 3 + 1] = c.g; a[i * 3 + 2] = c.b; }
  g.setAttribute('color', new THREE.BufferAttribute(a, 3));
  for (const k of Object.keys(g.attributes)) if (!['position', 'normal', 'color'].includes(k)) g.deleteAttribute(k);
  return g;
};
const vcMat = (o = {}) => new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.85, ...o });

// =====================================================================
// Monde agrandi : visible surtout depuis le ciel (un seul maillage par type)
// =====================================================================
function buildOutskirts(scene, quality) {
  const g = new THREE.Group();
  const R = mulberry32(2024);
  // savane / terre sous la ville et dans toute la région
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(17000, 9000).rotateX(-PI / 2), addMacroVariation(new THREE.MeshStandardMaterial({ color: 0x9a8a5a, roughness: 1 }), 0.002, 0.35, 0x6f7a3a, 0.4));
  ground.position.set(-1500, -0.08, -500); ground.receiveShadow = true; g.add(ground);
  // océan au sud du trait de côte réel (raccordé à la plage du jeu près de la ville) + bande de sable
  const shore = []; for (let x = -10000; x <= 7000; x += 100) shore.push([x, coastZ(x)]);
  const oShape = new THREE.Shape(); oShape.moveTo(shore[0][0], -shore[0][1]);
  for (const [x, z] of shore) oShape.lineTo(x, -z);
  oShape.lineTo(7000, -8000); oShape.lineTo(-10000, -8000); oShape.closePath();
  const waterMat = new THREE.MeshStandardMaterial({ color: 0x1b6a82, roughness: 0.18, metalness: 0.1 });
  const ocean = new THREE.Mesh(new THREE.ShapeGeometry(oShape).rotateX(-PI / 2), waterMat); ocean.position.y = 0.06; g.add(ocean);
  const sp = [], si = [];
  shore.forEach(([x, z], i) => { sp.push(x, 0.0, z - 34, x, 0.0, z + 2); if (i) { const k = i * 2; si.push(k - 2, k, k - 1, k - 1, k, k + 1); } });
  const sg = new THREE.BufferGeometry(); sg.setAttribute('position', new THREE.Float32BufferAttribute(sp, 3)); sg.setIndex(si); sg.computeVertexNormals();
  const sand = new THREE.Mesh(sg, new THREE.MeshStandardMaterial({ color: 0xe8d8b0, roughness: 1, side: THREE.DoubleSide })); g.add(sand);
  // lac Nokoué et lagune de Porto-Novo (contours OpenStreetMap)
  const lakeMat = new THREE.MeshStandardMaterial({ color: 0x3a6a5a, roughness: 0.25, metalness: 0.05 });
  const lakes = REGION.lakes.map((l) => { const sh = new THREE.Shape(l.pts.map(([x, z]) => new THREE.Vector2(x, -z))); const m = new THREE.Mesh(new THREE.ShapeGeometry(sh).rotateX(-PI / 2), lakeMat); m.position.y = 0.02; g.add(m); return m; });
  const lagoon = lakes[0];
  // banlieues : maisons basses (murs pastel, toits de tôle) sur une grille irrégulière
  const step = quality === 'low' ? 44 : quality === 'high' ? 26 : 32;
  const walls = [0xe8dcc8, 0xd8c8a8, 0xf0e0d0, 0xc8d8c8, 0xe0c8b8, 0xd0d8e0, 0xf2eee6], roofs = [0x9a4a32, 0x7a7a78, 0xa85a3a, 0x5a6a7a, 0x8a8a86];
  const parts = [];
  const skip = (x, z) => (x > -300 && x < 300 && z > -300 && z < 210) || (x > AIRPORT.x0 - 120 && x < AIRPORT.x1 + 60 && z > AIRPORT.z0 - 60 && z < 200) || z > BEACH_Z + 5
    || inLake(x, z) || inLake(x + 30, z) || inLake(x - 30, z) || inLake(x, z + 30) || inLake(x, z - 30) || z > coastZ(x) - 30 || nearRoad(x, z) || (z > 92 && z < 108 && x < -150 && x > -440);
  for (let x = -3600; x <= 3000; x += step) for (let z = -3400; z <= 900; z += step) {
    const px = x + (R() - 0.5) * step * 0.6, pz = z + (R() - 0.5) * step * 0.6;
    if (skip(px, pz)) continue;
    const dc = Math.hypot(px, pz);
    if (R() > (dc < 1500 ? 0.62 : dc < 3000 ? 0.4 : 0.18)) continue;
    const w = 7 + R() * 9, d = 7 + R() * 9, h = dc < 900 && R() < 0.2 ? 9 + R() * 12 : 3 + R() * 4, ry = (R() < 0.5 ? 0 : PI / 2) + (R() - 0.5) * 0.2;
    const m = new THREE.Matrix4().makeRotationY(ry).setPosition(px, 0, pz);
    parts.push(colorize(new THREE.BoxGeometry(w, h, d).translate(0, h / 2, 0).applyMatrix4(m), walls[(R() * walls.length) | 0]));
    parts.push(colorize(new THREE.BoxGeometry(w + 0.6, 0.4, d + 0.6).translate(0, h + 0.2, 0).applyMatrix4(m), roofs[(R() * roofs.length) | 0]));
  }
  // cocotiers et arbres
  const trees = [];
  for (let i = 0; i < (quality === 'low' ? 900 : 2000); i++) {
    const px = -3500 + R() * 6400, pz = -3300 + R() * 4200;
    if (skip(px, pz) && !(pz > coastZ(px) - 45 && pz < coastZ(px) - 4 && !nearRoad(px, pz) && !inLake(px, pz))) continue;
    const h = 7 + R() * 7, palm = R() < 0.6;
    trees.push(colorize(new THREE.CylinderGeometry(0.2, 0.32, h, 5).translate(px, h / 2, pz), 0x6a5236));
    trees.push(colorize((palm ? new THREE.ConeGeometry(3.4, 1.8, 7).translate(px, h + 0.4, pz) : new THREE.SphereGeometry(3 + R() * 2, 7, 5).translate(px, h + 1, pz)), palm ? 0x3f7a2a : 0x2f6a2a));
  }
  const town = new THREE.Mesh(mergeGeometries(parts), vcMat()); town.receiveShadow = true; g.add(town);
  const flora = new THREE.Mesh(mergeGeometries(trees), vcMat({ roughness: 0.9 })); g.add(flora);
  for (const m of [ground, sand, ocean, ...lakes, town, flora]) m.frustumCulled = false;
  scene.add(g);
  g.userData.detail = [town, flora];
  return g;
}

// =====================================================================
// Aéroport : pistes, bâtiments, balisage, clôture
// =====================================================================
function textTex(lines, w = 1024, h = 256, bg = '#0f1a24', fg = '#ffffff') {
  const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d');
  x.fillStyle = bg; x.fillRect(0, 0, w, h); x.fillStyle = fg; x.textAlign = 'center'; x.textBaseline = 'middle';
  x.font = `900 ${Math.round(h * 0.42)}px Arial`; x.fillText(lines[0], w / 2, lines[1] ? h * 0.38 : h / 2);
  if (lines[1]) { x.font = `700 ${Math.round(h * 0.18)}px Arial`; x.fillStyle = '#fcd116'; x.fillText(lines[1], w / 2, h * 0.76); }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}
function buildAirportSite(scene, col) {
  const A = AIRPORT, g = new THREE.Group();
  const flat = [], light = [], marks = [];
  const plane = (arr, w, d, x, z, y, c) => arr.push(colorize(new THREE.PlaneGeometry(w, d).rotateX(-PI / 2).translate(x, y, z), c));
  // herbe de l'aéroport, piste, voie de circulation, bretelles, aire de stationnement, accès routier
  plane(flat, A.x1 - A.x0, A.z1 - A.z0, (A.x0 + A.x1) / 2, (A.z0 + A.z1) / 2, 0.0, 0x7d8a4a);
  plane(flat, A.rwX1 - A.rwX0, A.rwW, (A.rwX0 + A.rwX1) / 2, A.rwZ, 0.03, 0x3a3c40);
  plane(flat, A.rwX1 - A.rwX0 - 50, 23, (A.rwX0 + A.rwX1) / 2, A.twZ, 0.03, 0x45474b);
  for (const x of [-560, -1300, -2000]) plane(flat, 23, A.twZ - A.rwZ, x, (A.twZ + A.rwZ) / 2, 0.035, 0x45474b);
  for (const x of [-660, -1150]) plane(flat, 23, 22, x, A.twZ + 20, 0.035, 0x45474b);
  plane(flat, 560, 80, -720, 91, 0.04, 0xa8a49a);
  plane(flat, 330, 70, -1170, 92, 0.04, 0xa8a49a);
  plane(flat, 200, 14, -340, 100, 0.03, 0x3a3c40); // route d'accès depuis le boulevard
  plane(flat, 40, 30, -455, 108, 0.045, 0x3a3c40);  // parking du terminal
  // marquages : axe, seuils, numéros, bords
  for (let x = A.rwX0 + 40; x < A.rwX1 - 40; x += 50) plane(marks, 30, 0.9, x, A.rwZ, 0.06, 0xf2f2f2);
  for (const [x0, dir] of [[A.rwX1 - 10, -1], [A.rwX0 + 10, 1]]) for (let k = 0; k < 8; k++) for (const s of [-1, 1]) plane(marks, 30, 1.6, x0 + dir * 15, A.rwZ + s * (3 + k * 2.4), 0.06, 0xf2f2f2);
  for (const s of [-1, 1]) plane(marks, A.rwX1 - A.rwX0, 0.8, (A.rwX0 + A.rwX1) / 2, A.rwZ + s * (A.rwW / 2 - 1), 0.06, 0xf2f2f2);
  for (let x = A.rwX0; x < A.rwX1 - 20; x += 20) plane(marks, 10, 0.5, x + 10, A.twZ, 0.065, 0xf2c200);
  // bâtiments : terminal vitré, tour de contrôle, hangars, kiosque des vols
  const solid = [], glassP = [];
  const box = (arr, w, h, d, x, y, z, c) => arr.push(colorize(new THREE.BoxGeometry(w, h, d).translate(x, y + h / 2, z), c));
  box(solid, 240, 3, 20, -680, 0, 141, 0xd8d4cc); box(glassP, 236, 9, 18, -680, 3, 141, 0x2a4a5a); box(solid, 246, 2, 24, -680, 12, 141, 0xf2f0ea);
  for (let i = -6; i <= 6; i++) box(solid, 1, 9, 19, -680 + i * 19, 3, 141, 0xf2f0ea);
  col.addBox(-800, 131, -560, 151, 14);
  for (const [w, x] of [[30, -650], [30, -710]]) { box(solid, 3, 9, 22, x, 3, 118, 0xe0ddd5); box(glassP, w, 3.6, 3, x + w / 2 - 1.5, 6, 108, 0x2a4a5a); } // passerelles
  box(solid, 7, 34, 7, -470, 0, 140, 0xe8e4dc); box(glassP, 11, 5, 11, -470, 34, 140, 0x2a6a7a); box(solid, 12, 1.2, 12, -470, 39, 140, 0xd8d4cc);
  col.addBox(-474, 136, -466, 144, 40);
  for (const x of [-1060, -1150, -1240]) {
    box(solid, 80, 1, 50, x, 21, 127, 0xb8bcc2); box(solid, 2, 21, 50, x - 39, 0, 127, 0xc8ccd2); box(solid, 2, 21, 50, x + 39, 0, 127, 0xc8ccd2); box(solid, 80, 21, 2, x, 0, 151, 0xc8ccd2);
    box(solid, 80, 4, 2, x, 17, 102, 0x9aa0a8);
    col.addBox(x - 40, 102, x - 38, 152, 21); col.addBox(x + 38, 102, x + 40, 152, 21); col.addBox(x - 40, 150, x + 40, 152, 21);
  }
  box(solid, 4, 2.6, 3, KIOSK.x, 0, KIOSK.z, 0x008751); box(solid, 5, 0.3, 4, KIOSK.x, 2.6, KIOSK.z, 0xfcd116);
  col.addBox(KIOSK.x - 2, KIOSK.z - 1.5, KIOSK.x + 2, KIOSK.z + 1.5, 2.6);
  // clôture (avec entrée routière à l'est) et murets du couloir d'accès
  const fence = [];
  const fz = (x0, x1, z) => { box(fence, x1 - x0, 2.2, 0.15, (x0 + x1) / 2, 0, z, 0x9aa0a6); col.addBox(x0, z - 0.4, x1, z + 0.4, 3); };
  const fx = (z0, z1, x) => { box(fence, 0.15, 2.2, z1 - z0, x, 0, (z0 + z1) / 2, 0x9aa0a6); col.addBox(x - 0.4, z0, x + 0.4, z1, 3); };
  fz(A.x0, A.x1, A.z0); fz(A.x0, A.x1, A.z1); fx(A.z0, A.z1, A.x0); fx(A.z0, 92, A.x1); fx(108, A.z1, A.x1);
  for (const z of [92, 108]) { box(fence, 270, 0.8, 0.3, -295, 0, z, 0xc8c2b6); col.addBox(-430, z - 0.4, -160, z + 0.4, 3); }
  const mats = { flat: vcMat({ roughness: 0.95 }), marks: vcMat({ roughness: 0.8 }), solid: vcMat({ roughness: 0.7 }), glass: vcMat({ roughness: 0.08, metalness: 0.4 }), fence: vcMat({ roughness: 0.6, metalness: 0.4 }) };
  for (const [arr, m, cast] of [[flat, mats.flat, false], [marks, mats.marks, false], [solid, mats.solid, true], [glassP, mats.glass, false], [fence, mats.fence, true]]) {
    const mesh = new THREE.Mesh(mergeGeometries(arr), m); mesh.receiveShadow = true; mesh.castShadow = cast; g.add(mesh);
  }
  // enseignes
  const sign = (tex, w, h, x, y, z, ry = 0) => { const s = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ map: tex, toneMapped: false })); s.position.set(x, y, z); s.rotation.y = ry; g.add(s); return s; };
  sign(textTex(['AÉROPORT DE COTONOU', 'TERMINAL • ARRIVÉES • DÉPARTS']), 60, 15, -680, 19, 130.8, PI);
  sign(textTex(['VOLS', 'comptoir • choisir un avion'], 512, 256, '#008751'), 4, 2, KIOSK.x, 3.9, KIOSK.z - 1.6, PI);
  sign(textTex(['27'], 256, 256, '#3a3c40'), 18, 18, A.rwX1 - 45, 0.07, A.rwZ, 0).rotation.set(-PI / 2, 0, PI / 2);
  sign(textTex(['09'], 256, 256, '#3a3c40'), 18, 18, A.rwX0 + 45, 0.07, A.rwZ, 0).rotation.set(-PI / 2, 0, -PI / 2);
  for (const [i, x] of [-1060, -1150, -1240].entries()) sign(textTex([`HANGAR ${i + 1}`]), 30, 7, x, 24.5, 101.9, PI);
  // manche à air
  const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 8, 6), new THREE.MeshStandardMaterial({ color: 0xdddddd })); pole.position.set(-580, 4, 12); g.add(pole);
  const sock = new THREE.Mesh(new THREE.ConeGeometry(0.7, 4, 10, 1, true).rotateZ(PI / 2), new THREE.MeshStandardMaterial({ color: 0xff7a1a, side: THREE.DoubleSide })); sock.position.set(-578, 7.6, 12); g.add(sock);
  // balisage lumineux de piste (une seule instance pour tous les feux)
  const lmat = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xfff2c0, emissiveIntensity: 0 });
  const pts = [];
  for (let x = A.rwX0; x <= A.rwX1; x += 60) for (const s of [-1, 1]) pts.push([x, A.rwZ + s * (A.rwW / 2 + 1), 0xfff2c0]);
  for (let k = -6; k <= 6; k++) { pts.push([A.rwX1 + 2, A.rwZ + k * 3.4, 0x40ff60]); pts.push([A.rwX0 - 2, A.rwZ + k * 3.4, 0xff3030]); }
  for (let x = A.rwX0 + 30; x <= A.rwX1 - 30; x += 45) for (const s of [-1, 1]) pts.push([x, A.twZ + s * 12.5, 0x3070ff]);
  const lights = new THREE.InstancedMesh(new THREE.BoxGeometry(0.5, 0.35, 0.5), lmat, pts.length);
  const m4 = new THREE.Matrix4(), c3 = new THREE.Color();
  pts.forEach(([x, z, c], i) => { lights.setMatrixAt(i, m4.makeTranslation(x, 0.2, z)); lights.setColorAt(i, c3.setHex(c)); });
  g.add(lights);
  scene.add(g);
  return { group: g, lmat, sock };
}

// =====================================================================
// Avions : modèles 3D procéduraux
// =====================================================================
const paintM = () => new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.38, metalness: 0.25 });
let liveryTex = null;
function livery() {
  if (liveryTex) return liveryTex;
  const c = document.createElement('canvas'); c.width = 1024; c.height = 128; const x = c.getContext('2d');
  x.clearRect(0, 0, 1024, 128); x.font = '900 86px Arial'; x.textBaseline = 'middle'; x.fillStyle = '#0b4a33'; x.fillText('BENIN LIFE', 10, 64); x.fillStyle = '#c8102e'; x.fillText('AIR', 590, 64);
  liveryTex = new THREE.CanvasTexture(c); liveryTex.colorSpace = THREE.SRGBColorSpace; return liveryTex;
}
function trapezoid(span, root, tip, sweep, th, mirror) {
  const s = mirror ? -1 : 1;
  const shape = new THREE.Shape([new THREE.Vector2(0, 0), new THREE.Vector2(s * span, -sweep), new THREE.Vector2(s * span, -sweep - tip), new THREE.Vector2(0, -root)]);
  return new THREE.ExtrudeGeometry(shape, { depth: th, bevelEnabled: false }).translate(0, 0, -th / 2).rotateX(PI / 2);
}
export function buildPlaneMesh(sp) {
  const g = new THREE.Group(), L = sp.len, r = sp.r, sy = sp.sy || 1, cy = sp.centerY;
  const white = 0xf4f4f2, grey = 0x9aa0a6, belly = 0xc8ccd2, dark = 0x1a2430, G = 0x0b6e4f, Y = 0xf2c200, Rd = 0xc8102e;
  const paint = [], glass = [], metal = [];
  // fuselage (tour de profil) avec queue relevée
  const pts = [];
  for (let i = 0; i <= 40; i++) {
    const t = i / 40; let rr;
    if (t < 0.2) rr = r * (0.18 + 0.82 * Math.sin((t / 0.2) * PI / 2)); else if (t > 0.86) rr = r * Math.sqrt(Math.max(0, 1 - ((t - 0.86) / 0.14) ** 2)); else rr = r;
    pts.push(new THREE.Vector2(Math.max(0.001, rr), -L / 2 + t * L));
  }
  const fus = new THREE.LatheGeometry(pts, 18).rotateX(PI / 2);
  const p = fus.attributes.position;
  for (let i = 0; i < p.count; i++) {
    const z = p.getZ(i), tz = (z + L / 2) / (0.22 * L);
    p.setY(i, p.getY(i) * sy + (tz < 1 ? r * sy * 0.55 * (1 - tz) : 0));
  }
  fus.computeVertexNormals();
  paint.push(colorize(fus.translate(0, cy, 0), white));
  paint.push(colorize(new THREE.BoxGeometry(r * 1.6, r * 0.3, L * 0.62).translate(0, cy - r * sy * 0.82, -L * 0.02), belly));
  if (sp.hump) paint.push(colorize(new THREE.SphereGeometry(1, 16, 10).scale(r * 0.82, r * 0.75, L * 0.19).translate(0, cy + r * 0.88, L * 0.24), white));
  // fenêtres, cockpit, liseré tricolore
  const winY = cy + r * sy * 0.25, nz = L / 2;
  for (const s of [-1, 1]) {
    glass.push(colorize(new THREE.BoxGeometry(0.05, Math.min(0.32, r * 0.18), L * 0.6).translate(s * (r * 0.985), winY, -L * 0.02), dark));
    if (sy > 1.1) glass.push(colorize(new THREE.BoxGeometry(0.05, 0.3, L * 0.55).translate(s * (r * 0.97), cy + r * sy * 0.62, -L * 0.03), dark));
    { const zc = nz - L * 0.075, tt = (zc + L / 2) / L, rr = tt > 0.86 ? r * Math.sqrt(Math.max(0, 1 - ((tt - 0.86) / 0.14) ** 2)) : r; // vitres du cockpit posées sur la surface du nez
      glass.push(colorize(new THREE.BoxGeometry(0.04, r * 0.22, L * 0.04).rotateY(s * 0.35).translate(s * rr * 0.9, cy + r * sy * 0.42, zc), dark)); }
    paint.push(colorize(new THREE.BoxGeometry(0.06, r * 0.08, L * 0.7).translate(s * r * 0.99, winY - r * 0.22, 0), G));
    paint.push(colorize(new THREE.BoxGeometry(0.06, r * 0.05, L * 0.7).translate(s * r * 0.99, winY - r * 0.31, 0), Y));
  }
  // planche de bord (visible en vue cockpit)
  { const ez = L / 2 - Math.max(1.4, L * 0.075); paint.push(colorize(new THREE.BoxGeometry(r * 1.1, r * 0.22, 0.5).translate(0, cy + r * sy * 0.1, ez + 0.9), 0x23272c)); paint.push(colorize(new THREE.BoxGeometry(r * 0.9, 0.03, 0.4).translate(0, cy + r * sy * 0.1 + r * 0.115, ez + 0.85), 0x2a8ab0)); }
  // ailes (+ volets séparés)
  const th = Math.max(0.18, r * 0.16);
  const flaps = [];
  for (const mirror of [false, true]) {
    const s = mirror ? -1 : 1;
    const w = trapezoid(sp.span / 2, sp.root, sp.tip, sp.sweep, th, mirror).rotateZ(s * sp.dih);
    paint.push(colorize(w.translate(0, cy + sp.wingY, sp.wingZ), white));
    if (sp.sharklet) paint.push(colorize(new THREE.BoxGeometry(0.15, 2.4, 1.2).translate(s * sp.span / 2, cy + sp.wingY + 1.2 + sp.span / 2 * sp.dih, sp.wingZ - sp.sweep - 0.6), Rd));
    if (sp.fence) paint.push(colorize(new THREE.BoxGeometry(0.15, 2.6, 2.8).translate(s * sp.span / 2, cy + sp.wingY + sp.span / 2 * sp.dih, sp.wingZ - sp.sweep - 1.6), white));
    // volet intérieur articulé au bord de fuite
    const fl = new THREE.Group();
    const span0 = r * 1.1, span1 = sp.span * 0.3, chord = sp.root * 0.22;
    const zTE0 = sp.wingZ - sp.root, zTE1 = sp.wingZ - (sp.sweep * (span1 / (sp.span / 2))) - (sp.root + (sp.tip - sp.root) * (span1 / (sp.span / 2)));
    fl.position.set(s * (span0 + span1) / 2, cy + sp.wingY + s * 0, (zTE0 + zTE1) / 2 + 0.05);
    fl.rotation.y = s * Math.atan2(zTE0 - zTE1, span1 - span0) * -1;
    const flm = new THREE.Mesh(colorize(new THREE.BoxGeometry(span1 - span0, th * 0.6, chord).translate(0, 0, -chord / 2), grey), null);
    fl.add(flm); flaps.push(fl);
  }
  // empennage
  const [fh, fr, ft, fs] = sp.fin;
  const fin = new THREE.ExtrudeGeometry(new THREE.Shape([new THREE.Vector2(0, 0), new THREE.Vector2(-fs, fh), new THREE.Vector2(-fs - ft, fh), new THREE.Vector2(-fr, 0)]), { depth: th * 0.8, bevelEnabled: false })
    .translate(0, 0, -th * 0.4).rotateY(-PI / 2);
  const finZ = -L / 2 + fr + L * 0.02, finY = cy + r * sy * 0.55 + r * 0.25;
  paint.push(colorize(fin.translate(0, finY, finZ), white));
  // drapeau sur la dérive (vert / jaune / rouge)
  for (const s of [-1, 1]) {
    paint.push(colorize(new THREE.BoxGeometry(0.05, fh * 0.6, fr * 0.28).translate(s * th * 0.45, finY + fh * 0.45, finZ - fs * 0.45 - fr * 0.14), G));
    paint.push(colorize(new THREE.BoxGeometry(0.05, fh * 0.3, fr * 0.5).translate(s * th * 0.45, finY + fh * 0.6, finZ - fs * 0.45 - fr * 0.53), Y));
    paint.push(colorize(new THREE.BoxGeometry(0.05, fh * 0.3, fr * 0.5).translate(s * th * 0.45, finY + fh * 0.3, finZ - fs * 0.3 - fr * 0.53), Rd));
  }
  const tY = sp.tTail ? finY + fh : cy + r * 0.3 * sy, tZ = sp.tTail ? finZ - fs : finZ - fr * 0.05;
  for (const mirror of [false, true]) paint.push(colorize(trapezoid(sp.tailSpan / 2, fr * (sp.tTail ? 0.7 : 0.6), ft * 0.7, fs * 0.5, th * 0.7, mirror).translate(0, tY, tZ + (sp.tTail ? ft * 0.1 : 0)), white));
  // moteurs : nacelles + soufflante ou hélice (pièces mobiles)
  const spinners = [];
  for (const e of sp.eng) {
    const ey = cy + e.y;
    if (e.nac) {
      const [nr, nl] = e.nac;
      metal.push(colorize(new THREE.CylinderGeometry(nr, nr * 0.85, nl, 18, 1, true).rotateX(PI / 2).translate(e.x, ey, e.z), white));
      metal.push(colorize(new THREE.TorusGeometry(nr, nr * 0.1, 6, 18).translate(e.x, ey, e.z + nl / 2), grey));
      metal.push(colorize(new THREE.CylinderGeometry(nr * 0.5, nr * 0.2, nl * 0.4, 10).rotateX(PI / 2).translate(e.x, ey, e.z - nl / 2 - nl * 0.15), 0x555a60));
      if (!e.prop) {
        const fan = new THREE.Group(); fan.position.set(e.x, ey, e.z + nl / 2 - 0.25);
        const blades = []; for (let k = 0; k < 14; k++) blades.push(new THREE.BoxGeometry(nr * 0.12, nr * 0.92, 0.04).translate(0, nr * 0.46, 0).rotateZ((k / 14) * PI * 2).rotateY(0));
        fan.add(new THREE.Mesh(colorize(mergeGeometries(blades), 0x8a9098), null));
        fan.add(new THREE.Mesh(colorize(new THREE.ConeGeometry(nr * 0.28, nr * 0.5, 12).rotateX(PI / 2).translate(0, 0, 0.2), 0xd8dce0), null));
        metal.push(colorize(new THREE.CircleGeometry(nr * 0.98, 18).translate(0, 0, -0.3).translate(e.x, ey, e.z + nl / 2 - 0.25), 0x101418));
        g.add(fan); spinners.push({ o: fan, k: 1.6 });
      }
      // mâts
      if (!sp.highWing && e.y < sp.wingY) metal.push(colorize(new THREE.BoxGeometry(0.3, Math.abs(sp.wingY - e.y) - nr * 0.8, nl * 0.6).translate(e.x, cy + (sp.wingY + e.y) / 2 + nr * 0.4, e.z - nl * 0.1), white));
      else if (Math.abs(e.x) > r) metal.push(colorize(new THREE.BoxGeometry(Math.abs(e.x) - r * 0.6, 0.35, nl * 0.4).translate(Math.sign(e.x) * (Math.abs(e.x) + r * 0.6) / 2, ey, e.z), white));
    }
    if (e.prop) {
      const prop = new THREE.Group(); prop.position.set(e.x, ey, e.z + (e.nac ? e.nac[1] / 2 + 0.2 : 0.1));
      const bl = []; for (let k = 0; k < e.prop; k++) bl.push(new THREE.BoxGeometry(0.16, e.pr, 0.05).translate(0, e.pr / 2, 0).rotateZ((k / e.prop) * PI * 2));
      prop.add(new THREE.Mesh(colorize(mergeGeometries(bl), 0x222222), null));
      prop.add(new THREE.Mesh(colorize(new THREE.ConeGeometry(0.22 + (e.nac ? 0.15 : 0), 0.5, 12).rotateX(PI / 2).translate(0, 0, 0.2), Rd), null));
      g.add(prop); spinners.push({ o: prop, k: 1, prop: true });
    }
  }
  // train d'atterrissage (rentrable sauf avion léger)
  const gear = new THREE.Group(), wheelsArr = [], wr = sp.wheelR;
  const gearParts = [];
  const leg = (x, z, n) => {
    const top = cy - r * sy * 0.6;
    gearParts.push(colorize(new THREE.CylinderGeometry(0.09 + r * 0.03, 0.09 + r * 0.03, top - wr, 8).translate(x, (top + wr) / 2, z), 0xb0b4b8));
    for (let k = 0; k < n; k++) { const wx = x + (k - (n - 1) / 2) * (wr * 0.9); const wg = new THREE.CylinderGeometry(wr, wr, wr * 0.55, 14).rotateZ(PI / 2).translate(wx, wr, z); gearParts.push(colorize(wg, 0x15171a)); }
  };
  const mainZ = sp.highWing ? sp.wingZ - sp.root * 0.7 : sp.wingZ - sp.root * 0.55, mainX = sp.highWing ? r * 1.05 : Math.min(sp.span * 0.12, r * 1.6 + 1.2);
  leg(0, L / 2 - L * 0.11, sp.len > 30 ? 2 : 1);
  for (const s of [-1, 1]) leg(s * mainX, mainZ, sp.len > 60 ? 4 : sp.len > 30 ? 2 : 1);
  if (sp.len > 60) for (const s of [-1, 1]) leg(s * r * 0.5, mainZ - 3.5, 4);
  gear.add(new THREE.Mesh(mergeGeometries(gearParts), null));
  g.add(gear);
  // matériaux
  const mP = paintM(), mG = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.1, metalness: 0.5 }), mM = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.35, metalness: 0.6 });
  const body = new THREE.Mesh(mergeGeometries(paint), mP); body.castShadow = true; body.receiveShadow = true; g.add(body);
  if (glass.length) g.add(new THREE.Mesh(mergeGeometries(glass), mG));
  if (metal.length) { const met = new THREE.Mesh(mergeGeometries(metal), mM); met.castShadow = true; g.add(met); }
  for (const fl of flaps) g.add(fl);
  g.traverse((o) => { if (o.isMesh && !o.material) { o.material = mM; o.castShadow = true; } });
  // inscription « BENIN LIFE AIR »
  if (L > 15) for (const s of [-1, 1]) {
    const tm = new THREE.Mesh(new THREE.PlaneGeometry(L * 0.32, L * 0.04), new THREE.MeshBasicMaterial({ map: livery(), transparent: true, depthWrite: false }));
    tm.position.set(s * (r + 0.02), winY + r * (sy > 1.1 ? 0.75 : 0.42), L * 0.08); tm.rotation.y = s * PI / 2; g.add(tm);
  }
  // escalier mobile (avions de ligne et jets) au niveau de la porte avant gauche
  let stairs = null;
  if (L > 20) {
    const doorY = cy - r * 0.2, doorZ = L / 2 - L * 0.16;
    const sg = []; const steps = Math.max(4, Math.round(doorY / 0.25));
    for (let k = 0; k < steps; k++) sg.push(colorize(new THREE.BoxGeometry(1.6, 0.06, 0.35).translate(0, (k + 1) * (doorY / steps), -k * 0.32), 0xd8d8d8));
    sg.push(colorize(new THREE.BoxGeometry(2.2, 0.8, steps * 0.32 + 2).translate(0, 0.4, -steps * 0.16), 0xf2c200));
    stairs = new THREE.Mesh(mergeGeometries(sg), new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.6 }));
    stairs.position.set(r + 1.4, 0, doorZ); stairs.rotation.y = -PI / 2; stairs.castShadow = true;
    g.add(stairs);
  }
  return { group: g, spinners, gear, flaps, stairs, eye: new THREE.Vector3(0, cy + r * sy * 0.42, L / 2 - Math.max(1.4, L * 0.075)), door: new THREE.Vector3(r + (L > 20 ? 1.4 + Math.max(4, Math.round((cy - r * 0.2) / 0.25)) * 0.32 + 1 : 1.4), 0, L > 20 ? L / 2 - L * 0.16 : sp.wingZ) };
}

// obstacle réel (bâtiment, clôture) à ce point — les murs invisibles des limites de la ville sont ignorés en vol
const _q = [];
export function solidAt(col, x, y, z) {
  for (const o of col.query(x, z, 0, _q)) {
    if (o.disabled || o.invisible || y > o.h || (o.lv !== undefined && o.lv >= 100)) continue; // intérieurs isolés (en hauteur) ignorés
    if (o.t === 0 ? (x > o.minX && x < o.maxX && z > o.minZ && z < o.maxZ) : ((x - o.x) ** 2 + (z - o.z) ** 2 < o.r * o.r)) return true;
  }
  return false;
}

// =====================================================================
// Avion pilotable
// =====================================================================
export class Aircraft {
  constructor(scene, spec, rec) {
    this.isAircraft = true; this.spec = null; this.pspec = spec; this.id = spec.id;
    this.parts = buildPlaneMesh(spec); this.mesh = this.parts.group;
    this.pos = new THREE.Vector3(rec.x, rec.y || 0, rec.z); this.heading = rec.h; this.pitch = 0; this.roll = 0;
    this.speed = 0; this.throttle = 0; this.airborne = false; this.gearDown = true; this.gearT = 1; this.flaps = 0; this.flapsT = 0; this.flapsAuto = true;
    this.vs = 0; this.steer = 0; this.occupied = false; this.headlight = null; this.stall = false;
    this.sound = { type: spec.sound, mul: 1 }; this.rpm = 0; this.hornFreqs = [520, 660];
    this.model = { wheelR: spec.wheelR };
    scene.add(this.mesh);
    this.sync(0);
  }
  get forward() { return { x: Math.sin(this.heading), z: Math.cos(this.heading) }; }
  enableHeadlight() {}
  circles() { return []; }
  exitPoint() {
    this.mesh.updateMatrixWorld(true);
    const d = this.parts.door.clone(); this.mesh.localToWorld(d); d.y = 0; return d;
  }
  update(dt, input, world) {
    const S = this.pspec, g = 9.81;
    let pitchIn = 0, rollIn = 0, thrUp = false, thrDn = false;
    if (this.occupied && input) {
      pitchIn = (input.down('KeyW') || input.down('ArrowUp') ? 1 : 0) - (input.down('KeyS') || input.down('ArrowDown') ? 1 : 0);
      rollIn = (input.down('KeyD') || input.down('ArrowRight') ? 1 : 0) - (input.down('KeyA') || input.down('ArrowLeft') ? 1 : 0);
      thrUp = input.down('ShiftLeft') || input.down('ShiftRight'); thrDn = input.down('Space');
      if (input.hit('KeyG') && !S.fixedGear) { if (this.airborne || !this.gearDown) this.gearDown = !this.gearDown; this.onMsg && this.onMsg(this.gearDown ? 'Train d’atterrissage sorti' : 'Train d’atterrissage rentré'); }
      if (input.hit('KeyB')) { this.flapsAuto = false; this.flaps = (this.flaps + 1) % 3; this.onMsg && this.onMsg(`Volets : ${['rentrés', '15°', '30°'][this.flaps]}`); }
    }
    if (thrUp) this.throttle = Math.min(1, this.throttle + dt * 0.45);
    if (thrDn) this.throttle = Math.max(0, this.throttle - dt * 0.6);
    // volets automatiques à basse vitesse (décollage / atterrissage)
    if (this.flapsAuto) this.flaps = this.speed < S.vStall * 1.35 && (this.gearDown || !this.airborne) ? (this.airborne ? 2 : 1) : 0;
    this.flapsT = damp(this.flapsT, this.flaps / 2, 2, dt);
    this.gearT = damp(this.gearT, this.gearDown ? 1 : 0, 1.5, dt);
    const vStall = S.vStall * (1 - 0.15 * this.flapsT * 2);
    const drag = S.acc / (S.vMax * S.vMax) * (1 + this.flapsT * 0.6 + this.gearT * 0.25);
    // au sol, poussée majorée (pilotage arcade : décollage en 500 à 900 m)
    let a = S.acc * this.throttle * (this.airborne ? 1 : 1.7) - drag * this.speed * this.speed;
    if (!this.airborne) {
      if (thrDn && this.throttle < 0.05) a -= 3.2; // freins
      a -= 0.25 * Math.sign(this.speed);
      if (this.speed < 0.05 && a < 0) { this.speed = 0; a = 0; }
    } else a -= g * Math.sin(this.pitch) * 0.85;
    this.speed = Math.max(0, this.speed + a * dt);
    const ctrl = clamp(this.speed / S.vRot, 0, 1);
    if (!this.airborne) {
      // roulage : direction par la roulette de nez, rotation au-delà de vRot
      this.steer = damp(this.steer, -rollIn * 0.5, 4, dt);
      this.heading += this.steer * dt * clamp(this.speed / 8, 0, 1) * (1 - clamp((this.speed - 20) / 60, 0, 0.85));
      this.roll = damp(this.roll, 0, 4, dt);
      if (this.speed > S.vRot * 0.92 && pitchIn > 0) this.pitch = Math.min(0.22, this.pitch + S.pitch * 0.6 * dt);
      else this.pitch = damp(this.pitch, 0, 3, dt);
      const lift = this.speed > S.vRot && this.pitch > 0.06;
      this.vs = 0; this.pos.y = 0;
      if (lift) { this.airborne = true; this.pos.y = 0.3; this.vs = this.speed * Math.sin(this.pitch); this.onMsg && this.onMsg('Décollage ! Rentre le train avec G'); }
      // repoussage (marche arrière lente) pour quitter le poste de stationnement
      this.pushback = !lift && pitchIn < 0 && this.throttle < 0.02 && this.speed < 0.5;
      if (this.pushback) { const f = this.forward; this.pos.x -= f.x * 2.2 * dt; this.pos.z -= f.z * 2.2 * dt; this.heading -= this.steer * 0.3 * dt; }
    } else {
      this.roll = damp(this.roll, rollIn * 0.75, S.roll * 1.6, dt);
      this.pitch = clamp(this.pitch + pitchIn * S.pitch * ctrl * dt - (pitchIn === 0 ? this.pitch * 0.3 * dt : 0), -0.45, 0.5);
      this.heading -= (g * Math.tan(this.roll) / Math.max(this.speed, 25)) * S.turn * dt * 1.6;
      this.stall = this.speed < vStall;
      let vs = this.speed * Math.sin(this.pitch);
      if (this.stall) { vs -= (vStall - this.speed) * 1.2 + 4; this.pitch = Math.max(-0.4, this.pitch - 0.35 * dt); }
      this.vs = damp(this.vs, vs, 3, dt);
      this.pos.y += this.vs * dt;
      if (this.pos.y > 4200) { this.pos.y = 4200; this.vs = Math.min(0, this.vs); }
    }
    const h = Math.cos(this.pitch) * this.speed;
    this.pos.x += Math.sin(this.heading) * h * dt; this.pos.z += Math.cos(this.heading) * h * dt;
    // limites du monde : demi-tour automatique
    if (Math.abs(this.pos.x + 400) > 6200 || this.pos.z < -6200 || this.pos.z > 6200) { const want = Math.atan2(-400 - this.pos.x, -this.pos.z); this.heading += clamp(want - this.heading, -1, 1) * dt; this.onMsg && this.onMsg('Limite de la zone de vol : retour vers Cotonou'); }
    // contact avec le sol / l'eau / les bâtiments
    let crash = null;
    if (this.airborne && this.pos.y <= 0 && this.vs <= 0) {
      if (overWater(this.pos.x, this.pos.z)) crash = 'Amerrissage forcé : l’avion est ramené à l’aéroport';
      else if (!this.gearDown) crash = 'Atterrissage sur le ventre (train rentré) : l’avion est ramené à l’aéroport';
      else if (this.vs < -7.5 || Math.abs(this.roll) > 0.35 || this.pitch < -0.12) crash = 'Atterrissage trop brutal : l’avion est ramené à l’aéroport';
      else { this.airborne = false; this.pos.y = 0; this.vs = 0; this.stall = false; this.onMsg && this.onMsg('Posé ! Réduis les gaz et freine avec Espace'); }
    }
    if (!this.airborne && overWater(this.pos.x, this.pos.z)) crash = 'L’avion est allé dans l’eau : il est ramené à l’aéroport';
    if (!crash && this.pos.y < 45) {
      const f = this.forward, nose = this.pspec.len / 2;
      for (const k of [0, nose * 0.9]) if (solidAt(world.collision, this.pos.x + f.x * k, this.pos.y + S.centerY, this.pos.z + f.z * k)) { crash = 'Collision avec un bâtiment : l’avion est ramené à l’aéroport'; break; }
    }
    if (crash && this.onCrash) this.onCrash(this, crash);
    this.rpm = this.throttle;
    this.sync(dt);
    return 0;
  }
  sync(dt) {
    this.mesh.position.copy(this.pos);
    this.mesh.rotation.set(-this.pitch, this.heading, this.roll, 'YXZ');
    const P = this.parts;
    for (const s of P.spinners) s.o.rotation.z += dt * (this.occupied ? (s.prop ? 8 + this.throttle * 40 : 6 + this.throttle * 30) : 0);
    P.gear.scale.y = this.pspec.fixedGear ? 1 : Math.max(0.02, this.gearT); P.gear.visible = this.gearT > 0.05 || this.pspec.fixedGear;
    P.flaps.forEach((f) => { f.rotation.x = this.flapsT * 0.5; });
    if (P.stairs) P.stairs.visible = !this.occupied && !this.airborne && this.speed < 0.5 && this.atStand;
  }
}

// =====================================================================
// Aéroport : gestion, interface, vol
// =====================================================================
export class Airport {
  constructor(ctx) {
    Object.assign(this, ctx); // scene, world, camera, player, ui, audio, env, settings, onSave, boardFn, onTeleport
    this.outskirts = buildOutskirts(this.scene, this.settings.quality);
    this.site = buildAirportSite(this.scene, this.world.collision);
    this.openCityWall();
    this.recs = PLANES.map((sp) => ({ id: sp.id, ...standOf(sp), y: 0, moved: false }));
    this.planes = new Map();
    this.open = false; this.sel = PLANES[4].id; this.cockpit = false;
    this.buildDom();
  }
  // ouvre le mur invisible ouest de la ville pour la route de l'aéroport (z 93 → 107)
  openCityWall() {
    const col = this.world.collision;
    for (const o of col.objects) if (o.t === 0 && o.minX <= -399 && o.maxX >= MAP.minX - 2 && o.maxX <= MAP.minX && o.minZ <= -399 && o.maxZ >= 399) o.disabled = true;
    col.addBox(-400, -400, MAP.minX - 1, 92, 50).invisible = true; col.addBox(-400, 108, MAP.minX - 1, 400, 50).invisible = true;
  }
  zoneName(x, z) {
    if (x > AIRPORT.x0 && x < AIRPORT.x1 && z > AIRPORT.z0 && z < AIRPORT.z1 + 6) return 'Aéroport de Cotonou';
    if (z > 92 && z < 108 && x < MAP.minX && x > AIRPORT.x1 - 2) return 'Route de l’aéroport';
    const pl = this.player.inCar;
    if (pl && pl.isAircraft && pl.airborne) return z > coastZ(x) ? 'Au-dessus du golfe de Guinée' : overWater(x, z) ? 'Au-dessus du lac Nokoué' : x < MAP.minX || x > MAP.maxX || z < MAP.minZ ? 'Au-dessus des environs de Cotonou' : 'Au-dessus de Cotonou';
    return null;
  }
  spawnPlane(rec) {
    if (this.planes.has(rec.id)) return this.planes.get(rec.id);
    const a = new Aircraft(this.scene, PLANE_BY_ID[rec.id], rec);
    a.atStand = !rec.moved;
    a.onMsg = (m) => this.ui.toast(m, 2.2);
    a.onCrash = (pl, msg) => this.resetPlane(pl, msg);
    this.planes.set(rec.id, a); return a;
  }
  despawnPlane(id) { const a = this.planes.get(id); if (!a || a.occupied) return; this.scene.remove(a.mesh); this.planes.delete(id); }
  resetPlane(pl, msg) {
    this.ui.toast(msg, 3.5); this.ui.fade(true);
    setTimeout(() => this.ui.fade(false), 700);
    this.toRunway(pl);
  }
  toRunway(pl) {
    pl.pos.set(AIRPORT.rwX1 - 25, 0, AIRPORT.rwZ); pl.heading = -PI / 2; pl.pitch = 0; pl.roll = 0; pl.speed = 0; pl.vs = 0; pl.throttle = 0; pl.airborne = false; pl.gearDown = true; pl.gearT = 1; pl.atStand = false;
    const rec = this.recs.find((r) => r.id === pl.id); Object.assign(rec, { x: pl.pos.x, z: pl.pos.z, h: pl.heading, y: 0, moved: true });
    pl.sync(0);
  }
  board(pl) {
    const P = this.player;
    this.ui.fade(true);
    setTimeout(() => {
      P.inCar = pl; pl.occupied = true; P.mesh.visible = false; pl.atStand = false;
      if (this.tpc) this.tpc.yaw = pl.heading + PI;
      this.ui.fade(false);
      const tch = document.body.classList.contains('touch');
      this.ui.toast(tch ? `${pl.pspec.name} : 🏃 gaz + (bascule) • ⤒ gaz − / freins • joystick : monter, descendre, virer • ✦ train • 👁 cockpit` : `${pl.pspec.name} : Maj = gaz +, Espace = gaz − / freins, Z/W monter, S descendre, Q-D virer, G train, B volets, V vue cockpit, E descendre (au sol, à l’arrêt)`, 7);
      if (this.audio && this.audio.ctx) this.audio.tone(880, 0.25, 0.05, 'sine');
    }, 450);
  }
  nearest(x, z) {
    let best = null;
    const dk = Math.hypot(x - KIOSK.x, z - (KIOSK.z - 2.6));
    if (dk < 3) best = { d: dk, it: { label: () => 'Comptoir des vols : choisir un avion', action: () => this.toggle(true) } };
    for (const pl of this.planes.values()) {
      if (pl.occupied || pl.airborne) continue;
      const dp = pl.exitPoint(); const d = Math.hypot(x - dp.x, z - dp.z);
      if (d < 3.2 && (!best || d < best.d)) best = { d, it: { label: () => `Embarquer à bord du ${pl.pspec.name}`, action: () => this.board(pl) } };
    }
    return best;
  }
  update(dt, t) {
    const P = this.player.pos, flying = this.player.inCar && this.player.inCar.isAircraft ? this.player.inCar : null;
    // avions chargés à proximité de l'aéroport (ou là où on les a laissés)
    for (const rec of this.recs) {
      const pl = this.planes.get(rec.id);
      if (pl && pl.occupied) { rec.x = pl.pos.x; rec.z = pl.pos.z; rec.h = pl.heading; if (pl.speed > 0.5 || pl.pushback) rec.moved = true; continue; }
      const d = Math.hypot(rec.x - P.x, rec.z - P.z);
      if (!pl && d < 1800) this.spawnPlane(rec); else if (pl && d > 2400) this.despawnPlane(rec.id);
    }
    for (const pl of this.planes.values()) if (pl !== flying && !pl.occupied) pl.sync(dt);
    // balisage la nuit, manche à air au vent
    this.site.lmat.emissiveIntensity = 0.2 + this.env.lightsOn * 3;
    this.site.sock.rotation.y = Math.sin(t * 0.3) * 0.3;
    // qualité basse (téléphone) : banlieues et arbres lointains seulement en vol ou près de l'aéroport
    const lowQ = this.settings.quality === 'low', showDetail = !lowQ || !!flying || P.x < -300;
    for (const m of this.outskirts.userData.detail) m.visible = showDetail;
    // en vol : horizon lointain visible, brume repoussée
    const cam = this.camera;
    if (flying) {
      const alt = flying.pos.y;
      if (!this._far) { this._far = cam.far; this._near = cam.near; }
      cam.far = 14000; cam.near = 0.3; cam.updateProjectionMatrix();
      const fog = this.scene.fog; fog.far = Math.max(fog.far, Math.min(5200, 900 + alt * 6 + flying.speed * 4)); fog.near = Math.max(fog.near, Math.min(800, alt * 1.5));
    } else if (this._far) { cam.far = this._far; cam.near = this._near; this._far = null; cam.updateProjectionMatrix(); }
    this.updateHud(flying);
    if (this.open) this.renderPreview(t);
  }
  applyCockpit(camera, tpc) {
    const pl = this.player.inCar;
    if (!this.cockpit || !pl || !pl.isAircraft) return false;
    pl.mesh.updateMatrixWorld(true);
    const eye = pl.parts.eye.clone(); pl.mesh.localToWorld(eye);
    let rel = tpc.yaw - (pl.heading + PI); while (rel > PI) rel -= 2 * PI; while (rel < -PI) rel += 2 * PI; rel = clamp(rel, -1.6, 1.6);
    camera.position.copy(eye);
    camera.quaternion.copy(pl.mesh.quaternion);
    camera.rotateY(PI - rel); camera.rotateX(clamp(-(tpc.pitch - 0.3) * 0.7, -0.6, 0.5));
    return true;
  }

  // ---------- tableau de bord de vol ----------
  updateHud(pl) {
    const el = this.dom.hud;
    if (!!pl !== this._hudOn) { this._hudOn = !!pl; el.classList.toggle('show', !!pl); document.body.classList.toggle('flying', !!pl); }
    if (!pl) return;
    const kmh = Math.round(pl.speed * 3.6), kt = Math.round(pl.speed * 1.944), alt = Math.round(pl.pos.y), vs = pl.vs;
    let hdg = Math.round(((PI - pl.heading) * 180 / PI + 360 * 4) % 360); // 0 = nord (vers la lagune), 180 = sud (vers la mer)
    const card = ['N', 'NE', 'E', 'SE', 'S', 'SO', 'O', 'NO'][Math.round(hdg / 45) % 8];
    const q = (k) => el.querySelector(k);
    q('.f-name').textContent = pl.pspec.name;
    q('.f-spd b').textContent = kmh; q('.f-spd small').textContent = `km/h • ${kt} nœuds`;
    q('.f-alt b').textContent = alt; q('.f-alt small').textContent = `m • ${vs >= 0 ? '+' : ''}${vs.toFixed(1)} m/s`;
    q('.f-hdg').textContent = `${String(hdg).padStart(3, '0')}° ${card}`;
    q('.f-thr i').style.height = Math.round(pl.throttle * 100) + '%'; q('.f-thr-l').textContent = `GAZ ${Math.round(pl.throttle * 100)} %`;
    q('.f-horizon i').style.transform = `rotate(${(-pl.roll * 180 / PI).toFixed(1)}deg) translateY(${(pl.pitch * 120).toFixed(1)}px)`;
    if (pl.isHeli) {
      q('.f-thr-l').textContent = `ROTOR ${Math.round(pl.rpm * 100)} %`; q('.f-thr i').style.height = Math.round(pl.rpm * 100) + '%';
      q('.f-state').innerHTML = `<span class="${pl.engine ? 'on' : ''}">MOTEUR ${pl.engine ? 'EN MARCHE' : 'COUPÉ'}</span><span>${pl.airborne ? 'EN VOL' : 'POSÉ'}</span>${this.cockpit ? '<span>COCKPIT</span>' : ''}`;
      q('.f-warn').textContent = pl.airborne && !pl.engine ? 'AUTOROTATION — PRÉPARE L’ATTERRISSAGE' : pl.airborne && pl.pos.y < 25 && pl.vs < -5 ? 'DESCENTE TROP RAPIDE' : !pl.engine && !pl.airborne ? 'G : DÉMARRER LE MOTEUR' : pl.rpm < 0.92 ? 'MONTÉE EN RÉGIME DU ROTOR…' : '';
      return;
    }
    q('.f-state').innerHTML = `<span class="${pl.gearDown ? 'on' : ''}">TRAIN ${pl.gearDown ? 'SORTI' : 'RENTRÉ'}</span><span>VOLETS ${['0', '15', '30'][pl.flaps]}${pl.flapsAuto ? ' A' : ''}</span><span>${pl.airborne ? 'EN VOL' : 'AU SOL'}</span>${this.cockpit ? '<span>COCKPIT</span>' : ''}`;
    q('.f-warn').textContent = pl.stall ? 'DÉCROCHAGE — PIQUE ET METS LES GAZ' : pl.airborne && pl.pos.y < 60 && pl.vs < -6 ? 'TROP BAS — REDRESSE' : !pl.airborne && pl.speed > pl.pspec.vRot * 0.9 ? 'ROTATION : TIRE (Z/W)' : '';
  }

  // ---------- comptoir des vols ----------
  buildDom() {
    const $ = (s) => document.querySelector(s);
    this.dom = { root: $('#air'), hud: $('#fhud') };
    this.dom.hud.innerHTML = `<div class="f-name"></div><div class="f-row"><div class="f-spd"><b>0</b><small></small></div><div class="f-horizon"><i></i><span></span></div><div class="f-alt"><b>0</b><small></small></div></div>
      <div class="f-row2"><div class="f-thr"><i></i></div><div><div class="f-hdg"></div><div class="f-thr-l"></div><div class="f-state"></div></div></div><div class="f-warn"></div>`;
    const r = this.dom.root;
    r.innerHTML = `<div class="g-box"><div class="g-head"><h2>VOLS <span>AÉROPORT DE COTONOU</span></h2><button class="g-x">✕</button></div>
      <div class="g-main"><div class="g-list"></div><div class="g-detail"><canvas class="g-pv" width="360" height="200"></canvas><div class="g-name"></div><div class="g-type"></div><div class="g-stats"></div>
      <div class="a-btns"><button class="g-take a-run">PRÉPARER SUR LA PISTE</button><button class="a-stand">EMBARQUER AU PARKING</button></div>
      <p class="g-note">Avions et compagnie fictifs, inspirés de catégories d’appareils réels. Pilotage simplifié (arcade).</p></div></div></div>`;
    r.querySelector('.g-x').addEventListener('click', (e) => { e.stopPropagation(); this.toggle(false); });
    r.querySelector('.g-list').addEventListener('click', (e) => { const c = e.target.closest('[data-pl]'); if (!c) return; e.stopPropagation(); this.sel = c.dataset.pl; this.renderMenu(); });
    r.querySelector('.a-run').addEventListener('click', (e) => { e.stopPropagation(); this.prepare(this.sel, true); });
    r.querySelector('.a-stand').addEventListener('click', (e) => { e.stopPropagation(); this.prepare(this.sel, false); });
  }
  prepare(id, runway) {
    this.toggle(false);
    const rec = this.recs.find((r) => r.id === id);
    const pl = this.spawnPlane(rec);
    if (pl.occupied) return;
    if (runway) this.toRunway(pl);
    else if (rec.moved) { Object.assign(rec, standOf(pl.pspec), { y: 0, moved: false }); pl.pos.set(rec.x, 0, rec.z); pl.heading = rec.h; pl.airborne = false; pl.speed = 0; pl.atStand = true; pl.sync(0); }
    const dp = pl.exitPoint(); this.player.pos.set(dp.x, 0, dp.z);
    this.board(pl);
    this.onSave && this.onSave();
  }
  toggle(on = !this.open) { this.open = on; this.dom.root.classList.toggle('show', on); if (on) this.renderMenu(); }
  renderMenu() {
    const r = this.dom.root;
    r.querySelector('.g-list').innerHTML = PLANES.map((p) => `<button class="g-card${p.id === this.sel ? ' sel' : ''}" data-pl="${p.id}"><b>${p.name}</b><small>${p.type}</small><span class="g-mini">${p.seats} places • ${p.engines}</span></button>`).join('');
    const p = PLANE_BY_ID[this.sel];
    r.querySelector('.g-name').textContent = p.name; r.querySelector('.g-type').textContent = p.type;
    const bar = (k, v, max, txt) => `<div><span>${k}</span><i><b style="width:${Math.round(v / max * 100)}%"></b></i><em>${txt}</em></div>`;
    r.querySelector('.g-stats').innerHTML = bar('Vitesse max', p.vMax, 270, Math.round(p.vMax * 3.6) + ' km/h') + bar('Décollage', p.vRot, 90, Math.round(p.vRot * 3.6) + ' km/h')
      + bar('Maniabilité', p.roll, 1.7, p.roll > 1.3 ? 'très agile' : p.roll > 0.8 ? 'agile' : 'lourd') + bar('Taille', p.len, 75, `${p.len} m • env. ${p.span} m`)
      + `<div><span>Moteurs</span><em class="g-wide">${p.engines}</em></div>`;
    this._pvKey = null;
  }
  renderPreview(t) {
    if (!this.studio) {
      const sc = new THREE.Scene(); sc.add(new THREE.HemisphereLight(0xffffff, 0x404040, 1.5)); const d = new THREE.DirectionalLight(0xffffff, 2.5); d.position.set(4, 8, 6); sc.add(d);
      const lut = new Uint8ClampedArray(256); for (let i = 0; i < 256; i++) { const v = i / 255; lut[i] = Math.round(255 * (v <= 0.0031308 ? v * 12.92 : 1.055 * Math.pow(v, 1 / 2.4) - 0.055)); }
      this.studio = { sc, cam: new THREE.PerspectiveCamera(30, 1.8, 0.1, 600), rt: new THREE.WebGLRenderTarget(360, 200), lut, px: new Uint8Array(360 * 200 * 4), img: new ImageData(360, 200) };
    }
    const St = this.studio;
    if (this._pvKey !== this.sel) { this._pvKey = this.sel; if (St.m) St.sc.remove(St.m); St.m = buildPlaneMesh(PLANE_BY_ID[this.sel]).group; St.sc.add(St.m); }
    if ((this._pvF = (this._pvF || 0) + 1) % 2) return;
    const p = PLANE_BY_ID[this.sel], R = Math.max(p.len, p.span) * 0.62;
    St.m.rotation.y = t * 0.5;
    St.cam.position.set(0, p.centerY + R * 0.55, R * 2.1); St.cam.lookAt(0, p.centerY, 0); St.cam.far = R * 8; St.cam.updateProjectionMatrix();
    const r = this.renderer, prev = r.getRenderTarget(), pc = r.getClearColor(new THREE.Color()), pa = r.getClearAlpha();
    St.sc.environment = this.scene.environment;
    r.setRenderTarget(St.rt); r.setClearColor(0, 0); r.clear(); r.render(St.sc, St.cam); r.readRenderTargetPixels(St.rt, 0, 0, 360, 200, St.px); r.setRenderTarget(prev); r.setClearColor(pc, pa);
    const { px, img, lut } = St;
    for (let y = 0; y < 200; y++) for (let x = 0; x < 360; x++) { const s = ((199 - y) * 360 + x) * 4, o = (y * 360 + x) * 4, a = px[s + 3], un = a ? 255 / a : 0; img.data[o] = lut[Math.min(255, (px[s] * un) | 0)]; img.data[o + 1] = lut[Math.min(255, (px[s + 1] * un) | 0)]; img.data[o + 2] = lut[Math.min(255, (px[s + 2] * un) | 0)]; img.data[o + 3] = a; }
    this.dom.root.querySelector('.g-pv').getContext('2d').putImageData(img, 0, 0);
  }
  handleKeys(input) {
    if (input.hit('Escape')) { this.toggle(false); return; }
    let i = PLANES.findIndex((p) => p.id === this.sel);
    if (input.hit('ArrowDown') || input.hit('KeyS')) i = Math.min(PLANES.length - 1, i + 1);
    if (input.hit('ArrowUp') || input.hit('KeyW') || input.hit('KeyZ')) i = Math.max(0, i - 1);
    if (PLANES[i].id !== this.sel) { this.sel = PLANES[i].id; this.renderMenu(); }
    if (input.hit('Enter')) this.prepare(this.sel, true);
  }
  serialize() { return { planes: this.recs.filter((r) => r.moved).map((r) => ({ id: r.id, x: Math.round(r.x), z: Math.round(r.z), h: +r.h.toFixed(3) })) }; }
  restore(s) { if (!s || !Array.isArray(s.planes)) return; for (const p of s.planes) { const r = this.recs.find((x) => x.id === p.id); if (r) Object.assign(r, { x: p.x, z: p.z, h: p.h, y: 0, moved: true }); } }
}
