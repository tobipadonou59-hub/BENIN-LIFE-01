// Mission 021, étape 5 — tourisme au Bénin. Sites RÉELS représentés de façon stylisée (architecture simplifiée, position
// dans la ville du jeu non géographique) : Route de l'Esclave et Porte du Non-Retour, Temple des Pythons, forêt sacrée de
// Kpassè (Ouidah) ; musée Honmè, Grande Mosquée, Jardin des plantes et de la nature (Porto-Novo) ; Ganvié (lac Nokoué).
// Sites existants réutilisés à Cotonou (plage de la Marina, place de l'Amazone, place des Martyrs, marché Dantokpa,
// jardin de Cadjèhoun). Un village artisanal FICTIF. Visites libres ou guidées (textes sobres, respect des traditions
// vodun), photos souvenirs, carnet de voyage, circuits, où manger (restaurants existants). Tarifs du jeu (fictifs).
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { colorize } from './vehicles.js';
import { createCharacter, SKINS } from './character.js';
import { fcfa } from './food-data.js';
import { ARTICLE_BY_ID } from './market-data.js';
import { TOWNS, coastZ, inLake, nearRoad } from './region-geo.js';

const PI = Math.PI;
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const pick = (a) => a[Math.floor(Math.random() * a.length)];
const RESPECT = 'Lieu sacré : tenue correcte, on suit les consignes du guide et des gardiens du culte, photos seulement là où elles sont permises.';
// [id, nom, ville, catégorie, statut, prix d'entrée (jeu), prix du guide (jeu), présentation, étapes de la visite guidée]
const SITES = [
  ['porte', 'Porte du Non-Retour', 'Ouidah', 'monument', 'stylise', 0, 5000, 'Mémorial érigé sur la plage de Ouidah, au bout de la Route de l’Esclave, en hommage aux millions d’Africains déportés pendant la traite atlantique.',
    ['La Porte du Non-Retour marque le lieu d’où des captifs étaient embarqués vers les Amériques.', 'Le monument fait partie du projet « La Route de l’Esclave » soutenu par l’UNESCO ; ses bas-reliefs évoquent des colonnes de captifs enchaînés.', 'C’est un lieu de mémoire et de recueillement : de nombreux descendants d’Africains déportés viennent s’y recueillir.', 'Représentation stylisée dans le jeu : ce n’est pas une copie fidèle du monument.']],
  ['route', 'Route de l’Esclave', 'Ouidah', 'monument', 'stylise', 0, 5000, 'Chemin de mémoire d’environ 4 km entre la ville de Ouidah et la plage, jalonné de lieux et de monuments commémoratifs.',
    ['La route part de la place où les captifs étaient vendus et mène jusqu’à la plage.', 'On y trouve notamment l’Arbre de l’Oubli, autour duquel les captifs devaient tourner, selon la tradition, pour oublier leurs origines.', 'Plus loin, la case Zomaï et le mémorial de Zoungbodji rappellent les conditions terribles de la détention.', 'L’Arbre du Retour symbolise le retour des âmes vers la terre de leurs ancêtres, avant la Porte du Non-Retour.', 'Dans le jeu, la route est raccourcie et ses étapes sont représentées par des stèles.']],
  ['pythons', 'Temple des Pythons', 'Ouidah', 'monument', 'stylise', 2000, 5000, 'Temple vodun consacré à Dangbé, le python sacré, situé face à la basilique de Ouidah.',
    ['Pour les fidèles du vodun, le python Dangbé est une divinité protectrice : on ne lui fait pas de mal.', 'Le temple abrite des pythons royaux, une espèce non venimeuse, sous la garde des prêtres du culte.', 'Le temple et la basilique se font face : à Ouidah, plusieurs religions coexistent depuis longtemps.', RESPECT]],
  ['kpasse', 'Forêt sacrée de Kpassè', 'Ouidah', 'loisirs', 'stylise', 2000, 5000, 'Forêt sacrée liée au roi Kpassè, figure fondatrice de Ouidah ; un lieu de culte et de promenade parsemé de sculptures.',
    ['Selon la tradition, le roi Kpassè s’est transformé en arbre pour échapper à ses ennemis ; un iroko lui est consacré.', 'La forêt est un lieu sacré du vodun ; des sculptures y représentent des divinités et des figures de l’histoire.', 'Elle protège aussi une végétation et des arbres très anciens au cœur de la ville.', RESPECT, 'Les sculptures du jeu sont des évocations simplifiées, pas des copies des œuvres réelles.']],
  ['honme', 'Musée Honmè (ancien palais royal)', 'Porto-Novo', 'monument', 'stylise', 2000, 5000, 'Ancien palais des rois de Porto-Novo, aujourd’hui musée sur l’histoire du royaume et la vie de la cour.',
    ['Porto-Novo, capitale du Bénin, fut le siège d’un royaume ancien, appelé Hogbonou ou Xogbonou.', 'Le palais Honmè réunit des cours, des cases et des espaces réservés au roi et aux cérémonies.', 'On y découvre l’organisation de la cour, les objets royaux et des rites de la tradition.', 'Représentation stylisée dans le jeu.']],
  ['mosquee', 'Grande Mosquée de Porto-Novo', 'Porto-Novo', 'monument', 'stylise', 0, 3000, 'Mosquée aux couleurs vives, construite au début du XXe siècle dans le style afro-brésilien.',
    ['Son architecture rappelle les églises de Bahia au Brésil : elle a été bâtie par des Afro-Brésiliens revenus au Bénin.', 'C’est un lieu de prière : la visite se fait en dehors des heures de prière, avec une tenue respectueuse.', 'Représentation stylisée dans le jeu (couleurs et formes simplifiées).']],
  ['jardin', 'Jardin des plantes et de la nature', 'Porto-Novo', 'loisirs', 'stylise', 1000, 3000, 'Jardin botanique au cœur de Porto-Novo : arbres tropicaux, plantes médicinales et petite forêt sacrée.',
    ['Le jardin présente de nombreuses espèces végétales du Bénin et d’Afrique de l’Ouest.', 'On y voit des plantes utilisées dans la médecine traditionnelle.', 'Une partie du jardin est une forêt sacrée, à respecter comme telle.']],
  ['ganvie', 'Ganvié, la cité lacustre', 'Lac Nokoué', 'loisirs', 'stylise', 15000, 0, 'Village sur pilotis au milieu du lac Nokoué, souvent surnommé « la Venise de l’Afrique ». Excursion en pirogue depuis l’embarcadère.',
    ['Ganvié a été fondé par les Tofinu, qui se sont réfugiés sur le lac pour échapper aux chasseurs d’esclaves.', 'Les maisons sont construites sur pilotis ; on se déplace en pirogue, même pour aller au marché.', 'La pêche est l’activité principale, notamment grâce aux « acadjas », des enclos de branchages où les poissons se reproduisent.', 'Dans le jeu, l’excursion est racontée (aperçu) : le village n’est pas encore modélisé en entier.']],
  ['marina', 'Plage de la Marina', 'Cotonou', 'loisirs', 'stylise', 0, 0, 'Plage de sable le long du boulevard de la Marina. Promenade, coucher de soleil, noix de coco fraîche. Baignade dangereuse (courants forts).', []],
  ['amazone', 'Place de l’Amazone', 'Cotonou', 'monument', 'stylise', 0, 3000, 'Place en bord de mer dominée par une statue rendant hommage aux Agodjié, les guerrières de l’ancien royaume du Dahomey.',
    ['Les Agodjié, appelées « Amazones » par les Européens, formaient un corps de guerrières au service des rois du Dahomey.', 'La statue de la place leur rend hommage ; celle du jeu est une interprétation libre, pas une copie de l’œuvre réelle.']],
  ['martyrs', 'Place des Martyrs', 'Cotonou', 'monument', 'stylise', 0, 0, 'Grande place commémorative de Cotonou.', []],
  ['dantokpa', 'Marché Dantokpa', 'Cotonou', 'marche', 'stylise', 0, 0, 'Grand marché de Cotonou, au bord de la lagune, l’un des plus grands d’Afrique de l’Ouest : tissus, épices, artisanat, produits frais.', []],
  ['village', 'Village artisanal de la Marina', 'Cotonou', 'marche', 'fictif', 0, 0, 'Marché artisanal fictif pour les visiteurs : tentures appliquées, sculptures, tissus, bijoux en perles, vanneries.', []],
  ['fidjrosse', 'Plage de Fidjrossè', 'Cotonou', 'loisirs', 'stylise', 0, 0, 'Plage populaire de l’ouest de Cotonou, animée le week-end. Baignade dangereuse (courants forts).', []],
].map(([id, name, town, cat, status, fee, guide, desc, tour]) => ({ id, name, town, cat, status, fee, guide, desc, tour }));
const SBY = Object.fromEntries(SITES.map((s) => [s.id, s]));
const CRAFT = [ // articles du village artisanal (fictif)
  ['art_tenture', '🧵', 'Tenture appliquée (style d’Abomey)', 'Tissu cousu de motifs symboliques, artisanat du Bénin.', 35000],
  ['art_sculpture', '🪵', 'Sculpture en bois (artisanat)', 'Pièce sculptée par un artisan, bois local.', 25000],
  ['art_perles', '📿', 'Collier en perles', 'Bijou artisanal en perles de verre.', 8000],
  ['art_panier', '🧺', 'Panier tressé', 'Vannerie artisanale.', 6000],
  ['art_batik', '🖼️', 'Tableau batik', 'Peinture sur tissu, scène de la vie quotidienne.', 15000],
  ['art_kente', '🧣', 'Étole tissée', 'Étole tissée à la main, couleurs vives.', 12000],
];
for (const [id, icon, name, desc] of CRAFT) if (!ARTICLE_BY_ID[id]) ARTICLE_BY_ID[id] = { id, icon, name, desc };
const CIRCUITS = [
  { id: 'ouidah', name: 'Ouidah, mémoire et spiritualité', price: 25000, sites: ['route', 'porte', 'pythons', 'kpasse'], desc: 'Route de l’Esclave, Porte du Non-Retour, Temple des Pythons, forêt sacrée de Kpassè (guide inclus toute la journée).' },
  { id: 'portonovo', name: 'Porto-Novo, capitale culturelle', price: 18000, sites: ['honme', 'mosquee', 'jardin'], desc: 'Musée Honmè, Grande Mosquée, Jardin des plantes et de la nature (guide inclus).' },
  { id: 'cotonou', name: 'Cotonou, du marché à la mer', price: 10000, sites: ['dantokpa', 'amazone', 'martyrs', 'marina', 'village'], desc: 'Marché Dantokpa, places de l’Amazone et des Martyrs, plage, village artisanal (guide inclus).' },
];
const GUIDES = ['Guide Hospice Agossa', 'Guide Florence Dossou', 'Guide Anicet Houngbo', 'Guide Clémence Akpo'];

export class Tourism {
  constructor(ctx) {
    Object.assign(this, ctx); // T, scene, world, player, ui, audio, env, economy, needs, venues, driver, onSave
    this.visited = {}; this.photos = []; this.circuit = null; this.view = 'sites'; this.people = []; this.points = []; this.groups = [];
    if (this.T) { this.T.tourism = this; if (this.T._tour) this.restore(this.T._tour); }
    this.place(); this.build();
  }
  site(id) { return SBY[id]; }
  day() { return this.economy.day || 1; }
  save() { this.onSave && this.onSave(); }
  // ------------------------------------------------------------------ placement (terrain libre vérifié)
  freeDisk(x, z, r) { const C = this.world.collision; for (let a = -r; a <= r; a += 1.5) for (let b = -r; b <= r; b += 1.5) { if (a * a + b * b > r * r) continue; const px = x + a, pz = z + b; if (C.pointBlocked(px, 1, pz) || inLake(px, pz) || pz > coastZ(px) - 4 || nearRoad(px, pz)) return false; } return true; }
  findFree(cx, cz, r, r0 = 0, r1 = 300) { for (let d = r0; d <= r1; d += 6) for (let k = 0; k < Math.max(1, Math.round(d / 5)); k++) { const a = (k / Math.max(1, Math.round(d / 5))) * PI * 2 + d * 0.37, x = cx + Math.cos(a) * d, z = cz + Math.sin(a) * d; if (this.freeDisk(x, z, r)) return { x, z }; } return null; }
  reserve(x, z, r, h = 3) { const C = this.world.collision; return C.addBox(x - r, z - r, x + r, z + r, h); }
  place() {
    const W = this.world, T = (n) => TOWNS.find((t) => t.name === n), O = T('Ouidah'), PN = T('Porto-Novo');
    const at = (id, p) => { if (p) SBY[id].pos = p; };
    if (O) {
      const cz = coastZ(O.x), beach = this.findFree(O.x, cz - 32, 7, 0, 60); at('porte', beach);
      const start = this.findFree(O.x, O.z + 40, 3, 0, 90); at('route', start);
      if (start && beach) { SBY.route.stops = []; const names = ['Place des enchères', 'Arbre de l’Oubli', 'Case Zomaï', 'Mémorial de Zoungbodji', 'Arbre du Retour'];
        names.forEach((n, i) => { const f = i / names.length, p = this.findFree(start.x + (beach.x - start.x) * f, start.z + (beach.z - start.z) * f, 2.5, 0, 40); if (p) SBY.route.stops.push({ n, ...p, tree: /Arbre/.test(n) }); }); }
      at('pythons', this.findFree(O.x - 30, O.z - 10, 9, 0, 200)); at('kpasse', this.findFree(O.x + 40, O.z - 30, 13, 0, 260));
    }
    if (PN) { at('honme', this.findFree(PN.x - 20, PN.z + 20, 10, 0, 240)); at('mosquee', this.findFree(PN.x + 30, PN.z, 8, 0, 240)); at('jardin', this.findFree(PN.x, PN.z - 60, 13, 0, 300)); }
    // Ganvié : embarcadère sur la rive du lac Nokoué la plus proche de Cotonou
    let shore = null; for (let t = 0; t <= 1 && !shore; t += 0.004) { const x = 0 + 1700 * t, z = -230 - 1470 * t; if (inLake(x, z)) { const back = t - 0.012; shore = { x: 1700 * back, z: -230 - 1470 * back, lx: x, lz: z }; } }
    if (shore) { const p = this.findFree(shore.x, shore.z, 4, 0, 60); if (p) at('ganvie', { ...p, lx: shore.lx, lz: shore.lz }); }
    // Cotonou : sites existants (points de visite à côté, sans gêner les interactions existantes)
    at('marina', this.findFree(-30, 172, 1.5, 0, 30)); at('fidjrosse', this.findFree(-250, 174, 1.5, 0, 40));
    if (W.amazone) at('amazone', this.findFree(W.amazone.x, W.amazone.z, 1.2, 9, 30)); if (W.martyrs && W.martyrs.x !== undefined) at('martyrs', this.findFree(W.martyrs.x, W.martyrs.z, 1.2, 6, 40));
    at('dantokpa', this.findFree(-50, 80, 1.2, 0, 30)); at('village', this.findFree(40, 172, 6, 0, 50));
    for (const s of SITES) if (s.pos) { const pois = this.ui.pois; if (pois && !pois.some((q) => q.id === `tour_${s.id}`) && !['marina', 'amazone', 'martyrs', 'dantokpa'].includes(s.id)) pois.push({ id: `tour_${s.id}`, name: s.name, cat: s.cat, x: s.pos.x, z: s.pos.z, status: s.status, access: true, address: s.town, note: s.status === 'fictif' ? 'Lieu fictif (inventé pour le jeu)' : 'Lieu réel représenté de façon stylisée' }); }
  }
  // ------------------------------------------------------------------ constructions stylisées
  build() {
    const C = this.world.collision;
    for (const s of SITES) {
      if (!s.pos) continue; const parts = [], glow = [], { x, z } = s.pos;
      const box = (x0, y0, z0, x1, y1, z1, c, arr = parts) => arr.push(colorize(new THREE.BoxGeometry(Math.abs(x1 - x0) || 0.01, Math.abs(y1 - y0) || 0.01, Math.abs(z1 - z0) || 0.01).translate(x + (x0 + x1) / 2, (y0 + y1) / 2, z + (z0 + z1) / 2), c));
      const tree = (tx, tz, h, r, c = 0x2f6a2a) => { parts.push(colorize(new THREE.CylinderGeometry(0.25, 0.4, h, 6).translate(x + tx, h / 2, z + tz), 0x5a4228)); parts.push(colorize(new THREE.SphereGeometry(r, 8, 6).translate(x + tx, h + r * 0.5, z + tz), c)); C.addCircle(x + tx, z + tz, 0.45, h); };
      const solid = (x0, z0, x1, z1, h) => C.addBox(x + x0, z + z0, x + x1, z + z1, h);
      const wallRing = (w, d, h, c, gap) => { box(-w, 0, -d, w, h, -d + 0.4, c); solid(-w, -d, w, -d + 0.4, h); box(-w, 0, -d, -w + 0.4, h, d, c); solid(-w, -d, -w + 0.4, d, h); box(w - 0.4, 0, -d, w, h, d, c); solid(w - 0.4, -d, w, d, h); box(-w, 0, d - 0.4, -gap, h, d, c); solid(-w, d - 0.4, -gap, d, h); box(gap, 0, d - 0.4, w, h, d, c); solid(gap, d - 0.4, w, d, h); };
      let pt = { x: x, z: z + 3 };
      if (s.id === 'porte') { // arche commémorative (interprétation libre) tournée vers la mer
        box(-6, 0, -1, 6, 0.6, 3, 0xb89a72); for (const sx of [-1, 1]) { box(sx * 3.2 - 1.2, 0.6, -0.6, sx * 3.2 + 1.2, 9, 1.6, 0x9a5a3a); solid(sx * 3.2 - 1.2, -0.6, sx * 3.2 + 1.2, 1.6, 9); for (let k = 0; k < 4; k++) box(sx * 3.2 - 1.0, 1.4 + k * 1.8, 1.6, sx * 3.2 + 1.0, 2.6 + k * 1.8, 1.7, 0x6a3a22); }
        box(-4.6, 9, -0.6, 4.6, 10.6, 1.6, 0x9a5a3a); box(-3.6, 10.6, -0.2, 3.6, 11.4, 1.2, 0x7a4a2a); pt = { x, z: z - 3 };
      } else if (s.id === 'route') { box(-1.5, 0, -0.3, 1.5, 1.8, 0.3, 0xc8b89a); box(-1.3, 1.0, 0.3, 1.3, 1.6, 0.32, 0x3a2a1a); solid(-1.5, -0.3, 1.5, 0.3, 1.8); pt = { x, z: z + 1.6 };
        for (const st of s.stops || []) { const sx = st.x - x, sz = st.z - z; box(sx - 0.35, 0, sz - 0.15, sx + 0.35, 1.5, sz + 0.15, 0xc8b89a); solid(sx - 0.35, sz - 0.15, sx + 0.35, sz + 0.15, 1.5); if (st.tree) tree(sx + 2, sz, 6, 3); }
      } else if (s.id === 'pythons') { wallRing(8, 6, 2.2, 0xd8c8a8, 1.4); box(-2.5, 0, -3.5, 2.5, 2.4, 0.5, 0xb8784a); parts.push(colorize(new THREE.ConeGeometry(3.8, 2.2, 8).translate(x, 3.4, z - 1.5), 0x9a8a5a)); solid(-2.5, -3.5, 2.5, 0.5, 3); tree(5, -3, 9, 3.4); box(-1.2, 2.5, 6.0, 1.2, 3.3, 6.1, 0x0b6e4f); pt = { x, z: z + 7.4 };
      } else if (s.id === 'kpasse') { const R = 11; for (let k = 0; k < 16; k++) { const a = k / 16 * PI * 2, rr = 5 + (k % 3) * 2.2; tree(Math.cos(a) * rr, Math.sin(a) * rr, 9 + (k % 4) * 2, 2.6 + (k % 3) * 0.6, k % 2 ? 0x2a5a24 : 0x3a6a2a); } tree(0, 0, 16, 4.5, 0x1f5a1f);
        for (const [a, c] of [[0.5, 0x8a5a3a], [2.2, 0x3a6a8a], [3.9, 0xc8a040], [5.3, 0x8a2a2a]]) { const sx = Math.cos(a) * 3, sz = Math.sin(a) * 3; box(sx - 0.4, 0, sz - 0.4, sx + 0.4, 2.2, sz + 0.4, c); parts.push(colorize(new THREE.SphereGeometry(0.5, 8, 6).translate(x + sx, 2.6, z + sz), c)); solid(sx - 0.4, sz - 0.4, sx + 0.4, sz + 0.4, 2.2); }
        for (const sx of [-1.6, 1.6]) { box(sx - 0.3, 0, R - 0.3, sx + 0.3, 3, R + 0.3, 0x5a3a22); solid(sx - 0.3, R - 0.3, sx + 0.3, R + 0.3, 3); } box(-1.9, 3, R - 0.3, 1.9, 3.5, R + 0.3, 0x5a3a22); pt = { x, z: z + R + 1.6 };
      } else if (s.id === 'honme') { wallRing(9, 8, 2.6, 0xb8784a, 1.6); for (const [bx, bz, w, d] of [[-4, -4, 3.5, 2.5], [4, -4, 3, 2.5], [0, -5.5, 2.5, 1.6]]) { box(bx - w, 0, bz - d, bx + w, 2.8, bz + d, 0xc88a5a); box(bx - w - 0.4, 2.8, bz - d - 0.4, bx + w + 0.4, 3.3, bz + d + 0.4, 0x7a5a3a); solid(bx - w, bz - d, bx + w, bz + d, 3.3); } box(-1.6, 2.6, 7.6, 1.6, 3.4, 8.1, 0x6a1a2a); pt = { x, z: z + 9.4 };
      } else if (s.id === 'mosquee') { box(-6, 0, -5, 6, 7, 3, 0xf2d870); box(-6.1, 6.6, -5.1, 6.1, 7.2, 3.1, 0x3a8ac8); for (const sx of [-4.5, 4.5]) { box(sx - 1.2, 0, 1.8, sx + 1.2, 11, 4.2, 0xf2a0b0); box(sx - 1.4, 10.6, 1.6, sx + 1.4, 11.2, 4.4, 0x3a8ac8); parts.push(colorize(new THREE.ConeGeometry(1.2, 2, 8).translate(x + sx, 12.2, z + 3), 0x2a9a5a)); } for (let k = 0; k < 5; k++) box(-4 + k * 2 - 0.4, 2, 3.0, -4 + k * 2 + 0.4, 4.5, 3.1, 0x2a5a8a); solid(-6, -5, 6, 4.2, 11); pt = { x, z: z + 6 };
      } else if (s.id === 'jardin') { for (let k = 0; k < 14; k++) { const a = k / 14 * PI * 2, rr = 6 + (k % 2) * 4; tree(Math.cos(a) * rr, Math.sin(a) * rr, 6 + (k % 3) * 2, 2.2 + (k % 2), [0x2f7a3a, 0x3a8a2a, 0x2a6a4a][k % 3]); } box(-3, 0.02, -2, 3, 0.08, 2, 0x4a9ad8, glow); box(-3.4, 0, -2.4, 3.4, 0.3, 2.4, 0x8a8a7a); solid(-3.4, -2.4, 3.4, 2.4, 0.6); pt = { x, z: z + 13.4 };
      } else if (s.id === 'ganvie') { const L = { x: s.pos.lx - x, z: s.pos.lz - z }, l = Math.hypot(L.x, L.z) || 1, ux = L.x / l, uz = L.z / l, ang = Math.atan2(ux, uz);
        const pier = new THREE.BoxGeometry(2.4, 0.3, 26).translate(0, 0.5, 13).rotateY(ang).translate(x, 0, z); parts.push(colorize(pier, 0x8a6440)); box(-2, 0, -2, 2, 2.6, 2, 0xc8a070); parts.push(colorize(new THREE.ConeGeometry(3, 1.6, 6).translate(x, 3.4, z), 0x9a8a5a)); solid(-2, -2, 2, 2, 3);
        for (let k = 0; k < 9; k++) { const d = 60 + (k % 3) * 22, o = (Math.floor(k / 3) - 1) * 24, hx = x + ux * d - uz * o, hz = z + uz * d + ux * o; for (const [a, b] of [[-1.5, -1.5], [1.5, -1.5], [-1.5, 1.5], [1.5, 1.5]]) parts.push(colorize(new THREE.CylinderGeometry(0.1, 0.1, 2.2, 5).translate(hx + a, 1.1, hz + b), 0x5a4228)); parts.push(colorize(new THREE.BoxGeometry(3.6, 2.2, 3.6).translate(hx, 3.3, hz), [0xc8a070, 0xb89060, 0xd8b080][k % 3])); parts.push(colorize(new THREE.ConeGeometry(3.2, 1.6, 4).rotateY(PI / 4).translate(hx, 5.2, hz), 0x8a7a4a)); }
        for (let k = 0; k < 4; k++) parts.push(colorize(new THREE.BoxGeometry(0.8, 0.3, 4.2).rotateY(ang + 0.2 * k).translate(x + ux * (14 + k * 7) + uz * 3, 0.15, z + uz * (14 + k * 7) - ux * 3), 0x5a3a22));
        pt = { x: x - ux * 3, z: z - uz * 3 };
      } else if (s.id === 'village') { for (let k = 0; k < 5; k++) { const sx = -8 + k * 4; box(sx - 1.6, 0, -1, sx + 1.6, 0.9, 0.6, 0x8a6440); for (const [a, b] of [[-1.6, -1.2], [1.6, -1.2], [-1.6, 1.2], [1.6, 1.2]]) box(sx + a - 0.06, 0, b - 0.06, sx + a + 0.06, 2.6, b + 0.06, 0x5a4228); box(sx - 1.9, 2.6, -1.5, sx + 1.9, 2.75, 1.5, [0xe8112d, 0xfcd116, 0x0b6e4f, 0x1f4e9c, 0xe46a1f][k]); for (let j = 0; j < 4; j++) box(sx - 1.3 + j * 0.7, 0.9, -0.6, sx - 0.9 + j * 0.7, 1.3, -0.2, [0xc8102e, 0xf2c200, 0x2fb04a, 0x7a2a8a][(j + k) % 4]); solid(sx - 1.6, -1, sx + 1.6, 0.6, 1.2); } pt = { x, z: z + 2.4 };
      }
      s.pt = pt;
      if (parts.length) { const g = new THREE.Group(), m = new THREE.Mesh(mergeGeometries(parts), new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.8 })); m.castShadow = true; m.receiveShadow = true; g.add(m); if (glow.length) g.add(new THREE.Mesh(mergeGeometries(glow), new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false }))); g.visible = false; this.scene.add(g); this.groups.push({ g, x, z }); }
      const lab = this.sign(s); lab.position.set(pt.x, 2.4, pt.z); this.scene.add(lab); lab.visible = false; this.groups.push({ g: lab, x, z });
    }
  }
  sign(s) {
    const c = document.createElement('canvas'); c.width = 512; c.height = 128; const x = c.getContext('2d');
    x.fillStyle = s.status === 'fictif' ? '#6a1a2a' : '#0b4a33'; x.fillRect(0, 0, 512, 128); x.fillStyle = '#fcd116'; x.fillRect(0, 118, 512, 10);
    x.fillStyle = '#fff'; x.textAlign = 'center'; x.font = '900 34px Arial'; x.fillText(s.name.length > 26 ? s.name.slice(0, 26) + '…' : s.name, 256, 52, 490); x.font = '700 22px Arial'; x.fillText(s.status === 'fictif' ? 'Lieu fictif du jeu' : 'Site réel • représentation stylisée', 256, 92);
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; const m = new THREE.Mesh(new THREE.PlaneGeometry(2.6, 0.65), new THREE.MeshBasicMaterial({ map: t, side: THREE.DoubleSide })); m.userData.bill = true; return m;
  }
  // ------------------------------------------------------------------ visites
  guided(s) { return this.circuit && this.circuit.day === this.day() && CIRCUITS.find((c) => c.id === this.circuit.id).sites.includes(s.id); }
  open(s) {
    const items = [], paid = this.paid && this.paid[s.id] === this.day();
    items.push({ label: 'ℹ️ Présentation', desc: s.status === 'fictif' ? 'Lieu fictif' : 'Site réel (représentation stylisée)', action: () => this.ui.toast(`${s.name} : ${s.desc}`, 7) });
    if (s.tour.length) items.push({ label: `🧑‍🏫 Visite guidée${this.guided(s) ? ' (circuit : incluse)' : s.guide ? '' : ' (incluse)'}`, desc: this.guided(s) || !s.guide ? `${s.tour.length} étapes` : `${fcfa(s.guide + (paid ? 0 : s.fee))}${s.fee && !paid ? ' (entrée comprise)' : ''}`, action: () => this.guide(s) });
    if (s.fee && !paid && s.id !== 'ganvie') items.push({ label: '🎟️ Visite libre', desc: `Entrée ${fcfa(s.fee)} (tarif du jeu)`, action: () => this.pay(s, s.fee, 'Entrée') && this.free(s) });
    else if (!s.fee || paid) items.push({ label: '🚶 Visite libre', desc: 'Promenade sur le site', action: () => this.free(s) });
    if (s.id === 'ganvie') items.push({ label: '🛶 Excursion en pirogue vers Ganvié (3 h)', desc: `${fcfa(s.fee)} • guide piroguier inclus`, action: () => this.ganvie(s) });
    if (s.id === 'marina' || s.id === 'fidjrosse') items.push({ label: '🌅 Attendre le coucher du soleil', action: () => this.sunset() }, { label: '🥥 Noix de coco fraîche', desc: fcfa(500), action: () => { if (!this.economy.pay(500, 'Noix de coco fraîche', s.name)) return; if (this.needs) this.needs.hunger = Math.min(100, this.needs.hunger + 6); this.ui.toast('🥥 Eau de coco bien fraîche, ouverte à la machette par le vendeur.', 2.5); } }, { label: '🌊 Se baigner ?', action: () => this.ui.toast('⚠️ Baignade dangereuse : les courants (barre) sont forts sur les plages de Cotonou. On profite du sable, pas des vagues !', 4) });
    if (s.id === 'village') items.push({ label: '🛍️ Acheter de l’artisanat', action: () => this.craft() });
    items.push({ label: '📸 Prendre une photo souvenir', desc: ['pythons', 'kpasse'].includes(s.id) ? 'Là où le guide l’autorise' : '', action: () => this.photo(s) });
    if (['pythons', 'kpasse', 'mosquee'].includes(s.id)) items.push({ label: '🙏 Règles de respect du lieu', action: () => this.ui.toast(s.id === 'mosquee' ? 'Mosquée : visite hors des heures de prière, épaules et jambes couvertes, chaussures retirées dans la salle de prière.' : RESPECT, 5) });
    this.ui.openMenu(`${s.cat === 'monument' ? '🏛️' : s.cat === 'marche' ? '🛍️' : '🌴'} ${s.name}`, `${s.town} • ${s.status === 'fictif' ? 'lieu fictif' : 'site réel représenté de façon stylisée'}`, items);
  }
  pay(s, n, what) { if (!n) return true; if (!this.economy.pay(n, `${what} : ${s.name}`, s.name)) { this.ui.toast('Solde insuffisant.', 2); return false; } this.T && this.T.spend('Tourisme', n, `${what} — ${s.name}`); if (what === 'Entrée' || what === 'Visite guidée') { this.paid = this.paid || {}; this.paid[s.id] = this.day(); } return true; }
  mark(s) { this.visited[s.id] = (this.visited[s.id] || 0) + 1; this.save(); }
  free(s) { this.mark(s); this.passTime(0.75, `🚶 Tu prends le temps de découvrir ${s.name}.${s.status !== 'fictif' ? ' (Représentation stylisée du site réel.)' : ''}`, { energy: -5 }); }
  guide(s) {
    const inc = this.guided(s), paid = this.paid && this.paid[s.id] === this.day(), cost = inc || !s.guide ? 0 : s.guide + (paid ? 0 : s.fee);
    if (cost && !this.pay(s, cost, 'Visite guidée')) return; const name = this.guideName || (this.guideName = pick(GUIDES)); this.mark(s);
    const step = (k) => { if (k >= s.tour.length) { this.passTime(1, `🧑‍🏫 Fin de la visite de ${s.name}. Merci à ${name} !`, { energy: -8 }); return; }
      this.ui.openMenu(`🧑‍🏫 ${name} — ${s.name}`, `Étape ${k + 1} sur ${s.tour.length}`, [{ label: s.tour[k], action: () => step(k + 1) }, { label: k + 1 < s.tour.length ? '➡️ Suite de la visite' : '✅ Terminer la visite', action: () => step(k + 1) }, { label: '📸 Photo souvenir', action: () => { this.photo(s); setTimeout(() => step(k + 1), 50); } }]); };
    step(0);
  }
  photo(s) { this.photos.unshift({ site: s.id, name: s.name, t: this.economy.stamp(), who: 'toi' }); this.photos.length = Math.min(this.photos.length, 80); this.ui.toast(`📸 Photo souvenir : ${s.name} (album NOVA TRAVEL, onglet « Tourisme »).`, 2.5); if (this.audio && this.audio.ctx) this.audio.tone(1500, 0.05, 0.06, 'square'); this.save(); }
  sunset() { const t = this.env.time; if (t > 18.6 || t < 6) return this.ui.toast('Le soleil est déjà couché : la plage est calme sous les étoiles.', 2.5); const h = 18.6 - t; if (h > 8) return this.ui.toast('Le coucher du soleil est vers 18 h 30 : reviens en fin d’après-midi.', 2.5); this.passTime(h, '🌅 Le soleil se couche sur le golfe de Guinée. Magnifique !', { energy: 5 }); }
  ganvie(s) { if (!this.pay(s, s.fee, 'Excursion à Ganvié')) return; this.mark(s); const st = s.tour; this.ui.fade && this.ui.fade(true); setTimeout(() => { this.ui.fade && this.ui.fade(false); this.ui.openMenu('🛶 Excursion à Ganvié (récit)', 'Pirogue sur le lac Nokoué • aperçu : le village n’est pas encore modélisé en entier', st.map((l) => ({ label: l, action: () => {} })).concat([{ label: '📸 Photo des maisons sur pilotis', action: () => this.photo(s) }, { label: '✅ Retour à l’embarcadère (3 h)', action: () => this.passTime(3, '🛶 Retour à l’embarcadère après 3 heures sur le lac. Une belle découverte !', { energy: -10, hunger: -8 }) }])); }, 600); }
  craft() { this.ui.openMenu('🛍️ Village artisanal de la Marina (fictif)', 'Artisanat du Bénin • articles ajoutés à « Mes articles »', CRAFT.map(([id, icon, name, , p]) => ({ label: `${icon} ${name}`, desc: fcfa(p), action: () => { if (!this.economy.pay(p, name, 'Village artisanal (fictif)')) return; this.economy.addItem(id); this.T && this.T.spend('Tourisme', p, name); this.ui.toast(`${icon} ${name} acheté. Merci, bonne visite !`, 2.5); } }))); }
  passTime(h, msg, fx = {}) { this.ui.fade && this.ui.fade(true); setTimeout(() => { this.env.time = (this.env.time + h) % 24; if (this.economy.update) this.economy.update(0); const n = this.needs; if (n) for (const [k, v] of Object.entries(fx)) n[k] = Math.max(0, Math.min(100, (n[k] || 0) + v)); this.ui.fade && this.ui.fade(false); this.ui.toast(msg, 3.5); }, 550); }
  buyCircuit(id) { const c = CIRCUITS.find((q) => q.id === id); if (!c) return; if (this.circuit && this.circuit.day === this.day()) return this.ui.toast('Tu as déjà un circuit aujourd’hui.', 2); if (!this.economy.pay(c.price, `Circuit touristique : ${c.name}`, 'NOVA TRAVEL')) return; this.circuit = { id, day: this.day() }; this.T && this.T.spend('Tourisme', c.price, c.name); this.ui.toast(`🗺️ Circuit « ${c.name} » réservé pour aujourd’hui : visites guidées incluses sur ses sites.`, 4); this.save(); }
  // ------------------------------------------------------------------ interactions, boucle
  nearest(x, z) {
    if (this.player.floorY > 1) return null; let best = null;
    for (const s of SITES) { if (!s.pt) continue; const d = Math.hypot(x - s.pt.x, z - s.pt.z); if (d < 2.6 && (!best || d < best.d)) best = { d: d + 0.3, it: { label: () => `${s.cat === 'monument' ? '🏛️' : s.cat === 'marche' ? '🛍️' : '🌴'} Visiter : ${s.name}`, action: () => this.open(s) } }; }
    if (SBY.route.stops) for (const st of SBY.route.stops) { const d = Math.hypot(x - st.x, z - (st.z + 0.9)); if (d < 1.8 && (!best || d < best.d)) best = { d, it: { label: () => `🪧 Route de l’Esclave : ${st.n}`, action: () => this.ui.toast(`🪧 ${st.n} — étape de la Route de l’Esclave, chemin de mémoire de Ouidah. Prends le temps de te recueillir.`, 4) } }; }
    for (const p of this.people) { const d = Math.hypot(x - p.x, z - p.z); if (d < 1.4 && (!best || d < best.d - 0.2)) best = { d, it: { label: () => `Parler à ${p.name}`, action: () => this.open(p.site) } }; }
    return best;
  }
  zoneLabel() { if (this.player.floorY > 1) return null; const P = this.player.pos; const s = SITES.find((q) => q.pt && Math.hypot(P.x - q.pt.x, P.z - q.pt.z) < (['marina', 'fidjrosse', 'amazone', 'martyrs', 'dantokpa'].includes(q.id) ? 0 : 40)); return s ? `${s.town} — ${s.name}` : null; }
  update(dt, cam) {
    const P = this.player.pos;
    for (const G of this.groups) { const near = Math.hypot(P.x - G.x, P.z - G.z) < 900; G.g.visible = near; if (near && G.g.userData.bill && cam) G.g.quaternion.copy(cam.quaternion); }
    this._sp = (this._sp || 0) - dt; if (this._sp > 0) return; this._sp = 1.5;
    const s = SITES.find((q) => q.pt && q.tour.length && Math.hypot(P.x - q.pt.x, P.z - q.pt.z) < 60);
    if ((s && this._site !== s.id) || (!s && this._site)) { for (const p of this.people) p.c.group.parent && p.c.group.parent.remove(p.c.group); this.people = []; this._site = s ? s.id : null;
      if (s) { const c = createCharacter({ female: Math.random() < 0.5, skin: pick(SKINS), shirtColor: 0x0b6e4f, collar: true, pants: 0x1f2a44, hat: 'cap', hatColor: 0xfcd116 }); const gx = s.pt.x + 1.6, gz = s.pt.z; c.group.position.set(gx, 0, gz); c.group.rotation.y = PI; this.scene.add(c.group); this.people.push({ c, x: gx, z: gz, site: s, name: `${this.guideName || (this.guideName = pick(GUIDES))} (guide)` });
        for (let k = 0; k < 2; k++) { const v = createCharacter({ female: k === 0, skin: pick(SKINS), shirtColor: pick([0xf6f6f6, 0xfcd116, 0x2f80ed, 0xe8112d]), pants: 0x2a2d33 }); const vx = s.pt.x - 1.5 - k * 1.2, vz = s.pt.z + 1.5; v.group.position.set(vx, 0, vz); v.group.rotation.y = PI; this.scene.add(v.group); this.people.push({ c: v, x: vx, z: vz, site: s, name: 'Visiteur' }); } } }
    for (const p of this.people) p.c.animate(1.5, 0);
  }
  // ------------------------------------------------------------------ application NOVA TRAVEL, onglet « Tourisme »
  renderApp() {
    const tabs = [['sites', 'Sites'], ['circuits', 'Circuits'], ['manger', 'Où manger'], ['album', 'Album photos']];
    let h = `<p class="ph-note">Sites réels représentés de façon stylisée (architecture et position simplifiées) ; tarifs du jeu fictifs. ${Object.keys(this.visited).length} site${Object.keys(this.visited).length > 1 ? 's' : ''} visité${Object.keys(this.visited).length > 1 ? 's' : ''} sur ${SITES.length} • ${this.photos.length} photo${this.photos.length > 1 ? 's' : ''}.</p><div class="ph-chips">${tabs.map(([k, l]) => `<button data-tr="tour:view:${k}" class="${k === this.view ? 'on' : ''}">${l}</button>`).join('')}</div>`;
    if (this.view === 'sites') { let town = ''; h += SITES.map((s) => { const head = s.town !== town ? `<h5>${s.town}</h5>` : ''; town = s.town; return `${head}<div class="ph-row"><span><b>${this.visited[s.id] ? '✅ ' : ''}${esc(s.name)}</b><small>${s.status === 'fictif' ? 'Lieu fictif' : 'Site réel (stylisé)'} • ${s.fee ? `entrée ${fcfa(s.fee)}` : 'accès libre'}${s.guide ? ` • guide ${fcfa(s.guide)}` : ''}</small><small>${esc(s.desc)}</small></span>${s.pos && this.driver ? `<button class="ph-mini" data-tr="tour:go:${s.id}">🚘 Y aller</button>` : ''}</div>`; }).join(''); }
    else if (this.view === 'circuits') h += CIRCUITS.map((c) => `<div class="ph-row"><span><b>${esc(c.name)}</b><small>${esc(c.desc)}</small></span>${this.circuit && this.circuit.id === c.id && this.circuit.day === this.day() ? '<em>✅ aujourd’hui</em>' : `<button class="ph-mini" data-tr="tour:circ:${c.id}">${fcfa(c.price)}</button>`}</div>`).join('') + '<p class="ph-note">Le circuit vaut pour la journée : visites guidées incluses ; déplacements avec ton chauffeur.</p>';
    else if (this.view === 'manger') { const list = (this.venues ? this.venues.list : []).filter((v) => v.type === 'restaurant' || v.type === 'bar'); h += list.map((v) => `<div class="ph-row"><span><b>${esc(v.name)}</b><small>${v.town} • ${v.type === 'bar' ? 'bar (boissons sans alcool)' : 'restaurant'} • établissement fictif</small></span>${this.driver ? `<button class="ph-mini" data-tr="tour:eat:${this.venues.list.indexOf(v)}">🚘 Y aller</button>` : ''}</div>`).join('') + '<p class="ph-note">Également : les restaurants gastronomiques des hôtels de luxe (onglet « Hôtels »).</p>'; }
    else h += this.photos.slice(0, 40).map((p) => `<div class="ph-row"><span><b>📸 ${esc(p.name)}</b><small>${p.t} • avec ${p.who}</small></span></div>`).join('') || '<p class="ph-note">Aucune photo : prends des photos souvenirs pendant tes visites.</p>';
    return h;
  }
  onPhone(a, b) {
    if (a === 'view') this.view = b; else if (a === 'circ') this.buyCircuit(b);
    else if (a === 'go' && this.driver) { const s = SBY[b]; if (!s || !s.pt) return true; this.economy.togglePhone(false); this.driver.toDest({ id: `tour_${s.id}`, label: s.name, x: s.pt.x, z: s.pt.z + 2 }); return false; }
    else if (a === 'eat' && this.driver) { const v = this.venues.list[+b]; if (!v) return true; this.economy.togglePhone(false); this.driver.toDest({ id: v.id, label: v.name, x: v.x, z: v.z }); return false; }
    return true;
  }
  serialize() { return { visited: this.visited, photos: this.photos, circuit: this.circuit, paid: this.paid || {} }; }
  restore(s) { if (!s) return; this.visited = s.visited || {}; this.photos = s.photos || []; this.circuit = s.circuit || null; this.paid = s.paid || {}; }
}
