// Mission 011 — 20 pouvoirs mystiques d'un univers FANTASTIQUE inspiré des couleurs, motifs et paysages du Bénin.
// Ces pouvoirs sont imaginaires : ils ne représentent ni des divinités, ni des rites, ni des cérémonies réelles du Vodun,
// religion vivante que le jeu respecte. Les symboles ci-dessous sont des glyphes géométriques inventés pour le jeu,
// dans l'esprit des tentures appliquées d'Abomey (formes pleines et couleurs franches), sans reprendre de signe sacré.

export const PCATS = [
  { id: 'nature', label: 'Nature et éléments', short: 'Éléments', color: '#e8762a' },
  { id: 'protection', label: 'Protection et énergie', short: 'Protection', color: '#2fb07a' },
  { id: 'esprits', label: 'Esprits et illusions', short: 'Illusions', color: '#8a6af0' },
  { id: 'exception', label: 'Pouvoirs exceptionnels', short: 'Exceptionnels', color: '#f2c230' },
];

// dur : durée (s) · cd : recharge (s) · cost : énergie mystique · pow : puissance (1 à 5) · lvl : niveau de déblocage
export const POWERS = [
  { id: 'feu', name: 'Esprit du Feu', cat: 'nature', lvl: 1, dur: 10, cd: 20, cost: 15, pow: 2, color: 0xff7a1a,
    desc: 'Une aura de flammes fantastiques t’enveloppe. Elle éclaire la nuit et tient les feux follets à distance.' },
  { id: 'eau', name: 'Esprit de l’Eau', cat: 'nature', lvl: 3, dur: 6, cd: 25, cost: 20, pow: 3, color: 0x2fa8ff,
    desc: 'Une vague circulaire écarte les passants, puis un bouclier d’eau t’entoure : la circulation s’arrête devant toi.' },
  { id: 'vent', name: 'Esprit du Vent', cat: 'nature', lvl: 1, dur: 12, cd: 30, cost: 20, pow: 2, color: 0xbfe8ff,
    desc: 'Le vent te porte : vitesse +60 %, sauts plus hauts et plus longs.' },
  { id: 'terre', name: 'Esprit de la Terre', cat: 'nature', lvl: 4, dur: 10, cd: 30, cost: 25, pow: 3, color: 0xb0582e,
    desc: 'Des blocs de latérite s’élèvent et tournent autour de toi : véhicules et passants gardent leurs distances, ton endurance ne baisse plus.' },
  { id: 'foudre', name: 'Esprit de la Foudre', cat: 'nature', lvl: 5, dur: 3, cd: 25, cost: 25, pow: 3, color: 0x9fd8ff,
    desc: 'Des éclairs lumineux frappent autour de toi, illuminent la ville et font reculer les passants.' },

  { id: 'bouclier', name: 'Bouclier Mystique', cat: 'protection', lvl: 2, dur: 12, cd: 35, cost: 20, pow: 3, color: 0x3fe0a0,
    desc: 'Un dôme de motifs lumineux te protège : passants et véhicules ne peuvent pas t’approcher.' },
  { id: 'aura', name: 'Aura Sacrée', cat: 'protection', lvl: 1, dur: 20, cd: 30, cost: 15, pow: 1, color: 0xffd75a,
    desc: 'Une aura dorée et un symbole tournant à tes pieds. Ton endurance ne s’épuise plus pendant l’effet.' },
  { id: 'regen', name: 'Régénération Spirituelle', cat: 'protection', lvl: 2, dur: 15, cd: 60, cost: 10, pow: 2, color: 0x7aff8a,
    desc: 'Des spirales vertes restaurent progressivement ton énergie (jauge ÉNERGIE : +18, plus avec les améliorations).' },
  { id: 'fantome', name: 'Pas Fantôme', cat: 'protection', lvl: 3, dur: 0.6, cd: 8, cost: 12, pow: 2, color: 0xc0a8ff,
    desc: 'Courte téléportation vers l’avant (jusqu’à 8 m), sans traverser les murs.' },
  { id: 'lumiere', name: 'Lumière Protectrice', cat: 'protection', lvl: 4, dur: 8, cd: 25, cost: 18, pow: 3, color: 0xfff4c0,
    desc: 'Une sphère de lumière repousse les feux follets dans un rayon de 20 m.' },

  { id: 'vision', name: 'Vision des Esprits', cat: 'esprits', lvl: 1, dur: 20, cd: 30, cost: 15, pow: 1, color: 0x6ad0ff,
    desc: 'Révèle les symboles cachés de la ville (20 à trouver), les feux follets et les pierres-portails proches. Approche-toi d’un symbole révélé pour le recueillir.' },
  { id: 'double', name: 'Double Mystique', cat: 'esprits', lvl: 5, dur: 20, cd: 40, cost: 25, pow: 2, color: 0xb070ff,
    desc: 'Une illusion lumineuse de ton personnage marche à tes côtés et imite tes gestes. Les véhicules s’arrêtent aussi devant elle.' },
  { id: 'brume', name: 'Brume Spirituelle', cat: 'esprits', lvl: 6, dur: 20, cd: 40, cost: 20, pow: 2, color: 0xa890d8,
    desc: 'Un brouillard magique violet t’entoure. Les feux follets perdent ta trace.' },
  { id: 'ancetres', name: 'Appel des Ancêtres', cat: 'esprits', lvl: 7, dur: 8, cd: 90, cost: 35, pow: 4, color: 0xffe2a0,
    desc: 'Animation symbolique : des colonnes de lumière et des silhouettes lumineuses imaginaires apparaissent en cercle puis s’effacent.' },
  { id: 'portail', name: 'Portail Mystique', cat: 'esprits', lvl: 6, dur: 1, cd: 20, cost: 30, pow: 3, color: 0x40e0d0,
    desc: 'Rejoins une pierre-portail déjà découverte. Les 7 pierres (dont celle de l’aéroport) se découvrent en t’en approchant.' },

  { id: 'colosse', name: 'Colosse de Terre', cat: 'exception', lvl: 8, dur: 15, cd: 90, cost: 40, pow: 4, color: 0x9a5a36,
    desc: 'Tu deviens une grande silhouette de latérite : pas lourds qui font trembler la caméra, passants écartés sur ton passage.' },
  { id: 'danse', name: 'Danse du Tonnerre', cat: 'exception', lvl: 9, dur: 4, cd: 90, cost: 45, pow: 5, color: 0x8fd0ff,
    desc: 'Une danse spectaculaire appelle un cercle d’éclairs, puis une onde qui repousse passants et feux follets.' },
  { id: 'onde', name: 'Onde Spirituelle', cat: 'exception', lvl: 7, dur: 1.2, cd: 25, cost: 30, pow: 4, color: 0xff6ad5,
    desc: 'Une onde d’énergie repousse les passants (12 m), les véhicules garés (10 m) et les feux follets.' },
  { id: 'gardiens', name: 'Protection des Gardiens', cat: 'exception', lvl: 9, dur: 25, cd: 120, cost: 45, pow: 4, color: 0xf2c230,
    desc: 'Trois gardiens imaginaires de latérite et d’or t’escortent : ils éloignent les feux follets et arrêtent la circulation.' },
  { id: 'eveil', name: 'Éveil Mystique', cat: 'exception', lvl: 10, dur: 15, cd: 180, cost: 70, pow: 5, color: 0xffffff,
    desc: 'Transformation exceptionnelle : aura multicolore, lévitation, vitesse du vent, régénération et bouclier réunis.' },
];
export const POWER_BY_ID = Object.fromEntries(POWERS.map((p) => [p.id, p]));
export const XP_LEVELS = [0, 100, 250, 450, 700, 1000, 1350, 1750, 2200, 2700];
export const MAX_RANK = 3;

// valeurs effectives selon le rang (amélioration)
export function stats(p, rank = 1) {
  const r = rank - 1;
  return { dur: +(p.dur * (1 + 0.25 * r)).toFixed(1), cd: Math.round(p.cd * (1 - 0.15 * r)), cost: p.cost, pow: Math.min(5, p.pow + r) };
}

// ---------- symboles inventés (dessin vectoriel sur canvas) ----------
const hex = (n) => '#' + n.toString(16).padStart(6, '0');
function star(x, cx, cy, n, r1, r2, rot = -Math.PI / 2) {
  x.beginPath();
  for (let i = 0; i < n * 2; i++) { const a = rot + (i * Math.PI) / n, r = i % 2 ? r2 : r1; x.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r); }
  x.closePath();
}
function person(x, cx, cy, s, armsUp = false) {
  x.beginPath(); x.arc(cx, cy - s * 0.62, s * 0.2, 0, 7); x.fill();
  x.beginPath(); x.moveTo(cx - s * 0.26, cy + s * 0.55); x.lineTo(cx - s * 0.16, cy - s * 0.36); x.lineTo(cx + s * 0.16, cy - s * 0.36); x.lineTo(cx + s * 0.26, cy + s * 0.55); x.closePath(); x.fill();
  x.lineWidth = s * 0.1; x.beginPath();
  if (armsUp) { x.moveTo(cx - s * 0.14, cy - s * 0.28); x.lineTo(cx - s * 0.42, cy - s * 0.75); x.moveTo(cx + s * 0.14, cy - s * 0.28); x.lineTo(cx + s * 0.42, cy - s * 0.75); }
  else { x.moveTo(cx - s * 0.16, cy - s * 0.3); x.lineTo(cx - s * 0.36, cy + s * 0.15); x.moveTo(cx + s * 0.16, cy - s * 0.3); x.lineTo(cx + s * 0.36, cy + s * 0.15); }
  x.stroke();
}
const GLYPHS = {
  feu(x) { x.beginPath(); x.moveTo(0, 0.62); x.bezierCurveTo(-0.5, 0.5, -0.45, -0.05, -0.05, -0.62); x.bezierCurveTo(0.05, -0.25, 0.4, -0.15, 0.3, -0.42); x.bezierCurveTo(0.6, 0.0, 0.5, 0.5, 0, 0.62); x.fill();
    x.fillStyle = 'rgba(0,0,0,0.35)'; x.beginPath(); x.moveTo(0, 0.5); x.bezierCurveTo(-0.22, 0.42, -0.2, 0.15, 0, -0.05); x.bezierCurveTo(0.2, 0.15, 0.22, 0.42, 0, 0.5); x.fill(); },
  eau(x) { x.lineWidth = 0.11; for (const y of [-0.32, 0, 0.32]) { x.beginPath(); for (let i = 0; i <= 24; i++) { const t = -0.6 + (i / 24) * 1.2; x.lineTo(t, y + Math.sin(t * 9) * 0.08); } x.stroke(); } },
  vent(x) { x.lineWidth = 0.09; x.beginPath(); for (let i = 0; i < 60; i++) { const a = i * 0.22, r = 0.04 + i * 0.008; x.lineTo(0.12 + Math.cos(a) * r, Math.sin(a) * r); } x.stroke();
    for (const [y, l] of [[-0.42, 0.7], [0.42, 0.5]]) { x.beginPath(); x.moveTo(-0.62, y); x.lineTo(-0.62 + l, y); x.stroke(); } },
  terre(x) { x.beginPath(); x.moveTo(-0.6, 0.45); x.lineTo(-0.15, -0.45); x.lineTo(0.1, -0.05); x.lineTo(0.28, -0.3); x.lineTo(0.62, 0.45); x.closePath(); x.fill();
    x.fillStyle = 'rgba(0,0,0,0.35)'; for (const [a, b] of [[-0.25, 0.25], [0.05, 0.3], [0.3, 0.2]]) { x.beginPath(); x.arc(a, b, 0.06, 0, 7); x.fill(); } },
  foudre(x) { x.beginPath(); x.moveTo(0.12, -0.65); x.lineTo(-0.32, 0.08); x.lineTo(-0.02, 0.08); x.lineTo(-0.16, 0.65); x.lineTo(0.34, -0.12); x.lineTo(0.04, -0.12); x.closePath(); x.fill(); },
  bouclier(x) { x.beginPath(); x.moveTo(0, -0.62); x.lineTo(0.48, -0.42); x.quadraticCurveTo(0.5, 0.3, 0, 0.65); x.quadraticCurveTo(-0.5, 0.3, -0.48, -0.42); x.closePath(); x.fill();
    x.strokeStyle = 'rgba(0,0,0,0.35)'; x.lineWidth = 0.07; x.beginPath(); x.moveTo(0, -0.45); x.lineTo(0, 0.45); x.moveTo(-0.3, -0.1); x.lineTo(0.3, -0.1); x.stroke(); },
  aura(x) { x.beginPath(); x.arc(0, 0, 0.26, 0, 7); x.fill(); x.lineWidth = 0.08; for (let i = 0; i < 12; i++) { const a = (i / 12) * Math.PI * 2; x.beginPath(); x.moveTo(Math.cos(a) * 0.38, Math.sin(a) * 0.38); x.lineTo(Math.cos(a) * (i % 2 ? 0.52 : 0.62), Math.sin(a) * (i % 2 ? 0.52 : 0.62)); x.stroke(); } },
  regen(x) { x.lineWidth = 0.1; x.beginPath(); for (let i = 0; i < 50; i++) { const t = i / 49; x.lineTo(Math.sin(t * 9) * 0.28 * (1 - t * 0.5), 0.6 - t * 1.1); } x.stroke();
    x.beginPath(); x.moveTo(0.25, -0.45); x.lineTo(0.55, -0.45); x.moveTo(0.4, -0.6); x.lineTo(0.4, -0.3); x.stroke(); },
  fantome(x) { x.globalAlpha = 0.45; x.beginPath(); x.ellipse(-0.3, 0.15, 0.13, 0.22, -0.2, 0, 7); x.fill(); x.globalAlpha = 1; x.beginPath(); x.ellipse(0.15, -0.05, 0.13, 0.22, -0.2, 0, 7); x.fill();
    x.lineWidth = 0.08; x.beginPath(); x.moveTo(-0.6, 0.5); x.lineTo(0.55, 0.5); x.lineTo(0.42, 0.38); x.moveTo(0.55, 0.5); x.lineTo(0.42, 0.62); x.stroke(); },
  lumiere(x) { star(x, 0, 0, 8, 0.62, 0.26); x.fill(); x.fillStyle = 'rgba(0,0,0,0.3)'; x.beginPath(); x.arc(0, 0, 0.14, 0, 7); x.fill(); },
  vision(x) { x.beginPath(); x.moveTo(-0.62, 0); x.quadraticCurveTo(0, -0.55, 0.62, 0); x.quadraticCurveTo(0, 0.55, -0.62, 0); x.fill();
    x.fillStyle = 'rgba(0,0,0,0.55)'; x.beginPath(); x.arc(0, 0, 0.2, 0, 7); x.fill(); x.fillStyle = '#fff'; x.beginPath(); x.arc(0.06, -0.06, 0.06, 0, 7); x.fill(); },
  double(x) { x.globalAlpha = 0.45; person(x, -0.18, 0.05, 0.9); x.globalAlpha = 1; person(x, 0.18, 0.05, 0.9); },
  brume(x) { x.lineWidth = 0.09; for (const [y, o] of [[-0.35, 0], [0, 0.15], [0.35, -0.1]]) { x.beginPath(); for (let i = 0; i <= 20; i++) { const t = -0.55 + (i / 20) * 1.1; x.lineTo(t + o, y + Math.sin(t * 7 + y * 5) * 0.06); } x.stroke(); }
    for (const [a, b] of [[-0.5, -0.55], [0.45, 0.55], [0.55, -0.15]]) { x.beginPath(); x.arc(a, b, 0.05, 0, 7); x.fill(); } },
  ancetres(x) { x.lineWidth = 0.07; x.beginPath(); x.arc(0, 0.4, 0.62, Math.PI * 1.08, Math.PI * 1.92); x.stroke(); person(x, -0.33, 0.22, 0.55); person(x, 0, 0.12, 0.62); person(x, 0.33, 0.22, 0.55); },
  portail(x) { x.lineWidth = 0.1; x.beginPath(); x.ellipse(0, 0, 0.36, 0.58, 0, 0, 7); x.stroke(); x.lineWidth = 0.06; x.beginPath(); x.ellipse(0, 0, 0.2, 0.38, 0, 0, 7); x.stroke(); x.beginPath(); x.arc(0, 0, 0.07, 0, 7); x.fill(); },
  colosse(x) { x.fillRect(-0.18, -0.6, 0.36, 0.3); x.fillRect(-0.36, -0.26, 0.72, 0.5); x.fillRect(-0.58, -0.26, 0.18, 0.42); x.fillRect(0.4, -0.26, 0.18, 0.42); x.fillRect(-0.3, 0.28, 0.24, 0.36); x.fillRect(0.06, 0.28, 0.24, 0.36); },
  danse(x) { person(x, 0, 0.12, 0.95, true); x.save(); x.scale(0.45, 0.45); x.translate(-1.1, -0.7); GLYPHS.foudre(x); x.translate(2.2, 0); GLYPHS.foudre(x); x.restore(); },
  onde(x) { x.lineWidth = 0.08; for (const r of [0.14, 0.32, 0.5]) { x.beginPath(); x.arc(0, 0, r, 0, 7); x.stroke(); } x.beginPath(); x.arc(0, 0, 0.06, 0, 7); x.fill(); },
  gardiens(x) { for (const [cx, h] of [[-0.38, 0.8], [0, 1.05], [0.38, 0.8]]) { x.fillRect(cx - 0.11, 0.6 - h, 0.22, h); x.beginPath(); x.moveTo(cx - 0.16, 0.6 - h); x.lineTo(cx, 0.6 - h - 0.18); x.lineTo(cx + 0.16, 0.6 - h); x.fill(); }
    x.fillStyle = 'rgba(0,0,0,0.4)'; for (const [cx, h] of [[-0.38, 0.8], [0, 1.05], [0.38, 0.8]]) x.fillRect(cx - 0.07, 0.6 - h + 0.12, 0.14, 0.04); },
  eveil(x) { star(x, 0, 0, 12, 0.64, 0.4); x.fill(); x.fillStyle = 'rgba(0,0,0,0.5)'; x.beginPath(); x.moveTo(-0.32, 0); x.quadraticCurveTo(0, -0.28, 0.32, 0); x.quadraticCurveTo(0, 0.28, -0.32, 0); x.fill(); x.fillStyle = '#fff'; x.beginPath(); x.arc(0, 0, 0.09, 0, 7); x.fill(); },
};

// Icône complète : médaillon, bordure de triangles (motif d'appliqué), glyphe central
export function drawPowerIcon(p, size = 128, glyphOnly = false) {
  const c = document.createElement('canvas'); c.width = c.height = size;
  const x = c.getContext('2d'), s = size / 2, col = hex(p.color), cat = PCATS.find((k) => k.id === p.cat).color;
  x.translate(s, s);
  if (!glyphOnly) {
    const g = x.createRadialGradient(0, -s * 0.2, s * 0.1, 0, 0, s);
    g.addColorStop(0, '#3a2a22'); g.addColorStop(1, '#120c0a');
    x.fillStyle = g; x.beginPath(); x.arc(0, 0, s * 0.96, 0, 7); x.fill();
    x.fillStyle = cat;
    for (let i = 0; i < 16; i++) { const a = (i / 16) * Math.PI * 2; x.save(); x.rotate(a); x.beginPath(); x.moveTo(-s * 0.09, -s * 0.93); x.lineTo(s * 0.09, -s * 0.93); x.lineTo(0, -s * 0.8); x.closePath(); x.fill(); x.restore(); }
    x.strokeStyle = cat; x.lineWidth = s * 0.05; x.beginPath(); x.arc(0, 0, s * 0.95, 0, 7); x.stroke();
    x.strokeStyle = 'rgba(255,255,255,0.12)'; x.lineWidth = s * 0.02; x.beginPath(); x.arc(0, 0, s * 0.74, 0, 7); x.stroke();
  } else {
    x.strokeStyle = col; x.lineWidth = s * 0.06; x.beginPath(); x.arc(0, 0, s * 0.94, 0, 7); x.stroke();
    x.lineWidth = s * 0.025; x.beginPath(); x.arc(0, 0, s * 0.8, 0, 7); x.stroke();
    x.fillStyle = col; for (let i = 0; i < 24; i++) { const a = (i / 24) * Math.PI * 2; x.beginPath(); x.arc(Math.cos(a) * s * 0.87, Math.sin(a) * s * 0.87, s * 0.025, 0, 7); x.fill(); }
  }
  x.save(); x.scale(s * (glyphOnly ? 1.1 : 0.95), s * (glyphOnly ? 1.1 : 0.95));
  x.fillStyle = col; x.strokeStyle = col; x.lineCap = 'round'; x.lineJoin = 'round';
  if (!glyphOnly) { x.shadowColor = col; x.shadowBlur = s * 0.25; }
  GLYPHS[p.id](x);
  x.restore();
  return c;
}
