// Mission 023, phase 2 — ABIDJAN (Côte d'Ivoire), cinquième secteur pays explorable, à sa position géographique réelle
// dans le repère du jeu (projection de la région du Bénin, échelle 1:5). Géographie SIMPLIFIÉE et positions approximatives :
// le Plateau (quartier des affaires) avance dans la lagune Ébrié entre la baie du Banco à l'ouest et la baie de Cocody à
// l'est ; Adjamé et la forêt du Banco au nord ; Cocody et la Riviera à l'est ; Treichville, le port, Marcory, Koumassi et
// Port-Bouët au sud de la lagune, jusqu'à l'océan. Ponts Félix-Houphouët-Boigny et Charles-de-Gaulle (Plateau–Treichville),
// pont Henri-Konan-Bédié (Riviera–Marcory). La basilique Notre-Dame-de-la-Paix (Yamoussoukro, ≈ 230 km au nord-ouest) est
// RAPPROCHÉE dans le jeu et signalée comme telle. Commerces, hôtel, restaurants, compagnies au nom inventé : FICTIFS.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { colorize } from './vehicles.js';
import { toWorld } from './africa-data.js';

const PI = Math.PI;
const O = toWorld(5.32, -4.02); // origine : le Plateau
export const ABIDJAN = { id: 'abidjan', country: '384', name: 'Abidjan', O, X0: -1600, X1: 2600, Z0: -1700, COAST: 1400 };
// ponts praticables (rectangles) : Félix-Houphouët-Boigny, Charles-de-Gaulle, Henri-Konan-Bédié
const BR = [[-158, 245, -142, 555], [142, 245, 158, 555], [1492, 245, 1508, 555]];
const onBridge = (x, z) => BR.some(([a, b, c, d]) => x > a && x < c && z > b && z < d);
// eau (coordonnées locales) : océan, lagune Ébrié, baie du Banco, baie de Cocody, lagune à l'ouest du port
const wet = (x, z) => z > ABIDJAN.COAST || (z > 250 && z < 550) || (x < -600 && z >= 550) || (x > -700 && x < -300 && z > -300 && z <= 250) || (x > 300 && x < 600 && z > -300 && z <= 250);
const isWet = (x, z) => wet(x, z) && !onBridge(x, z);
ABIDJAN.has = (x, z) => x > O.x + ABIDJAN.X0 - 40 && x < O.x + ABIDJAN.X1 + 40 && z > O.z + ABIDJAN.Z0 - 40 && z < O.z + ABIDJAN.COAST + 600;
ABIDJAN.near = (x, z) => Math.abs(x - O.x - 500) < 4800 && Math.abs(z - O.z + 150) < 4200;
ABIDJAN.water = (x, z) => isWet(x - O.x, z - O.z);
ABIDJAN.coastAt = () => ABIDJAN.COAST;
ABIDJAN.clamp = (obj, margin = 1) => {
  const p = obj.pos; let lx = Math.max(ABIDJAN.X0 + 2, Math.min(ABIDJAN.X1 - 2, p.x - O.x)), lz = Math.max(ABIDJAN.Z0 + 2, Math.min(ABIDJAN.COAST - margin, p.z - O.z));
  if (isWet(lx, lz)) { if (obj._dry) { lx = obj._dry.x - O.x; lz = obj._dry.z - O.z; if (obj.speed) obj.speed *= -0.2; } }
  p.x = O.x + lx; p.z = O.z + lz; if (!obj._dry) obj._dry = { x: 0, z: 0 }; if (!isWet(lx, lz)) { obj._dry.x = p.x; obj._dry.z = p.z; }
};
// voies : [x0, z0, x1, z1, largeur, nom]
const ROADS = [
  [-1600, -500, 2600, -500, 14, ''], [-1600, -900, 2600, -900, 12, ''], [-1600, 0, -700, 0, 10, ''],
  [-295, -200, 295, -200, 10, ''], [-295, 0, 295, 0, 10, ''], [-295, 150, 295, 150, 10, ''],
  [605, -200, 2600, -200, 12, ''], [605, 100, 2600, 100, 10, ''],
  [-1100, -1700, -1100, 245, 10, ''], [-600, -1700, -600, -305, 10, ''], [-150, -1700, -150, 1350, 14, 'Pont Félix-Houphouët-Boigny'], [150, -1700, 150, 1350, 14, 'Pont Charles-de-Gaulle'], [500, -1700, 500, -305, 10, ''],
  [850, -1700, 850, 245, 12, ''], [1200, -1700, 1200, 245, 10, ''], [1500, -1700, 1500, 1100, 12, 'Pont Henri-Konan-Bédié'], [1900, -1700, 1900, 245, 10, ''], [2300, -1700, 2300, 245, 10, ''],
  [-150, 650, 2600, 650, 12, ''], [-595, 900, 2600, 900, 14, 'Route de Grand-Bassam (stylisée)'], [-150, 1100, 2600, 1100, 10, ''], [-150, 1350, 1600, 1350, 10, ''],
  [600, 555, 600, 1350, 10, ''], [1000, 555, 1000, 1350, 10, ''], [1900, 555, 1900, 1100, 10, ''], [2300, 555, 2300, 1100, 10, ''],
];
const P = {
  cathedrale: { x: -230, z: 90 }, lagune: { x: 0, z: 236 }, stade: { x: 0, z: -420 }, adjame: { x: -300, z: -650 }, gare: { x: 320, z: -690 }, banco: { x: -1150, z: -890 },
  basilique: { x: -375, z: -1430 }, universite: { x: 1350, z: -370 }, hotel: { x: 1000, z: 185 }, mall: { x: 1700, z: -55 }, pont: { x: 1515, z: 232 }, treichville: { x: 0, z: 780 },
  port: { x: -360, z: 720 }, plage: { x: 1000, z: 1385 }, aeroport: { x: 2000, z: 1190 }, hopital: { x: 0, z: 1000 }, ecole: { x: 800, z: 1000 }, est: { x: 2580, z: 900 },
};
const TAXIS = [[-162, 60, 'Cathédrale Saint-Paul'], [60, -8, 'Le Plateau'], [80, -356, 'Stade'], [-250, -566, 'Marché d’Adjamé'], [260, -604, 'Gare routière d’Adjamé'], [-1190, -519, 'Banco'], [-330, -912, 'Basilique (rapprochée)'], [1300, -284, 'Université'], [1040, 128, 'Cocody'], [1760, 52, 'Riviera'], [60, 686, 'Treichville'], [-250, 886, 'Port'], [1040, 1362, 'Port-Bouët (plage)'], [2060, 1150, 'Aéroport']];
const QUARTIERS = [['Le Plateau', 0, 0], ['Adjamé', -100, -700], ['Abobo', 0, -1400], ['Forêt du Banco', -1150, -900], ['Attécoubé', -1150, 0], ['Basilique (rapprochée)', -375, -1400], ['Cocody', 1000, -200], ['Riviera', 2100, -300], ['Treichville', 0, 780], ['Port', -380, 720], ['Marcory', 900, 800], ['Koumassi', 2000, 800], ['Port-Bouët', 1300, 1250], ['Aéroport (Port-Bouët)', 2000, 1220]];
const SHOPS = ['MOBILE MONEY • TRANSFERT', 'PHARMACIE DE LA LAGUNE', 'COIFFURE BELLE DAME', 'QUINCAILLERIE ABOU', 'PAGNES CHEZ AWA', 'ATTIÉKÉ CHEZ TANTIE', 'GARBADROME', 'COUTURE ADJOUA', 'LIBRAIRIE DU PLATEAU', 'DÉPÔT DE PAIN', 'CABINET DENTAIRE', 'ÉLECTRO SERVICE'];
const NAMES = { f: ['Aya', 'Adjoua', 'Affoué', 'Amenan', 'Mariam', 'Fatou', 'Akissi', 'Ahou', 'Nadège', 'Awa'], m: ['Kouassi', 'Koffi', 'Yao', 'Konan', 'Seydou', 'Drissa', 'Didier', 'Serge', 'Moussa', 'Kouamé'] };

export function buildAbidjan(ctx) {
  const { scene, world, quality } = ctx, C = world.collision, g = new THREE.Group(); g.position.set(O.x, 0, O.z); scene.add(g);
  const parts = [], glass = [], heads = [], signs = {}, cols = [], points = [], lanes = [], lamps = [];
  const box = (x0, y0, z0, x1, y1, z1, c, arr = parts) => arr.push(colorize(new THREE.BoxGeometry(Math.abs(x1 - x0) || 0.01, Math.abs(y1 - y0) || 0.01, Math.abs(z1 - z0) || 0.01).translate((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), c));
  const solid = (x0, z0, x1, z1, h) => { const o = C.addBox(O.x + Math.min(x0, x1), O.z + Math.min(z0, z1), O.x + Math.max(x0, x1), O.z + Math.max(z0, z1), h); cols.push(o); return o; };
  const circle = (x, z, r, h) => { const o = C.addCircle(O.x + x, O.z + z, r, h); cols.push(o); return o; };
  const Pt = (x, z, r, label, action) => points.push({ x, z, r, label, action });
  const R = (() => { let a = 3841; return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; })();
  const reserved = [], reserve = (x0, z0, x1, z1) => reserved.push({ x0, z0, x1, z1 }), isRes = (x0, z0, x1, z1) => reserved.some((r) => x1 > r.x0 && x0 < r.x1 && z1 > r.z0 && z0 < r.z1);
  const CO = ABIDJAN.COAST;
  // ---- sol, océan, lagune Ébrié, baies, plage, ponts ----
  box(ABIDJAN.X0 - 400, -0.12, ABIDJAN.Z0 - 400, ABIDJAN.X1 + 400, -0.02, CO + 30, 0x8a8a5a);
  const L = 0x3a6a62; box(ABIDJAN.X0 - 400, -0.01, CO, ABIDJAN.X1 + 400, 0.03, CO + 1600, 0x1b6a82);
  box(ABIDJAN.X0 - 400, -0.01, 250, ABIDJAN.X1 + 400, 0.035, 550, L); box(ABIDJAN.X0 - 400, -0.01, 550, -600, 0.035, CO, L); box(-700, -0.01, -300, -300, 0.035, 250, L); box(300, -0.01, -300, 600, 0.035, 250, L);
  box(-600, -0.005, CO - 30, ABIDJAN.X1 + 400, 0.04, CO, 0xe8d8b0);
  for (const [a, b, c2, d] of BR) { box(a, 0.55, b, c2, 0.85, d, 0xb8b4ac); box(a, 0.85, b, a + 0.4, 1.7, d, 0xd8d4cc); box(c2 - 0.4, 0.85, b, c2, 1.7, d, 0xd8d4cc); for (let z = b + 20; z < d - 10; z += 40) box(a + 2, -0.3, z - 1.2, c2 - 2, 0.55, z + 1.2, 0x9a9690); }
  // ---- routes ----
  const roadSeg = ([x0, z0, x1, z1, w]) => { if (x0 === x1) box(x0 - w / 2, 0.02, Math.min(z0, z1), x0 + w / 2, 0.05, Math.max(z0, z1), 0x3a3c40); else box(Math.min(x0, x1), 0.02, z0 - w / 2, Math.max(x0, x1), 0.05, z0 + w / 2, 0x3a3c40); };
  for (const r of ROADS) { const [x0, z0, x1, z1] = r; if (x0 === x1) { roadSeg(r); box(x0 - 0.08, 0.05, Math.min(z0, z1), x0 + 0.08, 0.06, Math.max(z0, z1), 0xf2f2f2); } else {
    let s0 = null; for (let x = Math.min(x0, x1); x <= Math.max(x0, x1); x += 10) { const ok = !isWet(x, z0); if (ok && s0 === null) s0 = x; if ((!ok || x + 10 > Math.max(x0, x1)) && s0 !== null) { roadSeg([s0, z0, ok ? x : x - 10, z1, r[4]]); s0 = null; } } box(x0, 0.05, z0 - 0.08, x1, 0.06, z0 + 0.08, 0xf2f2f2); } }
  const roadAt = (x, z, m) => ROADS.some(([x0, z0, x1, z1, w]) => (x0 === x1 ? Math.abs(x - x0) < w / 2 + m && z > Math.min(z0, z1) - m && z < Math.max(z0, z1) + m : Math.abs(z - z0) < w / 2 + m && x > Math.min(x0, x1) - m && x < Math.max(x0, x1) + m));
  // ---- réservations (avant les immeubles) ----
  for (const [x, z] of TAXIS) reserve(x - 4, z - 4, x + 4, z + 4);
  reserve(-288, 32, -160, 148); reserve(-45, 196, 45, 250); reserve(-75, -476, 75, -350); reserve(-390, -730, -210, -560); reserve(220, -770, 420, -598); reserve(-1560, -1260, -740, -520);
  reserve(-585, -1695, -165, -905); reserve(1205, -460, 1495, -280); reserve(945, 115, 1055, 245); reserve(1605, -165, 1795, 60); reserve(1508, 200, 1540, 250); reserve(-130, 690, 130, 870);
  reserve(-580, 555, -160, 882); reserve(900, 1360, 1100, 1400); reserve(1600, 1108, 2600, 1372); reserve(-62, 950, 62, 1056); reserve(765, 965, 835, 1035); reserve(2520, 880, 2600, 920);
  for (const [rx, rz] of [[400, 760], [1050, -60]]) reserve(rx - 17, rz - 12, rx + 17, rz + 13);
  for (const [sx, sz] of [[700, 780], [2100, 1000]]) reserve(sx - 23, sz - 21, sx + 23, sz + 21);
  // ---- immeubles (identité ivoirienne : tours du Plateau, villas de Cocody, immeubles à balcons et enseignes d'Adjamé et Treichville) ----
  const FAC = [0xf2e8d0, 0xe8d0b0, 0xf6f0e2, 0xd8c8a8, 0xf0dcc0, 0xc8d8c8, 0xf4e4c8, 0xe0c8a0], TRIM = [0xf77f00, 0x009e60, 0xf6f6f6, 0x8a4a2a], ROOF = [0x9a5a3a, 0x7a7a76, 0x5a6a7a];
  const district = (x, z) => (z > 550 ? 'sud' : x > -300 && x < 300 && z > -300 ? 'plateau' : x > 600 ? 'cocody' : x < -700 && z > -300 ? 'ouest' : 'nord');
  const building = (x, z, w, d, ry, kind) => {
    const fac = FAC[(R() * FAC.length) | 0], trim = TRIM[(R() * TRIM.length) | 0], floors = kind === 'tour' ? 10 + ((R() * 18) | 0) : kind === 'centre' ? 2 + ((R() * 4) | 0) : kind === 'villa' ? 2 : kind === 'maison' ? 1 : 1 + ((R() * 3) | 0), h = floors * 3.2;
    const m = new THREE.Matrix4().makeRotationY(ry).setPosition(x, 0, z), add = (geo, c, arr = parts) => arr.push(colorize(geo.applyMatrix4(m), c));
    if (kind === 'tour') { add(new THREE.BoxGeometry(w, h, d).translate(0, h / 2, 0), [0x4a7a98, 0x5a8aa8, 0x3a6a7a, 0x7a9aa8][(R() * 4) | 0], glass); for (let f = 2; f < floors; f += 3) add(new THREE.BoxGeometry(w + 0.15, 0.4, d + 0.15).translate(0, f * 3.2, 0), 0xe8e8e4); add(new THREE.BoxGeometry(w + 0.4, 3, d + 0.4).translate(0, 1.5, 0), 0xd8d4cc); if (R() < 0.3) add(new THREE.BoxGeometry(w * 0.5, 4, d * 0.5).translate(0, h + 2, 0), 0xd8d4cc); }
    else if (kind === 'villa') { const W2 = w / 2, D2 = d / 2; for (const [a, b, c2, e] of [[-W2, -D2, W2, -D2 + 0.3], [-W2, -D2, -W2 + 0.3, D2], [W2 - 0.3, -D2, W2, D2], [-W2, D2 - 0.3, -1.6, D2], [1.6, D2 - 0.3, W2, D2]]) add(new THREE.BoxGeometry(c2 - a, 2.6, e - b).translate((a + c2) / 2, 1.3, (b + e) / 2), 0xf6f0e2); add(new THREE.BoxGeometry(3.2, 2.4, 0.1).translate(0, 1.2, D2 - 0.15), 0x2a2d33); add(new THREE.BoxGeometry(w * 0.6, 6.4, d * 0.46).translate(0, 3.2, -D2 * 0.4), fac); add(new THREE.ConeGeometry(Math.max(w * 0.6, d * 0.46) * 0.75, 2.4, 4).rotateY(PI / 4).translate(0, 7.6, -D2 * 0.4), ROOF[(R() * 3) | 0]); add(new THREE.BoxGeometry(w * 0.5, 0.15, 1.4).translate(0, 3.2, -D2 * 0.4 + d * 0.23 + 0.7), trim); }
    else { add(new THREE.BoxGeometry(w, h, d).translate(0, h / 2, 0), fac); add(new THREE.BoxGeometry(w + 0.2, 0.35, d + 0.2).translate(0, h + 0.17, 0), kind === 'maison' ? ROOF[(R() * 3) | 0] : 0xd8d0c0);
      for (let f = 0; f < floors; f++) for (let k = -1; k <= 1; k++) add(new THREE.BoxGeometry(w * 0.18, 1.3, 0.06).translate(k * w * 0.3, 1.8 + f * 3.2, d / 2 + 0.03), 0x2a3036);
      for (let f = 1; f < floors; f++) add(new THREE.BoxGeometry(w * 0.85, 0.15, 1.2).translate(0, f * 3.2, d / 2 + 0.6), trim);
      if (kind === 'centre' || (kind !== 'maison' && R() < 0.4)) { add(new THREE.BoxGeometry(w * 0.92, 0.14, 1.8).translate(0, 2.9, d / 2 + 0.9), TRIM[(R() * 4) | 0]); const t = SHOPS[(R() * SHOPS.length) | 0]; (signs[t] || (signs[t] = [])).push(new THREE.PlaneGeometry(Math.min(w * 0.85, 6.5), 0.75).translate(0, 3.5, d / 2 + 0.05).applyMatrix4(m)); } }
    const sw = Math.abs(Math.sin(ry)) > 0.5, hw = (sw ? d : w) / 2, hd = (sw ? w : d) / 2; cols.push(C.addBox(O.x + x - hw, O.z + z - hd, O.x + x + hw, O.z + z + hd, kind === 'villa' ? 7 : h));
  };
  const kindAt = (x, z) => { const D = district(x, z); if (D === 'plateau') return R() < 0.75 ? 'tour' : 'centre'; if (D === 'cocody') return R() < (x > 1700 ? 0.5 : 0.65) ? 'villa' : 'immeuble'; if (D === 'sud') return x < 600 ? (R() < 0.6 ? 'centre' : 'immeuble') : R() < 0.4 ? 'maison' : 'immeuble'; if (D === 'ouest') return R() < 0.6 ? 'maison' : 'immeuble'; return R() < 0.3 ? 'maison' : R() < 0.7 ? 'immeuble' : 'centre'; };
  const dens = (quality === 'low' ? 0.5 : quality === 'high' ? 0.92 : 0.78);
  const place = (x, z, w, d, rr) => { const sw = Math.abs(Math.sin(rr)) > 0.5, hw = (sw ? d : w) / 2 + 1, hd = (sw ? w : d) / 2 + 1, D = district(x, z), k = D === 'nord' && z < -1000 ? 0.45 : D === 'nord' || D === 'ouest' ? 0.65 : 1;
    if (R() > dens * k || isRes(x - hw, z - hd, x + hw, z + hd) || roadAt(x, z, Math.max(hw, hd)) || [[0, 0], [-hw, -hd], [hw, hd], [-hw, hd], [hw, -hd]].some(([a, b]) => wet(x + a, z + b)) || z + hd > CO - 34) return; building(x, z, w, d, rr, kindAt(x, z)); reserve(x - hw, z - hd, x + hw, z + hd); };
  const blocks = (xs, zs, stp) => { for (let i = 0; i < xs.length - 1; i++) for (let j = 0; j < zs.length - 1; j++) { const bx0 = xs[i] + 8, bx1 = xs[i + 1] - 8, bz0 = zs[j] + 8, bz1 = zs[j + 1] - 8; if (bx1 - bx0 < 20 || bz1 - bz0 < 20) continue;
    for (let x = bx0 + 8; x < bx1 - 6; x += stp) { const w = 10 + R() * 5, d = 10 + R() * 5; place(x, bz1 - d / 2 - 1, w, d, 0); place(x, bz0 + d / 2 + 1, w, d, PI); }
    for (let z = bz0 + 22; z < bz1 - 20; z += stp) { const w = 10 + R() * 5, d = 10 + R() * 5; place(bx0 + d / 2 + 1, z, w, d, -PI / 2); place(bx1 - d / 2 - 1, z, w, d, PI / 2); } } };
  blocks([-300, -150, 150, 300], [-300, -200, 0, 150, 250], 16);
  blocks([-1600, -1100, -600, -150, 150, 500, 600], [-1700, -900, -500, -300], 18);
  blocks([-1600, -1100, -700], [-300, 0, 250], 18);
  blocks([600, 850, 1200, 1500, 1900, 2300, 2600], [-1700, -900, -500, -200, 100, 250], 20);
  blocks([-600, -150, 150, 600, 1000, 1500, 1900, 2300, 2600], [550, 650, 900, 1100, 1350], 17);
  // ---- arbres, cocotiers, lampadaires ----
  const tree = (x, z, h, r, palm, c = 0x2f6a2a) => { parts.push(colorize(new THREE.CylinderGeometry(0.16, 0.3, h, 5).translate(x, h / 2, z), 0x6a5236)); parts.push(colorize(palm ? new THREE.ConeGeometry(2.8, 1.4, 7).translate(x, h + 0.3, z) : new THREE.SphereGeometry(r, 7, 5).translate(x, h + r * 0.4, z), palm ? 0x3f7a2a : c)); circle(x, z, 0.35, h); };
  for (let x = -580; x < 2600; x += 30) { const z = CO - 25; if (!isRes(x - 2, z - 2, x + 2, z + 2) && !roadAt(x, z, 1)) tree(x, z, 9 + R() * 3, 0, true); }
  for (let x = -280; x < 290; x += 26) { const z = 244; if (Math.abs(x) > 50 && !roadAt(x, z, 1) && !isRes(x - 2, z - 2, x + 2, z + 2)) tree(x, z, 8 + R() * 3, 0, true); }
  const lamp = (x, z, rr) => { const m = new THREE.Matrix4().makeRotationY(rr).setPosition(x, 0, z); parts.push(colorize(new THREE.CylinderGeometry(0.07, 0.1, 7, 6).translate(0, 3.5, 0).applyMatrix4(m), 0x5a5e64)); parts.push(colorize(new THREE.BoxGeometry(0.08, 0.08, 1.8).translate(0, 6.9, 0.85).applyMatrix4(m), 0x5a5e64)); heads.push(new THREE.BoxGeometry(0.35, 0.15, 0.7).translate(0, 6.85, 1.7).applyMatrix4(m)); circle(x, z, 0.18, 7); lamps.push([x + Math.sin(rr) * 1.7, z + Math.cos(rr) * 1.7]); };
  for (const [x0, z0, x1, z1, w] of ROADS) { const along = x0 === x1, a0 = along ? Math.min(z0, z1) : Math.min(x0, x1), a1 = along ? Math.max(z0, z1) : Math.max(x0, x1); if (a1 - a0 < 120) continue;
    for (let t = a0 + 15, k = 0; t < a1 - 10; t += 40, k++) { const s = k % 2 ? 1 : -1, x = along ? x0 + s * (w / 2 + 0.7) : t, z = along ? t : z0 + s * (w / 2 + 0.7); if (isRes(x - 1, z - 1, x + 1, z + 1) || wet(x, z) || ROADS.some((r) => (r[0] === r[2] ? !along && Math.abs(r[0] - x) < 9 && z > Math.min(r[1], r[3]) && z < Math.max(r[1], r[3]) : along && Math.abs(r[1] - z) < 9 && x > Math.min(r[0], r[2]) && x < Math.max(r[0], r[2])))) continue; lamp(x, z, along ? (s > 0 ? -PI / 2 : PI / 2) : (s > 0 ? PI : 0)); } }
  // ---- drapeau de la Côte d'Ivoire (orange, blanc, vert) ----
  const flagTex = (() => { const c = document.createElement('canvas'); c.width = 300; c.height = 200; const x = c.getContext('2d'); x.fillStyle = '#f77f00'; x.fillRect(0, 0, 100, 200); x.fillStyle = '#ffffff'; x.fillRect(100, 0, 100, 200); x.fillStyle = '#009e60'; x.fillRect(200, 0, 100, 200); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t; })();
  const flag = (x, z, h = 9) => { parts.push(colorize(new THREE.CylinderGeometry(0.06, 0.08, h, 6).translate(x, h / 2, z), 0xd8dde2)); const f = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 1.6), new THREE.MeshBasicMaterial({ map: flagTex, side: THREE.DoubleSide })); f.position.set(x + 1.25, h - 0.9, z); g.add(f); circle(x, z, 0.12, h); };
  const label = (t, sub, w, h, bg, fg) => { const c = document.createElement('canvas'); c.width = 1024; c.height = Math.max(64, Math.round(1024 * h / w)); const x = c.getContext('2d'); x.fillStyle = bg; x.fillRect(0, 0, c.width, c.height); x.fillStyle = fg; x.textAlign = 'center'; x.textBaseline = 'middle'; x.font = `900 ${Math.round(c.height * (sub ? 0.38 : 0.55))}px Arial`; x.fillText(t, c.width / 2, c.height * (sub ? 0.38 : 0.52), c.width - 30); if (sub) { x.font = `700 ${Math.round(c.height * 0.2)}px Arial`; x.fillText(sub, c.width / 2, c.height * 0.78, c.width - 30); } const tx = new THREE.CanvasTexture(c); tx.colorSpace = THREE.SRGBColorSpace; return new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ map: tx, side: THREE.DoubleSide })); };
  const put = (mesh, x, y, z, rr = 0) => { mesh.position.set(x, y, z); mesh.rotation.y = rr; g.add(mesh); return mesh; };
  const roadSign = (t, x, z, rr) => { parts.push(colorize(new THREE.CylinderGeometry(0.05, 0.05, 3, 6).translate(x, 1.5, z), 0x8a8f96)); put(label(t, '', 3.6, 0.7, '#009e60', '#ffffff'), x, 3.1, z, rr); circle(x, z, 0.1, 3); };
  // ---- cathédrale Saint-Paul (Plateau) : nef, tour inclinée et haubans (stylisés) ----
  { const c0 = P.cathedrale; box(-286, 0.03, 34, -170, 0.08, 146, 0xd8d4c8);
    parts.push(colorize(new THREE.BoxGeometry(80, 12, 70).translate(-240, 6, 90), 0xf2f0ea)); parts.push(colorize(new THREE.ConeGeometry(52, 14, 4).rotateY(PI / 4).scale(1.08, 1, 0.94).translate(-240, 19, 90), 0xc8c4bc)); solid(-282, 54, -198, 126, 26);
    const tw = new THREE.BoxGeometry(5, 62, 9).translate(0, 31, 0).rotateZ(0.32).translate(-186, 0, 90); parts.push(colorize(tw, 0xf6f4ee)); box(-188, 0, 84, -180, 4, 96, 0xe8e4dc); solid(-190, 84, -178, 96, 8);
    const top = new THREE.Vector3(-186 - Math.sin(0.32) * 62, Math.cos(0.32) * 62, 90); box(top.x - 0.4, top.y, 89.6, top.x + 0.4, top.y + 6, 90.4, 0xd8c890); box(top.x - 2, top.y + 3.5, 89.6, top.x + 2, top.y + 4.3, 90.4, 0xd8c890);
    for (const [ex, ez] of [[-280, 55], [-280, 125], [-240, 55], [-240, 125], [-205, 60], [-205, 120]]) { const a = new THREE.Vector3(ex, 12, ez), dv = top.clone().sub(a), len = dv.length(); const cg = new THREE.CylinderGeometry(0.1, 0.1, len, 4).translate(0, len / 2, 0); cg.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), dv.normalize())); cg.translate(a.x, a.y, a.z); parts.push(colorize(cg, 0xe8e8e8)); }
    put(label('CATHÉDRALE SAINT-PAUL', 'lieu de culte • visite respectueuse • stylisée', 7, 1.1, '#2a4a7a', '#ffffff'), -168, 2.6, c0.z, PI / 2); Pt(-162, c0.z, 3.2, '⛪ Cathédrale Saint-Paul du Plateau', () => ctx.visit('cathedrale')); }
  // ---- belvédère sur la lagune Ébrié (pointe du Plateau) ----
  { box(-40, 0.03, 200, 40, 0.1, 248, 0xd8d4c8); box(-40, 0.1, 247.5, 40, 1.1, 248, 0xe8e4dc); solid(-40, 247.5, 40, 248, 1.1); for (const dx of [-30, 30]) flag(dx, 205); put(label('LAGUNE ÉBRIÉ', 'belvédère du Plateau • représentation stylisée', 6, 1, '#2a6a72', '#ffffff'), 0, 2.4, 244, PI); Pt(0, 236, 4, '🌊 Visiter : vue sur la lagune Ébrié', () => ctx.visit('lagune')); }
  // ---- stade Félix-Houphouët-Boigny (stylisé) ----
  { const s = P.stade; parts.push(colorize(new THREE.CylinderGeometry(62, 58, 16, 32, 1, true).scale(1.06, 1, 0.82).translate(s.x, 8, s.z), 0xe8e4dc)); parts.push(colorize(new THREE.CylinderGeometry(64, 64, 1.2, 32, 1, true).scale(1.06, 1, 0.82).translate(s.x, 16.6, s.z), 0xf77f00)); parts.push(colorize(new THREE.CylinderGeometry(46, 46, 0.3, 32).scale(1.06, 1, 0.82).translate(s.x, 0.15, s.z), 0x3f8a3a));
    solid(s.x - 60, s.z - 46, s.x + 60, s.z + 46, 17); for (const dx of [-30, 0, 30]) flag(s.x + dx, s.z + 56, 10); put(label('STADE FÉLIX-HOUPHOUËT-BOIGNY', 'Le Plateau • représentation stylisée', 9, 1.3, '#f77f00', '#ffffff'), s.x, 2.6, s.z + 60); Pt(s.x, s.z + 65, 3.5, '🏟️ Visiter : stade Félix-Houphouët-Boigny', () => ctx.visit('stade')); }
  // ---- marché d'Adjamé ----
  { const b = P.adjame; box(-385, 0, -725, -215, 0.05, -565, 0x8a7a62); for (let r = 0; r < 4; r++) for (let k = 0; k < 7; k++) { const x = -372 + k * 24, z = -705 + r * 34; box(x - 3, 0, z - 1.4, x + 3, 0.85, z + 1.4, 0x8a6440); parts.push(colorize(new THREE.BoxGeometry(6.6, 0.12, 4).translate(x, 2.6, z), [0xf77f00, 0x009e60, 0xf2c200, 0x2a6ad8, 0xc8102e][(k + r) % 5])); for (const [a, b2] of [[-3, -1.8], [3, -1.8], [-3, 1.8], [3, 1.8]]) box(x + a - 0.06, 0, z + b2 - 0.06, x + a + 0.06, 2.6, z + b2 + 0.06, 0x5a4228); for (let j = 0; j < 4; j++) box(x - 2.5 + j * 1.3, 0.85, z - 0.9, x - 1.6 + j * 1.3, 1.25, z + 0.9, [0xc8102e, 0xf2c200, 0x2fb04a, 0xf77f00, 0x2a6ad8][(j + k + r) % 5]); solid(x - 3, z - 1.4, x + 3, z + 1.4, 1); }
    put(label('MARCHÉ D’ADJAMÉ', 'représentation stylisée', 8, 1.2, '#f77f00', '#ffffff'), b.x, 3.4, -575); Pt(b.x, -569, 3.5, '🛍️ Marché d’Adjamé : acheter', () => ctx.market('adjame')); }
  // ---- gare routière d'Adjamé ----
  { const s = P.gare; box(225, 0, -765, 415, 0.05, -603, 0x5a5c60); box(240, 4, -760, 400, 4.4, -745, 0x9aa0a6); for (const dx of [245, 320, 395]) { box(dx - 0.3, 0, -760, dx + 0.3, 4, -759.4, 0x5a5e64); circle(dx, -759.7, 0.4, 4); }
    for (let k = 0; k < 9; k++) { const bx = 240 + k * 20, bz = -700; box(bx - 1.3, 0.45, bz - 5, bx + 1.3, 3.2, bz + 5, [0x009e60, 0xf77f00, 0xf2f2ee][k % 3]); box(bx - 1.32, 1.9, bz - 4.8, bx + 1.32, 2.7, bz + 4.8, 0x2a3a44); solid(bx - 1.3, bz - 5, bx + 1.3, bz + 5, 3.2); }
    put(label('GARE ROUTIÈRE D’ADJAMÉ', 'cars interurbains et internationaux • stylisée', 8, 1.2, '#2a2d33', '#f2c200'), s.x, 3.4, -615); Pt(s.x, -608, 3, '🚌 Gare routière d’Adjamé : cars', () => ctx.busStation()); }
  // ---- forêt du Banco (parc national en pleine ville) ----
  { box(-1555, 0.03, -1255, -745, 0.06, -525, 0x3e6a32); for (let k = 0; k < 140; k++) { const x = -1540 + (k % 14) * 57 + (k % 3) * 6, z = -1240 + Math.floor(k / 14) * 70 + (k % 2) * 9; if (roadAt(x, z, 4)) continue; tree(x, z, 12 + (k % 5) * 3, 3.5 + (k % 3), false, k % 2 ? 0x24521f : 0x2f6227); }
    box(-1175, 0, -533, -1125, 3.2, -529, 0x6a4a2a); solid(-1175, -533, -1125, -529, 3.2); put(label('FORÊT DU BANCO', 'parc national • forêt en pleine ville • stylisée', 8, 1.2, '#24521f', '#ffffff'), -1150, 2.4, -526.5); Pt(-1150, -519, 3.5, '🌳 Visiter : forêt du Banco', () => ctx.visit('banco')); }
  // ---- basilique Notre-Dame-de-la-Paix (Yamoussoukro) : RAPPROCHÉE dans le jeu ----
  { const b = P.basilique; box(-580, 0.03, -1690, -170, 0.07, -910, 0xe0dccf); parts.push(colorize(new THREE.CylinderGeometry(46, 48, 30, 40).translate(b.x, 15, b.z), 0xf2f0ea)); parts.push(colorize(new THREE.SphereGeometry(44, 32, 12, 0, PI * 2, 0, PI / 2).scale(1, 1.3, 1).translate(b.x, 30, b.z), 0x9ab4c4));
    parts.push(colorize(new THREE.CylinderGeometry(4, 5, 10, 12).translate(b.x, 92, b.z), 0xf2f0ea)); parts.push(colorize(new THREE.SphereGeometry(4.5, 12, 6).translate(b.x, 98, b.z), 0xd8c890)); box(b.x - 0.4, 101, b.z - 0.4, b.x + 0.4, 108, b.z + 0.4, 0xd8c890); box(b.x - 2.4, 105, b.z - 0.4, b.x + 2.4, 105.8, b.z + 0.4, 0xd8c890); circle(b.x, b.z, 48, 30);
    box(b.x - 30, 0, b.z + 40, b.x + 30, 22, b.z + 58, 0xf2f0ea); parts.push(colorize(new THREE.ConeGeometry(34, 8, 4).rotateY(PI / 4).scale(1, 1, 0.4).translate(b.x, 26, b.z + 50), 0xe8e4dc)); for (let k = 0; k < 8; k++) { const x = b.x - 26 + k * 7.4; parts.push(colorize(new THREE.CylinderGeometry(1.1, 1.2, 20, 10).translate(x, 10, b.z + 61), 0xf6f4ee)); circle(x, b.z + 61, 1.2, 20); } solid(b.x - 30, b.z + 40, b.x + 30, b.z + 58, 22);
    for (const rad of [125, 140]) for (let a = 0.2; a <= PI - 0.2 + 1e-6; a += (PI - 0.4) / 30) { if (Math.abs(a - PI / 2) < 0.18) continue; const x = b.x + Math.cos(a) * rad, z = b.z + 40 + Math.sin(a) * rad * 0.9; parts.push(colorize(new THREE.CylinderGeometry(1.2, 1.3, 16, 10).translate(x, 8, z), 0xf6f4ee)); circle(x, z, 1.3, 16); }
    for (let a = 0.2; a < PI - 0.2; a += (PI - 0.4) / 30) { if (Math.abs(a - PI / 2) < 0.2) continue; const x = b.x + Math.cos(a) * 132.5, z = b.z + 40 + Math.sin(a) * 132.5 * 0.9; parts.push(colorize(new THREE.BoxGeometry(18, 1.2, 4).rotateY(PI / 2 - a).translate(x, 16.6, z), 0xe8e4dc)); }
    put(label('BASILIQUE NOTRE-DAME-DE-LA-PAIX', 'rapprochée dans le jeu : en réalité à Yamoussoukro, ≈ 230 km au nord-ouest', 11, 1.5, '#2a4a7a', '#ffffff'), b.x, 2.8, -925); Pt(b.x, -917, 4, '⛪ Basilique Notre-Dame-de-la-Paix (rapprochée)', () => ctx.visit('basilique')); }
  // ---- université Félix-Houphouët-Boigny (Cocody) ----
  { const u = P.universite; for (const [dx, dz, w, d, hh] of [[-70, -50, 70, 26, 13], [50, -50, 60, 26, 10], [-60, 30, 50, 30, 7], [60, 30, 60, 26, 10]]) { box(u.x + dx - w / 2, 0, u.z + dz - d / 2, u.x + dx + w / 2, hh, u.z + dz + d / 2, 0xf0e4c8); for (let f = 1; f * 3.2 < hh; f++) box(u.x + dx - w / 2, f * 3.2, u.z + dz + d / 2, u.x + dx + w / 2, f * 3.2 + 0.3, u.z + dz + d / 2 + 0.6, 0xf77f00); solid(u.x + dx - w / 2, u.z + dz - d / 2, u.x + dx + w / 2, u.z + dz + d / 2, hh); }
    flag(u.x - 20, u.z + 70, 8); put(label('UNIVERSITÉ FÉLIX-HOUPHOUËT-BOIGNY', 'Cocody • stylisée', 9, 1.3, '#2a4a7a', '#ffffff'), u.x, 3.2, u.z + 76); Pt(u.x, u.z + 82, 3, '🎓 Université Félix-Houphouët-Boigny (Cocody)', () => ctx.visit('universite')); }
  // ---- hôtel, restaurants (maquis, garbadrome), centre commercial, stations ----
  { const h = P.hotel; box(955, 0, 140, 1045, 42, 230, 0xf2ecdc); for (let f = 1; f < 13; f++) box(954, f * 3.2, 139, 1046, f * 3.2 + 0.3, 231, 0xf77f00); box(950, 42, 135, 1050, 43, 235, 0x7a7a76); solid(955, 140, 1045, 230, 43); put(label('HÔTEL LES PALMIERS DE COCODY', 'hôtel fictif', 9, 1.3, '#5a3a22', '#f2c200'), h.x, 4, 139.4, PI); Pt(h.x, 132, 2.6, '🏨 Hôtel Les Palmiers de Cocody (fictif) : réception', () => ctx.hotel()); }
  for (const [rx, rz, nm, sub, nmx] of [[400, 760, 'MAQUIS CHEZ TANTIE AWA', 'maquis fictif', 'Maquis Chez Tantie Awa'], [1050, -60, 'GARBADROME DU LAGON', 'restaurant fictif', 'Garbadrome du Lagon']]) { box(rx - 14, 0, rz - 10, rx + 14, 3.4, rz + 6, 0xf0d8a8); box(rx - 15, 3.4, rz - 11, rx + 15, 3.7, rz + 7, 0x8a4a2a); solid(rx - 14, rz - 10, rx + 14, rz + 6, 3.7); put(label(nm, sub, 4.8, 0.85, '#f77f00', '#ffffff'), rx, 2.6, rz + 6.1); Pt(rx, rz + 9, 2.4, `🍲 ${nmx} (fictif) : manger`, () => ctx.restaurant(nmx)); }
  { const s = P.mall; box(s.x - 85, 0, s.z - 95, s.x + 85, 11, s.z + 95, 0xe8e4dc); box(s.x - 86, 11, s.z - 96, s.x + 86, 11.8, s.z + 96, 0x009e60); box(s.x - 60, 0.2, s.z + 95, s.x + 60, 8, s.z + 95.2, 0x2a4a5a); solid(s.x - 85, s.z - 95, s.x + 85, s.z + 95, 11.8); put(label('CAP LAGUNE MALL', 'centre commercial fictif', 10, 1.4, '#009e60', '#ffffff'), s.x, 9, s.z + 95.6); Pt(s.x, s.z + 100, 3, '🛒 Cap Lagune Mall (fictif)', () => ctx.market('mall')); }
  for (const [sx, sz] of [[700, 780], [2100, 1000]]) { box(sx - 22, 0, sz - 20, sx + 22, 0.05, sz + 20, 0x4a4d52); for (const dx of [-7, 7]) { box(sx + dx - 0.6, 0, sz - 1, sx + dx + 0.6, 1.8, sz + 1, 0xd8dde2); solid(sx + dx - 0.6, sz - 1, sx + dx + 0.6, sz + 1, 1.8); } box(sx - 14, 4.4, sz - 7, sx + 14, 4.8, sz + 7, 0xf77f00); for (const [a, b] of [[-13, -6], [13, -6], [-13, 6], [13, 6]]) { box(sx + a - 0.2, 0, sz + b - 0.2, sx + a + 0.2, 4.4, sz + b + 0.2, 0xd8dde2); circle(sx + a, sz + b, 0.25, 4.4); } box(sx + 12, 0, sz - 19, sx + 20, 3, sz - 11, 0xf4f0e6); solid(sx + 12, sz - 19, sx + 20, sz - 11, 3); put(label('STATION LAGUNE', 'station-service fictive', 5, 0.9, '#f77f00', '#ffffff'), sx, 5.4, sz + 7.2); Pt(sx + 16, sz - 9, 2.2, '⛽ Station Lagune (fictive) : boutique', () => ctx.shopStation()); }
  // ---- pont Henri-Konan-Bédié (entrée nord, Riviera) ----
  { put(label('PONT HENRI-KONAN-BÉDIÉ', 'Riviera – Marcory • pont à péage • stylisé', 7, 1.1, '#1a1a1a', '#f2c200'), P.pont.x + 8, 2.6, 238, PI); parts.push(colorize(new THREE.CylinderGeometry(0.06, 0.06, 2.2, 5).translate(P.pont.x + 8, 1.1, 238.2), 0x5a5e64)); circle(P.pont.x + 8, 238.2, 0.1, 2.2); Pt(P.pont.x, P.pont.z, 3, '🌉 Pont Henri-Konan-Bédié', () => ctx.visit('pont')); }
  // ---- marché de Treichville ----
  { const t = P.treichville; box(-120, 0, 700, 120, 12, 860, 0xf2e8d0); for (let k = 0; k < 6; k++) parts.push(colorize(new THREE.CylinderGeometry(13, 13, 236, 16).rotateZ(PI / 2).scale(1, 0.55, 1).translate(0, 12, 714 + k * 26.5), 0xd86a2a)); for (let k = -5; k <= 5; k++) box(k * 21 - 3.5, 0.2, 699.8, k * 21 + 3.5, 6, 700, 0x5a3a22); solid(-120, 700, 120, 860, 20);
    for (const dx of [-60, 60]) flag(dx, 692, 8); put(label('MARCHÉ DE TREICHVILLE', 'représentation stylisée', 9, 1.3, '#009e60', '#ffffff'), t.x, 3.4, 696, PI); Pt(t.x, 690, 3.5, '🛍️ Marché de Treichville : acheter', () => ctx.market('treichville')); }
  // ---- port autonome (décor, vu de l'extérieur) : quai, portiques, conteneurs ----
  { box(-580, 0.03, 555, -160, 0.08, 878, 0x6a6c70); box(-580, 0, 876, -160, 2.2, 877, 0x8a8f96); solid(-580, 876, -160, 877, 2.2);
    for (const x of [-540, -460, -380, -300]) { for (const dz of [0, 18]) { box(x - 1, 0, 568 + dz, x + 1, 30, 570 + dz, 0xd86a2a); box(x + 30 - 1, 0, 568 + dz, x + 30 + 1, 30, 570 + dz, 0xd86a2a); circle(x, 569 + dz, 1.4, 30); circle(x + 30, 569 + dz, 1.4, 30); } box(x - 1, 30, 560, x + 31, 33, 590, 0xd86a2a); }
    for (let k = 0; k < 40; k++) { const x = -560 + (k % 10) * 38, z = 640 + Math.floor(k / 10) * 50, hh = 2.6 * (1 + (k % 3)); box(x, 0, z, x + 12, hh, z + 5, [0x2a6ad8, 0xc8102e, 0x009e60, 0xf77f00, 0x8a8f96][k % 5]); solid(x, z, x + 12, z + 5, hh); }
    put(label('PORT D’ABIDJAN', 'zone portuaire • vue de l’extérieur • stylisée', 8, 1.2, '#2a4a7a', '#ffffff'), P.port.x, 3, 880); Pt(P.port.x, 886, 3.5, '⚓ Port d’Abidjan (vue de l’extérieur)', () => ctx.visit('port')); }
  // ---- plage de Port-Bouët ----
  { const p0 = P.plage; for (let k = 0; k < 5; k++) { const x = p0.x - 80 + k * 40, z = 1394; parts.push(colorize(new THREE.ConeGeometry(3.4, 1.4, 8).translate(x, 3.4, z), [0xf77f00, 0xf6f6f6, 0x009e60, 0x2a6ad8, 0xf2c200][k])); parts.push(colorize(new THREE.CylinderGeometry(0.08, 0.08, 3, 5).translate(x, 1.5, z), 0x5a4228)); circle(x, z, 0.2, 3); } put(label('PLAGE DE PORT-BOUËT', 'baignade dangereuse (fortes vagues) • stylisée', 6, 1, '#2a6ad8', '#ffffff'), p0.x + 20, 2.4, 1372, PI); parts.push(colorize(new THREE.CylinderGeometry(0.06, 0.06, 2, 5).translate(p0.x + 20, 1, 1372.2), 0x5a5e64)); circle(p0.x + 20, 1372.2, 0.1, 2); Pt(p0.x, 1376, 4, '🌴 Plage de Port-Bouët', () => ctx.visit('plage')); }
  // ---- hôpital, école ----
  { const h = P.hopital; box(h.x - 58, 0, h.z - 46, h.x + 58, 12.8, h.z + 46, 0xf4f4f2); box(h.x - 5, 12.8, h.z - 5, h.x + 5, 13, h.z + 5, 0x009e60); solid(h.x - 58, h.z - 46, h.x + 58, h.z + 46, 13); put(label('CENTRE HOSPITALIER UNIVERSITAIRE', 'Treichville • représentation stylisée', 9, 1.2, '#ffffff', '#009e60'), h.x, 8.2, h.z + 46.2); Pt(h.x, h.z + 49, 3, '🏥 CHU (stylisé) : consultation', () => ctx.hospital()); }
  { const e = P.ecole; box(e.x - 28, 0, e.z - 28, e.x + 28, 3.4, e.z - 14, 0xf0e4c8); box(e.x - 29, 3.4, e.z - 29, e.x + 29, 3.7, e.z - 13, 0x8a4a2a); solid(e.x - 28, e.z - 28, e.x + 28, e.z - 14, 3.7); box(e.x - 28, 0.02, e.z - 14, e.x + 28, 0.05, e.z + 30, 0xc8a070); put(label('ÉCOLE PRIMAIRE', 'Marcory • stylisée', 6, 1, '#2a4a7a', '#ffffff'), e.x, 2.6, e.z - 13.9); flag(e.x + 22, e.z + 24, 7); Pt(e.x, e.z - 10, 2.6, '🎒 École primaire', () => ctx.visit('ecole')); }
  // ---- aéroport international Félix-Houphouët-Boigny (Port-Bouët, stylisé) ----
  { const a = P.aeroport; box(a.x - 120, 0, a.z - 22, a.x + 120, 14, a.z + 30, 0xe8e4dc); box(a.x - 122, 14, a.z - 24, a.x + 122, 15, a.z + 32, 0xf77f00); box(a.x - 100, 0.4, a.z - 22.2, a.x + 100, 8, a.z - 22, 0x2a4a5a); solid(a.x - 120, a.z - 22, a.x + 120, a.z + 30, 15);
    put(label('AÉROPORT INTERNATIONAL FÉLIX-HOUPHOUËT-BOIGNY', 'Port-Bouët • représentation stylisée', 16, 1.7, '#f77f00', '#ffffff'), a.x, 10.5, a.z - 22.4, PI); for (const dx of [-50, 50]) flag(a.x + dx, a.z - 34);
    box(1650, 0.03, 1300, 2550, 0.06, 1345, 0x3a3c40); for (let x = 1680; x < 2540; x += 40) box(x, 0.06, 1321.5, x + 20, 0.07, 1323.5, 0xf2f2f2); box(a.x - 140, 0.03, a.z + 30, a.x + 140, 0.05, 1298, 0x5a5c60);
    for (const [px, pz] of [[a.x - 60, a.z + 70], [a.x + 70, a.z + 72]]) { box(px - 20, 1.4, pz - 2, px + 20, 5, pz + 2, 0xf4f4f2); box(px - 2, 2.6, pz - 18, px + 4, 3.1, pz + 18, 0xd8dde2); box(px + 15, 5, pz - 0.2, px + 20, 9.5, pz + 0.2, 0xf77f00); solid(px - 20, pz - 2.2, px + 20, pz + 2.2, 5.4); }
    Pt(a.x, a.z - 30, 3.5, '✈️ Aérogare : vols, jet privé', () => ctx.airport()); }
  // ---- sortie est (route de Grand-Bassam, Noé et le Ghana), panneaux, taxis ----
  roadSign('Grand-Bassam • Noé–Elubo (Ghana) →', 2540, 912, -PI / 2); Pt(P.est.x, P.est.z, 4, '🛣️ Route de Grand-Bassam vers la frontière de Noé–Elubo et le Ghana', () => ctx.border('accra'));
  roadSign('Le Plateau ↑ Pont FHB', -162, 560, 0); roadSign('Treichville ↓', 162, 240, PI); roadSign('Cocody • Riviera →', 520, -488, 0); roadSign('Adjamé • Abobo ↑', -162, -310, 0); roadSign('Aéroport • Port-Bouët →', 1150, 912, 0); roadSign('Yamoussoukro (basilique rapprochée) ↑', -588, -890, PI / 2);
  for (const [x, z, n] of TAXIS) { put(label('TAXI', '', 1.2, 0.5, '#f77f00', '#ffffff'), x, 2.4, z, 0); parts.push(colorize(new THREE.CylinderGeometry(0.05, 0.05, 2.2, 5).translate(x, 1.1, z), 0x5a5e64)); circle(x, z, 0.1, 2.2); Pt(x, z + 1.4, 2.2, `🚕 Station de taxis (${n})`, () => ctx.taxi()); }
  // ---- maillages ----
  const mkm = (arr, mat) => { if (!arr.length) return; const ms = new THREE.Mesh(mergeGeometries(arr), mat); ms.receiveShadow = true; ms.castShadow = true; g.add(ms); };
  mkm(parts, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.85 })); mkm(glass, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.15, metalness: 0.45 }));
  if (heads.length) { for (const h of heads) for (const k of Object.keys(h.attributes)) if (!['position', 'normal'].includes(k)) h.deleteAttribute(k); g.add(new THREE.Mesh(mergeGeometries(heads), ctx.lampMat)); const pool = new THREE.InstancedMesh(new THREE.PlaneGeometry(13, 13).rotateX(-PI / 2), ctx.poolMat, lamps.length), dm = new THREE.Object3D(); lamps.forEach(([x, z], i) => { dm.position.set(x, 0.07, z); dm.updateMatrix(); pool.setMatrixAt(i, dm.matrix); }); pool.renderOrder = 2; g.add(pool); }
  for (const [t, arr] of Object.entries(signs)) { const c = document.createElement('canvas'); c.width = 512; c.height = 64; const x = c.getContext('2d'); x.fillStyle = ['#f77f00', '#f6f2e6', '#009e60', '#1a2a44'][t.length % 4]; x.fillRect(0, 0, 512, 64); x.fillStyle = t.length % 4 === 1 ? '#1a1a1a' : '#ffffff'; x.font = '900 32px Arial'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(t, 256, 34, 500); const tx = new THREE.CanvasTexture(c); tx.colorSpace = THREE.SRGBColorSpace; g.add(new THREE.Mesh(mergeGeometries(arr), new THREE.MeshBasicMaterial({ map: tx }))); }
  // ---- trottoirs des piétons ----
  const free = (x, z) => ![[0, 0], [0.4, 0], [-0.4, 0], [0, 0.4], [0, -0.4]].some(([a, b]) => C.pointBlocked(O.x + x + a, 0.5, O.z + z + b)) && !isWet(x, z);
  const runs = (ax, az, bx, bz) => { const L2 = Math.hypot(bx - ax, bz - az), n = Math.max(1, Math.floor(L2 / 2)), out = []; let st = null; for (let i = 0; i <= n; i++) { const t = i / n, x = ax + (bx - ax) * t, z = az + (bz - az) * t; if (free(x, z)) { if (!st) st = [x, z]; } else if (st) { if (Math.hypot(x - st[0], z - st[1]) > 30) out.push([st, [ax + (bx - ax) * ((i - 1) / n), az + (bz - az) * ((i - 1) / n)]]); st = null; } } if (st && Math.hypot(bx - st[0], bz - st[1]) > 30) out.push([st, [bx, bz]]); return out; };
  for (const [x0, z0, x1, z1, w] of ROADS) { if (Math.hypot(x1 - x0, z1 - z0) < 150) continue; for (const s of [-1, 1]) lanes.push(...(x0 === x1 ? runs(x0 + s * (w / 2 + 2), Math.min(z0, z1) + 10, x0 + s * (w / 2 + 2), Math.max(z0, z1) - 10) : runs(Math.min(x0, x1) + 5, z0 + s * (w / 2 + 2), Math.max(x0, x1) - 5, z0 + s * (w / 2 + 2)))); }
  // ---- carte du secteur (terre et eau échantillonnées) ----
  const S = 0.2, Wd = ABIDJAN.X1 - ABIDJAN.X0 + 80, Ht = CO + 300 - ABIDJAN.Z0 + 80, cv = document.createElement('canvas'); cv.width = Math.round(Wd * S); cv.height = Math.round(Ht * S); const x = cv.getContext('2d'), T = (lx, lz) => [(lx - ABIDJAN.X0 + 40) * S, (lz - ABIDJAN.Z0 + 40) * S];
  const img = x.createImageData(cv.width, cv.height); for (let py = 0; py < cv.height; py++) for (let px = 0; px < cv.width; px++) { const lx = px / S + ABIDJAN.X0 - 40, lz = py / S + ABIDJAN.Z0 - 40, i = (py * cv.width + px) * 4, wt = isWet(lx, lz); const c2 = wt ? (lz > CO ? [42, 122, 146] : [58, 122, 106]) : lz > CO - 30 ? [232, 214, 168] : (lx > -1555 && lx < -745 && lz > -1255 && lz < -525) ? [74, 116, 62] : [168, 154, 106]; img.data[i] = c2[0]; img.data[i + 1] = c2[1]; img.data[i + 2] = c2[2]; img.data[i + 3] = 255; } x.putImageData(img, 0, 0);
  x.fillStyle = '#d8ccb0'; for (const r of reserved) { if (r.x0 === -1560) continue; const [a, b] = T(r.x0, r.z0), [c2, d] = T(r.x1, r.z1); x.fillRect(a, b, Math.max(1, c2 - a), Math.max(1, d - b)); }
  x.strokeStyle = '#4d4f55'; x.lineCap = 'round'; for (const [x0, z0, x1, z1, w] of ROADS) { x.lineWidth = Math.max(2, w * S * 1.4); x.beginPath(); x.moveTo(...T(x0, z0)); x.lineTo(...T(x1, z1)); x.stroke(); }
  return { group: g, cols, points, lanes, map: { canvas: cv, X0: O.x + ABIDJAN.X0 - 40, Z0: O.z + ABIDJAN.Z0 - 40, W: Wd, H: Ht, S, has: ABIDJAN.has } };
}
export const ABIDJAN_PLACES = P;
export const ABIDJAN_QUARTIERS = QUARTIERS;
export const ABIDJAN_NAMES = NAMES;
