// Mission 016, phase 6 — garde-robe : 200 vêtements et accessoires distincts (couleur, coupe, motif ou forme),
// visibles sur le personnage procédural (un seul maillage, un seul matériau). Répartition demandée :
// 30 chemises & polos, 25 pantalons, 20 jeans, 20 t-shirts, 15 vestes & blazers, 15 ensembles professionnels,
// 15 tenues traditionnelles, 15 tenues décontractées, 15 tenues sportives, 10 chaussures, 10 accessoires, 10 tenues spéciales.
export const CLOTH_CATS = [
  ['chemises', 'Chemises & polos', 'haut'], ['pantalons', 'Pantalons', 'bas'], ['jeans', 'Jeans', 'bas'], ['tshirts', 'T-shirts', 'haut'],
  ['vestes', 'Vestes & blazers', 'veste'], ['pro', 'Ensembles professionnels', 'tenue'], ['trad', 'Tenues traditionnelles', 'tenue'], ['deco', 'Tenues décontractées', 'tenue'],
  ['sport', 'Tenues sportives', 'tenue'], ['chaussures', 'Chaussures', 'pieds'], ['acc', 'Accessoires', 'acc'], ['spec', 'Tenues spéciales', 'tenue'],
  ['luxe', 'Collection de luxe (à acheter)', 'tenue'], // mission 017 : achats personnels
];
const C = {
  blanc: 0xf2f2f2, noir: 0x1a1a1a, marine: 0x1f2a44, ciel: 0x8ab8e8, rouge: 0xc8102e, bordeaux: 0x6a1a2a, vert: 0x0b8a4f, olive: 0x6a7a3a, jaune: 0xf2c200, orange: 0xe46a1f,
  rose: 0xe88aa8, violet: 0x5b2c83, gris: 0x8a8f96, beige: 0xd8c8a8, marron: 0x6a4a32, turquoise: 0x2aa0a0, kaki: 0x8a7a4a, corail: 0xf07a6a, lavande: 0xa898d8, anthracite: 0x3a3d42,
  creme: 0xf0e6d0, moutarde: 0xc8a020, prune: 0x5a2a4a, emeraude: 0x0f6a5a, sable: 0xc8b088, chocolat: 0x4a2e1e, cobalt: 0x1f4ec8, menthe: 0x8ad8b8, saumon: 0xf2a088, ardoise: 0x5a6a7a,
  dore: 0xd8a830, argent: 0xc8ccd0, bouteille: 0x1a4a2a, lilas: 0xc8a8e0, brique: 0xa8442a,
};
const NM = { blanc: 'blanc', noir: 'noir', marine: 'bleu marine', ciel: 'bleu ciel', rouge: 'rouge', bordeaux: 'bordeaux', vert: 'vert', olive: 'vert olive', jaune: 'jaune', orange: 'orange', rose: 'rose', violet: 'violet', gris: 'gris', beige: 'beige', marron: 'marron', turquoise: 'turquoise', kaki: 'kaki', corail: 'corail', lavande: 'lavande', anthracite: 'anthracite', creme: 'crème', moutarde: 'moutarde', prune: 'prune', emeraude: 'émeraude', sable: 'sable', chocolat: 'chocolat', cobalt: 'bleu cobalt', menthe: 'menthe', saumon: 'saumon', ardoise: 'ardoise', dore: 'doré', argent: 'argenté', bouteille: 'vert bouteille', lilas: 'lilas', brique: 'brique' };
const L = [];
const add = (cat, name, o, sw, pat = null, slot = null, price = 0) => L.push({ id: `${cat}-${L.filter((q) => q.cat === cat).length + 1}`, cat, slot: slot || CLOTH_CATS.find((c) => c[0] === cat)[2], name, o, sw, pat, price });

// ---- 30 chemises & polos ----
for (const k of ['blanc', 'ciel', 'marine', 'rose', 'lavande', 'noir', 'bordeaux', 'creme', 'menthe', 'gris', 'saumon', 'kaki']) add('chemises', `Chemise ${NM[k]} à manches longues`, { shirtColor: C[k], sleeves: 'long', collar: true }, C[k]);
for (let i = 0; i < 8; i++) add('chemises', `Chemise en wax n°${i + 1}`, { pagne: i, collar: true }, null, i);
for (const k of ['blanc', 'noir', 'rouge', 'vert', 'jaune', 'cobalt', 'orange', 'turquoise', 'prune', 'sable']) add('chemises', `Polo ${NM[k]}`, { shirtColor: C[k], collar: true }, C[k]);
// ---- 25 pantalons ----
for (const k of ['noir', 'marine', 'gris', 'beige', 'kaki', 'marron', 'blanc', 'anthracite', 'olive', 'bordeaux', 'creme', 'chocolat', 'sable', 'ardoise', 'bouteille', 'prune', 'moutarde', 'brique', 'ciel', 'emeraude', 'lavande', 'rose', 'corail', 'turquoise', 'cobalt']) add('pantalons', `Pantalon ${NM[k]}`, { pants: C[k] }, C[k]);
// ---- 20 jeans ----
const BLUES = [['brut', 0x1f2f4f], ['délavé', 0x5a7aa8], ['clair', 0x8aa8c8], ['indigo', 0x2a3a6a], ['bleu moyen', 0x3f5f8f], ['bleu nuit', 0x18223a], ['stone', 0x6a8ab0], ['vintage', 0x7a90a8], ['bleu glacier', 0xa8c0d8], ['bleu jean', 0x34508a]];
for (const [n, c] of BLUES) add('jeans', `Jean ${n}`, { pants: c }, c);
for (const [n, c] of [['noir', 0x16181c], ['gris', 0x5a5e66], ['blanc', 0xe8e8e4], ['beige', 0xc8b898], ['marron', 0x5a3e2a]]) add('jeans', `Jean ${n}`, { pants: c }, c);
for (const [n, c] of [['brut', 0x1f2f4f], ['délavé', 0x5a7aa8], ['clair', 0x8aa8c8], ['noir', 0x16181c], ['indigo', 0x2a3a6a]]) add('jeans', `Short en jean ${n}`, { pants: c, shorts: true }, c);
// ---- 20 t-shirts ----
for (const k of ['blanc', 'noir', 'gris', 'rouge', 'jaune', 'vert', 'cobalt', 'orange', 'rose', 'turquoise', 'violet', 'kaki', 'corail', 'menthe', 'moutarde', 'bordeaux']) add('tshirts', `T-shirt ${NM[k]}`, { shirtColor: C[k] }, C[k]);
for (const k of ['blanc', 'noir', 'jaune', 'ciel']) add('tshirts', `Débardeur ${NM[k]}`, { shirtColor: C[k], sleeves: 'none' }, C[k]);
// ---- 15 vestes & blazers ----
for (const [n, c] of [['Blazer noir', C.noir], ['Blazer bleu marine', C.marine], ['Blazer gris', C.gris], ['Blazer beige', C.beige], ['Blazer bordeaux', C.bordeaux], ['Blazer vert bouteille', C.bouteille], ['Blazer crème', C.creme], ['Blazer bleu cobalt', C.cobalt],
  ['Blouson en jean', 0x3f5f8f], ['Veste en cuir marron', C.chocolat], ['Veste en cuir noire', 0x111111], ['Coupe-vent orange', C.orange], ['Coupe-vent jaune', C.jaune], ['Veste kaki (saharienne)', C.kaki], ['Gilet sans manches gris', C.anthracite]]) add('vestes', n, { jacket: c }, c);
// ---- 15 ensembles professionnels ----
for (const [n, j, sh, t] of [['Costume noir, cravate rouge', C.noir, C.blanc, C.rouge], ['Costume bleu marine, cravate bleu ciel', C.marine, C.blanc, C.ciel], ['Costume gris, cravate bordeaux', C.gris, C.blanc, C.bordeaux], ['Costume anthracite, cravate violette', C.anthracite, C.ciel, C.violet],
  ['Costume beige, cravate marron', C.beige, C.blanc, C.marron], ['Costume bleu cobalt, cravate noire', C.cobalt, C.blanc, C.noir], ['Costume bordeaux, cravate dorée', C.bordeaux, C.creme, C.dore], ['Costume vert bouteille, cravate crème', C.bouteille, C.blanc, C.creme],
  ['Costume crème, cravate verte', C.creme, C.ciel, C.vert], ['Costume chocolat, cravate orange', C.chocolat, C.creme, C.orange]]) add('pro', n, { jacket: j, pants: j, shirtColor: sh, sleeves: 'long', collar: true, tie: t, shoes: 0x1a120c }, j);
for (const [n, sh, p, t] of [['Tenue de bureau : chemise blanche & pantalon noir', C.blanc, C.noir, C.marine], ['Tenue de bureau : chemise bleu ciel & pantalon gris', C.ciel, C.gris, C.bordeaux], ['Tenue de bureau : chemise rose & pantalon marine', C.rose, C.marine, C.gris],
  ['Tenue de bureau : chemise lavande & pantalon beige', C.lavande, C.beige, C.prune], ['Tenue de bureau : chemise crème & pantalon chocolat', C.creme, C.chocolat, C.vert]]) add('pro', n, { shirtColor: sh, pants: p, sleeves: 'long', collar: true, tie: t, shoes: 0x1a120c }, sh);
// ---- 15 tenues traditionnelles béninoises ----
for (const [n, c] of [['Grand boubou en bazin blanc', C.blanc], ['Grand boubou en bazin bleu ciel', C.ciel], ['Grand boubou en bazin doré', C.dore], ['Grand boubou en bazin vert', C.vert], ['Grand boubou en bazin violet', C.violet], ['Grand boubou en bazin bordeaux', C.bordeaux]]) add('trad', n, { shirtColor: c, pants: c, robe: true, skirtColor: c, sleeves: 'long', hat: 'fila', hatColor: c }, c);
for (let i = 0; i < 5; i++) add('trad', `Ensemble en wax n°${i + 1} (chemise et pantalon)`, { pagne: i + 2, pants: [C.noir, C.marine, C.creme, C.marron, C.blanc][i], collar: true, sleeves: 'long' }, null, i + 2);
for (let i = 0; i < 4; i++) add('trad', `Pagne noué et foulard assortis n°${i + 1}`, { pagne: i, skirt: true, headwrap: true }, null, i);
// ---- 15 tenues décontractées ----
for (const [n, sh, p, extra] of [['T-shirt blanc & short kaki', C.blanc, C.kaki, { shorts: true }], ['T-shirt noir & jean délavé', C.noir, 0x5a7aa8, {}], ['Polo jaune & short bleu', C.jaune, C.marine, { shorts: true, collar: true }], ['Chemise wax & short beige', null, C.beige, { pagne: 1, shorts: true, collar: true }],
  ['T-shirt rouge & short noir', C.rouge, C.noir, { shorts: true }], ['Débardeur vert & short gris', C.vert, C.gris, { shorts: true, sleeves: 'none' }], ['T-shirt turquoise & pantalon blanc', C.turquoise, C.blanc, {}], ['Polo rose & jean clair', C.rose, 0x8aa8c8, { collar: true }],
  ['T-shirt orange & bermuda olive', C.orange, C.olive, { shorts: true }], ['Chemise lin crème & pantalon sable', C.creme, C.sable, { collar: true, sleeves: 'long' }], ['T-shirt corail & short marine', C.corail, C.marine, { shorts: true }], ['Sweat gris & jean brut', C.gris, 0x1f2f4f, { sleeves: 'long' }],
  ['T-shirt lavande & short blanc', C.lavande, C.blanc, { shorts: true }], ['T-shirt menthe & pantalon kaki', C.menthe, C.kaki, {}], ['Chemise ouverte & débardeur blanc', C.blanc, C.marine, { jacket: C.ciel }]]) add('deco', n, { shirtColor: sh ?? undefined, pants: p, shoes: 0xf2f2f2, sole: 0xffffff, ...extra }, sh ?? null, extra.pagne ?? null);
// ---- 15 tenues sportives ----
for (const [n, c, s] of [['Maillot vert & blanc', C.vert, C.blanc], ['Maillot jaune & vert', C.jaune, C.vert], ['Maillot rouge & blanc', C.rouge, C.blanc], ['Maillot bleu & jaune', C.cobalt, C.jaune], ['Maillot blanc & bleu', C.blanc, C.cobalt], ['Maillot noir & or', C.noir, C.dore], ['Maillot orange & noir', C.orange, C.noir], ['Maillot violet & blanc', C.violet, C.blanc]]) add('sport', `${n} (football)`, { shirtColor: c, stripe: s, pants: s === C.blanc ? C.noir : C.blanc, shorts: true, shoes: 0x1a1a1a, sole: 0xffffff }, c);
for (const [n, c, s] of [['Survêtement noir', C.noir, C.blanc], ['Survêtement bleu marine', C.marine, C.rouge], ['Survêtement gris', C.gris, C.noir], ['Survêtement rouge', C.rouge, C.blanc], ['Survêtement vert', C.vert, C.jaune]]) add('sport', n, { shirtColor: c, pants: c, sleeves: 'long', stripe: s, shoes: 0xf2f2f2, sole: 0xffffff }, c);
add('sport', 'Tenue de course (débardeur & short)', { shirtColor: C.jaune, sleeves: 'none', pants: C.noir, shorts: true, shoes: C.orange, sole: 0xffffff }, C.jaune);
add('sport', 'Tenue de basket', { shirtColor: C.rouge, sleeves: 'none', stripe: C.blanc, pants: C.rouge, shorts: true, shoes: 0xffffff, sole: 0xffffff }, C.rouge);
// ---- 10 chaussures ----
for (const [n, c, s] of [['Baskets blanches', 0xf2f2f2, 0xffffff], ['Baskets noires', 0x1a1a1a, 0xf2f2f2], ['Baskets rouges', C.rouge, 0xffffff], ['Chaussures de ville noires', 0x111111, null], ['Chaussures de ville marron', 0x5a3a22, null], ['Mocassins bordeaux', C.bordeaux, null], ['Sandales en cuir', 0x8a5a32, null], ['Tongs bleues', C.cobalt, null], ['Babouches beiges', C.beige, null], ['Bottines camel', 0xa8743a, 0x2a1a10]]) add('chaussures', n, { shoes: c, sole: s ?? undefined }, c);
// ---- 10 accessoires ----
for (const [n, o, c] of [['Casquette noire', { hat: 'cap', hatColor: 0x1a1a1a }, 0x1a1a1a], ['Casquette rouge', { hat: 'cap', hatColor: C.rouge }, C.rouge], ['Chapeau de paille', { hat: 'straw', hatColor: 0xd8b878 }, 0xd8b878], ['Bonnet traditionnel (fila) brodé', { hat: 'fila', hatColor: C.dore }, C.dore],
  ['Lunettes de soleil', { glasses: 0x111111 }, 0x111111], ['Lunettes de vue dorées', { glasses: C.dore }, C.dore], ['Montre dorée', { watch: C.dore }, C.dore], ['Montre argentée', { watch: C.argent }, C.argent], ['Collier de perles', { necklace: 0xc8302a }, 0xc8302a], ['Sac à dos', { bag: C.anthracite }, C.anthracite]]) add('acc', n, o, c);
// ---- 10 tenues spéciales ----
add('spec', 'Tenue de mariage (boubou doré brodé)', { shirtColor: C.dore, pants: C.dore, robe: true, skirtColor: C.dore, sleeves: 'long', hat: 'fila', hatColor: C.blanc, necklace: C.blanc }, C.dore);
add('spec', 'Smoking de soirée', { jacket: 0x0c0c0e, pants: 0x0c0c0e, shirtColor: C.blanc, sleeves: 'long', collar: true, tie: 0x0c0c0e, shoes: 0x0c0c0e }, 0x0c0c0e);
add('spec', 'Blouse blanche (médecin)', { jacket: C.blanc, shirtColor: C.ciel, pants: C.marine, sleeves: 'long', collar: true }, C.blanc);
add('spec', 'Tenue de chef cuisinier', { shirtColor: C.blanc, pants: C.noir, sleeves: 'long', collar: true, hat: 'toque', hatColor: C.blanc }, C.blanc);
add('spec', 'Uniforme de pilote', { jacket: C.marine, pants: C.marine, shirtColor: C.blanc, sleeves: 'long', collar: true, tie: C.noir, hat: 'cap', hatColor: C.marine, shoes: 0x0c0c0e }, C.marine);
add('spec', 'Gilet de sécurité (chantier)', { jacket: C.orange, stripe: 0xf2f2a0, shirtColor: C.gris, pants: C.marine, hat: 'cap', hatColor: C.jaune }, C.orange);
add('spec', 'Combinaison de mécanicien', { shirtColor: C.cobalt, pants: C.cobalt, sleeves: 'long', collar: true }, C.cobalt);
add('spec', 'Tenue de plage', { shirtColor: C.turquoise, sleeves: 'none', pants: C.corail, shorts: true, shoes: C.cobalt, hat: 'straw', hatColor: 0xd8b878, glasses: 0x111111 }, C.turquoise);
add('spec', 'Tenue de fête en wax doré', { pagne: 6, pants: C.noir, collar: true, sleeves: 'long', necklace: C.dore, watch: C.dore }, null, 6);
add('spec', 'Tenue de randonnée', { shirtColor: C.olive, sleeves: 'long', pants: C.kaki, bag: C.brique, hat: 'straw', hatColor: C.kaki, shoes: 0x5a3a22 }, C.olive);

// ---- collection de luxe (mission 017) : pièces à acheter avec le compte personnel (monnaie fictive du jeu) ----
const LUXE = [
  ['Costume sur mesure bleu nuit', { jacket: 0x141c34, pants: 0x141c34, shirtColor: 0xffffff, sleeves: 'long', collar: true, tie: 0x8a1a2a, shoes: 0x0c0c0e, watch: 0xd8a830 }, 0x141c34, 'tenue', 2500000],
  ['Costume trois-pièces anthracite', { jacket: 0x2e3034, pants: 0x2e3034, shirtColor: 0xdcefff, sleeves: 'long', collar: true, tie: 0x1f4e9c, shoes: 0x0c0c0e }, 0x2e3034, 'tenue', 3200000],
  ['Smoking blanc de gala', { jacket: 0xf6f4ee, pants: 0x0c0c0e, shirtColor: 0xffffff, sleeves: 'long', collar: true, tie: 0x0c0c0e, shoes: 0x0c0c0e }, 0xf6f4ee, 'tenue', 4500000],
  ['Grand boubou de gala brodé or', { shirtColor: 0xf8f2e0, pants: 0xf8f2e0, robe: true, skirtColor: 0xf8f2e0, sleeves: 'long', hat: 'fila', hatColor: 0xd8a830, necklace: 0xd8a830 }, 0xf8f2e0, 'tenue', 3800000],
  ['Tenue de soirée wax et velours', { pagne: 7, jacket: 0x2a0a2a, pants: 0x0c0c0e, sleeves: 'long', collar: true, shoes: 0x0c0c0e }, null, 'tenue', 2800000, 7],
  ['Souliers vernis noirs', { shoes: 0x050505, sole: 0x2a1a10 }, 0x050505, 'pieds', 650000],
  ['Mocassins en cuir fin cognac', { shoes: 0x8a4a1a }, 0x8a4a1a, 'pieds', 480000],
  ['Montre en or massif', { watch: 0xe8b830 }, 0xe8b830, 'acc', 12000000],
  ['Montre en platine', { watch: 0xe4e8ec }, 0xe4e8ec, 'acc', 18000000],
  ['Lunettes de créateur', { glasses: 0x3a2a10 }, 0x3a2a10, 'acc', 750000],
  ['Collier en or', { necklace: 0xe8b830 }, 0xe8b830, 'acc', 5500000],
  ['Chapeau panama', { hat: 'straw', hatColor: 0xf2ead8 }, 0xf2ead8, 'acc', 350000],
];
for (const [n, o, sw, slot, price, pat] of LUXE) add('luxe', n, o, sw, pat ?? null, slot, price);
export const CLOTHES = L;
export const CLOTH_BY_ID = Object.fromEntries(L.map((c) => [c.id, c]));
export const PAGNE_CSS = ['#f2b400', '#1f4e9c', '#7a1f5c', '#0b6e4f', '#e46a1f', '#ffffff', '#c8302a', '#d8a830'];

// combine les pièces portées en options du personnage
export function composeOutfit(cur, female) {
  const get = (id) => (id && CLOTH_BY_ID[id] ? CLOTH_BY_ID[id].o : null);
  let o = female ? { female: true, skirt: false, headwrap: false } : {};
  const tenue = get(cur.tenue);
  if (tenue) o = { ...o, ...tenue };
  else {
    o = { ...o, shirtColor: 0xf2f2f2, pants: 0x2b3442 };
    const h = get(cur.haut), b = get(cur.bas), v = get(cur.veste);
    if (h) { o = { ...o, ...h }; if (h.pagne !== undefined && h.shirtColor === undefined) delete o.shirtColor; }
    if (b) o = { ...o, ...b };
    if (v) o = { ...o, ...v };
  }
  if (o.pagne !== undefined && tenue && tenue.shirtColor === undefined) delete o.shirtColor;
  const p = get(cur.pieds); if (p) { o.shoes = p.shoes; if (p.sole !== undefined) o.sole = p.sole; else delete o.sole; }
  for (const a of cur.acc || []) { const ao = get(a); if (ao) o = { ...o, ...ao }; }
  if (o.hat && female) o.headwrap = false;
  return o;
}
