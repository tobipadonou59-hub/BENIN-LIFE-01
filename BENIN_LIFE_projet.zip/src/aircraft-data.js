// Mission 012 — étape 2 : les 8 avions (noms fictifs, proportions réelles approximatives, en mètres).
// Vitesses en m/s (pilotage arcade) : vRot = rotation au décollage, vStall = décrochage, vMax = vitesse maximale.
export const PLANES = [
  { id: 'cesla172', name: 'Cesla 172', type: 'Petit avion privé à hélice', len: 8.3, r: 0.62, span: 11, wingY: 0.75, highWing: true, wingZ: 0.9, root: 1.6, tip: 1.2, sweep: 0, dih: 0.03,
    fin: [2.0, 1.6, 0.9, 1.0], tailSpan: 3.4, eng: [{ x: 0, y: 0.05, z: 4.35, prop: 2, pr: 0.95, nose: true }], centerY: 1.05, wheelR: 0.28, fixedGear: true,
    vRot: 28, vStall: 21, vMax: 68, acc: 3.6, pitch: 0.75, roll: 1.6, turn: 1.25, seats: 4, engines: '1 moteur à pistons', sound: 'prop' },
  { id: 'atlantis72', name: 'Atlantis 72', type: 'Avion régional à turbopropulseurs', len: 27.2, r: 1.4, span: 27, wingY: 1.3, highWing: true, wingZ: 2.5, root: 2.6, tip: 1.6, sweep: 0.3, dih: 0.02,
    fin: [5.5, 4.6, 3.0, 2.8], tailSpan: 7.6, tTail: true, eng: [{ x: 4.1, y: 1.0, z: 4.1, nac: [0.62, 4.2], prop: 6, pr: 1.95 }, { x: -4.1, y: 1.0, z: 4.1, nac: [0.62, 4.2], prop: 6, pr: 1.95 }], centerY: 2.0, wheelR: 0.42,
    vRot: 52, vStall: 42, vMax: 145, acc: 3.2, pitch: 0.5, roll: 1.0, turn: 1.0, seats: 72, engines: '2 turbopropulseurs', sound: 'prop' },
  { id: 'gulfwing', name: 'Gulfwing G65', type: 'Jet privé long-courrier', len: 30.4, r: 1.3, span: 30.4, wingY: -0.7, wingZ: 2.0, root: 4.6, tip: 1.3, sweep: 4.6, dih: 0.06,
    fin: [5.0, 5.0, 3.0, 3.2], tailSpan: 9.6, tTail: true, eng: [{ x: 2.05, y: 0.75, z: -8.5, nac: [0.78, 4.6] }, { x: -2.05, y: 0.75, z: -8.5, nac: [0.78, 4.6] }], centerY: 2.0, wheelR: 0.4,
    vRot: 60, vStall: 47, vMax: 262, acc: 4.6, pitch: 0.6, roll: 1.4, turn: 1.15, seats: 18, engines: '2 réacteurs arrière', sound: 'jet' },
  { id: 'faucon8x', name: 'Faucon 8X', type: 'Jet d’affaires triréacteur', len: 24.5, r: 1.2, span: 26.3, wingY: -0.6, wingZ: 1.6, root: 4.0, tip: 1.2, sweep: 4.0, dih: 0.06,
    fin: [4.6, 4.6, 2.6, 3.0], tailSpan: 8.2, eng: [{ x: 1.9, y: 0.55, z: -6.8, nac: [0.7, 3.8] }, { x: -1.9, y: 0.55, z: -6.8, nac: [0.7, 3.8] }, { x: 0, y: 1.55, z: -8.6, nac: [0.66, 3.4] }], centerY: 1.8, wheelR: 0.38,
    vRot: 56, vStall: 45, vMax: 252, acc: 4.3, pitch: 0.6, roll: 1.4, turn: 1.15, seats: 16, engines: '3 réacteurs arrière', sound: 'jet' },
  { id: 'skyliner737', name: 'Skyliner 737', type: 'Avion de ligne moyen-courrier', len: 39.5, r: 1.9, span: 35.8, wingY: -1.1, wingZ: 3.4, root: 7.0, tip: 1.6, sweep: 7.0, dih: 0.1,
    fin: [7.2, 7.0, 2.6, 5.2], tailSpan: 14.4, eng: [{ x: 5.0, y: -2.1, z: 5.6, nac: [1.0, 4.6] }, { x: -5.0, y: -2.1, z: 5.6, nac: [1.0, 4.6] }], centerY: 3.6, wheelR: 0.55,
    vRot: 70, vStall: 57, vMax: 245, acc: 3.5, pitch: 0.45, roll: 0.9, turn: 0.95, seats: 189, engines: '2 réacteurs sous les ailes', sound: 'jet' },
  { id: 'aeria320', name: 'Aeria A320', type: 'Avion de ligne moyen-courrier', len: 37.6, r: 1.98, span: 35.8, wingY: -1.15, wingZ: 3.0, root: 7.0, tip: 1.5, sweep: 6.6, dih: 0.1, sharklet: true,
    fin: [6.6, 7.2, 2.8, 5.4], tailSpan: 12.5, eng: [{ x: 5.75, y: -2.15, z: 5.4, nac: [1.1, 4.4] }, { x: -5.75, y: -2.15, z: 5.4, nac: [1.1, 4.4] }], centerY: 3.7, wheelR: 0.55,
    vRot: 70, vStall: 56, vMax: 245, acc: 3.5, pitch: 0.45, roll: 0.9, turn: 0.95, seats: 180, engines: '2 réacteurs sous les ailes', sound: 'jet' },
  { id: 'jumbo747', name: 'Jumbo 747', type: 'Gros-porteur quadriréacteur', len: 70.7, r: 3.25, span: 64.4, wingY: -1.9, wingZ: 6.0, root: 14, tip: 4, sweep: 14, dih: 0.1, hump: true,
    fin: [12.5, 12.5, 4.2, 9.0], tailSpan: 22, eng: [{ x: 12, y: -3.1, z: 8.0, nac: [1.4, 7] }, { x: -12, y: -3.1, z: 8.0, nac: [1.4, 7] }, { x: 21.5, y: -2.6, z: 0.5, nac: [1.4, 7] }, { x: -21.5, y: -2.6, z: 0.5, nac: [1.4, 7] }], centerY: 6.2, wheelR: 0.65,
    vRot: 82, vStall: 66, vMax: 255, acc: 3.1, pitch: 0.32, roll: 0.6, turn: 0.75, seats: 416, engines: '4 réacteurs sous les ailes', sound: 'jet' },
  { id: 'aeria380', name: 'Aeria Super A380', type: 'Très gros-porteur à double pont', len: 72.7, r: 3.6, sy: 1.32, span: 79.8, wingY: -2.6, wingZ: 6.5, root: 17, tip: 4.2, sweep: 15, dih: 0.09, fence: true,
    fin: [14.2, 14.5, 5.0, 10], tailSpan: 30, eng: [{ x: 15.5, y: -3.9, z: 9.5, nac: [1.6, 7.2] }, { x: -15.5, y: -3.9, z: 9.5, nac: [1.6, 7.2] }, { x: 26.5, y: -3.4, z: 1.5, nac: [1.6, 7.2] }, { x: -26.5, y: -3.4, z: 1.5, nac: [1.6, 7.2] }], centerY: 7.2, wheelR: 0.7,
    vRot: 80, vStall: 64, vMax: 250, acc: 3.1, pitch: 0.3, roll: 0.55, turn: 0.7, seats: 575, engines: '4 réacteurs sous les ailes', sound: 'jet' },
];
export const PLANE_BY_ID = Object.fromEntries(PLANES.map((p) => [p.id, p]));
