// Mission 014, étape 5 — vie quotidienne du PDG : clients et partenaires fictifs reçus en personne à l'accueil de
// NOVA BOOK, événements professionnels avec décisions (effets réels sur la production, les prix, le moral, la
// trésorerie et la réputation), objectifs de développement récompensés. Montants : monnaie virtuelle du jeu.
import { createCharacter, SKINS } from './character.js';
import { SERVICES, CLIENTS } from './company.js';
import { JOBS } from './nova-data.js';
import { fcfa } from './food-data.js';

const pick = (a) => a[Math.floor(Math.random() * a.length)];
const r5 = (n) => Math.round(n / 5000) * 5000;
const VISITORS = [['M. Agossa', false], ['Mme Dossou', true], ['M. Houngbédji', false], ['Mme Ahouansou', true], ['M. Kpadonou', false], ['Mme Tossou', true], ['M. Adékambi', false], ['Mme Sossa', true]];
const PARTNERS = [
  { id: 'librairie', who: 'Librairie Les Pages du Golfe (fictive)', ask: 'propose de distribuer vos livres dans ses rayons', cost: 250000, effect: '2 nouvelles demandes de clients et réputation +3' },
  { id: 'papier', who: 'Papeterie Atlantique (fournisseur fictif)', ask: 'propose un contrat d’approvisionnement en papier de qualité', cost: 400000, effect: 'production de l’impression +20 % pendant 7 jours' },
  { id: 'agence', who: 'Agence Horizon Communication (fictive)', ask: 'propose une campagne de promotion de NOVA BOOK', cost: 300000, effect: 'prix des nouvelles commandes +10 % pendant 7 jours' },
];
// événements professionnels : [libellé, description, options [texte, coût, effet]]
const EVENTS = {
  panne: { t: '⚙️ Une presse tombe en panne', d: 'Une des presses de l’atelier d’impression (4e étage) est à l’arrêt.', o: [['Réparer tout de suite', 250000, 'repair'], ['Attendre le technicien (impression −50 % pendant 2 jours)', 0, 'mod:Impression:0.5:2']] },
  coupure: { t: '⚡ Coupure d’électricité dans le quartier', d: 'Le courant est coupé pour la journée.', o: [['Louer un groupe électrogène', 100000, 'none'], ['Travailler au ralenti (production −30 % aujourd’hui)', 0, 'mod:*:0.7:1']] },
  salon: { t: '📚 Salon du livre de Cotonou (événement fictif)', d: 'Les organisateurs proposent un stand à NOVA BOOK.', o: [['Participer avec un stand', 400000, 'rep:8|offers:2'], ['Ne pas participer', 0, 'none']] },
  augmentation: { t: '💬 Demande d’augmentation', d: '{emp} demande une augmentation de salaire.', o: [['Accepter (+10 % de salaire, moral +15)', 0, 'raise'], ['Refuser (moral −12)', 0, 'refuse']] },
  urgente: { t: '⏱️ Commande urgente', d: '{client} a besoin de supports imprimés en 2 jours et paie 40 % de plus.', o: [['Accepter la commande urgente', 0, 'urgent'], ['Refuser (réputation −1)', 0, 'rep:-1']] },
  presse: { t: '📰 Article élogieux dans un journal (fictif)', d: 'Un journaliste a apprécié les derniers livres de NOVA BOOK.', o: [['Merci ! (réputation +5)', 0, 'rep:5']] },
  papier: { t: '📦 Pénurie de papier', d: 'Les fournisseurs manquent de papier cette semaine.', o: [['Acheter du stock au prix fort', 200000, 'none'], ['Attendre (impression et édition −20 % pendant 3 jours)', 0, 'mod:Impression:0.8:3|mod:Édition:0.8:3']] },
  formation: { t: '🎓 Offre de formation groupée', d: 'Un centre de formation (fictif) propose une session pour 3 employés.', o: [['Inscrire 3 employés (compétence +5)', 300000, 'train3'], ['Refuser', 0, 'none']] },
  candidat: { t: '🌟 Candidature spontanée remarquable', d: 'Un(e) {job} très expérimenté(e) souhaite rejoindre NOVA BOOK.', o: [['Ajouter aux candidats (onglet Recrutement)', 0, 'cand'], ['Ne pas donner suite', 0, 'none']] },
  mecontent: { t: '😟 Client mécontent', d: '{client} se plaint d’un retard de livraison.', o: [['Geste commercial (réputation +2)', 100000, 'rep:2'], ['Ignorer (réputation −5)', 0, 'rep:-5']] },
};
export const OBJECTIVES = [
  ['livraisons', 'Livrer 5 commandes de clients', 500000], ['visites', 'Recevoir 3 clients ou partenaires en personne', 300000], ['tresor', 'Atteindre 15 000 000 FCFA de trésorerie (NOVA BOOK)', 1000000],
  ['effectif', 'Employer 35 personnes chez NOVA BOOK', 500000], ['equip', 'Équiper un département au niveau 3', 800000], ['filiale', 'Créer ou racheter une 2e société du groupe', 1000000],
  ['projet', 'Livrer un projet personnel du PDG', 500000], ['reputation', 'Atteindre une réputation de 75', 1000000], ['ca', 'Réaliser 8 000 000 FCFA de chiffre d’affaires dans un mois', 1500000], ['groupe', 'Posséder les 6 sociétés du groupe NOVA', 3000000],
];

export class CeoLife {
  constructor(ctx) {
    Object.assign(this, ctx); // company, group, projects, nova, phonePlus, economy, env, ui, audio, onSave
    this.rep = 50; this.mods = []; this.events = []; this.visit = null; this.visitAt = null; this.counters = { visits: 0, events: 0 }; this.claimed = {}; this.uid = 1;
    this.dom = document.querySelector('#visit');
    this.dom.addEventListener('click', (e) => this.onClick(e));
    this.company.life = this;
  }
  // ---- effets sur l'entreprise ----
  factor(dept) { let k = 1; for (const m of this.mods) if (m.kind === 'prod' && (m.dept === '*' || m.dept === dept)) k *= m.k; return k; }
  priceK() { let k = 0.9 + this.rep / 500; for (const m of this.mods) if (m.kind === 'price') k *= m.k; return k; }
  addMod(kind, dept, k, days, label) { this.mods.push({ kind, dept, k, until: this.company.day + days, label }); }
  repAdd(n) { this.rep = Math.max(0, Math.min(100, this.rep + n)); }
  // ---- chaque nouveau jour (appelé par company.newDay) ----
  newDay() {
    const C = this.company, d = C.day;
    this.mods = this.mods.filter((m) => m.until > d);
    for (const ev of this.events.filter((q) => d - q.day >= 2)) this.resolve(ev.id, ev.def.o.length - 1, true); // décision par défaut après 2 jours
    if (this.events.length < 3 && Math.random() < 0.6) this.newEvent();
    this.visitAt = Math.random() < 0.7 ? 9 + Math.random() * 7 : null;
  }
  newEvent(type) {
    const C = this.company, k = type || pick(Object.keys(EVENTS)), def = EVENTS[k];
    const emp = pick(C.staff), client = pick(CLIENTS), job = pick(['graphiste', 'maquettiste', 'developpeur', 'monteur', 'imprimeur', 'correcteur']);
    const ev = { id: this.uid++, k, day: C.day, emp: emp ? emp.id : null, empName: emp ? emp.name : '', client, job, def: null };
    ev.def = { t: def.t, d: def.d.replace('{emp}', ev.empName).replace('{client}', client).replace('{job}', JOBS[job].label.toLowerCase()), o: def.o };
    this.events.push(ev);
    this.economy.notify(`📌 Décision à prendre : ${def.t.replace(/^\S+ /, '')} — ordinateur du PDG, onglet « Objectifs & événements »`);
    this.onSave && this.onSave(); return ev;
  }
  resolve(id, i, auto = false) {
    const ev = this.events.find((q) => q.id === id); if (!ev) return;
    const [label, cost, eff] = ev.def.o[i] || ev.def.o[ev.def.o.length - 1], C = this.company;
    if (cost && C.cash < cost) { if (!auto) return this.ui.toast(`Trésorerie de NOVA BOOK insuffisante (${fcfa(cost)}).`, 2.2); return this.resolve(id, ev.def.o.length - 1, true); }
    if (cost) C.post(`${ev.def.t.replace(/^\S+ /, '')} — ${label}`, -cost, 'frais');
    for (const part of eff.split('|')) {
      const [a, b, c2, d2] = part.split(':');
      if (a === 'mod') this.addMod('prod', b, +c2, +d2, `${ev.def.t.replace(/^\S+ /, '')}`);
      if (a === 'rep') this.repAdd(+b);
      if (a === 'offers') { for (let n = 0; n < +b; n++) { C.offers.push(this.offer(1)); } }
      if (a === 'raise') { const e = C.staff.find((q) => q.id === ev.emp); if (e) { e.salary = r5(e.salary * 1.1); e.morale = Math.min(100, e.morale + 15); } }
      if (a === 'refuse') { const e = C.staff.find((q) => q.id === ev.emp); if (e) e.morale = Math.max(10, e.morale - 12); }
      if (a === 'urgent') { const o = { ...this.offer(1.4), days: 2, client: ev.client }; if (C.orders.filter((q) => q.dept === o.dept).length < C.capacity(o.dept)) { C.orders.push({ ...o, done: 0, left: 2, status: 'en cours' }); C.note(`📄 Commande urgente signée : ${o.label} pour ${o.client} — ${fcfa(o.price)}`); } else { C.offers.unshift(o); C.note(`📄 Commande urgente ajoutée aux demandes (département ${o.dept} complet)`); } }
      if (a === 'train3') { const list = [...C.staff].sort(() => Math.random() - 0.5).slice(0, 3); for (const e of list) e.skill = Math.min(100, e.skill + 5); C.note(`🎓 Formation : ${list.map((e) => e.name).join(', ')} (compétence +5)`); }
      if (a === 'cand') { const e = C.makeEmployee(`${pick(['Fortuné', 'Prudence', 'Elvire', 'Rodolphe', 'Gisèle', 'Anicet'])} ${pick(['Agbo', 'Houessou', 'Djossou', 'Kiki', 'Sagbo'])}`, ev.job, undefined, null, 88, 10); e.id = 0; e.cid = Math.random().toString(36).slice(2, 8); C.candidates.unshift(e); }
    }
    this.events = this.events.filter((q) => q !== ev); this.counters.events++;
    C.note(`${auto ? '⏳ Sans réponse, décision par défaut' : '✅ Décision prise'} : ${ev.def.t.replace(/^\S+ /, '')} → ${label}`);
    this.onSave && this.onSave(); this.refreshUI();
  }
  offer(k) { const C = this.company, s = pick(SERVICES); return { oid: Math.random().toString(36).slice(2, 8), sid: s.id, label: s.label, dept: s.dept, client: pick(CLIENTS), price: r5(s.price * k * this.priceK()), work: s.work, days: s.days }; }
  // ---- visites à l'accueil de NOVA BOOK ----
  update() {
    const h = this.env.time;
    if (this.visitAt && h >= this.visitAt && h < 17 && !this.visit) { this.visitAt = null; this.startVisit(); }
    if (this.visit && (h >= 18 || h < 7 || this.company.day > this.visit.day)) this.endVisit(true);
    if (this.visit && !this.visit.char && this.nova.floors && this.nova.floors[0]) this.spawnVisitor();
  }
  startVisit(kind) {
    const C = this.company, partner = kind ? kind === 'partner' : Math.random() < 0.35, [name, female] = pick(VISITORS);
    const v = { day: C.day, name, female, partner, char: null };
    if (partner) v.p = pick(PARTNERS); else { const o = this.offer(1.15); v.order = o; v.org = o.client; }
    v.org = partner ? v.p.who : v.order.client;
    this.visit = v; this.spawnVisitor();
    const sec = C.staff.find((e) => e.job === 'secretaire' && e.lv === 0);
    const msg = `${name} (${v.org}) vous attend à l’accueil de NOVA BOOK.`;
    if (this.phonePlus && sec) this.phonePlus.receive(`e:book:${sec.id}`, `Bonjour PDG, ${msg}`); else this.economy.notify(`🤝 ${msg}`);
    this.onSave && this.onSave();
  }
  spawnVisitor() {
    const v = this.visit, f = this.nova.floors && this.nova.floors[0]; if (!v || !f || v.char) return;
    const c = createCharacter({ female: v.female, skin: pick(SKINS), shirtColor: v.partner ? 0x22283a : 0x6a2a3a, pants: 0x1a1a1a, sleeves: 'long', collar: true, jacket: v.partner ? 0x22283a : undefined, bag: v.partner ? undefined : 0x3a2a1a });
    c.group.position.set(50.2, 0, 21.5); c.group.rotation.y = Math.PI / 2; f.group.add(c.group); v.char = c;
    v.col = this.world.collision.addCircle(50.2, 21.5, 0.35, 1.8); v.col.lv = 0;
    v.pt = { lv: 0, x: 50.2, z: 21.5, r: 1.9, label: `Recevoir ${v.name} (${v.partner ? 'partenaire' : 'client'} — ${v.org})`, action: () => this.openVisit() };
    this.nova.points.push(v.pt);
  }
  endVisit(missed) {
    const v = this.visit; if (!v) return;
    if (v.char) { v.char.group.parent && v.char.group.parent.remove(v.char.group); v.char.mesh.geometry.dispose(); }
    if (v.col) v.col.disabled = true;
    this.nova.points = this.nova.points.filter((p) => p !== v.pt);
    if (missed) { this.repAdd(-2); this.company.note(`🚪 ${v.name} (${v.org}) est reparti(e) sans être reçu(e) : réputation −2`); }
    this.visit = null; this.toggle(false); this.onSave && this.onSave();
  }
  openVisit() { if (!this.visit) return; this.open = true; this.dom.classList.add('show'); this.render(); }
  toggle(on) { this.open = on; this.dom.classList.toggle('show', on); if (on) this.render(); }
  visitAction(a) {
    const v = this.visit, C = this.company; if (!v) return;
    if (a === 'sign' || a === 'nego') {
      const o = { ...v.order };
      if (C.orders.filter((q) => q.dept === o.dept).length >= C.capacity(o.dept)) return this.ui.toast(`Le département ${o.dept} est complet : recrute ou attends la fin d’une commande.`, 2.6);
      if (a === 'nego') { if (Math.random() < 0.6) { o.price = r5(o.price * 1.1); this.ui.toast(`${v.name} accepte : +10 % (${fcfa(o.price)})`, 2.5); } else { this.repAdd(-1); this.ui.toast(`${v.name} refuse la hausse et préfère réfléchir. Réputation −1`, 2.8); this.counters.visits++; return this.endVisit(false); } }
      C.orders.push({ ...o, done: 0, left: o.days, status: 'en cours' }); C.note(`🤝 Contrat signé en personne avec ${v.org} : ${o.label} — ${fcfa(o.price)}`); this.repAdd(2);
    } else if (a === 'partner') {
      const P = v.p; if (C.cash < P.cost) return this.ui.toast(`Trésorerie de NOVA BOOK insuffisante (${fcfa(P.cost)}).`, 2.4);
      C.post(`Partenariat : ${P.who}`, -P.cost, 'invest');
      if (P.id === 'librairie') { C.offers.push(this.offer(1), this.offer(1)); this.repAdd(3); }
      if (P.id === 'papier') this.addMod('prod', 'Impression', 1.2, 7, 'Partenariat papier');
      if (P.id === 'agence') this.addMod('price', '*', 1.1, 7, 'Campagne de communication');
      C.note(`🤝 Partenariat conclu avec ${P.who} : ${P.effect}`); this.repAdd(1);
    } else if (a === 'decline') { C.note(`🙏 Vous avez reçu ${v.name} (${v.org}) et décliné poliment.`); }
    this.counters.visits++; this.endVisit(false);
  }
  render() {
    const v = this.visit; if (!this.open || !v) return;
    const C = this.company;
    let body;
    if (v.partner) body = `<p class="ve-note">« Bonjour PDG. ${v.p.who} ${v.p.ask}. »</p><div class="ve-row"><span><b>Proposition</b><small>Coût ${fcfa(v.p.cost)} (trésorerie NOVA BOOK : ${fcfa(C.cash)}) • effet : ${v.p.effect}</small></span></div>
      <div class="ve-confirm"><button class="ve-go" data-vs="partner" ${C.cash >= v.p.cost ? '' : 'disabled'}>Conclure le partenariat</button><button class="alt" data-vs="decline">Décliner poliment</button></div>`;
    else { const o = v.order, full = C.orders.filter((q) => q.dept === o.dept).length >= C.capacity(o.dept);
      body = `<p class="ve-note">« Bonjour PDG. Nous souhaitons confier à NOVA BOOK : ${o.label.toLowerCase()}. »</p><div class="ve-row"><span><b>${o.label}</b><small>Département ${o.dept} • délai ${o.days} jour(s) • ${full ? '⚠️ département complet' : 'capacité disponible'}</small></span><em>${fcfa(o.price)}</em></div>
      <div class="ve-confirm"><button class="ve-go" data-vs="sign" ${full ? 'disabled' : ''}>Signer le contrat</button><button data-vs="nego" ${full ? 'disabled' : ''}>Négocier +10 %</button><button class="alt" data-vs="decline">Refuser poliment</button></div>
      <p class="ve-note">Négocier : 60 % de chances d’obtenir +10 %, sinon le client repart (réputation −1). Recevoir les clients en personne améliore la réputation.</p>`; }
    this.dom.innerHTML = `<div class="ve-box"><div class="ve-head" style="--c:${v.partner ? '#1f4e9c' : '#0b6e4f'}"><span class="ve-ic">${v.female ? '👩🏿‍💼' : '👨🏿‍💼'}</span><div><h2>${v.name}</h2><small>${v.partner ? 'Partenaire' : 'Client'} • ${v.org} • rendez-vous à l’accueil de NOVA BOOK</small></div><span class="ve-bal">⭐ Réputation ${Math.round(this.rep)}</span><button data-vs="x">✕</button></div>${body}</div>`;
  }
  onClick(e) { const b = e.target.closest('[data-vs]'); if (!b) { if (e.target === this.dom) this.toggle(false); return; } e.stopPropagation(); const a = b.dataset.vs; if (a === 'x') return this.toggle(false); this.visitAction(a); }
  handleKeys(input) { if (input.hit('Escape')) this.toggle(false); }
  // ---- objectifs de développement ----
  progress(id) {
    const C = this.company, G = this.group, subs = G ? Object.keys(G.subs).length : 0;
    const ca = Math.max(C.cur().ca, ...(C.months || []).map((m) => m.ca || 0));
    return { livraisons: [C.done.length, 5], visites: [this.counters.visits, 3], tresor: [C.cash, 15000000], effectif: [C.staff.length, 35], equip: [Math.max(...Object.values(C.equip)), 3], filiale: [subs, 1],
      projet: [this.projects ? this.projects.list.filter((p) => p.state === 'livré').length : 0, 1], reputation: [Math.round(this.rep), 75], ca: [ca, 8000000], groupe: [subs + 1, 6] }[id];
  }
  claim(id) {
    const ob = OBJECTIVES.find((q) => q[0] === id); if (!ob || this.claimed[id]) return;
    const [v, t] = this.progress(id); if (v < t) return;
    this.claimed[id] = this.company.stamp(); this.company.post(`Objectif atteint : ${ob[1]}`, ob[2], 'capital'); this.repAdd(3);
    this.company.note(`🏆 Objectif atteint : ${ob[1]} → prime de ${fcfa(ob[2])} versée à NOVA BOOK, réputation +3`); this.onSave && this.onSave();
  }
  refreshUI() { if (this.bizUI && this.bizUI.open) this.bizUI.render(); }
  view() {
    const C = this.company, fmtK = (k) => `${k > 1 ? '+' : '−'}${Math.round(Math.abs(k - 1) * 100)} %`;
    const ev = this.events.map((e) => `<div class="bz-row"><span><b>${e.def.t}</b><small>${e.def.d} • reçu ${C.day - e.day === 0 ? 'aujourd’hui' : `il y a ${C.day - e.day} jour(s)`} (décision par défaut après 2 jours)</small></span><span class="bz-btns">${e.def.o.map((o, i) => `<button data-a="evt:${e.id}|${i}">${o[0]}${o[1] ? ` (${fcfa(o[1])})` : ''}</button>`).join('')}</span></div>`).join('') || '<p class="bz-note">Aucune décision en attente. De nouveaux événements arrivent au fil des jours.</p>';
    const mods = this.mods.map((m) => `<div class="bz-row"><span><b>${m.label}</b><small>${m.kind === 'price' ? 'prix des commandes' : m.dept === '*' ? 'production de tous les départements' : `production ${m.dept}`} ${fmtK(m.k)} • jusqu’au jour ${m.until}</small></span></div>`).join('');
    const obj = OBJECTIVES.map(([id, label, rew]) => { const [v, t] = this.progress(id), ok = v >= t, cl = this.claimed[id]; const pct = Math.min(100, Math.round(100 * v / t));
      return `<div class="bz-row"><span><b>${cl ? '🏆' : ok ? '✅' : '🎯'} ${label}</b><span class="pj-bar"><i style="width:${pct}%"></i></span><small>${t >= 100000 ? `${fcfa(v)} / ${fcfa(t)}` : `${v} / ${t}`} • récompense ${fcfa(rew)} + réputation 3</small></span><span class="bz-btns">${cl ? `<button disabled>Reçue (${cl})</button>` : `<button data-a="obj:${id}" ${ok ? 'class="on"' : 'disabled'}>Encaisser</button>`}</span></div>`; }).join('');
    const vis = this.visit ? `<div class="bz-alert">🤝 ${this.visit.name} (${this.visit.org}) vous attend à l’accueil de NOVA BOOK (rez-de-chaussée) jusqu’à 18 h.</div>` : '';
    return `${vis}<div class="bz-grid">${this.kpi('Réputation de NOVA BOOK', `${Math.round(this.rep)} / 100`, this.rep >= 60 ? 'pos' : this.rep < 40 ? 'neg' : '')}${this.kpi('Effet sur le prix des commandes', fmtK(this.priceK()))}${this.kpi('Clients et partenaires reçus', String(this.counters.visits))}${this.kpi('Décisions prises', String(this.counters.events))}</div>
      <h5>Décisions à prendre</h5>${ev}${mods ? `<h5>Effets en cours</h5>${mods}` : ''}<h5>Objectifs de développement</h5>${obj}`;
  }
  kpi(l, v, cls = '') { return `<div class="bz-k ${cls}"><small>${l}</small><b>${v}</b></div>`; }
  onAction(a, v) {
    if (a === 'evt') { const [id, i] = v.split('|'); this.resolve(+id, +i); return true; }
    if (a === 'obj') { this.claim(v); return true; }
    return false;
  }
  serialize() { return { rep: this.rep, mods: this.mods, events: this.events, visitAt: this.visitAt, counters: this.counters, claimed: this.claimed, uid: this.uid, visit: this.visit ? { day: this.visit.day, name: this.visit.name, female: this.visit.female, partner: this.visit.partner, p: this.visit.p, order: this.visit.order, org: this.visit.org } : null }; }
  restore(s) {
    if (!s) return;
    Object.assign(this, { rep: s.rep ?? 50, mods: s.mods || [], events: (s.events || []).filter((e) => e.def), visitAt: s.visitAt ?? null, counters: { visits: 0, events: 0, ...(s.counters || {}) }, claimed: s.claimed || {}, uid: s.uid || 1 });
    if (s.visit) this.visit = { ...s.visit, char: null };
  }
}
