// Textures 100 % procédurales (dessinées sur <canvas>) : aucun fichier image externe.
import * as THREE from 'three';
import { mulberry32 } from './util.js';

function mk(w, h) {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  return c;
}

// taille maximale des textures (réduite sur téléphone pour économiser la mémoire graphique)
let MAX_TEX = 4096;
export function setTextureBudget(px) { MAX_TEX = px; }

export function toTex(c, { repeat = true, srgb = true } = {}) {
  if (c.width > MAX_TEX || c.height > MAX_TEX) {
    const k = MAX_TEX / Math.max(c.width, c.height);
    const d = mk(Math.max(1, Math.round(c.width * k)), Math.max(1, Math.round(c.height * k)));
    d.getContext('2d').drawImage(c, 0, 0, d.width, d.height);
    c = d;
  }
  const t = new THREE.CanvasTexture(c);
  if (repeat) t.wrapS = t.wrapT = THREE.RepeatWrapping;
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = MAX_TEX < 4096 ? 2 : 8;
  t.needsUpdate = true;
  return t;
}

function speckle(ctx, w, h, colors, n, maxR, rand, alpha = 0.35) {
  for (let i = 0; i < n; i++) {
    ctx.fillStyle = colors[(rand() * colors.length) | 0];
    ctx.globalAlpha = 0.1 + rand() * alpha;
    const r = 0.6 + rand() * maxR;
    ctx.fillRect(rand() * w, rand() * h, r, r);
  }
  ctx.globalAlpha = 1;
}

function blotches(ctx, w, h, color, n, maxR, alpha, rand) {
  for (let i = 0; i < n; i++) {
    const x = rand() * w, y = rand() * h, r = maxR * (0.3 + rand() * 0.7);
    // dessine aussi les copies décalées pour que la texture reste raccordable
    for (const ox of [-w, 0, w]) for (const oy of [-h, 0, h]) {
      const g = ctx.createRadialGradient(x + ox, y + oy, 0, x + ox, y + oy, r);
      g.addColorStop(0, color);
      g.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.globalAlpha = alpha * (0.4 + rand() * 0.6);
      ctx.fillStyle = g;
      ctx.fillRect(x + ox - r, y + oy - r, r * 2, r * 2);
    }
  }
  ctx.globalAlpha = 1;
}

export function asphalt() {
  const c = mk(256, 256), x = c.getContext('2d'), R = mulberry32(11);
  x.fillStyle = '#4a4a4c'; x.fillRect(0, 0, 256, 256);
  blotches(x, 256, 256, '#2b2b2d', 10, 60, 0.35, R);
  blotches(x, 256, 256, '#6b665e', 6, 50, 0.2, R);
  speckle(x, 256, 256, ['#2a2a2c', '#66676a', '#3a3a3c', '#7a746a'], 9000, 1.8, R);
  return toTex(c);
}

export function pave() {
  // pavés autobloquants, très présents dans les rues de Cotonou
  const c = mk(256, 256), x = c.getContext('2d'), R = mulberry32(12);
  x.fillStyle = '#5c574f'; x.fillRect(0, 0, 256, 256);
  const bw = 32, bh = 16;
  for (let row = 0; row < 256 / bh; row++) {
    const off = (row % 2) * (bw / 2);
    for (let col = -1; col < 256 / bw + 1; col++) {
      const v = 120 + R() * 30;
      x.fillStyle = `rgb(${v + 8},${v + 2},${v - 6})`;
      x.fillRect(col * bw + off + 1.5, row * bh + 1.5, bw - 3, bh - 3);
    }
  }
  blotches(x, 256, 256, '#a5532c', 8, 70, 0.22, R);
  speckle(x, 256, 256, ['#3c3a36', '#9a948a'], 3000, 1.5, R);
  return toTex(c);
}

export function laterite() {
  const c = mk(256, 256), x = c.getContext('2d'), R = mulberry32(13);
  x.fillStyle = '#a4502e'; x.fillRect(0, 0, 256, 256);
  blotches(x, 256, 256, '#7a3820', 10, 70, 0.35, R);
  blotches(x, 256, 256, '#c8774a', 8, 60, 0.3, R);
  speckle(x, 256, 256, ['#6e321c', '#c97a4c', '#8e4527', '#d9a07a', '#5a2a18'], 14000, 2.2, R, 0.45);
  return toTex(c);
}

export function sidewalk() {
  const c = mk(256, 256), x = c.getContext('2d'), R = mulberry32(14);
  x.fillStyle = '#b6ad9f'; x.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) {
    const v = R() * 14 - 7;
    x.fillStyle = `rgba(${128 + v},${120 + v},${110 + v},0.18)`;
    x.fillRect(i * 64, j * 64, 64, 64);
  }
  x.strokeStyle = '#8f877b'; x.lineWidth = 2;
  for (let i = 0; i <= 4; i++) {
    x.beginPath(); x.moveTo(i * 64, 0); x.lineTo(i * 64, 256); x.stroke();
    x.beginPath(); x.moveTo(0, i * 64); x.lineTo(256, i * 64); x.stroke();
  }
  blotches(x, 256, 256, '#a4552f', 9, 60, 0.28, R);
  speckle(x, 256, 256, ['#77706a', '#d2cbc0'], 4000, 1.5, R);
  return toTex(c);
}

export function grass() {
  const c = mk(256, 256), x = c.getContext('2d'), R = mulberry32(15);
  x.fillStyle = '#58792f'; x.fillRect(0, 0, 256, 256);
  blotches(x, 256, 256, '#8c8a46', 8, 60, 0.4, R);
  blotches(x, 256, 256, '#3c5a20', 8, 50, 0.4, R);
  speckle(x, 256, 256, ['#406a22', '#7a9a3a', '#2e4e18', '#9aa858'], 14000, 2, R, 0.5);
  return toTex(c);
}

export function sand() {
  const c = mk(256, 256), x = c.getContext('2d'), R = mulberry32(16);
  x.fillStyle = '#ddc796'; x.fillRect(0, 0, 256, 256);
  blotches(x, 256, 256, '#c2a676', 10, 60, 0.35, R);
  speckle(x, 256, 256, ['#b89c6a', '#f2e2bc', '#a88c5e'], 12000, 1.5, R, 0.45);
  return toTex(c);
}

export function water() {
  // carte de normales simple pour onduler la mer
  const s = 256, c = mk(s, s), x = c.getContext('2d'), R = mulberry32(17);
  const h = new Float32Array(s * s);
  for (let k = 0; k < 40; k++) {
    const fx = (1 + Math.floor(R() * 6)) * 2 * Math.PI / s;
    const fy = (1 + Math.floor(R() * 6)) * 2 * Math.PI / s;
    const ph = R() * 6.28, a = 1 / (1 + k * 0.2);
    for (let j = 0; j < s; j++) for (let i = 0; i < s; i++) h[j * s + i] += Math.sin(i * fx + j * fy + ph) * a;
  }
  const img = x.createImageData(s, s);
  for (let j = 0; j < s; j++) for (let i = 0; i < s; i++) {
    const dx = h[j * s + ((i + 1) % s)] - h[j * s + ((i - 1 + s) % s)];
    const dy = h[((j + 1) % s) * s + i] - h[((j - 1 + s) % s) * s + i];
    const o = (j * s + i) * 4;
    img.data[o] = 128 + dx * 18; img.data[o + 1] = 128 + dy * 18; img.data[o + 2] = 255; img.data[o + 3] = 255;
  }
  x.putImageData(img, 0, 0);
  return toTex(c, { srgb: false });
}

export function roofConcrete() {
  const c = mk(256, 256), x = c.getContext('2d'), R = mulberry32(21);
  x.fillStyle = '#8b8781'; x.fillRect(0, 0, 256, 256);
  blotches(x, 256, 256, '#4d4a46', 12, 60, 0.35, R);
  speckle(x, 256, 256, ['#5e5a55', '#a9a49c'], 6000, 1.6, R);
  return toTex(c);
}

export function roofTin() {
  const c = mk(128, 128), x = c.getContext('2d'), R = mulberry32(22);
  for (let i = 0; i < 128; i += 8) {
    const g = x.createLinearGradient(i, 0, i + 8, 0);
    g.addColorStop(0, '#8e8a84'); g.addColorStop(0.5, '#c4c0b8'); g.addColorStop(1, '#77736d');
    x.fillStyle = g; x.fillRect(i, 0, 8, 128);
  }
  blotches(x, 128, 128, '#8a4a22', 10, 30, 0.6, R);
  return toTex(c);
}

export function wall(base) {
  const c = mk(256, 128), x = c.getContext('2d'), R = mulberry32(23 + base.length);
  x.fillStyle = base; x.fillRect(0, 0, 256, 128);
  blotches(x, 256, 128, 'rgba(70,60,50,1)', 6, 40, 0.15, R);
  x.strokeStyle = 'rgba(0,0,0,0.06)';
  for (let i = 0; i < 128; i += 21) { x.beginPath(); x.moveTo(0, i); x.lineTo(256, i); x.stroke(); }
  // éclaboussures de latérite au pied du mur
  const g = x.createLinearGradient(0, 80, 0, 128);
  g.addColorStop(0, 'rgba(164,80,46,0)'); g.addColorStop(1, 'rgba(150,72,40,0.75)');
  x.fillStyle = g; x.fillRect(0, 80, 256, 48);
  x.fillStyle = 'rgba(0,0,0,0.2)'; x.fillRect(0, 0, 256, 5);
  return toTex(c);
}

export function shopfront(seed) {
  const c = mk(256, 256), x = c.getContext('2d'), R = mulberry32(seed);
  // rideau métallique à moitié levé
  for (let i = 0; i < 110; i += 6) {
    x.fillStyle = i % 12 ? '#9a9da0' : '#7c7f82'; x.fillRect(0, i, 256, 6);
  }
  x.fillStyle = '#1c1714'; x.fillRect(0, 110, 256, 146);
  // étagères colorées
  for (let s = 0; s < 3; s++) {
    const y = 130 + s * 38;
    x.fillStyle = '#5a3d25'; x.fillRect(8, y + 26, 240, 5);
    for (let k = 10; k < 244; k += 9 + R() * 6) {
      x.fillStyle = `hsl(${R() * 360},${55 + R() * 30}%,${40 + R() * 25}%)`;
      const hh = 10 + R() * 14; x.fillRect(k, y + 26 - hh, 6 + R() * 4, hh);
    }
  }
  x.fillStyle = 'rgba(255,255,255,0.08)'; x.fillRect(0, 110, 256, 4);
  return toTex(c);
}

const SIGN_COLORS = [
  ['#c8102e', '#ffffff'], ['#0b6e4f', '#ffffff'], ['#f2c500', '#1a1a1a'], ['#1f4e9c', '#ffffff'],
  ['#ffffff', '#c8102e'], ['#e46a1f', '#ffffff'], ['#5b2c83', '#ffd23f'], ['#00a0b0', '#ffffff'],
];

export const SIGN_TEXTS = [
  ['ALIMENTATION DIEU MERCI', 'Gros & détail'],
  ['MAQUIS LE BON GOÛT', 'Amiwo • Pâte rouge • Poisson braisé'],
  ['PHARMACIE DE LA LAGUNE', 'Ouverte 7j/7'],
  ['COIFFURE BELLE DAME', 'Tresses • Mèches • Tissage'],
  ['QUINCAILLERIE ESPOIR', 'Ciment • Fer • Peinture'],
  ['TRANSFERT D\'ARGENT', 'Rapide et sûr'],
  ['ATELIER COUTURE LA GRÂCE', 'Pagnes • Bazin • Wax'],
  ['BAR LA DÉTENTE', 'Boissons fraîches'],
  ['VULCANISATEUR', 'Pneus • Chambres à air'],
  ['BOULANGERIE DU MATIN', 'Pain chaud tous les jours'],
  ['PRESSING ÉCLAT', 'Lavage • Repassage'],
  ['GLACIER TROPICAL', 'Jus d\'ananas • Bissap'],
  ['IMPRIMERIE LUMIÈRE', 'Faire-part • Banderoles'],
  ['RECHARGE CRÉDIT', 'Tous réseaux'],
  ['CABINET DENTAIRE', 'Soins & conseils'],
  ['CHEZ TANTI ROSE', 'Akassa • Atassi • Ablo'],
];

export function signAtlas() {
  const W = 1024, H = 1024, c = mk(W, H), x = c.getContext('2d');
  const rects = [];
  for (let i = 0; i < 16; i++) {
    const col = i % 2, row = (i / 2) | 0;
    const px = col * 512, py = row * 128;
    const [bg, fg] = SIGN_COLORS[i % SIGN_COLORS.length];
    x.fillStyle = bg; x.fillRect(px, py, 512, 128);
    x.strokeStyle = fg; x.lineWidth = 4; x.strokeRect(px + 8, py + 8, 496, 112);
    x.fillStyle = fg; x.textAlign = 'center'; x.textBaseline = 'middle';
    let fs = 54;
    x.font = `900 ${fs}px "Arial Black", Impact, sans-serif`;
    while (x.measureText(SIGN_TEXTS[i][0]).width > 470 && fs > 20) { fs -= 2; x.font = `900 ${fs}px "Arial Black", Impact, sans-serif`; }
    x.fillText(SIGN_TEXTS[i][0], px + 256, py + 52);
    x.font = 'italic 600 22px Arial, sans-serif';
    x.fillText(SIGN_TEXTS[i][1], px + 256, py + 98);
    // patine
    x.fillStyle = 'rgba(80,60,40,0.12)'; x.fillRect(px, py + 100, 512, 28);
    rects.push([col * 0.5, 1 - (row + 1) / 8, col * 0.5 + 0.5, 1 - row / 8]);
  }
  const t = toTex(c, { repeat: false });
  return { texture: t, rects };
}

// Motif « wax / pagne » raccordable
export function pagne(colors, seed) {
  const c = mk(128, 128), x = c.getContext('2d'), R = mulberry32(seed);
  x.fillStyle = colors[0]; x.fillRect(0, 0, 128, 128);
  const style = (R() * 3) | 0;
  for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) {
    const cx = i * 32 + 16, cy = j * 32 + 16;
    if (style === 0) {
      x.fillStyle = colors[1]; x.beginPath(); x.arc(cx, cy, 12, 0, 7); x.fill();
      x.fillStyle = colors[2]; x.beginPath(); x.arc(cx, cy, 6, 0, 7); x.fill();
      x.fillStyle = colors[3]; x.beginPath(); x.arc(cx, cy, 2.5, 0, 7); x.fill();
    } else if (style === 1) {
      x.fillStyle = (i + j) % 2 ? colors[1] : colors[2];
      x.beginPath(); x.moveTo(cx, cy - 13); x.lineTo(cx + 13, cy); x.lineTo(cx, cy + 13); x.lineTo(cx - 13, cy); x.fill();
      x.fillStyle = colors[3]; x.fillRect(cx - 3, cy - 3, 6, 6);
    } else {
      x.strokeStyle = colors[1]; x.lineWidth = 4;
      x.beginPath(); x.arc(cx - 16, cy - 16, 16, 0, Math.PI / 2); x.stroke();
      x.strokeStyle = colors[2];
      x.beginPath(); x.arc(cx + 16, cy + 16, 16, Math.PI, Math.PI * 1.5); x.stroke();
      x.fillStyle = colors[3]; x.beginPath(); x.arc(cx, cy, 4, 0, 7); x.fill();
    }
  }
  return toTex(c);
}

export function bark() {
  const c = mk(64, 128), x = c.getContext('2d'), R = mulberry32(31);
  x.fillStyle = '#7a6a55'; x.fillRect(0, 0, 64, 128);
  for (let i = 0; i < 128; i += 6) {
    x.fillStyle = `rgba(40,30,20,${0.25 + R() * 0.25})`; x.fillRect(0, i, 64, 2);
  }
  speckle(x, 64, 128, ['#4a3e30', '#9a8a70'], 800, 1.5, R);
  return toTex(c);
}

export function leaves() {
  const c = mk(128, 128), x = c.getContext('2d'), R = mulberry32(32);
  x.fillStyle = '#3f6a25'; x.fillRect(0, 0, 128, 128);
  for (let i = 0; i < 700; i++) {
    x.fillStyle = `hsl(${85 + R() * 30},${40 + R() * 25}%,${18 + R() * 25}%)`;
    x.beginPath(); x.ellipse(R() * 128, R() * 128, 3 + R() * 4, 1.5 + R() * 2, R() * 3, 0, 7); x.fill();
  }
  return toTex(c);
}

export function boat(seed) {
  const c = mk(64, 256), x = c.getContext('2d'), R = mulberry32(seed);
  const cols = ['#c8102e', '#f2c500', '#0b6e4f', '#1f4e9c', '#ffffff', '#e46a1f'];
  let y = 0;
  while (y < 64) {
    const h = 6 + R() * 12;
    x.fillStyle = cols[(R() * cols.length) | 0];
    x.fillRect(0, y, 64, h);
    y += h;
  }
  // bandes horizontales : on recopie le motif sur la hauteur
  for (let k = 64; k < 256; k += 64) x.drawImage(c, 0, 0, 64, 64, 0, k, 64, 64);
  const t = toTex(c);
  return t;
}

export function benFlag() {
  // drapeau du Bénin : bande verte verticale, jaune en haut, rouge en bas
  const c = mk(150, 100), x = c.getContext('2d');
  x.fillStyle = '#008751'; x.fillRect(0, 0, 60, 100);
  x.fillStyle = '#fcd116'; x.fillRect(60, 0, 90, 50);
  x.fillStyle = '#e8112d'; x.fillRect(60, 50, 90, 50);
  return toTex(c, { repeat: false });
}

export function stripes(a, b, n = 8) {
  const c = mk(64, 64), x = c.getContext('2d');
  for (let i = 0; i < n; i++) { x.fillStyle = i % 2 ? a : b; x.fillRect((i * 64) / n, 0, 64 / n, 64); }
  return toTex(c);
}

// ---------------------------------------------------------------------------
// Mission 002 : textures haute définition + cartes de normales procédurales
// ---------------------------------------------------------------------------

// Bruit de valeur lissé, raccordable (utilisé pour enduits, écorces, etc.)
function valueNoise(w, h, cells, rand) {
  const g = new Float32Array(cells * cells);
  for (let i = 0; i < g.length; i++) g[i] = rand();
  const out = new Float32Array(w * h);
  for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) {
    const fx = (i / w) * cells, fy = (j / h) * cells;
    const x0 = Math.floor(fx), y0 = Math.floor(fy), tx = fx - x0, ty = fy - y0;
    const sx = tx * tx * (3 - 2 * tx), sy = ty * ty * (3 - 2 * ty);
    const at = (X, Y) => g[(Y % cells) * cells + (X % cells)];
    out[j * w + i] = (at(x0, y0) * (1 - sx) + at(x0 + 1, y0) * sx) * (1 - sy) + (at(x0, y0 + 1) * (1 - sx) + at(x0 + 1, y0 + 1) * sx) * sy;
  }
  return out;
}

// Convertit un canvas de hauteurs (niveaux de gris) en carte de normales
export function heightToNormal(hc, strength = 2) {
  const w = hc.width, h = hc.height;
  const src = hc.getContext('2d').getImageData(0, 0, w, h).data;
  const c = mk(w, h), x = c.getContext('2d');
  const img = x.createImageData(w, h);
  const H = (i, j) => src[(((j + h) % h) * w + ((i + w) % w)) * 4] / 255;
  for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) {
    const dx = (H(i + 1, j) - H(i - 1, j)) * strength;
    const dy = (H(i, j + 1) - H(i, j - 1)) * strength;
    const l = Math.hypot(dx, dy, 1);
    const o = (j * w + i) * 4;
    img.data[o] = (-dx / l * 0.5 + 0.5) * 255;
    img.data[o + 1] = (dy / l * 0.5 + 0.5) * 255;
    img.data[o + 2] = (1 / l * 0.5 + 0.5) * 255;
    img.data[o + 3] = 255;
  }
  x.putImageData(img, 0, 0);
  return toTex(c, { srgb: false });
}

// Façade : 4 travées x 2 niveaux (12 m x 6 m), enduit réaliste, carte de normales et fenêtres éclairées la nuit
export function facade(base, shutter, seed, opts = {}) {
  const W = 1024, H = 512, B = 256; // 1 travée = 256 px = 3 m
  const R = mulberry32(seed);
  const c = mk(W, H), x = c.getContext('2d');
  const hc = mk(W, H), hx = hc.getContext('2d');
  const e = mk(W, H), ex = e.getContext('2d');
  // enduit : couleur de base + grain + variations basse fréquence
  x.fillStyle = base; x.fillRect(0, 0, W, H);
  const n1 = valueNoise(W / 4, H / 4, 8, R), img = x.getImageData(0, 0, W, H);
  for (let j = 0; j < H; j++) for (let i = 0; i < W; i++) {
    const o = (j * W + i) * 4;
    const v = n1[((j >> 2) * (W / 4)) + (i >> 2)] * 0.16 - 0.08 + (R() - 0.5) * 0.06;
    img.data[o] = Math.max(0, Math.min(255, img.data[o] * (1 + v)));
    img.data[o + 1] = Math.max(0, Math.min(255, img.data[o + 1] * (1 + v)));
    img.data[o + 2] = Math.max(0, Math.min(255, img.data[o + 2] * (1 + v * 1.1)));
  }
  x.putImageData(img, 0, 0);
  hx.fillStyle = '#808080'; hx.fillRect(0, 0, W, H);
  speckle(hx, W, H, ['#6a6a6a', '#9a9a9a'], 30000, 1.6, R, 0.5);
  ex.fillStyle = '#000'; ex.fillRect(0, 0, W, H);

  for (let row = 0; row < 2; row++) {
    const y0 = row * B;
    // corniche / bandeau de dalle (relief + peinture)
    x.fillStyle = opts.band || 'rgba(255,255,255,0.55)'; x.fillRect(0, y0 + 230, W, 20);
    x.fillStyle = 'rgba(0,0,0,0.18)'; x.fillRect(0, y0 + 250, W, 6);
    hx.fillStyle = '#c8c8c8'; hx.fillRect(0, y0 + 230, W, 20);
    // salissures sous la corniche
    const sg = x.createLinearGradient(0, y0, 0, y0 + 60);
    sg.addColorStop(0, 'rgba(40,35,30,0.22)'); sg.addColorStop(1, 'rgba(40,35,30,0)');
    x.fillStyle = sg; x.fillRect(0, y0, W, 60);
    for (let b = 0; b < 4; b++) {
      const bx = b * B;
      const wx = bx + 64, wy = y0 + 48, ww = 128, wh = 134;
      // coulures sous l'appui
      for (let k = 0; k < 6; k++) {
        const sx = wx + 6 + R() * (ww - 12), len = 30 + R() * 50;
        const g2 = x.createLinearGradient(0, wy + wh + 10, 0, wy + wh + 10 + len);
        g2.addColorStop(0, 'rgba(45,38,30,0.28)'); g2.addColorStop(1, 'rgba(45,38,30,0)');
        x.fillStyle = g2; x.fillRect(sx, wy + wh + 10, 3 + R() * 6, len);
      }
      // encadrement en saillie + appui
      x.fillStyle = '#efe9de'; x.fillRect(wx - 12, wy - 12, ww + 24, wh + 24);
      x.fillStyle = '#d9d1c2'; x.fillRect(wx - 18, wy + wh + 6, ww + 36, 12);
      hx.fillStyle = '#b8b8b8'; hx.fillRect(wx - 12, wy - 12, ww + 24, wh + 24);
      hx.fillStyle = '#e0e0e0'; hx.fillRect(wx - 18, wy + wh + 6, ww + 36, 12);
      hx.fillStyle = '#303030'; hx.fillRect(wx, wy, ww, wh); // ouverture en retrait
      const kind = R();
      if (kind < 0.42) {
        // persiennes fermées
        x.fillStyle = shutter; x.fillRect(wx, wy, ww, wh);
        for (let k = 0; k < wh; k += 8) {
          x.fillStyle = 'rgba(0,0,0,0.30)'; x.fillRect(wx, wy + k + 5, ww, 3);
          x.fillStyle = 'rgba(255,255,255,0.12)'; x.fillRect(wx, wy + k, ww, 2);
          hx.fillStyle = '#505050'; hx.fillRect(wx, wy + k, ww, 4);
          hx.fillStyle = '#383838'; hx.fillRect(wx, wy + k + 4, ww, 4);
        }
        x.fillStyle = 'rgba(0,0,0,0.4)'; x.fillRect(wx + ww / 2 - 2, wy, 4, wh);
        if (R() < 0.18) { ex.fillStyle = 'rgba(255,170,80,0.3)'; ex.fillRect(wx, wy, ww, wh); }
      } else {
        // vitrage avec reflet du ciel
        const gg = x.createLinearGradient(wx, wy, wx + ww * 0.6, wy + wh);
        gg.addColorStop(0, '#6f8fa6'); gg.addColorStop(0.45, '#2e4252'); gg.addColorStop(1, '#151d24');
        x.fillStyle = gg; x.fillRect(wx, wy, ww, wh);
        // rideau intérieur
        if (R() < 0.6) { x.fillStyle = `hsla(${R() * 360},40%,60%,0.35)`; x.fillRect(wx + 4, wy + 4, ww * (0.25 + R() * 0.25), wh - 8); }
        x.fillStyle = '#f1ece2'; x.fillRect(wx + ww / 2 - 3, wy, 6, wh); x.fillRect(wx, wy + wh * 0.36, ww, 5);
        hx.fillStyle = '#909090'; hx.fillRect(wx + ww / 2 - 3, wy, 6, wh); hx.fillRect(wx, wy + wh * 0.36, ww, 5);
        if (kind > 0.72) { // grille de défense en fer forgé
          x.fillStyle = 'rgba(28,28,28,0.9)'; hx.fillStyle = '#a0a0a0';
          for (let k = 8; k < ww; k += 14) { x.fillRect(wx + k, wy, 3, wh); hx.fillRect(wx + k, wy, 3, wh); }
          x.fillRect(wx, wy + wh * 0.5, ww, 3);
          x.strokeStyle = 'rgba(28,28,28,0.9)'; x.lineWidth = 2;
          for (let k = 0; k < 3; k++) { x.beginPath(); x.arc(wx + ww / 2, wy + 20 + k * 40, 10, 0, 7); x.stroke(); }
        }
        // battants de persienne ouverts
        for (const sx of [wx - 46, wx + ww + 12]) {
          x.fillStyle = shutter; x.fillRect(sx, wy, 34, wh);
          hx.fillStyle = '#a8a8a8'; hx.fillRect(sx, wy, 34, wh);
          x.fillStyle = 'rgba(0,0,0,0.25)';
          for (let k = 3; k < wh; k += 7) x.fillRect(sx, wy + k, 34, 2);
        }
        if (R() < 0.5) {
          const lg = ex.createLinearGradient(0, wy, 0, wy + wh);
          lg.addColorStop(0, '#ffd590'); lg.addColorStop(1, '#ff9a40');
          ex.fillStyle = lg; ex.fillRect(wx, wy, ww, wh);
        }
      }
    }
  }
  // fissures fines
  x.strokeStyle = 'rgba(60,50,40,0.35)'; x.lineWidth = 1;
  for (let k = 0; k < 6; k++) {
    let px = R() * W, py = R() * H; x.beginPath(); x.moveTo(px, py);
    for (let s2 = 0; s2 < 8; s2++) { px += (R() - 0.5) * 18; py += R() * 14; x.lineTo(px, py); }
    x.stroke();
  }
  return { map: toTex(c), normalMap: heightToNormal(hc, 3), emissive: toTex(e) };
}

// Claustra (bloc ajouré en béton) avec transparence
export function claustra() {
  const c = mk(256, 256), x = c.getContext('2d');
  x.fillStyle = '#e9e3d6'; x.fillRect(0, 0, 256, 256);
  x.globalCompositeOperation = 'destination-out';
  for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) {
    const cx = i * 64 + 32, cy = j * 64 + 32;
    x.beginPath(); x.arc(cx, cy, 20, 0, 7); x.fill();
    x.fillRect(cx - 30, cy - 4, 8, 8); x.fillRect(cx + 22, cy - 4, 8, 8);
  }
  x.globalCompositeOperation = 'source-over';
  x.strokeStyle = 'rgba(0,0,0,0.12)'; x.lineWidth = 2;
  for (let i = 0; i <= 4; i++) { x.beginPath(); x.moveTo(i * 64, 0); x.lineTo(i * 64, 256); x.stroke(); x.beginPath(); x.moveTo(0, i * 64); x.lineTo(256, i * 64); x.stroke(); }
  return toTex(c);
}

// Balustrade à balustres (transparence)
export function balustrade() {
  const c = mk(256, 128), x = c.getContext('2d');
  x.clearRect(0, 0, 256, 128);
  x.fillStyle = '#f0ebe1';
  x.fillRect(0, 0, 256, 16); x.fillRect(0, 112, 256, 16);
  for (let i = 8; i < 256; i += 32) {
    x.beginPath();
    x.moveTo(i + 6, 16); x.quadraticCurveTo(i + 18, 40, i + 8, 64); x.quadraticCurveTo(i + 22, 90, i + 6, 112);
    x.lineTo(i + 20, 112); x.quadraticCurveTo(i + 4, 90, i + 18, 64); x.quadraticCurveTo(i + 8, 40, i + 20, 16);
    x.fill();
  }
  return toTex(c);
}

// Dalles de caniveau en béton (couvre les caniveaux le long des routes)
export function gutter() {
  const c = mk(256, 64), x = c.getContext('2d'), R = mulberry32(41);
  x.fillStyle = '#9f998e'; x.fillRect(0, 0, 256, 64);
  speckle(x, 256, 64, ['#6f6a62', '#c2bcb0', '#8a5a3a'], 2500, 1.6, R, 0.4);
  for (let i = 0; i < 256; i += 64) {
    x.fillStyle = '#2a2622'; x.fillRect(i, 0, 4, 64);
    x.fillStyle = 'rgba(0,0,0,0.3)'; x.fillRect(i + 26, 28, 12, 8);
  }
  blotches(x, 256, 64, '#a4552f', 4, 30, 0.3, R);
  return toTex(c);
}

// Bande de sable/latérite qui envahit le bord des routes (transparence)
export function sandEdge() {
  const c = mk(256, 128), x = c.getContext('2d'), R = mulberry32(42);
  const img = x.createImageData(256, 128);
  const n = valueNoise(256, 128, 16, R);
  for (let j = 0; j < 128; j++) for (let i = 0; i < 256; i++) {
    const o = (j * 256 + i) * 4, t = j / 127;
    const a = Math.max(0, Math.min(1, (1 - t) * 1.6 - 0.35 + (n[j * 256 + i] - 0.5) * 0.9));
    const v = 0.85 + R() * 0.3;
    img.data[o] = 172 * v; img.data[o + 1] = 136 * v; img.data[o + 2] = 98 * v; img.data[o + 3] = a * 120;
  }
  x.putImageData(img, 0, 0);
  const t = toTex(c);
  t.wrapT = THREE.ClampToEdgeWrapping;
  return t;
}

// Feuille de cocotier : folioles fines, dégradé, transparence
export function palmFrond() {
  const W = 512, H = 128, c = mk(W, H), x = c.getContext('2d'), R = mulberry32(51);
  x.clearRect(0, 0, W, H);
  for (let i = 10; i < W - 4; i += 3.2) {
    const t = i / W;
    const len = 58 * Math.sin(Math.PI * Math.min(1, (i + 50) / (W + 40))) * (0.85 + R() * 0.3);
    const gcol = 70 + R() * 60, rcol = 40 + R() * 30 + t * 40;
    x.strokeStyle = `rgb(${rcol},${gcol + 30},${30 + R() * 20})`;
    x.lineWidth = 2.2;
    for (const s of [-1, 1]) {
      x.beginPath(); x.moveTo(i, 64);
      x.quadraticCurveTo(i + 14, 64 + s * len * 0.5, i + 22 + R() * 6, 64 + s * len);
      x.stroke();
    }
  }
  x.strokeStyle = '#8a8240'; x.lineWidth = 4;
  x.beginPath(); x.moveTo(0, 64); x.lineTo(W, 64); x.stroke();
  return toTex(c, { repeat: false });
}

export function deadFrond() {
  const W = 256, H = 64, c = mk(W, H), x = c.getContext('2d');
  for (let i = 6; i < W; i += 3) {
    x.strokeStyle = `rgb(${120 + (i % 30)},${90 + (i % 20)},50)`; x.lineWidth = 2;
    x.beginPath(); x.moveTo(i, 32); x.lineTo(i + 10, 6 + (i % 7)); x.stroke();
    x.beginPath(); x.moveTo(i, 32); x.lineTo(i + 10, 58 - (i % 7)); x.stroke();
  }
  return toTex(c, { repeat: false });
}

// Grappe de feuilles (cartes de feuillage des arbres)
export function leafCluster(hue = 100, seed = 61) {
  const S = 256, c = mk(S, S), x = c.getContext('2d'), R = mulberry32(seed);
  x.clearRect(0, 0, S, S);
  for (let k = 0; k < 260; k++) {
    const a = R() * Math.PI * 2, r = Math.sqrt(R()) * 110;
    const px = S / 2 + Math.cos(a) * r, py = S / 2 + Math.sin(a) * r;
    const l = 22 + R() * 30;
    x.save(); x.translate(px, py); x.rotate(R() * 6.28);
    x.fillStyle = `hsl(${hue + R() * 25},${40 + R() * 25}%,${20 + R() * 26}%)`;
    x.beginPath(); x.ellipse(0, 0, l * 0.5, l * 0.2, 0, 0, 7); x.fill();
    x.strokeStyle = 'rgba(0,0,0,0.2)'; x.lineWidth = 1; x.beginPath(); x.moveTo(-l * 0.5, 0); x.lineTo(l * 0.5, 0); x.stroke();
    x.restore();
  }
  return toTex(c, { repeat: false });
}

// Bougainvillier : fleurs magenta + feuilles
export function bougainvillea() {
  const S = 256, c = mk(S, S), x = c.getContext('2d'), R = mulberry32(71);
  for (let k = 0; k < 340; k++) {
    const a = R() * 6.28, r = Math.sqrt(R()) * 115;
    const px = S / 2 + Math.cos(a) * r, py = S / 2 + Math.sin(a) * r;
    const flower = R() < 0.6;
    x.fillStyle = flower ? `hsl(${315 + R() * 25},${70 + R() * 20}%,${45 + R() * 18}%)` : `hsl(${95 + R() * 20},45%,${22 + R() * 15}%)`;
    x.beginPath(); x.ellipse(px, py, 6 + R() * 6, 4 + R() * 4, R() * 3, 0, 7); x.fill();
  }
  return toTex(c, { repeat: false });
}

// Touffe d'herbe (transparence)
export function grassTuft() {
  const W = 128, H = 128, c = mk(W, H), x = c.getContext('2d'), R = mulberry32(81);
  for (let k = 0; k < 70; k++) {
    const bx = 10 + R() * 108, h = 50 + R() * 75, lean = (R() - 0.5) * 50;
    x.strokeStyle = `hsl(${60 + R() * 40},${35 + R() * 25}%,${25 + R() * 30}%)`;
    x.lineWidth = 1.5 + R() * 1.5;
    x.beginPath(); x.moveTo(bx, H); x.quadraticCurveTo(bx + lean * 0.3, H - h * 0.6, bx + lean, H - h); x.stroke();
  }
  return toTex(c, { repeat: false });
}

// Feuille de bananier (transparence)
export function bananaLeaf() {
  const W = 256, H = 96, c = mk(W, H), x = c.getContext('2d'), R = mulberry32(91);
  x.fillStyle = '#4f8a2e';
  x.beginPath(); x.moveTo(0, 48);
  x.bezierCurveTo(60, 0, 200, 4, 256, 44);
  x.bezierCurveTo(200, 92, 60, 96, 0, 48); x.fill();
  x.strokeStyle = 'rgba(30,60,20,0.5)'; x.lineWidth = 1;
  for (let i = 10; i < 250; i += 5) { x.beginPath(); x.moveTo(i, 48); x.lineTo(i + 8, 6 + R() * 10); x.stroke(); x.beginPath(); x.moveTo(i, 48); x.lineTo(i + 8, 90 - R() * 10); x.stroke(); }
  x.globalCompositeOperation = 'destination-out';
  for (let k = 0; k < 10; k++) { const px = 30 + R() * 200; x.fillRect(px, R() < 0.5 ? 0 : 60, 2, 40); }
  x.globalCompositeOperation = 'source-over';
  x.strokeStyle = '#c8d070'; x.lineWidth = 3; x.beginPath(); x.moveTo(0, 48); x.lineTo(256, 46); x.stroke();
  return toTex(c, { repeat: false });
}

// Écorce de cocotier annelée + carte de normales
export function palmBark() {
  const W = 128, H = 512, c = mk(W, H), x = c.getContext('2d'), R = mulberry32(101);
  const hc = mk(W, H), hx = hc.getContext('2d');
  x.fillStyle = '#7d6c58'; x.fillRect(0, 0, W, H);
  hx.fillStyle = '#808080'; hx.fillRect(0, 0, W, H);
  for (let y = 0; y < H; y += 9 + R() * 5) {
    x.fillStyle = `rgba(50,40,30,${0.3 + R() * 0.3})`; x.fillRect(0, y, W, 3);
    x.fillStyle = 'rgba(200,190,170,0.15)'; x.fillRect(0, y + 3, W, 2);
    hx.fillStyle = '#404040'; hx.fillRect(0, y, W, 3);
    hx.fillStyle = '#b0b0b0'; hx.fillRect(0, y + 3, W, 3);
  }
  speckle(x, W, H, ['#4a3e30', '#a09078', '#5e5a50'], 4000, 1.6, R, 0.4);
  return { map: toTex(c), normalMap: heightToNormal(hc, 4) };
}

// Climatiseur (façade avant)
export function acUnit() {
  const c = mk(64, 48), x = c.getContext('2d');
  x.fillStyle = '#e8e6e0'; x.fillRect(0, 0, 64, 48);
  x.fillStyle = '#9a9890';
  for (let i = 6; i < 42; i += 4) x.fillRect(6, i, 30, 2);
  x.beginPath(); x.arc(48, 24, 12, 0, 7); x.fillStyle = '#3a3a3a'; x.fill();
  x.strokeStyle = '#888'; x.beginPath(); x.moveTo(36, 24); x.lineTo(60, 24); x.moveTo(48, 12); x.lineTo(48, 36); x.stroke();
  return toTex(c, { repeat: false });
}

// Pavés autobloquants HD + normales
export function paveHD() {
  const S = 512, c = mk(S, S), x = c.getContext('2d'), R = mulberry32(12);
  const hc = mk(S, S), hx = hc.getContext('2d');
  x.fillStyle = '#5d5850'; x.fillRect(0, 0, S, S);
  hx.fillStyle = '#202020'; hx.fillRect(0, 0, S, S);
  const bw = 64, bh = 32;
  for (let row = 0; row < S / bh; row++) {
    const off = (row % 2) * (bw / 2);
    for (let col = -1; col < S / bw + 1; col++) {
      const v = 112 + R() * 34;
      const px = col * bw + off + 2, py = row * bh + 2;
      x.fillStyle = `rgb(${v + 6},${v + 1},${v - 8})`; x.fillRect(px, py, bw - 4, bh - 4);
      x.fillStyle = 'rgba(255,255,255,0.07)'; x.fillRect(px, py, bw - 4, 3);
      hx.fillStyle = '#c0c0c0'; hx.fillRect(px + 1, py + 1, bw - 6, bh - 6);
      hx.fillStyle = '#e0e0e0'; hx.fillRect(px + 4, py + 4, bw - 12, bh - 12);
    }
  }
  blotches(x, S, S, '#a4552f', 14, 110, 0.25, R);
  blotches(x, S, S, '#2a2622', 8, 80, 0.2, R);
  speckle(x, S, S, ['#3c3a36', '#9a948a'], 12000, 1.5, R);
  return { map: toTex(c), normalMap: heightToNormal(hc, 2.5) };
}

export function sandHD() {
  const S = 512, c = mk(S, S), x = c.getContext('2d'), R = mulberry32(16);
  const hc = mk(S, S), hx = hc.getContext('2d');
  x.fillStyle = '#dcc79a'; x.fillRect(0, 0, S, S);
  blotches(x, S, S, '#c4a878', 16, 110, 0.35, R);
  blotches(x, S, S, '#efdfba', 10, 90, 0.3, R);
  speckle(x, S, S, ['#b4986a', '#f6e8c6', '#a08860', '#8a8a8a'], 40000, 1.4, R, 0.5);
  // rides de vent
  const img = hx.createImageData(S, S);
  const n = valueNoise(S, S, 8, R);
  for (let j = 0; j < S; j++) for (let i = 0; i < S; i++) {
    const v = 0.5 + 0.5 * Math.sin((j + n[j * S + i] * 60) * 0.18 * Math.PI / 2 * 0.5);
    const o = (j * S + i) * 4; img.data[o] = img.data[o + 1] = img.data[o + 2] = v * 160 + R() * 40; img.data[o + 3] = 255;
  }
  hx.putImageData(img, 0, 0);
  return { map: toTex(c), normalMap: heightToNormal(hc, 1.2) };
}

export function grassHD() {
  const S = 512, c = mk(S, S), x = c.getContext('2d'), R = mulberry32(15);
  x.fillStyle = '#56752d'; x.fillRect(0, 0, S, S);
  blotches(x, S, S, '#9a9048', 14, 110, 0.4, R);
  blotches(x, S, S, '#33521c', 12, 90, 0.4, R);
  blotches(x, S, S, '#8a5a3a', 5, 50, 0.3, R);
  for (let k = 0; k < 26000; k++) {
    x.strokeStyle = `hsl(${65 + R() * 40},${35 + R() * 25}%,${18 + R() * 28}%)`;
    x.globalAlpha = 0.5;
    const px = R() * S, py = R() * S;
    x.beginPath(); x.moveTo(px, py); x.lineTo(px + (R() - 0.5) * 4, py - 3 - R() * 6); x.stroke();
  }
  x.globalAlpha = 1;
  return toTex(c);
}

// Plinthe colorée (soubassement) avec éclaboussures
export function plinth(color) {
  const c = mk(128, 64), x = c.getContext('2d'), R = mulberry32(color.length * 7);
  x.fillStyle = color; x.fillRect(0, 0, 128, 64);
  const g = x.createLinearGradient(0, 30, 0, 64);
  g.addColorStop(0, 'rgba(150,72,40,0)'); g.addColorStop(1, 'rgba(150,72,40,0.7)');
  x.fillStyle = g; x.fillRect(0, 30, 128, 34);
  speckle(x, 128, 64, ['#000', '#fff'], 800, 1.2, R, 0.1);
  x.fillStyle = 'rgba(255,255,255,0.35)'; x.fillRect(0, 0, 128, 3);
  return toTex(c);
}

// Fresque publicitaire peinte sur mur (générique)
export const MURALS = [
  ['#1f4e9c', '#ffffff', 'EAU MINÉRALE', 'Fraîche & pure'],
  ['#c8102e', '#ffd23f', 'CIMENT SOLIDE', 'Pour bâtir l\'avenir'],
  ['#0b6e4f', '#ffffff', 'LOTO DU BÉNIN', 'Tentez votre chance'],
  ['#f2c500', '#1a1a1a', 'JUS DE BISSAP', '100 % naturel'],
];
export function muralAtlas() {
  const c = mk(1024, 512), x = c.getContext('2d');
  MURALS.forEach(([bg, fg, t1, t2], i) => {
    const px = (i % 2) * 512, py = Math.floor(i / 2) * 256;
    x.fillStyle = bg; x.fillRect(px, py, 512, 256);
    x.fillStyle = fg; x.textAlign = 'center';
    x.font = '900 64px "Arial Black", Impact, sans-serif'; x.fillText(t1, px + 256, py + 120, 470);
    x.font = 'italic 700 34px Arial, sans-serif'; x.fillText(t2, px + 256, py + 180, 470);
    x.fillStyle = 'rgba(255,255,255,0.18)';
    for (let k = 0; k < 60; k++) x.fillRect(px + Math.random() * 512, py + Math.random() * 256, 2 + Math.random() * 10, 2);
    const g = x.createLinearGradient(0, py + 180, 0, py + 256);
    g.addColorStop(0, 'rgba(120,60,30,0)'); g.addColorStop(1, 'rgba(120,60,30,0.45)');
    x.fillStyle = g; x.fillRect(px, py + 180, 512, 76);
  });
  return toTex(c, { repeat: false });
}

// Panneaux routiers : 8 pictogrammes (2 rangées de 4) + 4 panneaux directionnels
export function roadSignAtlas() {
  const c = mk(512, 512), x = c.getContext('2d');
  x.fillStyle = '#8a8d90'; x.fillRect(0, 0, 512, 512);
  const cell = (i) => [(i % 4) * 128, Math.floor(i / 4) * 128];
  const center = (i) => { const [px, py] = cell(i); return [px + 64, py + 64]; };
  // 0 STOP
  { const [cx, cy] = center(0); x.fillStyle = '#fff'; poly(x, cx, cy, 60, 8, Math.PI / 8); x.fillStyle = '#c8102e'; poly(x, cx, cy, 54, 8, Math.PI / 8);
    x.fillStyle = '#fff'; x.font = '900 34px Arial'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('STOP', cx, cy + 2); }
  // 1 cédez le passage (triangle pointe en bas)
  { const [cx, cy] = center(1); x.fillStyle = '#c8102e'; tri(x, cx, cy, 62, true); x.fillStyle = '#fff'; tri(x, cx, cy, 44, true); }
  // 2 limitation 50
  { const [cx, cy] = center(2); x.fillStyle = '#c8102e'; circ(x, cx, cy, 60); x.fillStyle = '#fff'; circ(x, cx, cy, 46);
    x.fillStyle = '#111'; x.font = '900 46px Arial'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('50', cx, cy + 3); }
  // 3 passage piétons
  { const [px, py] = cell(3); x.fillStyle = '#1f5fbf'; x.fillRect(px + 6, py + 6, 116, 116); x.fillStyle = '#fff'; tri(x, px + 64, py + 66, 50, false);
    x.fillStyle = '#111'; circ(x, px + 64, py + 50, 6); x.fillRect(px + 60, py + 57, 8, 22); x.fillRect(px + 52, py + 79, 6, 12); x.fillRect(px + 70, py + 79, 6, 12);
    x.fillRect(px + 40, py + 92, 48, 4); }
  // 4 arrêt de bus
  { const [px, py] = cell(4); x.fillStyle = '#1f5fbf'; x.fillRect(px + 6, py + 6, 116, 116); x.fillStyle = '#fff'; x.font = '900 40px Arial'; x.textAlign = 'center'; x.textBaseline = 'middle';
    x.fillText('BUS', px + 64, py + 50); x.font = '700 18px Arial'; x.fillText('ARRÊT', px + 64, py + 90); }
  // 5 sens interdit
  { const [cx, cy] = center(5); x.fillStyle = '#c8102e'; circ(x, cx, cy, 60); x.fillStyle = '#fff'; x.fillRect(cx - 42, cy - 9, 84, 18); }
  // 6 feux tricolores (danger)
  { const [cx, cy] = center(6); x.fillStyle = '#c8102e'; tri(x, cx, cy, 62, false); x.fillStyle = '#fff'; tri(x, cx, cy, 44, false);
    x.fillStyle = '#222'; x.fillRect(cx - 8, cy - 14, 16, 34); x.fillStyle = '#e02020'; circ(x, cx, cy - 8, 4); x.fillStyle = '#f0c000'; circ(x, cx, cy + 3, 4); x.fillStyle = '#20a040'; circ(x, cx, cy + 14, 4); }
  // 7 parking zémidjans
  { const [px, py] = cell(7); x.fillStyle = '#1f5fbf'; x.fillRect(px + 6, py + 6, 116, 116); x.fillStyle = '#f2c200'; x.font = '900 60px Arial'; x.textAlign = 'center'; x.textBaseline = 'middle';
    x.fillText('P', px + 64, py + 52); x.fillStyle = '#fff'; x.font = '800 17px Arial'; x.fillText('ZÉMIDJAN', px + 64, py + 98); }
  // panneaux directionnels (fond vert, lettrage blanc)
  const boards = ['← GRAND MARCHÉ', 'PLAGE DE FIDJROSSÈ →', '↑ CENTRE-VILLE', '← JARDIN  •  PORT →'];
  boards.forEach((t, i) => {
    const py = 256 + i * 64;
    x.fillStyle = '#0b6e4f'; x.fillRect(4, py + 4, 504, 56); x.strokeStyle = '#fff'; x.lineWidth = 3; x.strokeRect(9, py + 9, 494, 46);
    x.fillStyle = '#fff'; x.font = '800 30px Arial'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(t, 256, py + 33, 480);
  });
  const t = toTex(c, { repeat: false });
  return {
    texture: t,
    icon: (i) => { const [px, py] = cell(i); return [px / 512, 1 - (py + 128) / 512, (px + 128) / 512, 1 - py / 512]; },
    board: (i) => [0, 1 - (256 + (i + 1) * 64) / 512, 1, 1 - (256 + i * 64) / 512],
  };
}
function poly(x, cx, cy, r, n, a0) { x.beginPath(); for (let k = 0; k < n; k++) { const a = a0 + (k / n) * Math.PI * 2; x.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r); } x.closePath(); x.fill(); }
function circ(x, cx, cy, r) { x.beginPath(); x.arc(cx, cy, r, 0, 7); x.fill(); }
function tri(x, cx, cy, r, down) { const s = down ? -1 : 1; x.beginPath(); x.moveTo(cx, cy - s * r); x.lineTo(cx + r * 0.95, cy + s * r * 0.7); x.lineTo(cx - r * 0.95, cy + s * r * 0.7); x.closePath(); x.fill(); }

export function smokePuff() {
  const c = mk(64, 64), x = c.getContext('2d');
  const g = x.createRadialGradient(32, 32, 0, 32, 32, 32);
  g.addColorStop(0, 'rgba(230,230,230,0.8)'); g.addColorStop(1, 'rgba(230,230,230,0)');
  x.fillStyle = g; x.fillRect(0, 0, 64, 64);
  return toTex(c, { repeat: false });
}

// Façade vitrée de bureaux (mur-rideau) : 4 travées x 2 niveaux, fenêtres éclairées la nuit
export function glassFacade(tint = '#3d6f86', seed = 7) {
  const W = 512, H = 256, c = mk(W, H), x = c.getContext('2d'), e = mk(W, H), ex = e.getContext('2d'), R = mulberry32(seed);
  x.fillStyle = '#c9ccce'; x.fillRect(0, 0, W, H);
  ex.fillStyle = '#000'; ex.fillRect(0, 0, W, H);
  for (let row = 0; row < 2; row++) for (let col = 0; col < 8; col++) {
    const px = col * 64 + 4, py = row * 128 + 8, w = 56, h = 108;
    const g = x.createLinearGradient(px, py, px + w * 0.4, py + h);
    g.addColorStop(0, '#a9d4e6'); g.addColorStop(0.35, tint); g.addColorStop(1, '#16303c');
    x.fillStyle = g; x.fillRect(px, py, w, h);
    x.fillStyle = 'rgba(255,255,255,0.12)'; x.fillRect(px, py + h * 0.55, w, 2);
    if (R() < 0.45) { ex.fillStyle = `rgba(255,${210 + R() * 30},${150 + R() * 60},${0.5 + R() * 0.4})`; ex.fillRect(px, py, w, h); }
  }
  x.fillStyle = '#e8eaeb'; for (let row = 0; row < 2; row++) x.fillRect(0, row * 128 + 118, W, 10);
  return { map: toTex(c), emissive: toTex(e) };
}

export function fishingNet() {
  const c = mk(128, 128), x = c.getContext('2d');
  x.clearRect(0, 0, 128, 128);
  x.strokeStyle = 'rgba(40,90,110,0.95)'; x.lineWidth = 1.6;
  for (let i = -128; i < 256; i += 10) { x.beginPath(); x.moveTo(i, 0); x.lineTo(i + 128, 128); x.stroke(); x.beginPath(); x.moveTo(i, 128); x.lineTo(i + 128, 0); x.stroke(); }
  x.fillStyle = '#e8a020'; for (let i = 6; i < 128; i += 22) { x.beginPath(); x.arc(i, 4, 3, 0, 7); x.fill(); }
  return toTex(c);
}

export function straw() {
  const c = mk(128, 128), x = c.getContext('2d'), R = mulberry32(55);
  x.fillStyle = '#b89a5a'; x.fillRect(0, 0, 128, 128);
  for (let i = 0; i < 900; i++) { x.strokeStyle = `hsl(${38 + R() * 12},${40 + R() * 20}%,${35 + R() * 30}%)`; x.lineWidth = 1; const px = R() * 128, py = R() * 128; x.beginPath(); x.moveTo(px, py); x.lineTo(px + (R() - 0.5) * 4, py + 10 + R() * 14); x.stroke(); }
  return toTex(c);
}

// Plaques de rue et enseignes de lieux (8 lignes de 512 x 64)
export const PLATES = ['Boulevard de la Marina', 'Boulevard central', 'MARCHÉ DANTOKPA', 'PLACE DES MARTYRS', 'BANQUE LAGUNE', 'HÔTEL OCÉAN BLEU', 'CENTRE D\'AFFAIRES', 'PLAGE • Baignade dangereuse'];
export function plateAtlas() {
  const c = mk(512, 512), x = c.getContext('2d');
  PLATES.forEach((t, i) => {
    const py = i * 64;
    const street = i < 2, big = i >= 2 && i < 4;
    x.fillStyle = street ? '#1f4e9c' : big ? '#0b6e4f' : i === 7 ? '#c8102e' : '#1a1a1a';
    x.fillRect(0, py, 512, 64);
    x.strokeStyle = street ? '#fff' : '#fcd116'; x.lineWidth = 3; x.strokeRect(5, py + 5, 502, 54);
    x.fillStyle = street ? '#fff' : '#fcd116';
    x.font = `${street ? 700 : 900} ${street ? 30 : 34}px Arial`; x.textAlign = 'center'; x.textBaseline = 'middle';
    x.fillText(t, 256, py + 34, 490);
  });
  const t = toTex(c, { repeat: false });
  return { texture: t, row: (i) => [0, 1 - (i + 1) * 64 / 512, 1, 1 - i * 64 / 512] };
}
