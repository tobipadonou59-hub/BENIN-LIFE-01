// Personnage importé (GLB, ex. généré par Tripo AI) piloté par nos animations procédurales.
// Formule B de la Mission 003 : le modèle et son squelette viennent de Tripo, les animations
// (repos, marche, course, saut, assis) sont celles du jeu, transférées os par os.
// Si le GLB contient lui-même des clips idle/walk/run, ils sont utilisés en priorité.
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { createCharacter } from './character.js';

// rôles de nos os -> motifs de noms courants (Tripo, Mixamo, Unreal, Blender…)
const ROLE_PATTERNS = [
  ['chest', /shoulder|clavicle|collar/i],
  ['handL', /(left|^l[_.\s]|[_.]l$|_l_).*hand|hand.*(left|[_.]l$)/i],
  ['handR', /(right|^r[_.\s]|[_.]r$|_r_).*hand|hand.*(right|[_.]r$)/i],
  ['foreL', /(left|^l[_.\s]|[_.]l$|_l_).*(forearm|lowerarm|elbow)|(forearm|lowerarm).*(left|[_.]l$)/i],
  ['foreR', /(right|^r[_.\s]|[_.]r$|_r_).*(forearm|lowerarm|elbow)|(forearm|lowerarm).*(right|[_.]r$)/i],
  ['armL', /(left|^l[_.\s]|[_.]l$|_l_).*(upperarm|arm|shoulder)|(upperarm|arm).*(left|[_.]l$)/i],
  ['armR', /(right|^r[_.\s]|[_.]r$|_r_).*(upperarm|arm|shoulder)|(upperarm|arm).*(right|[_.]r$)/i],
  ['footL', /(left|^l[_.\s]|[_.]l$|_l_).*(foot|toe|ankle)|(foot|toe).*(left|[_.]l$)/i],
  ['footR', /(right|^r[_.\s]|[_.]r$|_r_).*(foot|toe|ankle)|(foot|toe).*(right|[_.]r$)/i],
  ['shinL', /(left|^l[_.\s]|[_.]l$|_l_).*(shin|calf|lowerleg|knee|(?<!up)leg)|(calf|lowerleg|shin).*(left|[_.]l$)/i],
  ['shinR', /(right|^r[_.\s]|[_.]r$|_r_).*(shin|calf|lowerleg|knee|(?<!up)leg)|(calf|lowerleg|shin).*(right|[_.]r$)/i],
  ['thighL', /(left|^l[_.\s]|[_.]l$|_l_).*(thigh|upleg|upperleg|hip)|(thigh|upperleg).*(left|[_.]l$)/i],
  ['thighR', /(right|^r[_.\s]|[_.]r$|_r_).*(thigh|upleg|upperleg|hip)|(thigh|upperleg).*(right|[_.]r$)/i],
  ['head', /head/i],
  ['neck', /neck/i],
  ['chest', /chest|spine[_.]?0?[2-9]|upperspine|spine2|spine3/i],
  ['spine', /spine|abdomen|torso/i],
  ['hips', /hips|pelvis|root|^hip$/i],
];

function roleOf(name, used) {
  for (const [role, re] of ROLE_PATTERNS) if (!used.has(role) && re.test(name)) return role;
  for (const [role, re] of ROLE_PATTERNS) if (re.test(name)) return role; // plusieurs os pour un même rôle (ex. Spine1, Spine2)
  return null;
}

export function loadGLBCharacter(url, { height = 1.78, female = false, onStep = null } = {}) {
  return new Promise((resolve, reject) => {
    new GLTFLoader().load(url, (gltf) => {
      try { resolve(buildFromGLTF(gltf, { height, female, onStep })); } catch (e) { reject(e); }
    }, undefined, reject);
  });
}

export function buildFromGLTF(gltf, { height = 1.78, female = false, onStep = null } = {}) {
  const model = gltf.scene;
  let skinned = null;
  model.traverse((o) => {
    if (o.isMesh) {
      o.castShadow = true; o.receiveShadow = true;
      if (o.material && o.material.map) o.material.map.anisotropy = 4;
      if (o.isSkinnedMesh) { skinned = skinned || o; o.frustumCulled = false; }
    }
  });
  if (!skinned) throw new Error('Le GLB ne contient pas de maillage riggé (SkinnedMesh)');

  // mise à l'échelle du monde : hauteur réelle, pieds au sol, centré
  model.updateMatrixWorld(true);
  const box = new THREE.Box3().setFromObject(model);
  const size = box.getSize(new THREE.Vector3());
  const scale = height / Math.max(0.01, size.y);
  const pivot = new THREE.Group();
  model.scale.multiplyScalar(scale);
  model.updateMatrixWorld(true);
  const box2 = new THREE.Box3().setFromObject(model);
  const c = box2.getCenter(new THREE.Vector3());
  model.position.x -= c.x; model.position.z -= c.z; model.position.y -= box2.min.y;
  pivot.add(model);
  const root = new THREE.Group();
  root.add(pivot);

  const bones = skinned.skeleton.bones;
  const report = { file: 'GLB', bones: bones.length, triangles: 0, mapped: {}, clips: gltf.animations.map((a) => a.name), height: +(size.y * scale).toFixed(2), scale: +scale.toFixed(4) };
  model.traverse((o) => { if (o.isMesh) report.triangles += (o.geometry.index ? o.geometry.index.count : o.geometry.attributes.position.count) / 3; });

  // ---- clips intégrés au GLB (idle / walk / run) ----
  const clips = {};
  for (const a of gltf.animations) {
    const n = a.name.toLowerCase();
    if (/idle|stand/.test(n)) clips.idle = a; else if (/run|sprint/.test(n)) clips.run = a; else if (/walk/.test(n)) clips.walk = a;
  }
  const hasClips = clips.idle && clips.walk && clips.run;

  // ---- transfert des animations procédurales ----
  const used = new Set();
  const roleByBone = new Map();
  for (const b of bones) { const r = roleOf(b.name, used); if (r) { roleByBone.set(b, r); used.add(r); report.mapped[r] = (report.mapped[r] ? report.mapped[r] + ', ' : '') + b.name; } }
  const missing = ['hips', 'spine', 'head', 'thighL', 'thighR', 'shinL', 'shinR', 'armL', 'armR'].filter((r) => !used.has(r));
  report.missingRoles = missing;
  // rôle hérité de l'ancêtre le plus proche pour les os non reconnus
  const effRole = new Map();
  for (const b of bones) { let p = b; while (p && !roleByBone.has(p)) p = p.parent && p.parent.isBone ? p.parent : null; effRole.set(b, p ? roleByBone.get(p) : null); }

  // rotations de repos en espace « modèle » (racine de l'armature)
  const armatureRoot = bones[0].parent;
  armatureRoot.updateMatrixWorld(true);
  const rootInv = new THREE.Quaternion();
  armatureRoot.getWorldQuaternion(rootInv); rootInv.invert();
  const restLocal = new Map(), restModel = new Map();
  for (const b of bones) {
    restLocal.set(b, b.quaternion.clone());
    const q = new THREE.Quaternion(); b.getWorldQuaternion(q);
    restModel.set(b, rootInv.clone().multiply(q));
  }
  const hipsBone = bones.find((b) => roleByBone.get(b) === 'hips') || bones[0];
  const hipsRestPos = hipsBone.position.clone();
  const hipsWorldScale = new THREE.Vector3(); hipsBone.parent.getWorldScale(hipsWorldScale);

  // squelette « pilote » invisible : nos animations y tournent, puis sont recopiées
  const driver = createCharacter({ female, onStep });
  const dBones = driver.bones;
  driver.mesh.updateMatrixWorld(true);
  const dq = {}, dInv = new THREE.Quaternion(), tmp = new THREE.Quaternion();
  const target = new Map();
  const tq = new THREE.Quaternion(), pq = new THREE.Quaternion();

  function retarget() {
    driver.mesh.updateMatrixWorld(true);
    driver.mesh.getWorldQuaternion(dInv); dInv.invert();
    for (const role in dBones) { dBones[role].getWorldQuaternion(tmp); dq[role] = (dq[role] || new THREE.Quaternion()).copy(dInv).multiply(tmp); }
    // rotation cible en espace modèle = rotation du pilote * rotation de repos du modèle
    for (const b of bones) {
      const role = effRole.get(b);
      const rest = restModel.get(b);
      const t = target.get(b) || new THREE.Quaternion();
      if (role) t.copy(dq[role]).multiply(rest); else t.copy(rest);
      target.set(b, t);
    }
    for (const b of bones) {
      const t = target.get(b);
      const parentT = b.parent && b.parent.isBone ? target.get(b.parent) : null;
      if (parentT) b.quaternion.copy(pq.copy(parentT).invert().multiply(t));
      else b.quaternion.copy(pq.copy(restModel.get(b)).invert().multiply(t)).premultiply(restLocal.get(b));
    }
    // rebond du bassin (translation verticale)
    const dy = (dBones.hips.position.y - driver.hip0) / (hipsWorldScale.y || 1);
    hipsBone.position.copy(hipsRestPos); hipsBone.position.y += dy;
  }

  let mixer = null, actions = null, current = null;
  if (hasClips) {
    mixer = new THREE.AnimationMixer(model);
    actions = { idle: mixer.clipAction(clips.idle), walk: mixer.clipAction(clips.walk), run: mixer.clipAction(clips.run) };
    for (const a of Object.values(actions)) { a.play(); a.setEffectiveWeight(0); }
    actions.idle.setEffectiveWeight(1);
  }

  return {
    group: root, mesh: skinned, report, usesClips: !!hasClips,
    animate(dt, speed) {
      if (mixer) {
        const w = { idle: Math.max(0, 1 - speed / 1.5), walk: speed < 3.5 ? Math.min(1, speed / 1.5) : Math.max(0, 1 - (speed - 3.5) / 1.5), run: Math.max(0, Math.min(1, (speed - 3) / 2)) };
        const sum = w.idle + w.walk + w.run || 1;
        for (const k in actions) actions[k].setEffectiveWeight(w[k] / sum);
        actions.walk.timeScale = Math.max(0.6, speed / 1.4); actions.run.timeScale = Math.max(0.7, speed / 5.5);
        mixer.update(dt);
        driver.animate(dt, speed); // garde les bruits de pas synchronisés
        return;
      }
      driver.animate(dt, speed); retarget();
    },
    jumpPose() { if (mixer) return; driver.jumpPose(); retarget(); },
    sit() { driver.sit(); retarget(); },
  };
}
