// Mission 020, étape 7 — « Décoration intérieure » de la VILLA NOVA.
// Catalogue de meubles et de décorations achetés en FCFA virtuels (fauteuils, canapés, poufs, tables, consoles, étagères,
// bancs, plantes, lampadaires, sculptures, vases, tapis, aquarium, tableaux, miroirs, horloges, étagères murales), avec
// plusieurs modèles et 10 couleurs. Placement libre dans l'aile (devant le joueur, ou contre le mur qu'il regarde pour
// les objets muraux), rotation, déplacement, changement de modèle et de couleur, rangement dans la réserve. Règles de
// placement : jamais dans un mur ou un meuble, jamais devant une porte, un passage du personnel ou un point
// d'interaction. Les sièges posés sont utilisables (furniture.js). Jusqu'à 4 configurations enregistrées (objets placés,
// thèmes des chambres, éclairage). Tout est sauvegardé.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { colorize } from './vehicles.js';
import { VILLA, THEMES } from './villa.js';
import { fcfa } from './food-data.js';

const PI = Math.PI;
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
export const COLORS = [['Ivoire', 0xf4eedf], ['Sable', 0xd8c8a8], ['Cognac', 0x8a5a32], ['Bordeaux', 0x6a1a2a], ['Vert NOVA', 0x1f4a3a], ['Bleu nuit', 0x1f2a44], ['Or', 0xc9a24a], ['Noir', 0x1a1a1e], ['Terracotta', 0xb4532a], ['Gris perle', 0xb8bcc4]];
const GOLD = 0xc9a24a, WOOD = 0x3a2416, CHROME = 0xc8ccd2;
// type : [nom, catégorie, prix, modèles, couleur par défaut, empreinte [l, p], siège ?, mural ?]
export const CATALOG = {
  fauteuil: ['Fauteuil', 'Meubles', 250000, ['Club', 'Velours capitonné', 'Scandinave'], 2, [0.95, 0.9], 'fauteuil'],
  canape: ['Canapé 2 places', 'Meubles', 650000, ['Moderne', 'Chesterfield'], 1, [1.8, 0.9], 'canapé'],
  pouf: ['Pouf', 'Meubles', 60000, ['Rond', 'Carré'], 6, [0.55, 0.55], 'pouf'],
  table: ['Table d’appoint', 'Meubles', 90000, ['Marbre et or', 'Bois massif'], 0, [0.6, 0.6]],
  console: ['Console', 'Meubles', 300000, ['Dorée', 'Noyer'], 0, [1.4, 0.4]],
  etagere: ['Bibliothèque basse', 'Meubles', 180000, ['Classique', 'Design'], 2, [1.2, 0.4]],
  banc: ['Banc capitonné', 'Meubles', 150000, ['Velours'], 3, [1.3, 0.45], 'banc'],
  palmier: ['Palmier en pot', 'Plantes', 70000, ['Pot noir', 'Pot terracotta'], 7, [0.6, 0.6]],
  ficus: ['Ficus', 'Plantes', 55000, ['Pot blanc', 'Pot doré'], 0, [0.5, 0.5]],
  cactus: ['Cactus colonne', 'Plantes', 30000, ['Pot sable'], 1, [0.4, 0.4]],
  lampadaire: ['Lampadaire', 'Luminaires', 120000, ['Arc doré', 'Droit'], 6, [0.5, 0.5]],
  sculpture: ['Sculpture contemporaine en bois', 'Décoration', 200000, ['Abstraite', 'Spirale'], 2, [0.5, 0.5]],
  vase: ['Grand vase', 'Décoration', 45000, ['Céramique', 'Doré'], 0, [0.4, 0.4]],
  tapisR: ['Tapis rond', 'Décoration', 110000, ['Uni', 'Bordure dorée'], 3, [2.2, 2.2], null, false, true],
  tapisL: ['Grand tapis', 'Décoration', 160000, ['Uni', 'Bordure dorée'], 5, [3.0, 2.0], null, false, true],
  aquarium: ['Aquarium', 'Décoration', 400000, ['Tropical'], 7, [1.3, 0.5]],
  tableau: ['Tableau (œuvre au choix)', 'Murs', 150000, ['Lagune', 'Plage', 'Façades', 'Contemporain', 'Portrait', 'Marché', 'Savane', 'Or et nuit', 'Pilotis', 'Cotonou la nuit', 'Façade afro-brésilienne'], 6, [1.2, 0.1], null, true],
  miroir: ['Miroir mural', 'Murs', 90000, ['Rectangulaire', 'Rond'], 6, [0.9, 0.1], null, true],
  horloge: ['Horloge murale', 'Murs', 40000, ['Classique'], 7, [0.6, 0.1], null, true],
  etagereM: ['Étagère murale', 'Murs', 60000, ['Chêne', 'Noyer'], 2, [1.2, 0.3], null, true],
};
const ART = [0, 1, 2, 3, 4, 5, 6, 7, 13, 14, 15];

export class Decor {
  constructor(ctx) {
    Object.assign(this, ctx); // villa, luxe, furniture, ambiance, player, ui, economy, world, onSave
    this.owned = []; this.placed = {}; this.configs = []; this.uid = 1; this.placing = null; this.view = 'catalogue'; this.cat = 'Meubles';
    this.mat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.5, metalness: 0.1 });
    this.glowMat = new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false });
    this.dom = document.getElementById('decobar'); if (this.dom) this.dom.addEventListener('click', (e) => { const b = e.target.closest('[data-dk]'); if (b) { e.stopPropagation(); this.key(b.dataset.dk); } });
    this.meshes = {};
  }
  // ------------------------------------------------------------------ modèles 3D (fusionnés par objet)
  geo(it) {
    const [, , , , , [W, D]] = CATALOG[it.type], col = COLORS[it.color][1], P = [], G = [], A = [];
    const box = (x0, y0, z0, x1, y1, z1, c, list = P) => list.push(colorize(new THREE.BoxGeometry(Math.abs(x1 - x0) || 0.01, Math.abs(y1 - y0) || 0.01, Math.abs(z1 - z0) || 0.01).translate((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), c));
    const cyl = (x, y0, z, r0, r1, h, c, list = P, seg = 14) => list.push(colorize(new THREE.CylinderGeometry(r0, r1, h, seg).translate(x, y0 + h / 2, z), c));
    const sph = (x, y, z, r, c, sy = 1, list = P) => list.push(colorize(new THREE.SphereGeometry(r, 12, 8).scale(1, sy, 1).translate(x, y, z), c));
    const w = W / 2, d = D / 2, m = it.model;
    switch (it.type) {
      case 'fauteuil': case 'canape': {
        const leg = m === 2 && it.type === 'fauteuil' ? WOOD : GOLD; box(-w, 0.12, -d, w, 0.42, d, col); box(-w, 0.42, -d, w, m === 1 ? 0.95 : 0.9, -d + 0.22, col);
        for (const s of [-1, 1]) box(s * w - (s > 0 ? 0.18 : 0), 0.42, -d, s * w + (s > 0 ? 0 : 0.18), m === 1 && it.type === 'canape' ? 0.85 : 0.66, d, col);
        const n = it.type === 'canape' ? 2 : 1; for (let k = 0; k < n; k++) { const u = -w + 0.2 + (k + 0.5) * ((W - 0.4) / n); box(u - (W - 0.4) / n / 2 + 0.03, 0.42, -d + 0.24, u + (W - 0.4) / n / 2 - 0.03, 0.55, d - 0.03, 0xf4eedf); }
        if (m === 1) for (let k = 0; k < 6; k++) sph(-w + 0.2 + k * (W - 0.4) / 5, 0.7, -d + 0.23, 0.025, GOLD);
        for (const sx of [-1, 1]) for (const sz of [-1, 1]) box(sx * (w - 0.08) - 0.03, 0, sz * (d - 0.08) - 0.03, sx * (w - 0.08) + 0.03, 0.12, sz * (d - 0.08) + 0.03, leg); break;
      }
      case 'pouf': if (m === 0) cyl(0, 0, 0, 0.27, 0.27, 0.42, col, P, 18); else box(-0.27, 0, -0.27, 0.27, 0.42, 0.27, col); box(-0.2, 0.42, -0.2, 0.2, 0.43, 0.2, GOLD); break;
      case 'table': cyl(0, 0.52, 0, 0.3, 0.3, 0.04, m === 0 ? 0xece6dc : WOOD, P, 18); cyl(0, 0, 0, 0.04, 0.05, 0.52, m === 0 ? GOLD : WOOD, P, 8); cyl(0, 0, 0, 0.2, 0.2, 0.02, m === 0 ? GOLD : WOOD); break;
      case 'console': box(-w, 0.8, -d, w, 0.86, d, m === 0 ? 0xece6dc : 0x5a3a22); for (const s of [-1, 1]) box(s * (w - 0.1) - 0.04, 0, -d + 0.05, s * (w - 0.1) + 0.04, 0.8, d - 0.05, m === 0 ? GOLD : 0x5a3a22); sph(0.3, 0.98, 0, 0.12, col, 1.3); break;
      case 'etagere': box(-w, 0, -d, w, 1.0, d, m === 0 ? 0x5a3a22 : 0x1a1a1e); for (let s = 1; s < 3; s++) box(-w + 0.03, s * 0.33, -d, w - 0.03, s * 0.33 + 0.03, d + 0.01, m === 0 ? 0x8a6440 : col); for (let k = 0; k < 8; k++) box(-w + 0.1 + k * 0.13, 0.36, -0.1, -w + 0.18 + k * 0.13, 0.6 + (k % 3) * 0.03, 0.1, [0x6a1a2a, 0x1f2a44, 0x0b6e4f, 0xd8a830][k % 4]); sph(w - 0.2, 0.82, 0, 0.1, col); break;
      case 'banc': box(-w + 0.05, 0.3, -d + 0.03, w - 0.05, 0.47, d - 0.03, col); for (const s of [-1, 1]) box(s * (w - 0.15) - 0.03, 0, -d + 0.08, s * (w - 0.15) + 0.03, 0.3, d - 0.08, GOLD); break;
      case 'palmier': case 'ficus': case 'cactus': {
        const pot = it.type === 'palmier' ? (m === 0 ? 0x2a2d33 : 0xb4532a) : it.type === 'ficus' ? (m === 0 ? 0xf2f2f2 : GOLD) : 0xd8c8a8; cyl(0, 0, 0, 0.24, 0.19, 0.5, pot, P, 14);
        if (it.type === 'palmier') { cyl(0, 0.45, 0, 0.04, 0.06, 1.5, 0x6a4a2a, P, 6); for (let a = 0; a < 7; a++) P.push(colorize(new THREE.ConeGeometry(0.1, 1.0, 4).rotateZ(PI / 2.3).rotateY(a * 0.9).translate(Math.cos(a * 0.9) * 0.4, 1.95, -Math.sin(a * 0.9) * 0.4), 0x2f7a3a)); }
        else if (it.type === 'ficus') { cyl(0, 0.45, 0, 0.03, 0.04, 0.9, 0x6a4a2a, P, 6); for (let k = 0; k < 7; k++) sph(Math.cos(k * 1.3) * 0.16, 1.1 + (k % 3) * 0.16, Math.sin(k * 1.3) * 0.16, 0.24, k % 2 ? 0x2f7a3a : 0x3f9a4a, 0.8); }
        else { cyl(0, 0.45, 0, 0.1, 0.1, 1.1, 0x3f8a3a, P, 8); cyl(0.13, 0.8, 0, 0.05, 0.05, 0.4, 0x3f8a3a, P, 8); sph(0, 1.56, 0, 0.1, 0x3f8a3a); } break;
      }
      case 'lampadaire': cyl(0, 0, 0, 0.18, 0.2, 0.04, m === 0 ? GOLD : 0x1a1a1e);
        if (m === 0) { cyl(0, 0.04, 0, 0.022, 0.022, 1.9, GOLD, P, 6); for (let k = 0; k < 8; k++) { const a = (k / 8) * PI / 2, b2 = ((k + 1) / 8) * PI / 2; box(Math.sin(a) * 0.8 - 0.02, 1.94 - (1 - Math.cos(a)) * 0.25 - 0.02, -0.02, Math.sin(b2) * 0.8 + 0.02, 1.94 - (1 - Math.cos(a)) * 0.25 + 0.02, 0.02, GOLD); } cyl(0.8, 1.48, 0, 0.12, 0.2, 0.22, col); cyl(0.8, 1.46, 0, 0.18, 0.18, 0.02, 0xffe2a8, G); }
        else { cyl(0, 0.04, 0, 0.02, 0.02, 1.4, 0x1a1a1e, P, 6); cyl(0, 1.4, 0, 0.17, 0.22, 0.32, 0xffe2a8, G); } break;
      case 'sculpture': cyl(0, 0, 0, 0.22, 0.22, 0.8, 0xece6dc, P, 12); if (m === 0) { for (let k = 0; k < 4; k++) box(-0.06 + (k % 2) * 0.05, 0.8 + k * 0.18, -0.08, 0.08 + (k % 2) * 0.05, 0.98 + k * 0.18, 0.08, col); } else for (let k = 0; k < 10; k++) sph(Math.cos(k * 0.8) * 0.12, 0.85 + k * 0.07, Math.sin(k * 0.8) * 0.12, 0.06, col); break;
      case 'vase': sph(0, 0.35, 0, 0.2, m === 0 ? col : GOLD, 1.8); cyl(0, 0.62, 0, 0.07, 0.1, 0.2, m === 0 ? col : GOLD, P, 10); for (let k = 0; k < 5; k++) cyl(Math.cos(k) * 0.05, 0.8, Math.sin(k) * 0.05, 0.008, 0.008, 0.5 + (k % 2) * 0.15, 0x6a4a2a, P, 4); break;
      case 'tapisR': cyl(0, 0.015, 0, W / 2, W / 2, 0.02, m === 1 ? GOLD : col, P, 32); if (m === 1) cyl(0, 0.016, 0, W / 2 - 0.15, W / 2 - 0.15, 0.02, col, P, 32); break;
      case 'tapisL': box(-w, 0.015, -d, w, 0.035, d, m === 1 ? GOLD : col); if (m === 1) box(-w + 0.15, 0.016, -d + 0.15, w - 0.15, 0.036, d - 0.15, col); break;
      case 'aquarium': box(-w, 0, -d, w, 0.75, d, 0x1a1a1e); box(-w + 0.03, 0.75, -d + 0.03, w - 0.03, 1.35, d - 0.03, 0x3fa8d8, G); box(-w, 1.35, -d, w, 1.42, d, 0x1a1a1e); for (let k = 0; k < 6; k++) box(-w + 0.2 + k * 0.17, 0.85 + (k % 3) * 0.12, -0.05, -w + 0.27 + k * 0.17, 0.89 + (k % 3) * 0.12, 0.05, [0xff8a30, 0xfcd116, 0xe8112d][k % 3]); break;
      case 'tableau': { const i = ART[m] ?? 0, pl = new THREE.PlaneGeometry(1.1, 0.8), uv = pl.attributes.uv, u0 = (i % 4) / 4, v1 = 1 - Math.floor(i / 4) / 4; for (let k = 0; k < uv.count; k++) uv.setXY(k, u0 + uv.getX(k) * 0.25, v1 - 0.25 + uv.getY(k) * 0.25); A.push(pl.translate(0, 1.7, 0.05)); box(-0.61, 1.24, 0, 0.61, 2.16, 0.04, col); break; }
      case 'miroir': if (m === 0) { box(-0.45, 1.05, 0, 0.45, 2.25, 0.04, col); box(-0.4, 1.1, 0.04, 0.4, 2.2, 0.045, 0xd8e4ea); } else { P.push(colorize(new THREE.CylinderGeometry(0.45, 0.45, 0.04, 28).rotateX(PI / 2).translate(0, 1.7, 0.02), col)); P.push(colorize(new THREE.CylinderGeometry(0.4, 0.4, 0.01, 28).rotateX(PI / 2).translate(0, 1.7, 0.045), 0xd8e4ea)); } break;
      case 'horloge': P.push(colorize(new THREE.CylinderGeometry(0.3, 0.3, 0.04, 28).rotateX(PI / 2).translate(0, 1.9, 0.02), 0xf4eedf)); P.push(colorize(new THREE.TorusGeometry(0.3, 0.025, 6, 28).translate(0, 1.9, 0.04), col)); box(-0.012, 1.9, 0.045, 0.012, 2.1, 0.05, 0x1a1a1a); box(0, 1.89, 0.045, 0.16, 1.91, 0.05, 0x1a1a1a); break;
      case 'etagereM': box(-w, 1.5, 0, w, 1.54, 0.28, m === 0 ? 0x8a6440 : 0x5a3a22); for (let k = 0; k < 5; k++) { if (k % 2) sph(-w + 0.15 + k * 0.22, 1.66, 0.14, 0.09, col, 1.2); else box(-w + 0.08 + k * 0.22, 1.54, 0.06, -w + 0.22 + k * 0.22, 1.74, 0.22, [0x6a1a2a, 0x1f2a44, 0x0b6e4f][k % 3]); } break;
      default: box(-w, 0, -d, w, 0.5, d, col);
    }
    return { P, G, A };
  }
  build(it) {
    const { P, G, A } = this.geo(it), g = new THREE.Group();
    if (P.length) g.add(new THREE.Mesh(mergeGeometries(P), this.mat)); if (G.length) g.add(new THREE.Mesh(mergeGeometries(G), this.glowMat));
    if (A.length && this.luxe && this.luxe.mats) g.add(new THREE.Mesh(mergeGeometries(A), this.luxe.mats.art));
    g.userData.uid = it.uid; return g;
  }
  // ------------------------------------------------------------------ catalogue, réserve
  item(uid) { return this.owned.find((q) => q.uid === uid); }
  name(it) { const C = CATALOG[it.type]; return `${C[0]}${C[3].length > 1 ? ` « ${C[3][it.model]} »` : ''}`; }
  buy(type) {
    const C = CATALOG[type]; if (!C) return; if (this.owned.length >= 60) return this.ui.toast('La réserve est pleine (60 objets).', 2.5);
    if (!this.economy.pay(C[2], `Décoration intérieure — ${C[0]}`, 'Mobilier (boutique fictive)')) return this.ui.toast('Solde personnel insuffisant.', 2);
    const it = { uid: this.uid++, type, model: 0, color: C[4] }; this.owned.push(it); this.ui.toast(`🛋️ ${C[0]} acheté (${fcfa(C[2])}) : il t’attend dans la réserve.`, 2.5); this.onSave && this.onSave(); return it;
  }
  // ------------------------------------------------------------------ placement
  start(uid) {
    const it = this.item(uid); if (!it) return; if (!this.villa.inside) return this.ui.toast('Entre dans l’aile principale de la villa pour placer un objet.', 2.5);
    this.economy.togglePhone(false); this.unplace(uid, true);
    const prev = this.build(it); this.villa.inGroup.add(prev); this.placing = { it, mesh: prev, ry: this.player.facing + PI, ok: false };
    this.bar(); this.ui.toast(`🛋️ Placement : avance pour choisir l’endroit • R tourner • C couleur • M modèle • Entrée valider • Échap annuler`, 4);
  }
  wallSpot(fx, fz, dirx, dirz) { // mur ou grand meuble devant le joueur (objets muraux)
    const col = this.world.collision, lv = col.level; col.level = VILLA.LV; let hit = null;
    for (let t = 0.3; t < 3.5; t += 0.05) { const x = fx + dirx * t, z = fz + dirz * t; if (col.pointBlocked(VILLA.O.x + x, VILLA.Y + 3.0, VILLA.O.z + z)) { hit = { x: fx + dirx * (t - 0.08), z: fz + dirz * (t - 0.08) }; break; } }
    col.level = lv; return hit;
  }
  valid(it, x, z, ry) {
    const C = CATALOG[it.type], [W, D] = C[5], col = this.world.collision, lv = col.level, rug = C[8], wall = C[7]; col.level = VILLA.LV;
    const c = Math.cos(ry), s = Math.sin(ry), pts = [], nu = Math.max(2, Math.ceil(W / 0.15)), nv = Math.max(2, Math.ceil(D / 0.15));
    for (let i = 0; i <= nu; i++) for (let j = 0; j <= nv; j++) { const u = -W / 2 + (i / nu) * W, v = -D / 2 + (j / nv) * D; pts.push([x + u * c + v * s, z - u * s + v * c]); }
    let ok = true, why = '';
    const roomOf = (px, pz) => (Object.values(this.villa.rooms).find((q) => px >= q.x0 + 0.1 && px <= q.x1 - 0.1 && pz >= q.z0 + 0.1 && pz <= q.z1 - 0.1) || { id: 'couloirs' }).id, r0 = roomOf(x, z);
    if (pts.some(([px, pz]) => roomOf(px, pz) !== r0)) { ok = false; why = 'l’objet déborderait sur un mur ou une autre pièce'; }
    if (r0 === 'couloirs' && pts.some(([px, pz]) => px < -36.8 || px > 36.8 || (pz > 9.9 && px > -34) || (pz < 6.1 && pz > -9.9 && px > -34) || (pz < -13.9 && px > -34) || pz > 26.9 || pz < -30.9)) { ok = false; why = 'l’objet déborderait sur un mur'; }
    if (ok && !wall && !rug && pts.some(([px, pz]) => col.pointBlocked(VILLA.O.x + px, VILLA.Y + 0.3, VILLA.O.z + pz))) { ok = false; why = 'un mur ou un meuble gêne'; }
    if (rug && pts.some(([px, pz]) => col.pointBlocked(VILLA.O.x + px, VILLA.Y + 3.0, VILLA.O.z + pz))) { ok = false; why = 'le tapis passerait sous un mur'; }
    col.level = lv;
    const R = Object.values(this.villa.rooms).find((q) => x >= q.x0 && x <= q.x1 && z >= q.z0 && z <= q.z1);
    if (ok && !rug && !wall) { // portes, passages du personnel, points d'interaction
      const near = (a, b, r) => pts.some(([px, pz]) => Math.hypot(px - a, pz - b) < r);
      for (const q of Object.values(this.villa.rooms)) if (near(q.door.x, q.door.z, 1.4)) { ok = false; why = 'trop près d’une porte'; break; }
      if (ok && !R && pts.some(([px, pz]) => Math.abs(pz - 8) < 1.0 || Math.abs(pz + 12) < 1.0 || (px < -34 && Math.abs(px + 35.5) < 0.9 && pz < 10.2))) { ok = false; why = 'passage des couloirs'; }
      if (ok) { const F = this.furniture, spots = [...this.villa.points.map((q) => [q.x, q.z]), ...(F ? F.seats.filter((q) => !q.out && !q.decor).map((q) => [q.x, q.z]) : []), ...(F ? F.boxes.map((q) => [q.x, q.z]) : []), ...(this.ambiance ? this.ambiance.switches().map((q) => [q.x, q.z]) : [])]; if (spots.some(([a, b]) => near(a, b, 0.7))) { ok = false; why = 'devant un meuble ou un point d’interaction'; } }
    }
    if (ok && wall && !R && Math.abs(z - 8) < 2 && Math.abs(x + 35.5) > 1.5) { /* murs des couloirs : autorisés */ }
    return { ok, why, room: R ? R.id : 'couloirs' };
  }
  update() {
    const P = this.placing; if (!P) return; if (!this.villa.inside) return this.cancel();
    const pl = this.player, C = CATALOG[P.it.type], fx = pl.pos.x - VILLA.O.x, fz = pl.pos.z - VILLA.O.z, dx = Math.sin(pl.facing), dz = Math.cos(pl.facing);
    let x, z, ry = P.ry;
    if (C[7]) { const w = this.wallSpot(fx, fz, dx, dz); if (w) { x = w.x; z = w.z; ry = pl.facing + PI; } else { x = fx + dx * 1.5; z = fz + dz * 1.5; } }
    else { const dist = 1.2 + Math.max(C[5][0], C[5][1]) / 2; x = Math.round((fx + dx * dist) * 4) / 4; z = Math.round((fz + dz * dist) * 4) / 4; }
    P.x = x; P.z = z; P.cry = ry; P.mesh.position.set(x, 0, z); P.mesh.rotation.y = ry;
    const v = C[7] ? { ok: !!this.wallSpot(fx, fz, dx, dz), why: 'aucun mur devant toi', room: '' } : this.valid(P.it, x, z, ry);
    if (v.ok !== P.ok || v.why !== P.why) { P.ok = v.ok; P.why = v.why; this.bar(); }
    const t = performance.now() / 300; P.mesh.position.y = 0.02 + Math.sin(t) * 0.02;
  }
  key(k) {
    const P = this.placing; if (!P) return;
    if (k === 'rot') { P.ry += PI / 4; }
    else if (k === 'col') { P.it.color = (P.it.color + 1) % COLORS.length; this.rebuildPreview(); }
    else if (k === 'mod') { P.it.model = (P.it.model + 1) % CATALOG[P.it.type][3].length; this.rebuildPreview(); }
    else if (k === 'ok') return this.confirm();
    else if (k === 'no') return this.cancel();
    this.bar();
  }
  rebuildPreview() { const P = this.placing; this.villa.inGroup.remove(P.mesh); P.mesh = this.build(P.it); this.villa.inGroup.add(P.mesh); }
  handleKeys(input) { if (input.hit('KeyR')) this.key('rot'); if (input.hit('KeyC')) this.key('col'); if (input.hit('KeyM')) this.key('mod'); if (input.hit('Enter') || input.hit('NumpadEnter')) this.key('ok'); if (input.hit('Escape')) this.key('no'); }
  bar() {
    if (!this.dom) return; const P = this.placing; if (!P) { this.dom.classList.remove('show'); return; }
    const C = CATALOG[P.it.type];
    this.dom.innerHTML = `<span class="db-t"><b>${esc(this.name(P.it))}</b> • ${COLORS[P.it.color][0]} • ${P.ok ? '✅ emplacement libre' : `❌ ${esc(P.why || 'emplacement impossible')}`}</span>${C[7] ? '' : '<button data-dk="rot">⟳ Tourner (R)</button>'}<button data-dk="col">🎨 Couleur (C)</button>${C[3].length > 1 ? '<button data-dk="mod">🔁 Modèle (M)</button>' : ''}<button data-dk="ok" ${P.ok ? '' : 'disabled'}>✔ Poser (Entrée)</button><button data-dk="no">✖ Annuler</button>`;
    this.dom.classList.add('show');
  }
  // accès : depuis la porte de la pièce, on doit toujours pouvoir atteindre chaque point d'interaction (calcul de chemin)
  targets(R) {
    const inR = (x, z) => x >= R.x0 && x <= R.x1 && z >= R.z0 && z <= R.z1, F = this.furniture, T = this.villa.tv, out = [];
    for (const q of this.villa.points) if (q.room === R.id) out.push([q.x, q.z, q.r * 0.85]);
    if (F) { for (const q of F.seats) if (!q.out && !q.decor && inR(q.x, q.z)) out.push([q.x, q.z, 0.85]); for (const q of F.beds) if (q.room === R.id) out.push([q.x + q.bw / 2 + 0.45, q.z + q.sgn * 0.3, 0.9]); for (const q of F.boxes) if (inR(q.x, q.z)) out.push([q.x, q.z, 0.95]); }
    if (this.ambiance) for (const q of this.ambiance.switches()) if (q.id === R.id) out.push([q.x, q.z, 0.9]);
    if (T) for (const q of T.screens) if (q.room === R.id) { const pp = q.seat ? [q.seat.x, q.seat.z - 0.9] : [q.x + q.nx * (q.far ? 3 : 1.4), q.z + q.nz * (q.far ? 3 : 1.4)]; out.push([pp[0], pp[1], q.main ? 2.2 : 1.5]); }
    if (R.id === 'cuisine' && this.villa.cook) for (const q of this.villa.cook.spots()) out.push([q.x, q.z, 1.0]);
    return out;
  }
  access(R) {
    const col = this.world.collision, lv = col.level; col.level = VILLA.LV; const r0 = 0.3, bl = (x, z) => [[0, 0], [r0, 0], [-r0, 0], [0, r0], [0, -r0]].some(([a, c]) => col.pointBlocked(VILLA.O.x + x + a, VILLA.Y + 0.3, VILLA.O.z + z + c));
    const st = 0.25, nx = Math.round((R.x1 - R.x0) / st), nz = Math.round((R.z1 - R.z0) / st), seen = new Uint8Array((nx + 1) * (nz + 1)), idx = (i, j) => j * (nx + 1) + i;
    const sx = Math.round((R.door.x - R.x0) / st), sz = Math.round(((R.z0 === 10 ? R.z0 + 0.7 : R.z1 - 0.7) - R.z0) / st), q = [[sx, sz]]; seen[idx(sx, sz)] = 1;
    while (q.length) { const [i, j] = q.pop(); for (const [di, dj] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const a = i + di, c = j + dj; if (a < 0 || c < 0 || a > nx || c > nz || seen[idx(a, c)]) continue; if (bl(R.x0 + a * st, R.z0 + c * st)) continue; seen[idx(a, c)] = 1; q.push([a, c]); } }
    col.level = lv; const cells = []; for (let a = 0; a <= nx; a++) for (let c = 0; c <= nz; c++) if (seen[idx(a, c)]) cells.push([R.x0 + a * st, R.z0 + c * st]);
    return this.targets(R).every(([x, z, rad]) => cells.some(([cx, cz]) => Math.hypot(cx - x, cz - z) < rad + st * 0.6)); // marge : demi-case de la grille
  }
  confirm() { const P = this.placing; if (!P || !P.ok) return; this.villa.inGroup.remove(P.mesh); this.place(P.it, P.x, P.z, P.cry);
    const R = Object.values(this.villa.rooms).find((q) => P.x >= q.x0 && P.x <= q.x1 && P.z >= q.z0 && P.z <= q.z1);
    if (R && !CATALOG[P.it.type][7] && !CATALOG[P.it.type][8] && !this.access(R)) { this.unplace(P.it.uid, true); this.villa.inGroup.add(P.mesh); P.ok = false; P.why = 'bloquerait l’accès à un meuble ou à un équipement'; this.bar(); return this.ui.toast('❌ Ici, l’objet couperait le passage vers un lit, un siège, un rangement ou un équipement.', 3); }
    this.placing = null; this.bar(); this.ui.toast(`✅ ${this.name(P.it)} posé.`, 1.8); this.onSave && this.onSave(); }
  cancel() { const P = this.placing; if (!P) return; this.villa.inGroup.remove(P.mesh); this.placing = null; this.bar(); this.ui.toast('Placement annulé : l’objet est dans la réserve.', 2); }
  place(it, x, z, ry) {
    this.unplace(it.uid, true); const C = CATALOG[it.type], g = this.build(it); g.position.set(x, 0, z); g.rotation.y = ry; this.villa.inGroup.add(g);
    const rec = { x, z, ry, mesh: g, col: null, seat: null }; this.placed[it.uid] = rec;
    if (!C[7] && !C[8]) { const [W, D] = C[5], c = Math.abs(Math.cos(ry)), s = Math.abs(Math.sin(ry)), hx = (W * c + D * s) / 2, hz = (W * s + D * c) / 2, h = it.type === 'tapisR' ? 0 : 1.0; const o = this.world.collision.addBox(VILLA.O.x + x - hx, VILLA.O.z + z - hz, VILLA.O.x + x + hx, VILLA.O.z + z + hz, VILLA.Y + h); o.lv = VILLA.LV; rec.col = o; }
    if (C[6] && this.furniture) { const st = { x: x + Math.sin(ry) * 0.05, z: z + Math.cos(ry) * 0.05, ry, kind: C[6] === 'pouf' ? 'pouf' : C[6], decor: true }; st.room = (Object.values(this.villa.rooms).find((q) => x >= q.x0 && x <= q.x1 && z >= q.z0 && z <= q.z1) || {}).id || 'couloirs'; this.furniture.seats.push(st); rec.seat = st; }
  }
  unplace(uid, silent) {
    const rec = this.placed[uid]; if (!rec) return; this.villa.inGroup.remove(rec.mesh); if (rec.col) rec.col.disabled = true;
    if (rec.seat && this.furniture) { const i = this.furniture.seats.indexOf(rec.seat); if (i >= 0) this.furniture.seats.splice(i, 1); }
    delete this.placed[uid]; if (!silent) { this.ui.toast('Objet rangé dans la réserve.', 1.8); this.onSave && this.onSave(); }
  }
  recolor(uid, dc = 1) { const it = this.item(uid), rec = this.placed[uid]; if (!it) return; it.color = (it.color + dc + COLORS.length) % COLORS.length; if (rec) this.place(it, rec.x, rec.z, rec.ry); this.onSave && this.onSave(); }
  remodel(uid) { const it = this.item(uid), rec = this.placed[uid]; if (!it) return; it.model = (it.model + 1) % CATALOG[it.type][3].length; if (rec) this.place(it, rec.x, rec.z, rec.ry); this.onSave && this.onSave(); }
  turn(uid) { const it = this.item(uid), rec = this.placed[uid]; if (!it || !rec || CATALOG[it.type][7]) return; const ry = rec.ry + PI / 4; if (!this.valid(it, rec.x, rec.z, ry).ok && !CATALOG[it.type][8]) { const keep = rec; this.unplace(uid, true); const v = this.valid(it, keep.x, keep.z, ry); this.place(it, keep.x, keep.z, v.ok ? ry : keep.ry); if (!v.ok) this.ui.toast(`Impossible de tourner : ${v.why}.`, 2); } else this.place(it, rec.x, rec.z, ry); this.onSave && this.onSave(); }
  sell(uid) { const it = this.item(uid); if (!it) return; this.unplace(uid, true); this.owned = this.owned.filter((q) => q.uid !== uid); const back = Math.round(CATALOG[it.type][2] * 0.5); this.economy.earn(back, `Revente d’un objet de décoration — ${CATALOG[it.type][0]}`, 'Mobilier (boutique fictive)'); this.ui.toast(`Revendu ${fcfa(back)} (50 % du prix).`, 2); this.onSave && this.onSave(); }
  // ------------------------------------------------------------------ interactions dans la villa (touche E)
  nearest(x, z) {
    if (!this.villa.inside || this.placing) return null; const O = VILLA.O; let best = null;
    for (const [uid, r] of Object.entries(this.placed)) { const d = Math.hypot(x - (O.x + r.x), z - (O.z + r.z)); const it = this.item(+uid); if (!it) continue; const rr = CATALOG[it.type][7] ? 1.3 : 1.2; if (d < rr && (!best || d < best.d)) best = { d: d + 0.35, it: { label: () => `Décoration : ${this.name(it)}`, action: () => this.menu(+uid) } }; }
    return best;
  }
  menu(uid) {
    const it = this.item(uid); if (!it) return; const C = CATALOG[it.type];
    this.ui.openMenu(`🛋️ ${this.name(it)}`, `${COLORS[it.color][0]} • ${C[1]}`, [
      { label: '✋ Déplacer', action: () => this.start(uid) }, ...(C[7] ? [] : [{ label: '⟳ Tourner de 45°', action: () => this.turn(uid) }]),
      { label: `🎨 Couleur suivante (${COLORS[(it.color + 1) % COLORS.length][0]})`, action: () => { this.recolor(uid); this.menu(uid); } },
      ...(C[3].length > 1 ? [{ label: `🔁 Modèle suivant (${C[3][(it.model + 1) % C[3].length]})`, action: () => { this.remodel(uid); this.menu(uid); } }] : []),
      { label: '📦 Ranger dans la réserve', action: () => this.unplace(uid) },
    ]);
  }
  // ------------------------------------------------------------------ configurations
  snapshot(name) { return { name, at: this.economy.stamp(), place: Object.fromEntries(Object.entries(this.placed).map(([u, r]) => [u, [r.x, r.z, r.ry]])), themes: { ...(this.villa.decor || {}) }, light: this.ambiance ? JSON.parse(JSON.stringify(this.ambiance.set)) : null }; }
  saveConfig(i) { this.configs[i] = this.snapshot(this.configs[i] ? this.configs[i].name : `Configuration ${i + 1}`); this.ui.toast(`💾 Décoration enregistrée : « ${this.configs[i].name} ».`, 2.2); this.onSave && this.onSave(); }
  loadConfig(i) {
    const c = this.configs[i]; if (!c) return; for (const u of Object.keys(this.placed)) this.unplace(+u, true);
    let miss = 0; for (const [u, [x, z, ry]] of Object.entries(c.place)) { const it = this.item(+u); if (it) this.place(it, x, z, ry); else miss++; }
    if (c.themes) { this.villa.decor = { ...c.themes }; this.villa.applyDecor(); } if (c.light && this.ambiance) { this.ambiance.restore({ set: c.light }); }
    this.ui.toast(`🔄 « ${c.name} » appliquée${miss ? ` (${miss} objet(s) revendu(s) absent(s))` : ''}.`, 2.5); this.onSave && this.onSave();
  }
  // ------------------------------------------------------------------ application « Décoration intérieure »
  renderApp(b) {
    const tabs = [['catalogue', 'Catalogue'], ['reserve', `Réserve (${this.owned.filter((q) => !this.placed[q.uid]).length})`], ['places', `Placés (${Object.keys(this.placed).length})`], ['configs', 'Configurations']], v = this.view;
    let h = `<h4>🛋️ Décoration intérieure</h4><p class="ph-note">Achète (FCFA virtuels), place, déplace, tourne, change le modèle et la couleur des objets ; enregistre jusqu’à 4 configurations (objets, thèmes des chambres, éclairage).</p><div class="ph-chips">${tabs.map(([k, l]) => `<button data-dec="tab:${k}" class="${k === v ? 'on' : ''}">${l}</button>`).join('')}</div>`;
    if (v === 'catalogue') { const cats = [...new Set(Object.values(CATALOG).map((q) => q[1]))]; h += `<div class="ph-chips">${cats.map((c) => `<button data-dec="cat:${c}" class="${c === this.cat ? 'on' : ''}">${c}</button>`).join('')}</div>${Object.entries(CATALOG).filter(([, q]) => q[1] === this.cat).map(([k, q]) => `<div class="ph-row"><span><b>${esc(q[0])}</b><small>${q[3].length} modèle(s) : ${q[3].slice(0, 4).map(esc).join(', ')}${q[3].length > 4 ? '…' : ''} • 10 couleurs${q[6] ? ' • on peut s’y asseoir' : ''}</small></span><button class="ph-mini" data-dec="buy:${k}">${fcfa(q[2])}</button></div>`).join('')}`; }
    else if (v === 'reserve') { const list = this.owned.filter((q) => !this.placed[q.uid]); h += list.length ? list.map((it) => `<div class="ph-row"><span><b>${esc(this.name(it))}</b><small>${COLORS[it.color][0]}</small></span><span class="pp-acts"><button class="ph-mini" data-dec="place:${it.uid}">Placer</button><button class="ph-mini" data-dec="sell:${it.uid}">Revendre</button></span></div>`).join('') : '<p class="ph-note">La réserve est vide : achète des objets dans le catalogue.</p>'; }
    else if (v === 'places') { const list = this.owned.filter((q) => this.placed[q.uid]); h += list.length ? list.map((it) => { const r = this.placed[it.uid], R = Object.values(this.villa.rooms).find((q) => r.x >= q.x0 && r.x <= q.x1 && r.z >= q.z0 && r.z <= q.z1); return `<div class="ph-row"><span><b>${esc(this.name(it))}</b><small>${R ? esc(R.name) : 'Couloirs et hall'} • ${COLORS[it.color][0]}</small></span><span class="pp-acts"><button class="ph-mini" data-dec="col:${it.uid}">🎨</button>${CATALOG[it.type][3].length > 1 ? `<button class="ph-mini" data-dec="mod:${it.uid}">🔁</button>` : ''}<button class="ph-mini" data-dec="place:${it.uid}">✋</button><button class="ph-mini" data-dec="un:${it.uid}">📦</button></span></div>`; }).join('') : '<p class="ph-note">Aucun objet posé.</p>'; }
    else { h += [0, 1, 2, 3].map((i) => { const c = this.configs[i]; return `<div class="ph-row"><span><b>${c ? esc(c.name) : `Emplacement ${i + 1} (vide)`}</b><small>${c ? `${Object.keys(c.place).length} objet(s) • thèmes des chambres et éclairage • ${c.at}` : 'Enregistre la décoration actuelle'}</small></span><span class="pp-acts"><button class="ph-mini" data-dec="save:${i}">💾</button>${c ? `<button class="ph-mini" data-dec="load:${i}">Appliquer</button>` : ''}</span></div>`; }).join('') + `<h5>Thèmes des chambres</h5><p class="ph-note">Murs et linge de lit : ${THEMES.length} thèmes, dans « Ma Villa » (🎨) ou ici :</p>${Object.values(this.villa.rooms).filter((R) => R.mats).map((R) => `<div class="ph-row"><span><b>${esc(R.name)}</b><small>${THEMES[this.villa.decor[R.id] || 0][0]}</small></span><button class="ph-mini" data-dec="theme:${R.id}">🎨</button></div>`).join('')}`; }
    b.innerHTML = h;
  }
  onPhone(v) {
    const [a, arg] = v.split(':');
    if (a === 'tab') this.view = arg; else if (a === 'cat') this.cat = arg; else if (a === 'buy') this.buy(arg);
    else if (a === 'place') return this.start(+arg); else if (a === 'sell') this.sell(+arg); else if (a === 'un') this.unplace(+arg);
    else if (a === 'col') this.recolor(+arg); else if (a === 'mod') this.remodel(+arg);
    else if (a === 'save') this.saveConfig(+arg); else if (a === 'load') this.loadConfig(+arg);
    else if (a === 'theme') { this.villa.cycleDecor(arg); this.villa.onSave && this.villa.onSave(); }
    this.economy.renderPhone();
  }
  serialize() { return { owned: this.owned, place: Object.fromEntries(Object.entries(this.placed).map(([u, r]) => [u, [r.x, r.z, r.ry]])), configs: this.configs, uid: this.uid }; }
  restore(s) { if (!s) return; this.owned = s.owned || []; this.configs = s.configs || []; this.uid = s.uid || (Math.max(0, ...this.owned.map((q) => q.uid)) + 1); for (const [u, [x, z, ry]] of Object.entries(s.place || {})) { const it = this.item(+u); if (it) this.place(it, x, z, ry); } }
}
