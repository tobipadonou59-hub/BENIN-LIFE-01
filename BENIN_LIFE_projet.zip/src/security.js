// Mission 018 — sécurité personnelle (système fictif et NON VIOLENT : les gardes protègent, accueillent,
// orientent, accompagnent et signalent ; ils ne s'en prennent jamais aux habitants).
// Étape 1 : 4 gardes du corps à la résidence (entrée principale, cour, garage), animations (garde à vous,
// ronde, discussion entre collègues, salut au PDG), accompagnement à pied du joueur (formation derrière lui,
// attente devant les bâtiments, montée dans les véhicules), retour au poste, application « Sécurité personnelle ».
// Étape 2 : 14 gardes devant les sièges NOVA (4 NOVA BOOK, 2 par filiale) : accueil du PDG, salut et orientation des
// visiteurs vers la réception, accompagnement à l'intérieur de leur bâtiment, signalements de situations inhabituelles
// (toujours résolues sans violence : réception, maintenance, secours), affectations modifiables.
import * as THREE from 'three';
import { createCharacter, SKINS } from './character.js';
import { HOME } from './home.js';
import { regionZone } from './region-geo.js';

const PI = Math.PI;
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const ang = (a) => Math.atan2(Math.sin(a), Math.cos(a));
// postes de la résidence (lot : x −62…−22, z 110…142 ; portillon x −44,5 ; portail x −32 ; garage x −36…−28)
export const HOME_POSTS = [
  { id: 'entree_g', label: 'Entrée principale (gauche du portillon)', x: -46.6, z: 108.3, ry: PI, zone: 'Résidence — entrée' },
  { id: 'entree_d', label: 'Entrée principale (droite du portillon)', x: -42.4, z: 108.3, ry: PI, zone: 'Résidence — entrée' },
  { id: 'cour', label: 'Cour intérieure (ronde)', x: -51, z: 114, ry: PI, zone: 'Résidence — cour', patrol: [[-51, 114], [-40, 114.6], [-51, 114]] },
  { id: 'garage', label: 'Près des garages', x: -28.2, z: 116.6, ry: PI, zone: 'Résidence — garage' },
];
const ROSTER = [
  { id: 'g1', name: 'Rodrigue Akpaki', rank: 'Chef d’équipe', female: false, skin: SKINS[3], post: 'entree_g', escort: true },
  { id: 'g2', name: 'Prudence Hounkanrin', rank: 'Agente de protection', female: true, skin: SKINS[1], post: 'entree_d', escort: true },
  { id: 'g3', name: 'Firmin Dossa', rank: 'Agent de protection', female: false, skin: SKINS[0], post: 'cour', escort: false },
  { id: 'g4', name: 'Abel Kouton', rank: 'Agent de protection', female: false, skin: SKINS[2], post: 'garage', escort: false },
];
const CHAT = ['« Tout est calme ce matin. »', '« Tu as vu le match hier soir ? »', '« Relève à 18 h, n’oublie pas. »', '« Le portail a bien été vérifié. »', '« Il fait chaud, pense à boire de l’eau. »'];
const HELLO = ['Bonjour Monsieur le PDG !', 'Mes respects, Monsieur le PDG.', 'Bonne journée, Monsieur le PDG.', 'À votre service, Monsieur le PDG.'];
const SITE_ROSTER = [
  ['b1', 'Gérard Ahoyo', 'Chef de poste', false, 'book'], ['b2', 'Victorine Agossou', 'Agente de sécurité', true, 'book'], ['b3', 'Paterne Houngbo', 'Agent de sécurité', false, 'book'], ['b4', 'Josias Fagla', 'Agent de sécurité', false, 'book'],
  ['d1', 'Serge Ayena', 'Chef de poste', false, 'digital'], ['d2', 'Mireille Lokonon', 'Agente de sécurité', true, 'digital'],
  ['m1', 'Christian Gnonlonfoun', 'Chef de poste', false, 'media'], ['m2', 'Pélagie Dossou', 'Agente de sécurité', true, 'media'],
  ['i1', 'Olivier Ahouandogbo', 'Chef de poste', false, 'immo'], ['i2', 'Basile Toffa', 'Agent de sécurité', false, 'immo'],
  ['t1', 'Aristide Kpossou', 'Chef de poste', false, 'transport'], ['t2', 'Rosalie Ahanhanzo', 'Agente de sécurité', true, 'transport'],
  ['s1', 'Hippolyte Gbèdo', 'Chef de poste', false, 'distribution'], ['s2', 'Félicité Aïhou', 'Agente de sécurité', true, 'distribution'],
];
const TIE = { maison: 0x0d0e10, book: 0x008751, digital: 0x2f80ed, media: 0x7a2a8a, immo: 0x0b6e4f, transport: 0xe46a1f, distribution: 0xc8a020 };
const INC = {
  colis: { t: '📦 Colis sans étiquette déposé devant l’entrée', auto: 'La zone a été balisée et la réception a joint le livreur : c’était une livraison de fournitures mal étiquetée.' },
  enfant: { t: '🧒 Enfant égaré à l’accueil', auto: 'L’enfant a été confié à la réception ; ses parents ont été retrouvés grâce à l’annonce.' },
  stationnement: { t: '🚗 Véhicule garé devant l’entrée des livraisons', auto: 'Le propriétaire a été retrouvé poliment et a déplacé son véhicule.' },
  panne: { t: '⚡ Coupure de courant au portique d’entrée', help: [['tech', 'Envoyer un technicien (40 000 FCFA, trésorerie de la société)'], ['wait', 'Attendre le service du quartier']] },
  malaise: { t: '🚑 Un passant fait un malaise devant le bâtiment', help: [['secours', 'Appeler les secours et rester auprès de lui']] },
  visiteur: { t: '🙋 Visiteur sans rendez-vous qui demande à voir le PDG', help: [['recevoir', 'Le recevoir quelques minutes'], ['rdv', 'Lui proposer un rendez-vous via la réception']] },
};
const inLot = (x, z) => x > HOME.lot.x0 - 1 && x < HOME.lot.x1 + 1 && z > HOME.lot.z0 - 2.5 && z < HOME.lot.z1 + 1;

export class Security {
  constructor(ctx) {
    Object.assign(this, ctx); // scene, world, player, ui, audio, env, economy, onSave, isInside()
    this.guards = []; this.autoEscort = true; this.chatT = 12; this.open = false; this.hello = 0; this.incidents = []; this.incUid = 1; this.nextInc = null; this.welcomed = {}; this.selG = null;
    this.posts = HOME_POSTS.map((p) => ({ ...p, site: 'maison' })); this.sites = [{ id: 'maison', name: 'Résidence', door: { x: -44.5, z: 109.5 } }]; this.buildSites();
    for (const r of ROSTER) this.add(r);
    for (const [id, name, rank, female, site] of SITE_ROSTER) { const slot = this.freeSlot(site); if (slot) this.add({ id, name, rank, female, skin: SKINS[(id.charCodeAt(0) + +id[1]) % SKINS.length], post: slot.id, escort: false, assign: site }); }
  }
  add(r) { // un seul garde par identifiant (pas de doublon)
    if (this.guards.some((g) => g.id === r.id)) return null;
    const c = createCharacter({ female: r.female, skin: r.skin, shirtColor: 0xf4f4f4, pants: 0x15171a, skirt: false, headwrap: false, jacket: 0x15171a, tie: TIE[r.assign || 'maison'] || 0x0d0e10, collar: true, glasses: 0x050505, shoes: 0x0a0a0a, watch: 0xc8ccd0 });
    // oreillette et insigne « SÉCURITÉ »
    const ear = new THREE.Mesh(new THREE.SphereGeometry(0.022, 8, 6), new THREE.MeshStandardMaterial({ color: 0x111111 })); ear.position.set(0.095, 0.08, 0.0); c.bones.head.add(ear);
    const coil = new THREE.Mesh(new THREE.CylinderGeometry(0.004, 0.004, 0.22, 4), new THREE.MeshStandardMaterial({ color: 0xd8dde2 })); coil.position.set(0.1, -0.04, -0.03); coil.rotation.x = 0.3; c.bones.head.add(coil);
    const badge = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.035, 0.01), new THREE.MeshStandardMaterial({ color: 0xd8a830, metalness: 0.7, roughness: 0.3 })); badge.position.set(-0.07, 0.1, 0.135); c.bones.chest.add(badge);
    this.scene.add(c.group);
    const P = this.post(r.post) || HOME_POSTS[0];
    const g = { assign: 'maison', ...r, c, x: P.x, z: P.z, h: P.ry, mode: 'poste', speed: 0, act: null, actT: 0, pi: 0, wait: 0, saluted: -99, stuck: 0 };
    this.guards.push(g); this.place(g); return g;
  }
  post(id) { return this.posts.find((p) => p.id === id) || null; }
  // postes devant les sièges NOVA : tour NOVA BOOK (porte x 57–61, façade z 16) et entrées signalées des filiales
  buildSites() {
    const mk = (site, name, ox, oz, ry, n) => { const nx = Math.sin(ry), nz = Math.cos(ry), lx = Math.cos(ry), lz = -Math.sin(ry);
      this.sites.push({ id: site, name, door: { x: ox, z: oz }, ry });
      const slots = [[1.0, 2.3], [1.0, -2.3], [2.6, 4.2], [2.6, -4.2], [3.6, 1.2], [3.6, -1.2]];
      slots.slice(0, n).forEach(([o, l], i) => this.posts.push({ id: `${site}_${i + 1}`, site, label: `${name} — ${i < 2 ? 'de part et d’autre de l’entrée' : 'parvis'} (${l > 0 ? 'gauche' : 'droite'})`, x: ox + nx * o + lx * l, z: oz + nz * o + lz * l, ry, zone: `Devant ${name}` }));
    };
    mk('book', 'NOVA BOOK', 59, 15.2, PI, 6);
    for (const st of (this.offices && this.offices.sites) || []) mk(st.id, st.def.name, st.out.x, st.out.z, st.ry, 4);
  }
  site(id) { return this.sites.find((q) => q.id === id) || null; }
  freeSlot(site) { return this.posts.find((p) => p.site === site && !p.patrolOnly && !this.guards.some((g) => g.post === p.id)) || null; }
  reassign(g, site) {
    if (!g || g.assign === site) return; const slot = this.freeSlot(site); if (!slot) return this.ui.toast('Aucun poste libre à cette affectation.', 2);
    g.assign = site; g.post = slot.id; g.mode = 'poste'; g.x = slot.x; g.z = slot.z; g.h = slot.ry; g.y = 0; this.place(g);
    this.ui.toast(`🛡️ ${g.name} est affecté${g.female ? 'e' : ''} : ${this.site(site).name}.`, 2.5); this.onSave && this.onSave();
  }
  insideSite() { if (this.nova && this.nova.inside) return 'book'; if (this.offices && this.offices.inside >= 0 && this.offices.site) return this.offices.site.id; return null; }
  place(g) { g.c.group.position.set(g.x, g.y || 0, g.z); g.c.group.rotation.y = g.h; }
  // ------------------------------------------------------------------ ordres
  setMode(g, mode, quiet) {
    if (!g) return; g.mode = mode; g.wait = 0;
    if (mode === 'escorte' && !g.c.group.visible) { this.dropNear(g); }
    if (!quiet) this.ui.toast(`${g.name.split(' ')[0]} : « ${mode === 'escorte' ? 'Je vous accompagne, Monsieur le PDG.' : mode === 'poste' ? 'Je retourne à mon poste.' : 'Bien reçu, je reste ici.'} »`, 2.5);
    this.onSave && this.onSave();
  }
  allEscort() { for (const g of this.guards.filter((q) => q.assign === 'maison')) this.setMode(g, 'escorte', true); this.ui.toast('🛡️ Toute l’équipe de la résidence vous accompagne.', 2.5); }
  allPost() { for (const g of this.guards) this.setMode(g, 'poste', true); this.ui.toast('🛡️ Chaque garde retourne à son poste.', 2.5); }
  escorting() { return this.guards.filter((g) => g.mode === 'escorte'); }
  dropNear(g) { // le garde rejoint le joueur (sortie de véhicule, chargement) : derrière lui, hors de la vue directe
    const ep = g.inBld === undefined || !g.inBld ? (this.escort && this.escort.exitPoint()) : null, P0 = this.player.pos;
    if (ep && g.mode === 'escorte' && Math.hypot(ep.x - P0.x, ep.z - P0.z) < 40 && !(this.player.floorY > 50)) { // il descend du véhicule d'escorte
      const k = this.escorting().indexOf(g), C = this.world.collision;
      for (const r of [2.2, 3, 1.6]) { const a = k * 1.3 + r, x = ep.x + Math.cos(a) * r, z = ep.z + Math.sin(a) * r; if (!C.pointBlocked(x, 1, z)) { g.x = x; g.z = z; g.c.group.visible = true; this.place(g); return; } }
    }
    const p = this.player.pos, f = this.player.facing || 0, i = this.escorting().indexOf(g);
    const off = this.slot(i < 0 ? 0 : i), C = this.world.collision;
    for (const k of [1, 1.5, 0.6, 2.2]) { const x = p.x - Math.sin(f) * off.b * k + Math.cos(f) * off.s, z = p.z - Math.cos(f) * off.b * k - Math.sin(f) * off.s; if (!C.pointBlocked(x, 1, z)) { g.x = x; g.z = z; break; } }
    g.c.group.visible = true; g.h = f; this.place(g);
  }
  slot(i) { return [{ b: 2.2, s: 1.3 }, { b: 2.2, s: -1.3 }, { b: 3.6, s: 1.0 }, { b: 3.6, s: -1.0 }, { b: 4.8, s: 0 }][i % 5]; }
  // ------------------------------------------------------------------ déplacement
  walk(g, tx, tz, maxSpeed, dt) {
    const dx = tx - g.x, dz = tz - g.z, d = Math.hypot(dx, dz);
    const want = d < 0.25 ? 0 : Math.min(maxSpeed, d * 1.6 + 0.4);
    g.speed += (want - g.speed) * Math.min(1, dt * 4);
    if (d > 0.05 && g.speed > 0.05) {
      const st = Math.min(d, g.speed * dt), px = g.x, pz = g.z;
      g.x += (dx / d) * st; g.z += (dz / d) * st;
      const q = { x: g.x, z: g.z }; if (this.world.collision.level < 100) this.world.collision.resolve(q, 0.32); g.x = q.x; g.z = q.z;
      const moved = Math.hypot(g.x - px, g.z - pz); g.stuck = moved < st * 0.3 ? g.stuck + dt : 0;
      g.h += ang(Math.atan2(dx, dz) - g.h) * Math.min(1, dt * 8);
    }
    return d;
  }
  // ------------------------------------------------------------------ boucle
  update(dt) {
    const pl = this.player, P = pl.pos, inside = this.isInside ? this.isInside() : false, inVeh = !!pl.inCar || !!(this.transport && this.transport.riding) || !!(this.chauffeur && this.chauffeur.ride && ['riding', 'choose'].includes(this.chauffeur.ride.phase)), atHome = inLot(P.x, P.z);
    // escorte automatique : quand le PDG sort de la résidence, l'équipe d'escorte le suit ; elle revient quand il rentre
    if (this.autoEscort && !inside) {
      if (!atHome && !this._out) { this._out = true; const team = this.guards.filter((g) => g.escort && g.assign === 'maison' && g.mode === 'poste'); for (const g of team) { g.mode = 'escorte'; g.auto = true; } if (team.length) this.ui.toast(`🛡️ ${team.map((g) => g.name.split(' ')[0]).join(' et ')} vous accompagnent.`, 2.5); }
      else if (atHome && this._out) { this._out = false; for (const g of this.guards) if (g.auto && g.mode === 'escorte') { g.mode = 'poste'; g.auto = false; } }
    }
    this.hello -= dt; this.chatT -= dt; this.clock = (this.clock || 0) + dt;
    // discussion entre collègues aux deux postes d'entrée
    if (this.chatT <= 0) { this.chatT = 22 + Math.random() * 18; const a = this.guards.find((g) => g.post === 'entree_g' && g.mode === 'poste'), b = this.guards.find((g) => g.post === 'entree_d' && g.mode === 'poste'); const ap = this.post(a && a.post), bp = this.post(b && b.post); if (a && b && Math.hypot(a.x - ap.x, a.z - ap.z) < 0.6 && Math.hypot(b.x - bp.x, b.z - bp.z) < 0.6 && Math.hypot(P.x - a.x, P.z - a.z) > 3) { a.act = b.act = 'chat'; a.actT = b.actT = 6; a.peer = b; b.peer = a; if (Math.hypot(P.x - a.x, P.z - a.z) < 12 && !inVeh) this.ui.toast(`Les gardes discutent : ${CHAT[Math.floor(Math.random() * CHAT.length)]}`, 2.5); } }
    const esc = this.escorting();
    for (const g of this.guards) {
      let speed = 0;
      const far = Math.hypot(P.x - g.x, P.z - g.z);
      if (g.mode === 'escorte') {
        if (inVeh) { g.c.group.visible = false; g.inVeh = true; continue; } // il monte dans le véhicule
        if (g.inVeh) { g.inVeh = false; this.dropNear(g); }
        const inMine = inside && g.assign !== 'maison' && this.insideSite() === g.assign; // garde d'entreprise : il entre avec le PDG dans SON bâtiment
        if (inside && !inMine) { g.waiting = true; } // attend devant le bâtiment
        else {
          if (inMine && !g.inBld) { g.inBld = true; g.y = pl.floorY || 0; this.dropNear(g); }
          if (!inside && g.inBld) { g.inBld = false; g.y = 0; this.dropNear(g); }
          if (inMine) g.y = pl.floorY || 0;
          if (g.waiting && far > 30) this.dropNear(g); g.waiting = false;
          const St = g.assign !== 'maison' && !inside && this.site(g.assign);
          if (St && Math.hypot(P.x - St.door.x, P.z - St.door.z) > 45) { g.mode = 'poste'; this.ui.toast(`${g.name.split(' ')[0]} : « Je reprends mon poste devant ${St.name}. »`, 2.2); continue; }
          const i = esc.indexOf(g), o = this.slot(i), f = pl.facing || 0;
          const tx = P.x - Math.sin(f) * o.b + Math.cos(f) * o.s, tz = P.z - Math.cos(f) * o.b - Math.sin(f) * o.s;
          if (far > 45 || (g.stuck > 2.5 && far > 8)) { this.dropNear(g); g.stuck = 0; }
          const run = far > 7 ? 5.2 : 3.4;
          this.walk(g, tx, tz, run, dt); speed = g.speed;
          if (speed < 0.2) g.h += ang(f - g.h) * Math.min(1, dt * 3);
        }
      } else if (g.mode === 'poste') {
        const Pt = this.post(g.post); g.y = 0;
        if (Pt && Math.hypot(P.x - Pt.x, P.z - Pt.z) > 170 && Math.hypot(g.x - Pt.x, g.z - Pt.z) < 1) { g.c.group.visible = false; continue; } // loin du joueur : pas de rendu ni d'animation
        g.c.group.visible = true;
        if (Pt) {
          let tx = Pt.x, tz = Pt.z;
          if (Pt.patrol && !g.act) { const w = Pt.patrol[g.pi % Pt.patrol.length]; tx = w[0]; tz = w[1]; if (Math.hypot(g.x - tx, g.z - tz) < 0.3) { g.pause = (g.pause || 0) + dt; if (g.pause > 6) { g.pause = 0; g.pi++; } } }
          if (Math.hypot(g.x - Pt.x, g.z - Pt.z) > 60) { g.x = Pt.x; g.z = Pt.z; } // trop loin : relève au poste
          const d = this.walk(g, tx, tz, Pt.patrol ? 1.2 : 1.6, dt); speed = g.speed;
          if (d < 0.3 && !g.act) g.h += ang(Pt.ry - g.h) * Math.min(1, dt * 3);
        }
      } else { g.c.group.visible = true; } // « rester ici »
      // salut au PDG
      if (g.c.group.visible && !inVeh && far < 4.2 && speed < 0.5 && this.clock - g.saluted > 90) { g.saluted = this.clock; g.act = 'salut'; g.actT = 1.6; if (this.hello <= 0) { this.hello = 8; this.ui.toast(`${g.name.split(' ')[0]} (${g.rank.toLowerCase()}) : « ${HELLO[Math.floor(Math.random() * HELLO.length)]} »`, 2.2); } }
      if (g.act) { g.actT -= dt; if (g.act === 'salut') g.h += ang(Math.atan2(P.x - g.x, P.z - g.z) - g.h) * Math.min(1, dt * 8); if (g.act === 'chat' && g.peer) g.h += ang(Math.atan2(g.peer.x - g.x, g.peer.z - g.z) - g.h) * Math.min(1, dt * 5); if (g.actT <= 0) g.act = null; }
      this.place(g);
      if (far < 90) {
        g.c.animate(dt, speed);
        const b = g.c.bones;
        if (g.act === 'salut') { b.armR.rotation.x = -2.5; b.armR.rotation.z = -0.5; b.foreR.rotation.x = -1.9; }
        else if (g.act === 'chat') { const t = performance.now() / 300; b.armR.rotation.x = -0.4 + Math.sin(t) * 0.25; b.foreR.rotation.x = -1.1; }
        else if (g.act === 'point') { b.armR.rotation.x = -1.45; b.armR.rotation.z = -0.35; b.foreR.rotation.x = -0.1; }
        else if (g.act === 'wave') { b.armR.rotation.x = -2.7; b.armR.rotation.z = -0.4 + Math.sin(performance.now() / 120) * 0.35; b.foreR.rotation.x = -0.4; }
        else if (speed < 0.2) { b.armL.rotation.x = 0.25; b.armR.rotation.x = 0.25; b.armL.rotation.z = -0.25; b.armR.rotation.z = 0.25; b.foreL.rotation.x = -1.3; b.foreR.rotation.x = -1.3; } // mains croisées devant
      }
    }
    if (!inside && !inVeh) this.siteLife(P, dt);
    this.incidentTick();
  }
  // accueil du PDG, salut et orientation des visiteurs devant chaque siège
  siteLife(P, dt) {
    this.visT = (this.visT || 0) - dt;
    for (const St of this.sites) {
      if (St.id === 'maison') continue;
      const team = this.guards.filter((g) => g.assign === St.id && g.mode === 'poste' && g.c.group.visible); if (!team.length) continue;
      const d = Math.hypot(P.x - St.door.x, P.z - St.door.z);
      if (d < 8 && this.clock - (this.welcomed[St.id] || -999) > 120) {
        this.welcomed[St.id] = this.clock; const chef = team.find((g) => /Chef/.test(g.rank)) || team[0];
        chef.act = 'salut'; chef.actT = 1.8; chef.saluted = this.clock;
        const sub = St.id === 'book' ? null : this.group && this.group.subs[St.id];
        this.ui.toast(`${chef.name.split(' ')[0]} (${chef.rank.toLowerCase()}) : « Bienvenue, Monsieur le PDG. ${St.id === 'book' || sub ? `L’équipe de ${St.name} vous attend, la réception est juste à l’entrée.` : `Les locaux de ${St.name} sont sous surveillance en attendant l’ouverture de la société.`} »`, 3.2);
      }
      if (this.visT <= 0 && this.peds && d < 120) {
        const v = this.peds.list.find((q) => q.active && q.c.group.visible && Math.hypot(q.x - St.door.x, q.z - St.door.z) < 6.5);
        if (v) { const g = team[Math.floor(Math.random() * team.length)]; if (!g.act) { g.act = Math.random() < 0.5 ? 'wave' : 'point'; g.actT = 2.2; g.h = Math.atan2(v.x - g.x, v.z - g.z); g.lastVisit = g.act === 'point' ? 'Un visiteur a été orienté vers la réception.' : 'Un passant a été salué.'; } }
      }
    }
    if (this.visT <= 0) this.visT = 4;
    // visite d'affaires attendue au siège (mission 014) : la sécurité l'oriente vers la réception
    if (this.ceoLife && this.ceoLife.visit && this.ceoLife.visit !== this._visitSeen) { this._visitSeen = this.ceoLife.visit; const chef = this.guards.find((g) => g.assign === 'book'); if (chef) this.notifyFrom(chef, 'Un visiteur vient d’arriver au siège : je l’ai accueilli et orienté vers la réception. Il vous attend au rez-de-chaussée.'); }
  }
  notifyFrom(g, txt) { if (this.phonePlus) this.phonePlus.receive(`sec:${g.id}`, txt); else this.economy.notify(`🛡️ ${g.name} : ${txt}`); }
  // ------------------------------------------------------------------ signalements (situations inhabituelles, réponses non violentes)
  gameNow() { return (this.economy.day || 1) * 24 + this.env.time; }
  incidentTick() {
    const now = this.gameNow();
    if (this.nextInc === null) this.nextInc = now + 3 + Math.random() * 5;
    if (now >= this.nextInc) { this.nextInc = now + 14 + Math.random() * 20; this.raise(); }
    for (const I of this.incidents) {
      if (I.status !== 'en cours') continue;
      if (INC[I.type].auto && now >= I.at + 0.75) this.resolve(I, null);
      else if (INC[I.type].help && now >= I.at + 3) this.resolve(I, 'auto');
    }
  }
  raise(type, siteId) {
    const sites = this.sites.filter((q) => this.guards.some((g) => g.assign === q.id)); if (!sites.length) return null;
    const St = siteId ? this.site(siteId) : sites[Math.floor(Math.random() * sites.length)], types = Object.keys(INC), tp = type || types[Math.floor(Math.random() * types.length)];
    const chef = this.guards.find((g) => g.assign === St.id && /Chef/.test(g.rank)) || this.guards.find((g) => g.assign === St.id);
    const I = { id: this.incUid++, type: tp, site: St.id, siteName: St.name, by: chef.id, at: this.gameNow(), t: this.economy.stamp(), status: 'en cours', note: '' };
    this.incidents.unshift(I); this.incidents.length = Math.min(this.incidents.length, 25);
    this.notifyFrom(chef, `Signalement (${St.name}) : ${INC[tp].t.replace(/^\S+ /, '')}. ${INC[tp].help ? 'Nous avons besoin de votre accord : voir l’application Sécurité personnelle.' : 'L’équipe s’en occupe calmement, je vous tiens informé.'}`);
    this.onSave && this.onSave(); return I;
  }
  resolve(I, opt) {
    if (!I || I.status !== 'en cours') return;
    const chef = this.guards.find((g) => g.id === I.by), D = INC[I.type];
    if (D.auto) I.note = D.auto;
    else if (opt === 'tech') { const acc = I.site === 'book' || I.site === 'maison' ? (I.site === 'maison' ? 'perso' : 'book') : (this.group && this.group.subs[I.site] ? I.site : 'book'); const ok = this.group ? this.group.debit(acc, 40000, `Intervention technique — ${I.siteName}`, false, 'frais') : this.economy.pay(40000, `Intervention technique — ${I.siteName}`, 'Maintenance'); if (!ok) return this.ui.toast('Fonds insuffisants pour l’intervention.', 2); I.note = `Un technicien a rétabli le courant (40 000 FCFA, ${this.group ? this.group.accName(acc) : 'compte personnel'}).`; }
    else if (opt === 'wait') I.note = 'Le service du quartier a rétabli le courant au bout d’une heure ; l’équipe a filtré les entrées manuellement.';
    else if (opt === 'secours') { I.note = 'Les secours sont arrivés rapidement ; la personne a été prise en charge et va mieux. L’équipe est restée auprès d’elle.'; if (this.events) this.events.repAdd('generosite', 1); }
    else if (opt === 'recevoir') { I.note = 'Le visiteur a été reçu quelques minutes : il présentait un projet de partenariat (fictif). Il repart satisfait.'; if (this.events) this.events.repAdd('reseau', 1); }
    else if (opt === 'rdv') I.note = 'La réception lui a proposé un rendez-vous ; il est reparti calmement.';
    else I.note = 'Situation réglée par l’équipe de sécurité, sans votre intervention.';
    I.status = 'résolu'; I.done = this.economy.stamp(); if (this.events) this.events.repAdd('fiabilite', 0.5);
    if (chef) this.notifyFrom(chef, `Situation réglée (${I.siteName}) : ${I.note}`);
    this.onSave && this.onSave();
  }
  // ------------------------------------------------------------------ interactions (parler à un garde)
  nearest(x, z) {
    let best = null;
    for (const g of this.guards) { if (!g.c.group.visible || Math.abs((g.y || 0) - (this.player.floorY || 0)) > 2) continue; const d = Math.hypot(g.x - x, g.z - z); if (d < 1.9 && (!best || d < best.d)) best = { d, g }; }
    if (!best) return null; const g = best.g;
    return { d: best.d + 0.2, it: { label: () => `Parler à ${g.name} (${g.rank.toLowerCase()})`, action: () => this.menu(g) } };
  }
  menu(g) {
    const St = this.site(g.assign);
    if (g.assign !== 'maison') {
      const items = [
        { label: '💬 Faire le point', action: () => this.ui.toast(`${g.name.split(' ')[0]} : « ${this.report(g)} »`, 3.5) },
        { label: '🧭 Où est la réception ?', action: () => { g.act = 'point'; g.actT = 2.5; g.h = Math.atan2(St.door.x - g.x, St.door.z - g.z); this.ui.toast(`${g.name.split(' ')[0]} : « La réception est juste derrière l’entrée vitrée, sur votre droite. Je vous y accompagne si vous le souhaitez. »`, 3.5); } },
        g.mode !== 'escorte' ? { label: `🛡️ Accompagnez-moi dans ${St.name}`, action: () => this.setMode(g, 'escorte') } : { label: '↩️ Retournez à votre poste', action: () => this.setMode(g, 'poste') },
        { label: '📋 Signalements de ce site', action: () => { const L = this.incidents.filter((I) => I.site === g.assign).slice(0, 3); this.ui.toast(L.length ? L.map((I) => `${INC[I.type].t} — ${I.status}`).join(' • ') : 'Aucun signalement récent sur ce site.', 4); } },
      ];
      return this.ui.openMenu(`🛡️ ${g.name}`, `${g.rank} • sécurité de ${St.name} • protection fictive et non violente`, items);
    }
    const items = [
      { label: '💬 Faire le point', action: () => this.ui.toast(`${g.name.split(' ')[0]} : « ${this.report(g)} »`, 3.5) },
      g.mode !== 'escorte' ? { label: '🛡️ Accompagnez-moi', action: () => this.setMode(g, 'escorte') } : { label: '🏠 Retournez à votre poste', action: () => this.setMode(g, 'poste') },
      { label: '✋ Restez ici', action: () => this.setMode(g, 'ici') },
      { label: '👥 Toute l’équipe m’accompagne', action: () => this.allEscort() },
      { label: '↩️ Toute l’équipe à son poste', action: () => this.allPost() },
    ];
    this.ui.openMenu(`🛡️ ${g.name}`, `${g.rank} • ${this.where(g)} • système de protection fictif et non violent`, items);
  }
  report(g) {
    const h = this.env.time;
    if (g.assign !== 'maison') { const I = this.incidents.find((q) => q.site === g.assign && q.status === 'en cours'); return I ? `Situation en cours : ${INC[I.type].t.replace(/^\S+ /, '').toLowerCase()}. Nous gérons calmement.` : `Rien à signaler devant ${this.site(g.assign).name}. ${g.lastVisit || 'Les visiteurs sont orientés vers la réception.'}`; }
    if (g.mode === 'escorte') return 'Je reste près de vous. Rien à signaler.';
    return h < 6 || h > 21 ? 'Ronde de nuit effectuée, portail et portillon vérifiés. Tout est calme.' : `Rien à signaler à mon poste (${this.post(g.post).label.toLowerCase()}).`;
  }
  where(g) {
    if (g.mode === 'escorte') return g.inVeh ? (this.escort && this.escort.active ? 'dans le véhicule d’escorte, derrière le PDG' : 'dans le véhicule avec le PDG') : g.waiting ? 'attend devant le bâtiment' : 'accompagne le PDG';
    if (g.mode === 'ici') return `en attente — ${regionZone(g.x, g.z) || (this.world.zoneName ? this.world.zoneName(g.x, g.z) : 'Cotonou')}`;
    const p = this.post(g.post); return p ? p.label : 'résidence';
  }
  state(g) { return g.mode === 'escorte' ? '🟢 en accompagnement' : g.mode === 'ici' ? '🟡 en attente sur place' : g.act === 'chat' ? '🔵 à son poste (échange avec un collègue)' : '🔵 à son poste, disponible'; }
  // ------------------------------------------------------------------ application « Sécurité personnelle »
  renderApp(b) {
    const row = (g) => `<div class="ph-row${this.selG === g.id ? ' pp-on' : ''}"><span data-sec="sel:${g.id}"><b>${g.female ? '👮🏿‍♀️' : '👮🏿‍♂️'} ${esc(g.name)}</b><small>${esc(g.rank)} • ${esc(this.post(g.post) ? this.post(g.post).label : g.post)}<br>📍 ${esc(this.where(g))} • ${this.state(g)}${g.escort ? ' • équipe d’escorte' : ''}</small></span><span class="pp-acts">${g.mode !== 'escorte' ? `<button class="ph-mini" data-sec="esc:${g.id}">🛡️</button>` : `<button class="ph-mini" data-sec="post:${g.id}">↩️</button>`}</span></div>${this.selG === g.id ? `<div class="ph-chips">${g.assign === 'maison' ? `<button data-sec="team:${g.id}" class="${g.escort ? 'on' : ''}">${g.escort ? '★ Équipe d’escorte' : '☆ Ajouter à l’escorte'}</button>` : ''}${this.sites.map((q) => `<button data-sec="asg:${g.id}|${q.id}" class="${g.assign === q.id ? 'on' : ''}">${q.id === 'maison' ? '🏠' : '🏢'} ${esc(q.name)} (${this.guards.filter((x) => x.assign === q.id).length}/${this.posts.filter((p) => p.site === q.id).length})</button>`).join('')}</div>` : ''}`;
    const open = this.incidents.filter((I) => I.status === 'en cours');
    b.innerHTML = `<h4>🛡️ Sécurité personnelle</h4><p class="ph-note">${this.guards.length} gardes • système fictif et non violent : protection, accueil, orientation, accompagnement, signalements.</p>
      <div class="ph-chips"><button data-sec="all:escorte">👥 Équipe maison avec moi</button><button data-sec="all:poste">↩️ Tous au poste</button><button data-sec="auto" class="${this.autoEscort ? 'on' : ''}">Escorte auto : ${this.autoEscort ? 'oui' : 'non'}</button>${this.escort ? `<button data-sec="veh" class="${this.escort.enabled ? 'on' : ''}">🚙 Véhicule d’escorte : ${this.escort.enabled ? 'oui' : 'non'}</button>` : ''}</div>${this.escort ? `<p class="ph-note">🚙 Véhicule d’escorte BL-ESCORTE-1 : ${this.escort.where()}.</p>` : ''}
      ${open.length ? `<h5>🚨 Signalements en cours</h5>${open.map((I) => `<div class="ph-row"><span><b>${INC[I.type].t}</b><small>${esc(I.siteName)} • ${I.t}${INC[I.type].auto ? ' • l’équipe s’en occupe' : ''}</small></span></div>${INC[I.type].help ? `<div class="ph-chips">${INC[I.type].help.map(([k, l]) => `<button data-sec="inc:${I.id}|${k}">${esc(l)}</button>`).join('')}</div>` : ''}`).join('')}` : ''}
      ${this.sites.map((q) => { const L = this.guards.filter((g) => g.assign === q.id); return L.length ? `<h5>${q.id === 'maison' ? '🏠' : '🏢'} ${esc(q.name)} (${L.length})</h5><div class="ph-list">${L.map(row).join('')}</div>` : ''; }).join('')}
      <p class="ph-note">Touche un garde pour changer son affectation.</p>
      <h5>Historique des signalements</h5><div class="ph-list">${this.incidents.filter((I) => I.status !== 'en cours').slice(0, 6).map((I) => `<div class="ph-row"><span><b>${INC[I.type].t}</b><small>${esc(I.siteName)} • ${I.t} • ${esc(I.note)}</small></span></div>`).join('') || '<p class="ph-note">Aucun.</p>'}</div>`;
  }
  onPhone(v) {
    const [a, id] = v.split(':'), g = this.guards.find((q) => q.id === id);
    if (a === 'all') { if (id === 'escorte') this.allEscort(); else this.allPost(); }
    else if (a === 'auto') { this.autoEscort = !this.autoEscort; this.onSave && this.onSave(); }
    else if (a === 'veh' && this.escort) { this.escort.enabled = !this.escort.enabled; this.onSave && this.onSave(); }
    else if (a === 'esc') this.setMode(g, 'escorte');
    else if (a === 'post') this.setMode(g, 'poste');
    else if (a === 'team' && g) { g.escort = !g.escort; this.onSave && this.onSave(); }
    else if (a === 'sel') this.selG = this.selG === id ? null : id;
    else if (a === 'asg') { const [gid, site] = id.split('|'); this.reassign(this.guards.find((q) => q.id === gid), site); }
    else if (a === 'inc') { const [iid, opt] = id.split('|'); this.resolve(this.incidents.find((I) => I.id === +iid), opt); }
    if (this.economy.phoneOpen) this.economy.renderPhone();
  }
  // contacts du téléphone
  contacts() { return this.guards.map((g) => ({ key: `sec:${g.id}`, kind: 'sec', name: g.name, role: `${g.rank} • sécurité ${g.assign === 'maison' ? 'de la résidence' : `de ${this.site(g.assign).name}`}`, icon: g.female ? '👮🏿‍♀️' : '👮🏿‍♂️', guard: g })); }
  reply(c, txt) {
    const g = c.guard, t = txt.toLowerCase();
    if (/accompagn|viens|venez|rejoi/.test(t)) { this.setMode(g, 'escorte', true); return 'Bien reçu, je vous rejoins tout de suite, Monsieur le PDG.'; }
    if (/poste|retour|rentre/.test(t)) { this.setMode(g, 'poste', true); return 'Entendu, je retourne à mon poste.'; }
    if (/point|ça va|ca va|situation|rien/.test(t)) return this.report(g);
    return 'Bien reçu, Monsieur le PDG.';
  }
  serialize() { return { inc: this.incidents, incUid: this.incUid, nextInc: this.nextInc, auto: this.autoEscort, g: this.guards.map((g) => ({ id: g.id, mode: g.mode, assign: g.assign, post: g.post, escort: g.escort, x: g.mode === 'ici' ? g.x : undefined, z: g.mode === 'ici' ? g.z : undefined })) }; }
  restore(s) {
    if (!s) return; this.autoEscort = s.auto !== false; this.incidents = s.inc || []; this.incUid = s.incUid || 1; this.nextInc = s.nextInc ?? null;
    for (const q of s.g || []) { const g = this.guards.find((x) => x.id === q.id); if (!g) continue; Object.assign(g, { mode: q.mode || 'poste', assign: q.assign || 'maison', post: q.post || g.post, escort: !!q.escort }); if (g.mode === 'ici' && q.x != null) { g.x = q.x; g.z = q.z; } else { const P = this.post(g.post); if (P) { g.x = P.x; g.z = P.z; } } this.place(g); }
  }
}
