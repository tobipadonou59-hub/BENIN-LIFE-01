// Monuments. Statue provisoire procédurale de la Place de l'Amazone : interprétation libre
// (guerrière Agodjié en bronze), en attendant un éventuel modèle Tripo validé.
// Ce n'est pas une copie de l'œuvre réelle (inaugurée en 2022, protégée par le droit d'auteur).
import * as THREE from 'three';
import { createCharacter } from './character.js';

export function createAmazoneStatue(height = 9.5) {
  const c = createCharacter({ female: true, pagne: 0 });
  const bronze = new THREE.MeshStandardMaterial({ color: 0x7a5a32, metalness: 0.85, roughness: 0.36, envMapIntensity: 1.2 });
  c.mesh.material = bronze;
  const b = c.bones;
  // pose de monument : pas en avant, buste droit, bras gauche levé, coupe-coupe dans la main droite
  b.thighL.rotation.set(-0.22, 0, 0.06); b.shinL.rotation.x = 0.18; b.footL.rotation.x = 0.05;
  b.thighR.rotation.set(0.12, 0, -0.07); b.shinR.rotation.x = 0.06;
  b.spine.rotation.x = -0.04; b.chest.rotation.y = 0.12;
  b.head.rotation.set(-0.1, -0.1, 0);
  b.armL.rotation.set(-2.55, 0, 0.32); b.foreL.rotation.x = -0.35; b.handL.rotation.x = -0.2;
  b.armR.rotation.set(-0.25, 0, -0.32); b.foreR.rotation.x = -0.75;
  // coupe-coupe (machette) tenu lame vers le haut et l'avant
  const blade = new THREE.Group();
  const steel = new THREE.MeshStandardMaterial({ color: 0x8f7a58, metalness: 0.9, roughness: 0.25 });
  const bl = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.72, 0.012), steel); bl.position.y = 0.42; bl.castShadow = true;
  const tip = new THREE.Mesh(new THREE.ConeGeometry(0.035, 0.12, 4), steel); tip.position.y = 0.84; tip.scale.z = 0.3;
  const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.02, 0.16, 8), bronze);
  blade.add(bl, tip, handle);
  blade.rotation.x = 1.75; blade.position.set(0, -0.05, 0.02);
  b.handR.add(blade);
  const g = new THREE.Group();
  c.group.scale.setScalar(height / 1.78);
  g.add(c.group);
  g.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
  return g;
}

// Textures de la plaque et du panneau d'information
export function amazoneSigns() {
  const c = document.createElement('canvas'); c.width = 1024; c.height = 512;
  const x = c.getContext('2d');
  // plaque de bronze (haut)
  const g = x.createLinearGradient(0, 0, 0, 200);
  g.addColorStop(0, '#9a7a46'); g.addColorStop(1, '#6a4e26');
  x.fillStyle = g; x.fillRect(0, 0, 1024, 200);
  x.strokeStyle = '#d8bf86'; x.lineWidth = 6; x.strokeRect(14, 14, 996, 172);
  x.fillStyle = '#f0dca8'; x.textAlign = 'center'; x.textBaseline = 'middle';
  x.font = '900 86px Georgia, serif'; x.fillText('AMAZONE', 512, 84);
  x.font = 'italic 600 32px Georgia, serif'; x.fillText('Hommage aux Agodjié', 512, 150);
  // panneau d'information (bas)
  x.fillStyle = '#0b4d3a'; x.fillRect(0, 210, 1024, 302);
  x.fillStyle = '#fcd116'; x.fillRect(0, 210, 1024, 12);
  x.fillStyle = '#ffffff'; x.textAlign = 'left';
  x.font = '800 44px Arial'; x.fillText('PLACE DE L\'AMAZONE', 40, 270);
  x.font = '400 26px Arial';
  const lines = [
    'Les Agodjié (ou Minons) formaient un corps de guerrières',
    'du royaume du Danxomè, du XVIIe au XIXe siècle.',
    'Cette place leur rend hommage, face à l\'océan.',
    'Monument du jeu : interprétation libre, non officielle.',
  ];
  lines.forEach((l, i) => x.fillText(l, 40, 320 + i * 40));
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8;
  return t;
}
