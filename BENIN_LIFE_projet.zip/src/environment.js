// Ciel physique, nuages volumétriques simulés, éclairage d'ambiance issu du ciel (PMREM),
// soleil/lune avec ombres stabilisées, brume atmosphérique et cycle jour/nuit.
import * as THREE from 'three';
import { Sky } from 'three/addons/objects/Sky.js';
import { clamp, lerp } from './util.js';
import { Weather } from './weather.js';

const cloudVert = /* glsl */`
varying vec3 vDir;
void main() {
  vDir = normalize(position);
  vec4 p = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  gl_Position = p.xyww;
}`;
const cloudFrag = /* glsl */`
uniform float uTime; uniform vec3 uSunDir; uniform vec3 uSunCol; uniform vec3 uShadeCol; uniform float uCover; uniform float uNight;
varying vec3 vDir;
float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float noise(vec2 p) {
  vec2 i = floor(p), f = fract(p); vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash(i), hash(i + vec2(1, 0)), u.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), u.x), u.y);
}
float fbm(vec2 p) { float v = 0.0, a = 0.5; for (int i = 0; i < 6; i++) { v += a * noise(p); p = p * 2.03 + vec2(1.7, 9.2); a *= 0.5; } return v; }
void main() {
  vec3 d = normalize(vDir);
  if (d.y < 0.0) discard;
  vec2 uv = d.xz / (d.y + 0.08) * 0.9 + vec2(uTime * 0.0025, uTime * 0.001);
  float n = fbm(uv * 1.4);
  float c = smoothstep(uCover, uCover + 0.32, n);
  // épaisseur vers le soleil : bord éclairé, base plus sombre
  float n2 = fbm(uv * 1.4 + uSunDir.xz * 0.06);
  float light = clamp(0.55 + (n - n2) * 4.0, 0.0, 1.0);
  float sunGlow = pow(max(dot(d, uSunDir), 0.0), 8.0);
  vec3 col = mix(uShadeCol, uSunCol, light) + uSunCol * sunGlow * 0.5;
  col *= mix(1.0, 0.12, uNight);
  float a = c * smoothstep(0.0, 0.18, d.y) * 0.92;
  gl_FragColor = vec4(col, a);
  #include <colorspace_fragment>
}`;

export class Environment {
  constructor(scene, renderer, world) {
    this.scene = scene;
    this.renderer = renderer;
    this.world = world;
    this.time = 16.6;
    this.rate = 24 / (20 * 60); // 1 journée = 20 minutes réelles
    this.quality = 'medium';

    this.sky = new Sky();
    this.sky.scale.setScalar(4000);
    this.setSkyParams(this.sky);
    scene.add(this.sky);

    // ciel secondaire pour calculer l'éclairage d'ambiance (réflexions + lumière diffuse)
    this.envScene = new THREE.Scene();
    this.envSky = new Sky();
    this.envSky.scale.setScalar(50);
    this.setSkyParams(this.envSky);
    this.envScene.add(this.envSky);
    const ground = new THREE.Mesh(new THREE.SphereGeometry(40, 16, 8, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2),
      new THREE.MeshBasicMaterial({ color: 0x6a4030, side: THREE.BackSide }));
    this.envGround = ground;
    this.envScene.add(ground);
    this.pmrem = new THREE.PMREMGenerator(renderer);
    this.envRT = null;
    this.lastEnvTime = -99;

    // nuages
    this.cloudMat = new THREE.ShaderMaterial({
      vertexShader: cloudVert, fragmentShader: cloudFrag, transparent: true, depthWrite: false, side: THREE.BackSide, fog: false,
      uniforms: {
        uTime: { value: 0 }, uSunDir: { value: new THREE.Vector3() }, uSunCol: { value: new THREE.Color() },
        uShadeCol: { value: new THREE.Color() }, uCover: { value: 0.5 }, uNight: { value: 0 },
      },
    });
    this.clouds = new THREE.Mesh(new THREE.SphereGeometry(900, 32, 16), this.cloudMat);
    this.clouds.renderOrder = -1;
    this.clouds.frustumCulled = false;
    scene.add(this.clouds);

    this.sun = new THREE.DirectionalLight(0xffffff, 3);
    this.sun.castShadow = true;
    this.sun.shadow.bias = -0.0003;
    this.sun.shadow.normalBias = 0.035;
    scene.add(this.sun, this.sun.target);
    this.shadowExtent = 60;

    this.hemi = new THREE.HemisphereLight(0xbfd8ff, 0x8a5a3a, 0.5);
    scene.add(this.hemi);

    scene.fog = new THREE.Fog(0xcfd8de, 70, 480);

    // étoiles
    const n = 2000, pos = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      const th = Math.random() * Math.PI * 2, ph = Math.acos(Math.random() * 0.95);
      pos[i * 3] = Math.sin(ph) * Math.cos(th) * 1800;
      pos[i * 3 + 1] = Math.cos(ph) * 1800;
      pos[i * 3 + 2] = Math.sin(ph) * Math.sin(th) * 1800;
    }
    const sg = new THREE.BufferGeometry();
    sg.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    this.starMat = new THREE.PointsMaterial({ color: 0xffffff, size: 1.8, sizeAttenuation: false, transparent: true, opacity: 0, fog: false, depthWrite: false });
    this.stars = new THREE.Points(sg, this.starMat);
    this.stars.frustumCulled = false;
    scene.add(this.stars);

    // lune
    const mc = document.createElement('canvas'); mc.width = mc.height = 128;
    const mx = mc.getContext('2d');
    const g = mx.createRadialGradient(64, 64, 0, 64, 64, 64);
    g.addColorStop(0, 'rgba(255,255,240,1)'); g.addColorStop(0.22, 'rgba(240,240,225,1)'); g.addColorStop(0.27, 'rgba(180,200,255,0.25)'); g.addColorStop(1, 'rgba(120,150,255,0)');
    mx.fillStyle = g; mx.fillRect(0, 0, 128, 128);
    const mt = new THREE.CanvasTexture(mc); mt.colorSpace = THREE.SRGBColorSpace;
    this.moon = new THREE.Sprite(new THREE.SpriteMaterial({ map: mt, transparent: true, fog: false, depthWrite: false }));
    this.moon.scale.setScalar(160);
    scene.add(this.moon);
    this.moonDir = new THREE.Vector3(0.3, 0.75, -0.55).normalize();

    this.sunDir = new THREE.Vector3();
    this.night = 0;
    this.lightsOn = 0;
    this.timeScale = 1;     // vitesse du temps (Options)
    this.fogFar = 480;      // portée de la brume selon la qualité graphique
    this.weather = new Weather(scene);
    this.lastEnvKey = '';
    this._c1 = new THREE.Color(); this._c2 = new THREE.Color();
  }

  setSkyParams(sky) {
    const u = sky.material.uniforms;
    u.turbidity.value = 7;
    u.rayleigh.value = 1.4;
    u.mieCoefficient.value = 0.005;
    u.mieDirectionalG.value = 0.86;
  }

  setShadows(quality) {
    this.quality = quality;
    this.weather.setQuality(quality);
    const on = quality !== 'low';
    this.sun.castShadow = on;
    const size = quality === 'high' ? 4096 : 2048;
    this.shadowExtent = quality === 'high' ? 85 : 60;
    const sc = this.sun.shadow.camera;
    sc.left = -this.shadowExtent; sc.right = this.shadowExtent; sc.top = this.shadowExtent; sc.bottom = -this.shadowExtent;
    sc.near = 1; sc.far = 400;
    sc.updateProjectionMatrix();
    if (this.sun.shadow.mapSize.x !== size) {
      this.sun.shadow.mapSize.set(size, size);
      if (this.sun.shadow.map) { this.sun.shadow.map.dispose(); this.sun.shadow.map = null; }
    }
  }

  get clock() {
    const h = Math.floor(this.time) % 24, m = Math.floor((this.time % 1) * 60);
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
  }

  // période de la journée (affichée dans l'interface)
  get period() {
    const t = this.time;
    if (t >= 5.3 && t < 6.9) return 'Lever du soleil';
    if (t >= 6.9 && t < 11.5) return 'Matin';
    if (t >= 11.5 && t < 17.6) return 'Après-midi';
    if (t >= 17.6 && t < 18.9) return 'Coucher du soleil';
    if (t >= 18.9 && t < 19.8) return 'Crépuscule';
    return 'Nuit';
  }

  updateEnvMap(day) {
    this.envSky.material.uniforms.sunPosition.value.copy(this.sunDir);
    const o = this.weather.p.overcast, w = this.weather.wet;
    const eu = this.envSky.material.uniforms;
    eu.turbidity.value = lerp(7, 16, o); eu.rayleigh.value = lerp(1.4, 0.5, o);
    // sol plus sombre (et donc reflets plus contrastés) quand il est mouillé
    const gk = day * (1 - 0.35 * w);
    this.envGround.material.color.setRGB(0.42 * gk + 0.02, 0.26 * gk + 0.02, 0.19 * gk + 0.03);
    const rt = this.pmrem.fromScene(this.envScene, 0, 0.1, 200);
    if (this.envRT) this.envRT.dispose();
    this.envRT = rt;
    this.scene.environment = rt.texture;
  }

  update(dt, focus, camera, realTime = 0) {
    const dh = dt * this.rate * this.timeScale;
    this.time = (this.time + dh) % 24;
    const phase = ((this.time - 6.25) / 12.5) * Math.PI; // lever ~6h15, coucher ~18h45
    const elev = Math.sin(phase);
    this.sunDir.set(-Math.cos(phase), elev, 0.35).normalize();
    this.sky.material.uniforms.sunPosition.value.copy(this.sunDir);
    this.sky.position.copy(camera.position);
    this.stars.position.copy(camera.position);
    this.clouds.position.copy(camera.position);

    const day = clamp(elev * 3 + 0.15, 0, 1);
    const golden = clamp(1 - Math.abs(elev) * 3.5, 0, 1);
    this.night = 1 - clamp(elev * 5 + 0.4, 0, 1);

    // météo
    const W = this.weather;
    W.update(dt, dh, this.time, day, camera);
    const o = W.p.overcast, rain = W.p.rain, fogW = W.p.fog, flash = W.flash;
    const su = this.sky.material.uniforms;
    su.turbidity.value = lerp(7, 16, o); su.rayleigh.value = lerp(1.4, 0.5, o); su.mieCoefficient.value = lerp(0.005, 0.012, o);

    // éclairage d'ambiance recalculé périodiquement (toutes les ~6 minutes de jeu) ou quand la météo change
    const envKey = Math.round(o * 6) + ':' + Math.round(W.wet * 4);
    if (Math.abs(this.time - this.lastEnvTime) > 0.1 || envKey !== this.lastEnvKey) { this.lastEnvTime = this.time; this.lastEnvKey = envKey; this.updateEnvMap(day); }
    this.scene.environmentIntensity = lerp(0.1, 0.6, day) * (1 - 0.3 * o);

    // soleil ou lune ; ombres stabilisées (accrochage à la grille des texels)
    const moonUp = elev <= -0.05;
    const dir = moonUp ? this.moonDir : this.sunDir;
    const texel = (this.shadowExtent * 2) / this.sun.shadow.mapSize.x;
    const fx = Math.round(focus.x / texel) * texel, fz = Math.round(focus.z / texel) * texel;
    this.sun.position.set(fx + dir.x * 200, dir.y * 200, fz + dir.z * 200);
    this.sun.target.position.set(fx, 0, fz);
    if (moonUp) { this.sun.color.setRGB(0.55, 0.65, 1.0); this.sun.intensity = 0.35; }
    else {
      this.sun.color.setRGB(1, lerp(0.97, 0.62, golden), lerp(0.92, 0.38, golden));
      this.sun.intensity = 3.8 * clamp(elev * 3.5, 0.04, 1);
    }
    // ciel couvert : soleil voilé (ombres qui s'estompent), lumière diffuse grise
    this.sun.intensity *= 1 - 0.85 * o;
    this.hemi.intensity = lerp(0.12, 0.45, day) * (1 + 0.25 * o) + flash * 2.2;
    this.hemi.color.setRGB(lerp(0.3, 0.75, day), lerp(0.36, 0.85, day), lerp(0.6, 1, day)).lerp(this._c2.setRGB(0.62 * day + 0.2, 0.66 * day + 0.2, 0.7 * day + 0.24), o * 0.7);

    this.moon.position.copy(camera.position).addScaledVector(this.moonDir, 1200);
    this.moon.material.opacity = this.night;

    // brume : bleutée le jour, dorée au coucher, nuit bleu profond
    const fc = this._c1.setRGB(0.74, 0.82, 0.9).lerp(this._c2.setRGB(1.0, 0.72, 0.5), golden * 0.65).lerp(this._c2.setRGB(0.02, 0.03, 0.07), this.night);
    // pluie : gris ; brume côtière : blanc laiteux légèrement chaud
    fc.lerp(this._c2.setRGB(0.5 * day + 0.03, 0.54 * day + 0.035, 0.58 * day + 0.05), Math.max(o * 0.75, rain));
    fc.lerp(this._c2.setRGB(0.86 * day + 0.05, 0.84 * day + 0.06, 0.8 * day + 0.08), fogW * (1 - rain) * 0.85);
    this.scene.fog.color.copy(fc);
    const thick = Math.max(fogW, rain * 0.75) * (1 - 0.55 * this.night); // la nuit, la brume ne doit pas tout noyer dans le noir
    this.scene.fog.near = lerp(70, 6, thick);
    this.scene.fog.far = lerp(this.fogFar, Math.min(this.fogFar, 150), thick);
    this.renderer.toneMappingExposure = (lerp(0.95, 0.62, day) + golden * 0.08 * (1 - o)) * (1 - 0.1 * o) + flash * 0.25;
    this.starMat.opacity = this.night * 0.95;

    // nuages
    const cu = this.cloudMat.uniforms;
    cu.uTime.value = realTime;
    cu.uSunDir.value.copy(this.sunDir);
    cu.uSunCol.value.setRGB(1, lerp(1, 0.7, golden), lerp(1, 0.5, golden)).multiplyScalar(lerp(0.35, 1.05, day));
    cu.uShadeCol.value.setRGB(lerp(0.55, 0.66, day), lerp(0.58, 0.68, day), lerp(0.66, 0.76, day)).lerp(this._c2.setRGB(0.75, 0.5, 0.45), golden * 0.5).multiplyScalar(lerp(0.3, 1, day));
    cu.uNight.value = this.night;
    cu.uCover.value = W.p.cover;
    cu.uSunCol.value.lerp(this._c2.setRGB(0.75, 0.77, 0.8).multiplyScalar(lerp(0.3, 0.85, day)), o * 0.75).addScalar(flash * 0.8);
    cu.uShadeCol.value.multiplyScalar(1 - 0.5 * o);
    this.starMat.opacity *= 1 - o;
    this.moon.material.opacity *= 1 - 0.8 * o;

    // lampadaires et vitrines : allumés la nuit, et aussi sous un gros orage
    this.lightsOn = Math.max(this.night, clamp(rain * 1.2 - 0.3, 0, 0.7) * (0.4 + 0.6 * day));

    for (const m of this.world.nightMats) {
      if (m.prop === 'opacity') m.mat.opacity = m.max * this.lightsOn;
      else if (m.prop === 'intensity') m.mat.intensity = m.max * this.lightsOn;
      else m.mat.emissiveIntensity = m.max * this.lightsOn;
    }
  }
}
