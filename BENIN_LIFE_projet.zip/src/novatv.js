// Mission 020, étape 1 — Smart TV géante du salon (100 pouces, « 4K » stylisée), téléviseurs connectés dans les autres
// pièces, et application « NOVA TV » : 100 chaînes FICTIVES (aucun flux réel, aucune chaîne existante), programmes
// originaux générés par le jeu, guide électronique, programme en cours et à venir, télécommande (chaînes, volume,
// sourdine, pause des contenus enregistrés, favoris), éclairage LED derrière l'écran, son d'ambiance procédural.
import * as THREE from 'three';
import { VILLA } from './villa.js';

const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
// [premier, dernier, catégorie, clé, couleur, durée d'un programme (h), direct ?, noms de chaînes, programmes]
const CATS = [
  [1, 15, 'Actualités et informations', 'info', '#c8102e', 1, true,
    ['NOVA Info', 'Lagune Info 24', 'Atlantique Actu', 'Le Fil du Golfe', 'Info Littoral', 'Éco Afrique TV', 'Matin Bénin Info', 'Planète Actu', 'Info Régions', 'Société & Débats TV', 'Météo Golfe', 'Business Cotonou TV', 'Info Continent', 'Le Direct Info', 'Santé Info TV'],
    ['Journal du matin', 'Flash info', 'Le grand journal', 'Débat : économie et emploi', 'Météo et marées du Golfe', 'Le point international', 'Les régions en direct', 'L’entretien de l’actualité', 'Journal du soir', 'Revue de presse']],
  [16, 30, 'Divertissement et émissions', 'div', '#e46a1f', 1.5, true,
    ['NOVA Divertissement', 'Rire Plus', 'Soirée Golfe', 'Jeux & Quiz TV', 'Scène Ouverte TV', 'Télé Sourire', 'Maxi Show', 'Plateau Étoile', 'Club Détente', 'Famille TV', 'Défis TV', 'Le Grand Salon TV', 'Stars d’ici TV', 'Humour Afrique TV', 'Week-end TV'],
    ['Quiz NOVA', 'Le grand show du samedi', 'Talents en scène', 'Rire ensemble', 'Le défi des familles', 'Caméra souriante', 'Karaoké géant', 'Le jeu des mots', 'Soirée humour', 'Les petits plats des stars (fictif)']],
  [31, 40, 'Documentaires et découverte', 'doc', '#2f7a3a', 1, false,
    ['Découverte Nature TV', 'Planète Sauvage', 'Savoirs TV', 'Océans & Lagunes', 'Science Express', 'Histoire Monde TV', 'Explorateurs TV', 'Terre d’Afrique TV', 'Ingénieurs TV', 'Ciel & Espace TV'],
    ['Les lagunes du Golfe', 'Mangroves vivantes', 'Les grands parcs du nord', 'Comment ça marche ?', 'Le ciel la nuit', 'Voyage au large de l’Atlantique', 'Les bâtisseurs', 'Planète verte']],
  [41, 50, 'Culture et histoire du Bénin', 'cul', '#d8a830', 1, false,
    ['Héritage Bénin TV', 'Royaumes d’hier TV', 'Arts du Bénin TV', 'Patrimoine TV', 'Langues & Contes TV', 'Mémoire Ouidah TV', 'Porto-Novo Culture TV', 'Artisans TV', 'Musées & Palais TV', 'Traditions & Respect TV'],
    ['Les royaumes d’Abomey : histoire et palais', 'Ganvié, la cité lacustre', 'Porto-Novo, capitale aux mille couleurs', 'Tissus et pagnes du Bénin', 'Contes et proverbes', 'Ouidah, mémoire et route de l’esclave', 'Artisans du bronze et du bois', 'Comprendre et respecter les traditions', 'Les langues du Bénin', 'Grandes figures de l’histoire']],
  [51, 60, 'Sport et compétitions fictives', 'sport', '#1f4e9c', 2, true,
    ['NOVA Sport 1', 'NOVA Sport 2', 'Foot Golfe TV', 'Arène Sport', 'Athlé TV', 'Basket Afrique TV', 'Glisse & Mer TV', 'Rallye TV', 'Ring TV', 'Sport Jeunes TV'],
    ['Coupe NOVA de football (fictive) — en direct', 'Magazine du sport', 'Ligue du Golfe : résumé (compétition fictive)', 'Meeting d’athlétisme de Cotonou (fictif)', 'Basket : derby du littoral (fictif)', 'Course de pirogues (fictive)', 'Sport et santé', 'Le débrief']],
  [61, 70, 'Musique et spectacles', 'mus', '#7a2a8a', 1, false,
    ['Rythmes TV', 'NOVA Music', 'Afro Hits TV', 'Gospel Lumière TV', 'Jazz Lagune TV', 'Live Concert TV', 'Tradition Musicale TV', 'Hip-Hop Cotonou TV', 'Classique TV', 'Danse TV'],
    ['Top 20 des clips (artistes fictifs)', 'Concert live (fictif)', 'Les voix du gospel', 'Rythmes traditionnels', 'Nuit jazz', 'Danse en scène', 'Découvertes musicales', 'Classiques d’hier']],
  [71, 80, 'Cinéma et séries fictives', 'cine', '#3a3d44', 2, false,
    ['NOVA Cinéma', 'Ciné Golfe', 'Séries Plus', 'Ciné Classique TV', 'Action TV', 'Ciné Famille', 'Polar TV', 'Romance TV', 'Ciné Afrique TV', 'Séries Jeunes TV'],
    ['Film : Le dernier train pour Parakou (fictif)', 'Série : Les héritiers du Golfe (fictive)', 'Film : Mission Lagune (fictif)', 'Série : Brigade du Littoral (fictive)', 'Film : Un été à Ouidah (fictif)', 'Série : Familles d’ici (fictive)', 'Film : Le trésor du roi (fictif)', 'Animation : Le petit pêcheur (fictif)']],
  [81, 90, 'Jeunesse et éducation', 'kids', '#0b8a8a', 1, false,
    ['NOVA Kids', 'Petits Génies TV', 'Dessins Animés Plus', 'École TV', 'Maths Faciles TV', 'Sciences Juniors TV', 'Contes du Soir TV', 'Ados TV', 'Langues Faciles TV', 'Tout-Petits TV'],
    ['Dessin animé : Kiki et Zou (fictif)', 'Les petits génies', 'Maths en s’amusant', 'Contes du soir', 'Sciences juniors', 'Chante avec nous', 'Anglais facile', 'Bricolage pour enfants']],
  [91, 100, 'Cuisine, voyages et lifestyle', 'life', '#b4532a', 1, false,
    ['Cuisine du Bénin TV', 'Saveurs d’Afrique TV', 'Voyages & Évasion', 'Maison & Déco TV', 'Mode Afrique TV', 'Bien-être TV', 'Jardin TV', 'Auto Passion TV', 'Tech & Gadgets TV', 'Tourisme Bénin TV'],
    ['Cuisine : amiwo et poisson braisé', 'Saveurs du marché', 'Évasion : le nord du Bénin', 'Maison et déco', 'Mode et pagnes', 'Bien-être et sport doux', 'Au jardin', 'Auto passion', 'Tech et gadgets', 'Week-end au bord de la mer']],
];
export const CHANNELS = [];
for (const [a, b, cat, key, col, len, live, names, progs] of CATS) for (let n = a; n <= b; n++) CHANNELS.push({ n, name: names[n - a], cat, key, col, len, live, progs });
const LEDS = [['Blanc chaud', '#ffd9a0'], ['Bleu lagune', '#3aa0ff'], ['Violet', '#a060ff'], ['Vert NOVA', '#2fd08a'], ['Or', '#ffc030'], ['Rouge', '#ff4050'], ['Éteint', null]];

export class NovaTV {
  constructor(ctx) {
    Object.assign(this, ctx); // villa, scene, world, player, ui, audio, env, economy, input, onSave
    this.ch = 1; this.vol = 40; this.mute = false; this.favs = [1, 41, 51, 71, 91]; this.on = {}; this.led = 1; this.paused = false; this.view = 'guide'; this.filter = 'all';
    this.watching = null; this.banner = 0; this.guideOn = false; this.t = 0; this.acc = 0; this.beat = 0; this.digits = ''; this.digitT = 0;
    this.canvas = document.createElement('canvas'); this.canvas.width = 640; this.canvas.height = 360; this.ctx2 = this.canvas.getContext('2d');
    this.tex = new THREE.CanvasTexture(this.canvas); this.tex.colorSpace = THREE.SRGBColorSpace; this.tex.generateMipmaps = false; this.tex.minFilter = THREE.LinearFilter;
    this.mat = new THREE.MeshBasicMaterial({ map: this.tex, toneMapped: false });
    this.buildSalon(); this.buildScreens(); this.draw();
    this.dom = document.getElementById('tvr'); if (this.dom) this.dom.addEventListener('click', (e) => { const b = e.target.closest('[data-tv]'); if (b) { e.stopPropagation(); this.cmd(b.dataset.tv); } });
  }
  // ------------------------------------------------------------------ données de programme
  chan(n = this.ch) { return CHANNELS[n - 1]; }
  abs() { return (this.economy.day || 1) * 24 + this.env.time; }
  prog(c, off = 0) { // programme du créneau (déterministe, différent selon la chaîne)
    const a = this.abs(), slot = Math.floor(a / c.len) + off, start = slot * c.len, i = ((slot * 5 + c.n * 7) % c.progs.length + c.progs.length) % c.progs.length;
    return { title: c.progs[i], start, end: start + c.len, h0: ((start % 24) + 24) % 24, h1: (((start + c.len) % 24) + 24) % 24, pct: Math.max(0, Math.min(1, (a - start) / c.len)) };
  }
  hh(h) { const m = Math.round((h % 1) * 60); return `${String(Math.floor(h) % 24).padStart(2, '0')}:${String(m === 60 ? 0 : m).padStart(2, '0')}`; }
  canPause(c = this.chan()) { return !c.live; }
  // ------------------------------------------------------------------ Smart TV du salon (meuble, écran 100 pouces, LED, barre de son)
  buildSalon() {
    const R = this.villa.rooms.salon; if (!R) return;
    const g = new THREE.Group(); this.villa.inGroup.add(g); this.salonG = g;
    const x = R.cx - 3, z = R.z0 + 0.12, W = 2.21, H = 1.25, yc = 1.55; // 100 pouces (16:9)
    const add = (geo, mat, px, py, pz) => { const m = new THREE.Mesh(geo, mat); m.position.set(px, py, pz); g.add(m); return m; };
    const marble = new THREE.MeshStandardMaterial({ color: 0xece6dc, roughness: 0.25, metalness: 0.05 }), wood = new THREE.MeshStandardMaterial({ color: 0x3a2416, roughness: 0.55 }), black = new THREE.MeshStandardMaterial({ color: 0x08080a, roughness: 0.3, metalness: 0.4 });
    add(new THREE.BoxGeometry(5.6, 3.0, 0.08), marble, x, 1.5, R.z0 + 0.06);                           // panneau mural effet marbre
    add(new THREE.BoxGeometry(4.6, 0.42, 0.55), wood, x, 0.21, R.z0 + 0.4);                             // meuble TV intégré
    add(new THREE.BoxGeometry(4.5, 0.04, 0.5), marble, x, 0.44, R.z0 + 0.4);
    const gc = document.createElement('canvas'); gc.width = 256; gc.height = 160; const gx = gc.getContext('2d'); // lueur douce (dégradé), mélange additif
    for (let i = 0; i < 40; i++) { const k = i / 40; gx.fillStyle = `rgba(255,255,255,${0.035})`; const mx = 6 + k * 70, my = 6 + k * 45; gx.fillRect(mx, my, 256 - 2 * mx, 160 - 2 * my); }
    const gt = new THREE.CanvasTexture(gc); this.ledM = new THREE.MeshBasicMaterial({ color: 0xffd9a0, map: gt, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, toneMapped: false, depthWrite: false });
    this.ledP = add(new THREE.PlaneGeometry(W + 1.6, H + 1.1), this.ledM, x, yc, z + 0.015); this.ledP.visible = false; // halo LED derrière l'écran
    add(new THREE.BoxGeometry(W + 0.04, H + 0.04, 0.05), black, x, yc, z + 0.05);                       // cadre ultra-fin
    const scr = add(new THREE.PlaneGeometry(W, H), this.mat, x, yc, z + 0.08); scr.visible = false;
    const off = add(new THREE.PlaneGeometry(W, H), new THREE.MeshStandardMaterial({ color: 0x0c0d10, roughness: 0.15, metalness: 0.6 }), x, yc, z + 0.078);
    add(new THREE.BoxGeometry(1.4, 0.09, 0.12), black, x, 0.5, z + 0.32);                              // barre de son
    for (const s of [-1, 1]) { add(new THREE.BoxGeometry(0.3, 1.15, 0.3), black, x + s * 2.65, 0.575, R.z0 + 0.35); add(new THREE.CylinderGeometry(0.08, 0.08, 0.02, 12).rotateX(Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0x333438 }), x + s * 2.65, 0.85, R.z0 + 0.51); } // enceintes colonnes
    // grand canapé d'angle face à l'écran (cuir), table basse en marbre
    const leather = new THREE.MeshStandardMaterial({ color: 0x6a4630, roughness: 0.6 }), cushion = new THREE.MeshStandardMaterial({ color: 0x7a5238, roughness: 0.7 });
    const sz = R.z0 + 5.6; add(new THREE.BoxGeometry(5.0, 0.42, 1.0), leather, x, 0.21, sz); add(new THREE.BoxGeometry(5.0, 0.6, 0.25), leather, x, 0.72, sz + 0.42);
    for (let k = 0; k < 4; k++) add(new THREE.BoxGeometry(1.15, 0.14, 0.8), cushion, x - 1.8 + k * 1.2, 0.49, sz - 0.05);
    add(new THREE.BoxGeometry(1.0, 0.42, 1.8), leather, x - 2.0, 0.21, sz - 1.35); add(new THREE.BoxGeometry(0.25, 0.6, 1.8), leather, x - 2.38, 0.72, sz - 1.35); // méridienne
    add(new THREE.BoxGeometry(2.0, 0.08, 0.9), marble, x + 0.4, 0.4, sz - 1.7); add(new THREE.BoxGeometry(1.6, 0.36, 0.6), new THREE.MeshStandardMaterial({ color: 0xb8a070, metalness: 0.6, roughness: 0.3 }), x + 0.4, 0.18, sz - 1.7);
    const col = this.world.collision, solid = (x0, z0, x1, z1, h) => { const o = col.addBox(VILLA.O.x + x0, VILLA.O.z + z0, VILLA.O.x + x1, VILLA.O.z + z1, VILLA.Y + h); o.lv = VILLA.LV; };
    solid(x - 2.5, sz - 0.5, x + 2.5, sz + 0.55, 0.9); solid(x - 2.5, sz - 2.25, x - 1.5, sz - 0.5, 0.9); solid(x - 0.6, sz - 2.15, x + 1.4, sz - 1.25, 0.45); solid(x - 2.3, R.z0, x + 2.3, R.z0 + 0.7, 0.5);
    this.screens = [{ id: 'salon', name: 'Smart TV 100 pouces du salon', room: 'salon', mesh: scr, off, x, y: yc, z: z + 0.08, nx: 0, nz: 1, seat: { x: x + 0.6, z: sz - 0.1, face: Math.PI }, w: W, h: H, main: true }];
  }
  // téléviseurs déjà présents dans les autres pièces : on y pose un écran connecté à NOVA TV
  buildScreens() {
    for (const s of this.villa.screens || []) {
      const m = new THREE.Mesh(new THREE.PlaneGeometry(s.w, s.h), this.mat); m.position.set(s.x + s.nx * 0.07, s.y, s.z + s.nz * 0.07); m.rotation.y = Math.atan2(s.nx, s.nz); m.visible = false; this.villa.inGroup.add(m);
      this.screens.push({ ...s, mesh: m });
    }
  }
  screen(id) { return this.screens.find((s) => s.id === id); }
  // ------------------------------------------------------------------ allumer, regarder, télécommande
  setOn(id, v) { const s = this.screen(id); if (!s) return; this.on[id] = v; s.mesh.visible = v; if (s.off) s.off.visible = !v; if (s.main) this.ledP.visible = v && LEDS[this.led][1] !== null; if (v) this.banner = 4; this.onSave && this.onSave(); }
  anyOn() { return Object.values(this.on).some(Boolean); }
  watch(id) {
    const s = this.screen(id); if (!s) return; if (!this.on[id]) this.setOn(id, true);
    this.watching = id; this.banner = 4; const pl = this.player;
    const dd = s.far ? 8 : 2.6, st = s.seat || { x: s.x + s.nx * dd, z: s.z + s.nz * dd, face: Math.atan2(-s.nx, -s.nz) };
    pl.pos.set(VILLA.O.x + st.x, VILLA.Y, VILLA.O.z + st.z); pl.facing = st.face; pl.mesh.position.copy(pl.pos); pl.mesh.rotation.y = st.face;
    if (s.seat && pl.char && pl.char.sit) { pl.char.sit(false); pl.mesh.position.y = VILLA.Y - 0.05; this._sat = true; }
    this.showRemote(true); this.ui.toast(`📺 ${s.name} — ${this.chan().n}. ${this.chan().name}. Flèches : chaînes / volume • P pause • G guide • F favori • E quitter`, 4);
  }
  stopWatch() {
    if (!this.watching) return; this.watching = null; this.guideOn = false; this.showRemote(false); const pl = this.player;
    if (this._sat && pl.char && pl.char.stand) { pl.char.stand(); this._sat = false; } pl.mesh.position.y = VILLA.Y;
    if (this._fov && this.camera) { this.camera.fov = this._fov; this.camera.updateProjectionMatrix(); this._fov = null; }
  }
  applyCam(camera) {
    const s = this.screen(this.watching); if (!s) return; this.camera = camera; const O = VILLA.O, Y = VILLA.Y;
    const dd = s.far ? 8 : 2.6, st = s.seat || { x: s.x + s.nx * dd, z: s.z + s.nz * dd }, k = s.main ? 0.42 : 1; // un peu devant le canapé : l'écran remplit bien la vue
    camera.position.set(O.x + s.x + (st.x - s.x) * k, Y + (s.main ? 1.25 : s.y), O.z + s.z + (st.z - s.z) * k); camera.lookAt(O.x + s.x, Y + s.y - (s.main ? 0.42 : s.far ? 0.5 : 0.2), O.z + s.z); // écran un peu au-dessus de la télécommande
    if (camera.fov !== 50) { this._fov = this._fov || camera.fov; camera.fov = 50; camera.updateProjectionMatrix(); }
  }
  handleKeys(input) {
    if (input.hit('Escape') || input.hit('KeyE')) return this.stopWatch();
    if (input.hit('ArrowUp') || input.hit('PageUp')) this.cmd('up'); if (input.hit('ArrowDown') || input.hit('PageDown')) this.cmd('down');
    if (input.hit('ArrowRight') || input.hit('Equal') || input.hit('NumpadAdd')) this.cmd('v+'); if (input.hit('ArrowLeft') || input.hit('Minus') || input.hit('NumpadSubtract')) this.cmd('v-');
    if (input.hit('KeyP') || input.hit('Space')) this.cmd('pause'); if (input.hit('KeyG')) this.cmd('guide'); if (input.hit('KeyF')) this.cmd('fav'); if (input.hit('KeyM')) this.cmd('mute'); if (input.hit('KeyL')) this.cmd('led');
    for (let d = 0; d <= 9; d++) if (input.hit(`Digit${d}`) || input.hit(`Numpad${d}`)) this.cmd(`d${d}`);
  }
  setCh(n) { n = ((n - 1 + 100) % 100) + 1; this.ch = n; this.paused = false; this.banner = 4; if (this.audio && this.audio.ctx) this.audio.tone(880, 0.05, 0.04, 'sine'); this.onSave && this.onSave(); this.renderRemote(); }
  cmd(c) {
    if (c === 'up') this.setCh(this.ch + 1); else if (c === 'down') this.setCh(this.ch - 1);
    else if (c === 'v+') { this.vol = Math.min(100, this.vol + 5); this.mute = false; this.banner = 2.5; } else if (c === 'v-') { this.vol = Math.max(0, this.vol - 5); this.banner = 2.5; }
    else if (c === 'mute') this.mute = !this.mute;
    else if (c === 'pause') { if (this.canPause()) this.paused = !this.paused; else this.ui.toast('⏺ Programme en direct : la pause n’est pas disponible sur cette chaîne.', 2.5); }
    else if (c === 'fav') { const i = this.favs.indexOf(this.ch); if (i >= 0) this.favs.splice(i, 1); else this.favs.push(this.ch); this.favs.sort((a, b) => a - b); this.banner = 3; }
    else if (c === 'guide') this.guideOn = !this.guideOn;
    else if (c === 'led') { this.led = (this.led + 1) % LEDS.length; this.ledM.color.set(LEDS[this.led][1] || '#000'); this.ledP.visible = !!this.on.salon && LEDS[this.led][1] !== null; this.ui.toast(`💡 LED derrière l’écran : ${LEDS[this.led][0]}`, 1.8); }
    else if (c === 'power') { if (this.watching) { this.setOn(this.watching, false); this.stopWatch(); } }
    else if (c === 'exit') this.stopWatch();
    else if (c === 'nextfav') { const f = this.favs.find((n) => n > this.ch) || this.favs[0]; if (f) this.setCh(f); }
    else if (c.startsWith('go:')) { this.setCh(+c.slice(3)); this.guideOn = false; }
    else if (c.startsWith('d')) { this.digits = (this.digits + c.slice(1)).slice(-3); this.digitT = 1.6; this.banner = 2; }
    else if (c.startsWith('flt:')) this.filter = c.slice(4);
    this.onSave && this.onSave(); this.renderRemote();
  }
  showRemote(v) { if (!this.dom) return; this.dom.classList.toggle('show', v); if (v) this.renderRemote(); }
  renderRemote() {
    if (!this.dom || !this.watching) return; const c = this.chan(), p = this.prog(c), fav = this.favs.includes(c.n);
    const list = this.filter === 'fav' ? CHANNELS.filter((q) => this.favs.includes(q.n)) : this.filter === 'all' ? CHANNELS : CHANNELS.filter((q) => q.key === this.filter);
    this.dom.innerHTML = `<div class="tvr-pad"><div class="tvr-now"><b>${c.n}. ${esc(c.name)}${fav ? ' ★' : ''}</b><small>${esc(p.title)} • ${this.hh(p.h0)}–${this.hh(p.h1)}${c.live ? ' • DIRECT' : ''}${this.paused ? ' • ⏸ pause' : ''}</small></div>
      <div class="tvr-keys"><button data-tv="power">⏻</button><button data-tv="down">CH ▼</button><button data-tv="up">CH ▲</button><button data-tv="v-">🔉</button><button data-tv="v+">🔊</button><button data-tv="mute">${this.mute ? '🔇' : '🔈'} ${this.mute ? 0 : this.vol}</button><button data-tv="pause">⏯</button><button data-tv="fav">${fav ? '★' : '☆'}</button><button data-tv="nextfav">★ ▶</button><button data-tv="guide">${this.guideOn ? 'Fermer le guide' : 'Guide TV'}</button><button data-tv="led">💡 LED</button><button data-tv="exit">Quitter</button></div>
      ${this.guideOn ? `<div class="tvr-chips">${[['all', 'Toutes'], ['fav', '★ Favoris'], ...CATS.map((q) => [q[3], q[2].split(' ')[0]])].map(([k, l]) => `<button data-tv="flt:${k}" class="${this.filter === k ? 'on' : ''}">${l}</button>`).join('')}</div><div class="tvr-guide">${list.map((q) => { const a = this.prog(q), b = this.prog(q, 1); return `<button data-tv="go:${q.n}" class="${q.n === c.n ? 'on' : ''}"><b>${q.n}. ${esc(q.name)}</b><small>${this.hh(a.h0)} ${esc(a.title)} • puis ${this.hh(b.h0)} ${esc(b.title)}</small></button>`; }).join('')}</div>` : ''}</div>`;
  }
  // ------------------------------------------------------------------ interactions dans la villa
  nearest(x, z) {
    if (!this.villa.inside || this.watching) return null; const O = VILLA.O; let best = null;
    for (const s of this.screens) {
      const p = s.seat ? { x: s.seat.x, z: s.seat.z - 0.9 } : { x: s.x + s.nx * (s.far ? 3 : 1.4), z: s.z + s.nz * (s.far ? 3 : 1.4) }, d = Math.hypot(x - (O.x + p.x), z - (O.z + p.z));
      if (d < (s.main ? 2.2 : 1.5) && (!best || d < best.d)) best = { d, it: { label: () => (this.on[s.id] ? `Regarder NOVA TV (${s.name.toLowerCase()})` : `Allumer la télévision et regarder NOVA TV (${s.name.toLowerCase()})`), action: () => this.watch(s.id) } };
    }
    return best;
  }
  // ------------------------------------------------------------------ rendu de l'écran (dessin procédural, partagé par tous les écrans allumés)
  draw() {
    const g = this.ctx2, W = 640, H = 360, c = this.chan(), p = this.prog(c), t = this.paused ? this.tFrozen : this.t;
    if (!this.paused) this.tFrozen = this.t;
    const grad = g.createLinearGradient(0, 0, 0, H); grad.addColorStop(0, c.col); grad.addColorStop(1, '#0a0a10'); g.fillStyle = grad; g.fillRect(0, 0, W, H);
    g.save(); this.scene2d(g, c, t, W, H); g.restore();
    // incrustations : logo de la chaîne, direct, bandeau, guide
    g.fillStyle = 'rgba(0,0,0,0.55)'; g.fillRect(14, 12, 150, 34); g.fillStyle = '#fff'; g.font = '900 18px Arial'; g.fillText(`${c.n}`, 24, 35); g.font = '700 13px Arial'; g.fillText(c.name.slice(0, 18), 58, 34);
    if (c.live) { g.fillStyle = '#e8112d'; g.fillRect(W - 86, 14, 72, 22); g.fillStyle = '#fff'; g.font = '900 13px Arial'; g.fillText('● DIRECT', W - 80, 30); }
    if (this.paused) { g.fillStyle = 'rgba(0,0,0,0.5)'; g.fillRect(0, 0, W, H); g.fillStyle = '#fff'; g.fillRect(W / 2 - 26, H / 2 - 34, 18, 68); g.fillRect(W / 2 + 8, H / 2 - 34, 18, 68); }
    if (this.banner > 0 || this.digits) {
      g.fillStyle = 'rgba(8,10,16,0.85)'; g.fillRect(0, H - 92, W, 92); g.fillStyle = c.col; g.fillRect(0, H - 92, 8, 92);
      g.fillStyle = '#fff'; g.font = '900 22px Arial'; g.fillText(this.digits ? `Chaîne ${this.digits}_` : `${c.n}  ${c.name}${this.favs.includes(c.n) ? '  ★' : ''}`, 22, H - 62);
      g.font = '700 16px Arial'; g.fillText(`${this.hh(p.h0)}–${this.hh(p.h1)}  ${p.title}`.slice(0, 64), 22, H - 38);
      g.fillStyle = 'rgba(255,255,255,0.25)'; g.fillRect(22, H - 26, 380, 6); g.fillStyle = '#fcd116'; g.fillRect(22, H - 26, 380 * p.pct, 6);
      g.fillStyle = '#bbb'; g.font = '700 13px Arial'; g.fillText(`Ensuite : ${this.prog(c, 1).title}`.slice(0, 60), 22, H - 8);
      g.fillStyle = '#fff'; g.font = '700 14px Arial'; g.fillText(`${this.mute ? '🔇 muet' : `Volume ${this.vol}`}  •  NOVA TV 4K (chaîne fictive)`, W - 300, H - 62);
    }
    if (this.guideOn) {
      g.fillStyle = 'rgba(6,8,14,0.92)'; g.fillRect(40, 40, W - 80, H - 80); g.fillStyle = '#fcd116'; g.font = '900 18px Arial'; g.fillText('GUIDE TV — NOVA TV', 58, 68);
      const from = Math.max(1, Math.min(93, c.n - 3)); g.font = '700 13px Arial';
      for (let i = 0; i < 8; i++) { const q = CHANNELS[from - 1 + i], a = this.prog(q), y = 92 + i * 26; g.fillStyle = q.n === c.n ? 'rgba(252,209,22,0.25)' : 'rgba(255,255,255,0.05)'; g.fillRect(52, y - 16, W - 104, 22); g.fillStyle = '#fff'; g.fillText(`${q.n}. ${q.name}`.slice(0, 24), 58, y); g.fillStyle = '#ccc'; g.fillText(`${this.hh(a.h0)} ${a.title}`.slice(0, 44), 250, y); }
    }
    this.tex.needsUpdate = true;
  }
  scene2d(g, c, t, W, H) { // petites animations originales selon la catégorie (aucune image réelle)
    const k = c.key, s = Math.sin, R = (n) => ((Math.sin(n * 91.3 + c.n * 7.1) + 1) / 2);
    if (k === 'info') { g.fillStyle = '#1a2a4a'; g.fillRect(60, 70, 300, 200); g.fillStyle = '#2a3a5a'; g.fillRect(380, 70, 220, 140); g.fillStyle = '#6b4630'; g.beginPath(); g.arc(210, 150, 34, 0, 7); g.fill(); g.fillStyle = '#1f4e9c'; g.fillRect(166, 186, 88, 84); g.fillStyle = '#fff'; g.font = '700 14px Arial'; g.fillText('Plateau du journal', 400, 110); g.fillStyle = '#c8102e'; g.fillRect(0, 280, W, 26); g.fillStyle = '#fff'; g.font = '700 15px Arial'; const tk = '  INFO — Météo : ciel dégagé sur le littoral  •  Économie : le port de Cotonou en activité  •  Sport : la Coupe NOVA (fictive) continue  •'; g.fillText(tk + tk, -((t * 60) % 700), 298); }
    else if (k === 'sport') { g.fillStyle = '#2f8a3a'; g.fillRect(40, 60, W - 80, 230); g.strokeStyle = '#fff'; g.lineWidth = 3; g.strokeRect(50, 70, W - 100, 210); g.beginPath(); g.moveTo(W / 2, 70); g.lineTo(W / 2, 280); g.stroke(); g.beginPath(); g.arc(W / 2, 175, 34, 0, 7); g.stroke(); for (let i = 0; i < 14; i++) { g.fillStyle = i < 7 ? '#fcd116' : '#e8112d'; g.beginPath(); g.arc(80 + R(i) * 480 + s(t * 0.9 + i) * 40, 90 + R(i + 20) * 170 + s(t * 1.3 + i * 2) * 20, 7, 0, 7); g.fill(); } g.fillStyle = '#fff'; g.beginPath(); g.arc(W / 2 + s(t * 1.7) * 180, 175 + s(t * 2.3) * 70, 5, 0, 7); g.fill(); g.fillStyle = 'rgba(0,0,0,0.6)'; g.fillRect(W - 210, 52, 196, 26); g.fillStyle = '#fff'; g.font = '900 14px Arial'; g.fillText(`LAGUNE ${Math.floor(t / 40) % 3} - ${Math.floor(t / 55) % 3} ATLANTIQUE`, W - 202, 70); }
    else if (k === 'mus') { for (let i = 0; i < 24; i++) { const h = 30 + Math.abs(s(t * 3 + i * 0.7) * s(t * 1.1 + i)) * 190; g.fillStyle = `hsl(${(i * 15 + t * 40) % 360},80%,60%)`; g.fillRect(40 + i * 23, 290 - h, 16, h); } g.fillStyle = 'rgba(255,255,255,0.15)'; g.beginPath(); g.arc(W / 2, 120, 60 + s(t * 4) * 6, 0, 7); g.fill(); }
    else if (k === 'cine') { g.fillStyle = '#f0a050'; g.fillRect(0, 60, W, 160); g.fillStyle = '#ffd070'; g.beginPath(); g.arc(120 + (t * 4) % 400, 150, 30, 0, 7); g.fill(); g.fillStyle = '#2a1a10'; g.fillRect(0, 220, W, 80); for (let i = 0; i < 6; i++) { const x = (i * 130 - t * 12) % (W + 120); g.fillRect(x, 160, 12, 60); g.beginPath(); g.arc(x + 6, 150, 34, 0, Math.PI, true); g.fill(); } g.fillStyle = '#000'; g.fillRect(0, 0, W, 60); g.fillRect(0, 300, W, 60); g.beginPath(); g.arc(300 + s(t * 0.5) * 60, 200, 14, 0, 7); g.fill(); g.fillRect(292 + s(t * 0.5) * 60, 212, 16, 34); }
    else if (k === 'kids') { for (let i = 0; i < 9; i++) { g.fillStyle = ['#fcd116', '#ff6a9a', '#3aa0ff', '#2fd08a', '#ff8a30'][i % 5]; const x = 60 + i * 62, y = 200 - Math.abs(s(t * 2 + i)) * 120; g.beginPath(); g.arc(x, y, 18, 0, 7); g.fill(); g.fillStyle = '#111'; g.beginPath(); g.arc(x - 6, y - 4, 3, 0, 7); g.arc(x + 6, y - 4, 3, 0, 7); g.fill(); } g.fillStyle = '#fff'; g.font = '900 30px Arial'; g.fillText('A B C  1 2 3', 190, 300); }
    else if (k === 'life') { g.fillStyle = '#e8dcc4'; g.fillRect(0, 200, W, 160); g.fillStyle = '#555'; g.beginPath(); g.ellipse(W / 2, 220, 110, 34, 0, 0, 7); g.fill(); g.fillStyle = '#c8501a'; g.beginPath(); g.ellipse(W / 2, 214, 96, 26, 0, 0, 7); g.fill(); for (let i = 0; i < 6; i++) { g.fillStyle = 'rgba(255,255,255,0.35)'; g.beginPath(); g.arc(W / 2 - 60 + i * 24 + s(t + i) * 8, 170 - ((t * 30 + i * 20) % 110), 12, 0, 7); g.fill(); } }
    else if (k === 'cul') { g.fillStyle = '#7a4a22'; g.fillRect(0, 230, W, 130); for (let i = 0; i < 5; i++) { g.fillStyle = ['#d8a830', '#0b6e4f', '#c8102e', '#1f4e9c', '#e46a1f'][i]; g.fillRect(70 + i * 105, 110, 80, 120); g.fillStyle = 'rgba(255,255,255,0.4)'; for (let j = 0; j < 4; j++) g.fillRect(78 + i * 105, 120 + j * 26 + s(t + i + j) * 3, 64, 6); } g.fillStyle = '#fff'; g.font = '900 18px Arial'; g.fillText('Patrimoine et culture (documentaire)', 160, 290); }
    else if (k === 'doc') { g.fillStyle = '#2a7ab0'; g.fillRect(0, 210, W, 150); g.fillStyle = '#3f8a3a'; g.beginPath(); g.moveTo(0, 220); for (let x = 0; x <= W; x += 40) g.lineTo(x, 190 + s(x * 0.02 + 1) * 20); g.lineTo(W, 230); g.fill(); for (let i = 0; i < 5; i++) { const x = (i * 150 + t * 15) % (W + 60) - 30; g.fillStyle = '#4a2a16'; g.fillRect(x, 140, 6, 70); g.fillStyle = '#2f7a3a'; for (let a = 0; a < 5; a++) { g.beginPath(); g.ellipse(x + 3, 140, 40, 8, a * 0.6 + s(t + i) * 0.1, 0, 7); g.fill(); } } g.fillStyle = 'rgba(255,255,255,0.6)'; for (let i = 0; i < 6; i++) { g.beginPath(); g.arc((i * 120 + t * 25) % W, 250 + s(t + i) * 8, 3, 0, 7); g.fill(); } }
    else { g.fillStyle = '#fff'; for (let i = 0; i < 5; i++) { g.fillStyle = `hsl(${(t * 30 + i * 70) % 360},70%,55%)`; g.beginPath(); g.arc(W / 2 + s(t + i * 1.3) * 200, H / 2 + s(t * 1.4 + i) * 90, 28, 0, 7); g.fill(); } g.fillStyle = '#fff'; g.font = '900 34px Arial'; g.fillText(`${['QUIZ', 'SHOW', 'DÉFI', 'RIRE'][Math.floor(t / 4) % 4]} !`, W / 2 - 60, 200); }
  }
  // son d'ambiance procédural (très discret ; coupé en pause ou en sourdine)
  sound(dt, near) {
    const A = this.audio; if (!A || !A.ctx || this.mute || this.paused || near <= 0) return; this.beat -= dt; if (this.beat > 0) return;
    const c = this.chan(), v = (this.vol / 100) * near * 0.05, scale = [0, 2, 4, 7, 9, 12], base = { mus: 262, kids: 392, cine: 196, cul: 220, doc: 174, life: 247, div: 330 }[c.key];
    if (c.key === 'info') { this.beat = 0.09 + Math.random() * 0.16; A.tone(170 + Math.random() * 90, 0.07, v * 0.5, 'triangle'); }
    else if (c.key === 'sport') { this.beat = 0.6; if (A.burst) A.burst(0.5, 'bandpass', 900, 0.6, v * 0.9); }
    else { this.beat = c.key === 'mus' ? 0.22 : 0.42; A.tone(base * Math.pow(2, scale[(Math.random() * scale.length) | 0] / 12), 0.25, v * 0.7, c.key === 'kids' ? 'square' : 'sine'); }
  }
  // ------------------------------------------------------------------ boucle
  update(dt) {
    this.t += dt; if (this.banner > 0) this.banner -= dt; if (this.digitT > 0) { this.digitT -= dt; if (this.digitT <= 0 && this.digits) { const n = +this.digits; this.digits = ''; if (n >= 1 && n <= 100) this.setCh(n); } }
    if (this.watching && !this.villa.inside) this.stopWatch();
    if (!this.anyOn() || !this.villa.inside) return;
    // distance au téléviseur allumé le plus proche (rendu et son seulement à proximité : performances)
    const P = this.player.pos, O = VILLA.O; let near = 0;
    for (const s of this.screens) if (this.on[s.id]) { const d = Math.hypot(P.x - (O.x + s.x), P.z - (O.z + s.z)); near = Math.max(near, d < 3 ? 1 : d < 16 ? 1 - (d - 3) / 13 : 0); }
    if (this.watching) near = 1;
    this.acc += dt; if (near > 0 && this.acc > 0.1) { this.acc = 0; this.draw(); }
    this.sound(dt, near);
    if (this.watching && this._lastRemote !== Math.floor(this.t)) { this._lastRemote = Math.floor(this.t); this.renderRemote(); }
  }
  // ------------------------------------------------------------------ application « NOVA TV » (téléphone)
  renderApp(b) {
    const c = this.chan(), p = this.prog(c), tabs = [['guide', 'Guide TV'], ['fav', 'Favoris'], ['ecrans', 'Écrans de la villa']];
    const list = this.view === 'fav' ? CHANNELS.filter((q) => this.favs.includes(q.n)) : CHANNELS.filter((q) => this.filter === 'all' || this.filter === 'fav' || q.key === this.filter);
    let h = `<h4>📺 NOVA TV</h4><p class="ph-note">100 chaînes fictives, programmes originaux du jeu (aucune chaîne ni aucun flux réel).</p>
      <div class="ph-row"><span><b>En cours : ${c.n}. ${esc(c.name)}</b><small>${esc(p.title)} • ${this.hh(p.h0)}–${this.hh(p.h1)}${c.live ? ' • direct' : ''}${this.paused ? ' • en pause' : ''} • volume ${this.mute ? 'muet' : this.vol}</small></span></div>
      <div class="ph-chips"><button data-ntv="down">CH ▼</button><button data-ntv="up">CH ▲</button><button data-ntv="v-">🔉</button><button data-ntv="v+">🔊</button><button data-ntv="mute">${this.mute ? '🔇' : '🔈'}</button><button data-ntv="pause">⏯</button><button data-ntv="fav">${this.favs.includes(c.n) ? '★' : '☆'}</button></div>
      <div class="ph-chips">${tabs.map(([k, l]) => `<button data-ntv="tab:${k}" class="${this.view === k ? 'on' : ''}">${l}</button>`).join('')}</div>`;
    if (this.view === 'ecrans') h += `<p class="ph-note">Tous les téléviseurs de la villa sont connectés à NOVA TV et diffusent la chaîne choisie.</p>${this.screens.map((s) => `<div class="ph-row"><span><b>${esc(s.name)}</b><small>${this.on[s.id] ? 'Allumé' : 'Éteint'}</small></span><span class="pp-acts"><button class="ph-mini" data-ntv="pw:${s.id}">${this.on[s.id] ? 'Éteindre' : 'Allumer'}</button><button class="ph-mini" data-ntv="watch:${s.id}">Regarder</button></span></div>`).join('')}`;
    else {
      if (this.view === 'guide') h += `<div class="ph-chips">${[['all', 'Toutes'], ...CATS.map((q) => [q[3], `${q[0]}–${q[1]}`])].map(([k, l]) => `<button data-ntv="flt:${k}" class="${this.filter === k ? 'on' : ''}">${l}</button>`).join('')}</div>`;
      let lastCat = ''; h += list.map((q) => { const a = this.prog(q), bb = this.prog(q, 1), cc = this.prog(q, 2); const head = q.cat !== lastCat ? `<h5>${q.cat}</h5>` : ''; lastCat = q.cat; return `${head}<div class="ph-row"><span><b>${q.n}. ${esc(q.name)}${this.favs.includes(q.n) ? ' ★' : ''}</b><small>${this.hh(a.h0)} ${esc(a.title)}</small><small>${this.hh(bb.h0)} ${esc(bb.title)} • ${this.hh(cc.h0)} ${esc(cc.title)}</small></span><button class="ph-mini" data-ntv="go:${q.n}">${q.n === c.n ? '▶' : 'Choisir'}</button></div>`; }).join('') || '<p class="ph-note">Aucune chaîne favorite.</p>';
    }
    b.innerHTML = h;
  }
  onPhone(v) {
    const [a, arg] = v.split(':');
    if (a === 'tab') this.view = arg; else if (a === 'flt') this.filter = arg;
    else if (a === 'go') { this.setCh(+arg); this.guideOn = false; }
    else if (a === 'pw') this.setOn(arg, !this.on[arg]);
    else if (a === 'watch') { if (!this.villa.inside) { this.ui.toast('Rends-toi dans la villa pour regarder la télévision.', 2.5); return; } this.economy.togglePhone(false); return this.watch(arg); }
    else this.cmd(a);
    this.onSave && this.onSave(); this.economy.renderPhone();
  }
  serialize() { return { ch: this.ch, vol: this.vol, mute: this.mute, favs: this.favs, on: this.on, led: this.led }; }
  restore(s) {
    if (!s) return; this.ch = s.ch || 1; this.vol = s.vol ?? 40; this.mute = !!s.mute; this.favs = s.favs || this.favs; this.led = s.led ?? 1;
    this.ledM.color.set(LEDS[this.led][1] || '#000'); const save = this.onSave; this.onSave = null; for (const [id, v] of Object.entries(s.on || {})) if (v) this.setOn(id, true); this.onSave = save; this.banner = 0;
  }
}
