// Mission 021 — données de voyage (vols FICTIFS : compagnies, numéros de vol, horaires et tarifs inventés pour le jeu).
// Les durées de vol sont indicatives (ordre de grandeur d'un vol depuis Cotonou, escales éventuelles non détaillées).
export const AIRLINES = {
  nova: { name: 'NOVA AIR', color: '#0b6e4f', code: 'NV' },
  lagune: { name: 'Air Lagune', color: '#1f4e9c', code: 'LG' },
  atlant: { name: 'Atlantique Airways', color: '#c8102e', code: 'AT' },
};
// [id, ville, pays, région, compagnie, durée indicative (h), prix éco, prix affaires, heures de départ quotidiennes, porte]
export const DESTS = [
  ['lome', 'Lomé', 'Togo', 'Afrique de l’Ouest', 'lagune', 0.75, 60000, 150000, [7.5, 17], 'A1'],
  ['accra', 'Accra', 'Ghana', 'Afrique de l’Ouest', 'lagune', 1, 90000, 220000, [8.25, 18.5], 'A1'],
  ['abidjan', 'Abidjan', 'Côte d’Ivoire', 'Afrique de l’Ouest', 'nova', 1.5, 150000, 380000, [9, 19.5], 'A2'],
  ['dakar', 'Dakar', 'Sénégal', 'Afrique de l’Ouest', 'atlant', 3, 280000, 700000, [10.5], 'A2'],
  ['casablanca', 'Casablanca', 'Maroc', 'Afrique du Nord', 'atlant', 4.5, 350000, 900000, [11.5], 'A3'],
  ['johannesburg', 'Johannesburg', 'Afrique du Sud', 'Afrique australe', 'nova', 6, 600000, 2000000, [13], 'A3'],
  ['paris', 'Paris', 'France', 'Europe', 'nova', 6.5, 450000, 1500000, [22.5], 'A4'],
  ['londres', 'Londres', 'Royaume-Uni', 'Europe', 'atlant', 7, 480000, 1600000, [21.5], 'A4'],
  ['istanbul', 'Istanbul', 'Turquie', 'Europe et Asie', 'atlant', 7, 420000, 1300000, [20], 'A3'],
  ['dubai', 'Dubaï', 'Émirats arabes unis', 'Moyen-Orient', 'nova', 7.5, 520000, 1800000, [23.25], 'A4'],
  ['montreal', 'Montréal', 'Canada', 'Amérique du Nord', 'lagune', 11, 750000, 2400000, [14.5], 'A2'],
  ['newyork', 'New York', 'États-Unis', 'Amérique du Nord', 'nova', 11.5, 800000, 2600000, [15.5], 'A1'],
].map(([id, city, country, region, air, dur, eco, biz, times, gate], i) => ({ id, city, country, region, air, dur, eco, biz, times, gate, num: `${AIRLINES[air].code} ${300 + i * 7}` }));
// décalage horaire indicatif par rapport à Cotonou (UTC+1) ; « hiver » = heure d'hiver (l'heure d'été change d'une heure)
const TZ = { lome: [-1], accra: [-1], abidjan: [-1], dakar: [-1], casablanca: [0], johannesburg: [1], paris: [0, 1], londres: [-1, 1], istanbul: [2], dubai: [3], montreal: [-6, 1], newyork: [-6, 1] };
for (const D of DESTS) { D.tz = TZ[D.id][0]; D.dst = !!TZ[D.id][1]; }
export const DEST_BY_ID = Object.fromEntries(DESTS.map((d) => [d.id, d]));
// départs à partir d'un instant absolu (jour × 24 + heure), triés
export function departures(abs, hours = 24) {
  const out = []; const d0 = Math.floor(abs / 24) - 1;
  for (let d = d0; d <= d0 + 2 + Math.ceil(hours / 24); d++) for (const D of DESTS) for (const t of D.times) { const a = d * 24 + t; if (a >= abs - 1 && a <= abs + hours) out.push({ D, at: a, day: d, h: t }); }
  return out.sort((a, b) => a.at - b.at);
}
export function status(dep, abs) {
  const dt = dep.at - abs;
  if (dt < 0) return ['Parti', '#8a8f96'];
  if (dt < 0.25) return ['Porte fermée', '#e8112d'];
  if (dt < 0.75) return ['Embarquement', '#2fd08a'];
  if (dt < 3) return ['Enregistrement', '#fcd116'];
  return ['À l’heure', '#d8dde2'];
}
export const hh = (h) => { h = ((h % 24) + 24) % 24; const m = Math.round((h % 1) * 60); return `${String(Math.floor(h) + (m === 60 ? 1 : 0)).padStart(2, '0')}:${String(m === 60 ? 0 : m).padStart(2, '0')}`; };
