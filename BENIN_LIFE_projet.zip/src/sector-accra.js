// Mission 023, phase 1 — ACCRA (Ghana), deuxième secteur pays explorable, à sa position géographique réelle dans le
// repère du jeu (projection de la région du Bénin, échelle 1:5). Plan STYLISÉ et positions approximatives : côte orientée
// est-nord-est, lagune de Korle à l'ouest, Jamestown (phare, pirogues de pêche), Black Star Square (Black Star Gate) et
// l'Arche de l'Indépendance, parc commémoratif Kwame Nkrumah, marché de Makola, Oxford Street (Osu), Ring Road,
// Labadi Beach à l'est, aéroport Kotoka au nord-est. Commerces, hôtel et restaurants portant un nom inventé : FICTIFS.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { colorize } from './vehicles.js';
import { toWorld } from './africa-data.js';

const PI = Math.PI;
const O = toWorld(5.556, -0.197); // origine du secteur (centre d'Accra)
const coastAt = (lx) => 500 - 0.353 * (lx + 354); // trait de côte stylisé (orienté est-nord-est), en coordonnées locales
export const ACCRA = { id: 'accra', country: '288', name: 'Accra', O, X0: -800, X1: 1250, Z0: -1350, coastAt, LAG: { x0: -720, x1: -600, z0: 300, z1: 460 } };
const inLag = (x, z) => x > ACCRA.LAG.x0 && x < ACCRA.LAG.x1 && z > ACCRA.LAG.z0 && z < ACCRA.LAG.z1;
ACCRA.has = (x, z) => x > O.x + ACCRA.X0 - 40 && x < O.x + ACCRA.X1 + 40 && z > O.z + ACCRA.Z0 - 40 && z < O.z + 1200;
ACCRA.near = (x, z) => Math.abs(x - O.x - 225) < 3500 && Math.abs(z - O.z + 300) < 3200;
ACCRA.water = (x, z) => { const lx = x - O.x, lz = z - O.z; return lz > coastAt(lx) || inLag(lx, lz); };
ACCRA.clamp = (obj, margin = 1) => {
  const p = obj.pos; let lx = Math.max(ACCRA.X0 + 2, Math.min(ACCRA.X1 - 2, p.x - O.x)), lz = Math.max(ACCRA.Z0 + 2, p.z - O.z);
  lz = Math.min(coastAt(lx) - margin, lz);
  if (inLag(lx, lz)) { if (obj._dry) { lx = obj._dry.x - O.x; lz = obj._dry.z - O.z; if (obj.speed) obj.speed *= -0.2; } }
  p.x = O.x + lx; p.z = O.z + lz; if (!obj._dry) obj._dry = { x: 0, z: 0 }; if (!inLag(lx, lz)) { obj._dry.x = p.x; obj._dry.z = p.z; }
};
// voies principales (axes, coupés avant la plage) : [x0, z0, x1, z1, largeur, nom]
const EW = [[-700, 150, 560, 150, 12, 'High Street'], [-780, 30, 900, 30, 10, ''], [-780, -120, 1240, -120, 12, 'Route N1 (vers Tema et Aflao)'], [-780, -320, 1240, -320, 10, ''], [-700, -560, 1100, -560, 10, ''], [-300, -820, 1100, -820, 10, '']];
const NS = [-560, -300, -90, 90, 300, 520, 760, 1000].map((x) => [x, -1000, x, Math.min(coastAt(x) - 40, x === 90 ? 160 : 999), 10, x === 90 ? 'Independence Avenue' : x === 300 ? 'Oxford Street (Osu)' : '']);
const RING = { cx: 0, cz: 200, r: 640 };
const P = {
  bss: { x: 95, z: 222 }, arche: { x: -2, z: 196 }, nkrumah: { x: -155, z: 272 }, makola: { x: -215, z: 92 }, jamestown: { x: -370, z: 455 },
  labadi: { x: 1010, z: -40 }, aeroport: { x: 640, z: -1080 }, gare: { x: -40, z: -78 }, hopital: { x: -660, z: 180 }, ecole: { x: 640, z: -420 },
  hotel: { x: 430, z: 105 }, mall: { x: 640, z: -10 }, sortieEst: { x: 1225, z: -120 }, oxford: { x: 300, z: -60 },
};
const TAXIS = [[-212, 41.5, 'Makola'], [95, 161.5, 'Black Star Square'], [640, -1052, 'Aéroport Kotoka'], [-40, -46, 'Station de tro-tro'], [312, -135, 'Osu'], [1013, -108, 'Labadi']];
const QUARTIERS = [['Jamestown', -380, 420], ['Korle Gonno', -680, 380], ['Makola (centre)', -260, 90], ['Adabraka', -150, -150], ['Black Star Square', 95, 220], ['Osu', 340, -40], ['Ring Road', 0, -440], ['Kwame Nkrumah Circle', -300, -330], ['Labadi', 1000, -60], ['Airport Residential', 500, -700], ['Kotoka (aéroport)', 700, -1100]];
const SHOPS = ['GOD IS KING ENTERPRISE', 'BLESSED HANDS SALON', 'MOBILE MONEY', 'NO WEAPON VENTURES', 'SANKOFA PHONES', 'FAITH CHOP BAR', 'KENTE & MORE', 'GRACE PHARMACY', 'EBENEZER PRINTING', 'AKWAABA PROVISIONS', 'TRUST IN GOD TAILORING', 'MEDAASE STORE'];
const NAMES = { f: ['Ama', 'Akua', 'Abena', 'Efua', 'Esi', 'Adwoa', 'Akosua', 'Afia', 'Naa Dedei', 'Yaa'], m: ['Kwame', 'Kofi', 'Kwabena', 'Kojo', 'Yaw', 'Kwaku', 'Kwesi', 'Nii Armah', 'Ekow', 'Fiifi'] };

export function buildAccra(ctx) {
  const { scene, world, quality } = ctx, C = world.collision, g = new THREE.Group(); g.position.set(O.x, 0, O.z); scene.add(g);
  const parts = [], glow = [], heads = [], signs = {}, cols = [], points = [], lanes = [], lamps = [];
  const box = (x0, y0, z0, x1, y1, z1, c, arr = parts) => arr.push(colorize(new THREE.BoxGeometry(Math.abs(x1 - x0) || 0.01, Math.abs(y1 - y0) || 0.01, Math.abs(z1 - z0) || 0.01).translate((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), c));
  const solid = (x0, z0, x1, z1, h) => { const o = C.addBox(O.x + Math.min(x0, x1), O.z + Math.min(z0, z1), O.x + Math.max(x0, x1), O.z + Math.max(z0, z1), h); cols.push(o); return o; };
  const circle = (x, z, r, h) => { const o = C.addCircle(O.x + x, O.z + z, r, h); cols.push(o); return o; };
  const Pt = (x, z, r, label, action) => points.push({ x, z, r, label, action });
  const R = (() => { let a = 5717; return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; })();
  const reserved = [], reserve = (x0, z0, x1, z1) => reserved.push({ x0, z0, x1, z1 }), isRes = (x0, z0, x1, z1) => reserved.some((r) => x1 > r.x0 && x0 < r.x1 && z1 > r.z0 && z0 < r.z1);
  const ry2 = (geo, x, z, a) => geo.rotateY(a).translate(x, 0, z);
  // ---- sol, mer, plage (côte en biais), lagune de Korle ----
  box(ACCRA.X0 - 400, -0.12, ACCRA.Z0 - 400, ACCRA.X1 + 400, -0.02, 900, 0x8a8a52);
  const ang = Math.atan2(-0.353, 1), shore = (off, w, y, c) => { const L = 2700, g2 = new THREE.BoxGeometry(L, y, w).rotateY(-ang).translate(225, y / 2 - 0.02, coastAt(225) + off / Math.cos(ang)); parts.push(colorize(g2, c)); }; // décalage perpendiculaire à la côte
  shore(-14, 30, 0.04, 0xe8d8b0); shore(800, 1600, 0.05, 0x1b6a82);
  box(ACCRA.LAG.x0, -0.01, ACCRA.LAG.z0, ACCRA.LAG.x1, 0.035, ACCRA.LAG.z1, 0x3a6a5a);
  // ---- routes ----
  const roadSeg = (x0, z0, x1, z1, w, c = 0x3a3c40) => { if (x0 === x1) box(x0 - w / 2, 0.02, Math.min(z0, z1), x0 + w / 2, 0.05, Math.max(z0, z1), c); else box(Math.min(x0, x1), 0.02, z0 - w / 2, Math.max(x0, x1), 0.05, z0 + w / 2, c); };
  const clipEW = ([x0, z, x1, , w]) => { let a = x0, b = x1; while (b > a && z > coastAt(b) - 30) b -= 10; return [a, z, b, z, w]; };
  const EWc = EW.map(clipEW);
  for (const [x0, z0, x1, z1, w] of EWc) { roadSeg(x0, z0, x1, z1, w); box(x0, 0.05, z0 - 0.08, x1, 0.06, z0 + 0.08, 0xf2c200); }
  for (const [x0, z0, , z1, w] of NS) { if (inLag(x0, (z0 + z1) / 2)) continue; roadSeg(x0, z0, x0, z1, w); }
  const ringPts = []; for (let a = PI; a <= 2 * PI + 1e-6; a += PI / 90) { const px = RING.cx + Math.cos(a) * RING.r, pz = RING.cz + Math.sin(a) * RING.r; if (pz < coastAt(px) - 34) ringPts.push([px, pz]); }
  for (let i = 0; i < ringPts.length - 1; i++) { const [ax, az] = ringPts[i], [bx, bz] = ringPts[i + 1], len = Math.hypot(bx - ax, bz - az); parts.push(colorize(new THREE.BoxGeometry(12, 0.03, len + 1).rotateY(Math.atan2(bx - ax, bz - az)).translate((ax + bx) / 2, 0.045, (az + bz) / 2), 0x3a3c40)); }
  { const a0 = 120, a1 = 1240; const dx = a1 - a0, len = Math.hypot(dx, 0.353 * dx), cx = (a0 + a1) / 2; parts.push(colorize(new THREE.BoxGeometry(len, 0.03, 10).rotateY(-ang).translate(cx, 0.045, coastAt(cx) - 42), 0x3a3c40)); } // route côtière vers Labadi
  const nearRing = (x, z, d) => Math.abs(Math.hypot(x - RING.cx, z - RING.cz) - RING.r) < d && z < RING.cz && z < coastAt(x) - 30;
  const nearCoastRd = (x, z, d) => x > 110 && Math.abs(z - (coastAt(x) - 42)) < 5 + d;
  const roadAt = (x, z, m) => EWc.some(([x0, zz, x1, , w]) => x > x0 - m && x < x1 + m && Math.abs(z - zz) < w / 2 + m) || NS.some(([xx, z0, , z1, w]) => Math.abs(x - xx) < w / 2 + m && z > z0 - m && z < z1 + m) || nearRing(x, z, 6 + m) || nearCoastRd(x, z, m);
  // ---- réservations (lieux) ----
  reserve(20, 168, 172, 290); reserve(-40, 175, 30, 222); reserve(-218, 222, -92, 322); reserve(-285, 48, -145, 138); reserve(-400, 432, -320, 500); reserve(-80, -112, 10, -40); reserve(-700, 150, -620, 230);
  reserve(600, -445, 680, -395); reserve(395, 73, 470, 141); reserve(585, -55, 695, 25); reserve(500, -1350, 1250, -980); reserve(1180, -160, 1250, -82); reserve(240, -260, 290, -230); reserve(-330, -350, -270, -290);
  reserve(170, -80, 230, -40); reserve(330, -176, 360, -150); reserve(520 - 30, -100, 520 - 6, -76); reserve(-259, -555, -221, -525);
  for (const [x, z] of TAXIS) reserve(x - 4, z - 4, x + 4, z + 4);
  // ---- immeubles et maisons (identité ghanéenne : murs peints, enseignes peintes en anglais, couleurs kente) ----
  const FAC = [0xf2e6c8, 0xe8d4a0, 0xd8e8d0, 0xf0d0b0, 0xc8d8e8, 0xf6f2e8, 0xe8b878, 0xd0c0a0], TRIM = [0xd8a020, 0x1f7a3a, 0xc8102e, 0x1a1a1a], ROOF = [0x9aa0a6, 0x8a5a3a, 0x7a7e84];
  const building = (x, z, w, d, ry, kind) => {
    const fac = FAC[(R() * FAC.length) | 0], trim = TRIM[(R() * TRIM.length) | 0], floors = kind === 'tour' ? 6 + ((R() * 7) | 0) : kind === 'centre' ? 2 + ((R() * 3) | 0) : kind === 'maison' ? 1 : 1 + ((R() * 2) | 0), h = floors * 3.1;
    const m = new THREE.Matrix4().makeRotationY(ry).setPosition(x, 0, z), add = (geo, c) => parts.push(colorize(geo.applyMatrix4(m), c));
    if (kind === 'compound') { const W = w / 2, D = d / 2; for (const [a, b, c2, e] of [[-W, -D, W, -D + 0.25], [-W, -D, -W + 0.25, D], [W - 0.25, -D, W, D], [-W, D - 0.25, -1.3, D], [1.3, D - 0.25, W, D]]) add(new THREE.BoxGeometry(c2 - a, 2.2, e - b).translate((a + c2) / 2, 1.1, (b + e) / 2), fac); add(new THREE.BoxGeometry(2.6, 2.1, 0.08).translate(0, 1.05, D - 0.12), 0x5a5e64); add(new THREE.BoxGeometry(w * 0.62, 3, d * 0.44).translate(0, 1.5, -D * 0.42), FAC[(R() * FAC.length) | 0]); add(new THREE.BoxGeometry(w * 0.7, 0.4, d * 0.52).rotateX(0.12).translate(0, 3.2, -D * 0.42), ROOF[(R() * ROOF.length) | 0]); }
    else {
      add(new THREE.BoxGeometry(w, h, d).translate(0, h / 2, 0), fac); add(new THREE.BoxGeometry(w + 0.2, 0.35, d + 0.2).translate(0, h + 0.17, 0), kind === 'maison' ? ROOF[(R() * ROOF.length) | 0] : 0xd8d0c0);
      for (let f = 0; f < floors; f++) for (let k = -1; k <= 1; k++) add(new THREE.BoxGeometry(w * 0.17, 1.3, 0.06).translate(k * w * 0.3, 1.8 + f * 3.1, d / 2 + 0.03), kind === 'tour' ? 0x3a6a8a : 0x2a3036);
      if (kind === 'tour') for (let f = 1; f < floors; f++) add(new THREE.BoxGeometry(w + 0.1, 0.25, d + 0.1).translate(0, f * 3.1, 0), 0xe8e4dc);
      add(new THREE.BoxGeometry(w * 0.96, 0.6, 0.05).translate(0, 0.6, d / 2 + 0.03), trim); // soubassement peint
      if (kind === 'centre' || (kind !== 'maison' && R() < 0.4)) { add(new THREE.BoxGeometry(w * 0.92, 0.14, 1.8).translate(0, 2.8, d / 2 + 0.9), TRIM[(R() * TRIM.length) | 0]); const t = SHOPS[(R() * SHOPS.length) | 0]; (signs[t] || (signs[t] = [])).push(new THREE.PlaneGeometry(Math.min(w * 0.85, 6.5), 0.75).translate(0, 3.4, d / 2 + 0.05).applyMatrix4(m)); }
    }
    const sw = Math.abs(Math.sin(ry)) > 0.5, hw = (sw ? d : w) / 2, hd = (sw ? w : d) / 2; cols.push(C.addBox(O.x + x - hw, O.z + z - hd, O.x + x + hw, O.z + z + hd, kind === 'compound' ? 3.4 : h));
  };
  const zoneKind = (x, z) => (x > 380 && x < 760 && z > -330 && z < -120 ? 'tour' : (x > -340 && x < 360 && z > -120 && z < 150) || (Math.abs(x - 300) < 30) ? 'centre' : z < -560 ? (R() < 0.6 ? 'compound' : 'maison') : R() < 0.4 ? 'compound' : R() < 0.5 ? 'maison' : 'immeuble');
  const dens = quality === 'low' ? 0.55 : quality === 'high' ? 0.95 : 0.8;
  const xs = [-780, ...NS.map((n) => n[0]), 1240], zs = [-1000, -820, -560, -320, -120, 30, 150, 520];
  for (let i = 0; i < xs.length - 1; i++) for (let j = 0; j < zs.length - 1; j++) {
    const bx0 = xs[i] + 8, bx1 = xs[i + 1] - 8, bz0 = zs[j] + 8, bz1 = zs[j + 1] - 8; if (bx1 - bx0 < 20 || bz1 - bz0 < 20) continue;
    const place = (x, z, w, d, rr) => { const sw = Math.abs(Math.sin(rr)) > 0.5, hw = (sw ? d : w) / 2 + 1, hd = (sw ? w : d) / 2 + 1;
      if (R() > dens || isRes(x - hw, z - hd, x + hw, z + hd) || roadAt(x, z, Math.max(hw, hd)) || inLag(x, z) || inLag(x - hw, z - hd) || inLag(x + hw, z + hd) || z + hd > coastAt(x + hw) - 34 || z + hd > coastAt(x - hw) - 34) return; building(x, z, w, d, rr, zoneKind(x, z)); reserve(x - hw, z - hd, x + hw, z + hd); };
    for (let x = bx0 + 8; x < bx1 - 6; x += 15) { const w = 9 + R() * 4, d = 9 + R() * 4; place(x, bz1 - d / 2 - 1, w, d, 0); place(x, bz0 + d / 2 + 1, w, d, PI); }
    for (let z = bz0 + 22; z < bz1 - 20; z += 15) { const w = 9 + R() * 4, d = 9 + R() * 4; place(bx0 + d / 2 + 1, z, w, d, -PI / 2); place(bx1 - d / 2 - 1, z, w, d, PI / 2); }
  }
  // ---- arbres, cocotiers, lampadaires ----
  const tree = (x, z, h, r, palm) => { parts.push(colorize(new THREE.CylinderGeometry(0.16, 0.28, h, 5).translate(x, h / 2, z), 0x6a5236)); parts.push(colorize(palm ? new THREE.ConeGeometry(2.8, 1.4, 7).translate(x, h + 0.3, z) : new THREE.SphereGeometry(r, 7, 5).translate(x, h + r * 0.4, z), palm ? 0x3f7a2a : 0x2f6a2a)); circle(x, z, 0.35, h); };
  for (let x = 140; x < 1230; x += 26) { const z = coastAt(x) - 34; if (!isRes(x - 2, z - 2, x + 2, z + 2)) tree(x, z, 8 + R() * 3, 0, true); }
  const lamp = (x, z, rr) => { const m = new THREE.Matrix4().makeRotationY(rr).setPosition(x, 0, z); parts.push(colorize(new THREE.CylinderGeometry(0.07, 0.1, 7, 6).translate(0, 3.5, 0).applyMatrix4(m), 0x5a5e64)); parts.push(colorize(new THREE.BoxGeometry(0.08, 0.08, 1.8).translate(0, 6.9, 0.85).applyMatrix4(m), 0x5a5e64)); heads.push(new THREE.BoxGeometry(0.35, 0.15, 0.7).translate(0, 6.85, 1.7).applyMatrix4(m)); circle(x, z, 0.18, 7); lamps.push([x + Math.sin(rr) * 1.7, z + Math.cos(rr) * 1.7]); };
  for (const [x0, z0, x1, , w] of EWc) for (let x = x0 + 15, k = 0; x < x1 - 10; x += 34, k++) { const s = k % 2 ? 1 : -1, z = z0 + s * (w / 2 + 0.7); if (isRes(x - 1, z - 1, x + 1, z + 1) || NS.some((n) => Math.abs(n[0] - x) < 9) || nearRing(x, z, 8) || inLag(x, z) || z > coastAt(x) - 32) continue; lamp(x, z, s > 0 ? PI : 0); }
  for (const [x0, , , z1] of NS) for (let z = -980, k = 0; z < z1 - 8; z += 34, k++) { const s = k % 2 ? 1 : -1, x = x0 + s * 5.7; if (isRes(x - 1, z - 1, x + 1, z + 1) || EWc.some((e) => Math.abs(e[1] - z) < 9) || nearRing(x, z, 8) || inLag(x, z)) continue; lamp(x, z, s > 0 ? -PI / 2 : PI / 2); }
  // ---- drapeau du Ghana (rouge, or, vert ; étoile noire) et motifs kente ----
  const flagTex = (() => { const c = document.createElement('canvas'); c.width = 300; c.height = 200; const x = c.getContext('2d'); [['#ce1126', 0], ['#fcd116', 1], ['#006b3f', 2]].forEach(([col, i]) => { x.fillStyle = col; x.fillRect(0, i * 66.7, 300, 67); }); x.fillStyle = '#000'; x.beginPath(); for (let k = 0; k < 10; k++) { const r = k % 2 ? 12 : 30, a = -PI / 2 + k * PI / 5; x.lineTo(150 + Math.cos(a) * r, 100 + Math.sin(a) * r); } x.fill(); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t; })();
  const flag = (x, z, h = 9) => { parts.push(colorize(new THREE.CylinderGeometry(0.06, 0.08, h, 6).translate(x, h / 2, z), 0xd8dde2)); const f = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 1.6), new THREE.MeshBasicMaterial({ map: flagTex, side: THREE.DoubleSide })); f.position.set(x + 1.25, h - 0.9, z); g.add(f); circle(x, z, 0.12, h); };
  const label = (t, sub, w, h, bg, fg) => { const c = document.createElement('canvas'); c.width = 1024; c.height = Math.max(64, Math.round(1024 * h / w)); const x = c.getContext('2d'); x.fillStyle = bg; x.fillRect(0, 0, c.width, c.height); x.fillStyle = fg; x.textAlign = 'center'; x.textBaseline = 'middle'; x.font = `900 ${Math.round(c.height * (sub ? 0.38 : 0.55))}px Arial`; x.fillText(t, c.width / 2, c.height * (sub ? 0.38 : 0.52), c.width - 30); if (sub) { x.font = `700 ${Math.round(c.height * 0.2)}px Arial`; x.fillText(sub, c.width / 2, c.height * 0.78, c.width - 30); } const tx = new THREE.CanvasTexture(c); tx.colorSpace = THREE.SRGBColorSpace; return new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ map: tx, side: THREE.DoubleSide })); };
  const put = (mesh, x, y, z, rr = 0) => { mesh.position.set(x, y, z); mesh.rotation.y = rr; g.add(mesh); return mesh; };
  const roadSign = (t, x, z, rr) => { parts.push(colorize(new THREE.CylinderGeometry(0.05, 0.05, 3, 6).translate(x, 1.5, z), 0x8a8f96)); put(label(t, '', 3.4, 0.7, '#0b5a3a', '#ffffff'), x, 3.1, z, rr); circle(x, z, 0.1, 3); };
  // ---- Black Star Square : esplanade de défilés, tribunes, Black Star Gate (stylisés) ----
  { const b = P.bss; box(22, 0.03, 170, 170, 0.08, 288, 0xd8d4c8); for (let k = 0; k < 4; k++) box(30 + k * 36, 0.08, 172, 58 + k * 36, 0.09, 184, 0xc8c4b8);
    box(28, 0, 172, 162, 1.2, 180, 0xe8e4dc); box(28, 1.2, 173, 162, 2.4, 176, 0xe8e4dc); box(28, 2.4, 172, 162, 3.0, 174, 0xe8e4dc); solid(28, 172, 162, 180, 3); // tribune nord
    for (const s of [-1, 1]) { box(b.x + s * 9 - 3, 0, 268, b.x + s * 9 + 3, 16, 274, 0xf2f0ea); solid(b.x + s * 9 - 3, 268, b.x + s * 9 + 3, 274, 16); } box(b.x - 12, 16, 268, b.x + 12, 19, 274, 0xf2f0ea); solid(b.x - 12, 268, b.x + 12, 274, 19);
    const st = new THREE.Shape(); for (let k = 0; k < 10; k++) { const r = k % 2 ? 1.2 : 3, a = -PI / 2 + k * PI / 5; const fn = k ? 'lineTo' : 'moveTo'; st[fn](Math.cos(a) * r, -Math.sin(a) * r); } const star = new THREE.Mesh(new THREE.ExtrudeGeometry(st, { depth: 0.6, bevelEnabled: false }), new THREE.MeshStandardMaterial({ color: 0x0a0a0a, roughness: 0.4 })); star.position.set(b.x, 22.3, 270.7); g.add(star);
    for (const dx of [-60, -30, 30, 60]) flag(b.x + dx, 262); put(label('BLACK STAR SQUARE', 'Place de l’Indépendance • représentation stylisée', 8, 1.2, '#006b3f', '#fcd116'), b.x, 2.6, 186, PI);
    Pt(b.x, 194, 3.5, '🏛️ Visiter : Black Star Square', () => ctx.visit('bss')); Pt(b.x, 262, 3, '⭐ Black Star Gate', () => ctx.visit('bss')); }
  // ---- Arche de l'Indépendance (stylisée) ----
  { const a = P.arche; for (const s of [-1, 1]) { box(a.x + s * 7 - 2, 0, a.z - 2, a.x + s * 7 + 2, 12, a.z + 2, 0xf6f6f2); solid(a.x + s * 7 - 2, a.z - 2, a.x + s * 7 + 2, a.z + 2, 12); } box(a.x - 9, 12, a.z - 2, a.x + 9, 15, a.z + 2, 0xf6f6f2); solid(a.x - 9, a.z - 2, a.x + 9, a.z + 2, 15); box(a.x - 6, 12.6, a.z + 2, a.x + 6, 14.4, a.z + 2.1, 0xd8b030);
    Pt(a.x, a.z - 6, 3, '🏛️ Visiter : Arche de l’Indépendance', () => ctx.visit('arche')); put(label('INDEPENDENCE ARCH', 'Arche de l’Indépendance • stylisée', 5, 0.8, '#ce1126', '#ffffff'), a.x, 2.2, a.z - 2.2, PI); }
  // ---- parc commémoratif Kwame Nkrumah : allée, bassins, mausolée et statue (stylisés) ----
  { const n = P.nkrumah; box(-215, 0.03, 225, -95, 0.07, 320, 0x7a9a4e); box(n.x - 3, 0.07, 228, n.x + 3, 0.09, 300, 0xd8d4c8);
    for (const s of [-1, 1]) { box(n.x + s * 14 - 6, 0.07, 250, n.x + s * 14 + 6, 0.6, 290, 0xd8d0c0); box(n.x + s * 14 - 5.4, 0.55, 250.6, n.x + s * 14 + 5.4, 0.6, 289.4, 0x4aa8d8, glow); solid(n.x + s * 14 - 6, 250, n.x + s * 14 + 6, 290, 0.6); }
    box(n.x - 7, 0, 300, n.x + 7, 1, 314, 0xe8e4dc); parts.push(colorize(new THREE.CylinderGeometry(0.6, 4.6, 16, 4).rotateY(PI / 4).translate(n.x, 9, 307), 0xd8d0c8)); solid(n.x - 7, 300, n.x + 7, 314, 17);
    { const br = new THREE.MeshStandardMaterial({ color: 0x5a4a32, metalness: 0.6, roughness: 0.4 }), stt = new THREE.Group(); const body = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.6, 3.6, 8), br); body.position.y = 1.8; stt.add(body); const hd = new THREE.Mesh(new THREE.SphereGeometry(0.42, 10, 8), br); hd.position.y = 3.95; stt.add(hd); const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 2, 6), br); arm.position.set(0.65, 4.0, 0.3); arm.rotation.z = -0.9; stt.add(arm); stt.position.set(n.x, 2.4, 244); g.add(stt); box(n.x - 1.6, 0, 242.4, n.x + 1.6, 2.4, 245.6, 0x3a3a3a); solid(n.x - 1.6, 242.4, n.x + 1.6, 245.6, 2.4); }
    for (let k = 0; k < 8; k++) tree(-208 + (k % 2) * 106, 230 + Math.floor(k / 2) * 24, 7, 2.6);
    put(label('KWAME NKRUMAH MEMORIAL PARK', 'Parc commémoratif • représentation stylisée', 8, 1.2, '#1a1a1a', '#fcd116'), n.x, 2.4, 226, PI); Pt(n.x, 232, 3, '🏛️ Visiter : parc commémoratif Kwame Nkrumah', () => ctx.visit('nkrumah')); }
  // ---- marché de Makola ----
  { const m = P.makola; box(-280, 0, 70, -150, 7.5, 132, 0xd8c8a0); box(-282, 7.5, 68, -148, 8.2, 134, 0x8a8f96); solid(-280, 70, -150, 132, 8.2); put(label('MAKOLA MARKET', 'Marché de Makola • représentation stylisée', 9, 1.3, '#fcd116', '#1a1a1a'), m.x, 6, 69.4, PI);
    for (let k = 0; k < 9; k++) { const x = -276 + k * 14.5, z = 58; box(x - 2.4, 0, z - 1.1, x + 2.4, 0.85, z + 1.1, 0x8a6440); parts.push(colorize(new THREE.BoxGeometry(5.2, 0.12, 3.4).translate(x, 2.6, z), [0xce1126, 0xfcd116, 0x006b3f, 0x1f4e9c][k % 4])); for (const [a, b] of [[-2.4, -1.5], [2.4, -1.5], [-2.4, 1.5], [2.4, 1.5]]) box(x + a - 0.06, 0, z + b - 0.06, x + a + 0.06, 2.6, z + b + 0.06, 0x5a4228); for (let j = 0; j < 4; j++) box(x - 2 + j * 1.1, 0.85, z - 0.7, x - 1.3 + j * 1.1, 1.2, z + 0.7, [0xce1126, 0xfcd116, 0x2fb04a, 0xe46a1f][(j + k) % 4]); solid(x - 2.4, z - 1.1, x + 2.4, z + 1.1, 1); }
    Pt(m.x, 50.5, 3.5, '🛍️ Marché de Makola : acheter', () => ctx.market('makola')); }
  // ---- Jamestown : phare rayé, pirogues de pêche peintes ----
  { const j = P.jamestown; for (let k = 0; k < 8; k++) parts.push(colorize(new THREE.CylinderGeometry(2.0 - k * 0.12, 2.1 - k * 0.12, 3.6, 12).translate(j.x, 1.8 + k * 3.6, j.z), k % 2 ? 0xffffff : 0xc8102e)); parts.push(colorize(new THREE.CylinderGeometry(1.3, 1.3, 2.2, 10).translate(j.x, 30.1, j.z), 0x2a3a44)); box(j.x - 0.5, 29.2, j.z - 0.5, j.x + 0.5, 31, j.z + 0.5, 0xfff4c0, glow); parts.push(colorize(new THREE.ConeGeometry(1.6, 1.5, 10).translate(j.x, 32, j.z), 0xc8102e)); circle(j.x, j.z, 2.2, 33);
    for (let k = 0; k < 7; k++) { const x = -470 + k * 26, z = coastAt(-470 + k * 26) - 10; const cg = new THREE.BoxGeometry(1.6, 0.9, 11); parts.push(colorize(ry2(cg, x, z, -ang + PI / 2 + 0.2 * (k % 3)).translate(0, 0.45, 0), [0x2a6ad8, 0xe8b020, 0xc8102e, 0x2fb04a][k % 4])); circle(x, z, 1.2, 1); }
    put(label('JAMESTOWN', 'phare et port de pêche • représentation stylisée', 6, 1, '#c8102e', '#ffffff'), j.x + 8, 2.4, j.z - 18, PI); Pt(j.x + 6, j.z - 12, 3.5, '🏛️ Visiter : Jamestown, phare et port de pêche', () => ctx.visit('jamestown')); }
  // ---- Labadi Beach ----
  { const l = P.labadi; for (let k = 0; k < 4; k++) { const x = l.x - 60 + k * 40, z = coastAt(x) - 20; parts.push(colorize(new THREE.ConeGeometry(3.4, 1.4, 8).translate(x, 3.4, z), [0xce1126, 0xfcd116, 0x006b3f, 0x1f4e9c][k])); parts.push(colorize(new THREE.CylinderGeometry(0.08, 0.08, 3, 5).translate(x, 1.5, z), 0x5a4228)); circle(x, z, 0.2, 3); }
    Pt(l.x, coastAt(l.x) - 26, 4, '🌴 Labadi Beach', () => ctx.visit('labadi')); put(label('LABADI BEACH', 'La Pleasure Beach • baignade dangereuse', 5, 0.9, '#1f4e9c', '#ffffff'), l.x + 4, 2.4, coastAt(l.x) - 30, -ang + PI); }
  // ---- hôtel, restaurants (chop bars), centre commercial, stations, école, hôpital, station de tro-tro ----
  { const h = P.hotel; box(400, 0, 78, 465, 21.7, 136, 0xf6f2e8); for (let f = 1; f < 7; f++) box(399, f * 3.1, 136, 466, f * 3.1 + 0.25, 137.2, 0xd8a020); solid(400, 78, 465, 137.3, 22); put(label('HÔTEL GOLDEN COAST', 'hôtel fictif', 8, 1.2, '#1a1a1a', '#fcd116'), h.x + 2, 18, 137.4); Pt(h.x + 2, 140.5, 2.4, '🏨 Hôtel Golden Coast (fictif) : réception', () => ctx.hotel()); }
  for (const [rx, rz, nm] of [[200, -60, 'CHOP BAR MEDAASE'], [345, -163, 'KELEWELE CORNER']]) { box(rx - (nm.length > 15 ? 13 : 8), 0, rz - 8, rx + (nm.length > 15 ? 13 : 8), 3.4, rz + 6, 0xe8b878); box(rx - 14, 3.4, rz - 9, rx + 14, 3.7, rz + 7, 0x8a5a3a); solid(rx - 13, rz - 8, rx + 13, rz + 6, 3.7); put(label(nm, 'établissement fictif', 4.4, 0.8, '#006b3f', '#fcd116'), rx, 2.6, rz + 6.1); Pt(rx, rz + 9, 2.4, `🍲 ${nm.charAt(0) + nm.slice(1).toLowerCase()} (fictif) : manger`, () => ctx.restaurant(nm === 'CHOP BAR MEDAASE' ? 'Chop Bar Medaase' : 'Kelewele Corner')); }
  { const s = P.mall; box(s.x - 52, 0, s.z - 42, s.x + 52, 9, s.z + 32, 0xe8e4dc); box(s.x - 53, 9, s.z - 43, s.x + 53, 9.6, s.z + 33, 0xd8a020); box(s.x - 40, 0.2, s.z + 32, s.x + 40, 7, s.z + 32.2, 0x2a4a5a); solid(s.x - 52, s.z - 42, s.x + 52, s.z + 32, 9.6); put(label('ADINKRA MALL', 'centre commercial fictif', 9, 1.3, '#1a1a1a', '#fcd116'), s.x, 7.6, s.z + 32.6); Pt(s.x, s.z + 35, 3, '🛒 Centre commercial Adinkra (fictif)', () => ctx.market('mall')); }
  for (const [sx, sz] of [[265, -245], [-240, -540]]) { box(sx - 18, 0, sz - 14, sx + 18, 0.05, sz + 14, 0x4a4d52); for (const dx of [-6, 6]) { box(sx + dx - 0.6, 0, sz - 1, sx + dx + 0.6, 1.8, sz + 1, 0xd8dde2); solid(sx + dx - 0.6, sz - 1, sx + dx + 0.6, sz + 1, 1.8); } box(sx - 12, 4.4, sz - 6, sx + 12, 4.8, sz + 6, 0x006b3f); for (const [a, b] of [[-11, -5], [11, -5], [-11, 5], [11, 5]]) { box(sx + a - 0.2, 0, sz + b - 0.2, sx + a + 0.2, 4.4, sz + b + 0.2, 0xd8dde2); circle(sx + a, sz + b, 0.25, 4.4); } box(sx + 10, 0, sz - 13, sx + 17, 3, sz - 6, 0xf4f0e6); solid(sx + 10, sz - 13, sx + 17, sz - 6, 3); put(label('STATION SANKOFA', 'station-service fictive', 5, 0.9, '#006b3f', '#fcd116'), sx, 5.4, sz + 6.2); Pt(sx + 13.5, sz - 4.5, 2.2, '⛽ Station Sankofa (fictive) : boutique', () => ctx.shopStation()); reserve(sx - 19, sz - 15, sx + 19, sz + 15); }
  { const e = P.ecole; box(e.x - 30, 0, e.z - 22, e.x + 30, 3.4, e.z - 8, 0xf0e4c8); box(e.x - 31, 3.4, e.z - 23, e.x + 31, 3.7, e.z - 7, 0x8a5a3a); solid(e.x - 30, e.z - 22, e.x + 30, e.z - 8, 3.7); box(e.x - 30, 0.02, e.z - 8, e.x + 30, 0.05, e.z + 22, 0xc8a070); put(label('PUBLIC PRIMARY SCHOOL', 'école primaire publique • stylisée', 6, 1, '#0b3a6a', '#ffffff'), e.x, 2.6, e.z - 7.9); flag(e.x + 24, e.z + 16, 7); Pt(e.x, e.z - 4, 2.6, '🎒 École primaire publique', () => ctx.visit('ecole')); }
  { const h = P.hopital; box(h.x - 38, 0, h.z - 28, h.x + 38, 9.3, h.z + 26, 0xf4f4f2); box(h.x - 4, 9.3, h.z - 4, h.x + 4, 9.5, h.z + 4, 0xc8102e); solid(h.x - 38, h.z - 28, h.x + 38, h.z + 26, 9.5); put(label('TEACHING HOSPITAL', 'hôpital universitaire • représentation stylisée', 9, 1.2, '#ffffff', '#c8102e'), h.x, 7.2, h.z + 26.2); Pt(h.x, h.z + 29, 3, '🏥 Hôpital universitaire : consultation', () => ctx.hospital()); }
  { const s = P.gare; box(s.x - 40, 0, s.z - 32, s.x + 40, 0.05, s.z + 32, 0x5a5c60); box(s.x - 30, 4, s.z - 28, s.x + 30, 4.4, s.z - 18, 0x9aa0a6); for (const dx of [-28, 0, 28]) { box(s.x + dx - 0.3, 0, s.z - 28, s.x + dx + 0.3, 4, s.z - 27.4, 0x5a5e64); circle(s.x + dx, s.z - 27.7, 0.4, 4); }
    for (let k = 0; k < 5; k++) { const bx = s.x - 30 + k * 13, bz = s.z + 8; box(bx - 1.1, 0.4, bz - 3.2, bx + 1.1, 2.6, bz + 3.2, k % 2 ? 0x2a6ad8 : 0xe8e0d0); box(bx - 1.12, 1.5, bz - 3, bx + 1.12, 2.2, bz + 3, 0x2a3a44); solid(bx - 1.1, bz - 3.2, bx + 1.1, bz + 3.2, 2.6); }
    put(label('STATION DE TRO-TRO ET BUS', 'représentation stylisée', 7, 1.1, '#2a2d33', '#fcd116'), s.x, 5.4, s.z - 17.8); Pt(s.x, s.z - 14, 3, '🚌 Station de tro-tro et bus interurbains', () => ctx.busStation()); }
  // ---- aéroport international Kotoka (stylisé) ----
  { const a = P.aeroport; box(a.x - 70, 0, a.z - 30, a.x + 70, 12, a.z + 8, 0xe8e4dc); box(a.x - 72, 12, a.z - 32, a.x + 72, 13, a.z + 10, 0x0b5a3a); box(a.x - 60, 0.4, a.z + 8, a.x + 60, 7, a.z + 8.2, 0x2a4a5a); solid(a.x - 70, a.z - 30, a.x + 70, a.z + 8, 13);
    put(label('KOTOKA INTERNATIONAL AIRPORT', 'Accra • représentation stylisée', 14, 1.6, '#0b5a3a', '#fcd116'), a.x, 9.5, a.z + 8.4); for (const dx of [-36, 36]) flag(a.x + dx, a.z + 24);
    parts.push(colorize(new THREE.BoxGeometry(30, 0.06, 620).rotateY(-0.52).translate(900, 0.06, -1130), 0x3a3c40)); box(a.x - 70, 0.03, a.z - 130, a.x + 180, 0.05, a.z - 30, 0x5a5c60);
    for (const [px, pz] of [[a.x - 20, a.z - 80], [a.x + 80, a.z - 82]]) { box(px - 1.6, 1.2, pz - 16, px + 1.6, 4.2, pz + 16, 0xf4f4f2); box(px - 15, 2.2, pz - 2, px + 15, 2.6, pz + 3, 0xd8dde2); box(px - 0.2, 4.2, pz - 16, px + 0.2, 8, pz - 12, 0xce1126); solid(px - 1.8, pz - 16, px + 1.8, pz + 16, 4.5); }
    Pt(a.x, a.z + 12, 3.5, '✈️ Aérogare Kotoka : vols, jet privé, change', () => ctx.airport()); }
  // ---- sortie est (route N1 vers Tema et Aflao / Togo), carrefour de Kwame Nkrumah Circle, panneaux, taxis ----
  roadSign('← Tema • Aflao (Togo) — N1', 1170, -133.5, 0); Pt(1225, -120, 4, '🛣️ Route N1 vers Tema, Aflao et le Togo', () => ctx.border('togo'));
  roadSign('← Takoradi • Elubo (Côte d’Ivoire) — N1', -755, -133.5, 0); Pt(-778, -120, 4, '🛣️ Route N1 vers Takoradi, la frontière d’Elubo–Noé et la Côte d’Ivoire', () => ctx.border('ivoire'));
  { box(-305, 0.05, -325, -295, 0.4, -315, 0x7a9a4e); solid(-305, -325, -295, -315, 0.4); flag(-300, -320, 10); } // rond-point (Kwame Nkrumah Circle, stylisé)
  roadSign('High Street', -120, 136, 0); roadSign('Independence Avenue', 103, 100, PI / 2); roadSign('Ring Road', RING.cx + 10, RING.cz - RING.r + 13, 0); roadSign('Kotoka Airport ↑', 103, -300, PI / 2); roadSign('Oxford Street', 313, -100, PI / 2);
  for (const [x, z, n] of TAXIS) { put(label('TAXI', '', 1.2, 0.5, '#e8a020', '#1a1a1a'), x, 2.4, z, 0); parts.push(colorize(new THREE.CylinderGeometry(0.05, 0.05, 2.2, 5).translate(x, 1.1, z), 0x5a5e64)); circle(x, z, 0.1, 2.2); Pt(x, z + 1.4, 2.2, `🚕 Station de taxis (${n})`, () => ctx.taxi()); }
  // ---- maillages ----
  const mkm = (arr, mat) => { if (!arr.length) return null; const ms = new THREE.Mesh(mergeGeometries(arr), mat); ms.receiveShadow = true; ms.castShadow = true; g.add(ms); return ms; };
  mkm(parts, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.85 })); if (glow.length) g.add(new THREE.Mesh(mergeGeometries(glow), new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false })));
  if (heads.length) { for (const h of heads) for (const k of Object.keys(h.attributes)) if (!['position', 'normal'].includes(k)) h.deleteAttribute(k); g.add(new THREE.Mesh(mergeGeometries(heads), ctx.lampMat)); const pool = new THREE.InstancedMesh(new THREE.PlaneGeometry(13, 13).rotateX(-PI / 2), ctx.poolMat, lamps.length), dm = new THREE.Object3D(); lamps.forEach(([x, z], i) => { dm.position.set(x, 0.07, z); dm.updateMatrix(); pool.setMatrixAt(i, dm.matrix); }); pool.renderOrder = 2; g.add(pool); }
  for (const [t, arr] of Object.entries(signs)) { const c = document.createElement('canvas'); c.width = 512; c.height = 64; const x = c.getContext('2d'); x.fillStyle = ['#fcd116', '#f6f2e6', '#ce1126'][t.length % 3]; x.fillRect(0, 0, 512, 64); x.fillStyle = t.length % 3 === 2 ? '#ffffff' : '#1a1a1a'; x.font = '900 34px Arial'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(t, 256, 34, 500); const tx = new THREE.CanvasTexture(c); tx.colorSpace = THREE.SRGBColorSpace; g.add(new THREE.Mesh(mergeGeometries(arr), new THREE.MeshBasicMaterial({ map: tx }))); }
  // ---- trottoirs des piétons ----
  const free = (x, z) => ![[0, 0], [0.4, 0], [-0.4, 0], [0, 0.4], [0, -0.4]].some(([a, b]) => C.pointBlocked(O.x + x + a, 0.5, O.z + z + b)) && !inLag(x, z) && z < coastAt(x) - 2;
  const runs = (ax, az, bx, bz) => { const L2 = Math.hypot(bx - ax, bz - az), n = Math.max(1, Math.floor(L2 / 2)), out = []; let st = null; for (let i = 0; i <= n; i++) { const t = i / n, x = ax + (bx - ax) * t, z = az + (bz - az) * t; if (free(x, z)) { if (!st) st = [x, z]; } else if (st) { if (Math.hypot(x - st[0], z - st[1]) > 30) out.push([st, [ax + (bx - ax) * ((i - 1) / n), az + (bz - az) * ((i - 1) / n)]]); st = null; } } if (st && Math.hypot(bx - st[0], bz - st[1]) > 30) out.push([st, [bx, bz]]); return out; };
  for (const [x0, z0, x1, , w] of EWc) for (const s of [-1, 1]) lanes.push(...runs(x0 + 5, z0 + s * (w / 2 + 2), x1 - 5, z0 + s * (w / 2 + 2)));
  for (const [x0, z0, , z1, w] of NS) for (const s of [-1, 1]) lanes.push(...runs(x0 + s * (w / 2 + 2), z0 + 10, x0 + s * (w / 2 + 2), z1 - 4));
  // ---- carte du secteur ----
  const S = 0.5, W = ACCRA.X1 - ACCRA.X0 + 80, H = 1950, cv = document.createElement('canvas'); cv.width = Math.round(W * S); cv.height = Math.round(H * S); const x = cv.getContext('2d'), T = (lx, lz) => [(lx - ACCRA.X0 + 40) * S, (lz - ACCRA.Z0 + 40) * S];
  x.fillStyle = '#a89a6a'; x.fillRect(0, 0, cv.width, cv.height);
  x.fillStyle = '#2a7a92'; x.beginPath(); x.moveTo(...T(ACCRA.X0 - 40, coastAt(ACCRA.X0 - 40))); x.lineTo(...T(ACCRA.X1 + 40, coastAt(ACCRA.X1 + 40))); x.lineTo(cv.width, cv.height); x.lineTo(0, cv.height); x.closePath(); x.fill();
  x.strokeStyle = '#e8d6a8'; x.lineWidth = 30 * S; x.beginPath(); x.moveTo(...T(ACCRA.X0 - 40, coastAt(ACCRA.X0 - 40) - 15)); x.lineTo(...T(ACCRA.X1 + 40, coastAt(ACCRA.X1 + 40) - 15)); x.stroke();
  { const [a, b] = T(ACCRA.LAG.x0, ACCRA.LAG.z0), [c2, d] = T(ACCRA.LAG.x1, ACCRA.LAG.z1); x.fillStyle = '#3a7a6a'; x.fillRect(a, b, c2 - a, d - b); }
  x.fillStyle = '#d8ccb0'; for (const r of reserved) { const [a, b] = T(r.x0, r.z0), [c2, d] = T(r.x1, r.z1); x.fillRect(a, b, c2 - a, d - b); }
  x.strokeStyle = '#4d4f55'; x.lineCap = 'round'; for (const [x0, z0, x1, z1, w] of [...EWc, ...NS]) { x.lineWidth = w * S * 1.3; x.beginPath(); x.moveTo(...T(x0, z0)); x.lineTo(...T(x1, z1)); x.stroke(); }
  x.lineWidth = 12 * S * 1.3; x.beginPath(); ringPts.forEach((p, i) => (i ? x.lineTo(...T(p[0], p[1])) : x.moveTo(...T(p[0], p[1])))); x.stroke();
  x.beginPath(); x.moveTo(...T(120, coastAt(120) - 42)); x.lineTo(...T(1240, coastAt(1240) - 42)); x.stroke();
  x.save(); x.translate(...T(900, -1130)); x.rotate(0.52); x.fillStyle = '#3a3c40'; x.fillRect(-15 * S, -310 * S, 30 * S, 620 * S); x.restore();
  return { group: g, cols, points, lanes, map: { canvas: cv, X0: O.x + ACCRA.X0 - 40, Z0: O.z + ACCRA.Z0 - 40, W, H, S, has: ACCRA.has } };
}
export const ACCRA_PLACES = P;
export const ACCRA_QUARTIERS = QUARTIERS;
export const ACCRA_NAMES = NAMES;
export const ACCRA_TAXIS = TAXIS;
