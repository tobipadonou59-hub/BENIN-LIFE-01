// Mission 014, étape 2 — gestion de NOVA BOOK : compte de l'entreprise (séparé du compte personnel), employés,
// recrutement, formation, promotion, licenciement, paie de fin de mois (validation par le PDG ou automatique),
// commandes et contrats, équipements, comptabilité, alertes financières. 1 mois de jeu = 7 jours de jeu.
import { JOBS, FLOORS } from './nova-data.js';
import { fcfa } from './food-data.js';

export const MONTH_DAYS = 7;
const START_CASH = 3000000, FIXED = 400000; // charges fixes mensuelles : électricité, internet, entretien
const FIRST = ['Koffi', 'Afi', 'Sènan', 'Rodrigue', 'Bénédicte', 'Ismaël', 'Prisca', 'Gédéon', 'Nafissatou', 'Hervé', 'Mariette', 'Fortuné', 'Carine', 'Basile', 'Zénabou', 'Achille', 'Florence', 'Léandre', 'Ramatou', 'Cokou'];
const LAST = ['Agossou', 'Houngbédji', 'Dossou', 'Kpadonou', 'Akakpo', 'Gbènou', 'Tossou', 'Sagbo', 'Amoussou', 'Hounkanrin', 'Zannou', 'Ahouansou', 'Djossou', 'Kiki', 'Fagla', 'Togbé'];
const JOB_FLOOR = { graphiste: 1, maquettiste: 2, correcteur: 2, developpeur: 3, monteur: 3, imprimeur: 4, commercial: 0, comptable: 5, secretaire: 5, entretien: 5, rh: 5, directeur: 1 };
export const DEPTS = ['Graphisme', 'Édition', 'Informatique', 'Audiovisuel', 'Impression', 'Commercial', 'Administration', 'Services généraux', 'Direction'];
const PROD_DEPTS = ['Graphisme', 'Édition', 'Informatique', 'Audiovisuel', 'Impression'];
// prestations : département, prix de base (FCFA), charge de travail (points), délai (jours de jeu)
export const SERVICES = [
  { id: 'roman', label: 'Création et mise en page d’un roman', dept: 'Édition', price: 900000, work: 70, days: 3 },
  { id: 'manuel', label: 'Conception d’un manuel scolaire', dept: 'Édition', price: 1400000, work: 110, days: 4 },
  { id: 'educatif', label: 'Livre éducatif illustré', dept: 'Graphisme', price: 1100000, work: 85, days: 3 },
  { id: 'miseenpage', label: 'Mise en page de documents professionnels', dept: 'Édition', price: 350000, work: 25, days: 1 },
  { id: 'couverture', label: 'Conception de couvertures', dept: 'Graphisme', price: 300000, work: 20, days: 1 },
  { id: 'impression', label: 'Impression de livres (tirage)', dept: 'Impression', price: 1600000, work: 120, days: 3 },
  { id: 'brochure', label: 'Impression de brochures', dept: 'Impression', price: 500000, work: 40, days: 2 },
  { id: 'affiche', label: 'Création d’affiches', dept: 'Graphisme', price: 250000, work: 18, days: 1 },
  { id: 'pub', label: 'Supports publicitaires', dept: 'Graphisme', price: 600000, work: 45, days: 2 },
  { id: 'video', label: 'Montage d’une vidéo promotionnelle', dept: 'Audiovisuel', price: 800000, work: 60, days: 2 },
  { id: 'site', label: 'Site de commande en ligne', dept: 'Informatique', price: 1200000, work: 90, days: 4 },
];
export const CLIENTS = ['Éditions du Golfe (fictif)', 'Collège Lumière (fictif)', 'Association Lire à Cotonou (fictive)', 'Boulangerie du Matin (fictive)', 'Hôtel Océan Bleu (fictif)', 'Mairie de quartier (fictive)', 'École primaire Les Palmiers (fictive)', 'Festival Arts du Bénin (fictif)', 'Pharmacie de la Lagune (fictive)', 'Auteur indépendant (fictif)', 'Agence Voyages Ouidah (fictive)', 'ONG Avenir Jeunes (fictive)'];
const rnd = (a, b) => a + Math.random() * (b - a);
const pick = (a) => a[Math.floor(Math.random() * a.length)];
const r5 = (n) => Math.round(n / 5000) * 5000;

export class Company {
  constructor({ nova, economy, env, ui, audio, onSave }) {
    Object.assign(this, { nova, economy, env, ui, audio, onSave });
    this.cash = START_CASH; this.day = 1; this.month = 1; this.autoPay = false; this.uid = 1;
    this.ledger = [{ d: this.stamp(), label: 'Capital de départ', amount: START_CASH, cat: 'capital' }];
    this.months = []; this.payDue = null; this.unpaidDays = 0;
    this.equip = Object.fromEntries(PROD_DEPTS.map((d) => [d, 1]));
    this.staff = nova.staff.map((s) => this.makeEmployee(s.name, s.job, s.lv, s.seat));
    this.syncNova();
    this.candidates = []; this.refreshCandidates();
    this.offers = []; this.orders = []; this.done = []; this.refreshOffers();
    this.lastT = null;
  }
  stamp() { return `M${this.month || 1} J${((this.day - 1) % MONTH_DAYS) + 1}`; }
  makeEmployee(name, job, lv = JOB_FLOOR[job], seat = null, skill = rnd(45, 80), exp = Math.floor(rnd(1, 12))) {
    const J = JOBS[job];
    return { id: this.uid++, name, job, lv, seat, dept: J.dept, salary: r5(J.salary * (0.9 + skill / 400 + exp / 80)), skill: Math.round(skill), exp, grade: 1, morale: 75, status: 'présent', trainLeft: 0 };
  }
  prod(e) { return e.status === 'présent' ? (e.skill / 100) * (0.7 + e.morale / 330) * (1 + (e.grade - 1) * 0.12) * (e.boost && e.boost.until >= this.day ? e.boost.k : 1) : 0; }
  // les employés visibles dans l'immeuble suivent l'effectif réel
  syncNova() {
    const used = {};
    for (const e of this.staff) { const k = `${e.lv}`; used[k] = used[k] || new Set(); if (e.seat !== null && e.seat !== undefined) used[k].add(String(e.seat)); }
    for (const e of this.staff) if (e.seat === null || e.seat === undefined) { const cap = this.nova.seatCount ? this.nova.seatCount(e.lv) : 0; for (let i = 0; i < cap; i++) if (!used[e.lv].has(String(i))) { e.seat = i; used[e.lv].add(String(i)); break; } }
    this.nova.staff = this.staff.filter((e) => e.seat !== null && e.seat !== undefined).map((e) => ({ name: e.name, job: e.job, lv: e.lv, seat: e.seat }));
    this.nova.refreshPeople && this.nova.refreshPeople();
  }
  massSalary() { return this.staff.reduce((a, e) => a + e.salary, 0); }
  post(label, amount, cat) { this.cash += amount; this.ledger.unshift({ d: this.stamp(), label, amount, cat }); this.ledger.length = Math.min(this.ledger.length, 200); this.cur()[cat] = (this.cur()[cat] || 0) + amount; }
  cur() { if (!this.curM || this.curM.m !== this.month) this.curM = { m: this.month, ca: 0, salaires: 0, invest: 0, frais: 0, capital: 0, virement: 0 }; return this.curM; }

  // ---- recrutement ----
  refreshCandidates() {
    const jobs = Object.keys(JOBS).filter((j) => !JOBS[j].other); // métiers de l'édition seulement
    this.candidates = Array.from({ length: 6 }, () => { const job = pick(jobs), e = this.makeEmployee(`${pick(FIRST)} ${pick(LAST)}`, job); e.id = 0; e.cid = Math.random().toString(36).slice(2, 8); return e; });
  }
  hire(cid) {
    const c = this.candidates.find((q) => q.cid === cid); if (!c) return;
    const e = { ...c, id: this.uid++ }; delete e.cid; e.seat = null;
    this.staff.push(e); this.candidates = this.candidates.filter((q) => q !== c);
    this.syncNova(); this.note(`🤝 ${e.name} rejoint NOVA BOOK (${JOBS[e.job].label}, ${fcfa(e.salary)}/mois)`); this.onSave && this.onSave();
  }
  fire(id) {
    const e = this.staff.find((q) => q.id === id); if (!e) return;
    this.post(`Indemnité de départ — ${e.name}`, -e.salary, 'salaires');
    this.staff = this.staff.filter((q) => q !== e); this.syncNova(); this.note(`Licenciement de ${e.name} (indemnité ${fcfa(e.salary)})`); this.onSave && this.onSave();
  }
  train(id) {
    const e = this.staff.find((q) => q.id === id); if (!e || e.status !== 'présent') return;
    const cost = 150000; if (this.cash < cost) return this.note('❌ Trésorerie insuffisante pour la formation');
    this.post(`Formation — ${e.name}`, -cost, 'frais'); e.status = 'formation'; e.trainLeft = 1; this.note(`🎓 ${e.name} part en formation (1 jour)`); this.onSave && this.onSave();
  }
  promote(id) {
    const e = this.staff.find((q) => q.id === id); if (!e || e.grade >= 3) return;
    e.grade++; e.salary = r5(e.salary * 1.15); e.morale = Math.min(100, e.morale + 15); this.note(`⬆️ ${e.name} est promu(e) (échelon ${e.grade}, ${fcfa(e.salary)}/mois)`); this.onSave && this.onSave();
  }

  // ---- commandes ----
  refreshOffers() {
    while (this.offers.length < 5) {
      const s = pick(SERVICES), k = rnd(0.8, 1.35);
      this.offers.push({ oid: Math.random().toString(36).slice(2, 8), sid: s.id, label: s.label, dept: s.dept, client: pick(CLIENTS), price: r5(s.price * k * (this.life ? this.life.priceK() : 1)), work: Math.round(s.work * k), days: s.days + (k > 1.2 ? 1 : 0) });
    }
  }
  capacity(dept) { const n = this.staff.filter((e) => e.dept === dept).length; return n ? 1 + Math.floor(n / 3) : 0; }
  accept(oid) {
    const o = this.offers.find((q) => q.oid === oid); if (!o) return;
    const busy = this.orders.filter((q) => q.dept === o.dept).length;
    if (busy >= this.capacity(o.dept)) return this.note(`❌ Le département ${o.dept} est complet (${busy}/${this.capacity(o.dept)}). Recrute ou attends la fin d'une commande.`);
    this.offers = this.offers.filter((q) => q !== o);
    this.orders.push({ ...o, done: 0, left: o.days, status: 'en cours' });
    this.note(`📄 Contrat signé : ${o.label} pour ${o.client} — ${fcfa(o.price)}`); this.refreshOffers(); this.onSave && this.onSave();
  }
  decline(oid) { this.offers = this.offers.filter((q) => q.oid !== oid); this.refreshOffers(); }
  deptRate(dept) { // points de travail par heure de jeu
    const staff = this.staff.filter((e) => e.dept === dept), busy = Math.max(1, this.orders.filter((q) => q.dept === dept).length);
    return (staff.reduce((a, e) => a + this.prod(e), 0) * (1 + (this.equip[dept] - 1) * 0.25) * 1.35 * (this.life ? this.life.factor(dept) : 1)) / busy;
  }

  // ---- investissements ----
  equipCost(d) { return [0, 1500000, 3000000][this.equip[d]] || 0; }
  upgrade(d) {
    if (this.equip[d] >= 3) return; const c = this.equipCost(d);
    if (this.cash < c) return this.note('❌ Trésorerie insuffisante pour cet investissement');
    this.post(`Équipement ${d} niveau ${this.equip[d] + 1}`, -c, 'invest'); this.equip[d]++; this.note(`🛠️ ${d} : équipement niveau ${this.equip[d]} (+25 % de production)`); this.onSave && this.onSave();
  }
  transfer(amount, toCompany) {
    amount = Math.floor(amount); if (amount <= 0) return;
    if (toCompany) { if (!this.economy.pay(amount, 'Virement vers NOVA BOOK', 'Banque')) return; this.post('Apport du PDG (virement personnel)', amount, 'virement'); }
    else { if (this.cash < amount) return this.note('❌ Trésorerie de l’entreprise insuffisante'); this.post('Dividende versé au PDG', -amount, 'virement'); this.economy.earn(amount, 'Dividende NOVA BOOK', 'Banque'); }
    this.onSave && this.onSave();
  }

  // ---- paie ----
  payroll() {
    if (!this.payDue) return;
    const total = this.payDue.total;
    if (this.cash < total) { this.note(`⚠️ Trésorerie insuffisante : ${fcfa(this.cash)} pour ${fcfa(total)} de salaires`); return false; }
    this.post(`Salaires du mois ${this.payDue.month} (${this.payDue.lines.length} employés)`, -total, 'salaires');
    for (const e of this.staff) e.morale = Math.min(100, e.morale + 4);
    this.payDue = null; this.unpaidDays = 0; this.note(`✅ Salaires payés : ${fcfa(total)}`); this.onSave && this.onSave(); return true;
  }
  monthEnd() {
    const lines = this.staff.map((e) => ({ name: e.name, job: JOBS[e.job].label, salary: e.salary }));
    const sal = lines.reduce((a, l) => a + l.salary, 0);
    this.post('Charges fixes (électricité, internet, entretien)', -FIXED, 'frais');
    const m = this.cur(); this.months.unshift({ ...m, net: m.ca + m.salaires + m.invest + m.frais, cash: this.cash }); this.months.length = Math.min(this.months.length, 12);
    if (this.payDue) this.note('⚠️ Les salaires du mois précédent ne sont toujours pas payés !');
    this.payDue = { month: this.month, lines, total: sal + (this.payDue ? this.payDue.total : 0) };
    this.month++;
    this.note(`📅 Fin du mois ${this.month - 1} : salaires à payer ${fcfa(this.payDue.total)} (ordinateur du PDG, rubrique Salaires)`);
    if (this.cash < this.payDue.total) this.note('🚨 Alerte financière : la trésorerie ne couvre pas la paie. Décisions : apport personnel, recouvrement de commandes, réduction des effectifs.');
    if (this.autoPay) this.payroll();
    this.refreshCandidates();
    if (this.group) this.group.monthEnd();
  }
  note(msg) { this.economy.notify(msg); if (this.ui && this.ui.render && this.open) this.ui.render(); }

  // ---- temps qui passe (heures de jeu) ----
  update() {
    const h = this.env.time;
    if (this.lastT === null) { this.lastT = h; return; }
    let dh = h - this.lastT; if (dh < -12) dh += 24; if (dh < 0 || dh > 12) { this.lastT = h; return; }
    if (h < this.lastT) { this.newDay(); }
    this.lastT = h;
    if (dh <= 0) return;
    const work = h >= 7 && h < 19; // les équipes travaillent de 7 h à 19 h
    for (const o of this.orders) {
      if (work) o.done = Math.min(o.work, o.done + this.deptRate(o.dept) * dh);
      if (o.done >= o.work) this.deliver(o);
    }
    this.orders = this.orders.filter((o) => o.status === 'en cours');
  }
  newDay() {
    this.day++;
    for (const o of this.orders) o.left--;
    for (const e of this.staff) { if (e.status === 'formation' && --e.trainLeft <= 0) { e.status = 'présent'; e.skill = Math.min(100, e.skill + 10); this.note(`🎓 ${e.name} a terminé sa formation (compétence ${e.skill})`); } }
    if (this.payDue) { this.unpaidDays++; for (const e of this.staff) e.morale = Math.max(10, e.morale - 6); }
    if (Math.random() < 0.5) { this.offers.shift(); this.refreshOffers(); }
    if (this.group) this.group.newDay();
    if (this.talk) this.talk.newDay(); // fin des jours de repos accordés en conversation (mission 017)
    if (this.life) this.life.newDay(); // événements, visites (mission 014, étape 5)
    if ((this.day - 1) % MONTH_DAYS === 0) this.monthEnd();
    this.onSave && this.onSave();
  }
  deliver(o) {
    o.status = 'livrée';
    const late = o.left < 0, pay = late ? r5(o.price * 0.7) : o.price;
    this.post(`Facture ${o.client} — ${o.label}${late ? ' (retard −30 %)' : ''}`, pay, 'ca');
    this.done.unshift({ ...o, paid: pay, d: this.stamp(), late }); this.done.length = Math.min(this.done.length, 40);
    for (const e of this.staff.filter((q) => q.dept === o.dept)) e.exp += 0.05;
    this.note(`📦 Commande livrée : ${o.label} → ${fcfa(pay)} encaissés${late ? ' (livrée en retard)' : ''}`);
    if (this.audio && this.audio.ctx) { this.audio.tone(880, 0.1, 0.05, 'triangle'); this.audio.tone(1320, 0.14, 0.05, 'triangle', this.audio.sfx, 0.1); }
  }

  serialize() { return { cash: this.cash, day: this.day, month: this.month, autoPay: this.autoPay, uid: this.uid, ledger: this.ledger.slice(0, 120), months: this.months, payDue: this.payDue, equip: this.equip, staff: this.staff, candidates: this.candidates, offers: this.offers, orders: this.orders, done: this.done.slice(0, 30), curM: this.curM, unpaidDays: this.unpaidDays, group: this.group ? this.group.serialize() : this.savedGroup }; }
  restore(s) {
    if (!s) return;
    this.savedGroup = s.group || null; if (this.group && s.group) this.group.restore(s.group);
    Object.assign(this, { cash: s.cash ?? this.cash, day: s.day || 1, month: s.month || 1, autoPay: !!s.autoPay, uid: s.uid || this.uid, ledger: s.ledger || this.ledger, months: s.months || [], payDue: s.payDue || null, equip: { ...this.equip, ...(s.equip || {}) }, candidates: s.candidates || this.candidates, offers: s.offers || this.offers, orders: s.orders || [], done: s.done || [], curM: s.curM || null, unpaidDays: s.unpaidDays || 0 });
    if (Array.isArray(s.staff) && s.staff.length) { this.staff = s.staff; this.syncNova(); }
  }
}
export { FLOORS };
