// Caméra à la troisième personne avec orbite souris et anti-collision murs.
import * as THREE from 'three';
import { clamp, damp, dampAngle } from './util.js';

export class ThirdPersonCamera {
  constructor(camera, settings) {
    this.cam = camera;
    this.settings = settings;
    this.yaw = Math.PI; this.pitch = 0.32;
    this.dist = 5.5; this.wantDist = 5.5; this.curDist = 5.5;
    this.lastMouse = -99; this.time = 0;
    this.target = new THREE.Vector3();
    this._p = new THREE.Vector3();
  }

  handleInput(input) {
    const s = 0.0025 * this.settings.sensitivity;
    if (input.mouseDX || input.mouseDY) {
      this.yaw -= input.mouseDX * s;
      this.pitch += input.mouseDY * s * (this.settings.invertY ? -1 : 1);
      this.pitch = clamp(this.pitch, -0.25, 1.25);
      this.lastMouse = this.time;
    }
    if (input.wheel) this.wantDist = clamp(this.wantDist + input.wheel * 0.8, 2.5, 14);
  }

  // recadrage immédiat (téléportation : entrée ou sortie d'un intérieur)
  snap(focus) { this.target.set(focus.x, focus.y, focus.z); this.curDist = Math.min(this.curDist, this.indoorMax || 3.8); }
  update(dt, focus, world, follow) {
    this.time += dt;
    this.target.x = damp(this.target.x, focus.x, 14, dt);
    this.target.y = damp(this.target.y, focus.y, 10, dt);
    this.target.z = damp(this.target.z, focus.z, 14, dt);
    if (follow && this.time - this.lastMouse > 1.5 && Math.abs(follow.speed) > 1.5) {
      // derrière le véhicule (ou devant en marche arrière)
      const want = follow.speed > 0 ? follow.heading + Math.PI : follow.heading;
      this.yaw = dampAngle(this.yaw, want, 2.5, dt);
      this.pitch = damp(this.pitch, 0.22, 1.5, dt);
    }
    let base = follow ? Math.max(this.wantDist, follow.dist || 7.5) : this.wantDist;
    // à l'intérieur : caméra rapprochée et plongeante (toit masqué, vue « maison de poupée »)
    if (this.indoor && !follow) { const mx = this.indoorMax || 3.8, mp = this.indoorPitch || 1.1; base = Math.min(base, mx); if (this.pitch < mp) this.pitch += (mp - this.pitch) * Math.min(1, dt * 4); }
    const cp = Math.cos(this.pitch);
    const dx = Math.sin(this.yaw) * cp, dy = Math.sin(this.pitch), dz = Math.cos(this.yaw) * cp;
    // recherche de la distance libre
    let allowed = base;
    for (let i = 1; i <= 14; i++) {
      const t = (i / 14) * base;
      const x = this.target.x + dx * t, y = this.target.y + dy * t, z = this.target.z + dz * t;
      if (world.collision.pointBlocked(x, y, z)) { allowed = Math.max(0.8, t - 0.6); break; }
    }
    this.curDist = allowed < this.curDist ? damp(this.curDist, allowed, 25, dt) : damp(this.curDist, allowed, 3, dt);
    const p = this._p.set(this.target.x + dx * this.curDist, Math.max(0.35, this.target.y + dy * this.curDist), this.target.z + dz * this.curDist);
    this.cam.position.copy(p);
    this.cam.lookAt(this.target);
  }
}
