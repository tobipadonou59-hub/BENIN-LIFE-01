// Mission 016, phase 1 — NOVA BOOK : toilettes Hommes / Femmes à chaque étage et réfrigérateur du bureau du PDG.
// Géométrie procédurale fusionnée par étage (aucune lumière dynamique ajoutée), collisions filtrées par niveau.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { NB, colored, canvasTex } from './nova.js';
import { FOOD_BY_ID, fcfa } from './food-data.js';

const PI = Math.PI;
const W = { x0: 69, x1: 76, z0: 33.4, z1: 40, mid: 36.7 };          // bloc sanitaire (angle nord-est de chaque plateau)
const ROOMS = [
  { id: 'H', label: 'HOMMES', door: [34.3, 35.4], sinkZ: 33.75, wallZ: 33.52, stallZ: [35.2, 36.7], frontZ: 35.2, useZ: 34.75 },
  { id: 'F', label: 'FEMMES', door: [37.9, 39.0], sinkZ: 39.65, wallZ: 39.88, stallZ: [36.7, 38.2], frontZ: 38.2, useZ: 38.65 },
];
const STALLS = [[72.9, 74.45], [74.45, 76]];
// réfrigérateur du bureau du PDG (5e étage)
const FR = { x: 75.05, z: 31.9, lv: 5 };
export const CEO_FRIDGE_ITEMS = { eau: 6, jus_ananas: 3, jus_mangue: 3, bissap: 3, gingembre: 3, baobab: 2, eau_coco: 3, citronnade: 3, soda: 3, yaourt: 3, biscuits: 3, chocolat: 2, noix_cajou: 3, chips_plantain: 3, kuli_kuli: 2, atchomon: 2 };
const FR_CAP = 60;

function picto(x, w, h, kind) { // pictogramme homme / femme dessiné au canevas
  x.fillStyle = '#fff'; const cx = w * 0.22, top = h * 0.16, s = h * 0.7;
  x.beginPath(); x.arc(cx, top + s * 0.1, s * 0.1, 0, PI * 2); x.fill();
  if (kind === 'F') { x.beginPath(); x.moveTo(cx, top + s * 0.24); x.lineTo(cx - s * 0.2, top + s * 0.7); x.lineTo(cx + s * 0.2, top + s * 0.7); x.closePath(); x.fill(); x.fillRect(cx - s * 0.1, top + s * 0.7, s * 0.07, s * 0.28); x.fillRect(cx + s * 0.03, top + s * 0.7, s * 0.07, s * 0.28); }
  else { x.fillRect(cx - s * 0.13, top + s * 0.24, s * 0.26, s * 0.42); x.fillRect(cx - s * 0.12, top + s * 0.66, s * 0.1, s * 0.32); x.fillRect(cx + s * 0.02, top + s * 0.66, s * 0.1, s * 0.32); }
}
const plaqueTex = (kind, label) => canvasTex(384, 160, (x, w, h) => { x.fillStyle = kind === 'F' ? '#a0306a' : '#1f4e9c'; x.fillRect(0, 0, w, h); picto(x, w, h, kind); x.fillStyle = '#fff'; x.font = 'bold 50px Arial'; x.textAlign = 'center'; x.fillText(label, w * 0.62, h * 0.48); x.font = '24px Arial'; x.fillText('TOILETTES', w * 0.62, h * 0.8); });

export class NovaPlus {
  constructor(ctx) {
    Object.assign(this, ctx); // nova, world, ui, audio, needs, player, economy, company, onSave
    this.mats = {
      std: new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.6 }),
      shiny: new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.12, metalness: 0.5 }),
      lamp: new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false }),
      fglass: new THREE.MeshStandardMaterial({ color: 0xbfe0f0, roughness: 0.05, metalness: 0.1, transparent: true, opacity: 0.3, depthWrite: false }),
    };
    this.doors = []; this.stalls = []; this.act = null; this.needWash = false; this.open = false;
    this.fridge = { ...CEO_FRIDGE_ITEMS }; this.view = 'list'; this.sel = 'eau'; this.paying = false; this.lastPay = null;
    for (let lv = 0; lv < NB.levels; lv++) this.buildToilets(lv);
    this.buildFridge();
    this.buildDom();
  }

  // ------------------------------------------------------------------ toilettes
  buildToilets(lv) {
    const fl = this.nova.floors[lv], fg = fl.group, y0 = lv * NB.fh, col = this.world.collision, H = NB.fh;
    const P = { std: [], shiny: [], lamp: [] };
    const box = (w, h, d, x, y, z, c, k = 'std') => P[k].push(colored(new THREE.BoxGeometry(w, h, d).translate(x, y0 + y, z), c));
    const solid = (x0, z0, x1, z1, h = 50) => { const o = col.addBox(x0, z0, x1, z1, y0 + h); o.lv = lv; return o; };
    const pts = (label, x, z, action, r = 1.0) => this.nova.points.push({ lv, x, z, r, label, action });
    const WALL = 0xe6ecee;
    // sol carrelé, murs (nord, ouest avec deux portes, cloison centrale)
    box(W.x1 - W.x0, 0.02, W.z1 - W.z0, (W.x0 + W.x1) / 2, 0.13, (W.z0 + W.z1) / 2, 0xd8dde0);
    for (let i = 0; i < 7; i++) box(0.01, 0.005, W.z1 - W.z0, W.x0 + 0.5 + i, 0.142, (W.z0 + W.z1) / 2, 0xb8c0c4); // joints
    box(W.x1 - W.x0, H, 0.2, (W.x0 + W.x1) / 2, H / 2, W.z0, WALL); solid(W.x0, W.z0 - 0.1, W.x1, W.z0 + 0.1);
    box(W.x1 - W.x0, H, 0.16, (W.x0 + W.x1) / 2, H / 2, W.mid, WALL); solid(W.x0, W.mid - 0.08, W.x1, W.mid + 0.08);
    const segs = [[W.z0, ROOMS[0].door[0]], [ROOMS[0].door[1], ROOMS[1].door[0]], [ROOMS[1].door[1], W.z1]];
    for (const [a, b] of segs) { box(0.2, H, b - a, W.x0, H / 2, (a + b) / 2, WALL); solid(W.x0 - 0.1, a, W.x0 + 0.1, b); }
    for (const R of ROOMS) { const [a, b] = R.door; box(0.2, H - 2.3, b - a, W.x0, 2.3 + (H - 2.3) / 2, (a + b) / 2, WALL); box(0.24, 0.06, b - a + 0.1, W.x0, 2.3, (a + b) / 2, 0x6a4a32); }
    // murs opaques côté façade vitrée (intimité)
    box(W.x1 - W.x0, H - 0.1, 0.06, (W.x0 + W.x1) / 2, H / 2, W.z1 - 0.05, WALL); box(0.06, H - 0.1, W.z1 - W.z0, W.x1 - 0.05, H / 2, (W.z0 + W.z1) / 2, WALL);
    // faïence murale à hauteur d'appui
    box(W.x1 - W.x0 - 0.2, 1.2, 0.02, (W.x0 + W.x1) / 2, 0.75, W.z0 + 0.11, 0xcfe0e8); box(W.x1 - W.x0 - 0.2, 1.2, 0.02, (W.x0 + W.x1) / 2, 0.75, W.z1 - 0.09, 0xe8d0dc);
    // panneau de direction dans le couloir
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 0.5), new THREE.MeshBasicMaterial({ map: canvasTex(512, 106, (x, w, h) => { x.fillStyle = '#0b1220'; x.fillRect(0, 0, w, h); x.fillStyle = '#fff'; x.font = 'bold 44px Arial'; x.textAlign = 'center'; x.fillText('TOILETTES  H • F  →', w / 2, 70); }), toneMapped: false }));
    sign.position.set(64.5, y0 + 3.3, 36.7); sign.rotation.y = -PI / 2; fg.add(sign);
    const plaqueMat = {};
    for (const R of ROOMS) {
      const mat = plaqueMat[R.id] = new THREE.MeshBasicMaterial({ map: plaqueTex(R.id, R.label), toneMapped: false });
      const zc = (R.door[0] + R.door[1]) / 2, sgn = R.id === 'H' ? -1 : 1;
      // plaque murale à côté de la porte (côté couloir)
      const pl = new THREE.Mesh(new THREE.PlaneGeometry(0.72, 0.3), mat); pl.position.set(W.x0 - 0.11, y0 + 1.65, R.id === 'H' ? R.door[0] - 0.45 : R.door[1] + 0.45); pl.rotation.y = -PI / 2; fg.add(pl);
      // lavabos (2 vasques), savon, robinets, miroir
      const z = R.sinkZ, wz = R.wallZ, face = R.id === 'H' ? 1 : -1;
      box(2.8, 0.08, 0.5, 71.3, 0.86, z, 0xf2f2f2, 'shiny'); box(2.8, 0.78, 0.44, 71.3, 0.43, z - face * 0.02, 0x6a4a32);
      for (const sx of [70.6, 72.0]) { box(0.46, 0.05, 0.34, sx, 0.9, z + face * 0.02, 0xffffff, 'shiny'); box(0.04, 0.2, 0.04, sx, 1.0, z - face * 0.17, 0xc8ccd0, 'shiny'); box(0.04, 0.03, 0.14, sx, 1.09, z - face * 0.11, 0xc8ccd0, 'shiny'); box(0.09, 0.2, 0.07, sx + 0.33, 1.2, wz + face * 0.04, R.id === 'H' ? 0x2f80ed : 0xc0306a); }
      box(2.6, 0.95, 0.03, 71.3, 1.68, wz, 0xd8e8f2, 'shiny'); box(2.7, 0.04, 0.05, 71.3, 2.17, wz, 0x8a8f96, 'shiny');
      solid(69.9, Math.min(z, wz) - 0.3, 72.7, Math.max(z, wz) + 0.3, 1);
      // distributeur d'essuie-mains, poubelle, ventilation, éclairage
      box(0.12, 0.4, 0.3, W.x0 + 0.16, 1.3, R.id === 'H' ? 33.95 : 39.45, 0xf2f2f2);
      const bz = R.id === 'H' ? 36.3 : 37.15; box(0.32, 0.46, 0.32, W.x0 + 0.35, 0.23, bz, 0x5a5f66, 'shiny'); box(0.34, 0.03, 0.34, W.x0 + 0.35, 0.47, bz, 0x2a2d33); solid(W.x0 + 0.17, bz - 0.17, W.x0 + 0.53, bz + 0.17, 0.5);
      const vz = R.id === 'H' ? 34.1 : 39.3; box(0.03, 0.4, 0.6, W.x1 - 0.1, 3.5, vz, 0x9aa0a6, 'shiny'); for (let k = 0; k < 5; k++) box(0.035, 0.03, 0.56, W.x1 - 0.11, 3.34 + k * 0.08, vz, 0x3a3d42);
      P.lamp.push(colored(new THREE.BoxGeometry(2.6, 0.04, 0.6).translate(72.5, y0 + H - 0.32, R.id === 'H' ? 34.6 : 38.9), 0xffffff));
      if (R.id === 'H') { for (const ux of [73.6, 74.6]) { box(0.38, 0.6, 0.3, ux, 0.95, W.z0 + 0.26, 0xffffff, 'shiny'); box(0.04, 0.9, 0.42, ux + 0.48, 1.1, W.z0 + 0.3, 0x9aa0a6); } solid(73.3, W.z0, 75.2, W.z0 + 0.5, 1.5); }
      else { box(0.9, 0.55, 0.12, 74.6, 1.15, W.z1 - 0.08, 0xf2f2f2); const tl = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.16), new THREE.MeshBasicMaterial({ map: canvasTex(256, 80, (x, w, h) => { x.fillStyle = '#f2f2f2'; x.fillRect(0, 0, w, h); x.fillStyle = '#a0306a'; x.font = 'bold 26px Arial'; x.textAlign = 'center'; x.fillText('Table à langer', w / 2, 50); }), toneMapped: false })); tl.position.set(74.6, y0 + 1.3, W.z1 - 0.145); tl.rotation.y = PI; fg.add(tl); }
      // cabines : cloisons, WC, papier, poubelle sanitaire, porte (animée)
      const [sz0, sz1] = R.stallZ, fz = R.frontZ, back = R.id === 'H' ? sz1 : sz0;
      for (const x of [STALLS[0][0], STALLS[1][0]]) box(0.04, 2.0, sz1 - sz0, x, 1.12, (sz0 + sz1) / 2, 0x9ab0c0);
      STALLS.forEach(([x0, x1], si) => {
        const xc = (x0 + x1) / 2;
        box(0.36, 2.0, 0.04, x0 + 0.18, 1.12, fz, 0x9ab0c0); box(0.36, 2.0, 0.04, x1 - 0.18, 1.12, fz, 0x9ab0c0);
        box(0.4, 0.42, 0.55, xc, 0.21, back + (R.id === 'H' ? -0.4 : 0.4), 0xffffff, 'shiny');
        box(0.44, 0.42, 0.18, xc, 0.62, back + (R.id === 'H' ? -0.1 : 0.1), 0xffffff, 'shiny');
        box(0.12, 0.12, 0.1, x0 + 0.1, 0.72, (sz0 + sz1) / 2, 0xf8f8f8); box(0.13, 0.03, 0.11, x0 + 0.1, 0.79, (sz0 + sz1) / 2, 0xc8ccd0, 'shiny');
        if (R.id === 'F') box(0.22, 0.32, 0.2, x1 - 0.16, 0.17, (sz0 + sz1) / 2 - 0.3, 0xe8e2d6);
        const piv = new THREE.Group(); piv.position.set(x0 + 0.36, y0 + 0.12, fz); fg.add(piv);
        const leaf = new THREE.Mesh(new THREE.BoxGeometry(0.8, 1.9, 0.04), this.mats.std); leaf.geometry = colored(leaf.geometry, 0x8aa4b4); leaf.position.set(0.4, 1.05, 0); piv.add(leaf);
        const st = { lv, room: R.id, n: si + 1, piv, open: 1, target: 1, xc, fz, sgn: R.id === 'H' ? 1 : -1 }; this.stalls.push(st);
        pts(`Utiliser les toilettes — ${R.label.toLowerCase()} (cabine ${si + 1})`, xc, R.useZ, () => this.useToilet(st), 0.85);
      });
      solid(STALLS[0][0], sz0, W.x1, sz1, 2.1);
      // porte d'entrée (battant, plaque, fermeture automatique)
      const [d0, d1] = R.door, piv = new THREE.Group(); piv.position.set(W.x0, y0 + 0.12, d0); fg.add(piv);
      const leaf = new THREE.Mesh(colored(new THREE.BoxGeometry(0.05, 2.15, d1 - d0 - 0.04), R.id === 'H' ? 0x3a5a7a : 0x7a3a5a), this.mats.std); leaf.position.set(0, 1.08, (d1 - d0) / 2); piv.add(leaf);
      const dp = new THREE.Mesh(new THREE.PlaneGeometry(0.6, 0.25), plaqueMat[R.id]); dp.position.set(-0.03, 1.55, (d1 - d0) / 2); dp.rotation.y = -PI / 2; piv.add(dp);
      const hd = new THREE.Mesh(colored(new THREE.BoxGeometry(0.16, 0.03, 0.03), 0xc8ccd0), this.mats.shiny); hd.position.set(0, 1.0, d1 - d0 - 0.12); piv.add(hd);
      const o = solid(W.x0 - 0.05, d0, W.x0 + 0.05, d1);
      const door = { lv, room: R.id, label: R.label, piv, col: o, open: 0, target: 0, zc };
      this.doors.push(door);
      pts(`Ouvrir / fermer — Toilettes ${R.label.toLowerCase()}`, W.x0 - 0.7, zc, () => this.toggleDoor(door), 1.1);
      pts(`Ouvrir / fermer la porte (sortie)`, W.x0 + 0.65, zc, () => this.toggleDoor(door), 0.8);
      pts(`Lavabo : se laver les mains (savon, miroir)`, 71.3, R.id === 'H' ? 34.35 : 39.05, () => this.wash(R), 1.0);
      pts('Poubelle', W.x0 + 0.6, bz + (R.id === 'H' ? -0.5 : 0.5), () => this.ui.toast('Poubelle : déchets jetés. Merci de garder les lieux propres.', 1.8), 0.6);
    }
    for (const k of ['std', 'shiny', 'lamp']) if (P[k].length) { const m = new THREE.Mesh(mergeGeometries(P[k]), this.mats[k]); m.receiveShadow = k !== 'lamp'; fg.add(m); }
  }
  toggleDoor(d, force) {
    d.target = force !== undefined ? force : d.target > 0.5 ? 0 : 1;
    if (this.audio && this.audio.ctx) this.audio.tone(d.target ? 520 : 380, 0.06, 0.04, 'triangle');
  }
  inRoom(x, z) { return this.nova.inside && x > W.x0 && x < W.x1 && z > W.z0 && z < W.z1 ? (z < W.mid ? 'H' : 'F') : null; }
  wash(R) {
    if (this.act) return;
    const pl = this.player; this.act = { kind: 'wash', t: 3, total: 3, pos: { x: 71.3, z: R.id === 'H' ? 34.45 : 38.95 }, face: R.id === 'H' ? PI : 0 };
    this.ui.toast('Lavage des mains : savon, rinçage, essuie-mains…', 2.6);
    if (this.audio && this.audio.ctx) for (let k = 0; k < 6; k++) this.audio.tone(1800 + Math.random() * 1400, 0.05, 0.012, 'sine', this.audio.sfx, k * 0.35);
    pl.facing = this.act.face;
  }
  useToilet(st) {
    if (this.act) return;
    this.act = { kind: 'wc', t: 4.5, total: 4.5, st, pos: { x: st.xc, z: st.fz - st.sgn * 0.45 } };
    st.target = 0; this.player.mesh.visible = false;
    this.ui.toast(`Cabine ${st.n} occupée…`, 2);
    if (this.audio && this.audio.ctx) this.audio.tone(380, 0.06, 0.04, 'triangle');
  }
  endAct() {
    const a = this.act; this.act = null;
    if (a.kind === 'wash') { this.needs.hygiene = Math.min(100, this.needs.hygiene + 8); this.needWash = false; this.ui.toast('Mains propres ! Propreté +8', 2); }
    else {
      a.st.target = 1; this.player.mesh.visible = true; this.needWash = true;
      if (this.audio && this.audio.ctx) { this.audio.tone(140, 0.7, 0.05, 'sine'); this.audio.tone(90, 0.9, 0.04, 'sine', this.audio.sfx, 0.2); }
      this.ui.toast('Chasse d’eau tirée. Pense à te laver les mains au lavabo.', 2.6);
    }
  }

  // ------------------------------------------------------------------ réfrigérateur du PDG
  buildFridge() {
    const fg = this.nova.floors[FR.lv].group, y0 = FR.lv * NB.fh + 0.12, P = [], S = [];
    const add = (geo, c, list = P) => list.push(colored(geo, c));
    const fx = FR.x, fz = FR.z;
    add(new THREE.BoxGeometry(0.66, 1.55, 0.72).translate(fx, y0 + 0.775, fz), 0x2a2d33);
    add(new THREE.BoxGeometry(0.58, 1.38, 0.64).translate(fx - 0.05, y0 + 0.8, fz), 0xe8eef2); // cuve intérieure
    for (let k = 0; k < 4; k++) {
      const y = y0 + 0.2 + k * 0.34; add(new THREE.BoxGeometry(0.56, 0.015, 0.62).translate(fx - 0.06, y, fz), 0xc8d0d6, S);
      for (let i = 0; i < 5; i++) add(new THREE.CylinderGeometry(0.035, 0.035, 0.2 + (k === 0 ? 0.06 : 0), 8).translate(fx - 0.15, y + 0.11, fz - 0.24 + i * 0.12), [0x2f80ed, 0xf2d040, 0xf0a020, 0x8a1a3a, 0xd8eef8, 0x6a4a2a, 0xc8102e][(k * 5 + i) % 7]);
    }
    add(new THREE.BoxGeometry(0.67, 0.12, 0.73).translate(fx, y0 + 1.5, fz), 0x0b6e4f); // bandeau
    fg.add(new THREE.Mesh(mergeGeometries(P), this.mats.std)); fg.add(new THREE.Mesh(mergeGeometries(S), this.mats.shiny));
    const lab = new THREE.Mesh(new THREE.PlaneGeometry(0.6, 0.1), new THREE.MeshBasicMaterial({ map: canvasTex(256, 44, (x, w, h) => { x.fillStyle = '#0b6e4f'; x.fillRect(0, 0, w, h); x.fillStyle = '#fff'; x.font = 'bold 26px Arial'; x.textAlign = 'center'; x.fillText('NOVA • FRAIS', w / 2, 31); }), toneMapped: false }));
    lab.position.set(fx - 0.34, y0 + 1.5, fz); lab.rotation.y = -PI / 2; fg.add(lab);
    this.fLight = new THREE.Mesh(colored(new THREE.BoxGeometry(0.5, 0.03, 0.5).translate(fx - 0.06, y0 + 1.46, fz), 0xffffff), new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false })); fg.add(this.fLight);
    // porte vitrée (charnière côté z−)
    const piv = new THREE.Group(); piv.position.set(fx - 0.345, y0, fz - 0.36); fg.add(piv);
    const frame = []; for (const [w, h, d, x, y, z] of [[0.04, 1.5, 0.05, 0, 0.77, 0.03], [0.04, 1.5, 0.05, 0, 0.77, 0.69], [0.04, 0.05, 0.72, 0, 0.04, 0.36], [0.04, 0.05, 0.72, 0, 1.5, 0.36], [0.05, 0.4, 0.03, -0.03, 0.85, 0.62]]) frame.push(colored(new THREE.BoxGeometry(w, h, d).translate(x, y, z), 0x2a2d33));
    piv.add(new THREE.Mesh(mergeGeometries(frame), this.mats.shiny));
    const gl = new THREE.Mesh(new THREE.BoxGeometry(0.015, 1.42, 0.64), this.mats.fglass); gl.position.set(0, 0.77, 0.36); gl.renderOrder = 4; piv.add(gl);
    this.fDoor = { piv, open: 0 };
    const o = this.world.collision.addBox(fx - 0.36, fz - 0.38, fx + 0.36, fz + 0.38, FR.lv * NB.fh + 1.8); o.lv = FR.lv;
    this.nova.points.push({ lv: FR.lv, x: fx - 0.95, z: fz, r: 1.1, label: 'Réfrigérateur du bureau (boissons & en-cas)', action: () => this.toggle(true) });
  }
  fridgeCount() { return Object.values(this.fridge).reduce((a, b) => a + b, 0); }
  restockCost() { let c = 0, n = 0; for (const [id, t] of Object.entries(CEO_FRIDGE_ITEMS)) { const k = Math.max(0, t - (this.fridge[id] || 0)); c += k * FOOD_BY_ID[id].price; n += k; } return { c, n }; }
  consume(id) {
    if (!(this.fridge[id] > 0)) return this.ui.toast('Il n’en reste plus : réapprovisionne le réfrigérateur.', 2);
    const f = FOOD_BY_ID[id]; this.fridge[id]--; if (!this.fridge[id]) delete this.fridge[id];
    this.needs.hunger = Math.min(100, this.needs.hunger + f.hunger);
    if (f.kind === 'drink') this.needs.energy = Math.min(100, this.needs.energy + 2);
    this.ui.toast(`${f.kind === 'drink' ? 'Tu bois' : 'Tu manges'} : ${f.name}. Faim +${f.hunger}`, 2);
    if (this.audio && this.audio.ctx) this.audio.tone(f.kind === 'drink' ? 620 : 300, 0.08, 0.04, 'sine');
    this.render(); this.onSave && this.onSave();
  }
  takeAway(id) {
    if (!(this.fridge[id] > 0)) return;
    this.fridge[id]--; if (!this.fridge[id]) delete this.fridge[id];
    this.economy.addToBag(id, 1); this.ui.toast(`${FOOD_BY_ID[id].name} mis dans ton sac (à ranger au frigo de la maison).`, 2);
    this.render(); this.onSave && this.onSave();
  }
  // réassort : confirmation, vérification du solde, protection contre le double paiement
  payRestock(src) {
    if (this.paying) return;
    const { c, n } = this.restockCost(); if (!n) { this.view = 'list'; return this.render(); }
    if (this.fridgeCount() + n > FR_CAP) return this.ui.toast('Capacité du réfrigérateur dépassée.', 2);
    this.paying = true;
    let ok = false;
    if (src === 'perso') ok = this.economy.pay(c, `Réassort réfrigérateur du bureau (${n} articles)`, 'NOVA BOOK • bureau du PDG');
    else if (this.company && this.company.cash >= c) { this.company.post(`Réassort réfrigérateur du bureau du PDG (${n} articles)`, -c, 'frais'); ok = true; }
    else this.ui.toast('Trésorerie de NOVA BOOK insuffisante.', 2.2);
    if (ok) {
      for (const [id, t] of Object.entries(CEO_FRIDGE_ITEMS)) this.fridge[id] = Math.max(this.fridge[id] || 0, t);
      this.lastPay = { c, src, t: this.economy.stamp() };
      this.economy.notify(`🧊 Réfrigérateur du bureau réapprovisionné : ${n} articles • ${fcfa(c)} (${src === 'perso' ? 'compte personnel' : 'NOVA BOOK'})`);
      this.view = 'list'; this.onSave && this.onSave();
    }
    this.paying = false; this.render();
  }
  buildDom() {
    this.dom = document.querySelector('#cfr');
    this.dom.addEventListener('click', (e) => {
      const b = e.target.closest('[data-cf]'); if (!b) { if (e.target === this.dom) this.toggle(false); return; }
      e.stopPropagation(); const [a, v] = b.dataset.cf.split(':');
      if (this.audio && this.audio.ctx && this.audio.click) this.audio.click();
      if (a === 'x') return this.toggle(false);
      if (a === 'sel') this.sel = v;
      if (a === 'use') return this.consume(this.sel);
      if (a === 'take') return this.takeAway(this.sel);
      if (a === 'restock') this.view = 'confirm';
      if (a === 'back') this.view = 'list';
      if (a === 'pay') return this.payRestock(v);
      this.render();
    });
  }
  toggle(on) {
    this.open = on; this.dom.classList.toggle('show', on); this.view = 'list';
    if (on) { if (this.audio && this.audio.ctx) this.audio.tone(300, 0.1, 0.03, 'sine'); if (this.kitchen && !this.kitchen.icons) { this.kitchen.makeIcons(); setTimeout(() => this.render(), 1500); setTimeout(() => this.render(), 4000); } this.render(); }
  }
  render() {
    if (!this.open) return;
    const ic = (id) => { const k = this.kitchen && this.kitchen.icons && this.kitchen.icons[id]; return k ? `<img src="${k}" alt="">` : '<span class="cf-emo">🥤</span>'; };
    const ids = Object.keys(CEO_FRIDGE_ITEMS), f = FOOD_BY_ID[this.sel], n = this.fridge[this.sel] || 0, rc = this.restockCost();
    let body;
    if (this.view === 'confirm') {
      const C = this.company, perso = this.economy.balance >= rc.c, comp = C && C.cash >= rc.c;
      body = `<div class="cf-confirm"><h3>Réapprovisionner le réfrigérateur</h3>
        ${rc.n ? `<p>${rc.n} article${rc.n > 1 ? 's' : ''} à compléter • total <b>${fcfa(rc.c)}</b></p>
        <div class="cf-lines">${ids.filter((id) => (this.fridge[id] || 0) < CEO_FRIDGE_ITEMS[id]).map((id) => `<span>${FOOD_BY_ID[id].name} ×${CEO_FRIDGE_ITEMS[id] - (this.fridge[id] || 0)}</span>`).join('')}</div>
        <p class="cf-note">Choisis le compte à débiter (monnaie virtuelle du jeu). Le paiement n’est effectué qu’une fois, après confirmation.</p>
        <button class="cf-go" data-cf="pay:perso" ${perso ? '' : 'disabled'}>CONFIRMER • compte personnel (${fcfa(this.economy.balance)})</button>
        <button class="cf-go alt" data-cf="pay:nova" ${comp ? '' : 'disabled'}>CONFIRMER • trésorerie NOVA BOOK${C ? ` (${fcfa(C.cash)})` : ''}</button>` : '<p>Le réfrigérateur est déjà plein.</p>'}
        <button class="cf-sec" data-cf="back">Annuler</button></div>`;
    } else {
      body = `<div class="cf-main"><div class="cf-grid">${ids.map((id) => `<button class="cf-card${id === this.sel ? ' sel' : ''}${this.fridge[id] ? '' : ' dim'}" data-cf="sel:${id}">${ic(id)}<b>${FOOD_BY_ID[id].name}</b><i>×${this.fridge[id] || 0}</i></button>`).join('')}</div>
        <div class="cf-det">${ic(f.id)}<h3>${f.name}</h3><p>${f.desc}</p><p class="cf-note">${f.kind === 'drink' ? 'Boisson fraîche' : 'En-cas'} • Faim +${f.hunger} • En stock : ${n}</p>
          <button class="cf-go" data-cf="use" ${n ? '' : 'disabled'}>${f.kind === 'drink' ? 'BOIRE' : 'MANGER'}</button>
          <button class="cf-sec" data-cf="take" ${n ? '' : 'disabled'}>Emporter (sac de courses)</button>
          <button class="cf-sec" data-cf="restock">🧾 Réapprovisionner${rc.n ? ` (${fcfa(rc.c)})` : ' (plein)'}</button>
          ${this.lastPay ? `<p class="cf-note">Dernier réassort : ${fcfa(this.lastPay.c)} • ${this.lastPay.src === 'perso' ? 'compte personnel' : 'NOVA BOOK'} • ${this.lastPay.t}</p>` : ''}</div></div>`;
    }
    this.dom.innerHTML = `<div class="cf-box"><div class="cf-head"><h2>🧊 Réfrigérateur du bureau du PDG</h2><span>${this.fridgeCount()} / ${FR_CAP}</span><button data-cf="x">✕</button></div>${body}</div>`;
  }
  handleKeys(input) { if (input.hit('Escape') || input.hit('KeyE')) this.toggle(false); }

  // ------------------------------------------------------------------ boucle
  update(dt, P) {
    const nova = this.nova, lv = nova.inside ? nova.level : -1;
    for (const d of this.doors) {
      if (d.target > 0.5 && (d.lv !== lv || Math.hypot(P.x - W.x0, P.z - d.zc) > 3.5)) d.target = 0; // fermeture automatique
      if (d.lv !== lv && d.open === 0) continue;
      d.open += (d.target - d.open) * Math.min(1, dt * 4); if (Math.abs(d.target - d.open) < 0.001) d.open = d.target;
      d.piv.rotation.y = d.open * 1.4; d.col.disabled = d.open > 0.55;
    }
    for (const s of this.stalls) if (s.lv === lv || s.open !== s.target) { s.open += (s.target - s.open) * Math.min(1, dt * 5); s.piv.rotation.y = s.sgn * s.open * 1.2; }
    // éclairage à détection de présence
    const room = this.inRoom(P.x, P.z);
    this.mats.lamp.color.setScalar(room ? 1 : 0.35);
    if (this._room === 'H' || this._room === 'F') { if (!room && this.needWash) { this.needWash = false; this.ui.toast('Tu es sorti sans te laver les mains…', 2); } }
    this._room = room;
    // frigo : porte animée et lumière intérieure
    const fo = this.open ? 1 : 0; this.fDoor.open += (fo - this.fDoor.open) * Math.min(1, dt * 6); this.fDoor.piv.rotation.y = -this.fDoor.open * 1.7;
    this.fLight.visible = this.fDoor.open > 0.1;
    // activité en cours (lavabo, cabine)
    if (this.act) {
      const a = this.act, pl = this.player; pl.pos.x = a.pos.x; pl.pos.z = a.pos.z; pl.mesh.position.copy(pl.pos);
      if (a.face !== undefined) pl.mesh.rotation.y = a.face;
      a.t -= dt; if (a.t <= 0) this.endAct();
    }
  }
  serialize() { return { fridge: { ...this.fridge }, lastPay: this.lastPay }; }
  restore(s) { if (!s) return; if (s.fridge) this.fridge = Object.fromEntries(Object.entries(s.fridge).filter(([k, v]) => CEO_FRIDGE_ITEMS[k] !== undefined && v > 0).map(([k, v]) => [k, Math.min(v | 0, 20)])); this.lastPay = s.lastPay || null; }
}
