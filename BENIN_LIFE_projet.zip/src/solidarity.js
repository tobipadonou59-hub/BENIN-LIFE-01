// Mission 019, étape 4 — actions sociales en ville : aider les personnes dans le besoin (personnages FICTIFS).
// 10 personnes aux histoires, personnalités et situations différentes, à Cotonou, Porto-Novo, Ouidah, Pahou et
// Cocotomey. Le joueur discute d'abord (bonjour, son histoire, ses besoins, ses espoirs), puis choisit comment aider :
// argent virtuel, repas, eau et vêtements, orientation vers un centre d'accueil (fictif), hébergement temporaire,
// soutien à une association locale (fictive), ou la solution propre à sa situation (outil de travail, soins…).
// Les personnes gardent leur dignité : elles peuvent préférer une autre aide que l'argent, remercient à leur façon, et
// leur situation évolue réellement (on les revoit plus tard en train de travailler). Pas de « points » affichés par
// action : la réputation humanitaire progresse doucement et chaque personne ne compte qu'une fois.
import * as THREE from 'three';
import { createCharacter, SKINS } from './character.js';
import { fcfa } from './food-data.js';
import { TOWNS } from './region-geo.js';
import { snap } from './transport.js';
import { avatarSVG } from './social.js';

const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const pick = (a) => a[Math.floor(Math.random() * a.length)];
export const ASSOCS = {
  main: { name: 'Association Main Tendue de Cotonou (fictive)', aim: 'repas, hygiène et accompagnement des personnes à la rue' },
  aines: { name: 'Les Amis des Aînés (fictive)', aim: 'visites et aide à domicile pour les personnes âgées isolées' },
  esperance: { name: 'Centre d’accueil Espérance (fictif)', aim: 'hébergement d’urgence, soins de base, orientation vers l’emploi' },
  pecheurs: { name: 'Pêcheurs Solidaires de Ouidah (fictive)', aim: 'entraide entre familles de pêcheurs' },
  banque: { name: 'Banque alimentaire du Golfe (fictive)', aim: 'colis alimentaires pour les familles' },
};
const STAGES = ['situation difficile', 'un peu soulagé·e', 'en amélioration', 'situation stabilisée'];
// base : lieu existant du jeu ; spot trouvé automatiquement à proximité (trottoir, place, plage)
const PEOPLE = [
  { id: 'koffi', name: 'Koffi', age: 58, female: false, town: 'Cotonou', place: 'Marché Dantokpa', base: [-44, 86], pose: 'sit', look: { shirtColor: 0x7a6a4a, pants: 0x3a3a3a }, assoc: 'main',
    hello: 'Bonjour, mon fils… pardon, monsieur. Merci de vous arrêter.', story: 'J’étais tailleur depuis trente ans. L’an dernier, les pluies ont inondé mon atelier : ma machine à coudre est perdue. Depuis, je fais de petites retouches à la main, ici, près du marché.', need: 'Ce qui me manque, c’est une machine. Avec elle, je retravaille et je nourris ma famille moi-même.', hope: 'Je voudrais apprendre le métier à mon petit-fils.', prefers: 'solution', solution: { label: 'Offrir une machine à coudre neuve', cost: 120000, done: 'Koffi a retrouvé un atelier de retouches près du marché. Il vous salue chaque fois que vous passez.' } },
  { id: 'mariama', name: 'Mariama', age: 27, female: true, town: 'Cotonou', place: 'Marché Dantokpa', base: [-58, 98], pose: 'stand', look: { pagne: 3 }, assoc: 'banque',
    hello: 'Bonjour ! Vous voulez des oranges ? Elles sont sucrées aujourd’hui.', story: 'Je vends des oranges pour payer l’école de mes deux enfants. Ma petite fille a de la fièvre depuis hier, je n’ai pas pu acheter ses médicaments.', need: 'Si elle pouvait voir un infirmier… Le reste, je me débrouille.', hope: 'Que mes enfants fassent de longues études.', prefers: 'solution', solution: { label: 'Payer la consultation et les médicaments (centre de santé)', cost: 25000, done: 'La fille de Mariama est guérie. Mariama a repris sa vente d’oranges, le sourire aux lèvres.' } },
  { id: 'agossi', name: 'Grand-mère Agossi', age: 74, female: true, town: 'Cotonou', place: 'Place des Martyrs', base: [44, 120], pose: 'sit', look: { headwrap: true, pagne: 6 }, assoc: 'aines',
    hello: 'Bonjour mon enfant. Asseyez-vous un peu, ça me fait plaisir de parler.', story: 'Mes enfants sont partis travailler loin. Je vis seule et mes jambes sont fatiguées. Je viens sur la place pour voir du monde.', need: 'Un repas chaud de temps en temps, et quelqu’un qui passe me voir.', hope: 'Revoir mes petits-enfants pour la fête.', prefers: 'assoc', solution: { label: 'Financer une aide à domicile par « Les Amis des Aînés » (3 mois)', cost: 90000, done: 'Une bénévole des Amis des Aînés passe chaque jour chez Grand-mère Agossi. Elle vous fait dire merci.' } },
  { id: 'ezechiel', name: 'Ezéchiel', age: 41, female: false, town: 'Cotonou', place: 'Plage de la Marina', base: [10, 158], pose: 'sit', look: { shirtColor: 0xf2c200, pants: 0x2a2a3a }, assoc: 'esperance',
    hello: 'Bonsoir patron. Il fait bon au bord de la mer, n’est-ce pas ?', story: 'J’étais zémidjan. Après un accident, ma moto a été détruite et ma jambe a mis des mois à guérir. Maintenant je cherche du travail, n’importe lequel.', need: 'Une formation de chauffeur, peut-être. Je connais toutes les rues de Cotonou.', hope: 'Retravailler et ne plus dépendre de personne.', prefers: 'solution', solution: { label: 'Financer une formation de chauffeur-livreur (centre Espérance)', cost: 150000, done: 'Ezéchiel a terminé sa formation : il est chauffeur-livreur pour une entreprise du port (fictive).' } },
  { id: 'rodrigue', name: 'Rodrigue', age: 19, female: false, town: 'Cotonou', place: 'Jardin de Cadjèhoun', base: [44, -44], pose: 'sit', look: { shirtColor: 0x1f4e9c, pants: 0x22252a }, assoc: 'esperance',
    hello: 'Bonjour monsieur. Je révise mes cours ici, c’est calme.', story: 'Je suis étudiant en première année. Le propriétaire de ma chambre a vendu la maison, et je n’ai pas encore trouvé de logement. Je dors chez des amis, un soir ici, un soir là.', need: 'Un logement quelques semaines, le temps de trouver une chambre.', hope: 'Devenir ingénieur en informatique.', prefers: 'hebergement', solution: { label: 'Payer la caution d’une chambre étudiante et des fournitures', cost: 60000, done: 'Rodrigue a une chambre près de l’université. Il vous a écrit que ses notes remontent.' } },
  { id: 'jules', name: 'Jules', age: 35, female: false, town: 'Cotonou', place: 'Supermarché LAGUNA', base: [34, -100], pose: 'stand', look: { shirtColor: 0xe46a1f, pants: 0x2a2f3a }, assoc: 'esperance',
    hello: 'Bonjour. Excusez-moi de vous déranger.', story: 'Je suis maçon. Je me suis blessé au poignet sur un chantier, et sans contrat je n’ai rien touché. Ça fait trois semaines.', need: 'De quoi tenir le temps de guérir, et des conseils pour mes droits.', hope: 'Remonter des murs, construire des maisons solides.', prefers: 'orienter', solution: { label: 'Prendre en charge les soins du poignet et un mois de loyer', cost: 70000, done: 'Jules est guéri ; le centre Espérance l’a aidé à retrouver un chantier, avec un contrat cette fois.' } },
  { id: 'sylvain', name: 'Sylvain', age: 66, female: false, town: 'Porto-Novo', place: 'Porto-Novo', pose: 'sit', look: { shirtColor: 0x6a1a2a, pants: 0x3a3a3a, hat: 'straw' }, assoc: 'aines',
    hello: 'Bonjour ! Vous aimez la musique ? Je joue du gankogui depuis l’enfance.', story: 'Je jouais dans les cérémonies et les fêtes. Avec l’âge, on m’appelle moins. Je joue ici pour quelques pièces.', need: 'Que la musique continue… et un toit plus solide : ma chambre prend l’eau.', hope: 'Enseigner les rythmes aux jeunes du quartier.', prefers: 'assoc', solution: { label: 'Financer des cours de musique traditionnelle donnés par Sylvain (centre culturel, 6 mois)', cost: 100000, done: 'Sylvain enseigne les rythmes traditionnels à vingt jeunes de Porto-Novo. Il est rayonnant.' } },
  { id: 'afi', name: 'Afi', age: 45, female: true, town: 'Ouidah', place: 'Ouidah', pose: 'stand', look: { pagne: 1, headwrap: true }, assoc: 'pecheurs',
    hello: 'Bonjour. Vous venez de Cotonou ? Ici, c’est le pays de la pêche.', story: 'Mon mari et moi pêchons et je vends le poisson au marché. Notre pirogue s’est fendue pendant la dernière tempête. Sans elle, plus de pêche.', need: 'Faire réparer la pirogue, et le filet aussi.', hope: 'Que nos enfants aient le choix de leur métier.', prefers: 'solution', solution: { label: 'Financer la réparation de la pirogue et un filet neuf', cost: 150000, done: 'La pirogue d’Afi est réparée : la famille a repris la pêche. Elle vous garde le plus beau poisson.' } },
  { id: 'bertrand', name: 'Bertrand', age: 52, female: false, town: 'Pahou', place: 'Pahou', pose: 'sit', look: { shirtColor: 0x2f7a3a, pants: 0x3a3a2a }, assoc: 'main',
    hello: 'Bonjour. Vous voulez du pain sucré ? J’en vendais beaucoup avant.', story: 'Je vends sur le bord de la route. Mais je tousse beaucoup depuis des semaines et je n’ai pas pu me soigner. Je suis fatigué.', need: 'Voir un médecin. J’ai peur que ce soit grave.', hope: 'Reprendre mon petit commerce, tout simplement.', prefers: 'orienter', solution: { label: 'Payer les examens et le traitement complet', cost: 45000, done: 'Bertrand a été soigné à temps. Il a repris sa vente au bord de la RNIE 1.' } },
  { id: 'adjoa', name: 'Adjoa', age: 23, female: true, town: 'Cocotomey', place: 'Cocotomey', pose: 'stand', look: { pagne: 5 }, assoc: 'banque',
    hello: 'Bonjour monsieur. Je viens d’arriver, je ne connais encore personne ici.', story: 'Je viens du Nord, de Natitingou. Je suis venue chercher du travail en ville, mais je n’ai pas encore trouvé. Je dors chez une cousine éloignée, dans une pièce trop petite.', need: 'Un travail, même modeste. Je sais coudre, cuisiner, et je parle trois langues.', hope: 'Ouvrir un jour un petit restaurant de plats du Nord.', prefers: 'solution', solution: { label: 'Financer une formation en restauration et un kit de démarrage', cost: 110000, done: 'Adjoa sert maintenant des plats du Nord dans une petite cantine de Cocotomey. Les clients reviennent !' } },
];
const HELPS = {
  argent: { label: 'Donner de l’argent (virtuel)', amounts: [2000, 10000, 50000] },
  repas: { label: 'Acheter un repas (maquis voisin)', cost: 1500 },
  eau: { label: 'Offrir de l’eau et des vêtements', cost: 5000 },
  orienter: { label: 'Orienter vers le centre d’accueil Espérance', cost: 0 },
  hebergement: { label: 'Financer un hébergement temporaire (7 nuits, foyer partenaire)', cost: 35000 },
  assoc: { label: 'Soutenir l’association locale', cost: 100000 },
};
export const PROJECTS = [
  { id: 'cantine', name: 'Cantine solidaire de Dantokpa', goal: 2000000, assoc: 'main', people: ['koffi', 'mariama'], text: 'repas chauds à petit prix pour les travailleurs du marché' },
  { id: 'atelier', name: 'Atelier de couture solidaire', goal: 1500000, assoc: 'esperance', people: ['koffi', 'adjoa'], text: 'machines partagées et formation au métier' },
  { id: 'aines', name: 'Fonds de visites et de soins des aînés', goal: 1200000, assoc: 'aines', people: ['agossi', 'sylvain'], text: 'aide à domicile et consultations gratuites' },
  { id: 'pirogues', name: 'Pirogues solidaires de Ouidah', goal: 2500000, assoc: 'pecheurs', people: ['afi'], text: 'réparation des pirogues après les tempêtes' },
];

export class Solidarity {
  constructor(ctx) {
    Object.assign(this, ctx); // scene, world, player, ui, audio, economy, env, events, phonePlus, onSave
    this.st = {}; this.hum = 0; this.ledger = []; this.projects = {}; this.assocs = {}; this.open = false; this.cur = null; this.log = []; this.view = 'personnes';
    this.chars = []; this.dom = document.querySelector('#aide'); this.dom.addEventListener('click', (e) => this.onClick(e));
    for (const P of PEOPLE) this.place(P);
  }
  S(id) { return this.st[id] || (this.st[id] = { met: false, stage: 0, helps: [], hum: 0, asked: null, solved: false, topics: {} }); }
  // ------------------------------------------------------------------ placement (lieux existants, hors chaussée)
  place(P) {
    let bx, bz; if (P.base) [bx, bz] = P.base; else { const t = TOWNS.find((q) => q.name === P.town); if (!t) return; bx = t.x + 12; bz = t.z - 10; }
    const C = this.world.collision; let spot = null;
    for (let r = 0; r <= 40 && !spot; r += 2) for (let a = 0; a < 16; a++) { const x = bx + Math.cos(a * 0.39) * r, z = bz + Math.sin(a * 0.39) * r; if (C.pointBlocked(x, 1, z)) continue; const sn = snap(x, z); if (!P.base && sn.d < 9) continue; spot = { x, z }; break; }
    if (!spot) spot = { x: bx, z: bz };
    const i = this.chars.length, c = createCharacter({ female: P.female, skin: SKINS[(i * 3 + 1) % SKINS.length], skirt: P.female, ...P.look });
    if (P.pose === 'sit') c.sit(false);
    const g = new THREE.Group(); g.add(c.group); c.group.position.y = P.pose === 'sit' ? -0.42 : 0;
    if (P.pose === 'sit') { const stool = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.42, 0.4), new THREE.MeshStandardMaterial({ color: 0x6a4a32 })); stool.position.set(0, 0.21, -0.05); g.add(stool); }
    // ce qui change quand la situation est stabilisée (outil de travail, étal…)
    const work = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.75, 0.45), new THREE.MeshStandardMaterial({ color: { koffi: 0x2a2d33, mariama: 0xe8a020, afi: 0x2f80ed, adjoa: 0xd8b070 }[P.id] || 0x8a6a42 })); work.position.set(0, 0.38, 0.75); work.visible = false; g.add(work);
    g.position.set(spot.x, 0, spot.z); g.rotation.y = Math.atan2(bx - spot.x, bz - spot.z) || 0; this.scene.add(g);
    this.chars.push({ P, c, g, work, x: spot.x, z: spot.z, t: Math.random() * 5 });
  }
  // ------------------------------------------------------------------ boucle
  update(dt) {
    const pl = this.player.pos, day = this.economy.day;
    for (const ch of this.chars) {
      const d = Math.hypot(pl.x - ch.x, pl.z - ch.z); ch.g.visible = d < 150; if (!ch.g.visible) continue;
      const s = this.S(ch.P.id); ch.work.visible = s.solved;
      if (d < 60 && ch.P.pose !== 'sit') ch.c.animate(dt, 0);
      // la personne peut solliciter poliment (une fois par jour, jamais avec insistance)
      if (d < 4.5 && !this.player.inCar && s.asked !== day && !this.open && !s.solved) { s.asked = day; this.ui.toast(`${s.met ? ch.P.name : 'Une personne'} : « ${s.met ? 'Re-bonjour ! Merci encore de vous être arrêté.' : 'Excusez-moi… auriez-vous un moment pour parler ?'} »`, 3); }
    }
  }
  nearest(x, z) {
    let best = null; for (const ch of this.chars) { if (!ch.g.visible) continue; const d = Math.hypot(x - ch.x, z - ch.z); if (d < 1.9 && (!best || d < best.d)) best = { d, ch }; }
    if (!best) return null; const P = best.ch.P, s = this.S(P.id);
    return { d: best.d, it: { label: () => (s.met ? `Parler à ${P.name}` : `Parler à ${P.female ? 'la femme' : 'l’homme'} ${P.pose === 'sit' ? 'assis' + (P.female ? 'e' : '') : 'debout'} ici`), action: () => this.talk(P) } };
  }
  // ------------------------------------------------------------------ conversation et aide
  talk(P) {
    const s = this.S(P.id); this.cur = P; this.log = []; s.met = true;
    this.say(s.solved ? 'Ah, c’est vous ! Grâce à votre aide, ma vie a changé. Merci, vraiment. Venez quand vous voulez.' : s.met && s.helps.length ? 'Re-bonjour ! Merci encore pour l’autre jour.' : P.hello);
    this.open = true; this.dom.classList.add('show'); this.render(); this.onSave && this.onSave();
  }
  say(txt, me) { this.log.push({ me: !!me, txt }); }
  close() { this.open = false; this.cur = null; this.dom.classList.remove('show'); }
  topic(k) {
    const P = this.cur, s = this.S(P.id); s.topics[k] = true;
    const q = { story: 'Qu’est-ce qui vous arrive, si je peux me permettre ?', need: 'De quoi auriez-vous besoin ?', hope: 'Et pour l’avenir, qu’espérez-vous ?', moi: 'Je m’appelle… je dirige NOVA BOOK.' }[k];
    this.say(q, true);
    if (k === 'moi') this.say(pick(['Enchanté. C’est gentil de prendre le temps de parler avec moi.', 'Merci de vous présenter. Peu de gens s’arrêtent.', 'NOVA BOOK ? Mes petits-enfants lisent vos livres à l’école !']));
    else this.say(P[k]);
    this.render();
  }
  help(kind, amount) {
    const P = this.cur, s = this.S(P.id), H = HELPS[kind];
    if (!s.topics.story && kind !== 'repas' && kind !== 'eau') { this.say('Avant tout, prenez le temps de parler : demandez-lui ce qui lui arrive.', false); return this.render(); } // écouter d'abord
    let cost = kind === 'argent' ? amount : kind === 'solution' ? P.solution.cost : kind === 'assoc' ? H.cost : H.cost;
    if (kind === 'argent' && P.prefers !== 'argent' && amount > 10000 && !s.moneyOk) { s.moneyOk = true; this.say(`Merci, c’est généreux… mais ${P.prefers === 'solution' ? `ce qui m’aiderait vraiment, c’est : ${P.solution.label.toLowerCase()}.` : P.prefers === 'orienter' ? 'j’aurais surtout besoin d’être orienté·e vers des gens qui peuvent m’aider durablement.'.replace('orienté·e', P.female ? 'orientée' : 'orienté') : 'je préférerais que vous aidiez l’association qui nous accompagne.'} Je ne veux pas dépendre d’un don.`); return this.render(); }
    if (cost > 0) { if (this.economy.balance < cost) { this.say('(Solde personnel insuffisant.)', true); return this.render(); } if (!this.economy.pay(cost, `Aide solidaire — ${kind === 'solution' ? P.solution.label : H.label} (${P.name})`, 'Solidarité')) return; }
    this.say(kind === 'argent' ? `(Vous donnez ${fcfa(cost)}.)` : kind === 'solution' ? `(${P.solution.label}.)` : `(${H.label}.)`, true);
    let gain = 0, stage = 0;
    if (kind === 'repas') { this.say(pick(['Merci… je n’avais pas mangé depuis ce matin.', 'Que Dieu vous le rende. C’est très gentil.'])); gain = 1; stage = s.stage < 1 ? 1 : 0; }
    else if (kind === 'eau') { this.say('Merci beaucoup, ça va m’être très utile.'); gain = 1; stage = s.stage < 1 ? 1 : 0; }
    else if (kind === 'argent') { this.say(cost >= 50000 ? 'Je… je ne sais pas quoi dire. Merci du fond du cœur.' : 'Merci, ça m’aide pour aujourd’hui.'); gain = cost >= 50000 ? 3 : 1; stage = cost >= 10000 && s.stage < 1 ? 1 : 0; }
    else if (kind === 'orienter') { this.say(P.prefers === 'orienter' ? 'Le centre Espérance ? On m’en a parlé mais je n’osais pas y aller. J’irai demain, merci de m’avoir expliqué.' : 'Merci pour l’adresse, je la garde précieusement.'); gain = P.prefers === 'orienter' ? 3 : 1; stage = P.prefers === 'orienter' ? 1 : 0; this.know('esperance'); }
    else if (kind === 'hebergement') { this.say(P.prefers === 'hebergement' ? 'Une semaine au calme… je vais pouvoir chercher une chambre sereinement. Merci !' : 'Merci, quelques nuits au sec, ça change tout.'); gain = 3; stage = 1; this.know('esperance'); }
    else if (kind === 'assoc') { const A = ASSOCS[P.assoc]; this.say(`${A.name.replace(' (fictive)', '').replace(' (fictif)', '')} fait un travail formidable. Avec votre soutien, ils pourront aider d’autres personnes comme moi.`); gain = 3; stage = P.prefers === 'assoc' ? 1 : 0; this.know(P.assoc, cost); }
    else if (kind === 'solution') { this.say(pick(['C’est exactement ce dont j’avais besoin. Je vais pouvoir me relever par moi-même.', 'Vous avez écouté ce que je disais… Merci, je ne l’oublierai pas.'])); gain = 6; stage = 3; s.solved = true; s.solvedDay = this.economy.day; }
    s.stage = Math.min(3, s.stage + stage);
    const room = Math.max(0, 10 - s.hum), g = Math.min(gain, room); s.hum += g; this.hum = Math.min(100, this.hum + g); // chaque personne ne compte qu'une fois
    if (this.events) { this.events.repAdd('generosite', g * 0.6); if (g >= 3) this.events.repAdd('prestige', 0.5); }
    s.helps.push({ t: this.economy.stamp(), kind, cost }); this.ledger.unshift({ t: this.economy.stamp(), who: P.name, what: kind === 'solution' ? P.solution.label : H.label, cost }); this.ledger.length = Math.min(this.ledger.length, 80);
    this.milestones(); this.render(); this.onSave && this.onSave();
  }
  know(id, gift = 0) {
    const A = this.assocs[id] || (this.assocs[id] = { since: this.economy.stamp(), given: 0 }); A.given += gift;
    if (!A.contact) { A.contact = true; if (this.economy.notify) this.economy.notify(`🤝 Nouveau contact : ${ASSOCS[id].name}. ${gift ? 'Merci pour votre soutien !' : 'Ils vous remercient d’avoir orienté une personne vers eux.'}`); }
  }
  milestones() {
    const h = this.hum;
    if (h >= 12 && !this.m1) { this.m1 = true; this.know('main'); this.economy.notify('💌 L’association Main Tendue de Cotonou (fictive) vous écrit : « Des habitants nous ont parlé de vous. Merci pour votre écoute. »'); }
    if (h >= 22 && !this.m2) { this.m2 = true; if (this.events && this.events.invite) { const e = this.events.invite(true, 'concert'); if (e) this.economy.notify('🎻 Invitation à un événement caritatif reçue (Événements › Invitations).'); } }
    if (h >= 30 && !this.m3) { this.m3 = true; this.economy.notify('🌱 Projets sociaux ouverts : les associations vous proposent de financer des projets durables (NOVA Solidarité › Projets).'); }
  }
  fund(pid, amount) {
    const Pj = PROJECTS.find((q) => q.id === pid); if (!Pj) return; const st = this.projects[pid] || (this.projects[pid] = { got: 0, done: false }); if (st.done) return;
    const amt = Math.min(amount, Pj.goal - st.got); if (!this.economy.pay(amt, `Projet social — ${Pj.name}`, 'Solidarité')) return this.ui.toast('Solde insuffisant.', 2);
    st.got += amt; this.ledger.unshift({ t: this.economy.stamp(), who: Pj.name, what: 'Financement de projet social', cost: amt }); this.know(Pj.assoc, amt);
    if (st.got >= Pj.goal) { st.done = true; this.hum = Math.min(100, this.hum + 5); if (this.events) this.events.repAdd('generosite', 4); for (const id of Pj.people) { const s = this.S(id); s.stage = Math.min(3, s.stage + 1); } this.economy.notify(`🎉 Projet réalisé : ${Pj.name} — ${Pj.text}. Les bénéficiaires vous remercient.`); }
    this.onSave && this.onSave();
  }
  humLabel() { const h = this.hum; return h < 5 ? 'pas encore connue' : h < 15 ? 'quelques habitants vous connaissent' : h < 30 ? 'reconnue dans les quartiers' : h < 50 ? 'saluée par les associations' : 'reconnue dans tout le Golfe'; }
  // ------------------------------------------------------------------ interface (conversation)
  render() {
    if (!this.open || !this.cur) return; const P = this.cur, s = this.S(P.id);
    const helps = Object.entries(HELPS).map(([k, H]) => k === 'argent' ? H.amounts.map((a) => `<button data-ai="help:argent|${a}">💵 ${fcfa(a)}</button>`).join('') : `<button data-ai="help:${k}">${{ repas: '🍲', eau: '💧', orienter: '🧭', hebergement: '🛏️', assoc: '🤝' }[k]} ${H.label}${H.cost ? ` (${fcfa(H.cost)})` : ''}</button>`).join('');
    this.dom.innerHTML = `<div class="tk-box"><div class="tk-head">${avatarSVG({ seed: P.age * 7, female: P.female, skin: SKINS[1], shirt: 0x7a6a4a, age: P.age, wrap: !!P.look.headwrap }, 44)}<h2>${esc(P.name)}<small class="sc-sub">${P.age} ans • ${esc(P.place)}${P.town !== P.place ? `, ${P.town}` : ''} • personnage fictif</small></h2><button data-ai="x">✕</button></div>
      <p class="tk-note">Situation : ${STAGES[s.stage].replace('·e', P.female ? 'e' : '')}${s.solved ? ' ✓' : ''}</p>
      <div class="tk-log">${this.log.map((l) => `<div class="tk-msg ${l.me ? 'me' : ''}"><span>${esc(l.txt)}</span></div>`).join('')}</div>
      <div class="tk-sugg"><button data-ai="t:moi">🙋 Me présenter</button><button data-ai="t:story">💬 Que vous arrive-t-il ?</button><button data-ai="t:need">❓ De quoi avez-vous besoin ?</button><button data-ai="t:hope">🌅 Vos espoirs ?</button></div>
      ${s.solved ? '' : `<div class="mt-chips aide-help">${helps}${s.topics.need ? `<button class="on" data-ai="help:solution">✨ ${esc(P.solution.label)} (${fcfa(P.solution.cost)})</button>` : ''}</div>`}
      <p class="tk-note">Aide en monnaie virtuelle du jeu, prélevée sur le compte personnel. ${!s.topics.story ? 'Prenez d’abord le temps d’écouter son histoire.' : ''}</p></div>`;
    const lg = this.dom.querySelector('.tk-log'); if (lg) lg.scrollTop = lg.scrollHeight;
  }
  onClick(ev) {
    const b = ev.target.closest('[data-ai]'); if (!b) { if (ev.target === this.dom) this.close(); return; } ev.stopPropagation();
    const [a, v] = b.dataset.ai.split(':');
    if (a === 'x') return this.close();
    if (a === 't') return this.topic(v);
    if (a === 'help') { const [k, amt] = v.split('|'); return this.help(k, +amt || 0); }
  }
  handleKeys(input) { if (input.hit('Escape')) this.close(); }
  // ------------------------------------------------------------------ application « NOVA Solidarité » (actions sociales)
  renderApp(b, extra = '') {
    const tabs = [['personnes', 'Personnes'], ['assocs', 'Associations'], ['projets', 'Projets sociaux'], ['historique', 'Historique'], ...(this.extraTabs || [])];
    let body = '';
    if (this.view === 'personnes') body = `<p class="ph-note">Réputation humanitaire : <b>${this.humLabel()}</b>. Les personnes rencontrées sont des personnages fictifs ; leurs lieux ne sont pas marqués sur la carte, par respect.</p><div class="ph-list">${PEOPLE.filter((P) => this.S(P.id).met).map((P) => { const s = this.S(P.id); return `<div class="ph-row"><span><b>${esc(P.name)}, ${P.age} ans</b><small>${esc(P.place)}${P.town !== P.place ? `, ${P.town}` : ''} • ${STAGES[s.stage].replace('·e', P.female ? 'e' : '')}${s.solved ? ` • ${esc(P.solution.done)}` : ''}</small></span></div>`; }).join('') || '<p class="ph-note">Personne rencontrée pour l’instant. Promène-toi dans les quartiers de Cotonou et dans les villes de la région.</p>'}</div>`;
    else if (this.view === 'assocs') body = `<div class="ph-list">${Object.entries(ASSOCS).map(([id, A]) => { const k = this.assocs[id]; return `<div class="ph-row"><span><b>${esc(A.name)}</b><small>${esc(A.aim)}${k ? ` • en contact depuis ${k.since} • ${fcfa(k.given)} versés` : ' • pas encore en contact'}</small></span>${k ? `<button class="ph-mini" data-so="don:${id}">Don 100 000</button>` : ''}</div>`; }).join('')}</div>`;
    else if (this.view === 'projets') body = this.m3 ? PROJECTS.map((Pj) => { const st = this.projects[Pj.id] || { got: 0 }; return `<div class="ph-row"><span><b>${esc(Pj.name)}</b><small>${esc(Pj.text)} • avec ${esc(ASSOCS[Pj.assoc].name)} • ${fcfa(st.got)} / ${fcfa(Pj.goal)}${st.done ? ' • ✅ réalisé' : ''}</small></span>${st.done ? '' : `<span class="pp-acts"><button class="ph-mini" data-so="fund:${Pj.id}|250000">250 000</button><button class="ph-mini" data-so="fund:${Pj.id}|1000000">1 M</button></span>`}</div>`; }).join('') : '<p class="ph-note">Les projets sociaux s’ouvrent quand les associations vous connaissent (aidez plusieurs personnes et soutenez les associations).</p>';
    else if (this.view === 'historique') body = `<div class="ph-list">${this.ledger.slice(0, 25).map((l) => `<div class="ph-row"><span><b>${esc(l.who)}</b><small>${l.t} • ${esc(l.what)}</small></span><em>${l.cost ? fcfa(l.cost) : 'gratuit'}</em></div>`).join('') || '<p class="ph-note">Aucune action pour l’instant.</p>'}</div>`;
    else body = this.extraRender ? this.extraRender(this.view) : extra;
    b.innerHTML = `<h4>🤝 NOVA Solidarité</h4><div class="ph-chips">${tabs.map(([k, l]) => `<button data-so="tab:${k}" class="${this.view === k ? 'on' : ''}">${l}</button>`).join('')}</div>${body}`;
  }
  onPhone(v) {
    const i = v.indexOf(':'), a = v.slice(0, i), arg = v.slice(i + 1);
    if (a === 'tab') this.view = arg;
    else if (a === 'don') { if (this.economy.pay(100000, `Don — ${ASSOCS[arg].name}`, 'Solidarité')) { this.know(arg, 100000); this.ledger.unshift({ t: this.economy.stamp(), who: ASSOCS[arg].name, what: 'Don à l’association', cost: 100000 }); this.hum = Math.min(100, this.hum + 1); this.milestones(); } }
    else if (a === 'fund') { const [pid, amt] = arg.split('|'); this.fund(pid, +amt); }
    else if (this.onPhoneExtra) this.onPhoneExtra(a, arg);
    this.onSave && this.onSave(); if (this.economy.phoneOpen) this.economy.renderPhone();
  }
  serialize() { return { st: this.st, hum: this.hum, ledger: this.ledger, projects: this.projects, assocs: this.assocs, m: [this.m1, this.m2, this.m3] }; }
  restore(s) { if (!s) return; this.st = s.st || {}; this.hum = s.hum || 0; this.ledger = s.ledger || []; this.projects = s.projects || {}; this.assocs = s.assocs || {}; [this.m1, this.m2, this.m3] = s.m || []; for (const k of Object.keys(this.st)) this.st[k].asked = null; }
}
