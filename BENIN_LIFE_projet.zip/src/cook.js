// Mission 019, étape 2 — cuisinier personnel permanent de la VILLA NOVA.
// Recrutement (3 candidats fictifs), identité et personnalité, tenue de cuisine (veste blanche, toque, tablier),
// déplacements dans la cuisine professionnelle de l'aile (plan de travail, îlot, réfrigérateur), préparation des
// repas avec les VRAIS plats et ingrédients du jeu (catalogue alimentaire existant), réserves au réfrigérateur (stock de
// la cuisine du jeu) et dans les placards (épicerie sèche), courses faites par le cuisinier sur accord du joueur,
// menus proposés pour le petit-déjeuner, le déjeuner et le dîner, repas planifiés, commandes depuis le téléphone ou
// dans la cuisine, service à la salle à manger ou livraison par le chauffeur, conversation libre, salaire en FCFA
// virtuels (prélevé sur le compte personnel tous les 7 jours de jeu).
import * as THREE from 'three';
import { createCharacter, SKINS } from './character.js';
import { FOOD_BY_ID, fcfa } from './food-data.js';
import { VILLA } from './villa.js';

const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const norm = (s) => s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[’']/g, ' ');
const pick = (a) => a[Math.floor(Math.random() * a.length)];
export const CANDIDATES = [
  { id: 'clem', name: 'Clémentine Agossa', female: true, age: 52, origin: 'Bohicon', years: 25, salary: 150000, spec: 'Cuisine béninoise traditionnelle (pâtes, sauces, grillades)', trait: 'chaleureuse et fière de la cuisine de sa grand-mère', skin: SKINS[1] },
  { id: 'rodo', name: 'Rodolphe Kiki', female: false, age: 38, origin: 'Cotonou', years: 14, salary: 220000, spec: 'Chef formé en hôtellerie : cuisine béninoise raffinée et présentation', trait: 'perfectionniste et créatif', skin: SKINS[3] },
  { id: 'awa', name: 'Awa Sanni', female: true, age: 31, origin: 'Parakou', years: 8, salary: 130000, spec: 'Cuisine du Nord et du Sud, jus naturels et pâtisseries', trait: 'dynamique et toujours souriante', skin: SKINS[0] },
];
// épicerie sèche des placards (ingrédients du catalogue du jeu ; « fleurs_bissap » est propre aux placards)
const PANTRY = ['farine_mais', 'riz', 'haricots_secs', 'gari', 'huile_rouge', 'huile_arachide', 'arachide', 'sucre', 'cossettes', 'farine_mil', 'farine_ble', 'sel', 'cube', 'crevettes_sechees', 'fleurs_bissap', 'pain_singe', 'gingembre_racine', 'lait_poudre'];
const EXTRA = { fleurs_bissap: { name: 'Fleurs de bissap séchées', price: 300 } };
const iname = (id) => (FOOD_BY_ID[id] ? FOOD_BY_ID[id].name : EXTRA[id] ? EXTRA[id].name : id);
const iprice = (id) => (FOOD_BY_ID[id] ? FOOD_BY_ID[id].price : EXTRA[id] ? EXTRA[id].price : 300);
// plats du cuisinier : assiette (identifiants du catalogue) + ingrédients + durée (minutes de jeu)
export const DISHES = [
  { id: 'amiwo', name: 'Amiwo au poulet', plate: ['amiwo'], need: { farine_mais: 1, tomate: 1, poulet_frais: 1, huile_rouge: 1 }, min: 60, meal: ['dej', 'din'] },
  { id: 'watche', name: 'Watché, poisson braisé et sauce tomate', plate: ['watche', 'poisson_grille', 'sauce_tomate'], need: { riz: 1, haricots_secs: 1, poisson_frais: 1, tomate: 1, oignon: 1 }, min: 70, meal: ['dej'] },
  { id: 'atassi', name: 'Atassi et sauce pimentée', plate: ['atassi', 'sauce_pimentee'], need: { riz: 1, haricots_secs: 1, piment: 1, tomate: 1 }, min: 50, meal: ['dej', 'din'] },
  { id: 'akassa', name: 'Akassa, poisson frit et dja', plate: ['akassa', 'poisson_frit', 'dja'], need: { farine_mais: 1, poisson_frais: 1, huile_arachide: 1, tomate: 1, piment: 1 }, min: 45, meal: ['dej', 'din'] },
  { id: 'ablo', name: 'Ablo et poisson grillé', plate: ['ablo', 'poisson_grille'], need: { farine_mais: 1, sucre: 1, poisson_frais: 1 }, min: 50, meal: ['dej'] },
  { id: 'wo', name: 'Wɔ̌ (pâte blanche) et sauce gombo', plate: ['pate_blanche', 'sauce_gombo'], need: { farine_mais: 1, gombo: 1, tomate: 1 }, min: 45, meal: ['dej', 'din'] },
  { id: 'wo_crincrin', name: 'Wɔ̌ et sauce crincrin', plate: ['pate_blanche', 'sauce_crincrin'], need: { farine_mais: 1, corete: 1, crevettes_sechees: 1 }, min: 45, meal: ['din'] },
  { id: 'igname', name: 'Igname pilée, sauce graine et wagashi', plate: ['igname_pilee', 'sauce_graine', 'wagashi'], need: { igname: 1, huile_rouge: 1, tomate: 1, wagashi: 1 }, min: 80, meal: ['dej', 'din'] },
  { id: 'riz_gras', name: 'Riz au gras et poulet braisé', plate: ['riz_gras', 'poulet_grille'], need: { riz: 1, tomate: 1, oignon: 1, poulet_frais: 1 }, min: 70, meal: ['dej', 'din'] },
  { id: 'gari', name: 'Gari et sauce', plate: ['gari_sauce'], need: { gari: 1, tomate: 1, oignon: 1 }, min: 20, meal: ['dej', 'din'] },
  { id: 'pate_rouge', name: 'Pâte rouge et sauce arachide', plate: ['pate_rouge', 'sauce_arachide'], need: { farine_mais: 1, tomate: 1, arachide: 1, huile_rouge: 1 }, min: 55, meal: ['din'] },
  { id: 'poulet', name: 'Poulet braisé et alloco', plate: ['poulet_grille', 'alloco'], need: { poulet_frais: 1, plantain: 1, huile_rouge: 1 }, min: 50, meal: ['din'] },
  { id: 'wagashi', name: 'Wagashi frit et piment', plate: ['wagashi', 'sauce_pimentee'], need: { wagashi: 1, huile_arachide: 1, piment: 1 }, min: 20, meal: ['din'] },
  { id: 'bouillie', name: 'Koko (bouillie de mil) et akara', plate: ['koko', 'akara'], need: { farine_mil: 1, gingembre_racine: 1, haricots_secs: 1, huile_arachide: 1 }, min: 35, meal: ['pdj'] },
  { id: 'aklui', name: 'Aklui et atchomon', plate: ['aklui', 'atchomon'], need: { farine_mais: 1, sucre: 1, farine_ble: 1, huile_arachide: 1 }, min: 35, meal: ['pdj'] },
  { id: 'akassa_pdj', name: 'Akassa et akara du matin', plate: ['akassa', 'akara'], need: { farine_mais: 1, haricots_secs: 1, huile_arachide: 1 }, min: 30, meal: ['pdj'] },
  { id: 'bissap', name: 'Jus de bissap frais', plate: ['bissap'], need: { fleurs_bissap: 1, sucre: 1 }, min: 15, meal: ['pdj', 'dej', 'din'], drink: true },
  { id: 'gingembre', name: 'Jus de gingembre', plate: ['gingembre'], need: { gingembre_racine: 1, sucre: 1 }, min: 15, meal: ['pdj', 'dej', 'din'], drink: true },
  { id: 'baobab', name: 'Jus de baobab (toédji)', plate: ['baobab'], need: { pain_singe: 1, sucre: 1, lait_poudre: 1 }, min: 15, meal: ['pdj', 'dej', 'din'], drink: true },
];
const MEALS = { pdj: ['Petit-déjeuner', 7], dej: ['Déjeuner', 12.5], din: ['Dîner', 19.5] };

export class Cook {
  constructor(ctx) {
    Object.assign(this, ctx); // villa, kitchen, economy, env, needs, ui, audio, player, chauffeur, onSave
    this.hired = null; this.pantry = {}; this.queue = []; this.served = []; this.plan = { pdj: true, dej: true, din: true }; this.planned = {}; this.mem = { n: 0, fav: null }; this.payDay = null; this.view = 'menu'; this.c = null; this.t = 0; this.target = null;
    for (const id of PANTRY) this.pantry[id] = 3; // placards déjà garnis à l'arrivée
  }
  // ------------------------------------------------------------------ recrutement
  hire(id) {
    const C = CANDIDATES.find((q) => q.id === id); if (!C || this.hired) return;
    this.hired = { ...C, since: this.economy.stamp() }; this.payDay = this.economy.day + 7; this.spawn();
    this.ui.toast(`👩🏿‍🍳 ${C.name} rejoint la VILLA NOVA comme cuisinier${C.female ? 'e' : ''} personnel${C.female ? 'le' : ''} (${fcfa(C.salary)} par période de 7 jours).`, 3.5);
    this.onSave && this.onSave();
  }
  dismiss() { if (!this.hired) return; this.ui.toast(`${this.hired.name} quitte la villa. Merci pour son travail.`, 2.5); if (this.c) { this.c.group.parent && this.c.group.parent.remove(this.c.group); this.c = null; } this.hired = null; this.queue = []; this.onSave && this.onSave(); }
  title() { return this.hired ? (this.hired.female ? 'cuisinière' : 'cuisinier') : 'cuisinier'; }
  spawn() {
    if (this.c || !this.hired) return; const h = this.hired;
    this.c = createCharacter({ female: h.female, skin: h.skin, shirtColor: 0xf8f8f6, pants: 0x1a1a1a, skirt: false, headwrap: false, hat: 'toque', hatColor: 0xffffff, collar: true, shoes: 0x111111 });
    const apron = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.45, 0.02), new THREE.MeshStandardMaterial({ color: 0x0b6e4f })); apron.position.set(0, -0.12, 0.14); this.c.bones.spine.add(apron);
    this.villa.inGroup.add(this.c.group); const R = this.villa.rooms.cuisine; this.x = R.cx; this.z = R.cz - 1.4; this.h = 0; this.place();
    // vapeur de la marmite
    this.steam = new THREE.Group(); for (let i = 0; i < 6; i++) { const s = new THREE.Mesh(new THREE.SphereGeometry(0.12, 6, 5), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.35, depthWrite: false })); this.steam.add(s); } this.steam.position.set(R.cx, 1.0, R.cz); this.villa.inGroup.add(this.steam);
  }
  place() { this.c.group.position.set(this.x, 0, this.z); this.c.group.rotation.y = this.h; }
  spots() { const R = this.villa.rooms.cuisine; return [{ x: R.cx, z: R.cz - 1.25, h: 0, w: 'îlot' }, { x: R.x1 - 0.9, z: R.z0 + 2.4, h: 0, w: 'réfrigérateur' }, { x: R.x0 + 2.5, z: R.z1 - 1.6, h: 0, w: 'plan de travail' }, { x: R.x0 + 7, z: R.z1 - 1.6, h: 0, w: 'plaques de cuisson' }]; }
  // ------------------------------------------------------------------ stocks
  have(id) { return PANTRY.includes(id) ? this.pantry[id] || 0 : (this.kitchen.stock[id] || 0); }
  missing(d) { return Object.entries(d.need).filter(([id, n]) => this.have(id) < n).map(([id, n]) => [id, n - this.have(id)]); }
  consume(d) { for (const [id, n] of Object.entries(d.need)) { if (PANTRY.includes(id)) this.pantry[id] -= n; else this.kitchen.take(id, n); } }
  shopCost(list) { return list.reduce((a, [id, n]) => a + iprice(id) * n, 0); }
  shop(list, quiet) { // le cuisinier fait les courses (compte personnel, avec accord)
    const cost = this.shopCost(list); if (!cost) return true;
    if (!this.economy.pay(cost, `Courses du ${this.title()} — ${list.map(([id, n]) => `${n} ${iname(id)}`).join(', ')}`, 'VILLA NOVA')) { this.ui.toast('Solde personnel insuffisant pour les courses.', 2); return false; }
    for (const [id, n] of list) { if (PANTRY.includes(id)) this.pantry[id] = (this.pantry[id] || 0) + n; else this.kitchen.add(id, n); }
    if (!quiet) this.ui.toast(`🛒 ${this.hired.name.split(' ')[0]} a fait les courses (${fcfa(cost)}).`, 2.5); return true;
  }
  restock() { // réassort complet des placards et des produits frais courants
    const want = [...PANTRY.map((id) => [id, Math.max(0, 4 - (this.pantry[id] || 0))]), ...['tomate', 'oignon', 'piment', 'poisson_frais', 'poulet_frais', 'gombo', 'corete', 'igname', 'plantain', 'wagashi'].map((id) => [id, Math.max(0, 3 - (this.kitchen.stock[id] || 0))])].filter(([, n]) => n > 0);
    return want;
  }
  // ------------------------------------------------------------------ commandes
  order(dishId, opts = {}) {
    if (!this.hired) return this.ui.toast('Recrute d’abord un cuisinier (application « Mon cuisinier »).', 2.5);
    const d = DISHES.find((q) => q.id === dishId); if (!d) return;
    const miss = this.missing(d);
    if (miss.length && !opts.buy) { this.ask = { dishId, miss, cost: this.shopCost(miss), deliver: opts.deliver }; this.economy.phoneOpen && this.economy.renderPhone(); return this.ui.toast(`${this.hired.name.split(' ')[0]} : « Il me manque ${miss.map(([id]) => iname(id).toLowerCase()).join(', ')}. Je peux aller les acheter (${fcfa(this.shopCost(miss))}). »`, 4); }
    if (miss.length && !this.shop(miss)) return;
    this.consume(d); this.ask = null;
    const at = this.gameNow() + d.min / 60;
    this.queue.push({ id: d.id, name: d.name, plate: d.plate, at, deliver: !!opts.deliver, meal: opts.meal || null });
    if (!opts.quiet) this.ui.toast(`👩🏿‍🍳 ${this.hired.name.split(' ')[0]} : « ${pick(['Tout de suite !', 'Avec plaisir !', 'Bon choix !'])} ${d.name} sera prêt dans ${d.min} minutes. »`, 3);
    this.mem.n++; this.mem.last = d.name; this.onSave && this.onSave();
    return true;
  }
  gameNow() { return (this.economy.day || 1) * 24 + this.env.time; }
  ready(q) {
    if (q.deliver) { for (const id of q.plate) this.economy.addToBag(id, 1); this.economy.notify(`🚘 ${q.name} vous a été livré par le chauffeur (dans votre sac, téléphone › Mon sac).`); }
    else { this.served.push(q); if (this.served.length > 4) this.served.shift(); this.economy.notify(`🍽️ ${q.meal ? MEALS[q.meal][0] + ' : ' : ''}${q.name} est servi à la salle à manger de la villa.`); }
    if (this.audio && this.audio.ctx) this.audio.tone(880, 0.15, 0.05, 'sine');
  }
  eat() { // à la table familiale
    if (!this.served.length) return this.ui.toast(this.hired ? `Rien n’est servi pour le moment. Demande un plat à ${this.hired.name.split(' ')[0]} (cuisine ou téléphone).` : 'Rien n’est servi. Recrute un cuisinier pour des repas préparés.', 3);
    const q = this.served.shift(), n = this.needs; let h = 0; for (const id of q.plate) h += (FOOD_BY_ID[id] ? FOOD_BY_ID[id].hunger : 10);
    if (n) { n.hunger = Math.min(100, n.hunger + h); n.energy = Math.min(100, n.energy + 5); }
    this.villa.activity('Repas', 0.6, {}, `Délicieux : ${q.name}. Faim +${h}.`); this.onSave && this.onSave();
  }
  // ------------------------------------------------------------------ boucle
  update(dt) {
    if (!this.hired) return;
    const now = this.gameNow();
    for (let i = this.queue.length - 1; i >= 0; i--) if (now >= this.queue[i].at) this.ready(this.queue.splice(i, 1)[0]);
    // repas planifiés : préparés automatiquement 1 h avant l'heure du repas (si les ingrédients sont là)
    const day = this.economy.day, h = this.env.time;
    for (const [k, [label, at]] of Object.entries(MEALS)) {
      if (!this.plan[k] || this.planned[k] === day || h < at - 1 || h > at + 1) continue;
      this.planned[k] = day; const menu = this.menuOf(k), d = menu.find((q) => !this.missing(q).length);
      if (d) this.order(d.id, { meal: k, quiet: true }); else this.economy.notify(`👩🏿‍🍳 ${this.hired.name.split(' ')[0]} : il manque des ingrédients pour le ${label.toLowerCase()}. Autorise les courses dans l’application.`);
    }
    // salaire tous les 7 jours de jeu (compte personnel)
    if (this.payDay !== null && day >= this.payDay) { this.payDay = day + 7; if (this.economy.pay(this.hired.salary, `Salaire — ${this.hired.name} (${this.title()}, VILLA NOVA)`, 'Personnel de maison')) this.economy.notify(`💸 Salaire versé à ${this.hired.name} : ${fcfa(this.hired.salary)}.`); else this.economy.notify(`⚠️ Solde insuffisant pour le salaire de ${this.hired.name}.`); }
    // déplacements dans la cuisine (seulement quand le joueur est dans l'aile)
    if (!this.villa.inside) return; this.spawn(); if (!this.c) return;
    const work = h >= 6 && h < 22, busy = this.queue.length > 0; this.c.group.visible = work; this.steam.visible = busy && work;
    if (!work) return;
    this.t -= dt; if (!this.target || this.t <= 0) { const S = this.spots(); this.target = busy ? pick([S[0], S[3], S[3], S[1]]) : pick(S); this.t = 5 + Math.random() * 6; }
    const dx = this.target.x - this.x, dz = this.target.z - this.z, d = Math.hypot(dx, dz), sp = d > 0.1 ? Math.min(1.3, d * 2) : 0;
    if (d > 0.1) { this.x += dx / d * sp * dt; this.z += dz / d * sp * dt; this.h = Math.atan2(dx, dz); } else this.h = this.target.h;
    this.place(); this.c.animate(dt, sp);
    if (sp < 0.1 && busy) { const b = this.c.bones, k = Math.sin(performance.now() / 180); b.armR.rotation.x = -0.9 + k * 0.3; b.foreR.rotation.x = -1.0; b.armL.rotation.x = -0.6; b.foreL.rotation.x = -0.9; }
    if (this.steam.visible) this.steam.children.forEach((s, i) => { const p = ((performance.now() / 1500) + i / 6) % 1; s.position.set(Math.sin(i * 2 + p * 3) * 0.15, p * 1.4, Math.cos(i) * 0.1); s.material.opacity = 0.35 * (1 - p); s.scale.setScalar(0.6 + p); });
  }
  menuOf(k) { const list = DISHES.filter((d) => d.meal.includes(k) && !d.drink), day = this.economy.day || 1; return list.map((_, i) => list[(i + day * 3) % list.length]); }
  // ------------------------------------------------------------------ interactions dans la cuisine
  nearest(x, z) {
    if (!this.villa.inside || !this.c || !this.c.group.visible) return null;
    const { O } = VILLA, d = Math.hypot(x - (O.x + this.x), z - (O.z + this.z));
    return d < 1.8 ? { d, it: { label: () => `Parler à ${this.hired.name} (${this.title()})`, action: () => this.menu() } } : null;
  }
  menu() {
    const items = [{ label: '📋 Quel est le menu du jour ?', action: () => this.ui.toast(`${this.hired.name.split(' ')[0]} : « ${this.menuText()} »`, 5) }];
    for (const d of this.menuOf(this.mealNow()).slice(0, 4)) items.push({ label: `🍲 ${d.name}${this.missing(d).length ? ' (courses nécessaires)' : ''}`, action: () => this.order(d.id, { buy: true }) });
    items.push({ label: '🥤 Un jus de bissap', action: () => this.order('bissap', { buy: true }) }, { label: '📱 Toute la carte et les réserves (téléphone)', action: () => { this.economy.togglePhone(true); this.economy.app = 'chef'; this.economy.renderPhone(); } });
    this.ui.openMenu(`👩🏿‍🍳 ${this.hired.name}`, `${this.hired.spec} • ${this.queue.length ? `en préparation : ${this.queue.map((q) => q.name).join(', ')}` : 'disponible'}`, items);
  }
  mealNow() { const h = this.env.time; return h < 10.5 ? 'pdj' : h < 16 ? 'dej' : 'din'; }
  menuText() { const k = this.mealNow(); return `Pour le ${MEALS[k][0].toLowerCase()}, je vous propose : ${this.menuOf(k).slice(0, 3).map((d) => d.name.toLowerCase()).join(', ou ')}. Et un jus de bissap bien frais ?`; }
  // ------------------------------------------------------------------ conversation libre (téléphone)
  contact() { return this.hired ? { key: 'dom:chef', kind: 'dom', name: this.hired.name, role: `${this.title().charAt(0).toUpperCase() + this.title().slice(1)} personnel${this.hired.female ? 'le' : ''} • VILLA NOVA`, icon: '👩🏿‍🍳' } : null; }
  reply(txt) {
    const t = norm(txt), H = this.hired; if (!H) return '…';
    const STOP = new Set(['et', 'au', 'aux', 'de', 'du', 'la', 'le', 'les', 'des', 'un', 'une', 'jus', 'sauce', 'frais']);
    let want = null, best = 0; // plat dont le plus de mots apparaissent dans le message
    for (const d of DISHES) { const words = norm(d.name).replace(/[^a-z ]/g, ' ').split(' ').filter((w) => w.length > 2 && !STOP.has(w)); const sc = words.filter((w) => t.includes(w)).length + (words[0] && t.includes(words[0]) ? 0.5 : 0); if (sc > best) { best = sc; want = d; } }
    if (/jus/.test(t)) { const j = DISHES.find((d) => d.drink && t.includes(d.id)); if (j) want = j; }
    if (want && /(prepare|fais|veux|voudrais|commande|cuisine|envie)/.test(t)) { const deliver = /(livre|apporte|bureau|ou je suis)/.test(t); const ok = this.order(want.id, { buy: true, deliver }); return ok ? `Entendu ! ${want.name} ${deliver ? 'sera livré par le chauffeur' : 'sera servi à la salle à manger'} dans ${want.min} minutes.` : 'Je n’ai pas pu faire les courses, le solde est insuffisant.'; }
    if (/(menu|qu est.ce qu on mange|propose|aujourd hui)/.test(t)) return this.menuText();
    if (/(frigo|reste|reserve|placard|stock)/.test(t)) { const low = PANTRY.filter((id) => (this.pantry[id] || 0) < 2).map(iname); return low.length ? `Il commence à manquer : ${low.slice(0, 5).join(', ')}. Je peux faire les courses si vous m’y autorisez.` : 'Les placards sont bien garnis, ne vous inquiétez pas.'; }
    if (/(courses|acheter|marche)/.test(t)) { const w = this.restock(); return w.length ? `Pour tout réapprovisionner, il faut environ ${fcfa(this.shopCost(w))}. Validez dans l’application « Mon cuisinier ».` : 'Tout est déjà en stock !'; }
    if (/(bonjour|bonsoir|salut)/.test(t)) return `${this.env.time < 12 ? 'Bonjour' : 'Bonsoir'} Monsieur le PDG ! ${pick(['Le repas sera délicieux aujourd’hui.', 'La cuisine sent bon le soumbala !', 'Je vous ai préparé un bon jus.'])}`;
    if (/(merci|bravo|delicieux|excellent|bon repas)/.test(t)) return pick(['Ça me fait tellement plaisir ! Ma grand-mère serait fière.', 'Merci Monsieur le PDG, c’est avec amour que je cuisine.']);
    if (/(famille|enfant|d ou viens|originaire)/.test(t)) return `Je suis de ${H.origin}. J’ai appris à cuisiner très jeune, j’ai ${H.years} ans de métier.`;
    if (/(secret|astuce|recette)/.test(t)) return 'Mon secret ? Une bonne huile rouge, du piment frais et beaucoup de patience pour la sauce.';
    if (/(ca va|comment vas)/.test(t)) return 'Très bien merci, la cuisine est prête et les marmites aussi !';
    return pick(['Bien noté, Monsieur le PDG.', 'D’accord, je m’en occupe.', 'Avec plaisir.']);
  }
  // ------------------------------------------------------------------ application « Mon cuisinier »
  renderApp(b) {
    if (!this.hired) {
      b.innerHTML = `<h4>👩🏿‍🍳 Mon cuisinier</h4><p class="ph-note">Recrute un cuisinier permanent pour la VILLA NOVA (personnages fictifs). Salaire prélevé sur le compte personnel tous les 7 jours de jeu.</p><div class="ph-list">${CANDIDATES.map((c) => `<div class="ph-row"><span><b>${esc(c.name)}, ${c.age} ans</b><small>${esc(c.spec)} • ${c.years} ans d’expérience • originaire de ${c.origin} • ${esc(c.trait)}</small></span><span class="pp-acts"><em>${fcfa(c.salary)}</em><button class="ph-mini" data-ck="hire:${c.id}">Recruter</button></span></div>`).join('')}</div>`;
      return;
    }
    const H = this.hired, tabs = [['menu', 'Carte'], ['plan', 'Repas planifiés'], ['stock', 'Réserves'], ['info', H.name.split(' ')[0]]];
    let body = '';
    if (this.view === 'menu') body = `${this.ask ? `<div class="ph-row"><span><b>Courses nécessaires : ${this.ask.miss.map(([id, n]) => `${n} ${esc(iname(id))}`).join(', ')}</b><small>${fcfa(this.ask.cost)} sur le compte personnel</small></span><span class="pp-acts"><button class="ph-mini" data-ck="buy">✅ Autoriser</button><button class="ph-mini" data-ck="nobuy">Annuler</button></span></div>` : ''}
      ${this.queue.length ? `<p class="ph-note">En préparation : ${this.queue.map((q) => `${esc(q.name)} (${Math.max(0, Math.round((q.at - this.gameNow()) * 60))} min)`).join(' • ')}</p>` : ''}${this.served.length ? `<p class="ph-note">Servi à la salle à manger : ${this.served.map((q) => esc(q.name)).join(', ')}</p>` : ''}
      ${['pdj', 'dej', 'din'].map((k) => `<h5>${MEALS[k][0]}</h5><div class="ph-list">${DISHES.filter((d) => d.meal.includes(k) && !d.drink).map((d) => this.dishRow(d)).join('')}</div>`).join('')}<h5>Jus naturels</h5><div class="ph-list">${DISHES.filter((d) => d.drink).map((d) => this.dishRow(d)).join('')}</div>`;
    else if (this.view === 'plan') body = `<p class="ph-note">Le ${this.title()} prépare automatiquement chaque repas activé (1 h avant), avec les ingrédients disponibles.</p>${Object.entries(MEALS).map(([k, [l, at]]) => `<div class="ph-row"><span><b>${l} — ${Math.floor(at)} h ${at % 1 ? '30' : ''}</b><small>Menu du jour : ${esc(this.menuOf(k)[0].name)}</small></span><button class="ph-mini ${this.plan[k] ? 'on' : ''}" data-ck="plan:${k}">${this.plan[k] ? 'Activé' : 'Désactivé'}</button></div>`).join('')}`;
    else if (this.view === 'stock') { const w = this.restock(); body = `<h5>Placards (épicerie sèche)</h5><div class="ph-list">${PANTRY.map((id) => `<div class="ph-row"><span><b>${esc(iname(id))}</b></span><em>${this.pantry[id] || 0}</em></div>`).join('')}</div><h5>Réfrigérateur</h5><p class="ph-note">${Object.entries(this.kitchen.stock).filter(([id]) => FOOD_BY_ID[id] && FOOD_BY_ID[id].kind === 'ingredient' || ['wagashi'].includes(id)).map(([id, n]) => `${esc(iname(id))} × ${n}`).join(' • ') || 'Aucun ingrédient frais.'}</p>${w.length ? `<button class="ph-go" data-ck="restock">🛒 Faire les courses complètes (${fcfa(this.shopCost(w))})</button>` : '<p class="ph-note">Tout est en stock.</p>'}`; }
    else body = `<div class="ph-row"><span><b>${esc(H.name)}, ${H.age} ans</b><small>${esc(H.spec)} • originaire de ${H.origin} • ${H.years} ans d’expérience • ${esc(H.trait)} • depuis ${H.since}</small></span></div><p class="ph-note">Salaire : ${fcfa(H.salary)} tous les 7 jours (prochain versement J${this.payDay}). Horaires : 6 h – 22 h, dans la cuisine de l’aile principale. Conversation : Contacts › Maison.</p><button class="ph-mini" data-ck="fire">Mettre fin au contrat</button>`;
    b.innerHTML = `<h4>👩🏿‍🍳 ${esc(H.name)}</h4><div class="ph-chips">${tabs.map(([k, l]) => `<button data-ck="tab:${k}" class="${this.view === k ? 'on' : ''}">${l}</button>`).join('')}</div>${body}`;
  }
  dishRow(d) { const m = this.missing(d); return `<div class="ph-row"><span><b>${esc(d.name)}</b><small>${d.min} min • ${m.length ? `courses : ${m.map(([id]) => esc(iname(id))).join(', ')} (${fcfa(this.shopCost(m))})` : 'ingrédients disponibles'}</small></span><span class="pp-acts"><button class="ph-mini" data-ck="ord:${d.id}">Commander</button><button class="ph-mini" data-ck="dlv:${d.id}">🚘 Livrer</button></span></div>`; }
  onPhone(v) {
    const [a, id] = v.split(':');
    if (a === 'hire') this.hire(id); else if (a === 'fire') this.dismiss();
    else if (a === 'tab') this.view = id;
    else if (a === 'ord') this.order(id); else if (a === 'dlv') this.order(id, { deliver: true });
    else if (a === 'buy' && this.ask) this.order(this.ask.dishId, { buy: true, deliver: this.ask.deliver });
    else if (a === 'nobuy') this.ask = null;
    else if (a === 'plan') this.plan[id] = !this.plan[id];
    else if (a === 'restock') this.shop(this.restock());
    this.onSave && this.onSave(); if (this.economy.phoneOpen) this.economy.renderPhone();
  }
  serialize() { return { hired: this.hired, pantry: this.pantry, queue: this.queue, served: this.served, plan: this.plan, planned: this.planned, mem: this.mem, payDay: this.payDay }; }
  restore(s) { if (!s) return; Object.assign(this, { hired: s.hired || null, pantry: { ...this.pantry, ...(s.pantry || {}) }, queue: s.queue || [], served: s.served || [], plan: s.plan || this.plan, planned: s.planned || {}, mem: s.mem || this.mem, payDay: s.payDay ?? null }); }
}
