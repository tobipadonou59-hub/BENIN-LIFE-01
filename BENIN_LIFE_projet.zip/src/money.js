// Mission 025 — monnaie de grande capacité : les soldes personnels (compte NOVA PRIVATE BANK, carte VIP, espèces) sont des
// ENTIERS BigInt (aucun arrondi, même au-delà de 9 007 199 254 740 991 FCFA, limite des nombres JavaScript ordinaires).
// Échelle française : 1 milliard (Md) = 10^9 FCFA ; 1 billion = 10^12 FCFA. Monnaie fictive du jeu, sans valeur réelle.
export const MD = 10n ** 9n;
export const BILLION = 10n ** 12n;
export const B = (v) => { if (typeof v === 'bigint') return v; const n = Number(v); return Number.isFinite(n) ? BigInt(Math.round(n)) : 0n; };
export const groupDigits = (s) => s.replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
// montant exact avec séparateurs de milliers : « 100 000 000 000 000 000 FCFA »
export const fcfaBig = (v) => { const n = B(v), neg = n < 0n; return `${neg ? '−' : ''}${groupDigits((neg ? -n : n).toString())} FCFA`; };
const dec = (n, unit) => { const whole = n / unit, frac = ((n % unit) * 100n) / unit; return `${groupDigits(whole.toString())}${frac ? `,${frac.toString().padStart(2, '0').replace(/0$/, '')}` : ''}`; };
// affichage abrégé : « 100 000 billions FCFA », « 10 000 Md FCFA », « 25,5 M FCFA »
export const abbr = (v) => {
  let n = B(v); const neg = n < 0n; if (neg) n = -n; const s = neg ? '−' : '';
  if (n >= 1000n * BILLION) return `${s}${dec(n, BILLION)} billion${n >= 2n * BILLION ? 's' : ''} FCFA`;
  if (n >= MD) return `${s}${dec(n, MD)} Md FCFA`;
  if (n >= 1000000n) return `${s}${dec(n, 1000000n)} M FCFA`;
  return `${s}${groupDigits(n.toString())} FCFA`;
};
// saisie : chiffres uniquement (les espaces sont ignorés) ; renvoie 0n si invalide
export const parseAmount = (str) => { const d = String(str || '').replace(/[\s  ._]/g, ''); return /^\d{1,24}$/.test(d) ? BigInt(d) : 0n; };
