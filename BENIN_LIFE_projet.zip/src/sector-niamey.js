// Mission 023, phase 2 — NIAMEY (Niger), huitième secteur pays explorable, à sa position géographique réelle dans le
// repère du jeu (projection de la région du Bénin, échelle 1:5). Ville sahélienne au bord du fleuve Niger : la ville
// principale sur la rive gauche (nord), Harobanda et l'université sur la rive droite (sud), reliées par le pont Kennedy.
// Plan STYLISÉ, positions approximatives (le fleuve est redressé d'ouest en est ; l'aéroport Diori-Hamani est DÉPLACÉ au
// nord-est dans le jeu, en réalité au sud-est). Maisons en banco (terre crue) aux gargouilles de bois. Commerces, hôtel,
// restaurants au nom inventé : FICTIFS.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { colorize } from './vehicles.js';
import { toWorld } from './africa-data.js';

const PI = Math.PI;
const O = toWorld(13.51, 2.11); // origine : le centre-ville (rive gauche)
export const NIAMEY = { id: 'niamey', country: '562', name: 'Niamey', O, X0: -1500, X1: 1500, Z0: -1300, Z1: 1000, R0: 200, R1: 420 };
const BR = [[-9, 195, 9, 425]]; // pont Kennedy
const onBridge = (x, z) => BR.some(([a, b, c, d]) => x > a && x < c && z > b && z < d);
const wet = (x, z) => z > NIAMEY.R0 && z < NIAMEY.R1;
const isWet = (x, z) => wet(x, z) && !onBridge(x, z);
NIAMEY.has = (x, z) => x > O.x + NIAMEY.X0 - 40 && x < O.x + NIAMEY.X1 + 40 && z > O.z + NIAMEY.Z0 - 40 && z < O.z + NIAMEY.Z1 + 40;
NIAMEY.near = (x, z) => Math.abs(x - O.x) < 4200 && Math.abs(z - O.z + 150) < 4000;
NIAMEY.water = (x, z) => isWet(x - O.x, z - O.z);
NIAMEY.coastAt = () => NIAMEY.R0;
NIAMEY.clamp = (obj) => {
  const p = obj.pos; let lx = Math.max(NIAMEY.X0 + 2, Math.min(NIAMEY.X1 - 2, p.x - O.x)), lz = Math.max(NIAMEY.Z0 + 2, Math.min(NIAMEY.Z1 - 2, p.z - O.z));
  if (isWet(lx, lz)) { if (obj._dry) { lx = obj._dry.x - O.x; lz = obj._dry.z - O.z; if (obj.speed) obj.speed *= -0.2; } }
  p.x = O.x + lx; p.z = O.z + lz; if (!obj._dry) obj._dry = { x: 0, z: 0 }; if (!isWet(lx, lz)) { obj._dry.x = p.x; obj._dry.z = p.z; }
};
// voies : [x0, z0, x1, z1, largeur, nom]
const ROADS = [
  [-1500, -1000, 1500, -1000, 12, ''], [-1500, -700, 1500, -700, 12, ''], [-1500, -400, 1500, -400, 12, ''], [-1500, -100, 1500, -100, 14, ''], [-1500, 170, 1500, 170, 10, 'Corniche du fleuve (stylisée)'],
  [-1200, -1300, -1200, 170, 10, ''], [-900, -1300, -900, 170, 10, ''], [-600, -1300, -600, 170, 10, ''], [-300, -1300, -300, 170, 12, ''], [0, -1300, 0, 1000, 14, 'Pont Kennedy'], [300, -1300, 300, 170, 12, ''], [600, -1300, 600, 170, 10, ''], [900, -1000, 900, 170, 10, ''], [1200, -1000, 1200, 170, 10, ''],
  [-1500, 500, 1500, 500, 10, ''], [-1500, 700, 1500, 700, 14, 'Route de Torodi (vers le Burkina Faso)'], [-1500, 900, 1500, 900, 10, ''],
  [-900, 425, -900, 1000, 10, ''], [-600, 425, -600, 1000, 10, ''], [-300, 425, -300, 1000, 10, ''], [300, 425, 300, 1000, 10, ''], [600, 425, 600, 1000, 10, ''], [900, 425, 900, 1000, 10, ''],
];
const P = {
  musee: { x: -450, z: 45 }, fleuve: { x: -150, z: 188 }, pont: { x: 16, z: 180 }, mosquee: { x: 450, z: -850 }, grandmarche: { x: 150, z: -560 }, petitmarche: { x: -150, z: -250 },
  stade: { x: -750, z: -850 }, hotel: { x: 450, z: 110 }, mall: { x: 750, z: -550 }, hopital: { x: -1050, z: -250 }, ecole: { x: -1050, z: -550 }, gare: { x: -1050, z: -850 },
  universite: { x: -450, z: 805 }, aeroport: { x: 1050, z: -1065 }, ouest: { x: -1490, z: 700 },
};
const TAXIS = [[-400, -70, 'Musée national'], [-110, 158, 'Bord du fleuve'], [500, -712, 'Grande Mosquée'], [190, -460, 'Grand Marché'], [-110, -110, 'Petit Marché'], [-700, -712, 'Stade'], [500, 62, 'Hôtel'], [-400, 712, 'Université'], [1100, -1025, 'Aéroport'], [-1050, -756, 'Gare routière'], [-1430, 712, 'Route du Burkina']];
const QUARTIERS = [['Centre (Grand Marché)', 100, -450], ['Plateau', 300, -200], ['Musée national', -450, 40], ['Bord du fleuve', 0, 160], ['Yantala', -900, -500], ['Lacouroussou', -300, -700], ['Banifandou', 600, -800], ['Recasement', -900, -1000], ['Koira Kano', 900, -600], ['Aéroport (déplacé)', 1050, -1150], ['Harobanda (rive droite)', 300, 600], ['Université (rive droite)', -450, 800], ['Gaweye', -900, 650], ['Route de Torodi', -1300, 700]];
const SHOPS = ['TÉLÉCENTRE • TRANSFERT', 'PHARMACIE DU FLEUVE', 'COUTURE HADIZA', 'QUINCAILLERIE ISSOUFOU', 'BIJOUTERIE TOUARÈGUE', 'BOUTIQUE DU SAHEL', 'MAROQUINERIE', 'BOULANGERIE DU NIGER', 'LIBRAIRIE DU PLATEAU', 'KILICHI', 'ÉLECTRO SERVICE', 'TISSUS ET PAGNES'];
const NAMES = { f: ['Aïchatou', 'Hadiza', 'Mariama', 'Rakia', 'Zeinabou', 'Fati', 'Habsatou', 'Salamatou', 'Ramatou', 'Balkissa'], m: ['Issoufou', 'Moussa', 'Abdoulaye', 'Hamidou', 'Boubacar', 'Seyni', 'Moumouni', 'Ibrahim', 'Souley', 'Amadou'] };

export function buildNiamey(ctx) {
  const { scene, world, quality } = ctx, C = world.collision, g = new THREE.Group(); g.position.set(O.x, 0, O.z); scene.add(g);
  const parts = [], glass = [], heads = [], signs = {}, cols = [], points = [], lanes = [], lamps = [];
  const box = (x0, y0, z0, x1, y1, z1, c, arr = parts) => arr.push(colorize(new THREE.BoxGeometry(Math.abs(x1 - x0) || 0.01, Math.abs(y1 - y0) || 0.01, Math.abs(z1 - z0) || 0.01).translate((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), c));
  const solid = (x0, z0, x1, z1, h) => { const o = C.addBox(O.x + Math.min(x0, x1), O.z + Math.min(z0, z1), O.x + Math.max(x0, x1), O.z + Math.max(z0, z1), h); cols.push(o); return o; };
  const circle = (x, z, r, h) => { const o = C.addCircle(O.x + x, O.z + z, r, h); cols.push(o); return o; };
  const Pt = (x, z, r, label, action) => points.push({ x, z, r, label, action });
  const R = (() => { let a = 1351; return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; })();
  const reserved = [], reserve = (x0, z0, x1, z1) => reserved.push({ x0, z0, x1, z1 }), isRes = (x0, z0, x1, z1) => reserved.some((r) => x1 > r.x0 && x0 < r.x1 && z1 > r.z0 && z0 < r.z1);
  // ---- sol sableux, fleuve Niger, berges, bancs de sable, jardins maraîchers ----
  // le sol ne passe pas sous le fleuve (pas de surfaces superposées : précision d'affichage loin de l'origine du monde)
  box(NIAMEY.X0 - 400, -0.12, NIAMEY.Z0 - 400, NIAMEY.X1 + 400, -0.02, NIAMEY.R0 - 12, 0xc8a878); box(NIAMEY.X0 - 400, -0.12, NIAMEY.R1 + 12, NIAMEY.X1 + 400, -0.02, NIAMEY.Z1 + 400, 0xc8a878);
  box(NIAMEY.X0 - 400, -0.12, NIAMEY.R0, NIAMEY.X1 + 400, 0.03, NIAMEY.R1, 0x4a7a7a); box(NIAMEY.X0 - 400, -0.12, NIAMEY.R0 - 12, NIAMEY.X1 + 400, 0.02, NIAMEY.R0, 0xd8c8a0); box(NIAMEY.X0 - 400, -0.12, NIAMEY.R1, NIAMEY.X1 + 400, 0.02, NIAMEY.R1 + 12, 0xd8c8a0);
  for (const [x, z, rx, rz] of [[-800, 300, 120, 22], [500, 330, 90, 18], [1100, 270, 140, 25]]) parts.push(colorize(new THREE.CylinderGeometry(1, 1, 0.06, 24).scale(rx, 1, rz).translate(x, 0.04, z), 0xe0d0a8));
  for (let x = -1480; x < 1480; x += 60) { if ([-900, -600, -300, 0, 300, 600, 900].some((rx) => x < rx + 8 && x + 40 > rx - 8)) continue; box(x, 0.02, NIAMEY.R1 + 14, x + 40, 0.12, NIAMEY.R1 + 60, [0x5a8a3a, 0x6a9a3a, 0x4a7a32][((x + 1480) / 60) % 3]); }
  for (const [a, b, c2, d] of BR) { box(a, 0.55, b, c2, 0.85, d, 0xb8b4ac); box(a, 0.85, b, a + 0.4, 1.8, d, 0xd8d4cc); box(c2 - 0.4, 0.85, b, c2, 1.8, d, 0xd8d4cc); for (let z = b + 15; z < d - 10; z += 30) { box(a + 2, -0.3, z - 1.4, c2 - 2, 0.55, z + 1.4, 0x9a9690); for (const xx of [a + 0.2, c2 - 0.2]) box(xx - 0.12, 0.85, z - 0.12, xx + 0.12, 6, z + 0.12, 0x6a6e74); } }
  // ---- routes ----
  const roadSeg = ([x0, z0, x1, z1, w]) => { if (x0 === x1) box(x0 - w / 2, 0.02, Math.min(z0, z1), x0 + w / 2, 0.05, Math.max(z0, z1), 0x3a3c40); else box(Math.min(x0, x1), 0.02, z0 - w / 2, Math.max(x0, x1), 0.05, z0 + w / 2, 0x3a3c40); };
  for (const r of ROADS) { const [x0, z0, x1, z1] = r; roadSeg(r); if (x0 === x1) box(x0 - 0.08, 0.05, Math.min(z0, z1), x0 + 0.08, 0.06, Math.max(z0, z1), 0xf2f2f2); else box(x0, 0.05, z0 - 0.08, x1, 0.06, z0 + 0.08, 0xf2f2f2); }
  const roadAt = (x, z, m) => ROADS.some(([x0, z0, x1, z1, w]) => (x0 === x1 ? Math.abs(x - x0) < w / 2 + m && z > Math.min(z0, z1) - m && z < Math.max(z0, z1) + m : Math.abs(z - z0) < w / 2 + m && x > Math.min(x0, x1) - m && x < Math.max(x0, x1) + m));
  // ---- réservations (avant les immeubles) ----
  for (const [x, z] of TAXIS) reserve(x - 4, z - 4, x + 4, z + 4);
  reserve(-585, -72, -315, 160); reserve(-240, 176, -60, 200); reserve(320, -985, 580, -705); reserve(25, -685, 275, -412); reserve(-285, -385, -15, -106); reserve(-885, -985, -615, -705); reserve(400, 55, 500, 160);
  reserve(665, -615, 835, -485); reserve(-1112, -300, -988, -200); reserve(-1085, -585, -1015, -515); reserve(-1155, -935, -945, -748); reserve(-590, 706, -310, 895); reserve(640, -1300, 1500, -1006); reserve(-1500, 680, -1380, 720);
  for (const [rx, rz] of [[-750, -250], [750, -250]]) reserve(rx - 17, rz - 12, rx + 17, rz + 13);
  for (const [sx, sz] of [[-450, -550], [1050, -550]]) reserve(sx - 23, sz - 21, sx + 23, sz + 21);
  // ---- immeubles (identité nigérienne : maisons en banco à toit-terrasse et gargouilles, murs de cour, façades haoussa à motifs, quelques immeubles du Plateau) ----
  const FAC = [0xc8a070, 0xd8b080, 0xb8906a, 0xe0c8a0, 0xd0a878, 0xc89868, 0xe8d4b0, 0xb88a60], TRIM = [0xe05206, 0x0db02b, 0xf2f2ee, 0x7a4a2a], ROOF = [0xb8906a, 0x8a8f96, 0xa87850];
  const district = (x, z) => (z > NIAMEY.R1 ? 'rivedroite' : Math.abs(x - 150) < 450 && z > -750 ? 'centre' : 'quartier');
  const building = (x, z, w, d, ry, kind) => {
    const fac = FAC[(R() * FAC.length) | 0], trim = TRIM[(R() * TRIM.length) | 0], floors = kind === 'tour' ? 4 + ((R() * 5) | 0) : kind === 'centre' ? 2 + ((R() * 2) | 0) : kind === 'villa' ? 2 : kind === 'maison' ? 1 : 1 + ((R() * 2) | 0), h = floors * 3.2;
    const m = new THREE.Matrix4().makeRotationY(ry).setPosition(x, 0, z), add = (geo, c, arr = parts) => arr.push(colorize(geo.applyMatrix4(m), c));
    if (kind === 'tour') { add(new THREE.BoxGeometry(w, h, d).translate(0, h / 2, 0), [0x8a9aa8, 0xd8c8a8, 0x7a8a98][(R() * 3) | 0], glass); for (let f = 2; f < floors; f += 2) add(new THREE.BoxGeometry(w + 0.15, 0.4, d + 0.15).translate(0, f * 3.2, 0), 0xe8dcc8); add(new THREE.BoxGeometry(w + 0.4, 3, d + 0.4).translate(0, 1.5, 0), 0xd8c8a8); }
    else if (kind === 'villa') { const W2 = w / 2, D2 = d / 2; for (const [a, b, c2, e] of [[-W2, -D2, W2, -D2 + 0.3], [-W2, -D2, -W2 + 0.3, D2], [W2 - 0.3, -D2, W2, D2], [-W2, D2 - 0.3, -1.6, D2], [1.6, D2 - 0.3, W2, D2]]) add(new THREE.BoxGeometry(c2 - a, 2.6, e - b).translate((a + c2) / 2, 1.3, (b + e) / 2), fac); add(new THREE.BoxGeometry(3.2, 2.4, 0.1).translate(0, 1.2, D2 - 0.15), 0x5a3a22); add(new THREE.BoxGeometry(w * 0.6, 6.4, d * 0.46).translate(0, 3.2, -D2 * 0.4), 0xe8d4b0); add(new THREE.BoxGeometry(w * 0.64, 0.7, d * 0.5).translate(0, 6.75, -D2 * 0.4), 0xe8d4b0); }
    else { add(new THREE.BoxGeometry(w, h, d).translate(0, h / 2, 0), fac); add(new THREE.BoxGeometry(w + 0.2, 0.8, d + 0.2).translate(0, h + 0.4, 0), ROOF[(R() * 3) | 0]);
      for (let k = -1; k <= 1; k += 2) add(new THREE.BoxGeometry(0.25, 0.25, 1.4).translate(k * w * 0.35, h - 0.2, d / 2 + 0.7), 0x6a4a2a); // gargouilles en bois
      if (kind === 'maison' && R() < 0.5) for (let k = -2; k <= 2; k++) add(new THREE.ConeGeometry(0.45, 1.4, 4).translate(k * w * 0.2, h + 1.5, d / 2 - 0.2), fac); // créneaux décoratifs
      for (let f = 0; f < floors; f++) for (let k = -1; k <= 1; k++) add(new THREE.BoxGeometry(w * 0.14, 1.2, 0.06).translate(k * w * 0.3, 1.8 + f * 3.2, d / 2 + 0.03), 0x3a2a22);
      if (kind !== 'maison') add(new THREE.BoxGeometry(w * 0.7, 0.12, 0.12).translate(0, h - 0.8, d / 2 + 0.06), trim);
      if (kind === 'centre' || (kind !== 'maison' && R() < 0.4)) { add(new THREE.BoxGeometry(w * 0.92, 0.14, 1.8).translate(0, 2.9, d / 2 + 0.9), TRIM[(R() * 4) | 0]); const t = SHOPS[(R() * SHOPS.length) | 0]; (signs[t] || (signs[t] = [])).push(new THREE.PlaneGeometry(Math.min(w * 0.85, 6.5), 0.75).translate(0, 3.5, d / 2 + 0.05).applyMatrix4(m)); } }
    const sw = Math.abs(Math.sin(ry)) > 0.5, hw = (sw ? d : w) / 2, hd = (sw ? w : d) / 2; cols.push(C.addBox(O.x + x - hw, O.z + z - hd, O.x + x + hw, O.z + z + hd, kind === 'villa' ? 7 : h + 2));
  };
  const kindAt = (x, z) => { const D = district(x, z); if (D === 'centre') return R() < 0.2 ? 'tour' : R() < 0.7 ? 'centre' : 'immeuble'; if (D === 'rivedroite') return R() < 0.7 ? 'maison' : 'villa'; return R() < 0.6 ? 'maison' : R() < 0.8 ? 'immeuble' : 'villa'; };
  const dens = (quality === 'low' ? 0.5 : quality === 'high' ? 0.9 : 0.75);
  const place = (x, z, w, d, rr) => { const sw = Math.abs(Math.sin(rr)) > 0.5, hw = (sw ? d : w) / 2 + 1, hd = (sw ? w : d) / 2 + 1, k = district(x, z) === 'centre' ? 1 : 0.62;
    if (R() > dens * k || isRes(x - hw, z - hd, x + hw, z + hd) || roadAt(x, z, Math.max(hw, hd)) || [[0, 0], [-hw, -hd], [hw, hd], [-hw, hd], [hw, -hd]].some(([a, b]) => wet(x + a, z + b * 3))) return; building(x, z, w, d, rr, kindAt(x, z)); reserve(x - hw, z - hd, x + hw, z + hd); };
  const blocks = (xs, zs, stp) => { for (let i = 0; i < xs.length - 1; i++) for (let j = 0; j < zs.length - 1; j++) { const bx0 = xs[i] + 8, bx1 = xs[i + 1] - 8, bz0 = zs[j] + 8, bz1 = zs[j + 1] - 8; if (bx1 - bx0 < 20 || bz1 - bz0 < 20) continue;
    for (let x = bx0 + 8; x < bx1 - 6; x += stp) { const w = 10 + R() * 5, d = 10 + R() * 5; place(x, bz1 - d / 2 - 1, w, d, 0); place(x, bz0 + d / 2 + 1, w, d, PI); }
    for (let z = bz0 + 22; z < bz1 - 20; z += stp) { const w = 10 + R() * 5, d = 10 + R() * 5; place(bx0 + d / 2 + 1, z, w, d, -PI / 2); place(bx1 - d / 2 - 1, z, w, d, PI / 2); } } };
  blocks([-1500, -1200, -900, -600, -300, 0, 300, 600, 900, 1200, 1500], [-1300, -1000, -700, -400, -100, 170], 18);
  blocks([-1500, -900, -600, -300, 0, 300, 600, 900, 1500], [480, 500, 700, 900, 1000], 19);
  // ---- arbres (nimiers, palmiers doum, gaos), lampadaires ----
  const tree = (x, z, h, r, c = 0x4a6a2a) => { parts.push(colorize(new THREE.CylinderGeometry(0.18, 0.32, h, 5).translate(x, h / 2, z), 0x6a5236)); parts.push(colorize(new THREE.SphereGeometry(r, 7, 5).scale(1, 0.75, 1).translate(x, h + r * 0.3, z), c)); circle(x, z, 0.4, h); };
  const doum = (x, z) => { parts.push(colorize(new THREE.CylinderGeometry(0.2, 0.3, 6, 5).translate(x, 3, z), 0x7a6a52)); for (const s of [-1, 1]) { parts.push(colorize(new THREE.CylinderGeometry(0.14, 0.2, 3.5, 5).rotateZ(s * 0.6).translate(x + s * 1, 7.3, z), 0x7a6a52)); parts.push(colorize(new THREE.ConeGeometry(2, 1, 7).translate(x + s * 2, 9, z), 0x5a7a32)); } circle(x, z, 0.4, 9); };
  for (let x = -1480; x < 1480; x += 26) { const z = 182; if (!isRes(x - 2, z - 2, x + 2, z + 2) && !roadAt(x, z, 1.5)) (Math.round(x / 26) % 3 ? tree(x, z, 6, 3.2) : doum(x, z)); }
  for (const [x0, z0, x1, z1, w] of ROADS) { if (!(z0 === -100 || x0 === 0) || z0 > 170 && x0 !== 0) continue; const along = x0 === x1, a0 = along ? Math.min(z0, z1) : Math.min(x0, x1), a1 = along ? Math.max(z0, z1) : Math.max(x0, x1);
    for (let t = a0 + 25; t < a1 - 20; t += 24) for (const s of [-1, 1]) { const x = along ? x0 + s * (w / 2 + 4) : t, z = along ? t : z0 + s * (w / 2 + 4); if (!isRes(x - 2, z - 2, x + 2, z + 2) && !roadAt(x, z, 2.5) && !wet(x, z) && Math.abs(z - 310) > 130) tree(x, z, 5 + R() * 2, 3 + R()); } }
  const lamp = (x, z, rr) => { const m = new THREE.Matrix4().makeRotationY(rr).setPosition(x, 0, z); parts.push(colorize(new THREE.CylinderGeometry(0.07, 0.1, 7, 6).translate(0, 3.5, 0).applyMatrix4(m), 0x5a5e64)); parts.push(colorize(new THREE.BoxGeometry(0.08, 0.08, 1.8).translate(0, 6.9, 0.85).applyMatrix4(m), 0x5a5e64)); heads.push(new THREE.BoxGeometry(0.35, 0.15, 0.7).translate(0, 6.85, 1.7).applyMatrix4(m)); circle(x, z, 0.18, 7); lamps.push([x + Math.sin(rr) * 1.7, z + Math.cos(rr) * 1.7]); };
  for (const [x0, z0, x1, z1, w] of ROADS) { const along = x0 === x1, a0 = along ? Math.min(z0, z1) : Math.min(x0, x1), a1 = along ? Math.max(z0, z1) : Math.max(x0, x1); if (a1 - a0 < 120) continue;
    for (let t = a0 + 15, k = 0; t < a1 - 10; t += 40, k++) { const s = k % 2 ? 1 : -1, x = along ? x0 + s * (w / 2 + 0.7) : t, z = along ? t : z0 + s * (w / 2 + 0.7); if (isRes(x - 1, z - 1, x + 1, z + 1) || wet(x, z) || ROADS.some((r) => (r[0] === r[2] ? !along && Math.abs(r[0] - x) < 9 && z > Math.min(r[1], r[3]) && z < Math.max(r[1], r[3]) : along && Math.abs(r[1] - z) < 9 && x > Math.min(r[0], r[2]) && x < Math.max(r[0], r[2])))) continue; lamp(x, z, along ? (s > 0 ? -PI / 2 : PI / 2) : (s > 0 ? PI : 0)); } }
  // ---- drapeau du Niger (orange, blanc à disque orange, vert) ----
  const flagTex = (() => { const c = document.createElement('canvas'); c.width = 300; c.height = 258; const x = c.getContext('2d'); x.fillStyle = '#e05206'; x.fillRect(0, 0, 300, 86); x.fillStyle = '#ffffff'; x.fillRect(0, 86, 300, 86); x.fillStyle = '#0db02b'; x.fillRect(0, 172, 300, 86); x.fillStyle = '#e05206'; x.beginPath(); x.arc(150, 129, 30, 0, 7); x.fill(); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t; })();
  const flag = (x, z, h = 9) => { parts.push(colorize(new THREE.CylinderGeometry(0.06, 0.08, h, 6).translate(x, h / 2, z), 0xd8dde2)); const f = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 2.06), new THREE.MeshBasicMaterial({ map: flagTex, side: THREE.DoubleSide })); f.position.set(x + 1.25, h - 1.1, z); g.add(f); circle(x, z, 0.12, h); };
  const label = (t, sub, w, h, bg, fg) => { const c = document.createElement('canvas'); c.width = 1024; c.height = Math.max(64, Math.round(1024 * h / w)); const x = c.getContext('2d'); x.fillStyle = bg; x.fillRect(0, 0, c.width, c.height); x.fillStyle = fg; x.textAlign = 'center'; x.textBaseline = 'middle'; x.font = `900 ${Math.round(c.height * (sub ? 0.38 : 0.55))}px Arial`; x.fillText(t, c.width / 2, c.height * (sub ? 0.38 : 0.52), c.width - 30); if (sub) { x.font = `700 ${Math.round(c.height * 0.2)}px Arial`; x.fillText(sub, c.width / 2, c.height * 0.78, c.width - 30); } const tx = new THREE.CanvasTexture(c); tx.colorSpace = THREE.SRGBColorSpace; return new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ map: tx, side: THREE.DoubleSide })); };
  const put = (mesh, x, y, z, rr = 0) => { mesh.position.set(x, y, z); mesh.rotation.y = rr; g.add(mesh); return mesh; };
  const roadSign = (t, x, z, rr) => { parts.push(colorize(new THREE.CylinderGeometry(0.05, 0.05, 3, 6).translate(x, 1.5, z), 0x8a8f96)); put(label(t, '', 3.6, 0.7, '#0db02b', '#ffffff'), x, 3.1, z, rr); circle(x, z, 0.1, 3); };
  const pole = (x, z, h = 2.2) => { parts.push(colorize(new THREE.CylinderGeometry(0.06, 0.06, h, 5).translate(x, h / 2, z), 0x5a5e64)); circle(x, z, 0.1, h); };
  // ---- musée national Boubou-Hama : enceinte, pavillons, artisans, arbres ----
  { const m = P.musee; for (const [a, b, c2, d] of [[-580, -62, -480, -58], [-420, -62, -320, -58], [-584, -62, -580, 155], [-320, -62, -316, 155], [-584, 151, -316, 155]]) { box(a, 0, b, c2, 3, d, 0xc8905a); solid(a, b, c2, d, 3); }
    for (const [px, pz, w, d] of [[-540, 0, 30, 20], [-470, 20, 36, 22], [-380, 0, 30, 20], [-520, 90, 40, 24], [-400, 95, 34, 22]]) { box(px - w / 2, 0, pz - d / 2, px + w / 2, 5, pz + d / 2, 0xd8a870); box(px - w / 2 - 1, 5, pz - d / 2 - 1, px + w / 2 + 1, 5.6, pz + d / 2 + 1, 0x9a6a40); for (let k = -2; k <= 2; k++) parts.push(colorize(new THREE.ConeGeometry(0.6, 1.8, 4).translate(px + k * w * 0.2, 6.5, pz + d / 2), 0xd8a870)); solid(px - w / 2, pz - d / 2, px + w / 2, pz + d / 2, 6); }
    for (const [tx, tz] of [[-560, 50], [-450, 60], [-350, 50], [-450, -30], [-350, 130]]) tree(tx, tz, 6, 3.4); flag(-470, -50, 9);
    put(label('MUSÉE NATIONAL BOUBOU-HAMA', 'pavillons, artisans, jardins • représentation stylisée', 9, 1.3, '#7a4a2a', '#ffffff'), m.x, 2.6, -64, PI); Pt(m.x, -68, 3.5, '🏛️ Visiter : musée national Boubou-Hama', () => ctx.visit('musee')); }
  // ---- bord du fleuve : pirogues, pont Kennedy ----
  { for (let k = 0; k < 6; k++) { const x = -230 + k * 30, z = 214 + (k % 2) * 8; parts.push(colorize(new THREE.BoxGeometry(2.2, 0.8, 14).rotateY(PI / 2 + 0.2 * (k % 3 - 1)).translate(x, 0.35, z), [0x8a5a3a, 0x2a6ad8, 0xe05206][k % 3])); }
    put(label('LE FLEUVE NIGER', 'balades en pirogue • représentation stylisée', 6, 1, '#2a6a72', '#ffffff'), P.fleuve.x, 2.4, 192, PI); pole(P.fleuve.x + 3.2, 192.2); Pt(P.fleuve.x, P.fleuve.z, 4, '🛶 Le fleuve Niger : balade en pirogue', () => ctx.visit('fleuve'));
    put(label('PONT KENNEDY', 'inauguré en 1970 • représentation stylisée', 6, 1, '#1a1a1a', '#f2c200'), 20, 2.6, 186, PI); pole(23.2, 186.2); Pt(P.pont.x, P.pont.z, 3, '🌉 Pont Kennedy', () => ctx.visit('pont')); }
  // ---- Grande Mosquée (stylisée) ----
  { const m = P.mosquee; box(320, 0.03, -985, 580, 0.06, -705, 0xe8dcc8); for (const [a, b, c2, d] of [[330, -980, 570, -976], [330, -980, 334, -720], [566, -980, 570, -720], [330, -724, 430, -720], [470, -724, 570, -720]]) { box(a, 0, b, c2, 6, d, 0xf2ead8); solid(a, b, c2, d, 6); }
    box(370, 0, -960, 530, 13, -840, 0xf2ead8); parts.push(colorize(new THREE.SphereGeometry(26, 24, 12, 0, PI * 2, 0, PI / 2).translate(450, 13, -900), 0x2a8a5a)); box(449.7, 39, -900.3, 450.3, 44, -899.7, 0xd8c890); solid(370, -960, 530, -840, 40);
    parts.push(colorize(new THREE.CylinderGeometry(3.4, 4.2, 50, 8).translate(520, 25, -800), 0xf2ead8)); box(515.5, 50, -804.5, 524.5, 52, -795.5, 0xd8c8a8); parts.push(colorize(new THREE.ConeGeometry(3, 6, 8).translate(520, 55, -800), 0x2a8a5a)); solid(515.8, -804.2, 524.2, -795.8, 58);
    put(label('GRANDE MOSQUÉE DE NIAMEY', 'lieu de prière • visite respectueuse • stylisée', 8, 1.2, '#2a8a5a', '#ffffff'), m.x, 2.6, -716); Pt(m.x, -710, 3.2, '🕌 Grande Mosquée de Niamey', () => ctx.visit('mosquee')); }
  // ---- Grand Marché (bâtiment et étals) ----
  { const b = P.grandmarche; box(40, 0, -665, 260, 10, -520, 0xd8a878); box(39, 10, -666, 261, 10.8, -519, 0xe05206); for (let k = -4; k <= 4; k++) box(b.x + k * 24 - 4, 0.2, -519.9, b.x + k * 24 + 4, 6, -519.7, 0x3a2a22); solid(40, -665, 260, -520, 11);
    for (let k = 0; k < 8; k++) { const x = 52 + k * 28, z = -490; box(x - 3, 0, z - 1.4, x + 3, 0.85, z + 1.4, 0x8a6440); parts.push(colorize(new THREE.BoxGeometry(6.6, 0.12, 4).translate(x, 2.6, z), [0xe05206, 0x0db02b, 0xf2c200, 0x2a6ad8][k % 4])); for (const [a, b2] of [[-3, -1.8], [3, -1.8], [-3, 1.8], [3, 1.8]]) box(x + a - 0.06, 0, z + b2 - 0.06, x + a + 0.06, 2.6, z + b2 + 0.06, 0x5a4228); solid(x - 3, z - 1.4, x + 3, z + 1.4, 1); }
    put(label('GRAND MARCHÉ', 'centre-ville • représentation stylisée', 8, 1.2, '#e05206', '#ffffff'), b.x, 3.4, -466); Pt(b.x, -460, 3.5, '🛍️ Grand Marché : acheter', () => ctx.market('grandmarche')); }
  // ---- Petit Marché (fruits, légumes) ----
  { box(-285, 0, -385, -15, 0.05, -106, 0x8a7a62); for (let r = 0; r < 5; r++) for (let k = 0; k < 8; k++) { const x = -265 + k * 32, z = -365 + r * 50; box(x - 3, 0, z - 1.4, x + 3, 0.85, z + 1.4, 0x8a6440); parts.push(colorize(new THREE.BoxGeometry(6.6, 0.12, 4).translate(x, 2.6, z), [0xf2c200, 0x0db02b, 0xe05206, 0xf2f2ee][(k + r) % 4])); for (const [a, b2] of [[-3, -1.8], [3, -1.8], [-3, 1.8], [3, 1.8]]) box(x + a - 0.06, 0, z + b2 - 0.06, x + a + 0.06, 2.6, z + b2 + 0.06, 0x5a4228); for (let j = 0; j < 4; j++) box(x - 2.5 + j * 1.3, 0.85, z - 0.9, x - 1.6 + j * 1.3, 1.25, z + 0.9, [0xe8112d, 0xf2c200, 0x2fb04a, 0xe46a1f][(j + k + r) % 4]); solid(x - 3, z - 1.4, x + 3, z + 1.4, 1); }
    put(label('PETIT MARCHÉ', 'fruits et légumes • stylisé', 6, 1, '#0db02b', '#ffffff'), P.petitmarche.x, 3.4, -115); Pt(P.petitmarche.x, -110, 3.5, '🛍️ Petit Marché : acheter', () => ctx.market('petitmarche')); }
  // ---- stade Général-Seyni-Kountché (stylisé) ----
  { const s = P.stade; parts.push(colorize(new THREE.CylinderGeometry(62, 58, 15, 32, 1, true).scale(1.06, 1, 0.82).translate(s.x, 7.5, s.z), 0xe8dcc8)); parts.push(colorize(new THREE.CylinderGeometry(64, 64, 1.2, 32, 1, true).scale(1.06, 1, 0.82).translate(s.x, 15.6, s.z), 0x0db02b)); parts.push(colorize(new THREE.CylinderGeometry(46, 46, 0.3, 32).scale(1.06, 1, 0.82).translate(s.x, 0.15, s.z), 0x3f8a3a)); solid(s.x - 60, s.z - 46, s.x + 60, s.z + 46, 16);
    for (const dx of [-30, 0, 30]) flag(s.x + dx, s.z + 56, 10); put(label('STADE GÉNÉRAL-SEYNI-KOUNTCHÉ', 'représentation stylisée', 9, 1.3, '#e05206', '#ffffff'), s.x, 2.6, s.z + 134); Pt(s.x, s.z + 140, 3.5, '🏟️ Visiter : stade Général-Seyni-Kountché', () => ctx.visit('stade')); }
  // ---- hôtel, restaurants, centre commercial, stations, hôpital, école, gare routière ----
  { const h = P.hotel; box(405, 0, 70, 495, 26, 150, 0xe8d4b0); for (let f = 1; f < 8; f++) box(404, f * 3.2, 69, 496, f * 3.2 + 0.3, 151, 0xe05206); solid(405, 70, 495, 150, 26); put(label('HÔTEL FLEUVE NIGER', 'hôtel fictif', 8, 1.2, '#5a3a22', '#f2c200'), h.x, 4, 69.4, PI); Pt(h.x, 63, 2.6, '🏨 Hôtel Fleuve Niger (fictif) : réception', () => ctx.hotel()); }
  for (const [rx, rz, nm, sub, nmx] of [[-750, -250, 'MAQUIS LE KILICHI', 'grillades fictives', 'Maquis Le Kilichi'], [750, -250, 'LE JARDIN DU FLEUVE', 'restaurant fictif', 'Le Jardin du Fleuve']]) { box(rx - 14, 0, rz - 10, rx + 14, 3.4, rz + 6, 0xd8b080); box(rx - 15, 3.4, rz - 11, rx + 15, 3.7, rz + 7, 0x7a4a2a); solid(rx - 14, rz - 10, rx + 14, rz + 6, 3.7); put(label(nm, sub, 4.8, 0.85, '#0db02b', '#ffffff'), rx, 2.6, rz + 6.1); Pt(rx, rz + 9, 2.4, `🍲 ${nmx} (fictif) : manger`, () => ctx.restaurant(nmx)); }
  { const s = P.mall; box(s.x - 85, 0, s.z - 60, s.x + 85, 10, s.z + 60, 0xe8dcc8); box(s.x - 86, 10, s.z - 61, s.x + 86, 10.8, s.z + 61, 0x0db02b); box(s.x - 60, 0.2, s.z + 60, s.x + 60, 7.5, s.z + 60.2, 0x2a4a5a); solid(s.x - 85, s.z - 60, s.x + 85, s.z + 60, 10.8); put(label('SAHEL CENTER', 'centre commercial fictif', 9, 1.3, '#0db02b', '#ffffff'), s.x, 8.5, s.z + 60.6); Pt(s.x, s.z + 65, 3, '🛒 Sahel Center (fictif)', () => ctx.market('mall')); }
  for (const [sx, sz] of [[-450, -550], [1050, -550]]) { box(sx - 22, 0, sz - 20, sx + 22, 0.05, sz + 20, 0x4a4d52); for (const dx of [-7, 7]) { box(sx + dx - 0.6, 0, sz - 1, sx + dx + 0.6, 1.8, sz + 1, 0xd8dde2); solid(sx + dx - 0.6, sz - 1, sx + dx + 0.6, sz + 1, 1.8); } box(sx - 14, 4.4, sz - 7, sx + 14, 4.8, sz + 7, 0xe05206); for (const [a, b] of [[-13, -6], [13, -6], [-13, 6], [13, 6]]) { box(sx + a - 0.2, 0, sz + b - 0.2, sx + a + 0.2, 4.4, sz + b + 0.2, 0xd8dde2); circle(sx + a, sz + b, 0.25, 4.4); } box(sx + 12, 0, sz - 19, sx + 20, 3, sz - 11, 0xf4f0e6); solid(sx + 12, sz - 19, sx + 20, sz - 11, 3); put(label('STATION SAHEL', 'station-service fictive', 5, 0.9, '#e05206', '#ffffff'), sx, 5.4, sz + 7.2); Pt(sx + 16, sz - 9, 2.2, '⛽ Station Sahel (fictive) : boutique', () => ctx.shopStation()); }
  { const h = P.hopital; box(h.x - 58, 0, h.z - 46, h.x + 58, 12.8, h.z + 46, 0xf4f0e8); box(h.x - 5, 12.8, h.z - 5, h.x + 5, 13, h.z + 5, 0xe05206); solid(h.x - 58, h.z - 46, h.x + 58, h.z + 46, 13); put(label('CENTRE HOSPITALIER', 'représentation stylisée', 7, 1.1, '#ffffff', '#e05206'), h.x, 8.2, h.z + 46.2); Pt(h.x, h.z + 49, 3, '🏥 Centre hospitalier (stylisé) : consultation', () => ctx.hospital()); }
  { const e = P.ecole; box(e.x - 28, 0, e.z - 28, e.x + 28, 3.4, e.z - 14, 0xd8b080); box(e.x - 29, 3.4, e.z - 29, e.x + 29, 3.7, e.z - 13, 0x8a8f96); solid(e.x - 28, e.z - 28, e.x + 28, e.z - 14, 3.7); box(e.x - 28, 0.02, e.z - 14, e.x + 28, 0.05, e.z + 30, 0xc8a070); put(label('ÉCOLE PRIMAIRE', 'représentation stylisée', 6, 1, '#2a4a7a', '#ffffff'), e.x, 2.6, e.z - 13.9); flag(e.x + 22, e.z + 24, 7); Pt(e.x, e.z - 10, 2.6, '🎒 École primaire', () => ctx.visit('ecole')); }
  { const s = P.gare; box(-1150, 0, -930, -950, 0.05, -770, 0x5a5c60); box(-1140, 4, -925, -960, 4.4, -910, 0x9aa0a6); for (const dx of [-1135, -1050, -965]) { box(dx - 0.3, 0, -925, dx + 0.3, 4, -924.4, 0x5a5e64); circle(dx, -924.7, 0.4, 4); }
    for (let k = 0; k < 8; k++) { const bx = -1130 + k * 22, bz = -860; box(bx - 1.3, 0.45, bz - 5, bx + 1.3, 3.2, bz + 5, [0xe05206, 0x0db02b, 0xf2f2ee][k % 3]); box(bx - 1.32, 1.9, bz - 4.8, bx + 1.32, 2.7, bz + 4.8, 0x2a3a44); solid(bx - 1.3, bz - 5, bx + 1.3, bz + 5, 3.2); }
    put(label('GARE ROUTIÈRE', 'cars interurbains et internationaux • stylisée', 7, 1.1, '#2a2d33', '#f2c200'), s.x, 3.4, -775); Pt(s.x, -768, 3, '🚌 Gare routière : cars', () => ctx.busStation()); }
  // ---- université Abdou-Moumouni (rive droite) ----
  { const u = P.universite; for (const [dx, dz, w, d, hh] of [[-70, -40, 70, 26, 12], [60, -40, 60, 26, 9], [-60, 50, 50, 30, 7], [70, 50, 60, 26, 9]]) { box(u.x + dx - w / 2, 0, u.z + dz - d / 2, u.x + dx + w / 2, hh, u.z + dz + d / 2, 0xe0c8a0); for (let f = 1; f * 3.2 < hh; f++) box(u.x + dx - w / 2, f * 3.2, u.z + dz - d / 2 - 0.6, u.x + dx + w / 2, f * 3.2 + 0.3, u.z + dz - d / 2, 0xe05206); solid(u.x + dx - w / 2, u.z + dz - d / 2, u.x + dx + w / 2, u.z + dz + d / 2, hh); }
    flag(u.x + 20, 735, 8); put(label('UNIVERSITÉ ABDOU-MOUMOUNI', 'rive droite • stylisée', 8, 1.2, '#2a4a7a', '#ffffff'), u.x, 3.2, 720, PI); Pt(u.x, 714, 3, '🎓 Université Abdou-Moumouni (rive droite)', () => ctx.visit('universite')); }
  // ---- aéroport international Diori-Hamani (DÉPLACÉ au nord-est dans le jeu) ----
  { const a = P.aeroport; box(a.x - 110, 0, a.z - 28, a.x + 110, 13, a.z + 22, 0xe8dcc8); box(a.x - 112, 13, a.z - 30, a.x + 112, 14, a.z + 24, 0xe05206); box(a.x - 90, 0.4, a.z + 22, a.x + 90, 7.5, a.z + 22.2, 0x2a4a5a); solid(a.x - 110, a.z - 28, a.x + 110, a.z + 22, 14);
    put(label('AÉROPORT INTERNATIONAL DIORI-HAMANI', 'déplacé dans le jeu : en réalité au sud-est de la ville • stylisé', 15, 1.6, '#e05206', '#ffffff'), a.x, 10, a.z + 22.4); for (const dx of [-50, 50]) flag(a.x + dx, a.z + 32);
    box(680, 0.03, -1270, 1470, 0.06, -1230, 0x3a3c40); for (let x = 700; x < 1460; x += 40) box(x, 0.06, -1251, x + 20, 0.07, -1249, 0xf2f2f2); box(a.x - 130, 0.03, -1228, a.x + 130, 0.05, a.z - 28, 0x5a5c60);
    for (const [px, pz] of [[a.x - 55, a.z - 85], [a.x + 65, a.z - 88]]) { box(px - 20, 1.4, pz - 2, px + 20, 5, pz + 2, 0xf4f4f2); box(px - 2, 2.6, pz - 18, px + 4, 3.1, pz + 18, 0xd8dde2); box(px + 15, 5, pz - 0.2, px + 20, 9.5, pz + 0.2, 0xe05206); solid(px - 20, pz - 2.2, px + 20, pz + 2.2, 5.4); }
    Pt(a.x, a.z + 30, 3.5, '✈️ Aérogare : vols, jet privé', () => ctx.airport()); }
  // ---- sortie ouest (route de Torodi vers la frontière du Burkina Faso), panneaux, taxis ----
  roadSign('← Torodi • Kantchari (Burkina Faso)', -1450, 685.5, PI / 2); Pt(P.ouest.x, P.ouest.z, 4.5, '🛣️ Route de Torodi vers la frontière du Burkina Faso (Kantchari)', () => ctx.border('ouaga'));
  roadSign('Pont Kennedy • rive droite ↓', -8.5, 160, 0); roadSign('Grand Marché ↑', 8.5, -393, 0); roadSign('Aéroport (déplacé) ↑', 906.5, -992.5, 0); roadSign('Centre-ville ↑', 8.5, 432, PI);
  for (const [x, z, n] of TAXIS) { put(label('TAXI', '', 1.2, 0.5, '#0db02b', '#ffffff'), x, 2.4, z, 0); parts.push(colorize(new THREE.CylinderGeometry(0.05, 0.05, 2.2, 5).translate(x, 1.1, z), 0x5a5e64)); circle(x, z, 0.1, 2.2); Pt(x, z + 1.4, 2.2, `🚕 Station de taxis (${n})`, () => ctx.taxi()); }
  // ---- maillages ----
  const mkm = (arr, mat) => { if (!arr.length) return; const ms = new THREE.Mesh(mergeGeometries(arr), mat); ms.receiveShadow = true; ms.castShadow = true; g.add(ms); };
  mkm(parts, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.85 })); mkm(glass, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.15, metalness: 0.45 }));
  if (heads.length) { for (const h of heads) for (const k of Object.keys(h.attributes)) if (!['position', 'normal'].includes(k)) h.deleteAttribute(k); g.add(new THREE.Mesh(mergeGeometries(heads), ctx.lampMat)); const pool = new THREE.InstancedMesh(new THREE.PlaneGeometry(13, 13).rotateX(-PI / 2), ctx.poolMat, lamps.length), dm = new THREE.Object3D(); lamps.forEach(([x, z], i) => { dm.position.set(x, 0.07, z); dm.updateMatrix(); pool.setMatrixAt(i, dm.matrix); }); pool.renderOrder = 2; g.add(pool); }
  for (const [t, arr] of Object.entries(signs)) { const c = document.createElement('canvas'); c.width = 512; c.height = 64; const x = c.getContext('2d'); x.fillStyle = ['#0db02b', '#f6f2e6', '#e05206', '#1a2a44'][t.length % 4]; x.fillRect(0, 0, 512, 64); x.fillStyle = t.length % 4 === 1 ? '#1a1a1a' : '#ffffff'; x.font = '900 32px Arial'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(t, 256, 34, 500); const tx = new THREE.CanvasTexture(c); tx.colorSpace = THREE.SRGBColorSpace; g.add(new THREE.Mesh(mergeGeometries(arr), new THREE.MeshBasicMaterial({ map: tx }))); }
  // ---- trottoirs des piétons ----
  const free = (x, z) => ![[0, 0], [0.4, 0], [-0.4, 0], [0, 0.4], [0, -0.4]].some(([a, b]) => C.pointBlocked(O.x + x + a, 0.5, O.z + z + b)) && !isWet(x, z);
  const runs = (ax, az, bx, bz) => { const L2 = Math.hypot(bx - ax, bz - az), n = Math.max(1, Math.floor(L2 / 2)), out = []; let st = null; for (let i = 0; i <= n; i++) { const t = i / n, x = ax + (bx - ax) * t, z = az + (bz - az) * t; if (free(x, z)) { if (!st) st = [x, z]; } else if (st) { if (Math.hypot(x - st[0], z - st[1]) > 30) out.push([st, [ax + (bx - ax) * ((i - 1) / n), az + (bz - az) * ((i - 1) / n)]]); st = null; } } if (st && Math.hypot(bx - st[0], bz - st[1]) > 30) out.push([st, [bx, bz]]); return out; };
  for (const [x0, z0, x1, z1, w] of ROADS) { if (Math.hypot(x1 - x0, z1 - z0) < 150) continue; for (const s of [-1, 1]) lanes.push(...(x0 === x1 ? runs(x0 + s * (w / 2 + 2), Math.min(z0, z1) + 10, x0 + s * (w / 2 + 2), Math.max(z0, z1) - 10) : runs(Math.min(x0, x1) + 5, z0 + s * (w / 2 + 2), Math.max(x0, x1) - 5, z0 + s * (w / 2 + 2)))); }
  // ---- carte du secteur ----
  const S = 0.25, Wd = NIAMEY.X1 - NIAMEY.X0 + 80, Ht = NIAMEY.Z1 - NIAMEY.Z0 + 80, cv = document.createElement('canvas'); cv.width = Math.round(Wd * S); cv.height = Math.round(Ht * S); const x = cv.getContext('2d'), T = (lx, lz) => [(lx - NIAMEY.X0 + 40) * S, (lz - NIAMEY.Z0 + 40) * S];
  x.fillStyle = '#c8aa7a'; x.fillRect(0, 0, cv.width, cv.height); x.fillStyle = '#3a7a7a'; { const [a, b] = T(NIAMEY.X0 - 40, NIAMEY.R0), [c2, d] = T(NIAMEY.X1 + 40, NIAMEY.R1); x.fillRect(a, b, c2 - a, d - b); }
  x.fillStyle = '#e0ccaa'; for (const r of reserved) { if (r.x0 === 640) continue; const [a, b] = T(r.x0, r.z0), [c2, d] = T(r.x1, r.z1); x.fillRect(a, b, Math.max(1, c2 - a), Math.max(1, d - b)); }
  x.strokeStyle = '#4d4f55'; x.lineCap = 'round'; for (const [x0, z0, x1, z1, w] of ROADS) { x.lineWidth = Math.max(2, w * S * 1.4); x.beginPath(); x.moveTo(...T(x0, z0)); x.lineTo(...T(x1, z1)); x.stroke(); }
  return { group: g, cols, points, lanes, map: { canvas: cv, X0: O.x + NIAMEY.X0 - 40, Z0: O.z + NIAMEY.Z0 - 40, W: Wd, H: Ht, S, has: NIAMEY.has } };
}
export const NIAMEY_PLACES = P;
export const NIAMEY_QUARTIERS = QUARTIERS;
export const NIAMEY_NAMES = NAMES;
