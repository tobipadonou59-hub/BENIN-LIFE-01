// Mission 017, étape 1 — fortune personnelle du PDG : compte personnel doté de 10 000 000 000 FCFA (MONNAIE FICTIVE
// du jeu, sans aucune valeur réelle), banque personnelle (solde, épargne, virements, historique classé par catégories,
// dépenses et revenus), achats personnels : véhicules, propriétés (loyers mensuels), vêtements de luxe (garde-robe),
// équipements et loisirs. Les comptes des sociétés NOVA restent séparés (virements explicites uniquement).
import * as THREE from 'three';
import { fcfa } from './food-data.js';
import { CAR_BY_ID } from './cars-data.js';
import { ARTICLES, ARTICLE_BY_ID } from './market-data.js';

export const FORTUNE = 10000000000;
export const CAR_PRICES = { cybra: 65000000, rosso48: 180000000, urca: 150000000, gkaiser: 120000000, mcoupe: 55000000, sahel: 60000000, rangers: 70000000, nine11: 90000000, rsfast: 80000000, raijin: 75000000, diamant: 250000000, stallion: 40000000, hilo: 25000000 };
const EQUIP = [['eq_laptop', 'Ordinateur portable haut de gamme', 2500000, '💻', 'Pour travailler partout.'], ['eq_tablette', 'Tablette', 650000, '📱', 'Lecture et présentations.'], ['eq_photo', 'Appareil photo professionnel', 1800000, '📷', 'Pour les photos souvenirs.'], ['eq_drone', 'Drone de prise de vue', 1200000, '🛸', 'Vues aériennes.'], ['eq_montre', 'Montre connectée', 350000, '⌚', 'Agenda et notifications.']];
for (const [id, name, price, icon, desc] of EQUIP) if (!ARTICLE_BY_ID[id]) { const a = { id, name, price, icon, desc, lux: true }; ARTICLES.push(a); ARTICLE_BY_ID[id] = a; }
const LEISURE = [
  ['spa', 'Séance de spa (2 h)', 150000, 'Énergie +40, propreté 100 %', { energy: 40, hygiene: 100, hours: 2 }],
  ['massage', 'Massage relaxant (1 h)', 60000, 'Énergie +25', { energy: 25, hours: 1 }],
  ['diner', 'Dîner gastronomique privé', 250000, 'Faim 100 %', { hunger: 100, hours: 1.5 }],
  ['cinema', 'Séance de cinéma privée', 100000, 'Énergie +10', { energy: 10, hours: 2 }],
];
const CATS = [
  ['Alimentation & sorties', /supermarch|march|courses|restaurant|dîner|diner|repas|cocktail|bar |boisson|plat|menu|frigo|réfrigérateur/i],
  ['Transport', /carburant|taxi|zem|tokpa|transport|vol de passagers|course/i],
  ['Hébergement', /hôtel|hotel|chambre|nuit|douche|repos/i],
  ['Véhicules', /véhicule|vehicule|voiture|garage/i],
  ['Immobilier', /propriét|villa|immeuble|loyer/i],
  ['Mode & accessoires', /garde-robe|vêtement|costume|montre|collier|lunettes|chapeau|souliers|mocassins|boubou|smoking|tenue/i],
  ['Loisirs & équipements', /spa|massage|cinéma|ordinateur|tablette|appareil|drone/i],
  ['Banque & entreprises', /virement|apport|dividende|dépôt|retrait|prêt|compte|ouverture/i],
  ['Revenus', /allocation|prime|vente/i],
];
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

export class Fortune {
  constructor(ctx) {
    Object.assign(this, ctx); // scene, region, economy, venues, group, company, garage, wardrobe, ui, audio, env, needs, onSave
    this.granted = false; this.owned = {}; this.lastRent = null; this.tab = 'compte'; this.filter = 'tout'; this.form = null; this.shopTab = 'vehicules'; this.confirm = null;
    this.props = this.pickProperties();
  }
  // dotation unique de 10 milliards (nouvelle partie ou sauvegarde existante)
  grant() {
    if (this.granted) return;
    this.granted = true;
    this.economy.earn(FORTUNE, 'Ouverture du compte personnel — dotation de 10 milliards (monnaie fictive du jeu)', 'BANQUE LAGUNE');
    this.onSave && this.onSave();
  }
  cat(h) { const t = `${h.label} ${h.place || ''}`; for (const [c, re] of CATS) if (re.test(t)) return c; return h.amount > 0 ? 'Revenus' : 'Divers'; }
  // ------------------------------------------------------------------ propriétés (maisons et immeubles des villes)
  pickProperties() {
    const out = [], want = { 'Porto-Novo': 2, Ouidah: 2, Cocotomey: 1, Pahou: 1 };
    for (const t of (this.region && this.region.towns) || []) {
      const n = want[t.name] || 0; if (!n) continue;
      const pool = t.houses.filter((h) => !h.shop && Math.hypot(h.x - t.x, h.z - t.z) < t.r * 0.6), size = (h) => h.w * h.d;
      const tall = pool.filter((h) => h.h > 5.5).sort((a, b) => size(b) * b.h - size(a) * a.h), low = pool.filter((h) => h.h <= 5.5).sort((a, b) => size(b) - size(a));
      const cands = (n >= 2 ? [tall[0], low[0]] : [low[0] || tall[0]]).filter(Boolean); // un immeuble et une villa (ou une villa seule)
      cands.forEach((h, i) => {
        const big = h.h > 5.5, area = Math.round(h.w * h.d * (big ? Math.round(h.h / 3) : 1) * 10) / 10;
        const price = Math.round((big ? 600000000 + area * 1500000 : 150000000 + area * 1800000) / 5000000) * 5000000;
        out.push({ id: `prop:${t.name}:${i}`, town: t.name, house: h, type: big ? 'Immeuble de rapport' : 'Villa', name: `${big ? 'Immeuble' : 'Villa'} ${['des Cocotiers', 'du Flamboyant', 'de la Lagune', 'des Palmiers', 'du Baobab', 'Belle Vue'][out.length % 6]} — ${t.name}`, area, price, rent: Math.round(price * 0.008 / 5000) * 5000, x: h.x + Math.sin(h.ry) * (h.d / 2 + 2), z: h.z + Math.cos(h.ry) * (h.d / 2 + 2) });
      });
    }
    return out;
  }
  markOwned(p) {
    if (p.sign || !this.scene) return;
    const h = p.house, c = document.createElement('canvas'); c.width = 512; c.height = 96; const x = c.getContext('2d');
    x.fillStyle = '#0b1220'; x.fillRect(0, 0, 512, 96); x.fillStyle = '#d8a830'; x.fillRect(0, 86, 512, 10); x.fillStyle = '#fff'; x.font = '900 40px Arial'; x.textAlign = 'center'; x.fillText('PROPRIÉTÉ DU PDG', 256, 58);
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
    const m = new THREE.Mesh(new THREE.PlaneGeometry(3.2, 0.6), new THREE.MeshBasicMaterial({ map: t, toneMapped: false }));
    m.position.set(h.x + Math.sin(h.ry) * (h.d / 2 + 0.1), Math.min(h.h - 0.4, 2.9), h.z + Math.cos(h.ry) * (h.d / 2 + 0.1)); m.rotation.y = h.ry; this.scene.add(m); p.sign = m;
    if (this.ui && this.ui.pois && !this.ui.pois.some((q) => q.id === p.id)) { this.ui.pois.push({ id: p.id, name: `Ma propriété — ${p.name}`, cat: 'maison', x: p.x, z: p.z, status: 'fictif', access: true, note: `${p.type} • ${p.area} m² • loyer ${fcfa(p.rent)} par mois de jeu` }); this.ui.renderSide && this.ui.renderSide(); }
  }
  // ------------------------------------------------------------------ achats (toujours confirmés, payés sur le compte personnel)
  priceOf(model) { return CAR_PRICES[model] || 50000000; }
  payCar(model) {
    const price = CAR_PRICES[model] || 50000000, name = CAR_BY_ID[model] ? CAR_BY_ID[model].name : model;
    return this.economy.pay(price, `Achat de véhicule : ${name}`, 'Garage AUTO CONCEPT');
  }
  payCloth(it) { return this.economy.pay(it.price, `Garde-robe : ${it.name}`, 'Boutique de luxe (fictive)'); }
  buy(kind, id) {
    if (kind === 'prop') {
      const p = this.props.find((q) => q.id === id); if (!p || this.owned[id]) return;
      if (!this.economy.pay(p.price, `Achat de propriété : ${p.name}`, 'Agence Prestige Immobilier (fictive)')) return;
      this.owned[id] = { since: this.economy.stamp() }; this.markOwned(p);
      this.economy.notify(`🏡 Tu es propriétaire : ${p.name} • loyer de ${fcfa(p.rent)} versé chaque mois de jeu`);
    } else if (kind === 'equip') {
      const e = EQUIP.find((q) => q[0] === id); if (!e) return;
      if (!this.economy.pay(e[2], `Équipement : ${e[1]}`, 'Boutique high-tech (fictive)')) return;
      this.economy.addItem(e[0], 1); this.economy.notify(`${e[3]} ${e[1]} ajouté à « Mes articles »`);
    } else if (kind === 'loisir') {
      const l = LEISURE.find((q) => q[0] === id); if (!l) return;
      if (!this.economy.pay(l[2], `Loisirs : ${l[1]}`, 'Hôtel Océan Bleu — espace détente (fictif)')) return;
      const fx = l[4], n = this.needs;
      if (fx.energy) n.energy = Math.min(100, n.energy + fx.energy); if (fx.hygiene) n.hygiene = fx.hygiene; if (fx.hunger) n.hunger = fx.hunger;
      if (fx.hours) this.env.time = (this.env.time + fx.hours) % 24;
      this.ui.toast(`${l[1]} : ${l[3]}`, 2.5);
    }
    this.confirm = null; this.onSave && this.onSave();
  }
  // loyers : à chaque nouveau mois de jeu (7 jours)
  update() {
    if (!this.granted) this.grant(); // après le chargement de la sauvegarde
    const d = this.economy.day; if (this.lastRent === null) { this.lastRent = d; return; }
    if (d - this.lastRent >= 7) {
      this.lastRent = d; let tot = 0;
      for (const p of this.props) if (this.owned[p.id]) { this.economy.earn(p.rent, `Loyer encaissé : ${p.name}`, 'Agence Prestige Immobilier (fictive)'); tot += p.rent; }
      if (tot) this.economy.notify(`🏡 Loyers du mois : ${fcfa(tot)} versés sur ton compte personnel`);
    }
  }
  patrimoine() {
    const props = this.props.filter((p) => this.owned[p.id]).reduce((a, p) => a + p.price, 0);
    const cars = (this.garage ? this.garage.owned : []).reduce((a, o) => a + (CAR_PRICES[o.model] || 0), 0);
    return { props, cars, savings: this.venues ? this.venues.savings : 0 };
  }
  // ------------------------------------------------------------------ application « Ma banque »
  renderBank(b) {
    const E = this.economy, P = this.patrimoine(), G = this.group;
    const tabs = [['compte', 'Compte'], ['analyse', 'Dépenses & revenus'], ['virement', 'Virements']];
    let h = `<h4>🏦 Ma banque — BANQUE LAGUNE (fictive)</h4>
      <div class="ph-bal fx-bal"><small>Compte personnel</small><b>${fcfa(E.balance)}</b><small>Épargne : ${fcfa(P.savings)} • Patrimoine : ${fcfa(P.props + P.cars)}</small></div>
      <p class="ph-note">Monnaie fictive du jeu, sans valeur réelle. Les comptes des sociétés sont séparés.</p>
      <div class="ph-chips">${tabs.map(([k, l]) => `<button data-fx="tab:${k}" class="${k === this.tab ? 'on' : ''}">${l}</button>`).join('')}</div>`;
    if (this.tab === 'compte') {
      const list = E.history.filter((x) => this.filter === 'tout' || (this.filter === 'dep' ? x.amount < 0 : x.amount > 0)).slice(0, 60);
      h += `<div class="ph-chips">${[['tout', 'Tout'], ['dep', 'Dépenses'], ['rev', 'Revenus']].map(([k, l]) => `<button data-fx="flt:${k}" class="${k === this.filter ? 'on' : ''}">${l}</button>`).join('')}</div>
        <div class="ph-list">${list.map((x) => `<div class="ph-row"><span><b>${esc(x.label)}</b><small>${this.cat(x)} • ${esc(x.place || '')} • ${x.t}</small></span><em class="${x.amount < 0 ? 'neg' : 'pos'}">${x.amount < 0 ? '−' : '+'}${fcfa(Math.abs(x.amount))}</em></div>`).join('') || '<p class="ph-note">Aucune opération.</p>'}</div>`;
    } else if (this.tab === 'analyse') {
      const by = {}; let dep = 0, rev = 0;
      for (const x of E.history) { if (/dotation de 10 milliards/.test(x.label)) continue; const c = this.cat(x); by[c] = by[c] || { d: 0, r: 0 }; if (x.amount < 0) { by[c].d -= x.amount; dep -= x.amount; } else { by[c].r += x.amount; rev += x.amount; } }
      const max = Math.max(1, ...Object.values(by).map((v) => v.d));
      h += `<div class="ph-row"><span><b>Dépenses</b><small>${E.history.length} dernières opérations (hors dotation)</small></span><em class="neg">−${fcfa(dep)}</em></div><div class="ph-row"><span><b>Revenus</b></span><em class="pos">+${fcfa(rev)}</em></div>
        <h5>Dépenses par catégorie</h5><div class="ph-list">${Object.entries(by).filter(([, v]) => v.d > 0).sort((a, b) => b[1].d - a[1].d).map(([c, v]) => `<div class="fx-bar"><span>${c}</span><i style="width:${Math.max(3, Math.round(v.d / max * 100))}%"></i><em>${fcfa(v.d)}</em></div>`).join('') || '<p class="ph-note">Pas encore de dépenses.</p>'}</div>`;
    } else {
      const accs = G ? G.accounts().filter((a) => a !== 'perso') : [], F = this.form;
      const ops = [['dep', 'Compte → épargne (dépôt)'], ['wd', 'Épargne → compte (retrait)'], ...accs.map((a) => [`to:${a}`, `Compte → ${G.accName(a)} (apport)`]), ...accs.map((a) => [`from:${a}`, `${G.accName(a)} → compte (dividende)`])];
      h += `<div class="ph-list">${ops.map(([k, l]) => `<div class="ph-row${F && F.op === k ? ' pp-on' : ''}" data-fx="op:${k}"><span><b>${l}</b></span></div>`).join('')}</div>`;
      if (F) {
        h += `<div class="ph-chips">${[100000, 1000000, 10000000, 100000000, 1000000000].map((a) => `<button data-fx="amt:${a}" class="${F.amount === a ? 'on' : ''}">${fcfa(a)}</button>`).join('')}</div>`;
        h += F.token ? `<div class="pp-sum"><span>Opération</span><b>${ops.find((o) => o[0] === F.op)[1]}</b><span>Montant</span><b>${fcfa(F.amount)}</b></div><button class="ph-go" data-fx="ok:${F.token}">✅ CONFIRMER</button><button class="ph-mini" data-fx="cancel">Annuler</button>`
          : `<button class="ph-go" data-fx="review">VÉRIFIER L’OPÉRATION</button>`;
      }
    }
    b.innerHTML = h;
  }
  srcBalance(op) { const G = this.group; if (op === 'wd') return this.venues.savings; if (op.startsWith('from:')) return G.balance(op.slice(5)); return this.economy.balance; }
  exec(token) {
    const F = this.form; if (!F || F.token !== token) return; F.token = null; // jeton à usage unique
    if (this.srcBalance(F.op) < F.amount) { this.ui.toast('Solde insuffisant.', 2); return; }
    const E = this.economy, V = this.venues, G = this.group;
    if (F.op === 'dep') { if (!E.pay(F.amount, 'Dépôt sur le compte épargne', 'BANQUE LAGUNE')) return; V.savings += F.amount; V.savingsLog.unshift({ label: 'Dépôt', amount: F.amount, t: E.stamp() }); }
    else if (F.op === 'wd') { V.savings -= F.amount; E.earn(F.amount, 'Retrait du compte épargne', 'BANQUE LAGUNE'); V.savingsLog.unshift({ label: 'Retrait', amount: -F.amount, t: E.stamp() }); }
    else if (F.op.startsWith('to:')) G.transfer('perso', F.op.slice(3), F.amount);
    else if (F.op.startsWith('from:')) G.transfer(F.op.slice(5), 'perso', F.amount);
    this.form = null; this.onSave && this.onSave();
  }
  // ------------------------------------------------------------------ application « Achats & patrimoine »
  renderShop(b) {
    const tabs = [['vehicules', 'Véhicules'], ['immo', 'Propriétés'], ['mode', 'Mode de luxe'], ['equip', 'Équipements'], ['loisirs', 'Loisirs']], C = this.confirm;
    let h = `<h4>🛍️ Achats & patrimoine</h4><p class="ph-note">Payés avec le compte personnel (${fcfa(this.economy.balance)}) • monnaie fictive du jeu • confirmation à chaque achat.</p>
      <div class="ph-chips">${tabs.map(([k, l]) => `<button data-fx="stab:${k}" class="${k === this.shopTab ? 'on' : ''}">${l}</button>`).join('')}</div>`;
    const row = (kind, id, title, sub, price, done) => `<div class="ph-row"><span><b>${title}</b><small>${sub}</small></span>${done ? `<em class="pos">${done}</em>` : `<button class="ph-mini" data-fx="ask:${kind}|${id}">${fcfa(price)}</button>`}</div>${C && C.kind === kind && C.id === id ? `<div class="pp-sum"><span>Achat</span><b>${title}</b><span>Prix</span><b>${fcfa(price)}</b></div><button class="ph-go" data-fx="buy:${kind}|${id}">✅ CONFIRMER L’ACHAT</button><button class="ph-mini" data-fx="nobuy">Annuler</button>` : ''}`;
    if (this.shopTab === 'vehicules') h += `<div class="ph-list">${Object.entries(CAR_PRICES).map(([id, p]) => `<div class="ph-row"><span><b>${CAR_BY_ID[id] ? CAR_BY_ID[id].name : id}</b><small>${fcfa(p)} • livraison au garage AUTO CONCEPT</small></span></div>`).join('')}</div><p class="ph-note">Les véhicules s’achètent au garage AUTO CONCEPT (choix du modèle et de la couleur, puis confirmation).</p>`;
    else if (this.shopTab === 'immo') h += `<div class="ph-list">${this.props.map((p) => row('prop', p.id, p.name, `${p.type} • ${p.area} m² • loyer ${fcfa(p.rent)}/mois`, p.price, this.owned[p.id] ? 'à toi ✔' : '')).join('') || '<p class="ph-note">Aucune propriété disponible.</p>'}</div>`;
    else if (this.shopTab === 'mode') h += '<p class="ph-note">La collection de luxe (12 pièces : costumes sur mesure, smoking, boubou de gala, souliers, montres en or et en platine, bijoux…) s’achète dans la garde-robe, onglet « Collection de luxe ».</p>';
    else if (this.shopTab === 'equip') h += `<div class="ph-list">${EQUIP.map(([id, n, p, ic, d]) => row('equip', id, `${ic} ${n}`, `${d}${this.economy.items[id] ? ` • possédé ×${this.economy.items[id]}` : ''}`, p, '')).join('')}</div>`;
    else h += `<div class="ph-list">${LEISURE.map(([id, n, p, d]) => row('loisir', id, n, d, p, '')).join('')}</div>`;
    b.innerHTML = h;
  }
  onClick(btn) {
    const [a, ...r] = btn.dataset.fx.split(':'), v = r.join(':');
    if (this.audio && this.audio.ctx && this.audio.click) this.audio.click();
    if (a === 'tab') { this.tab = v; this.form = null; }
    else if (a === 'flt') this.filter = v;
    else if (a === 'op') this.form = { op: v, amount: 1000000, token: null };
    else if (a === 'amt' && this.form) { this.form.amount = +v; this.form.token = null; }
    else if (a === 'review' && this.form) { if (this.srcBalance(this.form.op) < this.form.amount) this.ui.toast('Solde insuffisant pour cette opération.', 2); else this.form.token = `F${Date.now()}${Math.random().toString(36).slice(2, 6)}`; }
    else if (a === 'ok') this.exec(v);
    else if (a === 'cancel') this.form = null;
    else if (a === 'stab') { this.shopTab = v; this.confirm = null; }
    else if (a === 'ask') { const [kind, id] = v.split('|'); this.confirm = { kind, id }; }
    else if (a === 'buy') { const [kind, id] = v.split('|'); if (this.confirm && this.confirm.kind === kind && this.confirm.id === id) this.buy(kind, id); }
    else if (a === 'nobuy') this.confirm = null;
    if (this.economy.phoneOpen) this.economy.renderPhone();
  }
  serialize() { return { granted: this.granted, owned: this.owned, lastRent: this.lastRent }; }
  restore(s) { if (!s) return; this.granted = !!s.granted; this.owned = s.owned || {}; this.lastRent = s.lastRent ?? null; for (const p of this.props) if (this.owned[p.id]) this.markOwned(p); }
}
