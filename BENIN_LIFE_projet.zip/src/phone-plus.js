// Mission 016, phase 4 — téléphone : contacts (employés de NOVA BOOK et du groupe, vendeurs fidèles, services),
// appels avec dialogues, messagerie, journal d'appels et virements aux employés.
// Les virements utilisent uniquement la monnaie virtuelle du jeu : vérification du solde, confirmation obligatoire,
// jeton à usage unique contre les doubles paiements, et inscription de chaque opération dans les relevés.
import { JOBS } from './nova-data.js';
import { VENDORS } from './market-data.js';
import { fcfa } from './food-data.js';
import { CLIENTS } from './company.js';
import { INSTR } from './group.js';

const pick = (a) => a[Math.floor(Math.random() * a.length)];
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const MOTIFS = ['Prime', 'Avance sur salaire', 'Remboursement de frais', 'Cadeau'];
const AMOUNTS = [5000, 10000, 25000, 50000, 100000];
const MAX_TRANSFER = 2000000;
const SERVICES = [
  { key: 's:garage', name: 'Garage AUTO CONCEPT', role: 'Concession & atelier (fictif)', icon: '🔧' },
  { key: 's:laguna', name: 'Supermarché LAGUNA', role: 'Service clients (fictif)', icon: '🛒' },
  { key: 's:banque', name: 'BANQUE LAGUNE', role: 'Conseiller bancaire (fictif)', icon: '🏦' },
];
const PERSO = [
  { key: 'p:maman', name: 'Maman', role: 'Famille (personnage fictif)', icon: '👵🏿' },
  { key: 'p:sedjro', name: 'Sèdjro', role: 'Grand frère (personnage fictif)', icon: '🧑🏿' },
  { key: 'p:afi', name: 'Afi', role: 'Amie d’enfance (personnage fictif)', icon: '👩🏿' },
];
const QUICK = {
  cli: ['Bonjour, êtes-vous satisfaits de nos services ?', 'Avez-vous un nouveau projet pour NOVA BOOK ?'],
  perso: ['Coucou, comment ça va ?', 'On se voit ce week-end ?', 'Je pense à toi 🙂'],
  emp: ['Bonjour, comment ça va ?', 'Peux-tu me faire un point sur ton travail ?', 'Merci pour ton excellent travail !', 'Bonne fin de journée.'],
  vend: ['Bonjour, tu as de la marchandise aujourd’hui ?', 'Merci, à bientôt au marché !'],
  serv: ['Bonjour, quels sont vos horaires ?', 'Merci beaucoup.'],
};

export class PhonePlus {
  constructor(ctx) {
    Object.assign(this, ctx); // economy, company, group, market, env, ui, audio, onSave
    this.threads = {}; this.unread = {}; this.calls = []; this.transfers = [];
    this.pending = []; this.call = null; this.sel = null; this.tab = 'emp'; this.form = null; this.praised = {};
    this.lastMsgDay = null; this.tokenSeq = 1;
  }

  // ------------------------------------------------------------------ contacts
  employees() {
    const out = [], C = this.company, G = this.group;
    if (C) for (const e of C.staff) out.push({ key: `e:book:${e.id}`, kind: 'emp', name: e.name, role: `${JOBS[e.job] ? JOBS[e.job].label : e.job} • NOVA BOOK`, acc: 'book', emp: e, org: 'NOVA BOOK', icon: '👔' });
    if (G) for (const [sid, s] of Object.entries(G.subs)) for (const e of s.staff) out.push({ key: `e:${sid}:${e.id}`, kind: 'emp', name: e.name, role: `${JOBS[e.job] ? JOBS[e.job].label : e.job} • ${s.name}${s.director === e.id ? ' (directeur)' : ''}`, acc: sid, emp: e, org: s.name, icon: '👔' });
    return out;
  }
  vendors() {
    const loyal = (this.market && this.market.loyal) || {};
    return VENDORS.filter((v) => loyal[v.id]).map((v) => ({ key: `v:${v.id}`, kind: 'vend', name: v.name, role: `${v.spec} • Dantokpa`, vendor: v, icon: v.female ? '👩🏿' : '👨🏿' }));
  }
  contacts(tab = null) {
    const cli = CLIENTS.map((n, i) => ({ key: `c:${i}`, kind: 'cli', name: n.replace(/ \(fictiv?e?\)/, ''), role: 'Client ou partenaire (fictif)', icon: '🤝' }));
    const all = [...this.employees(), ...cli, ...this.vendors(), ...SERVICES.map((s) => ({ ...s, kind: 'serv' })), ...PERSO.map((p) => ({ ...p, kind: 'perso' }))];
    let out = tab ? all.filter((c) => c.kind === tab) : all;
    if (this.q) { const q = this.q.toLowerCase(); out = out.filter((c) => c.name.toLowerCase().includes(q)); }
    return out;
  }
  dirOf(c) { if (!c || c.kind !== 'emp' || c.acc === 'book' || !this.group) return null; const s = this.group.subs[c.acc]; return s && s.director === c.emp.id ? s : null; }
  contact(key) { const q = this.q; this.q = ''; const c = this.contacts().find((x) => x.key === key) || null; this.q = q; return c; }
  unreadTotal() { return Object.values(this.unread).reduce((a, b) => a + b, 0); }
  workHours() { const h = this.env.time; return h >= 7 && h < 19; }

  // ------------------------------------------------------------------ messages
  push(key, from, txt) {
    const th = this.threads[key] || (this.threads[key] = []);
    th.push({ from, txt, t: this.economy.stamp() }); if (th.length > 40) th.splice(0, th.length - 40);
  }
  send(key, txt) {
    const c = this.contact(key); if (!c) return;
    this.push(key, 'me', txt);
    this.pending.push({ key, txt: this.replyTo(c, txt), at: performance.now() + 2500 + Math.random() * 3500 });
    this.onSave && this.onSave();
  }
  receive(key, txt) {
    const c = this.contact(key); if (!c) return;
    this.push(key, 'them', txt);
    if (!(this.economy.phoneOpen && this.economy.app === 'chat' && this.sel === key)) { this.unread[key] = (this.unread[key] || 0) + 1; this.economy.notify(`💬 ${c.name} : ${txt}`); }
    if (this.audio && this.audio.ctx) { this.audio.tone(1320, 0.06, 0.04, 'sine'); this.audio.tone(1760, 0.08, 0.04, 'sine', this.audio.sfx, 0.08); }
    this.refresh(); this.onSave && this.onSave();
  }
  status(c) { // point de travail d'un employé (selon son état réel dans la gestion)
    const e = c.emp, C = this.company;
    if (e.status && e.status !== 'présent') return `Je suis ${e.status} en ce moment, je reprends dès que possible.`;
    if (e.trainLeft > 0) return 'Je suis en formation, ça se passe très bien.';
    if (c.acc === 'book' && C) { const o = C.orders.find((q) => q.dept === e.dept); if (o) return `Je travaille sur la commande « ${o.label} » pour ${o.client}. C’est fait à ${Math.min(100, Math.round(100 * o.done / Math.max(1, o.work)))} %.`; }
    if (e.morale < 45) return 'Honnêtement, le moral n’est pas au top… une reconnaissance me ferait du bien.';
    return pick(['Tout avance normalement, le travail est à jour.', 'Le travail avance, pas de souci de mon côté.', 'On est dans les délais, je vous tiens au courant.']);
  }
  replyTo(c, txt) {
    if (/^📋/.test(txt)) return 'Bien reçu PDG, je transmets la consigne à l’équipe.';
    if (c.kind === 'emp') {
      if (/point/.test(txt)) return this.status(c);
      if (/Merci pour/.test(txt)) { this.praise(c, 2); return pick(['Merci beaucoup, ça me motive !', 'Merci PDG, ça fait plaisir.', 'Merci, je vais continuer comme ça.']); }
      if (/fin de journée/.test(txt)) return 'Merci, bonne soirée à vous aussi !';
      if (this.talk) return this.talk.reply(c.key, txt); // même moteur et même mémoire qu’en face à face (mission 017)
      if (/salaire|paie|argent/i.test(txt)) return 'Merci de vous en soucier PDG. Les virements et la paie se font depuis le téléphone ou NOVA Gestion.';
      if (/bonjour|salut|ça va|ca va/i.test(txt)) return this.workHours() ? 'Bonjour PDG ! Ça va bien, je suis au travail.' : 'Bonsoir PDG, ça va bien merci. Je suis à la maison.';
      return pick(['Bien noté PDG, je m’en occupe.', 'D’accord, c’est compris.', 'Très bien, je vous tiens informé(e).']);
    }
    if (c.kind === 'cli') { if (/nouveau projet/.test(txt)) { const C = this.company; if (C && C.offers && C.offers.length < 4 && C.refreshOffers) C.refreshOffers(); return C && C.offers && C.offers.length ? `Oui ! Regardez vos demandes de clients dans NOVA Gestion (${C.offers.length} en attente).` : 'Pas pour le moment, mais nous pensons à vous.'; } return 'Oui, très satisfaits. Merci pour votre sérieux !'; }
    if (c.kind === 'perso') return /week-end/.test(txt) ? 'Avec plaisir ! Appelle-moi samedi.' : pick(['Ça va bien, et toi ? Ne travaille pas trop !', 'Merci, ça me fait plaisir 😊', 'Tout va bien ici, à bientôt !']);
    if (c.kind === 'vend') return /marchandise/.test(txt) ? `Oui ! Il y a de tout : ${c.vendor.items.slice(0, 3).map((i) => this.market.itemInfo(i).name.toLowerCase()).join(', ')}… Passe me voir au marché.` : 'Merci à toi, que Dieu te garde !';
    if (/horaires/.test(txt)) return c.key === 's:laguna' ? 'Le supermarché est ouvert de 7 h à 22 h.' : c.key === 's:banque' ? 'Nos agences sont ouvertes de 8 h à 17 h.' : 'Le garage vous accueille tous les jours.';
    return 'Merci pour votre message, bonne journée.';
  }
  instruct(key, k) {
    const c = this.contact(key), s = this.dirOf(c); if (!s) return;
    this.group.setInstruction(s.id, k);
    this.send(key, k ? `📋 Consigne : ${INSTR[k].label}.` : '📋 Consigne : reprenez le fonctionnement normal.');
  }
  praise(c, k) { // reconnaissance : moral +k, une fois par jour et par employé
    const d = this.economy.day; if (this.praised[c.key] === d) return false;
    this.praised[c.key] = d; c.emp.morale = Math.min(100, c.emp.morale + k); return true;
  }
  // messages spontanés des employés, une fois par jour vers 9 h
  daily() {
    const emps = this.employees(); if (!emps.length) return;
    const C = this.company, e = pick(emps);
    let txt = pick(['Bonjour PDG, bonne journée à vous !', 'Bonjour ! Je suis bien arrivé(e) au bureau.', 'Bonjour PDG, l’équipe est au complet ce matin.']);
    if (C && C.payDue && e.acc === 'book') txt = 'Bonjour PDG, petit rappel : les salaires du mois sont à payer dans la gestion.';
    else if (e.emp.morale < 45) txt = 'Bonjour PDG, pourrions-nous parler de mes conditions de travail ?';
    else if (C && C.offers && C.offers.length && e.acc === 'book') txt = `Bonjour PDG, ${C.offers.length} nouvelle(s) demande(s) de clients attendent votre réponse.`;
    this.receive(e.key, txt);
  }

  // ------------------------------------------------------------------ appels
  startCall(key) {
    const c = this.contact(key); if (!c || this.call) return;
    const answers = c.kind === 'emp' ? (this.workHours() || Math.random() < 0.5) : c.kind === 'vend' ? this.env.time >= 6 && this.env.time < 20 : this.env.time >= 8 && this.env.time < 20;
    this.call = { key, phase: 'ring', t: 0, answers, lines: [], start: this.economy.stamp() };
    this.economy.app = 'call'; this.refresh();
  }
  incoming() {
    const cand = this.employees(); if (!cand.length || this.call) return;
    const dirs = cand.filter((c) => this.dirOf(c)), c = dirs.length && Math.random() < 0.6 ? pick(dirs) : pick(cand);
    const s = this.dirOf(c), C = this.company;
    const reason = s ? `Je vous appelle pour le point du jour : chiffre d’affaires du mois ${fcfa(s.cur.ca)}, trésorerie ${fcfa(s.cash)}.` : C && C.offers && C.offers.length && c.acc === 'book' ? `Un client attend votre réponse : ${C.offers[0].client}, pour « ${C.offers[0].label} ».` : this.status(c);
    this.call = { key: c.key, phase: 'incoming', t: 0, answers: true, lines: [], start: this.economy.stamp(), reason };
    if (!this.economy.phoneOpen) this.economy.togglePhone(true);
    this.economy.app = 'call'; this.refresh();
  }
  accept() { const C = this.call; if (!C || C.phase !== 'incoming') return; C.phase = 'talk'; C.talk = 0; this.say('Allô PDG ? ' + C.reason); }
  refuse() { const C = this.call; if (!C || C.phase !== 'incoming') return; const c = this.contact(C.key); this.hangup(); if (c) this.pending.push({ key: c.key, txt: 'Je vous ai appelé(e), rappelez-moi quand vous pourrez.', at: performance.now() + 4000 }); }
  hangup() {
    const C = this.call; if (!C) return;
    const c = this.contact(C.key);
    this.calls.unshift({ key: C.key, name: c ? c.name : '?', t: C.start, dur: C.phase === 'talk' ? Math.round(C.talk) : 0, missed: C.phase !== 'talk' });
    this.calls.length = Math.min(this.calls.length, 30);
    this.call = null; this.economy.app = 'calls'; this.refresh(); this.onSave && this.onSave();
  }
  say(txt, who = 'them') { this.call.lines.push({ who, txt }); this.refresh(); }
  callOption(opt) {
    const C = this.call, c = C && this.contact(C.key); if (!c || C.phase !== 'talk') return;
    if (opt === 'status') { this.say('Peux-tu me faire un point ?', 'me'); this.say(c.kind === 'emp' ? this.status(c) : this.replyTo(c, 'horaires')); }
    if (opt === 'praise') { this.say('Je voulais te féliciter pour ton travail.', 'me'); this.say(this.praise(c, 3) ? 'Merci beaucoup PDG ! Ça me fait vraiment plaisir.' : 'Merci, vous me l’avez déjà dit aujourd’hui 😊'); }
    if (opt === 'prices') { this.say('Quels sont tes prix aujourd’hui ?', 'me'); const M = this.market, v = c.vendor, prev = M.v; M.v = v; const txt = v.items.slice(0, 3).map((id) => `${M.itemInfo(id).name} à ${fcfa(M.deal(id).ask)}`).join(', '); M.v = prev; this.say(`${txt}. Viens au marché !`); }
    if (opt.startsWith('ins-')) { const k = opt.slice(4); const s = this.dirOf(c); if (s) { this.group.setInstruction(s.id, k); this.say(`Consigne : ${INSTR[k].label}.`, 'me'); this.say(`Bien reçu PDG. Effet attendu : ${INSTR[k].effect}.`); } }
    if (opt === 'client') { this.say('Avez-vous un nouveau projet pour NOVA BOOK ?', 'me'); this.say(this.replyTo(c, 'nouveau projet')); }
    if (opt === 'news') { this.say('Je voulais prendre de tes nouvelles !', 'me'); this.say(pick(['Ça va très bien, merci de penser à moi !', 'Tout va bien ! Passe à la maison un de ces jours.', 'Ça fait plaisir de t’entendre !'])); }
    if (opt === 'balance') { this.say('Quel est le solde de mon compte personnel ?', 'me'); this.say(`Votre solde est de ${fcfa(this.economy.balance)}.`); }
  }
  ring() { const a = this.audio; if (a && a.ctx) { a.tone(440, 0.4, 0.03, 'sine'); a.tone(480, 0.4, 0.03, 'sine'); } }

  // ------------------------------------------------------------------ virements
  openTransfer(key) { const c = this.contact(key); if (!c || c.kind !== 'emp') return; this.form = { key, amount: 10000, motif: MOTIFS[0], from: 'perso', step: 'edit', token: null }; this.economy.app = 'transfer'; this.refresh(); }
  accounts() { return this.group ? this.group.accounts() : ['perso']; }
  balanceOf(acc) { return this.group ? this.group.balance(acc) : this.economy.balance; }
  accName(acc) { return this.group ? this.group.accName(acc) : 'Compte personnel'; }
  review() {
    const F = this.form; if (!F) return;
    if (!(F.amount > 0) || F.amount > MAX_TRANSFER) return this.ui.toast(`Montant invalide (maximum ${fcfa(MAX_TRANSFER)}).`, 2);
    if (this.balanceOf(F.from) < F.amount) return this.ui.toast(`Solde insuffisant sur ${this.accName(F.from)}.`, 2.2);
    F.step = 'confirm'; F.token = `T${Date.now()}-${this.tokenSeq++}`; this.refresh();
  }
  execute(token) {
    const F = this.form; if (!F || F.step !== 'confirm' || F.token !== token) return; // jeton à usage unique
    F.token = null; F.step = 'busy';
    const c = this.contact(F.key);
    if (!c) { this.form = null; return this.ui.toast('Contact introuvable.', 2); }
    const recent = this.transfers.find((t) => t.key === F.key && t.amount === F.amount && Date.now() - t.ts < 10000);
    if (recent) { F.step = 'edit'; this.refresh(); return this.ui.toast('Virement identique déjà effectué à l’instant : opération bloquée pour éviter un doublon.', 3); }
    if (this.balanceOf(F.from) < F.amount) { F.step = 'edit'; this.refresh(); return this.ui.toast('Solde insuffisant.', 2); }
    const label = `Virement à ${c.name} — ${F.motif}`;
    const ok = this.group ? this.group.debit(F.from, F.amount, label, false, 'salaires') : this.economy.pay(F.amount, label, 'Virement');
    if (!ok) { F.step = 'edit'; return this.refresh(); }
    const e = c.emp; if (e) { const k = F.motif === 'Prime' || F.motif === 'Cadeau' ? Math.min(10, 2 + Math.round(F.amount / 25000)) : 1; e.morale = Math.min(100, e.morale + k); }
    const rec = { id: this.tokenSeq++, key: F.key, name: c.name, amount: F.amount, motif: F.motif, from: F.from, fromName: this.accName(F.from), t: this.economy.stamp(), ts: Date.now() };
    this.transfers.unshift(rec); this.transfers.length = Math.min(this.transfers.length, 60);
    this.push(F.key, 'me', `💸 Virement de ${fcfa(F.amount)} envoyé (${F.motif}).`);
    this.pending.push({ key: F.key, txt: F.motif === 'Prime' || F.motif === 'Cadeau' ? 'Merci infiniment PDG ! C’est bien reçu 🙏' : 'Bien reçu, merci PDG.', at: performance.now() + 3000 });
    this.economy.notify(`💸 Virement effectué : ${fcfa(F.amount)} à ${c.name} (${F.motif}) depuis ${rec.fromName}`);
    this.form = { ...F, step: 'done', rec };
    this.refresh(); this.onSave && this.onSave();
  }

  // ------------------------------------------------------------------ interface (applications du téléphone)
  refresh() {
    if (!this.economy.phoneOpen) return;
    const root = this.economy.dom.phone, ti = root.querySelector('.pp-text'), keep = ti ? { v: ti.value, f: document.activeElement === ti } : null;
    this.economy.renderPhone();
    const t2 = root.querySelector('.pp-text'); if (keep && t2) { t2.value = keep.v; if (keep.f) t2.focus(); } // message en cours de saisie conservé
  }
  homeButtons() {
    const u = this.unreadTotal();
    return `<button data-ph="contacts"><i>📇</i>Contacts</button><button data-ph="messages"><i>💬</i>Messages${u ? ` (${u})` : ''}</button><button data-ph="calls"><i>📞</i>Appels</button><button data-ph="transfers"><i>💸</i>Virements</button>${this.leds ? '<button data-ph="leds"><i>💡</i>Décoration LED</button>' : ''}`;
  }
  renderApp(app, b) {
    const row = (c, extra = '') => `<div class="ph-row"><span><b>${c.icon} ${esc(c.name)}</b><small>${esc(c.role)}</small></span>${extra}</div>`;
    if (app === 'leds') { if (this.leds) this.leds.renderApp(b); return; }
    if (app === 'contacts') {
      const tabs = [['emp', 'Employés'], ['cli', 'Clients & partenaires'], ['vend', 'Commerçants'], ['serv', 'Services'], ['perso', 'Personnels']], list = this.contacts(this.tab);
      b.innerHTML = `<h4>📇 Contacts</h4><input class="pp-search" type="search" placeholder="🔎 Rechercher un nom…" value="${esc(this.q || '')}"><div class="ph-chips">${tabs.map(([k, l]) => `<button data-pp="tab:${k}" class="${k === this.tab ? 'on' : ''}">${l} (${this.contacts(k).length})</button>`).join('')}</div>
        <div class="ph-list">${list.map((c) => row(c, `<span class="pp-acts"><button class="ph-mini" data-pp="call:${c.key}">📞</button><button class="ph-mini" data-pp="chat:${c.key}">💬</button>${c.kind === 'emp' ? `<button class="ph-mini" data-pp="pay:${c.key}">💸</button>` : ''}</span>`)).join('') || `<p class="ph-note">${this.q ? 'Aucun contact ne correspond à la recherche.' : this.tab === 'emp' ? 'Aucun employé.' : this.tab === 'vend' ? 'Achète chez un vendeur du marché Dantokpa pour enregistrer son contact.' : ''}</p>`}</div>
        <p class="ph-note">Personnes et entreprises fictives. Les numéros ne sont pas affichés.</p>`;
    } else if (app === 'messages') {
      const keys = Object.keys(this.threads).filter((k) => this.threads[k].length && this.contact(k)).sort((a, b) => (this.unread[b] || 0) - (this.unread[a] || 0));
      b.innerHTML = `<h4>💬 Messages</h4><div class="ph-list">${keys.map((k) => { const c = this.contact(k), last = this.threads[k][this.threads[k].length - 1]; return `<div class="ph-row" data-pp="chat:${k}"><span><b>${c.icon} ${esc(c.name)}${this.unread[k] ? ` <em class="pp-badge">${this.unread[k]}</em>` : ''}</b><small>${last.from === 'me' ? 'Moi : ' : ''}${esc(last.txt)}</small></span><small>${last.t}</small></div>`; }).join('') || '<p class="ph-note">Aucune conversation. Écris à un contact depuis 📇 Contacts.</p>'}</div>`;
    } else if (app === 'chat') {
      const c = this.contact(this.sel); if (!c) { b.innerHTML = '<p class="ph-note">Contact introuvable.</p>'; return; }
      this.unread[c.key] = 0;
      const th = this.threads[c.key] || [];
      b.innerHTML = `<h4>${c.icon} ${esc(c.name)}</h4><small class="ph-note">${esc(c.role)}</small><div class="ph-list pp-chat">${th.map((m) => `<div class="pp-msg ${m.from}"><span>${esc(m.txt)}</span><small>${m.t}</small></div>`).join('') || '<p class="ph-note">Nouvelle conversation.</p>'}${this.pending.some((p) => p.key === c.key) ? '<div class="pp-msg them typing"><span>…</span></div>' : ''}</div>
        <div class="ph-chips pp-quick">${QUICK[c.kind].map((q, i) => `<button data-pp="send:${i}">${esc(q)}</button>`).join('')}</div>
        ${this.dirOf(c) ? `<div class="ph-chips">${Object.entries(INSTR).map(([k, v]) => `<button data-pp="ins:${k}">📋 ${v.label}</button>`).join('')}<button data-pp="ins:">📋 Fonctionnement normal</button></div>` : ''}
        <div class="pp-write"><input class="pp-text" type="text" maxlength="160" placeholder="Écrire un message…"><button class="ph-mini" data-pp="sendtxt">Envoyer</button></div>
        <div class="pp-acts"><button class="ph-mini" data-pp="call:${c.key}">📞 Appeler</button>${c.kind === 'emp' ? `<button class="ph-mini" data-pp="pay:${c.key}">💸 Virement</button>` : ''}</div>`;
      const l = b.querySelector('.pp-chat'); if (l) l.scrollTop = l.scrollHeight;
    } else if (app === 'call') {
      const C = this.call, c = C && this.contact(C.key);
      if (!C || !c) { b.innerHTML = '<p class="ph-note">Aucun appel en cours.</p>'; return; }
      const opts = C.phase === 'talk' ? (c.kind === 'emp' ? [['status', 'Faire le point'], ['praise', 'Féliciter'], ...(this.dirOf(c) ? Object.entries(INSTR).map(([k, v]) => [`ins-${k}`, `Consigne : ${v.label}`]) : [])] : c.kind === 'cli' ? [['client', 'Proposer nos services']] : c.kind === 'perso' ? [['news', 'Prendre des nouvelles']] : c.kind === 'vend' ? [['prices', 'Prix du jour']] : c.key === 's:banque' ? [['balance', 'Mon solde'], ['status', 'Horaires']] : [['status', 'Horaires']]) : [];
      b.innerHTML = `<div class="pp-call"><div class="pp-av">${c.icon}</div><b>${esc(c.name)}</b><small>${C.phase === 'incoming' ? '📲 Appel entrant…' : C.phase === 'ring' ? 'Appel en cours…' : C.phase === 'talk' ? `En ligne • ${Math.floor(C.talk / 60)}:${String(Math.floor(C.talk % 60)).padStart(2, '0')}` : 'Messagerie : pas de réponse'}</small></div>
        <div class="ph-list pp-chat">${C.lines.map((m) => `<div class="pp-msg ${m.who}"><span>${esc(m.txt)}</span></div>`).join('')}</div>
        <div class="ph-chips">${opts.map(([k, l]) => `<button data-pp="opt:${k}">${l}</button>`).join('')}</div>
        ${C.phase === 'incoming' ? '<div class="pp-acts pp-inc"><button class="ph-go" data-pp="accept">📞 Accepter</button><button class="ph-go pp-hang" data-pp="refuse">📵 Refuser</button></div>' : '<button class="ph-go pp-hang" data-pp="hang">📵 Raccrocher</button>'}`;
      const l = b.querySelector('.pp-chat'); if (l) l.scrollTop = l.scrollHeight;
    } else if (app === 'calls') {
      b.innerHTML = `<h4>📞 Journal d’appels</h4><div class="ph-list">${this.calls.map((k) => `<div class="ph-row"><span><b>${k.missed ? '↗️' : '📞'} ${esc(k.name)}</b><small>${k.t} • ${k.missed ? 'sans réponse' : `${k.dur} s`}</small></span>${this.contact(k.key) ? `<button class="ph-mini" data-pp="call:${k.key}">Rappeler</button>` : ''}</div>`).join('') || '<p class="ph-note">Aucun appel. Appelle un contact depuis 📇 Contacts.</p>'}</div>`;
    } else if (app === 'transfers') {
      b.innerHTML = `<h4>💸 Virements</h4><p class="ph-note">Monnaie virtuelle du jeu uniquement. Chaque virement est confirmé et inscrit au relevé du compte débité.</p><div class="ph-list">${this.transfers.map((t) => `<div class="ph-row"><span><b>${esc(t.name)}</b><small>${t.motif} • ${esc(t.fromName)} • ${t.t}</small></span><em class="neg">−${fcfa(t.amount)}</em></div>`).join('') || '<p class="ph-note">Aucun virement. Utilise 💸 sur la fiche d’un employé.</p>'}</div>`;
    } else if (app === 'transfer') {
      const F = this.form, c = F && this.contact(F.key);
      if (!F || !c) { b.innerHTML = '<p class="ph-note">Aucun virement en cours.</p>'; return; }
      if (F.step === 'done') {
        b.innerHTML = `<div class="pp-ok"><b>✅ Virement effectué</b><p>${fcfa(F.rec.amount)} à ${esc(F.rec.name)}<br>${F.rec.motif} • depuis ${esc(F.rec.fromName)}<br>${F.rec.t}</p></div><button class="ph-go" data-ph="transfers">Voir l’historique</button><button class="ph-mini" data-pp="chat:${F.key}">💬 Conversation</button>`;
      } else if (F.step === 'confirm') {
        const after = this.balanceOf(F.from) - F.amount;
        b.innerHTML = `<h4>Confirmer le virement</h4><div class="pp-sum"><span>Bénéficiaire</span><b>${esc(c.name)}</b><span>Motif</span><b>${F.motif}</b><span>Montant</span><b>${fcfa(F.amount)}</b><span>Compte débité</span><b>${esc(this.accName(F.from))}</b><span>Solde après</span><b>${fcfa(after)}</b></div>
          <button class="ph-go" data-pp="exec:${F.token}">✅ CONFIRMER LE VIREMENT</button><button class="ph-mini" data-pp="edit">Modifier</button>
          <p class="ph-note">Le virement ne sera exécuté qu’une seule fois.</p>`;
      } else {
        b.innerHTML = `<h4>💸 Virement à ${esc(c.name)}</h4><small class="ph-note">${esc(c.role)}</small>
          <h5>Montant : ${fcfa(F.amount)}</h5><div class="ph-chips">${AMOUNTS.map((a) => `<button data-pp="amt:${a}" class="${a === F.amount ? 'on' : ''}">${fcfa(a)}</button>`).join('')}</div>
          <div class="pp-acts"><button class="ph-mini" data-pp="adj:-5000">−5 000</button><button class="ph-mini" data-pp="adj:5000">+5 000</button><button class="ph-mini" data-pp="adj:50000">+50 000</button></div>
          <h5>Motif</h5><div class="ph-chips">${MOTIFS.map((m) => `<button data-pp="motif:${m}" class="${m === F.motif ? 'on' : ''}">${m}</button>`).join('')}</div>
          <h5>Compte à débiter</h5><div class="ph-list">${this.accounts().map((a) => `<div class="ph-row${a === F.from ? ' pp-on' : ''}" data-pp="from:${a}"><span><b>${a === F.from ? '🔘' : '⚪'} ${esc(this.accName(a))}</b></span><em>${fcfa(this.balanceOf(a))}</em></div>`).join('')}</div>
          <button class="ph-go" data-pp="review">VÉRIFIER LE VIREMENT</button>`;
      }
    }
  }
  onClick(b) {
    const [a, ...rest] = b.dataset.pp.split(':'), v = rest.join(':');
    if (this.audio && this.audio.ctx && this.audio.click) this.audio.click();
    if (a === 'led' && this.leds) { const [k, ...r] = rest; this.leds.onApp(k, r.join(':')); return this.refresh(); }
    if (a === 'tab') this.tab = v;
    else if (a === 'chat') { this.sel = v; this.economy.app = 'chat'; }
    else if (a === 'sendtxt') { const el = this.economy.dom.phone.querySelector('.pp-text'), t = el && el.value.trim(); if (t) this.send(this.sel, t.slice(0, 160)); }
    else if (a === 'ins') { this.instruct(this.sel, v || null); }
    else if (a === 'accept') this.accept();
    else if (a === 'refuse') return this.refuse();
    else if (a === 'send') { const c = this.contact(this.sel); if (c) this.send(c.key, QUICK[c.kind][+v]); }
    else if (a === 'call') return this.startCall(v);
    else if (a === 'opt') this.callOption(v);
    else if (a === 'hang') return this.hangup();
    else if (a === 'pay') return this.openTransfer(v);
    else if (this.form) {
      const F = this.form;
      if (a === 'amt') F.amount = +v;
      if (a === 'adj') F.amount = Math.max(5000, Math.min(MAX_TRANSFER, F.amount + (+v)));
      if (a === 'motif') F.motif = v;
      if (a === 'from') F.from = v;
      if (a === 'review') return this.review();
      if (a === 'edit') { F.step = 'edit'; F.token = null; }
      if (a === 'exec') return this.execute(v);
    }
    this.refresh();
  }

  // champ de recherche et saisie de message (le clavier n'agit plus sur le jeu pendant la saisie)
  bindInputs(root) {
    root.addEventListener('input', (e) => { if (!e.target.classList.contains('pp-search')) return; this.q = e.target.value; const pos = e.target.selectionStart; this.refresh(); const el = root.querySelector('.pp-search'); if (el) { el.focus(); el.setSelectionRange(pos, pos); } });
    root.addEventListener('keydown', (e) => { if (e.target.classList.contains('pp-text') && e.key === 'Enter') { e.preventDefault(); const t = e.target.value.trim(); if (t) this.send(this.sel, t.slice(0, 160)); this.refresh(); } });
  }
  // ------------------------------------------------------------------ boucle
  update(dt) {
    const now = performance.now();
    for (let i = this.pending.length - 1; i >= 0; i--) if (now >= this.pending[i].at) { const p = this.pending.splice(i, 1)[0]; this.receive(p.key, p.txt); }
    const C = this.call;
    if (C) {
      C.t += dt;
      if (C.phase === 'incoming') { if ((C.t % 1.6) < dt) this.ring(); if (C.t > 15) { const c = this.contact(C.key); this.hangup(); if (c) this.receive(c.key, 'Appel manqué : je vous rappellerai.'); } }
      else if (C.phase === 'ring') { if ((C.t % 1.6) < dt) this.ring(); if (C.t > 3) { if (C.answers) { C.phase = 'talk'; C.talk = 0; const c = this.contact(C.key); this.say(c && c.kind === 'emp' ? (this.workHours() ? 'Allô, oui PDG ?' : 'Allô ? Bonsoir PDG.') : 'Allô, bonjour !'); } else { C.phase = 'voicemail'; this.refresh(); } } }
      else if (C.phase === 'talk') { C.talk += dt; if (Math.floor(C.talk) !== Math.floor(C.talk - dt) && this.economy.phoneOpen && this.economy.app === 'call') this.refresh(); }
    }
    // message du matin (vers 9 h, une fois par jour de jeu)
    const d = this.economy.day, h = this.env.time;
    if (h >= 9 && h < 10 && this.lastMsgDay !== d) { this.lastMsgDay = d; this.daily(); this.callAt = 11 + Math.random() * 6; }
    if (this.callAt && h >= this.callAt && h < this.callAt + 1 && this.lastCallDay !== d && this.canRing && this.canRing()) { this.lastCallDay = d; this.callAt = null; this.incoming(); }
  }
  serialize() { return { callDay: this.lastCallDay, threads: this.threads, unread: this.unread, calls: this.calls, transfers: this.transfers.map(({ ts, ...t }) => t), praised: this.praised, lastMsgDay: this.lastMsgDay }; }
  restore(s) {
    if (!s) return;
    this.threads = s.threads || {}; this.unread = s.unread || {}; this.calls = s.calls || []; this.transfers = (s.transfers || []).map((t) => ({ ...t, ts: 0 }));
    this.praised = s.praised || {}; this.lastMsgDay = s.lastMsgDay ?? null; this.lastCallDay = s.callDay ?? null;
  }
}
