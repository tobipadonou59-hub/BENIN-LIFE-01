// Mission 017, étape 5 — événements prestigieux et réputation à 7 indicateurs.
// Invitations (cartons) reçues selon la réputation, calendrier (événements + réunions), repère sur la carte,
// chauffeur facultatif, accueil avec contrôle du carton, code vestimentaire, cocktail de boissons SANS ALCOOL,
// rencontres avec des invités (cartes de visite échangées seulement avec leur accord), dîner placé à table,
// moment fort (don, trophée, discours…), photos (appareil acheté à l'étape 1, sinon photographe officiel),
// et réputation détaillée : prestige, élégance, réseau, générosité, fiabilité, professionnalisme, image médiatique.
// Tous les événements, organisateurs, invités et journaux sont fictifs ; les lieux sont des établissements du jeu.
import { fcfa } from './food-data.js';
import { CLOTH_BY_ID } from './clothes.js';
import { avatarSVG, fakePhone } from './social.js';
import { mulberry32 } from './util.js';
import { SKINS } from './character.js';

const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const hh = (h) => `${String(Math.floor(h)).padStart(2, '0')}:${String(Math.round((h % 1) * 60)).padStart(2, '0')}`;
export const REP = [['prestige', 'Prestige', '👑'], ['elegance', 'Élégance', '🎩'], ['reseau', 'Réseau', '🤝'], ['generosite', 'Générosité', '💝'], ['fiabilite', 'Fiabilité', '⏱️'], ['pro', 'Professionnalisme', '💼'], ['medias', 'Image médiatique', '📰']];
const KINDS = {
  gala: { icon: '🥂', title: 'Dîner de gala de la Fondation Lumière du Golfe', org: 'Fondation Lumière du Golfe (fictive)', place: 'hotel', hour: 20, dress: 'Tenue de soirée', moment: 'don', min: 0 },
  trophees: { icon: '🏆', title: 'Cérémonie des Trophées de l’Entreprise du Golfe', org: 'Club des entrepreneurs du Golfe (fictif)', place: 'hotel', hour: 19, dress: 'Tenue de soirée', moment: 'trophee', min: 45 },
  vernissage: { icon: '🖼️', title: 'Vernissage — jeunes artistes contemporains', org: 'Galerie Couleurs du Sud (fictive)', place: 'restaurant', hour: 18.5, dress: 'Élégant décontracté', moment: 'art', min: 0 },
  concert: { icon: '🎻', title: 'Concert caritatif pour les bibliothèques scolaires', org: 'Association Lire à Cotonou (fictive)', place: 'martyrs', hour: 19, dress: 'Élégant décontracté', moment: 'don', min: 0 },
  reception: { icon: '🍽️', title: 'Réception d’affaires de la Chambre des entrepreneurs', org: 'Chambre des entrepreneurs du Golfe (fictive)', place: 'hotel', hour: 19.5, dress: 'Tenue de soirée', moment: 'pitch', min: 40 },
  salon: { icon: '📚', title: 'Soirée d’ouverture du Salon du livre', org: 'Comité du Salon du livre de Cotonou (fictif)', place: 'restaurant', hour: 18, dress: 'Élégant décontracté', moment: 'livres', min: 0 },
};
const VIP_T = [['Président', 'Présidente', 'd’une fondation pour l’éducation'], ['Directeur général', 'Directrice générale', 'd’une banque régionale'], ['Architecte', 'Architecte', 'renommé·e'], ['Rédacteur en chef', 'Rédactrice en chef', 'd’un magazine économique'], ['Investisseur', 'Investisseuse', 'dans les entreprises locales'], ['Artiste peintre', 'Artiste peintre', 'exposé·e à l’international'], ['Directeur', 'Directrice', 'd’un groupe hôtelier'], ['Professeur', 'Professeure', 'd’économie'], ['Fondateur', 'Fondatrice', 'd’une start-up numérique'], ['Chef cuisinier', 'Cheffe cuisinière', 'réputé·e']];
const F_N = ['Nadège', 'Rosine', 'Afiavi', 'Estelle', 'Mariam', 'Carine', 'Gisèle', 'Inès', 'Edwige', 'Sènan'];
const M_N = ['Gildas', 'Romaric', 'Hervé', 'Arnaud', 'Florent', 'Bienvenu', 'Landry', 'Ulrich', 'Comlan', 'Moussa'];
const LAST = ['Zinsou', 'Adjovi', 'Gbaguidi', 'Hounkpatin', 'Akpovi', 'Sossa', 'Alapini', 'Lawani', 'Tossou', 'Houéto'];
const DRINKS = [['bissap', 'Bissap frais', '🌺'], ['baobab', 'Jus de baobab (toédji)', '🥤'], ['ananas', 'Cocktail ananas-gingembre sans alcool', '🍍'], ['citron', 'Citronnade à la menthe', '🍋'], ['eau', 'Eau minérale', '💧']];
const MENU = ['Entrée : salade d’avocat et crevettes de la lagune', 'Plat : poisson braisé, sauce tomate pimentée et amiwo', 'Dessert : salade de fruits tropicaux et glace coco', 'Boissons : bissap, jus de baobab, eau minérale (sans alcool)'];

export class Events {
  constructor(ctx) {
    Object.assign(this, ctx); // venues, ui, economy, env, needs, player, world, wardrobe, social, meetings, ceoLife, tpc, homePos, audio, onSave
    this.list = []; this.uid = 1; this.photos = []; this.rep = { prestige: 35, elegance: 40, reseau: 30, generosite: 35, fiabilite: 55, pro: 45, medias: 25 };
    this.nextInvite = null; this.open = false; this.view = 'inv'; this.sel = null; this.S = null; this.ask = null;
    this.dom = document.querySelector('#evt'); this.dom.addEventListener('click', (e) => this.onClick(e));
  }
  day() { return this.economy.day; }
  now() { return this.env.time; }
  get(id) { return this.list.find((e) => e.id === id) || null; }
  repAdd(k, n) { this.rep[k] = Math.max(0, Math.min(100, Math.round((this.rep[k] + n) * 10) / 10)); }
  score() { return Math.round(REP.reduce((a, [k]) => a + this.rep[k], 0) / REP.length); }
  // ------------------------------------------------------------------ lieux (établissements existants du jeu)
  places(kind) {
    const V = this.venues ? this.venues.list : [];
    if (kind === 'martyrs') { const p = this.ui.pois && this.ui.pois.find((q) => /Martyrs/.test(q.name)); return p ? [{ name: p.name, x: p.x, z: p.z, town: 'Cotonou' }] : []; }
    return V.filter((v) => v.type === kind && v.town !== 'Pahou').map((v) => ({ name: v.name, x: v.x, z: v.z, town: v.town, vid: v.id }));
  }
  // ------------------------------------------------------------------ invitations
  invite(force, wanted) {
    const pending = this.list.filter((e) => e.status === 'invitation').length; if (pending >= 3 && !force) return null;
    const R = mulberry32((this.uid * 7919 + this.day() * 131) >>> 0), score = this.score();
    const busy = new Set(this.list.filter((q) => q.status === 'invitation' || q.status === 'acceptée').map((q) => q.kind)), ok = Object.entries(KINDS).filter(([id, k]) => score >= k.min && !busy.has(id)), kinds = ok.length ? ok : Object.entries(KINDS).filter(([, k]) => score >= k.min), [kid, K] = wanted && KINDS[wanted] ? [wanted, KINDS[wanted]] : kinds[Math.floor(R() * kinds.length)];
    const pl = this.places(K.place); if (!pl.length) return null; const place = pl[Math.floor(R() * pl.length)];
    const vips = Array.from({ length: 3 }, (_, i) => { const f = R() < 0.5, [tm, tf, d] = VIP_T[Math.floor(R() * VIP_T.length)]; return { i, female: f, name: `${(f ? F_N : M_N)[Math.floor(R() * 10)]} ${LAST[Math.floor(R() * 10)]}`, title: `${f ? tf : tm} ${d.replace('·e', f ? 'e' : '')}`, open: R(), skin: SKINS[Math.floor(R() * SKINS.length)], shirt: [0x1a1a1a, 0x5b2c83, 0x0f6a5a, 0x6a1a2a, 0xd8a830][Math.floor(R() * 5)], seed: Math.floor(R() * 1e9) }; });
    const e = { id: this.uid++, kind: kid, title: `${K.title} (événement fictif)`, org: K.org, place, day: this.day() + 1 + Math.floor(R() * 3), hour: K.hour, dress: K.dress, table: 1 + Math.floor(R() * 12), vips, status: 'invitation', received: this.economy.stamp() };
    this.list.unshift(e);
    this.economy.notify(`🎟️ Invitation : ${K.icon} ${e.title} — J${e.day} à ${hh(e.hour)}, ${place.name}`);
    if (this.audio && this.audio.ctx) this.audio.tone(988, 0.12, 0.04, 'sine');
    this.onSave && this.onSave(); return e;
  }
  answer(e, yes) {
    if (!e || e.status !== 'invitation') return;
    if (yes) { e.status = 'acceptée'; this.addMarker(e); this.ui.toast(`✅ Invitation acceptée : ${e.title}. Ajoutée au calendrier et à la carte.`, 3); }
    else { e.status = 'déclinée'; this.ui.toast('Invitation déclinée poliment : l’organisateur te remercie de ta réponse.', 2.5); }
    this.onSave && this.onSave();
  }
  addMarker(e) { const P = this.ui.pois; if (!P || P.some((q) => q.id === `evt:${e.id}`)) return; P.push({ id: `evt:${e.id}`, name: `🎟️ ${KINDS[e.kind].title}`, cat: 'loisirs', x: e.place.x, z: e.place.z, status: 'fictif', access: true, note: `Événement fictif • J${e.day} à ${hh(e.hour)} • ${e.place.name} • code vestimentaire : ${e.dress}` }); this.ui.renderSide && this.ui.renderSide(); }
  dropMarker(e) { const P = this.ui.pois; if (!P) return; const i = P.findIndex((q) => q.id === `evt:${e.id}`); if (i >= 0) { P.splice(i, 1); this.ui.renderSide && this.ui.renderSide(); } }
  window(e) { return e.status === 'acceptée' && e.day === this.day() && this.now() >= e.hour - 0.5 && this.now() <= e.hour + 1.5; }
  // ------------------------------------------------------------------ chauffeur
  chauffeur(e, back) {
    if (this.player.inCar) return this.ui.toast('Gare d’abord ton véhicule : le chauffeur vient te chercher à pied.', 2.5);
    const cost = 15000;
    if (this.economy.balance < cost) return this.ui.toast('Solde personnel insuffisant pour le chauffeur.', 2);
    const tgt = back ? this.homePos : e.place, spot = this.freeSpot(tgt.x, tgt.z); if (!spot) return this.ui.toast('Le chauffeur ne trouve pas où se garer.', 2);
    if (!this.economy.pay(cost, back ? 'Chauffeur privé — retour à la maison' : `Chauffeur privé — ${e.place.name}`, 'Chauffeur')) return;
    this.player.pos.set(spot.x, 0, spot.z); this.player.floorY = 0; if (this.tpc) this.tpc.snap(this.player.pos);
    this.env.time = (this.env.time + 0.35) % 24;
    this.ui.toast(back ? '🚘 Ton chauffeur te dépose devant chez toi. Bonne nuit !' : `🚘 Ton chauffeur t’ouvre la portière devant ${e.place.name}. Le tapis rouge t’attend.`, 3.5);
  }
  freeSpot(x, z) { const C = this.world.collision; for (let r = 3; r <= 12; r += 1.5) for (let a = 0; a < 12; a++) { const px = x + Math.cos(a * 0.52) * r, pz = z + Math.sin(a * 0.52) * r; if (!C.pointBlocked(px, 1, pz)) return { x: px, z: pz }; } return null; }
  nearest(x, z) { // entrée de l'événement (devant le lieu, à l'heure prévue)
    for (const e of this.list) if (this.window(e) && Math.hypot(x - e.place.x, z - e.place.z) < 14) return { d: 0.6, it: { label: () => `🎟️ Entrer : ${KINDS[e.kind].title}`, action: () => this.begin(e) } };
    return null;
  }
  // ------------------------------------------------------------------ soirée
  dressScore() {
    const W = this.wardrobe, c = W && W.cur; if (!c) return { k: 0, txt: 'tenue simple' };
    const ids = [c.tenue, c.veste, c.haut, c.bas, c.pieds].filter(Boolean).map((id) => CLOTH_BY_ID[id]).filter(Boolean), cats = ids.map((q) => q.cat);
    if (cats.includes('luxe')) return { k: 2, txt: 'tenue de luxe remarquée' };
    if (cats.includes('pro') || cats.includes('trad') || (cats.includes('vestes') && !cats.includes('sport'))) return { k: 1, txt: cats.includes('trad') ? 'belle tenue traditionnelle' : 'tenue élégante' };
    if (cats.includes('sport') || cats.includes('tshirts')) return { k: -1, txt: 'tenue trop décontractée pour l’occasion' };
    return { k: 0, txt: 'tenue correcte' };
  }
  begin(e) {
    const late = this.now() - e.hour > 0.25, d = this.dressScore();
    this.S = { e, phase: 'arrivee', late, dress: d, drinks: [], cards: {}, talked: {}, momentDone: false, photos: 0, deltas: {}, ate: false };
    e.status = 'en cours'; this.open = true; this.dom.classList.add('show');
    this.bump('fiabilite', late ? -3 : 2); this.bump('elegance', d.k * 3); this.bump('prestige', 2);
    this.render();
  }
  bump(k, n) { if (!n) return; this.repAdd(k, n); if (this.S) this.S.deltas[k] = (this.S.deltas[k] || 0) + n; }
  photo(subject, official) {
    const S = this.S, e = S.e; if (!official && !this.hasCamera()) return;
    const ph = { id: `${e.id}-${this.photos.length}`, t: this.economy.stamp(), event: e.title, place: e.place.name, subject, official: !!official, seed: (e.id * 97 + this.photos.length * 13) >>> 0, kind: e.kind };
    this.photos.unshift(ph); this.photos.length = Math.min(this.photos.length, 60); S.photos++;
    if (S.photos === 1) this.bump('medias', 2);
    this.ui.toast(`📸 Photo ajoutée à l’album : ${subject}`, 2);
  }
  hasCamera() { return !!(this.economy.items && this.economy.items.eq_photo > 0); }
  photoSVG(ph, w = 150) {
    const R = mulberry32(ph.seed || 1), bg = { gala: '#2a1430', trophees: '#1a1430', vernissage: '#e8e2d6', concert: '#13233a', reception: '#2a1c10', salon: '#1f3a2a' }[ph.kind] || '#222';
    let ppl = ''; const n = 2 + Math.floor(R() * 3);
    for (let i = 0; i < n; i++) { const x = 30 + i * (100 / n) + R() * 8, sk = '#' + SKINS[Math.floor(R() * SKINS.length)].toString(16).padStart(6, '0'), sh = ['#1a1a1a', '#5b2c83', '#0f6a5a', '#d8a830', '#6a1a2a'][Math.floor(R() * 5)]; ppl += `<path d="M${x - 11} 100 Q${x - 10} 70 ${x} 68 Q${x + 10} 70 ${x + 11} 100Z" fill="${sh}"/><circle cx="${x}" cy="58" r="9" fill="${sk}"/>`; }
    return `<svg viewBox="0 0 150 100" width="${w}" class="ev-ph" role="img" aria-label="photo (illustration)"><rect width="150" height="100" fill="${bg}"/>${Array.from({ length: 7 }, (_, i) => `<circle cx="${10 + i * 22}" cy="12" r="3" fill="#fcd116" opacity="0.8"/>`).join('')}<rect x="0" y="86" width="150" height="14" fill="#7a1020"/>${ppl}${ph.official ? '<text x="146" y="96" font-size="7" fill="#fff" text-anchor="end">photo officielle</text>' : ''}</svg>`;
  }
  vipCard(v) { // carte de visite : seulement avec l'accord de l'invité
    const S = this.S, e = S.e; if (S.cards[v.i]) return;
    const chance = 0.25 + v.open * 0.35 + (S.talked[v.i] ? 0.2 : -0.15) + (this.rep.prestige - 40) / 200 + (this.rep.reseau - 30) / 300 + S.dress.k * 0.05;
    const yes = mulberry32((v.seed ^ 0x9e3779b9) >>> 0)() < chance;
    S.cards[v.i] = yes ? 'oui' : 'non';
    if (yes && this.social) {
      const id = `g:${e.id}-${v.i}`, [first, ...rest] = v.name.split(' '), now = this.economy.stamp();
      this.social.book[id] = { id, pid: v.seed, name: v.name, first, last: rest.join(' '), female: v.female, age: 40 + (v.seed % 25), job: v.title, origin: 'Cotonou', hobby: 'les arts et la culture', skin: v.skin, shirt: v.shirt, glasses: v.seed % 3 === 0, prof: 'vip',
        phone: fakePhone(v.seed), email: `${first.toLowerCase().normalize('NFD').replace(/[^a-z]/g, '')}.${rest.join('').toLowerCase().normalize('NFD').replace(/[^a-z]/g, '')}@reseau.example`, address: 'Adresse professionnelle non communiquée', metAt: now, metPlace: `${KINDS[e.kind].title} (${e.place.name})`, consent: now, rapport: 50 + (S.talked[v.i] ? 10 : 0), fav: false, hist: [{ t: now, txt: `Rencontre lors de l’événement : ${e.title} — accord pour échanger les cartes de visite` }] };
      this.bump('reseau', 4);
    }
  }
  moment(choice) {
    const S = this.S, e = S.e, kind = KINDS[e.kind].moment; if (S.momentDone) return;
    if (kind === 'don') {
      const amt = +choice; if (amt > 0) { if (this.economy.balance < amt) return this.ui.toast('Solde personnel insuffisant.', 2); if (!this.economy.pay(amt, `Don — ${KINDS[e.kind].org}`, 'Don caritatif')) return; this.bump('generosite', Math.min(15, 3 + Math.log10(amt / 100000) * 5)); this.bump('prestige', 2); this.bump('medias', 2); S.moment = `Don de ${fcfa(amt)} à ${KINDS[e.kind].org}, prélevé sur le compte personnel.`; } else S.moment = 'Pas de don ce soir.';
    } else if (kind === 'trophee') {
      const win = this.rep.pro >= 55 || (this.ceoLife && this.ceoLife.rep >= 65);
      const sp = { equipe: 'remercie les équipes de NOVA BOOK', vision: 'présente sa vision de l’édition au Bénin', social: 'parle de l’accès aux livres pour tous' }[choice];
      if (win) { this.bump('prestige', 6); this.bump('medias', 5); this.bump('pro', 3); if (this.ceoLife) this.ceoLife.repAdd(3); S.moment = `🏆 NOVA BOOK reçoit le « Trophée de l’innovation éditoriale » (fictif) ; le PDG ${sp}.`; }
      else { this.bump('pro', 2); this.bump('medias', 1); S.moment = `Le trophée revient à une autre entreprise (fictive). NOVA BOOK est nommée ; le PDG ${sp} lors de la table ronde.`; }
    } else if (kind === 'art') {
      if (choice === 'buy') { const amt = 3000000; if (this.economy.balance < amt) return this.ui.toast('Solde personnel insuffisant.', 2); if (!this.economy.pay(amt, 'Œuvre d’art — vernissage (artiste fictif)', 'Galerie')) return; this.economy.addItem && this.economy.addItem('oeuvre_art', 1); this.bump('generosite', 3); this.bump('prestige', 3); S.moment = `Achat d’une toile d’un jeune artiste (${fcfa(amt)}, compte personnel) : soutien aux artistes.`; }
      else { this.bump('reseau', 1); S.moment = 'Visite commentée de l’exposition avec les artistes.'; }
    } else if (kind === 'pitch') {
      this.bump('pro', choice === 'chiffres' ? 4 : 3); this.bump('reseau', 2);
      if (this.meetings && this.meetings.company) { const C = this.meetings.company; C.offers.length = Math.min(C.offers.length, 4); C.refreshOffers(); }
      S.moment = `Présentation de NOVA BOOK aux entrepreneurs (${choice === 'chiffres' ? 'résultats chiffrés' : 'vision et valeurs'}) : une nouvelle demande de client arrive dans NOVA Gestion.`;
    } else if (kind === 'livres') {
      this.bump('pro', 3); this.bump('medias', 3); if (this.ceoLife) this.ceoLife.repAdd(2);
      S.moment = choice === 'dedicace' ? 'Séance de dédicace des auteurs de NOVA BOOK : les lecteurs font la queue !' : 'Le PDG présente la nouvelle collection de NOVA BOOK au public.';
    }
    S.momentDone = true; this.render();
  }
  finish() {
    const S = this.S, e = S.e;
    e.status = 'terminée'; e.report = { deltas: S.deltas, moment: S.moment || '', cards: Object.values(S.cards).filter((v) => v === 'oui').length, photos: S.photos, dress: S.dress.txt, late: S.late };
    this.dropMarker(e); this.env.time = Math.min(23.9, this.env.time + 2.5);
    const paper = ['La Gazette du Golfe (journal fictif)', 'Le Quotidien des Affaires (fictif)', 'Bénin Culture Magazine (fictif)'][e.id % 3];
    if (S.deltas.medias > 0 || S.dress.k > 0) { this.bump('medias', 2); this.economy.notify(`📰 ${paper} : « Le PDG de NOVA BOOK remarqué à l’événement ${KINDS[e.kind].title}${S.dress.k > 0 ? `, dans une ${S.dress.txt}` : ''}. »`); }
    if (this.ceoLife) this.ceoLife.repAdd(1);
    this.S = null; this.view = 'rep'; this.render(); this.onSave && this.onSave();
  }
  // ------------------------------------------------------------------ interface
  show(view = 'inv') { this.open = true; this.view = view; this.dom.classList.add('show'); this.render(); }
  close() { if (this.S) return this.ui.toast('Tu es à l’événement : utilise « Quitter la soirée ».', 2.5); this.open = false; this.dom.classList.remove('show'); this.onSave && this.onSave(); }
  card(e) {
    const K = KINDS[e.kind];
    return `<div class="ev-card"><small>${esc(e.org)}</small><p>a l’honneur d’inviter</p><b>Monsieur / Madame le PDG de NOVA BOOK</b><p>à la</p><h3>${K.icon} ${esc(K.title)}</h3><p>le <b>J${e.day}</b> à <b>${hh(e.hour)}</b><br>${esc(e.place.name)} — ${esc(e.place.town)}</p><p class="ev-dress">Code vestimentaire : ${esc(e.dress)} • Table n° ${e.table}</p><small>Invitation nominative • événement fictif • boissons sans alcool</small></div>`;
  }
  repBars() { return `<div class="ev-rep">${REP.map(([k, l, ic]) => `<div><span>${ic} ${l}</span><i><b style="width:${this.rep[k]}%"></b></i><em>${Math.round(this.rep[k])}</em></div>`).join('')}</div><p class="ve-note">Réputation globale : <b>${this.score()}/100</b>. Elle détermine les invitations reçues (les Trophées et les réceptions d’affaires demandent une réputation d’au moins 40–45).</p>`; }
  render() {
    if (!this.open) return;
    if (this.S) return this.renderSession();
    const tabs = [['inv', '🎟️ Invitations'], ['cal', '📅 Calendrier'], ['album', '📸 Album'], ['rep', '⭐ Réputation']];
    let b = '';
    if (this.view === 'inv') {
      const inv = this.list.filter((e) => e.status === 'invitation');
      b = inv.map((e) => `${this.card(e)}<div class="mt-chips ev-act"><button class="on" data-ev="yes:${e.id}">✅ Accepter</button><button data-ev="no:${e.id}">Décliner poliment</button></div>`).join('') || '<p class="ve-note">Aucune invitation en attente. Les invitations arrivent régulièrement selon ta réputation (environ tous les 2 jours).</p>';
    } else if (this.view === 'cal') {
      const ev = this.list.filter((e) => e.status === 'acceptée').map((e) => ({ day: e.day, hour: e.hour, html: `<div class="ve-row"><span><b>${KINDS[e.kind].icon} ${esc(KINDS[e.kind].title)}</b><small>J${e.day} à ${hh(e.hour)} • ${esc(e.place.name)} • ${esc(e.dress)} • repère 🎟️ sur la carte</small></span><span class="mt-chips">${this.window(e) || (e.day === this.day() && this.now() >= e.hour - 1.5 && this.now() <= e.hour + 1.5) ? `<button data-ev="drive:${e.id}">🚘 Chauffeur privé, trajet direct (15 000 FCFA)</button>` : ''}${this.driver ? `<button data-ev="limo:${e.id}">🚘 Ma limousine (Augustin)</button>` : ''}<button data-ev="route:${e.id}">🧭 Itinéraire</button></span></div>` }));
      const mt = this.meetings ? this.meetings.list.filter((m) => m.status === 'prévue').map((m) => ({ day: m.day, hour: m.hour, html: `<div class="ve-row dim"><span><b>📅 ${esc(m.title)}</b><small>Réunion • J${m.day} à ${hh(m.hour)} • ${esc(this.meetings.roomInfo(m.room).short)}</small></span></div>` })) : [];
      const all = [...ev, ...mt].sort((a, c) => a.day - c.day || a.hour - c.hour);
      b = `<p class="ve-note">Aujourd’hui : J${this.day()} • ${this.env.clock}. Le chauffeur est disponible à partir d’une heure et demie avant l’événement.</p>${all.map((x) => x.html).join('') || '<p class="ve-note">Rien de prévu.</p>'}<h5>Événements passés</h5>${this.list.filter((e) => ['terminée', 'manquée', 'déclinée'].includes(e.status)).slice(0, 8).map((e) => `<div class="ve-row dim"><span><b>${esc(KINDS[e.kind].title)}</b><small>J${e.day} • ${e.status}${e.report && e.report.moment ? ` • ${esc(e.report.moment)}` : ''}</small></span></div>`).join('') || '<p class="ve-note">—</p>'}`;
    } else if (this.view === 'album') {
      b = `<p class="ve-note">${this.hasCamera() ? '📷 Appareil photo professionnel : prêt.' : 'Pas d’appareil photo : seul le photographe officiel te prend en photo (1 par événement). L’appareil s’achète dans Achats (téléphone).'}</p><div class="ev-album">${this.photos.map((p) => `<figure>${this.photoSVG(p)}<figcaption>${esc(p.subject)}<small>${esc(p.t)} • ${esc(p.place)}</small></figcaption></figure>`).join('') || '<p class="ve-note">Album vide.</p>'}</div>`;
    } else b = this.repBars();
    this.dom.innerHTML = `<div class="tk-box mt-box"><div class="tk-head"><h2>🎟️ Événements & réputation</h2><button data-ev="x">✕</button></div><div class="mt-chips">${tabs.map(([k, l]) => `<button data-ev="tab:${k}" class="${this.view === k ? 'on' : ''}">${l}</button>`).join('')}</div><div class="mt-body">${b}</div></div>`;
  }
  renderSession() {
    const S = this.S, e = S.e, K = KINDS[e.kind], steps = [['arrivee', 'Accueil'], ['cocktail', 'Cocktail'], ['diner', 'Dîner'], ['moment', 'Moment fort'], ['photos', 'Photos'], ['depart', 'Départ']];
    let b = '';
    if (S.phase === 'arrivee') b = `<p class="ve-note">🟥 Tapis rouge devant ${esc(e.place.name)}. L’hôtesse vérifie ton carton d’invitation.</p>${this.card(e)}<div class="ve-row"><span><b>Hôtesse d’accueil</b><small>« Bienvenue ! Votre table est la n° ${e.table}. ${S.late ? 'La soirée a déjà commencé, mais entrez je vous prie.' : 'Vous êtes parmi les premiers invités.'} »</small></span></div><div class="ve-row"><span><b>Tenue : ${esc(S.dress.txt)}</b><small>Code demandé : ${esc(e.dress)}${S.dress.k < 0 ? ' — l’hôtesse sourit poliment… (élégance −3)' : S.dress.k > 0 ? ' — plusieurs invités te complimentent' : ''}</small></span></div>`;
    else if (S.phase === 'cocktail') b = `<h5>Bar à boissons (toutes sans alcool, offertes)</h5><div class="mt-chips">${DRINKS.map(([k, l, ic]) => `<button data-ev="drink:${k}" ${S.drinks.includes(k) ? 'disabled' : ''}>${ic} ${l}</button>`).join('')}</div>
      <h5>Invités présents</h5>${e.vips.map((v) => `<div class="ve-row">${avatarSVG({ ...v, age: 45 }, 40)}<span><b>${esc(v.name)}</b><small>${esc(v.title)} (personnage fictif)${S.talked[v.i] ? ` • « ${esc(S.talked[v.i])} »` : ''}</small></span><span class="mt-chips"><button data-ev="talk:${v.i}" ${S.talked[v.i] ? 'disabled' : ''}>💬 Échanger</button>${S.cards[v.i] === 'oui' ? '<em class="pos">📇 carte échangée</em>' : S.cards[v.i] === 'non' ? '<em class="neg">refus respecté</em>' : `<button data-ev="cardv:${v.i}">📇 Proposer d’échanger les cartes</button>`}</span></div>`).join('')}
      <p class="ve-note">Les cartes de visite ne sont échangées qu’avec l’accord de l’invité ; un refus est respecté.</p>`;
    else if (S.phase === 'diner') b = `<h5>Table n° ${e.table}</h5><svg viewBox="0 0 200 120" class="mt-plan"><circle cx="100" cy="60" r="34" fill="#f6f1e6" stroke="#d8a830" stroke-width="3"/>${['Toi (PDG)', ...e.vips.map((v) => v.name.split(' ')[0]), 'Invité', 'Invitée'].map((n, i, a) => { const ang = (i / a.length) * Math.PI * 2 - Math.PI / 2, x = 100 + Math.cos(ang) * 50, y = 60 + Math.sin(ang) * 44; return `<circle cx="${x}" cy="${y}" r="9" fill="${i === 0 ? '#fcd116' : '#1f4e9c'}"/><text x="${x}" y="${y + (y > 60 ? 19 : -12)}" font-size="8" text-anchor="middle">${esc(n)}</text>`; }).join('')}<text x="100" y="63" font-size="9" text-anchor="middle">Table ${e.table}</text></svg>
      <div class="mt-slide"><h3>Menu</h3>${MENU.map((l) => `<p class="ve-note">${esc(l)}</p>`).join('')}</div><button data-ev="eat" ${S.ate ? 'disabled' : ''}>${S.ate ? 'Repas savouré ✓' : '🍽️ Savourer le dîner'}</button>`;
    else if (S.phase === 'moment') {
      const m = K.moment, done = S.momentDone;
      const opts = m === 'don' ? [[0, 'Ne pas donner'], [500000, 'Don de 500 000 FCFA'], [5000000, 'Don de 5 000 000 FCFA'], [50000000, 'Don de 50 000 000 FCFA']].map(([v, l]) => `<button data-ev="mom:${v}">${l}</button>`).join('')
        : m === 'trophee' ? [['equipe', 'Discours : remercier les équipes'], ['vision', 'Discours : vision de l’édition'], ['social', 'Discours : les livres pour tous']].map(([v, l]) => `<button data-ev="mom:${v}">${l}</button>`).join('')
          : m === 'art' ? '<button data-ev="mom:buy">Acheter une toile (3 000 000 FCFA, compte perso)</button><button data-ev="mom:visit">Visite commentée seulement</button>'
            : m === 'pitch' ? '<button data-ev="mom:chiffres">Présenter les résultats chiffrés</button><button data-ev="mom:vision">Présenter la vision et les valeurs</button>'
              : '<button data-ev="mom:dedicace">Organiser une séance de dédicace</button><button data-ev="mom:collection">Présenter la nouvelle collection</button>';
      b = `<h5>${{ don: '💝 Appel aux dons de l’organisateur', trophee: '🏆 Remise des trophées', art: '🖼️ Exposition', pitch: '💼 Prise de parole des entrepreneurs', livres: '📚 Ouverture du salon' }[m]}</h5>${done ? `<div class="ve-row"><span><b>${esc(S.moment)}</b></span></div>` : `<div class="mt-chips mt-col">${opts}</div>${m === 'don' ? '<p class="ve-note">Le don est prélevé sur ton compte personnel (monnaie fictive), jamais sur celui des entreprises.</p>' : ''}`}`;
    } else if (S.phase === 'photos') b = `<p class="ve-note">${this.hasCamera() ? '📷 Ton appareil photo professionnel est prêt.' : 'Tu n’as pas d’appareil photo (il s’achète dans le téléphone › Achats). Le photographe officiel te propose une photo.'}</p><div class="mt-chips">${this.hasCamera() ? [['Photo avec les organisateurs', 'org'], ['Photo de la table', 'table'], ['Photo de la salle décorée', 'salle'], ...e.vips.map((v) => [`Photo avec ${v.name}`, `v${v.i}`])].map(([l, k]) => `<button data-ev="ph:${k}" data-l="${esc(l)}">📸 ${esc(l)}</button>`).join('') : ''}<button data-ev="phoff">🎞️ Photo officielle (photographe)</button></div><div class="ev-album">${this.photos.filter((p) => p.event === e.title).slice(0, 6).map((p) => `<figure>${this.photoSVG(p, 120)}<figcaption>${esc(p.subject)}</figcaption></figure>`).join('')}</div>`;
    else b = `<h5>Fin de soirée</h5><p class="ve-note">L’organisateur te remercie de ta présence.${S.moment ? ` ${esc(S.moment)}` : ''}</p><div class="ev-rep">${REP.map(([k, l, ic]) => `<div><span>${ic} ${l}</span><i><b style="width:${this.rep[k]}%"></b></i><em>${Math.round(this.rep[k])}${S.deltas[k] ? ` (${S.deltas[k] > 0 ? '+' : ''}${Math.round(S.deltas[k] * 10) / 10})` : ''}</em></div>`).join('')}</div><div class="mt-chips"><button class="on" data-ev="leave:home">🚘 Rentrer avec le chauffeur (15 000 FCFA)</button><button data-ev="leave:walk">Sortir à pied</button></div>`;
    const idx = steps.findIndex(([k]) => k === S.phase), nxt = steps[idx + 1];
    this.dom.innerHTML = `<div class="tk-box mt-box"><div class="tk-head"><h2>${K.icon} ${esc(K.title)}</h2></div><div class="ev-steps">${steps.map(([k, l], i) => `<span class="${i <= idx ? 'on' : ''}">${l}</span>`).join('')}</div><div class="mt-body">${b}${nxt ? `<button class="sc-save" data-ev="step:${nxt[0]}">${nxt[1]} →</button>` : ''}</div></div>`;
  }
  onClick(ev) {
    const b = ev.target.closest('[data-ev]'); if (!b) { if (ev.target === this.dom) this.close(); return; }
    ev.stopPropagation(); const raw = b.dataset.ev, i = raw.indexOf(':'), a = i < 0 ? raw : raw.slice(0, i), v = i < 0 ? '' : raw.slice(i + 1), S = this.S;
    if (a === 'x') return this.close();
    if (a === 'tab') this.view = v;
    else if (a === 'yes' || a === 'no') this.answer(this.get(+v), a === 'yes');
    else if (a === 'drive') { const e = this.get(+v); if (e) { this.chauffeur(e); this.open = false; this.dom.classList.remove('show'); return; } }
    else if (a === 'limo' && this.driver) { const e = this.get(+v); if (e) { this.open = false; this.dom.classList.remove('show'); this.driver.toDest({ id: `evt:${e.id}`, label: e.title.replace(' (événement fictif)', ''), x: e.place.x, z: e.place.z }); return; } }
    else if (a === 'route') { const e = this.get(+v), p = e && this.ui.pois.find((q) => q.id === `evt:${e.id}`); if (p && this.ui.setRoute) { this.ui.setRoute(p); this.ui.toast(`🧭 Itinéraire vers ${e.place.name}`, 2); } }
    else if (S && a === 'step') S.phase = v;
    else if (S && a === 'drink') { S.drinks.push(v); if (this.needs) this.needs.hunger = Math.min(100, this.needs.hunger + 3); this.ui.toast(`${DRINKS.find((d) => d[0] === v)[1]} — sans alcool, bien frais.`, 1.8); }
    else if (S && a === 'talk') { const x = S.e.vips[+v]; S.talked[x.i] = ['Ravi·e de vous rencontrer ! J’ai entendu parler de NOVA BOOK.', 'Belle soirée, n’est-ce pas ? Que pensez-vous du marché du livre ?', 'Votre maison d’édition fait du bon travail, continuez !'][x.seed % 3].replace('Ravi·e', x.female ? 'Ravie' : 'Ravi'); this.bump('reseau', 2); }
    else if (S && a === 'cardv') this.vipCard(S.e.vips[+v]);
    else if (S && a === 'eat') { S.ate = true; if (this.needs) { this.needs.hunger = Math.min(100, this.needs.hunger + 45); } this.bump('elegance', 1); }
    else if (S && a === 'mom') return this.moment(v);
    else if (S && a === 'ph') this.photo(b.dataset.l || 'Photo');
    else if (S && a === 'phoff') { if (S.official) return this.ui.toast('Le photographe officiel t’a déjà pris en photo.', 1.8); S.official = true; this.photo('Photo officielle sur le tapis rouge', true); }
    else if (S && a === 'leave') { const e = S.e; this.finish(); this.open = false; this.dom.classList.remove('show'); if (v === 'home') this.chauffeur(e, true); return; }
    this.render();
  }
  handleKeys(input) { if (input.hit('Escape')) this.close(); }
  // ------------------------------------------------------------------ téléphone
  renderApp(b) {
    const inv = this.list.filter((e) => e.status === 'invitation').length, next = this.list.filter((e) => e.status === 'acceptée').sort((x, y) => x.day - y.day || x.hour - y.hour)[0];
    b.innerHTML = `<h4>🎟️ Événements</h4><div class="ph-list"><div class="ph-row"><span><b>${inv} invitation(s) en attente</b><small>${next ? `Prochain : ${esc(KINDS[next.kind].title)} — J${next.day} ${hh(next.hour)}` : 'Aucun événement accepté'}</small></span></div><div class="ph-row"><span><b>Réputation globale : ${this.score()}/100</b><small>${REP.map(([k, , ic]) => `${ic} ${Math.round(this.rep[k])}`).join(' ')}</small></span></div></div><button class="ph-go" data-evp="open">Ouvrir invitations, calendrier, album</button>`;
  }
  // ------------------------------------------------------------------ boucle
  update() {
    const d = this.day(), h = this.now();
    if (this.nextInvite === null) this.nextInvite = { day: d, h: Math.min(22, h + 0.5) }; // première invitation peu après le début
    if (d > this.nextInvite.day || (d === this.nextInvite.day && h >= this.nextInvite.h)) { this.invite(); this.nextInvite = { day: d + 2, h: 9 + ((d * 37) % 9) }; this.onSave && this.onSave(); }
    for (const e of this.list) {
      if (e.status === 'invitation' && (d > e.day || (d === e.day && h > e.hour))) { e.status = 'sans réponse'; this.bump('fiabilite', -2); }
      if (e.status === 'acceptée' && !e.reminded && e.day === d && h >= e.hour - 2) { e.reminded = true; this.economy.notify(`🎟️ Ce soir à ${hh(e.hour)} : ${KINDS[e.kind].title} — ${e.place.name} (code : ${e.dress}). Chauffeur disponible dans Événements › Calendrier.`); }
      if (e.status === 'acceptée' && (d > e.day || (d === e.day && h > e.hour + 1.5))) { e.status = 'manquée'; this.dropMarker(e); this.bump('fiabilite', -8); this.bump('prestige', -3); this.economy.notify(`⚠️ Événement manqué après l’avoir accepté : ${KINDS[e.kind].title}. L’organisateur est déçu (fiabilité −8).`); this.onSave && this.onSave(); }
    }
  }
  serialize() { return { list: this.list.slice(0, 40), uid: this.uid, photos: this.photos, rep: this.rep, nextInvite: this.nextInvite }; }
  restore(s) {
    if (!s) return; this.list = s.list || []; this.uid = s.uid || 1; this.photos = s.photos || []; this.rep = { ...this.rep, ...(s.rep || {}) }; this.nextInvite = s.nextInvite || null;
    for (const e of this.list) { if (e.status === 'en cours') e.status = 'terminée'; if (e.status === 'acceptée') this.addMarker(e); }
  }
}
