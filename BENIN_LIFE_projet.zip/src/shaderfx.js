// Petites extensions de shaders : variation macro anti-répétition, vent dans la végétation.
import * as THREE from 'three';

export const globalUniforms = { uTime: { value: 0 }, uWet: { value: 0 } };

let macroTex = null;
function getMacro() {
  if (macroTex) return macroTex;
  // bruit basse fréquence raccordable
  const s = 256, c = document.createElement('canvas');
  c.width = c.height = s;
  const x = c.getContext('2d');
  const img = x.createImageData(s, s);
  const g = (n) => { const a = new Float32Array(n * n); for (let i = 0; i < a.length; i++) a[i] = Math.random(); return a; };
  const layers = [[4, 0.5], [8, 0.25], [16, 0.15], [32, 0.1]].map(([n, w]) => [n, w, g(n)]);
  for (let j = 0; j < s; j++) for (let i = 0; i < s; i++) {
    let v = 0;
    for (const [n, w, a] of layers) {
      const fx = (i / s) * n, fy = (j / s) * n;
      const x0 = Math.floor(fx), y0 = Math.floor(fy), tx = fx - x0, ty = fy - y0;
      const sx = tx * tx * (3 - 2 * tx), sy = ty * ty * (3 - 2 * ty);
      const at = (X, Y) => a[((Y % n) + n) % n * n + ((X % n) + n) % n];
      v += w * ((at(x0, y0) * (1 - sx) + at(x0 + 1, y0) * sx) * (1 - sy) + (at(x0, y0 + 1) * (1 - sx) + at(x0 + 1, y0 + 1) * sx) * sy);
    }
    const o = (j * s + i) * 4;
    img.data[o] = img.data[o + 1] = img.data[o + 2] = v * 255; img.data[o + 3] = 255;
  }
  x.putImageData(img, 0, 0);
  macroTex = new THREE.CanvasTexture(c);
  macroTex.wrapS = macroTex.wrapT = THREE.RepeatWrapping;
  return macroTex;
}

// Module la couleur selon un bruit en coordonnées monde : casse la répétition des textures au sol.
// wetK : sensibilité à la pluie (assombrissement + flaques brillantes), 0 = insensible
export function addMacroVariation(mat, scale = 0.02, strength = 0.25, tint = null, wetK = 0.6) {
  const tex = getMacro();
  const prev = mat.onBeforeCompile;
  mat.onBeforeCompile = (sh, r) => {
    if (prev) prev(sh, r);
    sh.uniforms.uMacro = { value: tex };
    sh.uniforms.uMacroScale = { value: scale };
    sh.uniforms.uMacroStr = { value: strength };
    sh.uniforms.uMacroTint = { value: tint ? new THREE.Color(tint) : new THREE.Color(1, 1, 1) };
    sh.uniforms.uWet = globalUniforms.uWet;
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec2 vMacroUv;')
      .replace('#include <begin_vertex>', '#include <begin_vertex>\nvMacroUv = (modelMatrix * vec4(position, 1.0)).xz;');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nvarying vec2 vMacroUv;\nuniform sampler2D uMacro;\nuniform float uMacroScale;\nuniform float uMacroStr;\nuniform vec3 uMacroTint;\nuniform float uWet;')
      .replace('#include <map_fragment>', `#include <map_fragment>
        float mv = texture2D(uMacro, vMacroUv * uMacroScale).r * 0.65 + texture2D(uMacro, vMacroUv * uMacroScale * 4.3).r * 0.35;
        diffuseColor.rgb *= mix(vec3(1.0), mix(vec3(1.0 - uMacroStr), vec3(1.0 + uMacroStr * 0.6), mv) * mix(vec3(1.0), uMacroTint, smoothstep(0.55, 0.8, mv)), 1.0);
        // sol mouillé : plus sombre, flaques dans les creux du bruit
        float wetAmt = uWet * ${wetK.toFixed(2)};
        float puddle = smoothstep(0.44, 0.32, mv) * smoothstep(0.15, 0.6, uWet);
        diffuseColor.rgb *= mix(1.0, 0.6, wetAmt) * mix(1.0, 0.78, wetAmt * puddle);`)
      .replace('#include <roughnessmap_fragment>', `#include <roughnessmap_fragment>
        roughnessFactor = mix(roughnessFactor, mix(0.38, 0.05, puddle), clamp(wetAmt * 1.3, 0.0, 1.0));`);
  };
  mat.customProgramCacheKey = () => 'macro' + scale + strength + (tint || '') + 'w' + wetK;
  return mat;
}

// Balancement au vent (feuillages instanciés) : déplacement proportionnel à la hauteur locale.
export function addWind(mat, amp = 0.15, minY = 2) {
  const prev = mat.onBeforeCompile;
  mat.onBeforeCompile = (sh, r) => {
    if (prev) prev(sh, r);
    sh.uniforms.uTime = globalUniforms.uTime;
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nuniform float uTime;')
      .replace('#include <begin_vertex>', `#include <begin_vertex>
        {
          float h = max(0.0, position.y - ${minY.toFixed(2)});
          #ifdef USE_INSTANCING
            float ph = instanceMatrix[3].x * 0.37 + instanceMatrix[3].z * 0.23;
          #else
            float ph = 0.0;
          #endif
          float w = sin(uTime * 1.3 + ph) * 0.6 + sin(uTime * 2.7 + ph * 1.7 + position.x) * 0.4;
          transformed.x += w * h * ${amp.toFixed(3)} * 0.1;
          transformed.z += cos(uTime * 1.1 + ph) * h * ${amp.toFixed(3)} * 0.06;
          transformed.y += sin(uTime * 3.1 + position.x * 2.0 + ph) * h * ${amp.toFixed(3)} * 0.02;
        }`);
  };
  mat.customProgramCacheKey = () => 'wind' + amp + minY;
  return mat;
}
