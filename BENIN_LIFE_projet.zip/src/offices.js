// Mission 016, phase 5 — sièges visitables des 5 sociétés du groupe NOVA (DIGITAL, MEDIA, IMMOBILIER, TRANSPORT,
// DISTRIBUTION) : entrée signalée par une enseigne lumineuse sur l'immeuble réservé, intérieur aménagé construit à la
// demande (réception, espace de travail, bureau vitré du directeur, salle de réunion, équipements du métier, LED),
// employés réels de la société (gestion du groupe), supervision par le PDG. L'intérieur est placé en hauteur avec des
// collisions isolées (niveau ≥ 100) : il ne gêne rien dans la ville.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { createCharacter, SKINS } from './character.js';
import { SUBS, INSTR } from './group.js';
import { JOBS } from './nova-data.js';
import { fcfa } from './food-data.js';

const PI = Math.PI;
const ACCENT = { digital: 0x2f80ed, media: 0x7a2a8a, immo: 0x0b6e4f, transport: 0xe46a1f, distribution: 0xc8a020 };
const FLOORC = { digital: 0x5a6470, media: 0x3a3440, immo: 0x8a6a4c, transport: 0x6c727c, distribution: 0x8e877c };
const FEMALE = new Set(['Sika', 'Estelle', 'Akouavi', 'Ornella', 'Nadia', 'Yolande', 'Huguette', 'Rachelle']);
const EQUIP = {
  digital: 'Salle serveurs et écran de développement', media: 'Studio de tournage (fond vert, caméras, éclairages)', immo: 'Maquettes et annonces de biens',
  transport: 'Écran de suivi des véhicules et des livraisons', distribution: 'Entrepôt : rayonnages, palettes et table d’emballage',
};
const DESKS = [[-11, -5], [-8, -5], [-5, -5], [-2, -5], [-11, -1.5], [-8, -1.5], [-5, -1.5], [-2, -1.5]];
function colored(geo, hex) {
  const g = geo.index ? geo.toNonIndexed() : geo, c = new THREE.Color(hex), n = g.attributes.position.count, a = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { a[i * 3] = c.r; a[i * 3 + 1] = c.g; a[i * 3 + 2] = c.b; }
  g.setAttribute('color', new THREE.BufferAttribute(a, 3)); if (g.attributes.uv) g.deleteAttribute('uv'); return g;
}
function canvasTex(w, h, draw) { const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; return t; }
const hexCss = (h) => `#${h.toString(16).padStart(6, '0')}`;

export class Offices {
  constructor(ctx) {
    Object.assign(this, ctx); // scene, world, ui, audio, player, group, bizUI, home, env, leds, pois, onSave
    this.mats = {
      std: new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.7, emissive: 0x2a2826, emissiveIntensity: 1 }),
      shiny: new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.2, metalness: 0.35, emissive: 0x1a1a1a, emissiveIntensity: 1 }),
      glow: new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false }),
      glass: new THREE.MeshStandardMaterial({ color: 0x9fc4d8, roughness: 0.05, metalness: 0.2, transparent: true, opacity: 0.28, depthWrite: false }),
    };
    this.led = this.leds ? this.leds.mats.filiales : new THREE.MeshBasicMaterial({ color: 0xdcefff, toneMapped: false });
    this.sign = this.leds ? this.leds.mats.enseignes : this.led;
    this.sites = []; this.inside = -1; this.points = []; this.people = [];
  }
  // appelé une fois les lieux de la carte chargés (immeubles réservés aux sociétés du groupe)
  init(pois) {
    this.pois = pois; if (this.sites.length) return;
    SUBS.forEach((d, i) => this.placeSite(d, i));
  }
  // ------------------------------------------------------------------ entrée sur l'immeuble réservé
  placeSite(def, i) {
    const poi = (this.pois || []).find((p) => p.name === def.name); if (!poi) return;
    const f = (this.world.footprints || []).find((q) => poi.x >= q[0] && poi.x <= q[2] && poi.z >= q[1] && poi.z <= q[3]);
    const fp = f || [poi.x - 8, poi.z - 8, poi.x + 8, poi.z + 8];
    const cx = (fp[0] + fp[2]) / 2, cz = (fp[1] + fp[3]) / 2, col = this.world.collision;
    const faces = [[cx, fp[3], 0, 1], [cx, fp[1], 0, -1], [fp[2], cz, 1, 0], [fp[0], cz, -1, 0]];
    let best = null;
    const lv = col.level; col.level = 0;
    for (const [fx, fz, nx, nz] of faces) {
      let score = 0; for (const d of [1.4, 3, 5, 7]) if (!col.pointBlocked(fx + nx * d, 0.5, fz + nz * d)) score++;
      if (!best || score > best.score) best = { fx, fz, nx, nz, score };
    }
    col.level = lv;
    const ry = Math.atan2(best.nx, best.nz), out = { x: best.fx + best.nx * 1.5, z: best.fz + best.nz * 1.5 };
    const site = { def, i, id: def.id, cx, cz, out, ry, Y: 400 + i * 8, lv: 100 + i, built: null };
    // enseigne lumineuse + porte vitrée sur la façade
    const g = new THREE.Group(); this.scene.add(g); site.door = g;
    const wx = best.fx + best.nx * 0.12, wz = best.fz + best.nz * 0.12;
    const signMat = new THREE.MeshBasicMaterial({ map: canvasTex(512, 128, (x, w, h) => { x.fillStyle = '#0b1220'; x.fillRect(0, 0, w, h); x.fillStyle = hexCss(ACCENT[def.id]); x.fillRect(0, 0, 14, h); x.fillStyle = '#fff'; x.font = '900 52px Arial'; x.fillText(def.name, 34, 64); x.fillStyle = '#f2c200'; x.font = '700 24px Arial'; x.fillText(def.sector, 34, 102); }), toneMapped: false });
    const sp = new THREE.Mesh(new THREE.PlaneGeometry(4.4, 1.1), signMat); sp.position.set(wx, 3.3, wz); sp.rotation.y = ry; g.add(sp);
    const fr = []; const lx = Math.cos(ry), lz = -Math.sin(ry);
    for (const [u0, y0, u1, y1] of [[-2.25, 2.72, 2.25, 2.75], [-2.25, 3.86, 2.25, 3.89], [-2.25, 2.72, -2.22, 3.89], [2.22, 2.72, 2.25, 3.89]]) fr.push(new THREE.BoxGeometry(Math.max(0.03, Math.abs(u1 - u0)), y1 - y0, 0.04).rotateY(ry).translate(wx + lx * (u0 + u1) / 2 + best.nx * 0.03, (y0 + y1) / 2, wz + lz * (u0 + u1) / 2 + best.nz * 0.03));
    g.add(new THREE.Mesh(mergeGeometries(fr), this.sign));
    const dm = new THREE.Mesh(new THREE.PlaneGeometry(1.8, 2.3), new THREE.MeshBasicMaterial({ color: 0x6a8ea8, toneMapped: false, transparent: true, opacity: 0.85 })); dm.position.set(wx + best.nx * 0.02, 1.15, wz + best.nz * 0.02); dm.rotation.y = ry; g.add(dm);
    this.sites.push(site);
  }
  sub(site) { return this.group && this.group.subs[site.id]; }
  // ------------------------------------------------------------------ intérieur (construit à la première visite)
  build(site) {
    const id = site.id, O = { x: site.cx, y: site.Y, z: site.cz }, P = { std: [], shiny: [], glow: [], led: [] }, col = this.world.collision;
    const box = (w, h, d, x, y, z, c, k = 'std') => P[k].push(colored(new THREE.BoxGeometry(w, h, d).translate(O.x + x, O.y + y, O.z + z), c));
    const solid = (x0, z0, x1, z1, h = 3) => { const o = col.addBox(O.x + x0, O.z + z0, O.x + x1, O.z + z1, O.y + h); o.lv = site.lv; };
    const A = ACCENT[id], W = 0xeceae4;
    const g = new THREE.Group(); this.scene.add(g);
    // sol, plafond, murs (porte au sud), fenêtres, éclairage
    box(26, 0.1, 18, 0, 0.05, 0, FLOORC[id]); // pas de plafond : vue en coupe comme la maison et NOVA BOOK
    box(26.4, 3.6, 0.2, 0, 1.8, -9.1, W); box(0.2, 3.6, 18, -13.1, 1.8, 0, W); box(0.2, 3.6, 18, 13.1, 1.8, 0, W);
    box(11.8, 3.6, 0.2, -7.2, 1.8, 9.1, W); box(11.8, 3.6, 0.2, 7.2, 1.8, 9.1, W); box(2.4, 1.2, 0.2, 0, 3.0, 9.1, W);
    solid(-13.2, -9.2, 13.2, -9.0); solid(-13.2, -9.2, -13.0, 9.2); solid(13.0, -9.2, 13.2, 9.2); solid(-13.2, 9.0, -1.2, 9.2); solid(1.2, 9.0, 13.2, 9.2);
    box(2.3, 2.3, 0.05, 0, 1.15, 9.0, 0x6a8ea8, 'glow');
    for (const x of [-12.98, 12.98]) for (const z of [-4, 4]) box(0.03, 1.4, 3, x, 1.9, z, 0xbfe0f6, 'glow'); // fenêtres
    for (const x of [-8, 0, 8]) for (const z of [-5, 0, 5]) box(2.2, 0.04, 0.6, x, 3.58, z, 0xffffff, 'glow');
    // LED : gorge périphérique au plafond, accueil, salle de réunion, bureau du directeur
    for (const [x0, z0, x1, z1] of [[-12.9, -8.9, 12.9, -8.86], [-12.9, 8.86, 12.9, 8.9], [-12.9, -8.9, -12.86, 8.9], [12.86, -8.9, 12.9, 8.9]]) box(x1 - x0, 0.03, z1 - z0, (x0 + x1) / 2, 3.52, (z0 + z1) / 2, 0xffffff, 'led');
    // réception : comptoir, mur du logo avec cadre LED
    box(4, 1.1, 0.8, 0, 0.55, 5.2, 0xf2f2f2, 'shiny'); box(4.2, 0.06, 1.0, 0, 1.13, 5.2, 0x2a2d33, 'shiny'); box(4, 0.04, 0.03, 0, 0.1, 5.62, 0xffffff, 'led'); solid(-2.1, 4.75, 2.1, 5.65, 1.2);
    box(7, 3.0, 0.2, 0, 1.6, 3.2, A); solid(-3.5, 3.1, 3.5, 3.3);
    for (const [w, h, x, y] of [[7, 0.04, 0, 3.1], [7, 0.04, 0, 0.12], [0.04, 3, -3.5, 1.6], [0.04, 3, 3.5, 1.6]]) box(w, h, 0.03, x, y, 3.32, 0xffffff, 'led');
    const logo = new THREE.Mesh(new THREE.PlaneGeometry(5.6, 1.4), new THREE.MeshBasicMaterial({ map: canvasTex(640, 160, (x, w, h) => { x.fillStyle = '#ffffff'; x.font = '900 72px Arial'; x.textAlign = 'center'; x.fillText(site.def.name, w / 2, 86); x.font = '700 26px Arial'; x.fillStyle = '#f2c200'; x.fillText(site.def.sector.toUpperCase(), w / 2, 134); }), transparent: true, toneMapped: false }));
    logo.position.set(O.x, O.y + 1.9, O.z + 3.32); g.add(logo);
    // attente
    box(3, 0.45, 0.9, -9, 0.3, 7, 0x2a3a4a); box(3, 0.6, 0.2, -9, 0.75, 7.4, 0x223040); box(1.2, 0.06, 0.6, -9, 0.45, 6, 0x6a4a32); solid(-10.5, 5.6, -7.5, 7.5, 1);
    for (const [x, z] of [[-12.3, 8.3], [12.3, 8.3], [-12.3, -8.3]]) { box(0.5, 0.5, 0.5, x, 0.25, z, 0xe8e2d6); P.std.push(colored(new THREE.SphereGeometry(0.5, 8, 6).scale(1, 1.4, 1).translate(O.x + x, O.y + 1.1, O.z + z), 0x2f7a2a)); solid(x - 0.3, z - 0.3, x + 0.3, z + 0.3, 1); }
    // espace de travail : 8 postes
    for (const [x, z] of DESKS) {
      box(1.6, 0.06, 0.8, x, 0.76, z, 0xe8e2d6); box(0.06, 0.74, 0.7, x - 0.75, 0.37, z, 0x3a3d42); box(0.06, 0.74, 0.7, x + 0.75, 0.37, z, 0x3a3d42);
      box(0.6, 0.38, 0.04, x, 1.12, z - 0.25, 0x111418, 'shiny'); box(0.54, 0.32, 0.01, x, 1.12, z - 0.225, [0x2f80ed, 0x7a2a8a, 0x0b6e4f, 0xe46a1f, 0xc8a020][site.i], 'glow');
      box(0.5, 0.08, 0.5, x, 0.48, z + 0.75, 0x1d1f24); box(0.5, 0.6, 0.06, x, 0.82, z + 1.0, 0x1d1f24);
      solid(x - 0.82, z - 0.42, x + 0.82, z + 0.42, 1);
    }
    for (const z of [-5, -1.5]) box(10, 0.03, 0.05, -6.5, 3.5, z, 0xffffff, 'led'); // rubans au-dessus des postes
    // bureau vitré du directeur et salle de réunion
    const glass = [];
    glass.push(new THREE.BoxGeometry(0.05, 3.4, 4).translate(O.x + 5, O.y + 1.7, O.z - 7), new THREE.BoxGeometry(0.05, 3.4, 0.8).translate(O.x + 5, O.y + 1.7, O.z - 3.4), new THREE.BoxGeometry(8, 3.4, 0.05).translate(O.x + 9, O.y + 1.7, O.z - 3));
    solid(4.95, -9, 5.05, -5.0); solid(4.95, -3.8, 5.05, -3.0); solid(5, -3.05, 13, -2.95);
    box(2.4, 0.08, 1.0, 9.5, 0.78, -6.3, 0x3a2416, 'shiny'); box(2.3, 0.72, 0.06, 9.5, 0.38, -5.85, 0x3a2416); solid(8.3, -6.8, 10.7, -5.8, 1);
    box(0.7, 0.12, 0.7, 9.5, 0.55, -7.2, 0x111418); box(0.7, 1.0, 0.12, 9.5, 1.05, -7.6, 0x111418);
    box(0.8, 0.46, 0.04, 9.5, 1.08, -6.6, 0x111418, 'shiny'); box(2.4, 0.03, 0.03, 9.5, 0.08, -5.83, 0xffffff, 'led');
    for (const [x0, z0, x1, z1] of [[5.2, -8.85, 12.85, -8.82], [12.82, -8.85, 12.85, -3.2]]) box(x1 - x0, 0.03, z1 - z0, (x0 + x1) / 2, 3.4, (z0 + z1) / 2, 0xffffff, 'led');
    box(4, 0.06, 1.4, 9, 0.75, 0.2, 0x6a4a32); box(0.1, 0.72, 0.1, 9, 0.36, 0.2, 0x3a3d42); solid(7, -0.5, 11, 0.9, 1);
    for (const x of [7.6, 9, 10.4]) for (const z of [-0.8, 1.2]) { box(0.48, 0.08, 0.48, x, 0.47, z, 0x1d1f24); }
    for (const [w, d, x, z] of [[4.2, 0.03, 9, -0.6], [4.2, 0.03, 9, 1.0]]) box(w, 0.03, d, x, 3.0, z, 0xffffff, 'led');
    // écran du tableau de bord (mur ouest)
    site.statsTex = canvasTex(512, 288, () => {});
    const scr = new THREE.Mesh(new THREE.PlaneGeometry(3.2, 1.8), new THREE.MeshBasicMaterial({ map: site.statsTex, toneMapped: false })); scr.position.set(O.x - 12.95, O.y + 2.0, O.z + 0.5); scr.rotation.y = PI / 2; g.add(scr);
    box(0.06, 1.95, 3.35, -12.98, 2.0, 0.5, 0x111418);
    // équipements du métier
    this.equipment(id, box, solid, P);
    for (const k of ['std', 'shiny', 'glow']) if (P[k].length) { const m = new THREE.Mesh(mergeGeometries(P[k]), this.mats[k]); g.add(m); }
    if (P.led.length) g.add(new THREE.Mesh(mergeGeometries(P.led), this.led));
    if (glass.length) { const gm = new THREE.Mesh(mergeGeometries(glass), this.mats.glass); gm.renderOrder = 3; g.add(gm); }
    site.built = g;
  }
  equipment(id, box, solid, P) {
    if (id === 'digital') {
      for (let k = 0; k < 3; k++) { const x = -12.2 + k * 1.2; box(0.9, 2.1, 1.0, x, 1.05, -8.3, 0x1a1c20, 'shiny'); for (let r = 0; r < 8; r++) box(0.04, 0.04, 0.02, x - 0.3 + (r % 3) * 0.15, 0.4 + r * 0.2, -7.79, [0x2fd05a, 0x2f80ed, 0xf2c200][r % 3], 'glow'); }
      solid(-12.7, -8.8, -8.9, -7.8, 2.2);
      box(4, 1.8, 0.05, -5, 2.0, -8.95, 0x0b1a10, 'glow'); for (let k = 0; k < 9; k++) box(0.6 + (k * 37 % 20) / 10, 0.06, 0.01, -6.5 + (k % 3) * 0.3 + (k * 13 % 7) / 10, 2.7 - k * 0.15, -8.92, [0x2fd05a, 0xf2c200, 0x8ab8ff][k % 3], 'glow');
    } else if (id === 'media') {
      box(5, 3.2, 0.1, -9, 1.6, -8.9, 0x2fa04a); box(5, 0.05, 2.5, -9, 0.08, -7.6, 0x2fa04a); solid(-11.5, -8.95, -6.5, -8.8);
      for (const x of [-10.5, -7.5]) { box(0.06, 1.5, 0.06, x, 0.75, -5.8, 0x2a2d33); box(0.35, 0.25, 0.5, x, 1.6, -5.8, 0x111418, 'shiny'); box(0.15, 0.15, 0.2, x, 1.6, -6.1, 0x3a3d42); }
      for (const x of [-12, -6]) { box(0.06, 2.2, 0.06, x, 1.1, -7, 0x2a2d33); box(0.7, 0.7, 0.1, x, 2.3, -6.9, 0xfff6e0, 'glow'); solid(x - 0.3, -7.3, x + 0.3, -6.7, 2.5); }
      box(1.8, 0.06, 0.8, -3.5, 0.76, -7.8, 0x2a2d33); for (let m = 0; m < 3; m++) box(0.55, 0.32, 0.04, -4.1 + m * 0.6, 1.1, -8.1, 0x111418, 'shiny'); solid(-4.4, -8.2, -2.6, -7.4, 1);
    } else if (id === 'immo') {
      box(3, 0.8, 1.6, -8, 0.4, -7.4, 0xf2f2f2); solid(-9.5, -8.2, -6.5, -6.6, 1);
      for (let k = 0; k < 9; k++) { const h = 0.2 + (k * 7 % 5) * 0.12; box(0.3, h, 0.3, -9.1 + (k % 3) * 0.9 + (k % 2) * 0.2, 0.8 + h / 2, -7.9 + Math.floor(k / 3) * 0.5, [0xe8e2d6, 0xd8c8a8, 0x9fc4d8][k % 3]); }
      for (let k = 0; k < 4; k++) { box(1.5, 1.0, 0.04, -12 + k * 2.1, 1.9, -8.96, 0xffffff); box(1.3, 0.55, 0.01, -12 + k * 2.1, 2.05, -8.93, [0x9fc4d8, 0xd8b890, 0xa8c890, 0xc8a8b8][k], 'glow'); }
    } else if (id === 'transport') {
      box(6, 2.2, 0.05, -7, 2.0, -8.95, 0x0b1220, 'glow');
      for (let k = 0; k < 6; k++) box(0.9 + k * 0.3, 0.05, 0.01, -9 + k * 0.6, 1.4 + (k % 3) * 0.5, -8.92, [0xe46a1f, 0xf2c200, 0x2fd05a][k % 3], 'glow');
      box(1.2, 1.6, 0.4, -12.3, 0.8, -6, 0x5a5f66, 'shiny'); for (let k = 0; k < 6; k++) box(0.05, 0.12, 0.02, -12.6 + (k % 3) * 0.3, 1.2 + Math.floor(k / 3) * 0.3, -5.78, 0xf2c200, 'glow'); solid(-12.9, -6.2, -11.7, -5.8, 1.6);
      for (let k = 0; k < 4; k++) box(0.5, 1.9, 0.45, -12.5, 0.95, -3 + k * 0.55, [0xe46a1f, 0x5a5f66][k % 2], 'shiny'); solid(-12.75, -3.3, -12.25, -0.8, 2);
    } else if (id === 'distribution') {
      for (let r = 0; r < 3; r++) { const x = -11 + r * 3.2; box(2.8, 0.06, 0.9, x, 0.05, -8.2, 0x8a8f96); for (const y of [0.9, 1.8]) box(2.8, 0.05, 0.9, x, y, -8.2, 0x8a8f96, 'shiny'); for (const sx of [-1.35, 1.35]) box(0.06, 2.4, 0.9, x + sx, 1.2, -8.2, 0xe46a1f); for (let k = 0; k < 8; k++) box(0.5, 0.4, 0.6, x - 1.0 + (k % 4) * 0.65, 0.3 + Math.floor(k / 4) * 0.9, -8.2, [0xb8945a, 0xa88450, 0xc8a46a][k % 3]); solid(x - 1.4, -8.7, x + 1.4, -7.7, 2.4); }
      box(1.2, 0.15, 1.2, -3, 0.08, -7.5, 0xa88450); for (let k = 0; k < 4; k++) box(0.5, 0.4, 0.5, -3.25 + (k % 2) * 0.5, 0.36 + Math.floor(k / 2) * 0.4, -7.5, 0xb8945a); solid(-3.6, -8.1, -2.4, -6.9, 1.2);
    }
  }
  // ------------------------------------------------------------------ personnages
  spawn(site) {
    this.despawn();
    const s = this.sub(site); if (!s) return;
    const O = { x: site.cx, y: site.Y, z: site.cz }, add = (e, x, z, ry, sit, i) => {
      const c = createCharacter({ female: e ? FEMALE.has(e.name.split(' ')[0]) : true, skin: SKINS[i % SKINS.length], shirtColor: [0xf2f2f2, ACCENT[site.id], 0xe8e2d6, 0x1f4e9c, 0x2a2d33][i % 5], pants: 0x22252a });
      if (sit) c.sit(false);
      c.group.position.set(O.x + x, O.y + (sit ? -0.47 : 0) + 0.1, O.z + z); c.group.rotation.y = ry; this.scene.add(c.group);
      this.people.push({ c, sit, t: Math.random() * 9, e });
    };
    add(null, 0, 4.5, 0, false, 7); // hôtesse d'accueil (personnage d'ambiance)
    const team = s.staff.filter((e) => e.id !== s.director);
    team.slice(0, DESKS.length).forEach((e, i) => { const [x, z] = DESKS[i]; add(e, x, z + 0.72, PI, true, i); });
    const dir = s.staff.find((e) => e.id === s.director); if (dir) add(dir, 9.5, -7.15, 0, true, 3);
    site.shown = team.length; site.dir = dir || null;
  }
  despawn() { for (const p of this.people) { this.scene.remove(p.c.group); if (p.c.mesh && p.c.mesh.geometry) p.c.mesh.geometry.dispose(); } this.people = []; }
  // ------------------------------------------------------------------ entrer / sortir
  enter(site) {
    const s = this.sub(site);
    if (!s) { this.ui.toast(`${site.def.name} : locaux réservés. Crée ou rachète la société dans NOVA Gestion (onglet « Mes entreprises »).`, 3.5); return; }
    if (!site.built) this.build(site);
    site.built.visible = true;
    const pl = this.player; this.inside = site.i; this.site = site;
    this.world.collision.level = site.lv; pl.floorY = site.Y; pl.pos.set(site.cx, site.Y, site.cz + 7.4); pl.vy = 0; pl.facing = PI; pl.mesh.position.copy(pl.pos);
    if (this.tpc && this.tpc.snap) this.tpc.snap(pl.pos);
    this.spawn(site); this.drawStats(site);
    this.lightRig(true);
    this.ui.toast(`Bienvenue chez ${site.def.name} — ${s.staff.length} employé(s)${site.dir ? `, directeur : ${site.dir.name}` : ', pas de directeur nommé'}`, 3);
    if (this.audio && this.audio.ctx) this.audio.tone(880, 0.12, 0.04, 'sine');
  }
  exit(silent) {
    const site = this.site; if (!site) return;
    const pl = this.player; this.inside = -1; this.site = null;
    this.world.collision.level = 0; pl.floorY = 0; pl.pos.set(site.out.x, 0, site.out.z); pl.vy = 0; pl.mesh.position.copy(pl.pos); if (this.tpc && this.tpc.snap) this.tpc.snap(pl.pos);
    this.despawn(); if (site.built) site.built.visible = false; this.lightRig(false);
    if (!silent) this.ui.toast(`Tu sors de ${site.def.name}.`, 1.6);
  }
  lightRig(on) {
    const ls = this.home && this.home.lights; if (!ls) return;
    if (!this._orig) this._orig = ls.map((l) => ({ p: l.position.clone(), d: l.distance }));
    if (on && this.site) { const S = this.site; ls.forEach((l, i) => { l.position.set(S.cx - 8 + i * 8, S.Y + 3.2, S.cz); l.distance = 16; l.decay = 1.2; l.intensity = 22 * Math.min(1, (this.env ? this.env.lightsOn : 1) * 1.5); }); this._borrowed = true; }
    else if (this._borrowed) { ls.forEach((l, i) => { l.position.copy(this._orig[i].p); l.distance = this._orig[i].d; l.decay = 1.6; l.intensity = 0; }); this._borrowed = false; }
  }
  // ------------------------------------------------------------------ interactions
  insidePoints(site) {
    const s = this.sub(site), L = [];
    L.push([0, 8.3, 1.3, `Sortir de ${site.def.name}`, () => this.exit()]);
    L.push([0, 6.3, 1.5, `Accueil de ${site.def.name}`, () => this.ui.toast(`Accueil : « Bonjour PDG ! ${site.def.name} compte ${s.staff.length} employé(s). Trésorerie : ${fcfa(s.cash)}. »`, 3.5)]);
    L.push([-11.4, 0.5, 1.6, 'Tableau de bord de la société (NOVA Gestion)', () => this.openBiz(site)]);
    L.push([-6.5, 1.0, 2.2, 'Superviser l’équipe', () => this.supervise(site)]);
    L.push([9.5, -5.0, 1.4, site.dir ? `Parler au directeur, ${site.dir.name}` : 'Bureau du directeur (poste vacant : nommer un directeur)', () => this.director(site)]);
    L.push([9, 2.0, 1.5, 'Salle de réunion : point d’équipe et discussion collective', () => { this.supervise(site, true); if (this.talk) this.talk.openGroup(s.staff.map((e) => `e:${site.id}:${e.id}`), s.name); }]);
    L.push([-8, -6.6, 2.0, EQUIP[site.id], () => this.ui.toast(`${EQUIP[site.id]} • niveau d’équipement ${s.equip}/3${s.equip < 3 ? ' (amélioration possible dans NOVA Gestion)' : ''}`, 3)]);
    return L;
  }
  openBiz(site) { if (!this.bizUI) return; this.bizUI.tab = 'groupe'; this.bizUI.sub = site.id; this.bizUI.toggle(true); }
  supervise(site, meeting) {
    const s = this.sub(site), G = this.group, day = G && G.economy ? G.economy.day : 0;
    const rate = G ? Math.round(G.rate(s) / 5000) * 5000 : 0, avg = Math.round(s.staff.reduce((a, e) => a + e.morale, 0) / Math.max(1, s.staff.length));
    if (s.supervised !== day) { s.supervised = day; for (const e of s.staff) e.morale = Math.min(100, e.morale + 2); this.ui.toast(`${meeting ? 'Point d’équipe' : 'Supervision'} : production ≈ ${fcfa(rate)} par jour • moral moyen ${avg} → l’équipe est motivée (+2)`, 3.5); this.onSave && this.onSave(); }
    else this.ui.toast(`Production ≈ ${fcfa(rate)} par jour • moral moyen ${avg}. (Bonus de supervision déjà obtenu aujourd’hui.)`, 3);
  }
  director(site) {
    const s = this.sub(site), d = site.dir;
    if (!d) { this.ui.toast('Aucun directeur nommé : choisis-en un dans NOVA Gestion (fiche de la société).', 3); return this.openBiz(site); }
    if (this.talk) return this.talk.openKey(`e:${site.id}:${d.id}`); // mission 017 : conversation libre avec le directeur
    const ins = s.instruction && INSTR[s.instruction] ? `Consigne en cours : ${INSTR[s.instruction].label.toLowerCase()}.` : 'Aucune consigne particulière.';
    this.ui.toast(`${d.name} : « Bonjour PDG ! Chiffre d’affaires du mois : ${fcfa(s.cur.ca)}, trésorerie : ${fcfa(s.cash)}. ${ins} »`, 4.5);
    this.openBiz(site);
  }
  nearest(x, z) {
    if (this.inside >= 0) {
      const site = this.site, lx = x - site.cx, lz = z - site.cz; let best = null;
      for (const [px, pz, r, label, action] of this.insidePoints(site)) { const d = Math.hypot(lx - px, lz - pz); if (d < r && (!best || d < best.d)) best = { d, it: { label: () => label, action } }; }
      return best;
    }
    let best = null;
    for (const s of this.sites) { const d = Math.hypot(x - s.out.x, z - s.out.z); if (d < 2.4 && (!best || d < best.d)) best = { d, s }; }
    if (!best) return null;
    const site = best.s, active = !!this.sub(site);
    return { d: best.d * 0.8, it: { label: () => active ? `Entrer chez ${site.def.name}` : `${site.def.name} — locaux réservés (société pas encore créée)`, action: () => this.enter(site) } };
  }
  drawStats(site) {
    const s = this.sub(site); if (!s || !site.statsTex) return;
    const c = site.statsTex.image, x = c.getContext('2d'), w = c.width, h = c.height;
    x.fillStyle = '#0b1220'; x.fillRect(0, 0, w, h); x.fillStyle = hexCss(ACCENT[site.id]); x.fillRect(0, 0, w, 8);
    x.fillStyle = '#f2c200'; x.font = 'bold 26px Arial'; x.fillText(`${site.def.name} — tableau de bord`, 18, 44);
    x.fillStyle = '#fff'; x.font = '19px Arial';
    const rows = [['Trésorerie', fcfa(s.cash)], ['CA du mois', fcfa(s.cur.ca)], ['Employés', String(s.staff.length)], ['Directeur', site.dir ? site.dir.name : '— (à nommer)'], ['Équipements', `niveau ${s.equip}/3`], ['Locaux', s.premises]];
    rows.forEach(([k, v], i) => { x.fillStyle = '#9fb2c0'; x.fillText(k, 18, 84 + i * 32); x.fillStyle = '#fff'; x.fillText(v, 200, 84 + i * 32); });
    site.statsTex.needsUpdate = true;
  }
  update(dt, P) {
    for (const s of this.sites) s.door.visible = Math.hypot(P.x - s.out.x, P.z - s.out.z) < 220;
    if (this.inside < 0) return;
    const site = this.site;
    // sortie autrement que par la porte (pouvoir, transport…) : retour au niveau du sol
    if (Math.hypot(P.x - site.cx, P.z - site.cz) > 20 || Math.abs((P.y || site.Y) - site.Y) > 6) { this.inside = -1; this.site = null; this.world.collision.level = 0; this.player.floorY = 0; this.despawn(); if (site.built) site.built.visible = false; this.lightRig(false); return; }
    for (const p of this.people) {
      p.t += dt; const b = p.c.bones;
      if (!p.sit) { p.c.animate(dt, 0); continue; }
      b.armL.rotation.x = b.armR.rotation.x = -0.75; b.foreL.rotation.x = -0.9 + Math.sin(p.t * 14) * 0.08; b.foreR.rotation.x = -0.9 + Math.sin(p.t * 13 + 1) * 0.08; b.head.rotation.y = Math.sin(p.t * 0.4) * 0.15;
    }
    this._st = (this._st || 0) - dt; if (this._st <= 0) { this._st = 2; this.drawStats(site); }
  }
  serialize() { return {}; }
}
