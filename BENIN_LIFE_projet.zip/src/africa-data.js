// Mission 023 — données du continent : 54 États africains, détail des 28 pays de la mission (villes, monuments,
// monnaies, phase de développement). Coordonnées géographiques APPROXIMATIVES (latitude, longitude en degrés décimaux,
// arrondies) pour la carte du téléphone et le placement à l'échelle du jeu. Monnaies : noms réels ; taux de conversion
// = valeurs du JEU, configurables, qui ne sont pas des taux de change réels ni en temps réel.
// Statut d'une ville : 'jouable' (explorable dans le jeu), 'dev' (pas encore développée : affichée comme telle).

// valeur indicative d'une unité de chaque monnaie en francs CFA (configuration du jeu)
export const CURRENCIES = {
  XOF: { name: 'Franc CFA (UEMOA)', sym: 'FCFA', rate: 1 },
  XAF: { name: 'Franc CFA (CEMAC)', sym: 'FCFA', rate: 1 },
  GHS: { name: 'Cedi ghanéen', sym: 'GH₵', rate: 40 },
  NGN: { name: 'Naira nigérian', sym: '₦', rate: 0.4 },
  CDF: { name: 'Franc congolais', sym: 'FC', rate: 0.21 },
  KES: { name: 'Shilling kényan', sym: 'KSh', rate: 4.5 },
  TZS: { name: 'Shilling tanzanien', sym: 'TSh', rate: 0.23 },
  UGX: { name: 'Shilling ougandais', sym: 'USh', rate: 0.16 },
  RWF: { name: 'Franc rwandais', sym: 'FRw', rate: 0.43 },
  ETB: { name: 'Birr éthiopien', sym: 'Br', rate: 4.5 },
  ZAR: { name: 'Rand sud-africain', sym: 'R', rate: 33 },
  AOA: { name: 'Kwanza angolais', sym: 'Kz', rate: 0.65 },
  ZMW: { name: 'Kwacha zambien', sym: 'K', rate: 23 },
  MZN: { name: 'Metical mozambicain', sym: 'MT', rate: 9.3 },
  NAD: { name: 'Dollar namibien', sym: 'N$', rate: 33 },
  MAD: { name: 'Dirham marocain', sym: 'DH', rate: 62 },
  DZD: { name: 'Dinar algérien', sym: 'DA', rate: 4.5 },
  TND: { name: 'Dinar tunisien', sym: 'DT', rate: 195 },
  EGP: { name: 'Livre égyptienne', sym: 'E£', rate: 12 },
};
export const toCurrency = (fcfa, code) => fcfa / (CURRENCIES[code] ? CURRENCIES[code].rate : 1);

// 54 États (code ISO numérique → nom) ; les pays sans détail sont affichés « à venir »
export const STATES = { '012': 'Algérie', '024': 'Angola', '204': 'Bénin', '072': 'Botswana', '854': 'Burkina Faso', '108': 'Burundi', '132': 'Cap-Vert', '120': 'Cameroun', '140': 'Centrafrique', '148': 'Tchad', '174': 'Comores', '178': 'République du Congo', '180': 'RD Congo', '384': 'Côte d’Ivoire', '262': 'Djibouti', '818': 'Égypte', '226': 'Guinée équatoriale', '232': 'Érythrée', '748': 'Eswatini', '231': 'Éthiopie', '266': 'Gabon', '270': 'Gambie', '288': 'Ghana', '324': 'Guinée', '624': 'Guinée-Bissau', '404': 'Kenya', '426': 'Lesotho', '430': 'Liberia', '434': 'Libye', '450': 'Madagascar', '454': 'Malawi', '466': 'Mali', '478': 'Mauritanie', '480': 'Maurice', '504': 'Maroc', '508': 'Mozambique', '516': 'Namibie', '562': 'Niger', '566': 'Nigeria', '646': 'Rwanda', '678': 'Sao Tomé-et-Principe', '686': 'Sénégal', '690': 'Seychelles', '694': 'Sierra Leone', '706': 'Somalie', '710': 'Afrique du Sud', '728': 'Soudan du Sud', '729': 'Soudan', '834': 'Tanzanie', '768': 'Togo', '788': 'Tunisie', '800': 'Ouganda', '894': 'Zambie', '716': 'Zimbabwe' };

const c = (name, lat, lon, status = 'dev', extra = {}) => ({ name, lat, lon, status, ...extra });
const m = (name, lat, lon, city, note = '') => ({ name, lat, lon, city, note });
// [id ISO, nom, phase, monnaie, langues, villes, monuments, aéroports, ports]
export const COUNTRIES = [
  { id: '204', name: 'Bénin', phase: 0, cur: 'XOF', langs: 'français, fon, yoruba, goun, bariba…', cities: [c('Cotonou', 6.37, 2.43, 'jouable', { capitale: false }), c('Porto-Novo', 6.50, 2.60, 'jouable', { capitale: true }), c('Ouidah', 6.36, 2.09, 'jouable'), c('Parakou', 9.34, 2.63)],
    monuments: [m('Statue et place de l’Amazone', 6.36, 2.41, 'Cotonou', 'jouable'), m('Porte du Non-Retour', 6.32, 2.09, 'Ouidah', 'jouable'), m('Palais royaux d’Abomey', 7.18, 1.99, 'Abomey'), m('Musée d’histoire de Ouidah', 6.36, 2.09, 'Ouidah'), m('Lac Nokoué et Ganvié', 6.47, 2.42, 'Ganvié', 'jouable')],
    airports: ['Aéroport international de Cotonou (jouable)'], ports: ['Port autonome de Cotonou (jouable)'] },
  { id: '768', name: 'Togo', phase: 1, cur: 'XOF', langs: 'français, éwé, kabyè, mina…', cities: [c('Lomé', 6.13, 1.22, 'jouable', { capitale: true }), c('Kpalimé', 6.90, 0.63), c('Kara', 9.55, 1.19)],
    monuments: [m('Monument de l’Indépendance', 6.13, 1.215, 'Lomé', 'jouable'), m('Marché des féticheurs d’Akodessawa', 6.145, 1.255, 'Lomé', 'jouable'), m('Koutammakou, le pays des Batammariba', 10.0, 1.1, 'Kara (région)'), m('Paysages de Kpalimé (mont Agou)', 6.86, 0.75, 'Kpalimé')],
    airports: ['Aéroport international Gnassingbé Eyadéma, Lomé (jouable)'], ports: ['Port autonome de Lomé (décor)'] },
  { id: '288', name: 'Ghana', phase: 1, cur: 'GHS', langs: 'anglais, akan (twi, fanti), éwé, ga…', cities: [c('Accra', 5.60, -0.19, 'jouable', { capitale: true }), c('Kumasi', 6.69, -1.62), c('Cape Coast', 5.11, -1.25)],
    monuments: [m('Independence Arch et Black Star Square', 5.55, -0.19, 'Accra', 'jouable'), m('Kwame Nkrumah Memorial Park', 5.54, -0.20, 'Accra', 'jouable'), m('Jamestown (phare, port de pêche)', 5.53, -0.21, 'Accra', 'jouable'), m('Marché de Makola', 5.55, -0.21, 'Accra', 'jouable'), m('Château de Cape Coast', 5.10, -1.24, 'Cape Coast'), m('Château d’Elmina', 5.08, -1.35, 'Elmina')], airports: ['Kotoka International Airport, Accra (jouable)'], ports: ['Port de Tema'] },
  { id: '566', name: 'Nigeria', phase: 1, cur: 'NGN', langs: 'anglais, yoruba, haoussa, igbo…', cities: [c('Lagos', 6.45, 3.40, 'jouable'), c('Abuja', 9.06, 7.49, 'jouable', { capitale: true }), c('Kano', 12.00, 8.52)],
    monuments: [m('National Theatre, Lagos', 6.48, 3.37, 'Lagos', 'jouable'), m('Zuma Rock', 9.13, 7.23, 'près d’Abuja', 'jouable'), m('Aso Rock', 9.08, 7.53, 'Abuja', 'jouable'), m('Mosquée nationale et Centre œcuménique chrétien', 9.06, 7.48, 'Abuja', 'jouable'), m('Eagle Square', 9.055, 7.505, 'Abuja', 'jouable'), m('Lekki Conservation Centre', 6.44, 3.53, 'Lagos', 'jouable'), m('Pont Lekki–Ikoyi', 6.45, 3.43, 'Lagos', 'jouable'), m('Tafawa Balewa Square', 6.45, 3.40, 'Lagos', 'jouable')], airports: ['Murtala Muhammed International Airport, Lagos (jouable)', 'Nnamdi Azikiwe International Airport, Abuja (jouable)'], ports: ['Ports de Lagos (Apapa, Tin Can)'] },
  { id: '384', name: 'Côte d’Ivoire', phase: 2, cur: 'XOF', langs: 'français, dioula, baoulé, bété…', cities: [c('Abidjan', 5.32, -4.02, 'jouable'), c('Yamoussoukro', 6.82, -5.28, 'dev', { capitale: true }), c('Bouaké', 7.69, -5.03)],
    monuments: [m('Basilique Notre-Dame de la Paix', 6.81, -5.30, 'Yamoussoukro (rapprochée d’Abidjan dans le jeu)', 'jouable'), m('Cathédrale Saint-Paul', 5.33, -4.02, 'Abidjan', 'jouable'), m('Parc national du Banco', 5.39, -4.05, 'Abidjan', 'jouable'), m('Lagune Ébrié et ses ponts', 5.30, -4.00, 'Abidjan', 'jouable')], airports: ['Aéroport Félix-Houphouët-Boigny, Abidjan'], ports: ['Port autonome d’Abidjan'] },
  { id: '686', name: 'Sénégal', phase: 2, cur: 'XOF', langs: 'français, wolof, pulaar, sérère…', cities: [c('Dakar', 14.69, -17.45, 'jouable', { capitale: true }), c('Saint-Louis', 16.03, -16.49), c('Touba', 14.85, -15.88)],
    monuments: [m('Monument de la Renaissance africaine', 14.72, -17.50, 'Dakar', 'jouable'), m('Île de Gorée', 14.67, -17.40, 'Dakar', 'jouable'), m('Lac Rose', 14.84, -17.23, 'près de Dakar'), m('Grande Mosquée de Touba', 14.86, -15.88, 'Touba')], airports: ['Aéroport international Blaise-Diagne'], ports: ['Port autonome de Dakar'] },
  { id: '854', name: 'Burkina Faso', phase: 2, cur: 'XOF', langs: 'français, mooré, dioula, fulfulde…', cities: [c('Ouagadougou', 12.37, -1.52, 'jouable', { capitale: true }), c('Bobo-Dioulasso', 11.18, -4.30)], monuments: [m('Grand Marché Rood Woko', 12.367, -1.523, 'Ouagadougou', 'jouable'), m('Cathédrale de l’Immaculée-Conception', 12.367, -1.527, 'Ouagadougou', 'jouable'), m('Palais du Moro Naba', 12.37, -1.54, 'Ouagadougou', 'jouable'), m('Monument des Héros nationaux', 12.31, -1.50, 'Ouagadougou (Ouaga 2000)', 'jouable'), m('Grande Mosquée de Bobo-Dioulasso', 11.18, -4.29, 'Bobo-Dioulasso')], airports: ['Aéroport international de Ouagadougou'], ports: [] },
  { id: '562', name: 'Niger', phase: 2, cur: 'XOF', langs: 'français, haoussa, zarma, tamasheq…', cities: [c('Niamey', 13.51, 2.11, 'jouable', { capitale: true }), c('Agadez', 16.97, 7.99)], monuments: [m('Musée national Boubou-Hama', 13.51, 2.10, 'Niamey', 'jouable'), m('Pont Kennedy et fleuve Niger', 13.50, 2.11, 'Niamey', 'jouable'), m('Grande Mosquée de Niamey', 13.53, 2.13, 'Niamey', 'jouable'), m('Grande Mosquée d’Agadez', 16.97, 7.99, 'Agadez')], airports: ['Aéroport Diori-Hamani, Niamey'], ports: [] },
  { id: '466', name: 'Mali', phase: 2, cur: 'XOF', langs: 'français, bambara, peul, songhaï…', cities: [c('Bamako', 12.64, -8.00, 'dev', { capitale: true }), c('Tombouctou', 16.77, -3.01)], monuments: [], airports: ['Aéroport de Bamako-Sénou'], ports: [] },
  { id: '120', name: 'Cameroun', phase: 3, cur: 'XAF', langs: 'français, anglais, nombreuses langues nationales', cities: [c('Douala', 4.05, 9.70), c('Yaoundé', 3.87, 11.52, 'dev', { capitale: true }), c('Bafoussam', 5.48, 10.42)],
    monuments: [m('Mont Cameroun', 4.20, 9.17, 'Buea'), m('Palais royal de Foumban', 5.73, 10.90, 'Foumban'), m('Chutes de la Lobé', 2.88, 9.90, 'Kribi'), m('Plages de Kribi', 2.94, 9.91, 'Kribi')], airports: ['Aéroport international de Douala'], ports: ['Port de Douala', 'Port de Kribi'] },
  { id: '266', name: 'Gabon', phase: 3, cur: 'XAF', langs: 'français, fang, myènè, punu…', cities: [c('Libreville', 0.42, 9.47, 'dev', { capitale: true }), c('Port-Gentil', -0.72, 8.78)], monuments: [], airports: ['Aéroport Léon-Mba, Libreville'], ports: ['Port d’Owendo'] },
  { id: '178', name: 'République du Congo', phase: 3, cur: 'XAF', langs: 'français, lingala, kituba…', cities: [c('Brazzaville', -4.27, 15.28, 'dev', { capitale: true }), c('Pointe-Noire', -4.78, 11.86)], monuments: [], airports: ['Aéroport Maya-Maya, Brazzaville'], ports: ['Port autonome de Pointe-Noire'] },
  { id: '180', name: 'RD Congo', phase: 3, cur: 'CDF', langs: 'français, lingala, swahili, kikongo, tshiluba', cities: [c('Kinshasa', -4.32, 15.31, 'dev', { capitale: true }), c('Lubumbashi', -11.66, 27.48)], monuments: [], airports: ['Aéroport international de N’djili, Kinshasa'], ports: ['Port de Matadi'] },
  { id: '148', name: 'Tchad', phase: 3, cur: 'XAF', langs: 'français, arabe, sara…', cities: [c('N’Djamena', 12.13, 15.06, 'dev', { capitale: true })], monuments: [], airports: ['Aéroport de N’Djamena'], ports: [] },
  { id: '404', name: 'Kenya', phase: 4, cur: 'KES', langs: 'swahili, anglais', cities: [c('Nairobi', -1.29, 36.82, 'dev', { capitale: true }), c('Mombasa', -4.04, 39.67)],
    monuments: [m('Parc national de Nairobi', -1.37, 36.86, 'Nairobi'), m('Réserve du Maasai Mara', -1.49, 35.14, 'Narok'), m('Fort Jesus', -4.06, 39.68, 'Mombasa')], airports: ['Jomo Kenyatta International Airport'], ports: ['Port de Mombasa'] },
  { id: '834', name: 'Tanzanie', phase: 4, cur: 'TZS', langs: 'swahili, anglais', cities: [c('Dar es Salaam', -6.79, 39.21), c('Zanzibar', -6.16, 39.19), c('Dodoma', -6.16, 35.75, 'dev', { capitale: true })], monuments: [], airports: ['Julius Nyerere International Airport'], ports: ['Port de Dar es Salaam'] },
  { id: '800', name: 'Ouganda', phase: 4, cur: 'UGX', langs: 'anglais, swahili, luganda…', cities: [c('Kampala', 0.35, 32.58, 'dev', { capitale: true }), c('Entebbe', 0.06, 32.46)], monuments: [], airports: ['Entebbe International Airport'], ports: [] },
  { id: '646', name: 'Rwanda', phase: 4, cur: 'RWF', langs: 'kinyarwanda, français, anglais, swahili', cities: [c('Kigali', -1.95, 30.06, 'dev', { capitale: true })], monuments: [], airports: ['Kigali International Airport'], ports: [] },
  { id: '231', name: 'Éthiopie', phase: 4, cur: 'ETB', langs: 'amharique, oromo, tigrinya…', cities: [c('Addis-Abeba', 9.03, 38.74, 'dev', { capitale: true })], monuments: [], airports: ['Aéroport international de Bole'], ports: [] },
  { id: '710', name: 'Afrique du Sud', phase: 5, cur: 'ZAR', langs: '12 langues officielles (zoulou, xhosa, afrikaans, anglais…)', cities: [c('Johannesburg', -26.20, 28.05), c('Le Cap (Cape Town)', -33.92, 18.42), c('Durban', -29.86, 31.03), c('Pretoria', -25.75, 28.19, 'dev', { capitale: true })],
    monuments: [m('Montagne de la Table', -33.96, 18.40, 'Le Cap'), m('Nelson Mandela Square', -26.11, 28.05, 'Johannesburg (Sandton)'), m('Robben Island', -33.81, 18.37, 'Le Cap'), m('V&A Waterfront', -33.90, 18.42, 'Le Cap')], airports: ['O. R. Tambo International Airport', 'Cape Town International Airport'], ports: ['Port de Durban', 'Port du Cap'] },
  { id: '024', name: 'Angola', phase: 5, cur: 'AOA', langs: 'portugais, umbundu, kimbundu…', cities: [c('Luanda', -8.84, 13.23, 'dev', { capitale: true })], monuments: [], airports: ['Aéroport de Luanda'], ports: ['Port de Luanda'] },
  { id: '894', name: 'Zambie', phase: 5, cur: 'ZMW', langs: 'anglais, bemba, nyanja…', cities: [c('Lusaka', -15.39, 28.32, 'dev', { capitale: true })], monuments: [], airports: ['Kenneth Kaunda International Airport'], ports: [] },
  { id: '508', name: 'Mozambique', phase: 5, cur: 'MZN', langs: 'portugais, makhuwa, tsonga…', cities: [c('Maputo', -25.97, 32.57, 'dev', { capitale: true })], monuments: [], airports: ['Aéroport de Maputo'], ports: ['Port de Maputo'] },
  { id: '516', name: 'Namibie', phase: 5, cur: 'NAD', langs: 'anglais, oshiwambo, afrikaans…', cities: [c('Windhoek', -22.56, 17.08, 'dev', { capitale: true })], monuments: [], airports: ['Hosea Kutako International Airport'], ports: ['Port de Walvis Bay'] },
  { id: '504', name: 'Maroc', phase: 6, cur: 'MAD', langs: 'arabe, amazigh, français', cities: [c('Casablanca', 33.57, -7.59), c('Rabat', 34.02, -6.83, 'dev', { capitale: true }), c('Marrakech', 31.63, -8.01)], monuments: [], airports: ['Aéroport Mohammed-V, Casablanca'], ports: ['Port de Casablanca', 'Tanger Med'] },
  { id: '012', name: 'Algérie', phase: 6, cur: 'DZD', langs: 'arabe, tamazight, français', cities: [c('Alger', 36.75, 3.06, 'dev', { capitale: true }), c('Oran', 35.70, -0.63)], monuments: [], airports: ['Aéroport d’Alger'], ports: ['Port d’Alger'] },
  { id: '788', name: 'Tunisie', phase: 6, cur: 'TND', langs: 'arabe, français', cities: [c('Tunis', 36.81, 10.18, 'dev', { capitale: true }), c('Sousse', 35.83, 10.64)], monuments: [], airports: ['Aéroport de Tunis-Carthage'], ports: ['Port de Radès'] },
  { id: '818', name: 'Égypte', phase: 6, cur: 'EGP', langs: 'arabe', cities: [c('Le Caire', 30.04, 31.24, 'dev', { capitale: true }), c('Alexandrie', 31.20, 29.92), c('Louxor', 25.69, 32.64)],
    monuments: [m('Pyramides de Gizeh', 29.98, 31.13, 'Gizeh'), m('Grand Sphinx de Gizeh', 29.975, 31.137, 'Gizeh'), m('Temple de Karnak', 25.72, 32.66, 'Louxor'), m('Vallée des Rois', 25.74, 32.60, 'Louxor')], airports: ['Aéroport international du Caire'], ports: ['Port d’Alexandrie'] },
];
export const COUNTRY_BY_ID = Object.fromEntries(COUNTRIES.map((k) => [k.id, k]));
export const PHASES = ['Bénin (déjà jouable)', 'Phase 1 : Bénin, Togo, Ghana, Nigeria', 'Phase 2 : Côte d’Ivoire, Sénégal, Burkina Faso, Niger, Mali', 'Phase 3 : Cameroun, Gabon, Congo, RD Congo, Tchad', 'Phase 4 : Kenya, Tanzanie, Ouganda, Rwanda, Éthiopie', 'Phase 5 : Afrique du Sud, Angola, Zambie, Mozambique, Namibie', 'Phase 6 : Maroc, Algérie, Tunisie, Égypte'];

// projection du jeu (même formule que la région du Bénin, échelle 1:5) : longitude/latitude → coordonnées du monde
export const GEO = { lon0: 2.4253, lat0: 6.3503, kx: 111320 * Math.cos((6.37 * Math.PI) / 180), ky: 110574, scale: 5 };
export const toWorld = (lat, lon) => ({ x: ((lon - GEO.lon0) * GEO.kx) / GEO.scale, z: (-(lat - GEO.lat0) * GEO.ky) / GEO.scale });
