// Mission 012 — étape 4 : port maritime (représentation stylisée, à l'est de la ville du jeu) : 3 jetées praticables,
// quai, gare maritime, capitainerie (choix des bateaux), grues, conteneurs, bittes d'amarrage, passerelles ;
// 10 bateaux amarrés, pilotables ; navires de croisière visitables (pont piscine, salon, restaurant, cabines,
// passerelle de commandement). Montants : monnaie virtuelle du jeu.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { BOATS, BOAT_BY_ID } from './boat-data.js';
import { Boat, Waves } from './boats.js';
import { PIERS, coastZ } from './region-geo.js';
import { createCharacter, SKINS } from './character.js';
import { fcfa } from './food-data.js';

const PI = Math.PI;
export const PORT = { x0: 300, x1: 760, z0: 140 };
const PIER_DEFS = [{ x0: 440, x1: 460, z0: 178, z1: 600 }, { x0: 610, x1: 630, z0: 178, z1: 600 }, { x0: 720, x1: 728, z0: 176, z1: 330 }];
const KIOSK = { x: 372, z: 178 };
// postes d'amarrage : centre du navire, cap (0 = proue vers le large), côté de la jetée (+1 = jetée à l'est du navire)
const BERTHS = {
  symphonie: { x: 414.5, z: 410, h: 0, side: 1 }, merveille: { x: 485.5, z: 410, h: 0, side: -1 }, euromonde: { x: 586, z: 395, h: 0, side: 1 }, reinemarine: { x: 652.5, z: 400, h: 0, side: -1 },
  perle: { x: 711.5, z: 250, h: 0, side: 1 }, navette: { x: 715, z: 312, h: 0, side: 1 }, fleche: { x: 732.8, z: 212, h: 0, side: -1 }, eclair: { x: 731.4, z: 248, h: 0, side: -1 }, espoir: { x: 732.6, z: 285, h: 0, side: -1 },
  ferry: { x: 350, z: null, h: PI / 2, side: 0 },
};
function colored(geo, hex) {
  const g = geo.index ? geo.toNonIndexed() : geo, c = new THREE.Color(hex), n = g.attributes.position.count, a = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { a[i * 3] = c.r; a[i * 3 + 1] = c.g; a[i * 3 + 2] = c.b; }
  g.setAttribute('color', new THREE.BufferAttribute(a, 3)); if (g.attributes.uv) g.deleteAttribute('uv'); return g;
}
const tex = (w, h, draw) => { const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t; };

export class Port {
  constructor(ctx) {
    Object.assign(this, ctx); // scene, world, player, ui, audio, economy, needs, env, tpc, camera, home, onSave
    for (const r of PIER_DEFS) PIERS.push(r);
    BERTHS.ferry.z = coastZ(350) + 11 + 3.5;
    this.berths = BERTHS; this.recs = BOATS.map((b) => ({ id: b.id, ...this.berthOf(b.id), moved: false }));
    this.boats = new Map(); this.open = false; this.sel = BOATS[0].id; this.cruise = null;
    this.buildSite();
    this.waves = new Waves(this.scene);
    this.dom = document.querySelector('#port');
    this.dom.addEventListener('click', (e) => this.onClick(e));
  }
  berthOf(id) { const b = BERTHS[id]; return { x: b.x, z: b.z, h: b.h }; }
  boardPoint(id) { // point du quai ou de la jetée face au navire amarré
    const sp = BOAT_BY_ID[id], b = BERTHS[id];
    if (b.side === 0) return { x: b.x, z: coastZ(b.x) - 2.5 };
    return { x: b.x + b.side * (sp.beam / 2 + 2.6), z: b.z - sp.len * 0.15 };
  }
  pois() { return [{ id: 'port', name: 'Port de Cotonou (représentation stylisée)', cat: 'transport', x: 520, z: 165, status: 'stylise', access: true, note: 'Quais, jetées, gare maritime, capitainerie • 10 bateaux (noms fictifs) • position non géographique' }, { id: 'port-capitainerie', name: 'Capitainerie du port', cat: 'transport', x: KIOSK.x, z: KIOSK.z - 2, status: 'fictif', access: true, note: 'Choisir un bateau, embarquer, visiter les paquebots' }]; }
  // ------------------------------------------------------------------ site portuaire
  buildSite() {
    const P = [], L = [], col = this.world.collision;
    const box = (w, h, d, x, y, z, c, arr = P) => arr.push(colored(new THREE.BoxGeometry(w, h, d).translate(x, y + h / 2, z), c));
    const solid = (x0, z0, x1, z1, h = 3) => col.addBox(x0, z0, x1, z1, h);
    // terre-plein portuaire (béton) le long du rivage, bord de quai
    for (let x = PORT.x0; x < PORT.x1; x += 20) { const cz = coastZ(x + 10); P.push(colored(new THREE.PlaneGeometry(20, cz - PORT.z0).rotateX(-PI / 2).translate(x + 10, 0.05, (PORT.z0 + cz) / 2), 0x9a9a96)); box(20, 0.6, 1.2, x + 10, -0.2, cz - 0.6, 0x6a6a66); }
    // jetées : tablier, bordures jaunes, bittes d'amarrage, lampadaires ; garde-corps invisibles sur les bords
    for (const r of PIER_DEFS) {
      const w = r.x1 - r.x0, d = r.z1 - r.z0, cx = (r.x0 + r.x1) / 2, cz = (r.z0 + r.z1) / 2;
      box(w, 0.7, d, cx, -0.55, cz, 0x8a8a86); box(w + 0.6, 2.5, d, cx, -3.2, cz, 0x5a5a56);
      for (const x of [r.x0 + 0.3, r.x1 - 0.3]) { box(0.3, 0.06, d, x, 0.15, cz, 0xf2c200); for (let z = r.z0 + 10; z < r.z1; z += 25) { box(0.5, 0.6, 0.5, x + (x < cx ? 0.4 : -0.4), 0.15, z, 0x2a2d33); } }
      for (let z = r.z0 + 20; z < r.z1; z += 40) { box(0.2, 7, 0.2, cx, 0.15, z, 0x5a5f66); L.push(colored(new THREE.BoxGeometry(1.2, 0.2, 0.5).translate(cx, 7.2, z), 0xfff2c8)); }
      for (const x of [r.x0 - 0.2, r.x1 + 0.2]) { const o = solid(x - 0.2, coastZ(x) - 0.8, x + 0.2, r.z1 + 0.2, 2); o.invisible = true; }
      const o = solid(r.x0, r.z1, r.x1, r.z1 + 0.4, 2); o.invisible = true;
    }
    // gare maritime, capitainerie, grues portiques, conteneurs, entrepôt
    box(90, 9, 22, 515, 0, 156, 0xe8e4dc); box(92, 1.2, 24, 515, 9, 156, 0x0b6e4f); for (let k = 0; k < 9; k++) box(6, 4, 0.1, 476 + k * 10, 3, 167.1, 0x2a4a5a);
    solid(470, 145, 560, 167, 10);
    box(4, 2.6, 3, KIOSK.x, 0, KIOSK.z, 0x1f4e9c); box(5, 0.3, 4, KIOSK.x, 2.6, KIOSK.z, 0xf2f2f2); solid(KIOSK.x - 2, KIOSK.z - 1.5, KIOSK.x + 2, KIOSK.z + 1.5, 2.6);
    for (const x of [675, 705]) { for (const dz of [-6, 6]) for (const dx of [-5, 5]) box(1, 38, 1, x + dx, 0, 184 + dz * 0.3 + (dz > 0 ? 0 : -8), 0xe46a1f); box(12, 2, 30, x, 38, 186, 0xe46a1f); box(3, 3, 4, x, 35, 190, 0x2a2d33); solid(x - 6, 175, x + 6, 178, 40); }
    const CC = [0xc8302a, 0x1f4e9c, 0x0b6e4f, 0xf2c200, 0x8a8f96, 0xe46a1f];
    for (let i = 0; i < 6; i++) for (let j = 0; j < 3; j++) for (let k = 0; k < 1 + ((i + j) % 3); k++) box(12, 2.6, 2.5, 600 + i * 14, k * 2.6, 148 + j * 3, CC[(i * 3 + j + k) % 6]);
    solid(593, 146, 683, 157, 8);
    box(40, 10, 18, 330, 0, 150, 0xc8ccd0); box(41, 1, 19, 330, 10, 150, 0x8a8f96); solid(310, 141, 350, 159, 11);
    const g = new THREE.Group();
    g.add(new THREE.Mesh(mergeGeometries(P), new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.85, polygonOffset: true, polygonOffsetFactor: -1 })));
    this.lmat = new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false }); g.add(new THREE.Mesh(mergeGeometries(L), this.lmat));
    const sign = (txt, sub, w, x, y, z, ry, bg = '#0b6e4f') => { const m = new THREE.Mesh(new THREE.PlaneGeometry(w, w / 4), new THREE.MeshBasicMaterial({ map: tex(512, 128, (c, W, H) => { c.fillStyle = bg; c.fillRect(0, 0, W, H); c.fillStyle = '#fff'; c.font = '900 50px Arial'; c.textAlign = 'center'; c.fillText(txt, W / 2, 62); c.font = '700 24px Arial'; c.fillStyle = '#f2c200'; c.fillText(sub, W / 2, 104); }), toneMapped: false })); m.position.set(x, y, z); m.rotation.y = ry; g.add(m); };
    sign('GARE MARITIME', 'Port de Cotonou • représentation stylisée', 24, 515, 7.5, 167.2, 0);
    sign('⚓ CAPITAINERIE', 'Bateaux • croisières', 4.4, KIOSK.x, 3.6, KIOSK.z + 1.6, 0, '#1f4e9c');
    this.scene.add(g); this.site = g;
  }
  // ------------------------------------------------------------------ bateaux
  spawn(rec) {
    if (this.boats.has(rec.id)) return this.boats.get(rec.id);
    const b = new Boat(this.scene, BOAT_BY_ID[rec.id], rec); b.col = this.world.collision; b.onMsg = (m) => this.msg(m);
    this.boats.set(rec.id, b); return b;
  }
  msg(m) { const t = performance.now(); if (this._mt && t - this._mt < 2500) return; this._mt = t; this.ui.toast(m, 2.2); }
  despawn(id) { const b = this.boats.get(id); if (!b || b.occupied) return; b.dispose(this.scene); this.boats.delete(id); }
  docked(b) { const r = this.berthOf(b.id); return Math.hypot(b.pos.x - r.x, b.pos.z - r.z) < 3 && Math.abs(b.speed) < 0.3; }
  toBerth(b) { const r = this.berthOf(b.id), rec = this.recs.find((q) => q.id === b.id); b.pos.set(r.x, 0, r.z); b.heading = r.h; b.speed = 0; b.steer = 0; Object.assign(rec, r, { moved: false }); b.sync(0); }
  board(b) {
    const P = this.player;
    this.ui.fade(true);
    setTimeout(() => {
      P.inCar = b; b.occupied = true; P.mesh.visible = false;
      if (this.tpc) this.tpc.yaw = b.heading + PI;
      this.ui.fade(false);
      const big = b.bspec.len > 60;
      this.ui.toast(`À la barre — ${b.bspec.name} : Z/W avant, S arrière, Q-D (A-D) tourner, Espace ralentir, K corne${big ? ', B explorer le navire (à l’arrêt)' : ''}, E débarquer près d’un quai`, 6);
      if (this.audio && this.audio.ctx) this.audio.tone(big ? 110 : 330, 0.6, 0.06, 'sawtooth');
    }, 450);
  }
  nearest(x, z) {
    let best = null;
    const dk = Math.hypot(x - KIOSK.x, z - (KIOSK.z - 2.4));
    if (dk < 2.6) best = { d: dk, it: { label: () => '⚓ Capitainerie : choisir un bateau', action: () => this.toggle(true) } };
    for (const b of this.boats.values()) {
      if (b.occupied || !this.docked(b)) continue;
      const bp = this.boardPoint(b.id), d = Math.hypot(x - bp.x, z - bp.z);
      if (d < 4 && (!best || d < best.d)) {
        const big = ['cruise', 'liner', 'ferry'].includes(b.bspec.kind);
        best = { d, it: { label: () => big ? `Monter à bord : ${b.bspec.name} (visiter les ponts) — passerelle d’embarquement` : `Prendre la barre : ${b.bspec.name}`, action: () => (big ? this.visit(b) : this.board(b)) } };
      }
    }
    if (this.cruise) return this.cruise.nearest(x, z);
    return best;
  }
  update(dt) {
    const P = this.player.pos, cur = this.player.inCar && this.player.inCar.isBoat ? this.player.inCar : null;
    for (const rec of this.recs) {
      const b = this.boats.get(rec.id);
      if (b && b.occupied) { rec.x = b.pos.x; rec.z = b.pos.z; rec.h = b.heading; if (!this.docked(b)) rec.moved = true; continue; }
      const d = Math.hypot(rec.x - P.x, rec.z - P.z);
      if (!b && d < 2600) this.spawn(rec); else if (b && d > 3200) this.despawn(rec.id);
    }
    for (const b of this.boats.values()) if (b !== cur) { b.speed *= Math.max(0, 1 - dt * 0.5); if (Math.abs(b.speed) < 0.05) b.speed = 0; b.sync(dt); }
    this.lmat.color.setScalar(0.35 + (this.env ? this.env.lightsOn : 0) * 0.9);
    this.site.visible = Math.hypot(P.x - 540, P.z - 300) < 3500;
    if (this.camera) this.waves.update(dt, this.camera);
    if (this.cruise) this.cruise.update(dt);
  }
  // débarquement : près d'un quai ; si c'est le poste d'amarrage, le bateau est ramené à quai proprement
  canExit(b) { return !!b.exitPoint(); }
  onExit(b) { const r = this.berthOf(b.id); if (Math.hypot(b.pos.x - r.x, b.pos.z - r.z) < 60 && Math.abs(b.speed) < 2) this.toBerth(b); this.onSave && this.onSave(); }
  // ------------------------------------------------------------------ capitainerie
  toggle(on) { this.open = on; this.dom.classList.toggle('show', on); if (on) this.render(); }
  render() {
    const sp = BOAT_BY_ID[this.sel], big = ['cruise', 'liner', 'ferry'].includes(sp.kind), rec = this.recs.find((r) => r.id === sp.id);
    this.dom.innerHTML = `<div class="g-box"><div class="g-head"><h2>CAPITAINERIE <span>PORT DE COTONOU (STYLISÉ)</span></h2><button class="g-x" data-pt="x">✕</button></div>
      <div class="g-main"><div class="g-list">${BOATS.map((b) => `<button class="g-card${b.id === this.sel ? ' sel' : ''}" data-pt="sel:${b.id}"><b>${b.name}</b><small>${b.type}</small><span class="g-mini">${b.len} m • ${b.pax} passagers</span></button>`).join('')}</div>
      <div class="g-detail"><div class="g-name">${sp.name}</div><div class="g-type">${sp.type}</div>
        <div class="g-stats"><div><span>Longueur</span><em class="g-wide">${sp.len} m • largeur ${sp.beam} m</em></div><div><span>Vitesse max</span><em class="g-wide">${Math.round(sp.vMax * 1.944)} nœuds (${Math.round(sp.vMax * 3.6)} km/h)</em></div><div><span>Capacité</span><em class="g-wide">${sp.pax} passagers${sp.cabins ? ` • ${sp.cabins} cabines` : ''}</em></div><div><span>Position</span><em class="g-wide">${rec.moved ? 'en mer ou hors de son poste' : 'à quai'}</em></div></div>
        <div class="a-btns"><button class="g-take" data-pt="helm">PRENDRE LA BARRE</button>${big ? '<button class="a-stand" data-pt="visit">VISITER LE NAVIRE</button>' : ''}</div>
        ${rec.moved ? '<div class="a-btns"><button class="a-stand" data-pt="home">RAMENER À SON POSTE D’AMARRAGE</button></div>' : ''}
        <p class="g-note">Navires fictifs inspirés de catégories de bateaux réels. Pilotage simplifié : Z/W avant, S arrière, Q-D tourner, Espace ralentir, K corne, E débarquer près d’un quai${big ? ', B explorer le navire à l’arrêt' : ''}.</p></div></div></div>`;
  }
  onClick(e) {
    const b = e.target.closest('[data-pt]'); if (!b) { if (e.target === this.dom) this.toggle(false); return; }
    e.stopPropagation(); if (this.audio && this.audio.ctx && this.audio.click) this.audio.click();
    const [a, v] = b.dataset.pt.split(':');
    if (a === 'x') return this.toggle(false);
    if (a === 'sel') this.sel = v;
    if (a === 'home') { const bt = this.spawn(this.recs.find((r) => r.id === this.sel)); if (!bt.occupied) { this.toBerth(bt); this.ui.toast(`${bt.bspec.name} est revenu à son poste d’amarrage.`, 2.2); this.onSave && this.onSave(); } }
    if (a === 'helm' || a === 'visit') {
      const rec = this.recs.find((r) => r.id === this.sel), bt = this.spawn(rec); this.toggle(false);
      if (bt.occupied) return;
      if (rec.moved) this.toBerth(bt);
      const bp = this.boardPoint(bt.id); this.player.pos.set(bp.x, 0, bp.z); this.player.mesh.position.copy(this.player.pos);
      if (a === 'helm') this.board(bt); else this.visit(bt);
      return;
    }
    this.render();
  }
  handleKeys(input) { if (input.hit('Escape')) this.toggle(false); }
  // ------------------------------------------------------------------ visite des grands navires
  visit(b) {
    if (this.player.inCar) { this.player.inCar = null; b.occupied = false; this.player.mesh.visible = true; }
    this.cruise = new ShipDeck({ ...this, port: this, ship: b }); this.cruise.enter();
  }
  helmFromDeck(b) { this.cruise.leave(false); this.cruise = null; this.board(b); }
  leaveDeck() { this.cruise.leave(true); this.cruise = null; }
  serialize() { return { boats: this.recs.filter((r) => r.moved).map((r) => ({ id: r.id, x: Math.round(r.x), z: Math.round(r.z), h: +r.h.toFixed(3) })) }; }
  restore(s) { if (!s || !Array.isArray(s.boats)) return; for (const p of s.boats) { const r = this.recs.find((x) => x.id === p.id); if (r) Object.assign(r, { x: p.x, z: p.z, h: p.h, moved: true }); } }
}

// =====================================================================
// Espaces accessibles des grands navires : pont piscine, salon-bar, restaurant, coursive et cabine, passerelle
// (construit au-dessus du navire, collisions isolées niveau 140 ; la mer est simulée autour du pont)
// =====================================================================
const LV = 140, Y = 480;
class ShipDeck {
  constructor(ctx) { Object.assign(this, ctx); this.cols = []; this.people = []; this.points = []; }
  enter() {
    const b = this.ship, sp = b.bspec, O = { x: b.pos.x, z: b.pos.z }; this.O = O;
    const P = { n: [], glow: [] }, g = new THREE.Group(), col = this.world.collision; this.g = g;
    const box = (w, h, d, x, y, z, c, k = 'n') => P[k].push(colored(new THREE.BoxGeometry(w, h, d).translate(O.x + x, Y + y + h / 2, O.z + z), c));
    const solid = (x0, z0, x1, z1, h = 3) => { const o = col.addBox(O.x + x0, O.z + z0, O.x + x1, O.z + z1, Y + h); o.lv = LV; this.cols.push(o); };
    const pt = (x, z, r, label, action) => this.points.push({ x, z, r, label, action });
    const person = (x, z, ry, opts = {}, sit = false) => { const c = createCharacter({ female: Math.random() < 0.5, skin: SKINS[Math.floor(Math.random() * SKINS.length)], pagne: opts.shirtColor === undefined ? Math.floor(Math.random() * 6) : undefined, ...opts }); if (sit) c.sit(false); c.group.position.set(O.x + x, Y + (sit ? -0.37 : 0.1), O.z + z); c.group.rotation.y = ry; g.add(c.group); this.people.push({ c, sit, t: Math.random() * 5 }); const o = col.addCircle(O.x + x, O.z + z, 0.32, Y + 1.8); o.lv = LV; this.cols.push(o); };
    // mer autour du navire (vue depuis les ponts) et coque/bastingage
    const sea = new THREE.Mesh(new THREE.CircleGeometry(4000, 48).rotateX(-PI / 2), new THREE.MeshStandardMaterial({ color: 0x1d6f88, roughness: 0.15, metalness: 0.1 })); sea.position.set(O.x, Y - 14, O.z); g.add(sea);
    box(48, 0.2, 30, 0, 0, 0, 0xc8a878); box(50, 14, 32, 0, -14.1, 0, sp.hull);
    for (const [w, d, x, z] of [[48, 0.15, 0, -15], [48, 0.15, 0, 15], [0.15, 30, -24, 0], [0.15, 30, 24, 0]]) box(w, 1.1, d, x, 0.1, z, 0xd8d8d8);
    solid(-24.3, -15.3, 24.3, -14.8, 2); solid(-24.3, 14.8, 24.3, 15.3, 2); solid(-24.3, -15.3, -23.8, 15.3, 2); solid(23.8, -15.3, 24.3, 15.3, 2);
    // cloisons : salon/restaurant à l'ouest, coursive + cabine au centre, passerelle au nord-centre, piscine à l'est
    box(0.2, 3, 30, -8, 0.1, 0, 0xf2f2f2); solid(-8.1, -15, -7.9, -2, 3.1); solid(-8.1, 2, -7.9, 15, 3.1);
    box(16, 3, 0.2, -16, 0.1, 0, 0xf2f2f2); solid(-24, -0.1, -18, 0.1, 3.1); solid(-14, -0.1, -8, 0.1, 3.1);
    box(0.2, 3, 30, 4, 0.1, 0, 0xf2f2f2); solid(3.9, -15, 4.1, -2, 3.1); solid(3.9, 2, 4.1, 6, 3.1); solid(3.9, 10, 4.1, 15, 3.1);
    // salon-bar (sud-ouest) : canapés, piano, bar avec barman
    for (const [x, z] of [[-20, -10], [-14, -10], [-20, -5]]) { box(3, 0.45, 1, x, 0.1, z, 0x5a2a4a); box(3, 0.6, 0.2, x, 0.55, z - 0.45, 0x4a2040); solid(x - 1.5, z - 0.5, x + 1.5, z + 0.5, 1); }
    box(1.6, 1, 1.4, -11, 0.1, -4, 0x0c0c0e); solid(-11.8, -4.7, -10.2, -3.3, 1.2);
    box(6, 1.1, 0.8, -17, 0.1, -13.6, 0xf2f2f2); solid(-20, -14, -14, -13.2, 1.2); person(-17, -14.3, 0, { shirtColor: 0x1a1a1a, collar: 0xffffff });
    pt(-17, -12.2, 1.6, `Bar — ${sp.name} : boire un cocktail sans alcool (2 000 FCFA)`, () => this.buy(2000, 'Cocktail sans alcool', 10, 'energy'));
    pt(-11, -2.8, 1.2, 'Piano du salon : écouter le pianiste', () => this.ui.toast('🎹 Le pianiste joue une mélodie douce. Énergie +3', 2.2) || (this.needs.energy = Math.min(100, this.needs.energy + 3)));
    // restaurant (nord-ouest)
    for (const [x, z] of [[-20, 4], [-14, 4], [-20, 9], [-14, 9]]) { box(1.4, 0.06, 1, x, 0.78, z, 0xf2f2f2); box(0.1, 0.75, 0.1, x, 0.1, z, 0x3a3d42); solid(x - 0.7, z - 0.5, x + 0.7, z + 0.5, 1); }
    person(-14, 9.75, PI, {}, true); person(-20, 3.25, 0, {}, true); person(-11, 6, -PI / 2, { shirtColor: 0x1a1a1a, collar: 0xffffff });
    pt(-17, 6.5, 2.2, 'Restaurant du navire : dîner (6 000 FCFA, faim +60)', () => this.buy(6000, 'Dîner au restaurant du navire', 60, 'hunger'));
    // coursive des cabines et cabine ouverte (centre-sud)
    for (let k = 0; k < 4; k++) { box(0.9, 2.1, 0.05, -6 + k * 2.6, 0.1, -14.8, 0x6a4a32); }
    box(3.4, 0.5, 2.2, -3, 0.1, -9, 0xf2f2f2); box(3.4, 0.12, 1.6, -3, 0.62, -8.8, 0x2f6aa8); box(0.05, 1.2, 2, -7.85, 1.2, -9, 0x8ac8e8, 'glow'); solid(-4.7, -10.1, -1.3, -7.9, 0.8);
    pt(-3, -6.6, 1.3, 'Cabine : se reposer une heure (énergie +25)', () => { this.needs.energy = Math.min(100, this.needs.energy + 25); this.env.time = (this.env.time + 1) % 24; this.ui.toast('Tu te reposes dans la cabine. Énergie +25', 2.4); });
    // passerelle de commandement (nord-centre) : console, barre
    box(11.6, 1.1, 1.2, -2, 0.1, 13.6, 0x2a2d33); box(11.6, 1.6, 0.05, -2, 1.3, 14.6, 0x8ac8e8, 'glow'); box(0.9, 1.0, 0.9, -2, 0.1, 11.8, 0x1a1a1a); solid(-7.8, 13, 3.8, 14.2, 1.2); solid(-2.45, 11.35, -1.55, 12.25, 1);
    person(1.5, 12, PI, { shirtColor: 0xf2f2f2, collar: 0x1a1a1a, sleeves: 'long', hat: 'cap', hatColor: 0xf2f2f2 });
    pt(-2, 10.6, 1.4, `Passerelle de commandement : prendre la barre (${sp.name})`, () => this.port.helmFromDeck(b));
    // pont piscine (est) : piscine, transats, toboggan
    box(12, 0.25, 8, 14, 0.05, 0, 0xf2f2f2); box(11, 0.1, 7, 14, 0.25, 0, 0x2ab8e8, 'glow'); solid(8, -4, 20, 4, 0.5);
    for (let k = 0; k < 6; k++) { box(0.8, 0.35, 2, 9 + k * 2, 0.1, -8, 0xf2f2f2); box(0.8, 0.35, 2, 9 + k * 2, 0.1, 8, 0xf2f2f2); }
    if (sp.slides) for (let k = 0; k < 2; k++) P.n.push(colored(new THREE.TorusGeometry(3 + k, 0.4, 6, 16, PI * 1.4).rotateX(PI / 2).translate(O.x + 20, Y + 3 + k * 1.5, O.z - 10 + k * 3), [0xe46a1f, 0x2fd05a][k]));
    person(10, -8, PI, { shirtColor: 0xf2c200, shorts: true, sleeves: 'none' }, true); person(16, 8, 0, { shirtColor: 0x2aa0a0, shorts: true, sleeves: 'none' }, true);
    pt(14, -5.2, 1.6, 'Piscine : se baigner (énergie +8, propreté +10)', () => { this.needs.energy = Math.min(100, this.needs.energy + 8); this.needs.hygiene = Math.min(100, this.needs.hygiene + 10); this.ui.toast('🏊 Baignade à la piscine du pont supérieur !', 2.4); });
    // descendre à quai (si le navire est amarré) — sinon retour à la passerelle
    pt(-22, 13, 1.6, () => (this.port.docked(b) ? 'Descendre à quai (passerelle d’embarquement)' : 'Navire en mer : retourner à la passerelle pour débarquer au port'), () => (this.port.docked(b) ? this.port.leaveDeck() : this.ui.toast('Le navire n’est pas à quai : prends la barre et ramène-le au port.', 2.6)));
    const nm = new THREE.Mesh(new THREE.PlaneGeometry(10, 1.6), new THREE.MeshBasicMaterial({ map: tex(640, 100, (c, W, H) => { c.fillStyle = '#0b1a2a'; c.fillRect(0, 0, W, H); c.fillStyle = '#fff'; c.font = '900 52px Arial'; c.textAlign = 'center'; c.fillText(sp.name.toUpperCase(), W / 2, 68); }), toneMapped: false })); nm.position.set(O.x - 16, Y + 3.6, O.z - 0.1); g.add(nm);
    for (const k of ['n', 'glow']) if (P[k].length) g.add(new THREE.Mesh(mergeGeometries(P[k]), k === 'glow' ? new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false }) : new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.6, emissive: 0x201c18 })));
    this.scene.add(g);
    this.ui.fade(true);
    setTimeout(() => {
      const pl = this.player; this.world.collision.level = LV; pl.floorY = Y; pl.pos.set(O.x - 22, Y, O.z + 11.5); pl.vy = 0; pl.facing = 0; pl.mesh.position.copy(pl.pos);
      if (this.tpc && this.tpc.snap) this.tpc.snap(pl.pos);
      this.ui.fade(false); this.ui.toast(`Bienvenue à bord — ${sp.name} : pont piscine, salon, restaurant, cabines et passerelle de commandement`, 4);
    }, 400);
  }
  buy(price, label, n, need) {
    if (!this.economy.pay(price, label, this.ship.bspec.name)) return;
    if (need === 'hunger') this.needs.hunger = Math.min(100, this.needs.hunger + n); else { this.needs.energy = Math.min(100, this.needs.energy + n); this.needs.hunger = Math.min(100, this.needs.hunger + 4); }
    this.ui.toast(`${label} • ${fcfa(price)}`, 2);
  }
  nearest(x, z) {
    const lx = x - this.O.x, lz = z - this.O.z; let best = null;
    for (const p of this.points) { const d = Math.hypot(lx - p.x, lz - p.z); if (d < p.r && (!best || d < best.d)) best = { d, p }; }
    if (!best) return null; const p = best.p;
    return { d: best.d, it: { label: () => (typeof p.label === 'function' ? p.label() : p.label), action: p.action } };
  }
  update(dt) { for (const p of this.people) { p.t += dt; if (!p.sit) p.c.animate(dt, 0); } }
  leave(toQuay) {
    this.scene.remove(this.g); this.g.traverse((o) => { if (o.geometry) o.geometry.dispose(); if (o.material) { if (o.material.map) o.material.map.dispose(); o.material.dispose(); } });
    for (const o of this.cols) o.disabled = true;
    const pl = this.player; this.world.collision.level = 0; pl.floorY = 0;
    if (toQuay) { const bp = this.port.boardPoint(this.ship.id); pl.pos.set(bp.x, 0, bp.z); pl.mesh.position.copy(pl.pos); if (this.tpc && this.tpc.snap) this.tpc.snap(pl.pos); this.ui.toast(`Tu redescends à quai (${this.ship.bspec.name}).`, 1.8); }
  }
}
