// Fichier généré par tools/build.mjs : modèles de personnages GLB disponibles.
export const CHARACTER_GLB = {  };
