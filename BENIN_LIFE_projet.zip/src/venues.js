// Mission 016, phase 3 — lieux de vie dans les 5 villes (Cotonou, Porto-Novo, Ouidah, Pahou, Cocotomey) :
// restaurants, bars (boissons sans alcool), poissonneries, mini-marchés, banques, hôtels et stations-service,
// plus le carburant des véhicules du joueur. Tous les établissements sont fictifs (noms inventés pour le jeu).
// L'argent utilisé est uniquement la monnaie virtuelle du jeu.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { FOOD_BY_ID, fcfa } from './food-data.js';
import { ARTICLE_BY_ID } from './market-data.js';
import { TOWNS, nearestOnRoad, nearRoad, coastZ, inLake } from './region-geo.js';

const PI = Math.PI;
export const FUEL_PRICE = 680; // FCFA par litre (prix du jeu)
const r25 = (n) => Math.max(25, Math.round(n / 25) * 25);
const inCity = (x, z) => x > -320 && x < 320 && z > -320 && z < 220;
const inAirport = (x, z) => x > -2280 && x < -370 && z > -140 && z < 230;
const okLand = (x, z, m = 4) => z < coastZ(x) - m && !inLake(x, z);
function colored(geo, hex) {
  const g = geo.index ? geo.toNonIndexed() : geo, c = new THREE.Color(hex), n = g.attributes.position.count, a = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { a[i * 3] = c.r; a[i * 3 + 1] = c.g; a[i * 3 + 2] = c.b; }
  g.setAttribute('color', new THREE.BufferAttribute(a, 3)); if (g.attributes.uv) g.deleteAttribute('uv'); return g;
}

export const TYPES = {
  restaurant: { label: 'Restaurant', icon: '🍲', color: '#c8502a', cat: 'restaurant', open: [7, 23] },
  bar: { label: 'Bar (sans alcool)', icon: '🥤', color: '#8a1030', cat: 'restaurant', open: [9, 24] },
  poissonnerie: { label: 'Poissonnerie', icon: '🐟', color: '#1f6aa8', cat: 'marche', open: [6, 19] },
  minimarche: { label: 'Mini-marché', icon: '🛒', color: '#0b6e4f', cat: 'marche', open: [7, 22] },
  banque: { label: 'Banque', icon: '🏦', color: '#1f4e9c', cat: 'services', open: [8, 17] },
  hotel: { label: 'Hôtel', icon: '🏨', color: '#7a2a8a', cat: 'services', open: [0, 24] },
  station: { label: 'Station-service', icon: '⛽', color: '#e46a1f', cat: 'transport', open: [0, 24] },
};
const ORDER = ['restaurant', 'bar', 'poissonnerie', 'minimarche', 'banque', 'hotel', 'station'];
// noms fictifs par ville
const NAMES = {
  Cotonou: { restaurant: 'MAQUIS LE BON GOÛT', bar: 'Paillote Bar de la Plage', poissonnerie: 'Poissonnerie de la Marina', minimarche: 'ALIMENTATION DIEU MERCI', banque: 'BANQUE LAGUNE', hotel: 'HÔTEL OCÉAN BLEU', station: 'Station Lagune Énergie' },
  'Porto-Novo': { restaurant: 'Restaurant La Capitale', bar: 'Bar Jus du Jardin', poissonnerie: 'Poissonnerie de la Lagune', minimarche: 'Mini-marché Bon Prix', banque: 'Banque Lagune — agence Porto-Novo', hotel: 'Hôtel Les Jardins', station: 'Station Horizon' },
  Ouidah: { restaurant: 'Restaurant Le Baobab', bar: 'Bar Coco Frais', poissonnerie: 'Poissonnerie de la Plage', minimarche: 'Mini-marché L’Étoile', banque: 'Banque Lagune — agence Ouidah', hotel: 'Hôtel Soleil Couchant', station: 'Station Ouest Énergie' },
  Pahou: { restaurant: 'Maquis Chez Tantie Afi', bar: 'Bar Bissap Frais', poissonnerie: 'Poissonnerie du Marché', minimarche: 'Mini-marché La Providence', banque: 'Banque Lagune — point d’accueil Pahou', hotel: 'Auberge du Calme', station: 'Station Bon Voyage' },
  Cocotomey: { restaurant: 'Restaurant Le Palmier', bar: 'Bar La Fraîcheur', poissonnerie: 'Poissonnerie Nokoué', minimarche: 'Mini-marché Bonne Affaire', banque: 'Banque Lagune — agence Cocotomey', hotel: 'Hôtel Le Relais', station: 'Station Express' },
};
// cartes des restaurants (assiettes composées d'aliments du catalogue)
const MENUS = {
  Cotonou: [['pate_rouge', 'sauce_arachide', 'poulet_grille'], ['amiwo', 'poulet_grille'], ['akassa', 'sauce_pimentee', 'poisson_frit'], ['atassi', 'sauce_tomate', 'fromage_soja'], ['riz_gras', 'poisson_frit'], ['pate_blanche', 'sauce_gombo', 'poisson_grille']],
  'Porto-Novo': [['igname_pilee', 'sauce_graine', 'brochettes'], ['telibo', 'sauce_gombo', 'poisson_fume'], ['pate_blanche', 'calalou'], ['watche', 'sauce_pimentee', 'wagashi'], ['riz_tomate', 'poulet_grille']],
  Ouidah: [['poisson_grille', 'akassa', 'dja'], ['riz_tomate', 'poisson_frit'], ['pate_blanche', 'sauce_crevettes'], ['amiwo', 'poisson_frit'], ['ablo', 'sauce_pimentee', 'poisson_grille']],
  Pahou: [['watche', 'sauce_pimentee', 'fromage_soja'], ['igname_frite', 'brochettes'], ['pate_rouge', 'sauce_tomate', 'poulet_grille'], ['alloco', 'poisson_frit']],
  Cocotomey: [['dakouin', 'poisson_fume'], ['yekeyeke', 'sauce_crincrin', 'poisson_frit'], ['adowe', 'dja'], ['piron', 'sauce_poisson_fume'], ['riz_gras', 'brochettes']],
};
const BAR = ['bissap', 'gingembre', 'baobab', 'jus_ananas', 'jus_mangue', 'citronnade', 'eau_coco', 'jus_tamarin', 'soda', 'eau', 'the_menthe', 'cafe', 'degue'];
const FISH = { Cotonou: ['capitaine', 'bar', 'maquereau', 'crevettes', 'crabes', 'poisson_fume'], 'Porto-Novo': ['tilapia', 'silure', 'crevettes', 'poisson_fume', 'poisson_seche'], Ouidah: ['capitaine', 'bar', 'maquereau', 'crevettes', 'poisson_fume'], Pahou: ['tilapia', 'maquereau', 'poisson_fume', 'poisson_seche'], Cocotomey: ['tilapia', 'silure', 'crabes', 'crevettes', 'poisson_fume'] };
const MINI = ['riz', 'spaghetti', 'macaroni', 'sucre', 'sel', 'huile_arachide', 'concentre_tomate', 'sardines', 'thon', 'lait', 'lait_poudre', 'eau', 'soda', 'pain', 'biscuits', 'oeufs', 'savon_noir', 'dentifrice', 'papier_toilette', 'bougies', 'piles'];

export class Venues {
  constructor(ctx) {
    Object.assign(this, ctx); // scene, world, region, ui, audio, economy, needs, env, player, cars, garage, bizUI, group, onSave
    this.list = []; this.stock = {}; this.stockDay = -1; this.fuel = {}; this.savings = 0; this.savingsLog = []; this.open = false; this.v = null; this.busy = false;
    this.mat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.75 });
    this.groups = [];
    this.placeCotonou();
    for (const t of this.region.towns) this.placeTown(t);
    this.restock();
    this.dom = document.querySelector('#venue');
    this.dom.addEventListener('click', (e) => this.onClick(e));
    this.hud = document.querySelector('#fuel');
    this._last = null; this._low = false;
  }

  // ------------------------------------------------------------------ placement
  add(town, type, x, z, ry, extra = {}) {
    const v = { id: `${town}:${type}`, town, type, name: NAMES[town][type], x, z, ry, ...extra };
    this.list.push(v); return v;
  }
  placeCotonou() {
    const W = this.world, near = (arr, f) => arr.filter(f).sort((a, b) => Math.hypot(a.x, a.z) - Math.hypot(b.x, b.z))[0];
    const maq = near(W.shopFronts || [], (f) => f.name === 'MAQUIS LE BON GOÛT');
    if (maq) this.add('Cotonou', 'restaurant', maq.x, maq.z, maq.ry, { host: true });
    const ali = near(W.shopFronts || [], (f) => f.name === 'ALIMENTATION DIEU MERCI');
    if (ali) this.add('Cotonou', 'minimarche', ali.x, ali.z, ali.ry, { host: true });
    const bank = near(W.namedPlaces || [], (o) => o.name === 'BANQUE LAGUNE' && o.door);
    if (bank) this.add('Cotonou', 'banque', bank.door.x, bank.door.z, bank.door.ry, { host: true });
    const hot = near(W.namedPlaces || [], (o) => o.name === 'HÔTEL OCÉAN BLEU' && o.door);
    if (hot) this.add('Cotonou', 'hotel', hot.door.x, hot.door.z, hot.door.ry, { host: true });
    // paillotes de la plage (comptoirs existants)
    this.add('Cotonou', 'bar', -100, 163.6, PI, { host: true, sign: { x: -100, y: 2.3, z: 163.7 } });
    this.add('Cotonou', 'poissonnerie', 100, 163.6, PI, { host: true, sign: { x: 100, y: 2.3, z: 163.7 } });
    // station à la sortie est (RNIE 1 vers Porto-Novo)
    this.placeStation('Cotonou', 520, -110, null);
    const g = new THREE.Group(); this.scene.add(g); this.groups.push({ g, x: 0, z: 60, r: 500 });
    for (const v of this.list.filter((q) => q.town === 'Cotonou' && q.sign)) this.signMesh(v, g, v.sign.x, v.sign.y, v.sign.z, v.ry + PI, 2.6);
  }
  placeTown(t) {
    const cands = t.houses.filter((h) => Math.hypot(h.x - t.x, h.z - t.z) < t.r * 0.45).sort((a, b) => (b.shop - a.shop) || (Math.hypot(a.x - t.x, a.z - t.z) - Math.hypot(b.x - t.x, b.z - t.z)));
    const g = new THREE.Group(); this.scene.add(g); this.groups.push({ g, x: t.x, z: t.z, r: t.r + 500 });
    const used = new Set();
    this.placeStation(t.name, t.x, t.z, t); // d'abord la station (elle libère son terrain au bord de la route)
    const pool = cands.filter((h) => t.houses.includes(h));
    for (const type of ORDER) {
      if (type === 'station') continue;
      for (const h of pool) {
        if (used.has(h)) continue;
        const fx = Math.sin(h.ry), fz = Math.cos(h.ry), e = Math.max(h.w, h.d) * 0.5 * 0.8;
        const off = Math.max(h.d / 2 + 1.4, e + 0.9), px = h.x + fx * off, pz = h.z + fz * off;
        if (t.houses.some((o) => o !== h && Math.abs(px - o.x) < Math.max(o.w, o.d) * 0.4 + 0.6 && Math.abs(pz - o.z) < Math.max(o.w, o.d) * 0.4 + 0.6)) continue;
        if (!okLand(px, pz, 2) || nearRoad(px, pz)) continue;
        used.add(h); h.shop = true;
        const v = this.add(t.name, type, px, pz, h.ry, { house: h });
        const sy = Math.min(h.h - 0.5, 3.3), sx = h.x + fx * (h.d / 2 + 0.09), sz = h.z + fz * (h.d / 2 + 0.09);
        this.signMesh(v, g, sx, sy, sz, h.ry, Math.min(h.w - 1, 4.6));
        break;
      }
    }
  }
  signTex(v) {
    const T = TYPES[v.type], c = document.createElement('canvas'); c.width = 512; c.height = 128; const x = c.getContext('2d');
    x.fillStyle = T.color; x.fillRect(0, 0, 512, 128); x.fillStyle = 'rgba(255,255,255,0.9)'; x.fillRect(0, 112, 512, 16);
    x.font = '64px sans-serif'; x.textBaseline = 'middle'; x.fillText(T.icon, 14, 58);
    x.fillStyle = '#fff'; let fs = 40; x.font = `900 ${fs}px Arial`; const name = v.name.replace(/ — .*/, '');
    while (x.measureText(name).width > 400 && fs > 18) { fs -= 2; x.font = `900 ${fs}px Arial`; }
    x.fillText(name, 96, 46); x.font = '700 22px Arial'; x.fillStyle = '#ffe9a8'; x.fillText(`${T.label}${v.type === 'bar' ? '' : ''} • ${v.town}`, 96, 90);
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; return t;
  }
  signMesh(v, g, x, y, z, ry, w) {
    const p = new THREE.Mesh(new THREE.PlaneGeometry(w, w / 4), new THREE.MeshBasicMaterial({ map: this.signTex(v), toneMapped: false }));
    p.position.set(x, y, z); p.rotation.y = ry; g.add(p);
  }
  // station-service : auvent, 2 îlots de pompes, boutique, totem (le long de la RNIE 1)
  placeStation(town, cx, cz, t) {
    const np = nearestOnRoad(cx, cz); if (!np) return;
    const h = np.h, ax = Math.sin(h), az = Math.cos(h);
    let best = null;
    for (const k of [0, 1, -1, 2, -2, 3, -3, 4, -4, 5, -5, 6, -6]) for (const side of [1, -1]) {
      if (best) break;
      const bx = np.x + ax * k * 30, bz = np.z + az * k * 30, nx = Math.cos(h) * side, nz = -Math.sin(h) * side;
      const C = { x: bx + nx * 20, z: bz + nz * 20 };
      const P = (u, v) => ({ x: C.x + ax * u + nx * v, z: C.z + az * u + nz * v });
      const corners = [P(-13, -9), P(13, -9), P(-13, 9), P(13, 9), P(0, 5.5)];
      if (corners.every((q) => okLand(q.x, q.z, 3) && !inCity(q.x, q.z) && !inAirport(q.x, q.z)) && !nearRoad(P(0, 5.5).x, P(0, 5.5).z)) best = { C, P, nx, nz };
    }
    if (!best) return;
    const { C, P } = best, col = this.world.collision, parts = [], glow = [];
    // libère l'emplacement (maisons de la ville qui chevauchent la station)
    for (const tw of this.region.towns) tw.houses = tw.houses.filter((hh) => { const hit = Math.hypot(hh.x - C.x, hh.z - C.z) < 17 + Math.max(hh.w, hh.d) * 0.5; if (hit && hh.col) hh.col.disabled = true; return !hit; });
    const rot = Math.atan2(ax, az);
    const box = (w, hgt, d, u, y, v, c, arr = parts) => { const q = P(u, v); arr.push(colored(new THREE.BoxGeometry(w, hgt, d).rotateY(rot).translate(q.x, y, q.z), c)); };
    box(26, 0.06, 18, 0, 0.03, 0, 0x9a9a96);
    box(14, 0.5, 9, 0, 4.9, -1, 0xf2f2f2); box(14.1, 0.3, 9.1, 0, 4.55, -1, 0xe46a1f);
    for (const [u, v] of [[-5.5, -4.5], [5.5, -4.5], [-5.5, 2.5], [5.5, 2.5]]) { const q = P(u, v); parts.push(colored(new THREE.CylinderGeometry(0.25, 0.25, 4.6, 8).translate(q.x, 2.3, q.z), 0xd8d8d8)); col.addCircle(q.x, q.z, 0.3, 5); }
    for (const u of [-3, 3]) { box(1.4, 0.25, 3.6, u, 0.13, -1, 0xc8c8c4); for (const v of [-2, 0]) { box(0.7, 1.7, 0.55, u, 1.1, v, 0xf2f2f2); box(0.72, 0.35, 0.57, u, 1.6, v, 0xe46a1f); const q = P(u, v); glow.push(colored(new THREE.PlaneGeometry(0.4, 0.22).rotateY(rot + PI / 2).translate(q.x + Math.cos(rot) * 0.37, 1.35, q.z - Math.sin(rot) * 0.37), 0x9affc8)); } const q = P(u, -1); col.addCircle(q.x, q.z, 0.9, 1.8); }
    box(9, 3.4, 5, 0, 1.7, 5.5, 0xf2eee6); box(9.2, 0.4, 5.2, 0, 3.6, 5.5, 0xe46a1f); box(3.2, 1.6, 0.08, -1.5, 1.6, 2.97, 0x2a3a44); box(1.2, 2.2, 0.08, 2.2, 1.1, 2.97, 0x5a3a22);
    for (const u of [-3, 0, 3]) { const q = P(u, 5.5); col.addCircle(q.x, q.z, 2.6, 4); }
    const tq = P(11.5, -7.5); parts.push(colored(new THREE.BoxGeometry(0.5, 6, 0.5).translate(tq.x, 3, tq.z), 0x2a2d33)); col.addCircle(tq.x, tq.z, 0.4, 6);
    const g = new THREE.Group(); this.scene.add(g); this.groups.push({ g, x: C.x, z: C.z, r: 900 });
    const m = new THREE.Mesh(mergeGeometries(parts), this.mat); m.castShadow = true; m.receiveShadow = true; g.add(m);
    g.add(new THREE.Mesh(mergeGeometries(glow), new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false })));
    const pump = P(0, -1), v = this.add(town, 'station', pump.x, pump.z, rot, { r: 6.5, cx: C.x, cz: C.z });
    // panneaux : façade de la boutique et totem (prix)
    const fq = P(0, 2.9); this.signMesh(v, g, fq.x, 3.0, fq.z, rot + PI, 5);
    const tex = (() => { const c = document.createElement('canvas'); c.width = 256; c.height = 320; const x = c.getContext('2d'); x.fillStyle = '#e46a1f'; x.fillRect(0, 0, 256, 320); x.fillStyle = '#fff'; x.textAlign = 'center'; x.font = '900 34px Arial'; x.fillText('⛽ STATION', 128, 56); x.font = '700 22px Arial'; x.fillText(v.name.replace('Station ', ''), 128, 92); x.fillStyle = '#111'; x.fillRect(20, 120, 216, 170); x.fillStyle = '#9affc8'; x.font = '700 24px Arial'; x.fillText('SUPER', 128, 160); x.font = '900 52px Arial'; x.fillText(`${FUEL_PRICE}`, 128, 222); x.font = '700 20px Arial'; x.fillText('FCFA / L (prix du jeu)', 128, 266); const t2 = new THREE.CanvasTexture(c); t2.colorSpace = THREE.SRGBColorSpace; return t2; })();
    for (const s of [0, PI]) { const pl = new THREE.Mesh(new THREE.PlaneGeometry(1.8, 2.25), new THREE.MeshBasicMaterial({ map: tex, toneMapped: false })); pl.position.set(tq.x + Math.sin(rot + s) * 0.27, 5.2, tq.z + Math.cos(rot + s) * 0.27); pl.rotation.y = rot + s + PI; g.add(pl); }
  }
  pois() {
    return this.list.map((v) => ({ id: `venue:${v.id}`, name: v.name, cat: TYPES[v.type].cat, x: v.x, z: v.z, status: 'fictif', access: true, note: `${TYPES[v.type].icon} ${TYPES[v.type].label} • ${v.town} • ${this.hoursText(v)} • établissement fictif` }));
  }
  hoursText(v) { const [a, b] = TYPES[v.type].open; return a === 0 && b === 24 ? 'ouvert 24 h/24' : `ouvert de ${a} h à ${b} h`; }
  isOpen(v) { const [a, b] = TYPES[v.type].open, h = this.env.time; return h >= a && h < b; }

  // ------------------------------------------------------------------ stock & sauvegarde
  items(v) {
    if (v.type === 'restaurant') return MENUS[v.town].map((p, i) => `menu${i}`);
    if (v.type === 'bar') return BAR;
    if (v.type === 'poissonnerie') return FISH[v.town];
    if (v.type === 'minimarche') return MINI;
    return [];
  }
  restock() { for (const v of this.list) for (const id of this.items(v)) this.stock[`${v.id}:${id}`] = v.type === 'restaurant' ? 15 : v.type === 'bar' ? 30 : 12; }
  left(v, id) { return this.stock[`${v.id}:${id}`] ?? 0; }
  serialize() { return { stock: { ...this.stock }, day: this.stockDay, fuel: { ...this.fuel }, savings: this.savings, savingsLog: this.savingsLog.slice(0, 30) }; }
  restore(s) {
    if (!s) return;
    if (s.stock) for (const [k, n] of Object.entries(s.stock)) if (k in this.stock) this.stock[k] = Math.max(0, n | 0);
    this.savings = Math.max(0, +s.savings || 0); this.savingsLog = Array.isArray(s.savingsLog) ? s.savingsLog : [];
    this.stockDay = s.day ?? -1; if (s.fuel) for (const [k, n] of Object.entries(s.fuel)) this.fuel[k] = Math.max(0, +n || 0);
  }

  // ------------------------------------------------------------------ carburant
  carKey(car) { if (!car || car.isAircraft) return null; if (car.personal) return 'perso'; if (car.uid) return `g${car.uid}`; return null; }
  capacity(car) { return car.isMoto ? 12 : 50; }
  level(car) { const k = this.carKey(car); if (!k) return null; if (this.fuel[k] === undefined) this.fuel[k] = this.capacity(car); return this.fuel[k]; }
  ownedNear(x, z, r = 14) {
    const out = [];
    for (const c of this.cars || []) if (this.carKey(c) && Math.hypot(c.pos.x - x, c.pos.z - z) < r) out.push(c);
    if (this.garage) for (const c of this.garage.cars || []) if (this.carKey(c) && !out.includes(c) && Math.hypot(c.pos.x - x, c.pos.z - z) < r) out.push(c);
    return out;
  }
  carName(car) { return car.personal ? 'Voiture personnelle' : car.spec ? car.spec.name : car.isMoto ? 'Moto' : 'Véhicule'; }
  // entrée de conduite : plus d'accélération quand le réservoir est vide
  carInput(car, input) {
    const L = this.level(car); if (L === null || L > 0) return input;
    return { down: (k) => (k === 'KeyW' || k === 'ArrowUp' || k === 'KeyS' || k === 'ArrowDown' ? false : input.down(k)), hit: (k) => input.hit(k) };
  }
  updateFuel(dt, car) {
    const k = this.carKey(car), el = this.hud;
    if (!k) { if (el) el.classList.remove('show'); this._last = null; return; }
    const L0 = this.level(car), cap = this.capacity(car);
    if (this._last && this._last.car === car) {
      const d = Math.hypot(car.pos.x - this._last.x, car.pos.z - this._last.z);
      if (d < 50) this.fuel[k] = Math.max(0, L0 - d / 1000 * (car.isMoto ? 0.35 : 0.9) - (Math.abs(car.speed) > 0.5 ? 0 : dt * 0.0004));
    }
    this._last = { car, x: car.pos.x, z: car.pos.z };
    const L = this.fuel[k], pct = L / cap;
    if (pct < 0.15 && !this._low) { this._low = true; const s = this.nearestStation(car.pos.x, car.pos.z); this.ui.toast(`⛽ Réservoir presque vide (${L.toFixed(1)} L). Station la plus proche : ${s ? `${s.name} à ${(s.d / 1000).toFixed(1)} km` : '—'}`, 4); }
    if (pct > 0.2) this._low = false;
    if (L <= 0 && !this._empty) { this._empty = true; this.ui.toast('⛽ Panne sèche ! Pousse jusqu’à une station ou fais venir de l’essence à pied depuis une station.', 4); }
    if (L > 0) this._empty = false;
    if (el) { el.classList.add('show'); el.innerHTML = `<i style="width:${Math.round(pct * 100)}%;background:${pct < 0.15 ? '#ff5a4a' : pct < 0.35 ? '#f2c200' : '#2fd05a'}"></i><span>⛽ ${L.toFixed(1)} / ${cap} L</span>`; }
  }
  nearestStation(x, z) { let b = null; for (const v of this.list) if (v.type === 'station') { const d = Math.hypot(v.x - x, v.z - z); if (!b || d < b.d) b = { ...v, d }; } return b; }

  // ------------------------------------------------------------------ interaction
  nearest(x, z) {
    let best = null;
    for (const v of this.list) { const d = Math.hypot(x - v.x, z - v.z), r = v.r || 2.2; if (d < r && (!best || d < best.d)) best = { d, v }; }
    if (!best) return null;
    const v = best.v, T = TYPES[v.type];
    if (this.interiors && ['restaurant', 'hotel', 'banque'].includes(v.type)) return { d: best.d * 0.8, it: { label: () => `${T.icon} Entrer : ${v.name}${this.isOpen(v) ? '' : ' (fermé)'}`, action: () => this.interiors.enter(v) } };
    return { d: best.d * 0.8, it: { label: () => `${T.icon} ${v.name}${this.isOpen(v) ? '' : ' (fermé)'} — ${T.label}`, action: () => this.toggle(true, v) } };
  }
  update(dt, P) {
    if (this.economy && this.economy.day !== this.stockDay) { if (this.stockDay !== -1) this.restock(); this.stockDay = this.economy.day; }
    for (const q of this.groups) q.g.visible = Math.hypot(P.x - q.x, P.z - q.z) < q.r;
    if (this.sleep) {
      const s = this.sleep; s.t += dt;
      if (s.phase === 0 && s.t > 1.0) { s.phase = 1; this.ui.fade(true); }
      if (s.phase === 1 && s.t > 2.4) {
        s.phase = 2; const n = this.needs, hrs = s.hours;
        this.env.time = (this.env.time + hrs) % 24;
        n.energy = Math.min(100, s.energy === 100 ? 100 : n.energy + s.energy); if (s.hyg) n.hygiene = 100;
        n.hunger = Math.max(0, n.hunger - hrs * 1.5);
        this.ui.fade(false); this.ui.toast(s.msg.replace('{h}', this.env.clock), 3.5);
      }
      if (s.t > 3.2) { this.sleep = null; this.onSave && this.onSave(); }
    }
  }
  // ---- banque : compte de dépôt personnel (BANQUE LAGUNE, fictive) — dépôts et retraits au guichet ou au distributeur ----
  bankOps() {
    const amts = [5000, 10000, 25000, 50000, 100000], F = this.bankForm;
    let h = `<div class="ve-row"><span><b>💼 Compte de dépôt BANQUE LAGUNE</b><small>Argent mis en sécurité à la banque (monnaie du jeu) • portefeuille : ${fcfa(this.economy.balance)}</small></span><em>${fcfa(this.savings)}</em></div>
      <div class="ve-row"><span><b>${this.atm ? '🏧 Distributeur' : '🧾 Guichet'} — dépôt</b><small>Portefeuille → compte</small></span>${amts.map((a) => `<button data-ve="bkq:dep:${a}" ${this.economy.balance >= a ? '' : 'disabled'}>${a / 1000} k</button>`).join('')}</div>
      <div class="ve-row"><span><b>${this.atm ? '🏧 Distributeur' : '🧾 Guichet'} — retrait</b><small>Compte → portefeuille</small></span>${amts.map((a) => `<button class="alt" data-ve="bkq:wd:${a}" ${this.savings >= a ? '' : 'disabled'}>${a / 1000} k</button>`).join('')}</div>`;
    if (F) h += `<div class="ve-confirm"><b>Confirmer ${F.op === 'dep' ? 'le dépôt' : 'le retrait'} de ${fcfa(F.amount)} — ${F.op === 'dep' ? `portefeuille après : ${fcfa(this.economy.balance - F.amount)}` : `compte après : ${fcfa(this.savings - F.amount)}`}</b><button class="ve-go" data-ve="bkok:${F.token}">CONFIRMER</button><button class="alt" data-ve="bkno">Annuler</button></div>`;
    if (this.savingsLog.length) h += `<div class="ve-list">${this.savingsLog.slice(0, 4).map((l) => `<div class="ve-row"><span><b>${l.label}</b><small>${l.t}</small></span><em class="${l.amount < 0 ? 'neg' : 'pos'}">${l.amount < 0 ? '−' : '+'}${fcfa(Math.abs(l.amount))}</em></div>`).join('')}</div>`;
    return h;
  }
  bankExec(token) {
    const F = this.bankForm; if (!F || F.token !== token) return; this.bankForm = null; // jeton à usage unique : pas de double opération
    const where = `${this.v ? this.v.name : 'BANQUE LAGUNE'} (${this.atm ? 'distributeur' : 'guichet'})`;
    if (F.op === 'dep') { if (this.economy.balance < F.amount) return this.ui.toast('Solde du portefeuille insuffisant.', 2); if (!this.economy.pay(F.amount, 'Dépôt sur le compte BANQUE LAGUNE', where)) return; this.savings += F.amount; }
    else { if (this.savings < F.amount) return this.ui.toast('Solde du compte insuffisant.', 2); this.savings -= F.amount; this.economy.earn(F.amount, 'Retrait du compte BANQUE LAGUNE', where); }
    this.savingsLog.unshift({ label: F.op === 'dep' ? 'Dépôt' : 'Retrait', amount: F.op === 'dep' ? F.amount : -F.amount, t: this.economy.stamp() }); this.savingsLog.length = Math.min(this.savingsLog.length, 30);
    if (this.audio && this.audio.ctx) this.audio.tone(this.atm ? 1200 : 700, 0.08, 0.04, 'square');
    this.render(); this.onSave && this.onSave();
  }
  pay(total, label, v) {
    const sig = `${label}|${total}`, now = performance.now();
    if (this._lastPay && this._lastPay.sig === sig && now - this._lastPay.t < 600) return false; // anti double-clic : même paiement répété
    this._lastPay = { sig, t: now };
    if (this.economy.balance < total) { this.ui.toast('Solde insuffisant.', 2); return false; }
    return this.economy.pay(total, label, `${v.name} (${v.town})`);
  }
  plateOf(v, id) { const i = +id.slice(4); return MENUS[v.town][i]; }
  plateName(items) { return items.map((i) => FOOD_BY_ID[i].name).join(' + '); }
  plateHunger(items) { return items.reduce((a, i) => a + FOOD_BY_ID[i].hunger, 0); }
  priceOf(v, id) {
    if (v.type === 'restaurant') return r25(this.plateOf(v, id).reduce((a, i) => a + FOOD_BY_ID[i].price, 0) * 1.25);
    const f = FOOD_BY_ID[id]; if (f) return r25(f.price * (v.type === 'bar' ? 1.5 : v.type === 'minimarche' ? 1.15 : 1.1));
    return ARTICLE_BY_ID[id] ? r25(ARTICLE_BY_ID[id].price * 1.1) : 0;
  }
  nameOf(v, id) { return v.type === 'restaurant' ? this.plateName(this.plateOf(v, id)) : FOOD_BY_ID[id] ? FOOD_BY_ID[id].name : ARTICLE_BY_ID[id].name; }
  buy(v, id, mode) {
    const left = this.left(v, id); if (left <= 0) return this.ui.toast('Épuisé pour aujourd’hui : réassort demain matin.', 2);
    const price = this.priceOf(v, id), name = this.nameOf(v, id);
    if (!this.pay(price, name, v)) return;
    this.stock[`${v.id}:${id}`] = left - 1;
    const foods = v.type === 'restaurant' ? this.plateOf(v, id) : [id];
    if (mode === 'here') {
      const h = foods.reduce((a, i) => a + (FOOD_BY_ID[i] ? FOOD_BY_ID[i].hunger : 0), 0);
      this.needs.hunger = Math.min(100, this.needs.hunger + h); if (v.type === 'bar') this.needs.energy = Math.min(100, this.needs.energy + 3);
      this.ui.toast(`${v.type === 'bar' ? 'Tu bois' : 'Bon appétit !'} ${name} • Faim +${h}`, 2.5);
      if (this.onHere) this.onHere(v, foods);
    } else {
      for (const i of foods) { if (FOOD_BY_ID[i]) this.economy.addToBag(i, 1); else this.economy.addItem(i, 1); }
      this.ui.toast(`${name} : dans ton sac${FOOD_BY_ID[foods[0]] ? ' (à ranger au frigo)' : ''}`, 2.2);
    }
    if (this.audio && this.audio.ctx) this.audio.tone(880, 0.06, 0.04, 'sine');
    this.render(); this.onSave && this.onSave();
  }
  hotel(v, kind) {
    const H = { rest: [5000, 'Repos 2 h'], night: [15000, 'Nuit — chambre standard'], comfort: [25000, 'Nuit — chambre confort'], shower: [1000, 'Douche'] }[kind];
    if (!this.pay(H[0], H[1], v)) return;
    this.toggle(false);
    if (this.interiors && this.interiors.inside === 'hotel') return this.interiors.giveKey(v, kind); // la chambre se trouve à l'étage de l'hôtel
    if (kind === 'shower') { this.needs.hygiene = 100; this.ui.toast('Douche prise : propreté 100 %', 2.5); this.onSave && this.onSave(); return; }
    this.startSleep(v, kind);
  }
  startSleep(v, kind) {
    const toMorning = ((7 - this.env.time) + 24) % 24 || 24;
    this.sleep = kind === 'rest' ? { t: 0, phase: 0, hours: 2, energy: 30, msg: `Repos terminé ({h}). Énergie +30` }
      : { t: 0, phase: 0, hours: toMorning, energy: 100, hyg: kind === 'comfort', msg: `Bonjour ! Il est {h}. Bonne nuit passée à ${v.name}. Énergie 100 %${kind === 'comfort' ? ', propreté 100 %' : ''}` };
  }
  refuel(car, liters, v) {
    const k = this.carKey(car); if (!k) return;
    const cap = this.capacity(car), cur = this.level(car), L = Math.min(liters, cap - cur);
    if (L < 0.5) return this.ui.toast('Le réservoir est déjà plein.', 2);
    const price = r25(L * FUEL_PRICE);
    if (!this.pay(price, `Carburant ${L.toFixed(1)} L — ${this.carName(car)}`, v)) return;
    this.fuel[k] = Math.min(cap, cur + L);
    this.ui.toast(`⛽ ${L.toFixed(1)} L ajoutés (${fcfa(price)}). Réservoir : ${this.fuel[k].toFixed(1)} / ${cap} L`, 3);
    if (this.audio && this.audio.ctx) this.audio.tone(320, 0.4, 0.03, 'sine');
    this.confirm = null; this.render(); this.onSave && this.onSave();
  }

  // ------------------------------------------------------------------ interface
  toggle(on, v = this.v, atm = false) {
    this.atm = on ? atm : false; this.bankForm = null;
    if (on && !this.isOpen(v)) { this.ui.toast(`${v.name} est fermé (${this.hoursText(v)}).`, 2.5); return; }
    this.open = on; this.v = v; this.confirm = null; this.dom.classList.toggle('show', on);
    if (on) { this.sel = this.items(v)[0] || null; this.render(); }
  }
  render() {
    if (!this.open) return;
    const v = this.v, T = TYPES[v.type], bal = fcfa(this.economy.balance);
    let body = '';
    if (['restaurant', 'bar', 'poissonnerie', 'minimarche'].includes(v.type)) {
      const here = v.type === 'restaurant' || v.type === 'bar';
      body = `<div class="ve-list">${this.items(v).map((id) => { const n = this.left(v, id), p = this.priceOf(v, id); return `<div class="ve-row${n ? '' : ' dim'}"><span><b>${this.nameOf(v, id)}</b><small>${fcfa(p)}${v.type === 'restaurant' ? ` • faim +${this.plateHunger(this.plateOf(v, id))}` : ''} • ${n ? `reste ${n}` : 'épuisé'}</small></span>
        ${here ? `<button data-ve="here:${id}" ${n ? '' : 'disabled'}>${v.type === 'bar' ? 'Boire ici' : 'Manger ici'}</button>` : ''}<button class="alt" data-ve="take:${id}" ${n ? '' : 'disabled'}>${here ? 'À emporter' : 'Acheter'}</button></div>`; }).join('')}</div>
        <p class="ve-note">${v.type === 'bar' ? 'Boissons sans alcool uniquement. ' : ''}${here ? 'Sur place : la faim est rassasiée tout de suite. ' : ''}Les aliments achetés vont dans ton sac (à ranger au réfrigérateur de la maison).</p>`;
    } else if (v.type === 'hotel') {
      body = `<div class="ve-list">
        <div class="ve-row"><span><b>Repos de 2 heures</b><small>${fcfa(5000)} • énergie +30</small></span><button data-ve="hotel:rest">Réserver</button></div>
        <div class="ve-row"><span><b>Nuit — chambre standard</b><small>${fcfa(15000)} • dormir jusqu’à 7 h, énergie 100 %</small></span><button data-ve="hotel:night">Réserver</button></div>
        <div class="ve-row"><span><b>Nuit — chambre confort</b><small>${fcfa(25000)} • jusqu’à 7 h, énergie et propreté 100 %</small></span><button data-ve="hotel:comfort">Réserver</button></div>
        <div class="ve-row"><span><b>Douche</b><small>${fcfa(1000)} • propreté 100 %</small></span><button data-ve="hotel:shower">Payer</button></div></div>
        <p class="ve-note">Paiement immédiat depuis ton compte personnel (monnaie du jeu).</p>`;
    } else if (v.type === 'banque') {
      const G = this.group, accs = G ? G.accounts() : ['perso'];
      body = `<div class="ve-list">${accs.map((a) => `<div class="ve-row"><span><b>${G ? G.accName(a) : 'Compte personnel'}</b><small>Solde</small></span><em>${fcfa(G ? G.balance(a) : this.economy.balance)}</em></div>`).join('')}</div>
        <div class="ve-list">${(this.economy.history || []).slice(0, 5).map((h) => `<div class="ve-row"><span><b>${h.label}</b><small>${h.place} • ${h.t}</small></span><em class="${h.amount < 0 ? 'neg' : 'pos'}">${h.amount < 0 ? '−' : '+'}${fcfa(Math.abs(h.amount))}</em></div>`).join('')}</div>
        ${this.bankOps()}
        ${this.atm ? '' : '<button class="ve-go" data-ve="bank">🏦 Espace bancaire : virements, prêts, relevés</button>'}
        <p class="ve-note">Banque fictive du jeu : comptes en monnaie virtuelle uniquement, aucun lien avec une vraie banque.</p>`;
    } else if (v.type === 'station') {
      const cars = this.ownedNear(v.cx ?? v.x, v.cz ?? v.z, 18);
      body = cars.length ? `<div class="ve-list">${cars.map((c, i) => { const L = this.level(c), cap = this.capacity(c), full = cap - L, fp = r25(full * FUEL_PRICE); return `<div class="ve-row"><span><b>${this.carName(c)}</b><small>Réservoir ${L.toFixed(1)} / ${cap} L • manque ${full.toFixed(1)} L</small></span>
        <button data-ve="fuelq:${i}:full" ${full >= 0.5 ? '' : 'disabled'}>Plein • ${fcfa(fp)}</button><button class="alt" data-ve="fuelq:${i}:5000" ${full >= 0.5 ? '' : 'disabled'}>5 000 FCFA</button></div>`; }).join('')}</div>
        ${this.confirm ? `<div class="ve-confirm"><b>Confirmer : ${this.confirm.L.toFixed(1)} L pour ${this.carName(this.confirm.car)} • ${fcfa(r25(this.confirm.L * FUEL_PRICE))}</b><button class="ve-go" data-ve="fuelok">CONFIRMER LE PAIEMENT</button><button class="alt" data-ve="fuelno">Annuler</button></div>` : ''}`
        : '<p class="ve-note">Aucun de tes véhicules n’est garé près des pompes. Gare-toi sous l’auvent, descends, puis reviens ici.</p>';
      body += `<p class="ve-note">Prix du jeu : ${FUEL_PRICE} FCFA le litre (super). Paiement depuis le compte personnel, après confirmation.</p>`;
    }
    this.dom.innerHTML = `<div class="ve-box"><div class="ve-head" style="--c:${T.color}"><span class="ve-ic">${T.icon}</span><div><h2>${v.name}</h2><small>${T.label} • ${v.town} • ${this.hoursText(v)} • établissement fictif</small></div><span class="ve-bal">💰 ${bal}</span><button data-ve="x">✕</button></div>${body}</div>`;
  }
  onClick(e) {
    const b = e.target.closest('[data-ve]'); if (!b) { if (e.target === this.dom) this.toggle(false); return; }
    e.stopPropagation(); if (this.audio && this.audio.ctx && this.audio.click) this.audio.click();
    const [a, p1, p2] = b.dataset.ve.split(':'), v = this.v;
    if (a === 'x') return this.toggle(false);
    if (a === 'here' || a === 'take') return this.buy(v, p1, a);
    if (a === 'hotel') return this.hotel(v, p1);
    if (a === 'bank') { this.toggle(false); if (this.bizUI && this.company) { this.bizUI.tab = 'banque'; this.bizUI.toggle(true); } else this.ui.toast('Espace bancaire indisponible.', 2); return; }
    if (a === 'fuelq') { const car = this.ownedNear(v.cx ?? v.x, v.cz ?? v.z, 18)[+p1]; if (!car) return; const full = this.capacity(car) - this.level(car); this.confirm = { car, L: p2 === 'full' ? full : Math.min(full, 5000 / FUEL_PRICE) }; return this.render(); }
    if (a === 'fuelok' && this.confirm) return this.refuel(this.confirm.car, this.confirm.L, v);
    if (a === 'fuelno') { this.confirm = null; return this.render(); }
    if (a === 'bkq') { const amount = +p2; this.bankForm = { op: p1, amount, token: `B${Date.now()}${Math.random().toString(36).slice(2, 6)}` }; return this.render(); }
    if (a === 'bkok') return this.bankExec(p1);
    if (a === 'bkno') { this.bankForm = null; return this.render(); }
  }
  handleKeys(input) { if (input.hit('Escape') || input.hit('KeyE')) this.toggle(false); }
}
