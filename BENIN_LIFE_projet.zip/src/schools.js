// Mission 019, étape 7 — réseau de 10 établissements scolaires FICTIFS, inscription de l'enfant et application « Vie scolaire ».
// Chaque école réutilise un bâtiment existant (Cotonou : bâtiments sans usage ; villes de la région : une habitation générée
// près du centre), dotée d'une enseigne, d'un logo, d'un portail et d'un drapeau. L'intérieur est un campus isolé (un seul
// modèle partagé, habillé aux couleurs de l'établissement visité, pour préserver les performances) : salles de classe,
// bureaux administratifs, salle des professeurs, bibliothèque, salle informatique, cantine, toilettes, cour de récréation,
// terrain de sport, infirmerie, parking, portail et clôture. Élèves, enseignants, direction et personnel (PNJ fictifs)
// suivent l'emploi du temps. Inscription fictive (rendez-vous avec la direction, classe selon l'âge, frais virtuels,
// uniforme, fournitures), calendrier scolaire, notes et bulletins fictifs, absences, réunions, activités.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { colorize } from './vehicles.js';
import { createCharacter, SKINS } from './character.js';
import { fcfa } from './food-data.js';

const PI = Math.PI;
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const pick = (a) => a[Math.floor(Math.random() * a.length)];
export const CAMPUS = { LV: 170, Y: 600, O: { x: 16.5, z: 52.5 } };
// cycles et classes (système béninois : maternelle, primaire CI–CM2, collège 6e–3e, lycée 2nde–Tle)
export const CLASSES = [
  ['mat', 'Petite section', 3], ['mat', 'Moyenne section', 4], ['mat', 'Grande section', 5],
  ['pri', 'CI', 6], ['pri', 'CP', 7], ['pri', 'CE1', 8], ['pri', 'CE2', 9], ['pri', 'CM1', 10], ['pri', 'CM2', 11],
  ['col', '6e', 12], ['col', '5e', 13], ['col', '4e', 14], ['col', '3e', 15], ['lyc', 'Seconde', 16], ['lyc', 'Première', 17], ['lyc', 'Terminale', 18],
];
export const CYCLES = { mat: 'Maternelle', pri: 'Primaire', col: 'Collège', lyc: 'Lycée' };
const SUBJ = {
  mat: ['Langage', 'Éveil', 'Graphisme', 'Motricité', 'Comptines'],
  pri: ['Français', 'Mathématiques', 'Éducation scientifique', 'Histoire-Géographie', 'Anglais', 'Éducation physique'],
  col: ['Français', 'Mathématiques', 'SVT', 'Physique-Chimie', 'Histoire-Géographie', 'Anglais', 'EPS'],
  lyc: ['Français', 'Mathématiques', 'SVT', 'Physique-Chimie', 'Histoire-Géographie', 'Anglais', 'Philosophie', 'EPS'],
};
const KIT = { mat: 20000, pri: 35000, col: 50000, lyc: 60000 };
const INSCR = 25000;
// réseau d'établissements (tous fictifs : noms, logos, personnels et élèves inventés pour le jeu)
export const SCHOOLS = [
  { id: 'nova', name: 'NOVA SCHOOL COTONOU', short: 'NOVA School', town: 'Cotonou', fp: [10.5, 45, 22.5, 60], cycles: ['mat', 'pri', 'col', 'lyc'], c1: '#0b6e4f', c2: '#fcd116', uni: 0x0b6e4f, motto: 'Apprendre, oser, réussir', dir: ['Mme Hortense Adéchokan', true], sec: ['M. Gilles Hounkpè', false], fees: { mat: 150000, pri: 190000, col: 250000, lyc: 300000 }, uniform: 30000, pupils: 840, teachers: 48, pcs: 60, books: 9000, field: 'terrain synthétique', clubs: ['Robotique', 'Football', 'Théâtre'], note: 'Bilingue français-anglais, salles connectées.' },
  { id: 'littoral', name: 'ACADÉMIE DU LITTORAL', short: 'Académie du Littoral', town: 'Cotonou', fp: [-122.8, 24.5, -110.8, 39.5], cycles: ['mat', 'pri', 'col'], c1: '#1f4e9c', c2: '#ffffff', uni: 0x2f80ed, motto: 'La mer, l’horizon, le savoir', dir: ['M. Barthélémy Dossou-Yovo', false], sec: ['Mme Clarisse Agbo', true], fees: { mat: 90000, pri: 120000, col: 160000 }, uniform: 20000, pupils: 520, teachers: 30, pcs: 25, books: 4500, field: 'terrain en sable', clubs: ['Environnement et océan', 'Chorale', 'Football'], note: 'Projet pédagogique sur le littoral et l’environnement.' },
  { id: 'elites', name: 'GROUPE SCOLAIRE LES ÉLITES', short: 'Les Élites', town: 'Cotonou', fp: [137.8, -123, 155.8, -111], cycles: ['pri', 'col', 'lyc'], c1: '#6a1a2a', c2: '#d8a830', uni: 0x7a2a3a, motto: 'Excellence et discipline', dir: ['M. Raoul Agossou', false], sec: ['Mme Viviane Tchibozo', true], fees: { pri: 160000, col: 220000, lyc: 280000 }, uniform: 28000, pupils: 690, teachers: 42, pcs: 45, books: 7000, field: 'terrain multisport', clubs: ['Mathématiques', 'Débat', 'Basket-ball'], note: 'Préparation renforcée aux examens (CEP, BEPC, BAC).' },
  { id: 'inter', name: 'ÉCOLE INTERNATIONALE DE COTONOU', short: 'École internationale', town: 'Cotonou', fp: [132.5, 10.4, 147.5, 22.4], cycles: ['mat', 'pri', 'col', 'lyc'], c1: '#0a2a5a', c2: '#e8112d', uni: 0x0a2a5a, motto: 'Ouverts sur le monde', dir: ['Mme Nadia Soglo-Kpadé', true], sec: ['M. Arnaud Lokossou', false], fees: { mat: 280000, pri: 350000, col: 420000, lyc: 480000 }, uniform: 35000, pupils: 610, teachers: 52, pcs: 80, books: 12000, field: 'terrain synthétique', clubs: ['Model UN', 'Musique', 'Natation scolaire'], note: 'Programme bilingue, langues étrangères dès la maternelle (établissement fictif).' },
  { id: 'cocotomey', name: 'COLLÈGE MODERNE DE COCOTOMEY', short: 'Collège de Cocotomey', town: 'Cocotomey', cycles: ['col', 'lyc'], c1: '#e46a1f', c2: '#ffffff', uni: 0xe46a1f, motto: 'Travail, rigueur, avenir', dir: ['M. Sylvestre Houngbo', false], sec: ['Mme Eugénie Azon', true], fees: { col: 110000, lyc: 140000 }, uniform: 18000, pupils: 950, teachers: 44, pcs: 30, books: 5000, field: 'terrain en latérite', clubs: ['Football', 'Informatique', 'Journal du collège'], note: 'Grand collège de quartier, très bons résultats au BEPC.' },
  { id: 'portonovo', name: 'ACADÉMIE DE PORTO-NOVO', short: 'Académie de Porto-Novo', town: 'Porto-Novo', cycles: ['pri', 'col', 'lyc'], c1: '#2a5a2a', c2: '#fcd116', uni: 0x2f7a3a, motto: 'Culture, savoir, citoyenneté', dir: ['Mme Odette Adjaho', true], sec: ['M. Prosper Ahouandjinou', false], fees: { pri: 100000, col: 140000, lyc: 180000 }, uniform: 20000, pupils: 780, teachers: 40, pcs: 35, books: 8000, field: 'terrain multisport', clubs: ['Patrimoine et histoire', 'Danse', 'Échecs'], note: 'Ateliers sur le patrimoine de la capitale.' },
  { id: 'ouidah', name: 'GROUPE SCOLAIRE D’OUIDAH', short: 'G. S. d’Ouidah', town: 'Ouidah', cycles: ['mat', 'pri', 'col'], c1: '#7a2a8a', c2: '#ffffff', uni: 0x7a2a8a, motto: 'Mémoire et avenir', dir: ['M. Firmin Kpanou', false], sec: ['Mme Rachelle Hessou', true], fees: { mat: 70000, pri: 90000, col: 130000 }, uniform: 16000, pupils: 560, teachers: 31, pcs: 20, books: 4000, field: 'terrain en sable', clubs: ['Arts plastiques', 'Contes et traditions', 'Football'], note: 'Ateliers d’histoire, de contes et de respect des traditions.' },
  { id: 'pahou', name: 'ÉCOLE MODERNE DE PAHOU', short: 'École de Pahou', town: 'Pahou', cycles: ['mat', 'pri'], c1: '#0b8a8a', c2: '#fcd116', uni: 0x0b8a8a, motto: 'Grandir ensemble', dir: ['Mme Bernadette Gandaho', true], sec: ['M. Élie Sossou', false], fees: { mat: 50000, pri: 70000 }, uniform: 12000, pupils: 320, teachers: 18, pcs: 12, books: 2500, field: 'terrain en herbe', clubs: ['Jardinage', 'Chant', 'Football'], note: 'Petite école familiale avec jardin pédagogique.' },
  { id: 'lycee', name: 'LYCÉE DU GRAND COTONOU', short: 'Lycée du Grand Cotonou', town: 'Cotonou', fp: [-122.5, -157.5, -110.5, -142.5], cycles: ['col', 'lyc'], c1: '#1a1a1a', c2: '#fcd116', uni: 0x2a2d33, motto: 'Le savoir élève', dir: ['M. Augustin Gbaguidi', false], sec: ['Mme Félicité Zinsou', true], fees: { col: 150000, lyc: 200000 }, uniform: 22000, pupils: 1200, teachers: 64, pcs: 50, books: 10000, field: 'terrain multisport', clubs: ['Sciences', 'Théâtre', 'Basket-ball'], note: 'Séries scientifiques et littéraires.' },
  { id: 'institut', name: 'INSTITUT SCOLAIRE NOVA', short: 'Institut NOVA', town: 'Cotonou', fp: [-90, -122.9, -75, -110.9], cycles: ['mat', 'pri', 'col'], c1: '#e8112d', c2: '#ffffff', uni: 0xc8102e, motto: 'Chaque enfant compte', dir: ['Mme Irène Akakpo', true], sec: ['M. Charles Fanou', false], fees: { mat: 120000, pri: 160000, col: 210000 }, uniform: 25000, pupils: 480, teachers: 32, pcs: 40, books: 6000, field: 'terrain synthétique', clubs: ['Codage', 'Peinture', 'Football'], note: 'Petits effectifs (25 élèves par classe), suivi personnalisé.' },
];
const SBY = Object.fromEntries(SCHOOLS.map((s) => [s.id, s]));
// campus (repère local) : enceinte x −32…32, z −24…24 ; portail au sud
const ROOMS = [
  ['c1', 'Classe', -31.5, 13, -22.5, 23, 'classe'], ['c2', 'Classe', -22.5, 13, -13.5, 23, 'classe'], ['c3', 'Classe', -13.5, 13, -4.5, 23, 'classe'], ['c4', 'Classe', -4.5, 13, 4.5, 23, 'classe'],
  ['c5', 'Classe', 4.5, 13, 13.5, 23, 'classe'], ['c6', 'Classe', 13.5, 13, 22.5, 23, 'classe'], ['biblio', 'Bibliothèque', 22.5, 13, 31.5, 23, 'biblio'],
  ['direction', 'Bureaux administratifs', -31.5, 3.4, -22, 10.2, 'direction'], ['profs', 'Salle des professeurs', -31.5, -4, -22, 3.4, 'profs'], ['cantine', 'Cantine', -31.5, -12, -22, -4, 'cantine'],
  ['info', 'Salle informatique', 22, 4, 31.5, 10.2, 'info'], ['infirmerie', 'Infirmerie', 22, -1, 31.5, 4, 'infirmerie'], ['wc', 'Toilettes', 22, -8, 31.5, -1, 'wc'],
];
// calendrier scolaire fictif (année de 80 jours de jeu)
const YEAR = 80, TERMS = [[0, 19, '1er trimestre'], [24, 43, '2e trimestre'], [48, 67, '3e trimestre']], VAC = [[20, 23, 'Vacances de fin d’année'], [44, 47, 'Vacances de Pâques'], [68, 79, 'Grandes vacances']];
const DAYS = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche'];

export class Schools {
  constructor(ctx) {
    Object.assign(this, ctx); // scene, world, region, player, ui, audio, env, economy, needs, tpc, home, events, onSave
    this.inside = false; this.cur = null; this.points = []; this.people = []; this.enr = {}; this.rdv = null; this.met = {}; this.view = 'enfant'; this.sel = null; this.lastDay = null; this.logos = {};
    this.buildOutsides(); this.buildCampus();
  }
  // ------------------------------------------------------------------ calendrier
  day() { return this.economy.day || 1; }
  dow(d = this.day()) { return (d - 1) % 7; } // jour 1 = lundi
  yt(d = this.day()) { return (d - 1) % YEAR; }
  year(d = this.day()) { return Math.floor((d - 1) / YEAR) + 1; }
  term(d = this.day()) { const t = this.yt(d), i = TERMS.findIndex(([a, b]) => t >= a && t <= b); return i < 0 ? null : { i, a: TERMS[i][0], b: TERMS[i][1], label: TERMS[i][2] }; }
  vacation(d = this.day()) { const t = this.yt(d), v = VAC.find(([a, b]) => t >= a && t <= b); return v ? v[2] : null; }
  schoolDay(d = this.day()) { return this.dow(d) < 5 && !!this.term(d); }
  dayStart(d) { return d - this.yt(d); }
  // ------------------------------------------------------------------ outils
  cycleOf(age) { return age < 6 ? 'mat' : age < 12 ? 'pri' : age < 16 ? 'col' : 'lyc'; }
  classIdxFor(age) { let i = CLASSES.findIndex((c) => c[2] === Math.min(18, Math.max(3, age))); return i < 0 ? 0 : i; }
  offers(s, ci) { return s.cycles.includes(CLASSES[ci][0]); }
  logo(s) {
    if (this.logos[s.id]) return this.logos[s.id];
    const c = document.createElement('canvas'); c.width = c.height = 256; const x = c.getContext('2d');
    x.fillStyle = s.c1; x.beginPath(); x.arc(128, 128, 120, 0, 7); x.fill(); x.strokeStyle = s.c2; x.lineWidth = 10; x.beginPath(); x.arc(128, 128, 100, 0, 7); x.stroke();
    x.fillStyle = s.c2; x.beginPath(); x.moveTo(70, 120); x.lineTo(128, 90); x.lineTo(186, 120); x.lineTo(128, 150); x.closePath(); x.fill(); x.fillRect(150, 122, 6, 40); // toque de diplômé stylisée
    x.font = '900 46px Arial'; x.textAlign = 'center'; x.fillText(s.short.split(' ').filter((w) => /^[A-ZÉ]/.test(w) && w.length > 2).map((w) => w[0]).join('').slice(0, 3) || s.short[0], 128, 208);
    this.logos[s.id] = c; return c;
  }
  logoURL(s) { const c = this.logo(s); if (!s._url) s._url = c.toDataURL('image/png'); return s._url; }
  label(a, b, w, h, bg, fg = '#fff', logoS = null) {
    const c = document.createElement('canvas'); c.width = 768; c.height = Math.round(768 * h / w); const x = c.getContext('2d'); x.fillStyle = bg; x.fillRect(0, 0, c.width, c.height);
    let ox = c.width / 2; if (logoS) { const L = this.logo(logoS), sz = c.height * 0.86; x.drawImage(L, 8, c.height * 0.07, sz, sz); ox = (sz + 16 + c.width) / 2; }
    x.fillStyle = fg; x.textAlign = 'center'; const W = c.width - (logoS ? c.height + 30 : 30);
    let fs = Math.round(c.height * (b ? 0.36 : 0.5)); x.font = `900 ${fs}px Arial`; while (x.measureText(a).width > W && fs > 10) { fs -= 2; x.font = `900 ${fs}px Arial`; }
    x.fillText(a, ox, c.height * (b ? 0.48 : 0.66)); if (b) { x.font = `700 ${Math.round(c.height * 0.2)}px Arial`; x.fillText(b, ox, c.height * 0.82); }
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ map: t, toneMapped: false }));
  }
  // ------------------------------------------------------------------ extérieurs (bâtiments existants réutilisés)
  buildOutsides() {
    const col = this.world.collision; this.outs = [];
    for (const s of SCHOOLS) {
      let cx, cz, faces;
      if (s.fp) { const [a, b, c, d] = s.fp; cx = (a + c) / 2; cz = (b + d) / 2; faces = [[cx, d, 0, 1, c - a], [cx, b, 0, -1, c - a], [c, cz, 1, 0, d - b], [a, cz, -1, 0, d - b]]; }
      else {
        const T = this.region && this.region.towns.find((t) => t.name === s.town); if (!T) continue;
        const hs = T.houses.filter((h) => !h.school && Math.hypot(h.x - T.x, h.z - T.z) < T.r * 0.45 && h.w > 9 && h.d > 9).sort((p, q) => Math.hypot(p.x - T.x - 20, p.z - T.z) - Math.hypot(q.x - T.x - 20, q.z - T.z));
        let H = null, bestF = null;
        for (const h of hs) {
          const sx = Math.sin(h.ry), cxr = Math.cos(h.ry), e = Math.max(h.w, h.d) * 0.4;
          const fs = [[h.x + sx * e, h.z + cxr * e, sx, cxr, e * 2], [h.x - sx * e, h.z - cxr * e, -sx, -cxr, e * 2], [h.x + cxr * e, h.z - sx * e, cxr, -sx, e * 2], [h.x - cxr * e, h.z + sx * e, -cxr, sx, e * 2]];
          for (const f of fs) { let sc = 0; for (const dd of [1.4, 3, 5, 7]) if (!col.pointBlocked(f[0] + f[2] * dd, 0.5, f[1] + f[3] * dd)) sc++; if (sc === 4) { bestF = f; break; } }
          if (bestF) { H = h; break; }
        }
        if (!H) continue; H.school = s.id; cx = H.x; cz = H.z; faces = [bestF];
      }
      let best = null;
      for (const [fx, fz, nx, nz, wid] of faces) { let sc = 0; for (const dd of [1.4, 3, 5, 7]) if (!col.pointBlocked(fx + nx * dd, 0.5, fz + nz * dd)) sc++; if (!best || sc > best.sc) best = { fx, fz, nx, nz, wid, sc }; }
      const ry = Math.atan2(best.nx, best.nz), g = new THREE.Group(); g.name = `ECOLE_${s.id}`; this.scene.add(g);
      const wx = best.fx + best.nx * 0.14, wz = best.fz + best.nz * 0.14, lx = Math.cos(ry), lz = -Math.sin(ry), W = Math.min(9, best.wid - 1);
      const sign = this.label(s.name, `${s.motto} • établissement fictif`, W, W * 0.17, s.c1, '#fff', s); sign.position.set(wx, 3.6, wz); sign.rotation.y = ry; g.add(sign);
      const door = new THREE.Mesh(new THREE.PlaneGeometry(2, 2.3), new THREE.MeshBasicMaterial({ color: new THREE.Color(s.c1).multiplyScalar(0.8) })); door.position.set(wx + best.nx * 0.02, 1.15, wz + best.nz * 0.02); door.rotation.y = ry; g.add(door);
      // portail : deux piliers et un fronton aux couleurs de l'école, devant l'entrée
      const pm = new THREE.MeshStandardMaterial({ color: new THREE.Color(s.c1) }), am = new THREE.MeshStandardMaterial({ color: new THREE.Color(s.c2) });
      for (const k of [-1.9, 1.9]) { const p = new THREE.Mesh(new THREE.BoxGeometry(0.4, 2.8, 0.4), pm); p.position.set(wx + best.nx * 2.2 + lx * k, 1.4, wz + best.nz * 2.2 + lz * k); g.add(p); col.addCircle(p.position.x, p.position.z, 0.25, 2.8); }
      const top = new THREE.Mesh(new THREE.BoxGeometry(4.2, 0.35, 0.3), am); top.position.set(wx + best.nx * 2.2, 2.85, wz + best.nz * 2.2); top.rotation.y = ry; g.add(top);
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 6, 6), new THREE.MeshStandardMaterial({ color: 0xd8dde2 })); pole.position.set(wx + best.nx * 2.6 + lx * 3.4, 3, wz + best.nz * 2.6 + lz * 3.4); g.add(pole);
      const flag = this.label(s.short, '', 1.5, 0.75, s.c1, s.c2); flag.position.set(pole.position.x + lx * 0.78, 5.4, pole.position.z + lz * 0.78); flag.rotation.y = ry; g.add(flag);
      s.doorPt = { x: wx + best.nx * 1.5, z: wz + best.nz * 1.5 }; s.ext = g; s.cx = cx; s.cz = cz; this.outs.push(s);
    }
  }
  // ------------------------------------------------------------------ campus intérieur (modèle unique, niveau isolé)
  buildCampus() {
    const { LV, Y, O } = CAMPUS, g = new THREE.Group(); g.position.set(O.x, Y, O.z); g.visible = false; this.scene.add(g); this.inGroup = g;
    const parts = [], col = this.world.collision, H = 3.2, T = 0.18;
    const box = (x0, y0, z0, x1, y1, z1, c) => parts.push(colorize(new THREE.BoxGeometry(Math.abs(x1 - x0), Math.abs(y1 - y0), Math.abs(z1 - z0)).translate((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), c));
    const solid = (x0, z0, x1, z1, h = H) => { const o = col.addBox(O.x + Math.min(x0, x1), O.z + Math.min(z0, z1), O.x + Math.max(x0, x1), O.z + Math.max(z0, z1), Y + h); o.lv = LV; };
    const wallX = (z, x0, x1, gaps = [], hh = H, c = 0xf2ece0) => { let a = x0; for (const [g0, g1] of [...gaps, [x1, x1]]) { if (g0 > a) { box(a, 0, z - T / 2, g0, hh, z + T / 2, c); solid(a, z - T / 2, g0, z + T / 2, hh); } a = g1; } };
    const wallZ = (x, z0, z1, gaps = [], hh = H, c = 0xf2ece0) => { let a = z0; for (const [g0, g1] of [...gaps, [z1, z1]]) { if (g0 > a) { box(x - T / 2, 0, a, x + T / 2, hh, g0, c); solid(x - T / 2, a, x + T / 2, g0, hh); } a = g1; } };
    box(-34, -0.1, -26, 34, 0, 26, 0xd8c8a8);
    // cour de récréation (dalles), préau, arbres, bancs, mât
    box(-21, 0, -12, 21, 0.02, 12.8, 0xcfc4b0); box(-8, 0, -2, 6, 0.03, 6, 0xbfb29a);
    box(-8, 3, -2, 6, 3.15, 6, 0x8a8f96); for (const [x, z] of [[-7.8, -1.8], [5.8, -1.8], [-7.8, 5.8], [5.8, 5.8]]) { box(x - 0.15, 0, z - 0.15, x + 0.15, 3, z + 0.15, 0x6a6f76); solid(x - 0.15, z - 0.15, x + 0.15, z + 0.15); }
    for (const [x, z] of [[-17, 7], [-17, -8], [14, 7], [-1, 8.6]]) { box(x - 0.25, 0, z - 0.25, x + 0.25, 2.8, z + 0.25, 0x6a4a32); box(x - 1.6, 2.8, z - 1.6, x + 1.6, 4, z + 1.6, 0x2f7a3a); solid(x - 0.3, z - 0.3, x + 0.3, z + 0.3, 3); box(x + 0.6, 0.4, z - 1, x + 1.1, 0.48, z + 1, 0x8a6a42); }
    box(-12.05, 0, -6.05, -11.95, 7, -5.95, 0xd8dde2); box(-11.95, 5.9, -6, -10.6, 6.3, -5.98, 0x0b8a3a); box(-11.95, 5.5, -6, -10.6, 5.9, -5.98, 0xfcd116); box(-11.95, 5.1, -6, -10.6, 5.5, -5.98, 0xe8112d); // drapeau du Bénin
    // parking (marquage au sol) et voitures du personnel stylisées
    box(-21, 0, -23.5, -6, 0.03, -13, 0x4a4d52); for (let k = 0; k < 6; k++) box(-20.6 + k * 2.5, 0.031, -23.4, -20.5 + k * 2.5, 0.04, -18.5, 0xf6f6f6);
    for (const [x, c] of [[-19.3, 0x2f80ed], [-14.3, 0xd8dde2], [-9.3, 0x1a1a1a]]) { box(x - 0.9, 0.2, -23, x + 0.9, 1.05, -19.2, c); box(x - 0.8, 1.05, -22.2, x + 0.8, 1.6, -20, 0x9ab8c4); solid(x - 0.9, -23, x + 0.9, -19.2, 1.6); }
    // terrain de sport (lignes, buts, panier)
    box(8, 0, -23.5, 31.5, 0.03, -9, 0x3f8a3a); box(19.7, 0.031, -23.5, 19.8, 0.04, -9, 0xffffff); for (const [z0, z1] of [[-23.5, -23.4], [-9.1, -9]]) box(8, 0.031, z0, 31.5, 0.04, z1, 0xffffff);
    for (const x of [8.3, 31.2]) { box(x - 0.05, 0, -17.5, x + 0.05, 1.8, -17.4, 0xffffff); box(x - 0.05, 0, -14.6, x + 0.05, 1.8, -14.5, 0xffffff); box(x - 0.05, 1.75, -17.5, x + 0.05, 1.85, -14.5, 0xffffff); }
    // enceinte : clôture (mur bas + grille) et portail
    const fence = (axis, k, a, b, gaps = []) => { (axis === 'x' ? wallX : wallZ)(k, a, b, gaps, 2.2, 0xe8dcc4); };
    fence('x', 24, -32, 32); fence('x', -24, -32, 32, [[-4, 4]]); fence('z', -32, -24, 24); fence('z', 32, -24, 24);
    box(-4.4, 0, -24.3, -4, 3, -23.7, 0x8a8f96); box(4, 0, -24.3, 4.4, 3, -23.7, 0x8a8f96); box(-4.4, 2.8, -24.2, 4.4, 3.1, -23.8, 0x8a8f96); // portail ouvert
    for (const x of [-6.2, 6.2]) box(x - 1.8, 0, -24.1, x + 1.8, 2.2, -23.9, 0x5a5f66); // battants repliés
    // bâtiments : murs et portes
    const doorX = (r) => [(r[2] + r[4]) / 2 - 0.8, (r[2] + r[4]) / 2 + 0.8], doorZ = (r) => [(r[3] + r[5]) / 2 - 0.8, (r[3] + r[5]) / 2 + 0.8];
    wallX(13, -31.8, 31.8, ROOMS.filter((r) => r[3] === 13).map(doorX)); wallX(23, -31.8, 31.8);
    wallZ(-22, -12, 10.2, ROOMS.filter((r) => r[4] === -22).map(doorZ)); wallX(-12, -31.8, -22); wallX(10.2, -31.8, -22); wallZ(22, -8, 10.2, ROOMS.filter((r) => r[2] === 22).map(doorZ)); wallX(-8, 22, 31.8); wallX(10.2, 22, 31.8);
    box(-31.8, 0, 10.3, 31.8, 0.025, 12.9, 0xb8ad98); // couloir couvert devant les classes
    for (const r of ROOMS) { if (r[3] === 13) { if (r[2] > -31.5) wallZ(r[2], 13.1, 22.9); } else if (r[3] > -12 && !(r[3] === -8)) wallX(r[3], r[2] + 0.1, r[4] - 0.1); }
    box(-32, 3.2, 13, 32, 3.4, 23.4, 0xb4532a); box(-32, 3.2, -12.2, -22, 3.4, 13, 0xb4532a); box(22, 3.2, -8.2, 32, 3.4, 13, 0xb4532a); // toitures (débord)
    this.rooms = {}; this.plaques = {};
    const P = (x, z, r, label, action) => this.points.push({ x, z, r, label, action });
    for (const [id, name, x0, z0, x1, z1, type] of ROOMS) {
      const cx = (x0 + x1) / 2, cz = (z0 + z1) / 2; this.rooms[id] = { id, name, type, x0, z0, x1, z1, cx, cz, seats: [] };
      this.furnish(this.rooms[id], box, solid, P);
    }
    P(0, -22.4, 1.8, 'Sortir de l’école (portail)', () => this.exit());
    P(14, -16, 2.6, 'Regarder l’activité sportive', () => this.ui.toast(this.schoolTime().where === 'terrain' ? '⚽ Séance d’EPS : échauffement, relais puis petit match. Les élèves se donnent à fond !' : '⚽ Le terrain est calme pour le moment.', 3));
    const m = new THREE.Mesh(mergeGeometries(parts), new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.78 })); m.receiveShadow = true; g.add(m);
    // enseigne intérieure (au-dessus du portail) et plaques des salles : retexturées à chaque visite
    this.gateSign = new THREE.Mesh(new THREE.PlaneGeometry(8, 1.1), new THREE.MeshBasicMaterial({ toneMapped: false })); this.gateSign.position.set(0, 3.8, -23.8); g.add(this.gateSign);
    for (const id of Object.keys(this.rooms)) { const R = this.rooms[id], onN = R.z0 === 13, onW = R.x1 === -22; const pl = new THREE.Mesh(new THREE.PlaneGeometry(2.6, 0.42), new THREE.MeshBasicMaterial({ toneMapped: false })); pl.position.set(onN ? R.cx : onW ? -21.88 : 21.88, 2.6, onN ? 12.88 : R.cz); pl.rotation.y = onN ? PI : onW ? PI / 2 : -PI / 2; g.add(pl); this.plaques[id] = pl; }
  }
  furnish(R, box, solid, P) {
    const { id, type, x0, z0, x1, z1, cx, cz } = R;
    if (type === 'classe') {
      box(x0 + 1.2, 1.0, z1 - 0.16, x1 - 1.2, 2.3, z1 - 0.1, 0x1a3a2a); box(cx - 1, 0, z1 - 2.2, cx + 1, 0.76, z1 - 1.6, 0x6a4a32); solid(cx - 1, z1 - 2.2, cx + 1, z1 - 1.6, 0.8);
      for (let r = 0; r < 3; r++) for (let k = 0; k < 4; k++) {
        const tx = x0 + 1.6 + k * 2.0, tz = z0 + 1.9 + r * 2.3; box(tx - 0.55, 0.62, tz - 0.3, tx + 0.55, 0.68, tz + 0.3, 0xd8b88a); box(tx - 0.5, 0, tz - 0.25, tx + 0.5, 0.62, tz - 0.2, 0x6a4a32);
        box(tx - 0.22, 0, tz - 0.8, tx + 0.22, 0.4, tz - 0.4, 0x2f80ed); R.seats.push([tx, tz - 0.62]); if (k === 0) solid(x0 + 1.0, tz - 0.32, x1 - 1.0, tz + 0.32, 0.7);
      }
      R.seats.sort(() => 0); P(cx + 3, z0 + 1, 1.6, `Regarder dans la classe`, () => this.classInfo(id));
    } else if (type === 'biblio') {
      for (let k = 0; k < 4; k++) { box(x0 + 0.5 + k * 2.1, 0, z1 - 0.7, x0 + 2.4 + k * 2.1, 2.2, z1 - 0.3, 0x6a4a32); for (let j = 0; j < 4; j++) box(x0 + 0.6 + k * 2.1, 0.3 + j * 0.5, z1 - 0.65, x0 + 2.3 + k * 2.1, 0.6 + j * 0.5, z1 - 0.35, [0xe8112d, 0x2f80ed, 0xfcd116, 0x0b6e4f][(k + j) % 4]); }
      solid(x0 + 0.5, z1 - 0.7, x1 - 0.5, z1 - 0.3, 2.2); box(cx - 1.5, 0.72, cz - 1.5, cx + 1.5, 0.78, cz + 0.2, 0xd8c08a); solid(cx - 1.5, cz - 1.5, cx + 1.5, cz + 0.2, 0.8);
      P(cx, z0 + 1.2, 2, 'Lire un moment à la bibliothèque', () => this.read());
    } else if (type === 'direction') {
      box(cx - 1.3, 0.72, cz - 0.5, cx + 1.3, 0.78, cz + 0.5, 0x4a2a16); box(cx - 1.2, 0, cz - 0.4, cx + 1.2, 0.72, cz + 0.4, 0x4a2a16); solid(cx - 1.3, cz - 0.5, cx + 1.3, cz + 0.5, 0.8);
      box(x0 + 0.3, 0, z0 + 0.4, x0 + 0.8, 1.9, z0 + 3, 0x8a8f96); solid(x0 + 0.3, z0 + 0.4, x0 + 0.8, z0 + 3, 1.9); box(x0 + 0.3, 0, z1 - 2.6, x0 + 1.6, 0.75, z1 - 0.4, 0x6a4a32);
    } else if (type === 'profs') {
      box(cx - 2.5, 0.72, cz - 0.8, cx + 2.5, 0.78, cz + 0.8, 0xa07a4a); solid(cx - 2.5, cz - 0.8, cx + 2.5, cz + 0.8, 0.8); for (let k = 0; k < 6; k++) box(x0 + 0.3, 0, z0 + 0.4 + k * 1.05, x0 + 0.8, 1.9, z0 + 1.35 + k * 1.05, 0x5a6a7a); solid(x0 + 0.3, z0 + 0.4, x0 + 0.8, z1 - 0.3, 1.9);
      P(cx, cz + 1.6, 1.6, 'Salle des professeurs', () => this.ui.toast(`🧑🏿‍🏫 ${this.cur.teachers} enseignants (fictifs) préparent les cours, corrigent les copies et organisent les réunions avec les parents.`, 3.5));
    } else if (type === 'cantine') {
      for (let k = 0; k < 3; k++) { const tz = z0 + 1.6 + k * 2.4; box(x0 + 2, 0.7, tz, x1 - 2.2, 0.76, tz + 0.9, 0xa07a4a); solid(x0 + 2, tz, x1 - 2.2, tz + 0.9, 0.8); for (let j = 0; j < 5; j++) R.seats.push([x0 + 2.5 + j * 1.1, tz - 0.45]); }
      box(x0 + 0.3, 0, z0 + 1, x0 + 1.0, 0.95, z1 - 1.2, 0xd8dde2); solid(x0 + 0.3, z0 + 1, x0 + 1.0, z1 - 1.2, 1);
      P(x0 + 1.6, z1 - 0.6, 1.6, 'Déjeuner à la cantine (repas béninois du jour)', () => this.canteen());
    } else if (type === 'info') {
      for (let k = 0; k < 8; k++) { const tx = x0 + 1.4 + (k % 4) * 2.2, tz = z0 + 1.6 + Math.floor(k / 4) * 3; box(tx - 0.8, 0.72, tz - 0.35, tx + 0.8, 0.76, tz + 0.35, 0xd8dde2); box(tx - 0.3, 0.76, tz + 0.05, tx + 0.3, 1.15, tz + 0.1, 0x111111); solid(tx - 0.8, tz - 0.35, tx + 0.8, tz + 0.35, 0.8); }
      P(cx, z1 - 1, 1.8, 'Salle informatique', () => this.ui.toast(`💻 ${this.cur.pcs} ordinateurs dans l’établissement (fictif), cours d’informatique dès le primaire.`, 3));
    } else if (type === 'infirmerie') {
      box(x0 + 0.5, 0, z0 + 0.5, x0 + 1.4, 0.7, z0 + 2.6, 0xf6f6f6); solid(x0 + 0.5, z0 + 0.5, x0 + 1.4, z0 + 2.6, 0.7); box(x1 - 1.2, 0, z1 - 0.9, x1 - 0.4, 1.8, z1 - 0.4, 0xd8dde2); box(x1 - 1.0, 1.2, z1 - 0.95, x1 - 0.6, 1.6, z1 - 0.9, 0xe8112d);
    } else if (type === 'wc') {
      for (let k = 0; k < 4; k++) box(x0 + 0.4 + k * 2.2, 0, z0 + 0.3, x0 + 2.2 + k * 2.2, 2, z0 + 1.6, k < 2 ? 0x9ab8c4 : 0xe0b8c8); solid(x0 + 0.4, z0 + 0.3, x1 - 0.4, z0 + 1.6, 2);
      for (let k = 0; k < 3; k++) box(x0 + 1 + k * 1.4, 0.8, z1 - 0.5, x0 + 1.8 + k * 1.4, 0.9, z1 - 0.2, 0xf6f6f6);
      P(cx, cz + 1, 1.6, 'Toilettes', () => this.ui.toast('🚻 Toilettes filles et garçons, lavabos pour le lavage des mains, entretenues chaque jour.', 2.5));
    }
  }
  // ------------------------------------------------------------------ visite : habillage et PNJ
  dress(s) {
    const mk = (pl, a, b, bg, fg, lg) => { const m = this.label(a, b, 4, 4 * pl.geometry.parameters.height / pl.geometry.parameters.width, bg, fg, lg); if (pl.material.map) pl.material.map.dispose(); pl.material.map = m.material.map; pl.material.needsUpdate = true; };
    mk(this.gateSign, s.name, s.motto, s.c1, '#fff', s);
    const cls = this.classLabels(s); this.classOfRoom = cls;
    for (const [id, pl] of Object.entries(this.plaques)) mk(pl, cls[id] ? `Classe de ${cls[id]}` : this.rooms[id].name, '', s.c1, '#fff');
    this.spawnPeople(s);
  }
  classLabels(s) {
    const offered = CLASSES.map((c, i) => i).filter((i) => this.offers(s, i)), out = {}, ids = ['c1', 'c2', 'c3', 'c4', 'c5', 'c6'];
    ids.forEach((id, k) => { out[id] = CLASSES[offered[Math.round(k * (offered.length - 1) / 5)]][1]; });
    // les classes des enfants du joueur inscrits ici figurent toujours sur une porte
    const mine = Object.values(this.enr).filter((e) => e.school === s.id).map((e) => CLASSES[e.ci][1]);
    mine.forEach((c, k) => { if (!Object.values(out).includes(c)) out[ids[5 - k]] = c; });
    return out;
  }
  clearPeople() { for (const p of this.people) { p.c.group.parent && p.c.group.parent.remove(p.c.group); } this.people = []; }
  spawnPeople(s) {
    this.clearPeople(); const g = this.inGroup, R = this.rooms;
    const add = (opts, data) => { const c = createCharacter(opts); g.add(c.group); const p = { c, x: 0, z: 0, path: [], h: 0, ...data }; this.people.push(p); return p; };
    add({ female: s.dir[1], skin: SKINS[1], shirtColor: 0x2a2d33, jacket: true, collar: true, pants: 0x1a1a1a, skirt: false, glasses: true }, { role: 'dir', name: s.dir[0], title: s.dir[1] ? 'Directrice' : 'Directeur', home: [R.direction.cx, R.direction.cz + 1.1], staff: true });
    add({ female: s.sec[1], skin: SKINS[3], shirtColor: 0xf6f6f6, collar: true, pants: 0x2a2d33, skirt: false }, { role: 'sec', name: s.sec[0], title: 'Secrétariat et administration', home: [R.direction.x1 - 1.4, R.direction.z0 + 1.4], staff: true });
    const T = [['M. Didier Assogba', false], ['Mme Sabine Houénou', true], ['M. Koffi Mensah', false], ['Mme Lucie Dagba', true]];
    T.forEach(([n, f], i) => add({ female: f, skin: SKINS[(i + 2) % SKINS.length], shirtColor: [0x1f4e9c, 0x6a1a2a, 0x0b6e4f, 0x7a2a8a][i], pants: 0x2a2d33, skirt: false, collar: true }, { role: 'prof', name: n, title: 'Enseignant' + (f ? 'e' : ''), room: ['c1', 'c3', 'c4', 'c6'][i], home: [R.profs.cx - 1.5 + i, R.profs.cz - 1.4], staff: true }));
    add({ female: true, skin: SKINS[0], shirtColor: 0xf6f6f6, pants: 0xf6f6f6, skirt: false }, { role: 'inf', name: 'Mme Pauline Avocè', title: 'Infirmière scolaire', home: [R.infirmerie.cx, R.infirmerie.cz], staff: true });
    add({ female: true, skin: SKINS[2], shirtColor: 0xf6f6f6, headwrap: true, pants: 0x2a2d33, skirt: false }, { role: 'cant', name: 'Mme Victoire Adanhoumè', title: 'Responsable de la cantine', home: [R.cantine.x0 + 1.3, R.cantine.z1 - 0.38], staff: true });
    add({ female: false, skin: SKINS[1], shirtColor: 0x3a4a3a, pants: 0x2a2d33, hat: 'cap', hatColor: 0x2a2d33 }, { role: 'gard', name: 'M. Théophile Ahomadégbé', title: 'Gardien', home: [5.2, -22.6], staff: true, always: true });
    const F = ['Afi', 'Sèna', 'Mariam', 'Grâce', 'Fifamè', 'Inès', 'Prisca', 'Divine'], M = ['Koffi', 'Josué', 'Fiacre', 'Wilfried', 'Ange', 'Gédéon', 'Samuel', 'Rachad'];
    for (let i = 0; i < 18; i++) { const f = i % 2 === 0, ci = CLASSES.findIndex((c) => c[1] === Object.values(this.classOfRoom)[i % 6]); const age = ci >= 0 ? CLASSES[ci][2] : 10;
      const p = add({ female: f, skin: SKINS[(i + 1) % SKINS.length], shirtColor: s.uni, pants: f ? s.uni : 0x1f2a3a, skirt: f, shorts: !f && age < 12 }, { role: 'eleve', name: (f ? F : M)[i % 8], age, room: `c${(i % 6) + 1}`, seat: Math.floor(i / 6) * 3 + (i % 3) });
      p.c.group.scale.setScalar(0.55 + Math.min(14, age) * 0.03); }
    // enfant(s) du joueur, s'ils sont à l'école aujourd'hui
    if (this.family) for (const ch of this.family.children) { const e = this.enr[ch.id]; if (!e || e.school !== s.id) continue; const room = Object.entries(this.classOfRoom).find(([, v]) => v === CLASSES[e.ci][1]); const i = ch.idx >= 0 ? ch.idx : 0;
      const p = add({ female: ch.female, skin: SKINS[(i + 2) % SKINS.length], shirtColor: e.uniform ? s.uni : [0xfcd116, 0x2f80ed, 0xe8112d, 0x0b6e4f, 0xe46a1f, 0x7a2a8a][i % 6], pants: e.uniform ? (ch.female ? s.uni : 0x1f2a3a) : 0x1f3a5a, skirt: ch.female, shorts: !ch.female && ch.age < 12 }, { role: 'mine', name: ch.first, child: ch, age: ch.age, room: room ? room[0] : 'c1', seat: 11 });
      p.c.group.scale.setScalar(0.55 + Math.min(14, ch.age) * 0.03); }
    this._where = null; this.placePeople(true);
  }
  // emploi du temps de l'établissement (lieu des élèves selon l'heure)
  schoolTime() {
    const h = this.env.time, d = this.day(), open = this.schoolDay(d), wed = this.dow(d) === 2;
    if (!open) return { where: 'none', label: this.dow(d) >= 5 ? 'Week-end : établissement fermé aux élèves' : `${this.vacation(d) || 'Vacances'} : pas de cours` };
    if (h < 7.5 || h >= (wed ? 12.2 : 16.5)) return { where: 'none', label: 'Pas de cours en ce moment' };
    if (h < 8) return { where: 'cour', label: 'Accueil des élèves dans la cour' };
    if (h < 10) return { where: 'classe', label: 'Cours' };
    if (h < 10.25) return { where: 'cour', label: 'Récréation' };
    if (h < 12) return { where: 'classe', label: 'Cours' };
    if (wed) return { where: 'cour', label: 'Sortie (mercredi après-midi libre)' };
    if (h < 13) return { where: 'cantine', label: 'Déjeuner à la cantine' };
    if (h < 15) return { where: 'classe', label: 'Cours' };
    return { where: 'terrain', label: 'EPS et activités sportives' };
  }
  roomAt(x, z) { return Object.values(this.rooms).find((R) => x >= R.x0 && x <= R.x1 && z >= R.z0 && z <= R.z1) || null; }
  doorPts(R) { return R.z0 === 13 ? [[R.cx, 11.6], [R.cx, 13.8]] : R.x1 === -22 ? [[-21.2, R.cz], [-22.8, R.cz]] : [[21.2, R.cz], [22.8, R.cz]]; }
  via(R, tz) { // allées : on contourne les rangées de tables
    if (R.type === 'classe') return [[R.x1 - 0.55, R.z0 + 0.8], [R.x1 - 0.55, tz]];
    if (R.x1 === -22) return [[R.type === 'cantine' ? R.x1 - 1.4 : R.x1 - 0.8, tz]];
    return [];
  }
  pathTo(p, x, z) {
    const A = this.roomAt(p.x, p.z), B = this.roomAt(x, z), pts = [];
    if (A && A === B) return [...this.via(A, p.z).reverse(), ...this.via(A, z), [x, z]];
    const lane = (q) => [Math.max(-21, Math.min(21, q[0])), 11.6]; // couloir couvert, puis la cour
    if (A) { const [out, inn] = this.doorPts(A); pts.push(...this.via(A, p.z).reverse(), inn, out); if (A.z0 === 13) pts.push(lane(out)); }
    if (B) { const [out, inn] = this.doorPts(B); if (B.z0 === 13) pts.push(lane(out)); pts.push(out, inn, ...this.via(B, z)); }
    pts.push([x, z]); return pts;
  }
  spotFor(p, S) {
    const R = this.rooms, h = this.env.time, open = S.where !== 'none';
    if (p.role === 'gard') return { x: 5.2, z: -22.6 };
    if (p.role === 'dir' || p.role === 'sec' || p.role === 'inf' || p.role === 'cant') { const work = this.dow() < 5 && h >= 7.5 && h < 17.5; if (!work) return null; if (p.role === 'cant' && !(open && h >= 11 && h < 14)) return null; if (p.role === 'inf' && !open) return null; return { x: p.home[0], z: p.home[1], face: PI }; }
    if (p.role === 'prof') { if (!open && !(this.meetingOn())) return null; if (S.where === 'classe') { const r = R[p.room]; return { x: r.cx - 2.2, z: r.z1 - 2.6, face: PI }; } if (S.where === 'terrain' && p.room === 'c1') return { x: 19.7, z: -11 }; if (this.meetingOn()) return { x: p.home[0], z: p.home[1] - 0.6 }; if (S.where === 'cour' && p.room === 'c3') return { x: -3, z: 0 }; return { x: p.home[0], z: p.home[1] }; }
    if (p.role === 'mine') { const st = this.status(p.child); if (!st || !st.atSchool) return null; }
    if (!open) return null;
    if (S.where === 'classe') { const s = R[p.room].seats[p.seat % 12]; return { x: s[0], z: s[1], sit: true, face: 0 }; }
    if (S.where === 'cantine') { const i = this.people.indexOf(p), s = R.cantine.seats[i % R.cantine.seats.length]; return { x: s[0], z: s[1], sit: true, face: 0 }; }
    if (S.where === 'terrain') return { x: 10 + Math.random() * 20, z: -22 + Math.random() * 12, roam: 'terrain' };
    return { x: -19 + Math.random() * 38, z: -10 + Math.random() * 21, roam: 'cour' };
  }
  placePeople(snap) {
    const S = this.schoolTime();
    for (const p of this.people) {
      const was = p.c.group.visible && !!p.t, t = this.spotFor(p, S); p.t = t; p.c.group.visible = !!t; if (!t) continue;
      if (snap || !was) { p.x = t.x; p.z = t.z; p.path = []; if (p.seated) { p.c.stand(); p.seated = false; } } else p.path = this.pathTo(p, t.x, t.z);
    }
  }
  // ------------------------------------------------------------------ entrer / sortir
  nearestSchool(x, z) { let best = null; for (const s of this.outs) { const d = Math.hypot(x - s.doorPt.x, z - s.doorPt.z); if (!best || d < best.d) best = { d, s }; } return best; }
  enter(s) {
    const { Y, LV, O } = CAMPUS, pl = this.player, h = this.env.time;
    if (this.dow() >= 5) return this.ui.toast(`🏫 ${s.name} est fermé le week-end. Rendez-vous et inscriptions : application « Vie scolaire ».`, 3.5);
    if (h < 7 || h >= 18.5) return this.ui.toast(`🏫 ${s.name} est fermé (ouvert de 7 h à 18 h 30 en semaine).`, 3);
    this.cur = s; this.inside = true; this.inGroup.visible = true; this.world.collision.level = LV; pl.floorY = Y; pl.vy = 0;
    pl.pos.set(O.x, Y, O.z - 21.5); pl.facing = 0; pl.mesh.position.copy(pl.pos); if (this.tpc && this.tpc.snap) this.tpc.snap(pl.pos);
    this.dress(s); this.lit = true;
    this.ui.toast(`🏫 ${s.name} — ${s.motto}. ${this.schoolTime().label}. (Établissement fictif)`, 3.5);
    if (this.audio && this.audio.ctx) this.audio.door();
  }
  exit(silent) {
    const pl = this.player, s = this.cur; this.inside = false; this.inGroup.visible = false; this.world.collision.level = 0; pl.floorY = 0; pl.vy = 0; this.clearPeople();
    if (s) { pl.pos.set(s.doorPt.x, 0, s.doorPt.z); pl.mesh.position.copy(pl.pos); if (this.tpc && this.tpc.snap) this.tpc.snap(pl.pos); }
    this.lightOff(); if (!silent) this.ui.toast(`Tu sors de ${s ? s.name : 'l’école'}.`, 1.6); this.cur = null;
  }
  lightOff() { const ls = this.home && this.home.lights; if (!ls || !this._orig) return; ls.forEach((l, i) => { l.position.copy(this._orig[i].p); l.distance = this._orig[i].d; l.intensity = 0; }); this.lit = false; }
  zoneLabel() { return this.cur ? `${this.cur.short} (${this.cur.town})` : null; }
  // ------------------------------------------------------------------ interactions
  nearest(x, z) {
    if (!this.inside) { const n = this.nearestSchool(x, z); return n && n.d < 2.2 ? { d: n.d, it: { label: () => `Entrer : ${n.s.name}`, action: () => this.enter(n.s) } } : null; }
    const O = CAMPUS.O; let best = null;
    for (const p of this.points) { const d = Math.hypot(x - (O.x + p.x), z - (O.z + p.z)); if (d < p.r && (!best || d < best.d)) best = { d, it: { label: () => p.label, action: p.action } }; }
    for (const p of this.people) { if (!p.c.group.visible) continue; const d = Math.hypot(x - (O.x + p.x), z - (O.z + p.z)); if (d < (p.staff ? 1.8 : 1.3) && (!best || d < best.d + (p.staff || p.role === 'mine' ? 0.4 : 0))) best = { d, it: { label: () => (p.role === 'eleve' ? `Dire bonjour à ${p.name} (élève)` : p.role === 'mine' ? `Faire un signe à ${p.name}` : `Parler à ${p.name} (${p.title.toLowerCase()})`), action: () => this.talk(p) } }; }
    return best;
  }
  talk(p) {
    const s = this.cur;
    if (p.role === 'eleve') return this.ui.toast(`${p.name} : « ${pick([`Bonjour monsieur !`, `Bonjour ! Je suis en ${this.classOfRoom[p.room] || 'classe'}.`, `On a ${pick(['maths', 'français', 'sport', 'anglais'])} tout à l’heure !`, `Bienvenue à ${s.short} !`])} »`, 3);
    if (p.role === 'mine') { const c = p.child; if (this.family) this.family.applyEff(c, { bonheur: 2 }); return this.ui.toast(`${c.first} te fait un grand signe depuis sa place, tout fier${c.female ? 'e' : ''} 😊 (la classe sourit).`, 3); }
    const items = [];
    if (p.role === 'dir') {
      items.push({ label: '🏫 Présentez-moi l’établissement', action: () => this.ui.toast(`${p.name} : « ${this.pitch(s)} »`, 7) });
      const r = this.rdv && this.rdv.school === s.id;
      if (this.canMeet(s)) items.push({ label: '🤝 Entretien d’inscription (rendez-vous)', action: () => this.meeting(s, p.name) });
      else if (!this.met[s.id]) items.push({ label: r ? `📅 Rendez-vous prévu le jour ${this.rdv.day} à ${this.hh(this.rdv.h)}` : '📅 Prendre rendez-vous', action: () => (r ? this.ui.toast(`${p.name} : « Je vous attends le jour ${this.rdv.day} à ${this.hh(this.rdv.h)}. »`, 3) : this.book(s)) });
      if (this.met[s.id]) items.push({ label: '📝 Inscrire mon enfant', action: () => this.enrollMenu(s) });
      if (this.meetingOn() && this.myKidsAt(s).length) items.push({ label: '👨‍👩‍👧 Réunion parents-professeurs', action: () => this.attendMeeting(s) });
    } else if (p.role === 'sec') {
      items.push({ label: '💶 Frais de scolarité (virtuels)', action: () => this.ui.toast(`${p.name} : « ${this.feesText(s)} »`, 7) }, { label: '📅 Calendrier scolaire', action: () => this.ui.toast(`${p.name} : « ${this.calText()} »`, 7) });
      if (!this.met[s.id] && !(this.rdv && this.rdv.school === s.id)) items.push({ label: '📅 Rendez-vous avec la direction', action: () => this.book(s) });
      for (const ch of this.myKidsAt(s)) { const e = this.enr[ch.id]; if (!e.uniform) items.push({ label: `👕 Uniforme pour ${ch.first} (${fcfa(s.uniform)})`, action: () => this.buy(ch.id, 'uniform') }); if (!e.kit) items.push({ label: `✏️ Fournitures pour ${ch.first} (${fcfa(KIT[CLASSES[e.ci][0]])})`, action: () => this.buy(ch.id, 'kit') }); }
    } else if (p.role === 'prof') {
      const kid = this.myKidsAt(s).find((ch) => this.classOfRoom[p.room] === CLASSES[this.enr[ch.id].ci][1]);
      items.push({ label: '💬 Bonjour, comment se passe l’année ?', action: () => this.ui.toast(`${p.name} : « ${kid ? this.teacherOn(kid) : pick(['Les élèves sont motivés, nous préparons les compositions.', 'Nous lisons un roman en classe, ils adorent.', 'Le programme avance bien, merci de votre visite.'])} »`, 5) });
      if (this.meetingOn() && kid) items.push({ label: `👨‍👩‍👧 Réunion parents-professeurs (${kid.first})`, action: () => this.attendMeeting(s) });
    } else items.push({ label: '💬 Bonjour', action: () => this.ui.toast(`${p.name} : « ${p.role === 'inf' ? 'Je m’occupe des petits bobos, des visites médicales et de la prévention. Les dossiers sont confidentiels.' : p.role === 'cant' ? 'Aujourd’hui : riz au gras, poisson braisé et bouillie de maïs pour le goûter.' : 'Bienvenue ! Les visiteurs se présentent au secrétariat.'} »`, 4) });
    this.ui.openMenu(`🏫 ${p.name}`, `${p.title} • ${s.name} (personnage fictif)`, items);
  }
  pitch(s) { return `${s.name} accueille ${s.pupils} élèves (${s.cycles.map((c) => CYCLES[c].toLowerCase()).join(', ')}) avec ${s.teachers} enseignants. Bibliothèque de ${s.books} livres, ${s.pcs} ordinateurs, ${s.field}, cantine, infirmerie, parking. ${s.note} Clubs : ${s.clubs.join(', ')}.`; }
  feesText(s) { return `Inscription : ${fcfa(INSCR)}. Par trimestre : ${s.cycles.map((c) => `${CYCLES[c].toLowerCase()} ${fcfa(s.fees[c])}`).join(', ')}. Uniforme : ${fcfa(s.uniform)}. Fournitures selon le cycle. Montants en FCFA virtuels du jeu.`; }
  calText() { const d = this.day(), st = this.dayStart(d); return `Année scolaire ${this.year()} (calendrier du jeu, 80 jours) : ${TERMS.map(([a, b, l]) => `${l} J${st + a}–J${st + b}`).join(', ')} ; ${VAC.map(([a, b, l]) => `${l.toLowerCase()} J${st + a}–J${st + b}`).join(', ')}. Cours du lundi au vendredi, mercredi après-midi libre.`; }
  hh(h) { return `${Math.floor(h)} h${h % 1 ? String(Math.round((h % 1) * 60)).padStart(2, '0') : ''}`; }
  myKidsAt(s) { return this.family ? this.family.children.filter((c) => this.enr[c.id] && this.enr[c.id].school === s.id) : []; }
  read() { this.env.time = (this.env.time + 0.5) % 24; this.ui.toast('📚 Tu feuillettes un livre d’histoire du Dahomey et un recueil de contes béninois.', 3); }
  canteen() { const h = this.env.time; if (!(h >= 11.5 && h < 14) || this.dow() >= 5) return this.ui.toast('La cantine sert le déjeuner de 11 h 30 à 14 h en semaine.', 2.5); if (!this.economy.pay(1500, `Cantine — ${this.cur.short}`, this.cur.name)) return; if (this.needs) this.needs.hunger = Math.min(100, this.needs.hunger + 35); this.ui.toast('🍛 Riz au gras, poisson braisé et jus de bissap : 1 500 FCFA. Bon appétit !', 3); }
  classInfo(id) { const s = this.cur, c = this.classOfRoom[id], S = this.schoolTime(); const mine = this.myKidsAt(s).filter((ch) => CLASSES[this.enr[ch.id].ci][1] === c).map((ch) => ch.first); this.ui.toast(`📘 Classe de ${c} — ${S.where === 'classe' ? 'cours en cours, on ne dérange pas la classe' : 'salle vide pour le moment'}.${mine.length ? ` C’est la classe de ${mine.join(' et ')}.` : ''}`, 3.5); }
  teacherOn(ch) { const e = this.enr[ch.id], av = this.average(e); return av == null ? `${ch.first} s’intègre bien dans la classe. Nous aurons les premières notes bientôt.` : av >= 14 ? `${ch.first} est un${ch.female ? 'e' : ''} excellent${ch.female ? 'e' : ''} élève : ${av.toFixed(1)}/20 de moyenne. Continuez à l’encourager !` : av >= 10 ? `${ch.first} travaille correctement (${av.toFixed(1)}/20). Un peu plus de lecture le soir l’aiderait.` : `${ch.first} rencontre des difficultés (${av.toFixed(1)}/20). Aidons-${ch.female ? 'la' : 'le'} ensemble : devoirs accompagnés chaque soir.`; }
  // ------------------------------------------------------------------ rendez-vous, entretien, inscription
  book(s) {
    const d = this.day(), h = this.env.time; let day = d, hh = Math.ceil(h + 1);
    if (this.dow(d) >= 5 || hh > 16 || hh < 8) { day = d + 1; while (this.dow(day) >= 5) day++; hh = 10; }
    this.rdv = { school: s.id, day, h: hh }; this.economy.notify(`📅 Rendez-vous avec ${s.dir[0]} (${s.name}) : jour ${day} à ${this.hh(hh)}. À l’école, ou par appel depuis « Vie scolaire ».`);
    this.ui.toast(`📅 Rendez-vous confirmé : jour ${day} à ${this.hh(hh)}.`, 3); this.onSave && this.onSave();
  }
  canMeet(s) { const r = this.rdv; return !!(r && r.school === s.id && this.day() === r.day && this.env.time >= r.h - 0.5 && this.env.time < 17.5); }
  meeting(s, who) {
    this.met[s.id] = true; this.rdv = null; this.onSave && this.onSave();
    const kids = this.family ? this.family.children : [];
    this.ui.openMenu(`🤝 Entretien avec ${who || s.dir[0]}`, `${this.pitch(s)} ${kids.length ? 'Nous pouvons maintenant procéder à l’inscription.' : 'Vous pourrez inscrire votre enfant quand il ou elle vivra avec vous.'}`, [
      ...(kids.length ? [{ label: '📝 Procéder à l’inscription', action: () => this.enrollMenu(s) }] : []),
      { label: '💶 Les frais de scolarité', action: () => this.ui.toast(this.feesText(s), 7) }, { label: '🙏 Merci, au revoir', action: () => {} },
    ]);
  }
  enrollMenu(s) {
    const kids = this.family ? this.family.children : []; if (!kids.length) return this.ui.toast('Aucun enfant à inscrire pour le moment.', 2.5);
    if (!this.met[s.id]) return this.ui.toast('Un entretien avec la direction est nécessaire avant l’inscription.', 3);
    const items = [];
    for (const ch of kids) {
      const ci = this.classIdxFor(ch.age), cands = [ci, ci - 1].filter((i) => i >= 0 && this.offers(s, i));
      if (this.enr[ch.id] && this.enr[ch.id].school === s.id) { items.push({ label: `✅ ${ch.first} est déjà inscrit${ch.female ? 'e' : ''} ici (${CLASSES[this.enr[ch.id].ci][1]})`, action: () => {} }); continue; }
      if (!cands.length) { items.push({ label: `ℹ️ ${ch.first} (${ch.age} ans) : niveau non proposé ici (${s.cycles.map((c) => CYCLES[c]).join(', ')})`, action: () => {} }); continue; }
      for (const i of cands) items.push({ label: `📝 Inscrire ${ch.first} en ${CLASSES[i][1]} (${CYCLES[CLASSES[i][0]].toLowerCase()})${i === ci ? ' — classe de son âge' : ' — classe inférieure, pour consolider'}`, desc: `Inscription ${fcfa(INSCR)} + 1er trimestre ${fcfa(s.fees[CLASSES[i][0]])} (FCFA virtuels)`, action: () => this.enroll(s, ch, i) });
    }
    this.ui.openMenu(`📝 Inscription — ${s.name}`, 'Inscription fictive : la classe est choisie selon l’âge de l’enfant. Uniforme et fournitures ensuite (secrétariat ou application).', items);
  }
  enroll(s, ch, ci) {
    const cy = CLASSES[ci][0], cost = INSCR + s.fees[cy];
    if (!this.economy.pay(cost, `Inscription de ${ch.first} — ${s.name} (frais virtuels)`, s.name)) return this.ui.toast('Solde personnel insuffisant.', 2);
    const prev = this.enr[ch.id];
    this.enr[ch.id] = { school: s.id, ci, since: this.day(), uniform: false, kit: false, club: null, grades: {}, bulletins: [], absences: [], paidTerm: this.termKey(), meetings: [], escort: null, year: this.year() };
    if (prev) this.economy.notify(`🏫 ${ch.first} quitte ${SBY[prev.school].short} pour ${s.short}.`);
    if (this.family) { this.family.log(`🎒 ${ch.first} est inscrit${ch.female ? 'e' : ''} à ${s.name} en ${CLASSES[ci][1]}.`); this.family.applyEff(ch, { etudes: 3, bonheur: 3 }); }
    this.economy.notify(`🎒 ${ch.first} est inscrit${ch.female ? 'e' : ''} à ${s.name} en ${CLASSES[ci][1]}. Pensez à l’uniforme et aux fournitures. Suivi : application « Vie scolaire ».`);
    this.ui.toast(`🎒 Inscription validée : ${ch.first}, ${CLASSES[ci][1]}, ${s.short}.`, 3.5); this.onSave && this.onSave();
  }
  unenroll(id) { const e = this.enr[id], ch = this.family && this.family.children.find((c) => c.id === id); if (!e) return; delete this.enr[id]; if (ch) this.family.log(`${ch.first} n’est plus inscrit${ch.female ? 'e' : ''} à ${SBY[e.school].name}.`); this.onSave && this.onSave(); }
  buy(id, what) {
    const e = this.enr[id], s = e && SBY[e.school], ch = this.family.children.find((c) => c.id === id); if (!e) return;
    const cost = what === 'uniform' ? s.uniform : KIT[CLASSES[e.ci][0]], label = what === 'uniform' ? `Uniforme ${s.short}` : `Fournitures scolaires (${CLASSES[e.ci][1]})`;
    if (e[what]) return this.ui.toast('Déjà acheté.', 2);
    if (!this.economy.pay(cost, `${label} pour ${ch.first}`, s.name)) return this.ui.toast('Solde personnel insuffisant.', 2);
    e[what] = true; this.family.applyEff(ch, { bonheur: 2, etudes: what === 'kit' ? 2 : 0 }); this.ui.toast(`${what === 'uniform' ? '👕' : '✏️'} ${label} pour ${ch.first} : ${fcfa(cost)}.`, 3); this.onSave && this.onSave();
  }
  termKey(d = this.day()) { const t = this.term(d); return t ? `${this.year(d)}-${t.i}` : null; }
  // réunions parents-professeurs : 10e jour de chaque trimestre, 16 h 30 – 18 h 30
  meetingDay(d = this.day()) { const t = this.term(d); return t ? this.dayStart(d) + t.a + 10 : null; }
  meetingOn() { const d = this.day(), h = this.env.time; return this.meetingDay(d) === d && h >= 16.5 && h < 18.5; }
  attendMeeting(s) {
    const kids = this.myKidsAt(s); if (!kids.length) return; const k = this.termKey();
    for (const ch of kids) { const e = this.enr[ch.id]; if (e.meetings.includes(k)) continue; e.meetings.push(k); this.family.applyEff(ch, { etudes: 5, confiance: 3 }); this.family.log(`👨‍👩‍👧 Réunion parents-professeurs pour ${ch.first} (${s.short}).`); }
    this.ui.toast(`👨‍👩‍👧 Réunion parents-professeurs : ${kids.map((ch) => this.teacherOn(ch)).join(' ')}`, 8); if (this.events) this.events.repAdd('fiabilite', 0.5); this.onSave && this.onSave();
  }
  // ------------------------------------------------------------------ suivi quotidien (notes, absences, bulletins, frais)
  average(e, tk = this.termKey()) { const g = e.grades[tk]; if (!g) return null; const all = Object.values(g).flat(); return all.length ? all.reduce((a, b) => a + b, 0) / all.length : null; }
  daily(d) {
    if (!this.family) return;
    const prev = d - 1;
    for (const ch of this.family.children) {
      const e = this.enr[ch.id]; if (!e) continue; const s = SBY[e.school], cy = CLASSES[e.ci][0];
      // rentrée : passage en classe supérieure
      if (this.yt(d) === 0 && e.year !== this.year(d)) { const av = e.lastYearAvg; e.year = this.year(d); e.kit = false; if (av == null || av >= 10) { const n = e.ci + 1; if (n < CLASSES.length && this.offers(s, n)) e.ci = n; else if (n < CLASSES.length) this.economy.notify(`🎓 ${ch.first} a terminé le cycle proposé par ${s.short} : inscris-${ch.female ? 'la' : 'le'} dans un établissement qui propose la suite.`); } this.economy.notify(`🎒 Rentrée scolaire : ${ch.first} entre en ${CLASSES[e.ci][1]} (${s.short}). Pense aux nouvelles fournitures.`); }
      // frais du trimestre (facturés le premier jour)
      const tk = this.termKey(d); if (tk && e.paidTerm !== tk) { if (this.economy.pay(s.fees[cy], `Frais de scolarité ${this.term(d).label} — ${ch.first} (${s.short})`, s.name)) e.paidTerm = tk; else this.economy.notify(`💶 Frais du trimestre impayés pour ${ch.first} (${s.short}) : solde insuffisant.`); }
      // la journée d'hier : présence, note
      if (this.schoolDay(prev) && prev >= e.since) {
        if (e.absentDay === prev) e.absences.unshift({ d: prev, why: e.absentWhy || 'maladie' });
        else { const subj = SUBJ[cy], sj = subj[prev % subj.length], k = this.termKey(prev); const base = 6 + ch.etudes / 100 * 11 + (e.kit ? 0.8 : -1) + (e.uniform ? 0.2 : 0) - (ch.sante < 40 ? 1.5 : 0), n = Math.max(0, Math.min(20, Math.round((base + (Math.random() * 6 - 3)) * 2) / 2)); ((e.grades[k] ||= {})[sj] ||= []).push(n); if (n >= 14) this.family.applyEff(ch, { bonheur: 1 }); }
        this.family.applyEff(ch, { etudes: 0.6 });
      }
      // bulletin à la fin du trimestre
      const tp = this.term(prev); if (tp && this.yt(prev) === tp.b && prev >= e.since) {
        const k = this.termKey(prev), av = this.average(e, k), g = e.grades[k] || {};
        const b = { k, label: `${tp.label} ${this.year(prev)}`, avg: av, subj: Object.fromEntries(Object.entries(g).map(([sj, v]) => [sj, v.reduce((a, c) => a + c, 0) / v.length])), abs: e.absences.filter((a) => this.termKey(a.d) === k).length, app: av == null ? 'Arrivée récente : pas assez de notes.' : av >= 16 ? 'Félicitations du conseil de classe.' : av >= 14 ? 'Encouragements : très bon trimestre.' : av >= 12 ? 'Bon travail, continuez ainsi.' : av >= 10 ? 'Résultats corrects, des progrès possibles.' : 'Trimestre difficile : un accompagnement est conseillé.' };
        e.bulletins.unshift(b); if (tp.i === 2) e.lastYearAvg = av; this.family.applyEff(ch, { bonheur: av != null && av >= 12 ? 4 : 0 });
        this.economy.notify(`📄 Bulletin du ${b.label} pour ${ch.first} : ${av == null ? '—' : `${av.toFixed(2)}/20`} — ${b.app} (application « Vie scolaire »)`); this.family.log(`📄 Bulletin de ${ch.first} (${b.label}) : ${av == null ? '—' : av.toFixed(2) + '/20'}.`);
      }
      // aujourd'hui : absence éventuelle (malade, ou impossible de s'y rendre)
      e.absentDay = null; e.escortDay = null;
      if (this.schoolDay(d) && d >= e.since) { if (ch.sante < 35) { e.absentDay = d; e.absentWhy = 'malade (reste se reposer à la maison)'; this.economy.notify(`🤒 ${ch.first} est malade et reste à la maison aujourd’hui. L’école est prévenue.`); } else if (Math.random() < 0.02) { e.absentDay = d; e.absentWhy = 'rendez-vous médical'; } }
      // rappel de réunion
      if (this.meetingDay(d) === d) this.economy.notify(`👨‍👩‍👧 Aujourd’hui de 16 h 30 à 18 h 30 : réunion parents-professeurs à ${s.short} pour ${ch.first}.`);
    }
    this.onSave && this.onSave();
  }
  // statut d'un enfant (utilisé par la vie familiale)
  status(ch) {
    const e = this.enr[ch.id], d = this.day(), h = this.env.time; if (!e) return null; const s = SBY[e.school], wed = this.dow(d) === 2;
    if (!this.schoolDay(d)) return { enrolled: true, school: s, cls: CLASSES[e.ci][1], off: this.dow(d) >= 5 ? 'week-end' : this.vacation(d) };
    if (e.absentDay === d) return { enrolled: true, school: s, cls: CLASSES[e.ci][1], absent: e.absentWhy };
    const clubOn = wed && e.club && h >= 14 && h < 16;
    const atSchool = (h >= 7.6 && h < (wed ? 12.2 : 16.5)) || clubOn;
    return { enrolled: true, school: s, cls: CLASSES[e.ci][1], atSchool, label: clubOn ? `au club ${e.club} (${s.short})` : `à l’école : ${s.short}, ${CLASSES[e.ci][1]}` };
  }
  escort(ch) { const e = this.enr[ch.id]; if (!e) return; e.escortDay = this.day(); e.escorts = (e.escorts || 0) + 1; }
  // ------------------------------------------------------------------ boucle
  update(dt) {
    const d = this.day(); if (this.lastDay === null) this.lastDay = d; if (d > this.lastDay) { for (let k = this.lastDay + 1; k <= d; k++) this.daily(k); this.lastDay = d; }
    // rendez-vous manqué
    if (this.rdv && (d > this.rdv.day || (d === this.rdv.day && this.env.time >= 17.5))) { const s = SBY[this.rdv.school]; this.rdv = null; this.economy.notify(`📅 Rendez-vous manqué avec la direction de ${s.short}. Tu peux en reprendre un dans « Vie scolaire ».`); this.onSave && this.onSave(); }
    if (this.rdv && !this._rdvRing && this.canMeet(SBY[this.rdv.school]) && !this.inside) { this._rdvRing = true; this.economy.notify(`📅 C’est l’heure de ton rendez-vous avec ${SBY[this.rdv.school].dir[0]} : rends-toi à l’école ou rejoins l’entretien par appel dans « Vie scolaire ».`); }
    // enseignes visibles seulement à proximité (performances)
    const P = this.player.pos; for (const s of this.outs) s.ext.visible = Math.hypot(P.x - s.cx, P.z - s.cz) < 450;
    if (!this.inside) return;
    if (Math.abs((P.y || CAMPUS.Y) - CAMPUS.Y) > 6 || Math.hypot(P.x - CAMPUS.O.x, P.z - CAMPUS.O.z) > 50) { this.inside = false; this.inGroup.visible = false; this.world.collision.level = 0; this.player.floorY = 0; this.clearPeople(); this.lightOff(); this.cur = null; return; }
    const ls = this.home && this.home.lights; if (ls) { if (!this._orig) this._orig = ls.map((l) => ({ p: l.position.clone(), d: l.distance })); ls.forEach((l, i) => { l.position.set(P.x - 6 + i * 6, CAMPUS.Y + 3, P.z + (i === 1 ? 4 : -2)); l.distance = 18; l.decay = 1.1; l.intensity = 4.5 * Math.min(1, 0.4 + this.env.lightsOn); }); }
    const S = this.schoolTime(), key = `${S.where}|${this.meetingOn()}|${this.dow() < 5 && this.env.time >= 7.5 && this.env.time < 17.5}`; if (key !== this._where) { this._where = key; this.placePeople(false); }
    for (const p of this.people) {
      if (!p.t) continue; if (p.path.length) { const [px, pz] = p.path[0]; if (Math.hypot(px - p.x, pz - p.z) < 0.25) p.path.shift(); }
      const tg = p.path.length ? p.path[0] : [p.t.x, p.t.z], dx = tg[0] - p.x, dz = tg[1] - p.z, dd = Math.hypot(dx, dz); let sp = 0;
      if (dd > 0.2) { const v = p.t.roam ? 2.2 : 1.3, st = Math.min(dd, v * dt); p.x += dx / dd * st; p.z += dz / dd * st; p.h = Math.atan2(dx, dz); sp = v; if (p.seated) { p.c.stand(); p.seated = false; } }
      else if (p.t.roam) { p.wait = (p.wait || 0) - dt; if (p.wait < 0) { p.wait = 2 + Math.random() * 4; const t = this.spotFor(p, S); if (t) { p.t = t; p.path = []; } } }
      else { if (p.t.face !== undefined) p.h = p.t.face; if (p.t.sit && !p.seated) { p.c.sit(false); p.seated = true; } }
      p.c.group.position.set(p.x, p.seated ? -0.12 * p.c.group.scale.y : 0, p.z); p.c.group.rotation.y = p.h || 0; if (!p.seated) p.c.animate(dt, sp);
    }
  }
  // ------------------------------------------------------------------ application « Vie scolaire »
  edt(cy) { // emploi du temps hebdomadaire (fictif)
    const sj = SUBJ[cy]; return DAYS.slice(0, 5).map((dn, i) => [dn, i === 2 ? [`8 h – 10 h : ${sj[(i * 2) % sj.length]}`, `10 h 15 – 12 h : ${sj[(i * 2 + 1) % sj.length]}`, 'Après-midi libre (clubs 14 h – 16 h)'] : [`8 h – 10 h : ${sj[(i * 2) % sj.length]}`, `10 h 15 – 12 h : ${sj[(i * 2 + 1) % sj.length]}`, `13 h – 15 h : ${sj[(i * 2 + 2) % sj.length]}`, `15 h – 16 h 30 : ${cy === 'mat' ? 'Jeux et motricité' : 'EPS / activités'}`]]);
  }
  renderApp(b) {
    const tabs = [['enfant', 'Mon enfant'], ['edt', 'Emploi du temps'], ['notes', 'Résultats'], ['vie', 'Réunions & activités'], ['cal', 'Calendrier'], ['etab', 'Établissements']], v = this.view;
    const kids = this.family ? this.family.children : [], sel = kids.find((c) => c.id === this.kidSel) || kids[0]; if (sel) this.kidSel = sel.id; const e = sel && this.enr[sel.id], s = e && SBY[e.school];
    let h = `<h4>🎒 Vie scolaire</h4><div class="ph-chips">${tabs.map(([k, l]) => `<button data-sc="tab:${k}" class="${k === v ? 'on' : ''}">${l}</button>`).join('')}</div>`;
    if (kids.length > 1 && v !== 'etab' && v !== 'cal') h += `<div class="ph-chips">${kids.map((c) => `<button data-sc="kid:${c.id}" class="${c === sel ? 'on' : ''}">${esc(c.first)}</button>`).join('')}</div>`;
    const noKid = '<p class="ph-note">Aucun enfant à la maison pour le moment (application « Vie familiale »). Tu peux déjà consulter et comparer les établissements.</p>';
    const noEnr = sel ? `<p class="ph-note">${esc(sel.first)} n’est pas encore inscrit${sel.female ? 'e' : ''} dans une école. Onglet « Établissements » : comparer, prendre rendez-vous, s’inscrire.</p>` : noKid;
    if (v === 'enfant') {
      if (!sel || !e) h += noEnr;
      else { const st = this.status(sel), av = this.average(e); h += `<div class="ph-row"><span><img src="${this.logoURL(s)}" style="width:42px;height:42px;vertical-align:middle;margin-right:8px"><b>${esc(sel.first)}, ${sel.age} ans</b><small>${esc(s.name)} • classe de ${CLASSES[e.ci][1]} (${CYCLES[CLASSES[e.ci][0]].toLowerCase()})</small></span></div>
        <div class="ph-list"><div class="ph-row"><span><b>En ce moment</b><small>${esc(st.absent ? `absent${sel.female ? 'e' : ''} : ${st.absent}` : st.off ? `pas de cours (${st.off})` : st.atSchool ? st.label : 'pas en classe')}</small></span></div>
        <div class="ph-row"><span><b>Moyenne du trimestre</b></span><em>${av == null ? '—' : av.toFixed(2) + '/20'}</em></div><div class="ph-row"><span><b>Absences</b></span><em>${e.absences.length}</em></div>
        <div class="ph-row"><span><b>👕 Uniforme</b></span>${e.uniform ? '<em>✅</em>' : `<button class="ph-mini" data-sc="buy:${sel.id}|uniform">Acheter • ${fcfa(s.uniform)}</button>`}</div>
        <div class="ph-row"><span><b>✏️ Fournitures (${CLASSES[e.ci][1]})</b></span>${e.kit ? '<em>✅</em>' : `<button class="ph-mini" data-sc="buy:${sel.id}|kit">Acheter • ${fcfa(KIT[CLASSES[e.ci][0]])}</button>`}</div>
        <div class="ph-row"><span><b>Frais de scolarité</b><small>${fcfa(s.fees[CLASSES[e.ci][0]])} par trimestre (FCFA virtuels) • ${e.paidTerm === this.termKey() ? 'trimestre en cours réglé' : this.termKey() ? 'trimestre en cours non réglé' : 'vacances'}</small></span>${this.termKey() && e.paidTerm !== this.termKey() ? `<button class="ph-mini" data-sc="pay:${sel.id}">Régler</button>` : ''}</div></div>
        <button class="ph-mini" data-sc="go:${s.id}">🚘 Aller à l’école (chauffeur)</button> <button class="ph-mini" data-sc="unenr:${sel.id}">Changer d’école / désinscrire</button>`; }
    } else if (v === 'edt') {
      if (!e) h += noEnr; else h += `<p class="ph-note">${esc(sel.first)} — ${CLASSES[e.ci][1]}, ${esc(s.short)}. Accueil 7 h 30, récréation 10 h – 10 h 15, cantine 12 h – 13 h.${e.club ? ` Club : ${esc(e.club)} (mercredi 14 h – 16 h).` : ''}</p>${this.edt(CLASSES[e.ci][0]).map(([dn, sl]) => `<h5>${dn}</h5>${sl.map((x) => `<p class="ph-note">${x}</p>`).join('')}`).join('')}`;
    } else if (v === 'notes') {
      if (!e) h += noEnr; else { const g = e.grades[this.termKey()] || {}; h += `<h5>Trimestre en cours</h5>${Object.keys(g).length ? Object.entries(g).map(([sj, arr]) => `<div class="ph-row"><span><b>${sj}</b><small>${arr.slice(-6).map((n) => `${n}`).join(' • ')}</small></span><em>${(arr.reduce((a, c) => a + c, 0) / arr.length).toFixed(1)}</em></div>`).join('') : '<p class="ph-note">Pas encore de notes ce trimestre.</p>'}
        <h5>Bulletins</h5>${e.bulletins.length ? e.bulletins.slice(0, 6).map((bb) => `<div class="ph-row"><span><b>📄 ${bb.label}</b><small>${bb.app} • absences : ${bb.abs}</small><small>${Object.entries(bb.subj).map(([sj, a]) => `${sj} ${a.toFixed(1)}`).join(' • ')}</small></span><em>${bb.avg == null ? '—' : bb.avg.toFixed(2)}</em></div>`).join('') : '<p class="ph-note">Le premier bulletin arrivera à la fin du trimestre.</p>'}
        <h5>Absences</h5>${e.absences.slice(0, 8).map((a) => `<p class="ph-note">Jour ${a.d} : ${esc(a.why)}</p>`).join('') || '<p class="ph-note">Aucune absence.</p>'}<p class="ph-note">Notes et bulletins fictifs, calculés selon les études de l’enfant (devoirs, réunions, fournitures, santé).</p>`; }
    } else if (v === 'vie') {
      if (!e) h += noEnr; else { const md = this.meetingDay(); h += `<h5>Réunions avec les enseignants</h5><p class="ph-note">Réunion parents-professeurs : ${md ? `jour ${md}, 16 h 30 – 18 h 30, à ${esc(s.short)} (parler à la direction ou à l’enseignant de la classe)` : 'reprise au prochain trimestre'}. Participations : ${e.meetings.length}.</p>
        <h5>Activités scolaires (clubs du mercredi)</h5>${s.clubs.map((c) => `<div class="ph-row"><span><b>${esc(c)}</b><small>${e.club === c ? 'inscrit·e' : 'mercredi 14 h – 16 h'}</small></span>${e.club === c ? `<button class="ph-mini" data-sc="club:${sel.id}|">Quitter</button>` : `<button class="ph-mini" data-sc="club:${sel.id}|${esc(c)}">Inscrire</button>`}</div>`).join('')}
        <h5>Accompagnement</h5><p class="ph-note">Accompagner ${esc(sel.first)} à l’école : le matin entre 7 h et 8 h, à la villa (parler à ${esc(sel.first)}). Déjà fait : ${e.escorts || 0} fois.</p>`; }
    } else if (v === 'cal') {
      const d = this.day(), t = this.term(d); h += `<p class="ph-note">Aujourd’hui : jour ${d} (${DAYS[this.dow(d)]}) — ${t ? t.label : this.vacation(d) || ''}${this.schoolDay(d) ? ', jour de classe' : ', pas de cours'}.</p><p class="ph-note">${this.calText()}</p><p class="ph-note">Bulletins : à la fin de chaque trimestre. Réunions parents-professeurs : 10e jour de chaque trimestre.</p>`;
    } else {
      const S = this.sel && SBY[this.sel];
      if (S) {
        const r = this.rdv && this.rdv.school === S.id;
        h += `<div class="ph-row"><span><img src="${this.logoURL(S)}" style="width:48px;height:48px;vertical-align:middle;margin-right:8px"><b>${esc(S.name)}</b><small>${esc(S.town)} • « ${esc(S.motto)} » • établissement fictif</small></span></div><p class="ph-note">${esc(this.pitch(S))}</p><p class="ph-note">Niveaux : ${S.cycles.map((c) => `${CYCLES[c]} (${CLASSES.filter((q) => q[0] === c).map((q) => q[1]).join(', ')})`).join(' ; ')}.</p><p class="ph-note">${esc(this.feesText(S))}</p>
          <p class="ph-note">Direction : ${esc(S.dir[0])} • Secrétariat : ${esc(S.sec[0])} (personnages fictifs).</p>
          ${this.met[S.id] ? `<button class="ph-go" data-sc="insc:${S.id}">📝 Inscrire mon enfant</button>` : r ? `<p class="ph-note">📅 Rendez-vous : jour ${this.rdv.day} à ${this.hh(this.rdv.h)}.</p>${this.canMeet(S) ? `<button class="ph-go" data-sc="call:${S.id}">📞 Rejoindre l’entretien par appel</button>` : ''}` : `<button class="ph-go" data-sc="rdv:${S.id}">📅 Prendre rendez-vous avec la direction</button>`}
          <button class="ph-mini" data-sc="go:${S.id}">🚘 M’y conduire (chauffeur)</button> <button class="ph-mini" data-sc="sel:">← Retour à la liste</button>`;
      } else {
        h += `<p class="ph-note">Réseau de 10 établissements fictifs. Toutes disposent de : salles de classe, bureaux administratifs, salle des professeurs, bibliothèque, salle informatique, cantine, toilettes, cour, terrain de sport, infirmerie, parking, portail et clôture.</p>
          <div class="ph-list">${SCHOOLS.map((S) => `<div class="ph-row"><span><img src="${this.logoURL(S)}" style="width:34px;height:34px;vertical-align:middle;margin-right:6px"><b>${esc(S.name)}</b><small>${esc(S.town)} • ${S.cycles.map((c) => CYCLES[c]).join(', ')} • ${S.pupils} élèves • ${S.pcs} PC • ${S.books} livres • ${esc(S.field)} • dès ${fcfa(Math.min(...Object.values(S.fees)))}/trim.</small></span><button class="ph-mini" data-sc="sel:${S.id}">Voir</button></div>`).join('')}</div>
          <h5>Comparer</h5><div style="overflow-x:auto"><table style="font-size:11px;border-collapse:collapse;width:100%"><tr><th style="text-align:left">École</th><th>Élèves/ens.</th><th>PC</th><th>Livres</th><th>Frais min.</th></tr>${SCHOOLS.map((S) => `<tr><td>${esc(S.short)}</td><td style="text-align:center">${Math.round(S.pupils / S.teachers)}</td><td style="text-align:center">${S.pcs}</td><td style="text-align:center">${S.books}</td><td style="text-align:center">${fcfa(Math.min(...Object.values(S.fees)))}</td></tr>`).join('')}</table></div>`;
      }
    }
    b.innerHTML = h;
  }
  onPhone(v) {
    const [a, arg = ''] = v.split(':');
    if (a === 'tab') this.view = arg;
    else if (a === 'kid') this.kidSel = arg;
    else if (a === 'sel') this.sel = arg || null;
    else if (a === 'rdv') this.book(SBY[arg]);
    else if (a === 'call') { this.economy.togglePhone(false); return this.meeting(SBY[arg], `${SBY[arg].dir[0]} (appel)`); }
    else if (a === 'insc') { this.economy.togglePhone(false); return this.enrollMenu(SBY[arg]); }
    else if (a === 'buy') { const [id, w] = arg.split('|'); this.buy(id, w); }
    else if (a === 'pay') { const e = this.enr[arg], s = e && SBY[e.school], ch = this.family.children.find((c) => c.id === arg); if (e && this.economy.pay(s.fees[CLASSES[e.ci][0]], `Frais de scolarité — ${ch.first} (${s.short})`, s.name)) { e.paidTerm = this.termKey(); this.onSave && this.onSave(); } }
    else if (a === 'club') { const [id, c] = arg.split('|'); const e = this.enr[id]; if (e) { e.club = c || null; this.onSave && this.onSave(); } }
    else if (a === 'unenr') { const ch = this.family.children.find((c) => c.id === arg); this.economy.togglePhone(false); return this.ui.openMenu(`Désinscrire ${ch.first} ?`, 'Tu pourras l’inscrire ailleurs (rendez-vous avec la direction de la nouvelle école).', [{ label: 'Oui, désinscrire', action: () => this.unenroll(arg) }, { label: 'Non', action: () => {} }]); }
    else if (a === 'go' && this.driver) { const s = SBY[arg]; this.economy.togglePhone(false); return this.driver.toDest({ id: `ecole_${s.id}`, label: s.name, x: s.doorPt.x, z: s.doorPt.z }); }
    this.economy.renderPhone();
  }
  serialize() { return { enr: this.enr, rdv: this.rdv, met: this.met, lastDay: this.lastDay }; }
  restore(s) { if (!s) return; this.enr = s.enr || {}; this.rdv = s.rdv || null; this.met = s.met || {}; this.lastDay = s.lastDay ?? null; }
}
