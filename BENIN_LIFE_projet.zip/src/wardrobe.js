// Mission 016, phase 6 — garde-robe du joueur : 200 vêtements, essayage en direct sur le personnage (vue miroir),
// combinaison haut / bas / veste / tenue complète / chaussures / accessoires, ensembles favoris, sauvegarde.
import { CLOTHES, CLOTH_CATS, CLOTH_BY_ID, PAGNE_CSS, composeOutfit } from './clothes.js';
import * as THREE from 'three';
import { OUTFITS } from './home.js';

const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const css = (h) => `#${(h ?? 0x888888).toString(16).padStart(6, '0')}`;
const EMPTY = () => ({ haut: null, bas: null, veste: null, tenue: null, pieds: null, acc: [] });
const SLOT_LABEL = { haut: 'Haut', bas: 'Bas', veste: 'Veste', tenue: 'Tenue complète', pieds: 'Chaussures', acc: 'Accessoires' };
const MAX_ACC = 3, MAX_FAVS = 12;

export class Wardrobe {
  constructor(ctx) {
    Object.assign(this, ctx); // ui, audio, player, tpc, rebuild(), legacy(id), legacyId(), onSave
    this.cur = EMPTY(); this.favs = []; this.owned = new Set(); this.buying = null; this.open = false; this.cat = 'chemises'; this.sel = null; this.prev = null;
    this.dom = document.querySelector('#wardrobe');
    this.dom.addEventListener('click', (e) => this.onClick(e));
  }
  active() { const c = this.cur; return !!(c.haut || c.bas || c.veste || c.tenue || c.pieds || c.acc.length); }
  opts(female) { return composeOutfit(this.cur, female); }
  worn(id) { const c = this.cur; return c.haut === id || c.bas === id || c.veste === id || c.tenue === id || c.pieds === id || c.acc.includes(id); }
  // ---- ouverture : devant le miroir de la chambre ou devant l'armoire ----
  show(atMirror) {
    this.open = true; this.prev = JSON.parse(JSON.stringify(this.cur)); this.prevLegacy = this.legacyId && this.legacyId();
    const pl = this.player;
    if (atMirror) { pl.pos.set(-48.6, 0, 132.1); pl.mesh.position.copy(pl.pos); pl.facing = Math.PI / 2; pl.mesh.rotation.y = Math.PI / 2; }
    this.dom.classList.add('show'); this.render();
    if (this.audio && this.audio.ctx) this.audio.tone(520, 0.08, 0.03, 'triangle');
  }
  close(keep) {
    if (!this.open) return;
    if (!keep) { this.cur = this.prev || this.cur; if (!this.active() && this.prevLegacy && this.legacy) this.legacy(this.prevLegacy, true); else this.rebuild(); }
    else { this.ui.toast('Tenue enregistrée ✔', 1.8); this.onSave && this.onSave(); }
    this.open = false; this.dom.classList.remove('show');
  }
  // vue « miroir » : la caméra se place face au personnage, légèrement décalée pour qu'il reste visible à droite du panneau
  applyMirror(cam, touch) {
    const p = this.player.pos, f = this.player.facing, d = 2.3;
    const v = this._v || (this._v = { dir: new THREE.Vector3(), right: new THREE.Vector3(), up: new THREE.Vector3(0, 1, 0) });
    cam.position.set(p.x + Math.sin(f) * d, p.y + 1.2, p.z + Math.cos(f) * d);
    v.dir.set(-Math.sin(f), 0, -Math.cos(f)); v.right.copy(v.dir).cross(v.up).normalize();
    const k = touch ? 1.0 : 0.6; cam.lookAt(p.x - v.right.x * k, p.y + 0.95, p.z - v.right.z * k);
  }
  // ---- essayage ----
  wear(id) {
    const it = CLOTH_BY_ID[id]; if (!it) return;
    if (it.price && !this.owned.has(id)) { this.buying = id; this.sel = id; return this.render(); } // pièce de luxe : achat d'abord
    const c = this.cur, s = it.slot;
    if (s === 'acc') { if (c.acc.includes(id)) c.acc = c.acc.filter((q) => q !== id); else { if (c.acc.length >= MAX_ACC) return this.ui.toast(`${MAX_ACC} accessoires au maximum : retires-en un.`, 2); c.acc.push(id); } }
    else if (c[s] === id) c[s] = null;
    else { c[s] = id; if (s === 'haut' || s === 'bas' || s === 'veste') c.tenue = null; }
    this.sel = id; this.rebuild(); this.render();
  }
  favSave() {
    if (!this.active()) return this.ui.toast('Porte au moins un vêtement avant d’enregistrer un ensemble.', 2);
    if (this.favs.length >= MAX_FAVS) return this.ui.toast(`${MAX_FAVS} ensembles favoris au maximum : supprimes-en un.`, 2.2);
    const sig = JSON.stringify(this.cur); if (this.favs.some((f) => JSON.stringify(f.cur) === sig)) return this.ui.toast('Cet ensemble est déjà dans tes favoris.', 2);
    let n = this.favs.length + 1; while (this.favs.some((f) => f.name === `Ensemble n°${n}`)) n++;
    this.favs.push({ name: `Ensemble n°${n}`, cur: JSON.parse(sig) }); this.ui.toast(`⭐ Ensemble n°${n} enregistré dans tes favoris`, 2); this.onSave && this.onSave();
  }
  pieceName(id) { return id && CLOTH_BY_ID[id] ? CLOTH_BY_ID[id].name : null; }
  swatch(it) { return it.pat !== null && it.pat !== undefined ? `background: repeating-linear-gradient(45deg, ${PAGNE_CSS[it.pat % PAGNE_CSS.length]} 0 6px, #1a1a1a 6px 9px, #f2f2f2 9px 12px)` : `background:${css(it.sw)}`; }
  icon(it) { return { chemises: '👔', pantalons: '👖', jeans: '👖', tshirts: '👕', vestes: '🧥', pro: '🤵🏿', trad: '🥻', deco: '🩳', sport: '⚽', chaussures: '👟', acc: '🧢', spec: '✨' }[it.cat]; }
  render() {
    if (!this.open) return;
    const c = this.cur, list = this.cat === 'favs' || this.cat === 'base' ? [] : CLOTHES.filter((q) => q.cat === this.cat);
    const wornList = ['tenue', 'haut', 'bas', 'veste', 'pieds'].filter((s) => c[s]).map((s) => `<span><b>${SLOT_LABEL[s]}</b> ${esc(this.pieceName(c[s]))}</span>`).concat(c.acc.map((a) => `<span><b>Accessoire</b> ${esc(this.pieceName(a))}</span>`));
    let grid;
    if (this.cat === 'favs') grid = this.favs.length ? this.favs.map((f, i) => `<div class="wd-fav"><b>⭐ ${esc(f.name)}</b><small>${[f.cur.tenue, f.cur.haut, f.cur.bas, f.cur.veste, f.cur.pieds, ...f.cur.acc].filter(Boolean).map((id) => esc(this.pieceName(id))).join(' • ')}</small><span><button data-wd="favon:${i}">Porter</button><button class="alt" data-wd="favdel:${i}">Supprimer</button></span></div>`).join('') : '<p class="wd-note">Aucun ensemble favori. Compose une tenue puis « ⭐ Enregistrer en favori ».</p>';
    else if (this.cat === 'base') { const kind = this.player.kind === 'female' ? 'female' : 'male'; grid = OUTFITS[kind].map((o) => `<button class="wd-card" data-wd="legacy:${o.id}"><i class="wd-sw" style="background:#888"></i><b>${esc(o.name)}</b><small>${o.cat}</small></button>`).join(''); }
    else grid = list.map((it) => { const lock = it.price && !this.owned.has(it.id); return `<button class="wd-card${this.worn(it.id) ? ' on' : ''}${lock ? ' lock' : ''}" data-wd="wear:${it.id}"><i class="wd-sw" style="${this.swatch(it)}">${lock ? '🔒' : this.icon(it)}</i><b>${esc(it.name)}</b>${this.worn(it.id) ? '<small>porté ✔</small>' : lock ? `<small class="wd-price">${it.price.toLocaleString('fr-FR')} FCFA</small>` : it.price ? '<small>acheté</small>' : ''}</button>`; }).join('');
    this.dom.innerHTML = `<div class="wd-box"><div class="wd-head"><h2>👗 Garde-robe <small>${CLOTHES.length} vêtements et accessoires • vue miroir</small></h2><button data-wd="cancel">Annuler</button><button class="ok" data-wd="ok">✔ Valider la tenue</button></div>
      <div class="wd-tabs">${CLOTH_CATS.map(([k, l]) => `<button data-wd="cat:${k}" class="${k === this.cat ? 'on' : ''}">${l} (${CLOTHES.filter((q) => q.cat === k).length})</button>`).join('')}<button data-wd="cat:favs" class="${this.cat === 'favs' ? 'on' : ''}">⭐ Favoris (${this.favs.length})</button><button data-wd="cat:base" class="${this.cat === 'base' ? 'on' : ''}">Tenues de base</button></div>
      <div class="wd-main"><div class="wd-grid">${grid}</div>
        <div class="wd-side"><h4>Tenue portée</h4><div class="wd-worn">${wornList.join('') || '<span>Tenue de base</span>'}</div>
          <p class="wd-note">Touche un vêtement pour l’essayer ; touche-le à nouveau pour le retirer. Une tenue complète remplace haut, bas et veste. ${MAX_ACC} accessoires au maximum.</p>
          ${this.buying ? (() => { const it = CLOTH_BY_ID[this.buying]; return `<div class="wd-buy"><b>Acheter « ${esc(it.name)} »</b><span>${it.price.toLocaleString('fr-FR')} FCFA • compte personnel (monnaie fictive du jeu)</span><button data-wd="buyok">✔ Confirmer l’achat</button><button class="alt" data-wd="buyno">Annuler</button></div>`; })() : ''}
          <button data-wd="fav">⭐ Enregistrer en favori</button><button class="alt" data-wd="clear">Tout retirer (tenue de base)</button></div></div></div>`;
    const g = this.dom.querySelector('.wd-grid'); if (g && this._scroll) g.scrollTop = this._scroll;
  }
  onClick(e) {
    const b = e.target.closest('[data-wd]'); if (!b) return; e.stopPropagation();
    const g = this.dom.querySelector('.wd-grid'); this._scroll = g ? g.scrollTop : 0;
    if (this.audio && this.audio.ctx && this.audio.click) this.audio.click();
    const [a, v] = b.dataset.wd.split(':');
    if (a === 'cat') { this.cat = v; this._scroll = 0; }
    else if (a === 'wear') return this.wear(v);
    else if (a === 'buyok') { const it = CLOTH_BY_ID[this.buying]; if (it && this.buyFn && this.buyFn(it)) { this.owned.add(it.id); this.buying = null; this.onSave && this.onSave(); return this.wear(it.id); } this.buying = null; }
    else if (a === 'buyno') this.buying = null;
    else if (a === 'ok') return this.close(true);
    else if (a === 'cancel') return this.close(false);
    else if (a === 'fav') this.favSave();
    else if (a === 'favon') { const f = this.favs[+v]; if (f) { this.cur = JSON.parse(JSON.stringify(f.cur)); this.rebuild(); } }
    else if (a === 'favdel') { if (b.dataset.sure) { this.favs.splice(+v, 1); this.onSave && this.onSave(); } else { b.dataset.sure = '1'; b.textContent = 'Confirmer ?'; return; } }
    else if (a === 'clear') { this.cur = EMPTY(); this.rebuild(); }
    else if (a === 'legacy') { this.cur = EMPTY(); if (this.legacy) this.legacy(v, true); }
    this.render();
  }
  handleKeys(input) { if (input.hit('Escape')) this.close(false); }
  serialize() { return { cur: this.cur, favs: this.favs, owned: [...this.owned] }; }
  restore(s) {
    if (!s) return;
    if (Array.isArray(s.owned)) this.owned = new Set(s.owned.filter((id) => CLOTH_BY_ID[id]));
    const ok = (id) => (id && CLOTH_BY_ID[id] && (!CLOTH_BY_ID[id].price || this.owned.has(id)) ? id : null);
    if (s.cur) this.cur = { haut: ok(s.cur.haut), bas: ok(s.cur.bas), veste: ok(s.cur.veste), tenue: ok(s.cur.tenue), pieds: ok(s.cur.pieds), acc: (s.cur.acc || []).filter((a) => CLOTH_BY_ID[a]).slice(0, MAX_ACC) };
    if (Array.isArray(s.favs)) this.favs = s.favs.filter((f) => f && f.cur).slice(0, MAX_FAVS);
    this.cur.acc = this.cur.acc.filter((a) => !CLOTH_BY_ID[a].price || this.owned.has(a));
  }
}
