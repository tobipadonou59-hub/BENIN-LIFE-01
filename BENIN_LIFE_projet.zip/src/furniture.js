// Mission 020, étape 6 — interactions avec les meubles et équipements de la VILLA NOVA.
// S'asseoir sur tous les sièges (canapés, fauteuils, chaises, tabourets, bancs, sièges du cinéma, fauteuil de direction),
// avec des actions selon l'endroit (regarder NOVA TV, travailler, manger, se détendre, NOVA Gestion, film) ; s'allonger
// sur les lits ; ranger ses articles (achats du marché et du supermarché) dans les commodes, dressings, buffet et vitrines
// du bureau. Le personnel utilise les équipements de ses tâches : plaques de cuisson du cuisinier, lave-linge de la
// buanderie, lits faits par l'équipe d'entretien ; pauses assises dans l'espace du personnel. Rangements sauvegardés.
import * as THREE from 'three';
import { VILLA } from './villa.js';
import { ARTICLE_BY_ID } from './market-data.js';

const PI = Math.PI;
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const H = { canapé: 0.55, fauteuil: 0.55, chaise: 0.52, 'chaise de réunion': 0.52, 'chaise de jardin': 0.56, 'chaise de bureau': 0.52, tabouret: 0.8, banc: 0.48, 'fauteuil de direction': 0.58, 'siège de cinéma': 0.55 };

export class Furniture {
  constructor(ctx) {
    Object.assign(this, ctx); // villa, luxe, player, ui, economy, env, needs, tv, cook, staff, bizUI, world, onSave
    this.seated = null; this.lying = null; this.store = {}; this.dom = document.getElementById('sitbar');
    if (this.dom) this.dom.addEventListener('click', (e) => { const b = e.target.closest('[data-sit]'); if (b) { e.stopPropagation(); this.act(b.dataset.sit); } });
    this.seats = this.collectSeats(); this.beds = this.collectBeds(); this.boxes = this.collectStorage(); this.buildEquipment();
  }
  // ------------------------------------------------------------------ inventaire des sièges, lits et rangements
  roomOf(x, z) { return Object.values(this.villa.rooms).find((R) => x >= R.x0 && x <= R.x1 && z >= R.z0 && z <= R.z1) || null; }
  collectSeats() {
    const out = (this.luxe ? this.luxe.seats : []).map((s) => ({ ...s }));
    const S = this.villa.rooms.salon; if (S) { // canapés d'origine du salon de réception
      for (const x of [-30, -28, -26]) out.push({ x, z: S.z1 - 3.25, ry: PI, kind: 'canapé' });
      for (const z of [18.9, 20, 21.1]) { out.push({ x: S.cx - 3 - 3.2 + 0.05, z, ry: PI / 2, kind: 'canapé' }); out.push({ x: S.cx - 3 + 3.2 - 0.05, z, ry: -PI / 2, kind: 'canapé' }); }
    }
    const Ci = this.villa.rooms.cinema; if (Ci) for (let r = 0; r < 3; r++) for (let k = 0; k < 5; k++) out.push({ x: Ci.cx - 4 + k * 2, z: Ci.z1 - (5 + r * 3) - 0.1, ry: 0, kind: 'siège de cinéma', dy: 0.15 * r });
    for (const s of out) { s.room = s.out ? null : (this.roomOf(s.x, s.z) || {}).id || 'couloirs'; if (s.kind === 'canapé' && s.room && /^(inv|enf|suite|ch_)/.test(s.room) && Math.abs(s.ry) === PI / 2 && this.luxe) s.kind = 'fauteuil'; }
    return out;
  }
  collectBeds() { return Object.values(this.villa.rooms).filter((R) => R.bed).map((R) => ({ room: R.id, name: R.name, x: R.bed.x, z: R.bed.z, sgn: R.z0 === 10 ? 1 : -1, bw: R.type === 'suite' ? 2.4 : 1.6 })); }
  collectStorage() { return (this.luxe && this.luxe.storage) || []; }
  // ------------------------------------------------------------------ équipements utilisés par le personnel
  buildEquipment() {
    const K = this.villa.rooms.cuisine, g = this.villa.inGroup; this.rings = [];
    if (K) { const m = new THREE.MeshBasicMaterial({ color: 0xff3a1a, toneMapped: false, transparent: true, opacity: 0.85 }); for (const [u, v] of [[-0.25, -0.8], [0.25, -0.8], [-0.25, -0.55], [0.25, -0.55]]) { const r = new THREE.Mesh(new THREE.TorusGeometry(0.08, 0.012, 6, 20).rotateX(PI / 2), m); r.position.set(K.cx + u, 0.945, K.z1 + v); r.visible = false; g.add(r); this.rings.push(r); } }
    const B = this.villa.rooms.buanderie; this.drums = [];
    if (B) for (let k = 0; k < 3; k++) { const grp = new THREE.Group(); grp.position.set(B.x0 + 0.95 + k * 1.1, 0.48, B.z1 - 1.22); g.add(grp); const glass = new THREE.Mesh(new THREE.CircleGeometry(0.26, 20), new THREE.MeshStandardMaterial({ color: 0x9ab8c4, roughness: 0.1, metalness: 0.3 })); glass.rotation.y = PI; grp.add(glass); const lin = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.07, 0.01), new THREE.MeshStandardMaterial({ color: [0x2f80ed, 0xe8112d, 0xf6f6f6][k] })); lin.position.z = -0.005; grp.add(lin); this.drums.push({ grp, lin }); }
  }
  // ------------------------------------------------------------------ interactions proposées par la touche E
  nearest(x, z) {
    if (!this.villa.inside || this.seated || this.lying) return null; const O = VILLA.O; let best = null;
    for (const s of this.seats) { if (s.out) continue; const d = Math.hypot(x - (O.x + s.x), z - (O.z + s.z)); if (d < 0.85 && (!best || d < best.d)) best = { d: d + 0.15, it: { label: () => `S’asseoir (${s.kind})`, action: () => this.sit(s) } }; }
    for (const b of this.beds) { const sx = b.x + b.bw / 2 + 0.45, d = Math.hypot(x - (O.x + sx), z - (O.z + b.z + b.sgn * 0.3)); if (d < 0.9 && (!best || d < best.d)) best = { d: d + 0.1, it: { label: () => 'S’allonger sur le lit', action: () => this.lie(b) } }; }
    for (const c of this.boxes) { const d = Math.hypot(x - (O.x + c.x), z - (O.z + c.z)); if (d < 0.95 && (!best || d < best.d)) best = { d: d + 0.2, it: { label: () => `Ranger des objets (${c.name})`, action: () => this.storageMenu(c) } }; }
    return best;
  }
  nearestOut(x, z) { // chaises de la pergola (jardin)
    if (this.villa.inside || this.seated || this.player.inCar) return null; let best = null;
    for (const s of this.seats) { if (!s.out) continue; const d = Math.hypot(x - s.x, z - s.z); if (d < 0.8 && (!best || d < best.d)) best = { d, it: { label: () => `S’asseoir (${s.kind})`, action: () => this.sit(s) } }; }
    return best;
  }
  // ------------------------------------------------------------------ s'asseoir / s'allonger
  place(x, y, z, ry) { const pl = this.player; pl.pos.set(x, y, z); pl.facing = ry; pl.mesh.position.set(x, y, z); pl.mesh.rotation.set(0, ry, 0); }
  sit(s) {
    const pl = this.player, O = s.out ? { x: 0, z: 0 } : VILLA.O, Y = s.out ? 0 : VILLA.Y, back = -0.12, px = s.x + Math.sin(s.ry) * back, pz = s.z + Math.cos(s.ry) * back;
    this.seated = s; this._floorY = pl.floorY; this.place(O.x + px, Y, O.z + pz, s.ry);
    if (pl.char && pl.char.sit) pl.char.sit(false); pl.mesh.position.y = Y + (H[s.kind] || 0.52) - 0.55 + (s.dy || 0);
    this.bar(); this.ui.toast(`🪑 Assis (${s.kind}). E ou « Se lever » pour te relever.`, 2);
  }
  lie(b) {
    const pl = this.player, O = VILLA.O; this.lying = b; if (pl.char && pl.char.stand) pl.char.stand();
    this.place(O.x + b.x, VILLA.Y, O.z + b.z, 0); pl.mesh.position.set(O.x + b.x, VILLA.Y + 0.78, O.z + b.z - b.sgn * 0.8); // pieds vers le bas du lit, tête vers la tête de lit
    pl.mesh.rotation.order = 'YXZ'; pl.mesh.rotation.set(-PI / 2, b.sgn > 0 ? PI : 0, 0);
    this.bar(); this.ui.toast('🛏️ Allongé sur le lit. E pour te lever.', 2);
  }
  stand() {
    const pl = this.player; if (!this.seated && !this.lying) return; const s = this.seated, b = this.lying; this.seated = null; this.lying = null;
    if (pl.char && pl.char.stand) pl.char.stand(); pl.mesh.rotation.order = 'XYZ'; pl.mesh.rotation.set(0, pl.facing, 0);
    const O = s && s.out ? { x: 0, z: 0 } : VILLA.O, Y = s && s.out ? 0 : VILLA.Y;
    if (s) { // se relever devant le siège, sinon derrière ou sur le côté (chaises tournées vers une table)
      const col = this.world.collision, lv = col.level; col.level = s.out ? 0 : VILLA.LV; let best = null;
      for (const [a, d] of [[0, 0.65], [PI, 0.7], [PI / 2, 0.7], [-PI / 2, 0.7], [0, 0.95], [PI, 1.0], [PI / 2, 1.0], [-PI / 2, 1.0]]) { const ang = s.ry + a, fx = s.x + Math.sin(ang) * d, fz = s.z + Math.cos(ang) * d; if (![[0, 0], [0.3, 0], [-0.3, 0], [0, 0.3], [0, -0.3]].some(([u, v]) => col.pointBlocked(O.x + fx + u, Y + 0.3, O.z + fz + v))) { best = [fx, fz]; break; } }
      col.level = lv; const [fx, fz] = best || [s.x + Math.sin(s.ry) * 0.65, s.z + Math.cos(s.ry) * 0.65]; this.place(O.x + fx, Y, O.z + fz, s.ry); }
    else if (b) this.place(O.x + b.x + b.bw / 2 + 0.55, Y, O.z + b.z, PI / 2);
    pl.mesh.position.y = Y; if (this.dom) this.dom.classList.remove('show');
  }
  get busy() { return !!(this.seated || this.lying); }
  actions() {
    const s = this.seated, b = this.lying, out = [];
    if (b) { out.push(['sleep', '😴 Dormir / sieste'], ['phone', '📱 Téléphone']); }
    else if (s) {
      const r = s.room;
      if (r === 'salon' && this.tv) out.push(['tv', '📺 Regarder NOVA TV']);
      if (s.kind === 'chaise de bureau') out.push(['work', '💻 Travailler (1 h)']);
      if (s.kind === 'fauteuil de direction') out.push(['gestion', '📊 NOVA Gestion'], ['work', '💻 Travailler (1 h)']);
      if ((r === 'manger' || (r === 'cuisine' && s.kind === 'chaise')) && this.villa.meal) out.push(['meal', '🍽️ Prendre un repas']);
      if (r === 'cinema') out.push(['film', '🎬 Regarder un film (2 h)']);
      if (s.out) out.push(['air', '🌴 Profiter du jardin (30 min)']);
      out.push(['rest', '😌 Se détendre (30 min)']);
    }
    out.push(['up', '🚶 Se lever']); return out;
  }
  bar() { if (!this.dom) return; this.dom.innerHTML = `${this.actions().map(([k, l]) => `<button data-sit="${k}">${l}</button>`).join('')}`; this.dom.classList.add('show'); }
  act(k) {
    const V = this.villa, s = this.seated;
    if (k === 'up') return this.stand();
    if (k === 'tv') { this.stand(); return this.tv.watch('salon'); }
    if (k === 'gestion') { this.stand(); return this.bizUI && this.bizUI.toggle(true); }
    if (k === 'meal') { this.stand(); return V.meal(); }
    if (k === 'phone') { this.economy.togglePhone(true); return; }
    if (k === 'sleep') { const b = this.lying; this.stand(); return V.sleepMenu(b ? b.name : 'Chambre'); }
    const pose = () => { if (this.seated) this.sit(this.seated); }; // l'activité garde le joueur assis
    if (k === 'work') { V.activity('Travail au bureau', 1, { energy: -5 }, 'Tu avances sur tes dossiers.'); }
    else if (k === 'film') V.activity('Séance de cinéma', 2, { energy: 6 }, 'Film projeté sur grand écran (programme fictif) 🍿');
    else if (k === 'rest') V.activity('Détente', 0.5, { energy: 6 }, `Un moment de calme (${s ? s.kind : 'repos'}).`);
    else if (k === 'air') { this.env.time = (this.env.time + 0.5) % 24; if (this.needs) this.needs.energy = Math.min(100, this.needs.energy + 5); this.ui.toast('🌴 Une demi-heure à l’ombre de la pergola.', 2.5); }
    setTimeout(pose, 50);
  }
  handleKeys(input) { if (input.hit('KeyE') || input.hit('Escape')) this.stand(); }
  // ------------------------------------------------------------------ rangements (articles achetés)
  storageMenu(c) {
    const inv = this.economy.items || {}, st = this.store[c.id] || {}, items = [], name = (id) => (ARTICLE_BY_ID[id] ? `${ARTICLE_BY_ID[id].icon} ${ARTICLE_BY_ID[id].name}` : id);
    for (const [id, n] of Object.entries(inv)) if (n > 0) items.push({ label: `⬇️ Ranger : ${name(id)} (×${n} sur toi)`, action: () => { this.move(id, c, 1); this.storageMenu(c); } });
    for (const [id, n] of Object.entries(st)) if (n > 0) items.push({ label: `⬆️ Reprendre : ${name(id)} (×${n} rangé${n > 1 ? 's' : ''})`, action: () => { this.move(id, c, -1); this.storageMenu(c); } });
    if (!items.length) items.push({ label: 'Rien à ranger : achète des articles au marché Dantokpa ou au supermarché.', action: () => {} });
    this.ui.openMenu(`🗄️ ${c.name}`, `${Object.values(st).reduce((a, b) => a + b, 0)} objet(s) rangé(s) ici • ${Object.values(inv).reduce((a, b) => a + b, 0)} sur toi (« Mes articles » du téléphone)`, items);
  }
  move(id, c, dir) {
    const inv = this.economy.items, st = (this.store[c.id] ||= {});
    if (dir > 0) { if (!inv[id]) return; inv[id]--; if (!inv[id]) delete inv[id]; st[id] = (st[id] || 0) + 1; }
    else { if (!st[id]) return; st[id]--; if (!st[id]) delete st[id]; inv[id] = (inv[id] || 0) + 1; }
    this.onSave && this.onSave();
  }
  // ------------------------------------------------------------------ boucle : personnel et équipements
  update(dt) {
    if (this.seated && !this.seated.out && !this.villa.inside) this.stand();
    if (this.lying && !this.villa.inside) this.stand();
    if (!this.villa.inside) return;
    // plaques allumées quand le cuisinier cuisine aux plaques
    const ck = this.cook, K = this.villa.rooms.cuisine; let hot = false;
    if (ck && ck.hired && ck.c && ck.c.group.visible && K) { const sp = ck.spots()[3]; hot = Math.hypot(ck.x - sp.x, ck.z - sp.z) < 0.6 || (ck.queue && ck.queue.length > 0 && ck.target === sp); }
    for (const r of this.rings) r.visible = hot;
    // lave-linge en marche quand la blanchisseuse travaille à la buanderie
    const st = this.staff, washing = !!(st && st.team.some((m) => m.cur && m.cur.working && m.cur.spot && m.cur.spot.room === 'buanderie'));
    this.drums.forEach((d, i) => { if (washing && i < 2) d.lin.rotation.z += dt * (6 + i * 2); });
    // pauses assises du personnel dans l'espace du personnel
    if (st) for (const m of st.team) this.staffBreak(m, dt);
  }
  staffBreak(m, dt) {
    const free = !m.cur && m.c && m.c.group.visible && m.c.group.parent === this.villa.inGroup;
    if (!free) { if (m._seat) { m._seat.taken = null; m._seat = null; if (m.c && m.c.stand) m.c.stand(); m._sat = false; } return; }
    if (!m._seat) { const s = this.seats.find((q) => q.room === 'personnel' && !q.taken); if (!s) return; s.taken = m.id; m._seat = s; m._walk = this.staff.pathIn(m, s.x + Math.sin(s.ry) * 0.6, s.z + Math.cos(s.ry) * 0.6).concat([[s.x, s.z]]); }
    const c = m.c; if (m._walk && m._walk.length) { const [tx, tz] = m._walk[0], dx = tx - m.x, dz = tz - m.z, d = Math.hypot(dx, dz); if (d < 0.12) m._walk.shift(); else { const v = Math.min(1.3, d * 3); m.x += dx / d * v * dt; m.z += dz / d * v * dt; m.h = Math.atan2(dx, dz); c.group.position.set(m.x, 0, m.z); c.group.rotation.y = m.h; c.animate(dt, v); } return; }
    if (!m._sat) { m._sat = true; c.sit(false); } c.group.position.set(m._seat.x, -0.03, m._seat.z); c.group.rotation.y = m._seat.ry;
  }
  freeSpot(R, x, z) { // emplacement de travail du personnel hors des meubles
    const col = this.world.collision, lv = col.level; col.level = VILLA.LV; const bad = (a, b) => a < R.x0 + 0.6 || a > R.x1 - 0.6 || b < R.z0 + 0.6 || b > R.z1 - 0.6 || [[0, 0], [0.35, 0], [-0.35, 0], [0, 0.35], [0, -0.35]].some(([u, v]) => col.pointBlocked(VILLA.O.x + a + u, VILLA.Y + 0.3, VILLA.O.z + b + v));
    let out = [x, z]; if (bad(x, z)) { out = null; for (let r = 0.5; r < 5 && !out; r += 0.5) for (let k = 0; k < 12 && !out; k++) { const a = x + Math.cos(k * PI / 6) * r, b = z + Math.sin(k * PI / 6) * r; if (!bad(a, b)) out = [a, b]; } }
    col.level = lv; return out || [R.cx, R.cz];
  }
  serialize() { return { store: this.store }; }
  restore(s) { if (s && s.store) this.store = s.store; }
}
