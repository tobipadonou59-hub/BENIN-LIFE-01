// Mission 019, étape 1 — VILLA NOVA : agrandissement de la résidence du joueur (la maison existante est conservée).
// Extérieur (sur la parcelle existante, le terrain étant bordé par les maisons voisines et la route) : entrée
// « VILLA NOVA » avec portail et portillon automatiques, lampadaires, jardin paysager (massifs, bordures, bornes
// lumineuses), grande piscine à débordement avec plage et transats, salon de jardin sur la terrasse, abri deux
// véhicules (garage total : maison + limousine + abri = 4 places).
// Intérieur : nouvelle aile principale accessible par une porte au dos de la maison (intérieur isolé, même principe que
// les bureaux et les hôtels du jeu) : grand salon, salle à manger, cuisine professionnelle, bureau, cinéma, salle de
// sport, salle de jeux, buanderie, salles de bains, espace du personnel, et 9 chambres (suite parentale, 3 chambres
// d'enfants, 4 chambres d'invités, chambre du personnel), chacune avec salle de bain privée, armoire, lit, télévision,
// bureau et décoration personnalisable (sauvegardée).
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { colorize } from './vehicles.js';

const PI = Math.PI;
export const VILLA = { O: { x: -44, z: 126 }, Y: 520, LV: 150 }; // niveau isolé de l'aile (au-dessus de la maison)
export const POOL = { x0: -35.2, x1: -29.8, z0: 130.2, z1: 140.4 };
const CARPORT = { x0: -61.7, x1: -56.7, z0: 113.2, z1: 124.6 };
const DOOR = { x: -42, z: 134.25 }; // porte de l'aile, au dos de la maison (terrasse)
// palettes de décoration des chambres (murs, linge de lit)
export const THEMES = [['Ivoire et or', 0xf1e6cf, 0xd8a830], ['Bleu lagune', 0xd6e6f2, 0x1f4e9c], ['Vert NOVA', 0xdcebdc, 0x0b6e4f], ['Rose poudré', 0xf3dde2, 0xc0587a], ['Terracotta', 0xf0d8c4, 0xb4532a], ['Lavande', 0xe6dff2, 0x6a4a9a], ['Pagne wax', 0xf6e7b8, 0xe46a1f]];
// pièces : [id, nom, x0, z0, x1, z1, type, porte (x ou z sur le couloir)]
const ROOMS = [
  ['salon', 'Grand salon', -34, 10, -16, 26, 'salon'], ['manger', 'Salle à manger familiale', -16, 10, -2, 26, 'manger'], ['cuisine', 'Cuisine professionnelle', -2, 10, 12, 26, 'cuisine'],
  ['buanderie', 'Buanderie', 12, 10, 20, 26, 'buanderie'], ['personnel', 'Espace du personnel', 20, 10, 28, 26, 'personnel'], ['ch_perso', 'Chambre du personnel de maison', 28, 10, 36, 26, 'chambre'],
  ['bureau', 'Bureau personnel', -34, -10, -26, 6, 'bureau'], ['cinema', 'Salle de cinéma', -26, -10, -12, 6, 'cinema'], ['sport', 'Salle de sport', -12, -10, 0, 6, 'sport'], ['jeux', 'Salle de jeux', 0, -10, 12, 6, 'jeux'],
  ['sdb', 'Salle de bains commune', 12, -10, 18, 6, 'sdb'], ['inv3', 'Chambre d’invités 3', 18, -10, 27, 6, 'chambre'], ['inv4', 'Chambre d’invités 4', 27, -10, 36, 6, 'chambre'],
  ['suite', 'Suite parentale', -34, -30, -16, -14, 'suite'], ['enf1', 'Chambre d’enfant 1', -16, -30, -6, -14, 'chambre'], ['enf2', 'Chambre d’enfant 2', -6, -30, 4, -14, 'chambre'], ['enf3', 'Chambre d’enfant 3', 4, -30, 14, -14, 'chambre'],
  ['inv1', 'Chambre d’invités 1', 14, -30, 25, -14, 'chambre'], ['inv2', 'Chambre d’invités 2', 25, -30, 36, -14, 'chambre'],
];
export const VILLA_ROOMS = ROOMS.map(([id, name, , , , , type]) => ({ id, name, type }));

export class Villa {
  constructor(ctx) {
    Object.assign(this, ctx); // scene, world, player, ui, audio, env, needs, home, tpc, wardrobe, kitchen, bizUI, economy, onSave
    this.inside = false; this.decor = {}; this.autoGate = true; this.poolLights = true; this.points = []; this.act = null; this.swimT = 0;
    if (this.scene.getObjectByName('VILLA_NOVA')) throw new Error('villa déjà construite'); // jamais deux fois
    this.buildOutside(); this.buildInside();
  }
  // ------------------------------------------------------------------ outils de construction
  batch() { const parts = []; return { parts, box: (x0, y0, z0, x1, y1, z1, c) => parts.push(colorize(new THREE.BoxGeometry(Math.abs(x1 - x0), Math.abs(y1 - y0), Math.abs(z1 - z0)).translate((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), c)), cyl: (r, h, x, y, z, c, seg = 10) => parts.push(colorize(new THREE.CylinderGeometry(r, r, h, seg).translate(x, y, z), c)) }; }
  mesh(b, opts = {}) { if (!b.parts.length) return null; const m = new THREE.Mesh(mergeGeometries(b.parts), new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.7, ...opts })); m.castShadow = m.receiveShadow = true; return m; }
  label(text, w, h, bg = '#0b0c0e', fg = '#d8a830', font = 26) { const c = document.createElement('canvas'); c.width = 512; c.height = Math.round(512 * h / w); const x = c.getContext('2d'); x.fillStyle = bg; x.fillRect(0, 0, c.width, c.height); x.fillStyle = fg; x.font = `900 ${font}px Georgia`; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(text, c.width / 2, c.height / 2 + 2); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ map: t, toneMapped: false })); }
  // ------------------------------------------------------------------ extérieur (parcelle existante)
  buildOutside() {
    const g = new THREE.Group(); g.name = 'VILLA_NOVA'; this.scene.add(g); const b = this.batch(), col = this.world.collision;
    // entrée : fronton « VILLA NOVA » au-dessus du portillon, lanternes sur les piliers
    const sign = this.label('VILLA NOVA', 3.2, 0.5); sign.position.set(-44.5, 3.05, 109.86); sign.rotation.y = PI; g.add(sign);
    b.box(-46.3, 2.7, 109.8, -42.7, 3.3, 110.0, 0x1a1a1a);
    this.lanterns = [];
    for (const px of [-45.85, -43.15, -35.65, -28.35]) { b.box(px - 0.12, 2.7, 109.88, px + 0.12, 3.0, 110.12, 0x1a1a1a); const l = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.26, 0.2), new THREE.MeshBasicMaterial({ color: 0xffe2a0, toneMapped: false })); l.position.set(px, 3.13, 110); g.add(l); this.lanterns.push(l); }
    // jardin paysager : massifs fleuris, bordures, bornes lumineuses le long des allées
    for (const [x0, z0, x1, z1] of [[-58, 113, -50, 116], [-41, 113, -37, 116], [-58, 136.6, -52, 138.2]]) { b.box(x0, 0.06, z0, x1, 0.22, z1, 0x5a3a22); for (let i = 0; i < (x1 - x0) * 2; i++) b.box(x0 + 0.25 + i * 0.5, 0.22, z0 + 0.3 + (i % 3) * ((z1 - z0 - 0.6) / 2), x0 + 0.5 + i * 0.5, 0.45, z0 + 0.55 + (i % 3) * ((z1 - z0 - 0.6) / 2), [0xe8112d, 0xfcd116, 0xc0587a, 0xf6f6f6][i % 4]); }
    this.bollards = [];
    for (const z of [111.5, 113.5, 115.5, 117]) for (const x of [-46, -43]) { b.box(x - 0.07, 0, z - 0.07, x + 0.07, 0.5, z + 0.07, 0x23262b); const l = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.06, 0.12), new THREE.MeshBasicMaterial({ color: 0xfff0c8, toneMapped: false })); l.position.set(x, 0.5, z); g.add(l); this.bollards.push(l); }
    // grande piscine (bassin, margelles, plage en bois, transats, parasol, échelle)
    const P = POOL;
    for (const [x0, z0, x1, z1] of [[P.x0 - 0.9, P.z0 - 1.6, P.x1 + 0.9, P.z0 - 0.3], [P.x0 - 0.9, P.z1 + 0.3, P.x1 + 0.9, P.z1 + 0.9], [P.x0 - 0.9, P.z0 - 0.3, P.x0 - 0.3, P.z1 + 0.3], [P.x1 + 0.3, P.z0 - 0.3, P.x1 + 0.9, P.z1 + 0.3]]) b.box(x0, 0.0, z0, x1, 0.1, z1, 0x9a7a52); // plage en bois autour du bassin
    for (const [x0, z0, x1, z1] of [[P.x0 - 0.3, P.z0 - 0.3, P.x1 + 0.3, P.z0], [P.x0 - 0.3, P.z1, P.x1 + 0.3, P.z1 + 0.3], [P.x0 - 0.3, P.z0, P.x0, P.z1], [P.x1, P.z0, P.x1 + 0.3, P.z1]]) b.box(x0, 0, z0, x1, 0.46, z1, 0xeee8dc); // margelles (bassin surélevé)
    b.box(P.x0, 0.07, P.z0, P.x1, 0.12, P.z1, 0x2f9ed0);                                                        // fond carrelé
    for (let k = 0; k < 6; k++) b.box(P.x0 + 0.2, 0.121, P.z0 + 0.6 + k * 1.6, P.x1 - 0.2, 0.125, P.z0 + 0.7 + k * 1.6, 0x1a6a9a); // lignes de nage
    for (const s of [-0.25, 0.25]) b.box(P.x1 - 0.5 + s - 0.02, 0.1, P.z0 + 0.15, P.x1 - 0.5 + s + 0.02, 1.2, P.z0 + 0.2, 0xd8dde2);   // échelle
    this.water = new THREE.Mesh(new THREE.PlaneGeometry(P.x1 - P.x0, P.z1 - P.z0, 8, 16).rotateX(-PI / 2), new THREE.MeshStandardMaterial({ color: 0x3fb6e8, transparent: true, opacity: 0.78, roughness: 0.05, metalness: 0.1, emissive: 0x0a4a70, emissiveIntensity: 0.3 }));
    this.water.position.set((P.x0 + P.x1) / 2, 0.36, (P.z0 + P.z1) / 2); g.add(this.water);
    const poolCol = col.addBox(P.x0 - 0.05, P.z0 - 0.05, P.x1 + 0.05, P.z1 + 0.05, 0.6); this.poolCol = poolCol;
    // transats et parasol (bande arrière du jardin), salon de jardin sur la terrasse
    for (let k = 0; k < 3; k++) { const x = -48 + k * 2.4; b.box(x - 0.35, 0.25, 139.2, x + 0.35, 0.33, 141.1, 0xf6f6f6); b.box(x - 0.35, 0.33, 140.6, x + 0.35, 0.8, 140.75, 0xf6f6f6); b.box(x - 0.3, 0, 139.3, x + 0.3, 0.25, 141, 0x8a8f96); col.addBox(x - 0.4, 139.2, x + 0.4, 141.1, 0.8); }
    b.cyl(0.03, 2.3, -40.2, 1.15, 140.2, 0xd8dde2); const umb = new THREE.Mesh(new THREE.ConeGeometry(1.5, 0.45, 10, 1, true), new THREE.MeshStandardMaterial({ color: 0x0b6e4f, side: THREE.DoubleSide })); umb.position.set(-40.2, 2.3, 140.2); g.add(umb);
    for (const [x, z, ry] of [[-54.6, 135.6, 0], [-52.4, 137.4, PI / 2]]) { const sx = ry ? 0.45 : 1.1, sz = ry ? 1.1 : 0.45; b.box(x - sx, 0.08, z - sz, x + sx, 0.45, z + sz, 0x6a4a32); b.box(x - sx + 0.05, 0.45, z - sz + 0.05, x + sx - 0.05, 0.6, z + sz - 0.05, 0xe9dcc0); col.addBox(x - sx, z - sz, x + sx, z + sz, 0.6); }
    // abri deux véhicules (structure, toit, marquage au sol)
    const C = CARPORT; for (const [x, z] of [[C.x0, C.z0], [C.x1, C.z0], [C.x0, C.z1], [C.x1, C.z1]]) { b.box(x - 0.1, 0, z - 0.1, x + 0.1, 2.7, z + 0.1, 0x23262b); col.addCircle(x, z, 0.15, 2.7); }
    b.box(C.x0 - 0.3, 2.7, C.z0 - 0.3, C.x1 + 0.3, 2.85, C.z1 + 0.3, 0x2a2d33); b.box(C.x0, 0.06, C.z0, C.x1, 0.08, C.z1, 0x8a8a8a);
    b.box(C.x0 + 0.2, 0.08, (C.z0 + C.z1) / 2 - 0.05, C.x1 - 0.2, 0.09, (C.z0 + C.z1) / 2 + 0.05, 0xf6f6f6);
    // porte de l'aile de la villa (au dos de la maison, sur la terrasse)
    b.box(DOOR.x - 1.15, 0, DOOR.z - 0.05, DOOR.x + 1.15, 2.75, DOOR.z + 0.12, 0xd8a830); b.box(DOOR.x - 0.95, 0, DOOR.z + 0.05, DOOR.x + 0.95, 2.5, DOOR.z + 0.14, 0x3a2416);
    const ds = this.label('AILE PRINCIPALE • VILLA NOVA', 2.6, 0.32); ds.position.set(DOOR.x, 3.0, DOOR.z + 0.16); g.add(ds);
    const m = this.mesh(b); g.add(m); this.outGroup = g;
  }
  // ------------------------------------------------------------------ intérieur (aile principale, niveau isolé)
  buildInside() {
    const { O, Y, LV } = VILLA, g = new THREE.Group(); g.position.set(O.x, Y, O.z); g.visible = false; this.scene.add(g); this.inGroup = g;
    const b = this.batch(), col = this.world.collision, H = 3.2, T = 0.18;
    const solid = (x0, z0, x1, z1, h = H) => { const o = col.addBox(O.x + Math.min(x0, x1), O.z + Math.min(z0, z1), O.x + Math.max(x0, x1), O.z + Math.max(z0, z1), Y + h); o.lv = LV; };
    const wallX = (z, x0, x1, gaps = [], c = 0xf4efe6) => { let a = x0; for (const [g0, g1] of [...gaps, [x1, x1]]) { if (g0 > a) { b.box(a, 0, z - T / 2, g0, H, z + T / 2, c); solid(a, z - T / 2, g0, z + T / 2); } a = g1; } };
    const wallZ = (x, z0, z1, gaps = [], c = 0xf4efe6) => { let a = z0; for (const [g0, g1] of [...gaps, [z1, z1]]) { if (g0 > a) { b.box(x - T / 2, 0, a, x + T / 2, H, g0, c); solid(x - T / 2, a, x + T / 2, g0); } a = g1; } };
    // sols : marbre (couloirs, réception), parquet (chambres), carrelage (cuisine, bains)
    b.box(-37, -0.1, -31, 37, 0, 27, 0xe8e2d6);
    for (const [, , x0, z0, x1, z1, type] of ROOMS) b.box(x0, 0, z0, x1, 0.02, z1, { chambre: 0xa0703f, suite: 0x8a5a32, cuisine: 0xd0d4d8, sdb: 0xbfd6dc, buanderie: 0xc8ccd0, sport: 0x3a3d42, cinema: 0x3a1418, jeux: 0x2a4a6a }[type] || 0xd9cdb8);
    // murs extérieurs et cloisons (portes sur les couloirs z 6–10 et z −14…−10)
    wallX(27, -37, 37); wallX(-31, -37, 37); wallZ(-37, -31, 27, [[6.6, 9.4]]); wallZ(37, -31, 27);
    const doorsN = ROOMS.filter((r) => r[3] === 10).map((r) => [(r[2] + r[4]) / 2 - 0.8, (r[2] + r[4]) / 2 + 0.8]);
    const doorsM = ROOMS.filter((r) => r[3] === -10).map((r) => [(r[2] + r[4]) / 2 - 0.8, (r[2] + r[4]) / 2 + 0.8]);
    const doorsS = ROOMS.filter((r) => r[3] === -30).map((r) => [(r[2] + r[4]) / 2 - 0.8, (r[2] + r[4]) / 2 + 0.8]);
    const J = [-36.9, -34.1]; // galerie ouest qui relie les deux couloirs
    wallX(10, -36.9, 36.9, [J, ...doorsN]); wallX(6, -36.9, 36.9, [J, ...doorsM]); wallX(-10, -36.9, 36.9, [J]); wallX(-14, -36.9, 36.9, [J, ...doorsS]);
    for (const r of ROOMS) { const [, , x0, z0, x1, z1] = r; wallZ(x0, z0 + 0.1, z1 - 0.1); if (x1 === 36) wallZ(x1, z0 + 0.1, z1 - 0.1); }
    // le mur z = −10 n'a pas de portes : les pièces du rang central s'ouvrent sur le couloir nord (z 6–10)
    this.rooms = {}; this.points = [];
    const P = (x, z, r, label, action, room) => this.points.push({ x, z, r, label, action, room });
    for (const [id, name, x0, z0, x1, z1, type] of ROOMS) {
      const cx = (x0 + x1) / 2, cz = (z0 + z1) / 2, R = { id, name, type, x0, z0, x1, z1, cx, cz, door: { x: cx, z: z0 === 10 ? 10.6 : z0 === -10 ? 5.4 : -13.4 } };
      this.rooms[id] = R;
      const plaque = this.label(name, 2.4, 0.3, '#f6f1e6', '#3a2416', 22); plaque.position.set(cx + 1.8, 2.5, z0 === 10 ? 9.88 : z0 === -10 ? 6.12 : -13.88); plaque.rotation.y = z0 === 10 ? PI : 0; g.add(plaque);
      this.furnish(R, b, g, solid, P);
    }
    // couloirs : tapis, plantes, tableaux, lustres
    b.box(-34, 0.02, 7.3, 34, 0.03, 8.7, 0x6a1a2a); b.box(-34, 0.02, -12.7, 34, 0.03, -11.3, 0x6a1a2a);
    for (const x of [-30, -10, 10, 30]) { b.cyl(0.25, 0.5, x, 0.25, 8, 0x3a2416); b.cyl(0.05, 0.9, x, 0.95, 8, 0x2a6a3a); b.box(x - 0.45, 1.2, 7.55, x + 0.45, 1.7, 8.45, 0x2f8a4a); }
    for (const x of [-24, 0, 24]) b.box(x - 0.6, 1.4, 6.12, x + 0.6, 2.2, 6.16, [0xe46a1f, 0x1f4e9c, 0x0b6e4f][(x / 24 + 1) | 0]);
    // passage entre les deux couloirs (escalier d'honneur stylisé à l'ouest)
    b.box(-36.8, 0.02, -13.8, -34.3, 0.03, 9.8, 0x6a1a2a); for (let k = 0; k < 5; k++) b.box(-36.75, 1.3, -8 + k * 3, -36.7, 2.1, -6.8 + k * 3, [0xd8a830, 0x0b6e4f, 0xe46a1f, 0x1f4e9c, 0x7a2a8a][k]); // galerie de tableaux
    // entrée : sortie vers la terrasse de la maison
    P(-36.2, 8, 1.5, 'Retourner sur la terrasse de la maison', () => this.exit());
    const m = this.mesh(b); g.add(m);
  }
  // ------------------------------------------------------------------ mobilier et interactions par pièce
  furnish(R, b, g, solid, P) {
    const { id, type, x0, z0, x1, z1, cx, cz, name } = R, w = x1 - x0, d = z1 - z0, back = z0 === 10 ? z1 - 0.4 : z0 + 0.4, front = z0 === 10 ? z0 : z1, sgn = z0 === 10 ? 1 : -1;
    const at = (u, v) => [cx + u, z0 === 10 ? z0 + v : z1 - v]; // u : travers, v : profondeur depuis la porte
    const T = THEMES[this.decor[id] || 0];
    if (type === 'chambre' || type === 'suite') {
      // matériaux propres à la pièce (décoration personnalisable)
      const wallM = new THREE.MeshStandardMaterial({ color: T[1], roughness: 0.8 }), bedM = new THREE.MeshStandardMaterial({ color: T[2], roughness: 0.7 });
      const bw = type === 'suite' ? 2.4 : 1.6, [bx, bz] = at(-w / 2 + bw / 2 + 1.0, d - 2.3);
      const accent = new THREE.Mesh(new THREE.BoxGeometry(w - 0.4, 2.9, 0.05), wallM); accent.position.set(cx, 1.5, z0 === 10 ? z1 - 0.12 : z0 + 0.12); g.add(accent);
      b.box(bx - bw / 2, 0, bz - 1.1, bx + bw / 2, 0.45, bz + 1.1, 0x4a2a16); b.box(bx - bw / 2 + 0.05, 0.45, bz - 1.05, bx + bw / 2 - 0.05, 0.6, bz + 1.05, 0xf6f6f6);
      const sheet = new THREE.Mesh(new THREE.BoxGeometry(bw - 0.05, 0.08, 1.4), bedM); sheet.position.set(bx, 0.64, bz - sgn * 0.3); g.add(sheet);
      b.box(bx - bw / 2, 0.45, bz + sgn * 1.1, bx + bw / 2, 1.3, bz + sgn * 1.2, 0x4a2a16);   // tête de lit
      solid(bx - bw / 2, bz - 1.1, bx + bw / 2, bz + 1.2, 0.7);
      const [ax, az] = at(w / 2 - 0.5, d - 2.0); b.box(ax - 0.35, 0, az - 1.0, ax + 0.35, 2.2, az + 1.0, 0x6a4a32); solid(ax - 0.35, az - 1.0, ax + 0.35, az + 1.0, 2.2);          // armoire
      const [dx, dz] = at(w / 2 - 0.6, 1.6); b.box(dx - 0.4, 0.72, dz - 0.7, dx + 0.4, 0.78, dz + 0.7, 0xe8dcc4); b.box(dx - 0.35, 0, dz - 0.6, dx + 0.35, 0.72, dz - 0.55, 0x6a4a32);  // bureau
      const [tx, tz] = at(-w / 2 + 0.15, d / 2 - 0.4); b.box(tx - 0.05, 1.1, tz - 0.8, tx + 0.05, 1.9, tz + 0.8, 0x111111);                                                       // télévision murale
      (this.screens ||= []).push({ id, name: `TV — ${name}`, room: id, x: tx, y: 1.5, z: tz, nx: 1, nz: 0, w: 1.55, h: 0.76 });
      // salle de bain privée (cloison vitrée, douche, lavabo)
      const [sx, sz] = at(-w / 2 + 1.2, 1.1); b.box(sx - 1.1, 0.02, sz - 0.9, sx + 1.1, 0.03, sz + 0.9, 0xbfd6dc); b.box(sx + 1.1, 0, sz - 0.9, sx + 1.15, 2.2, sz + 0.9, 0x9ab8c4); b.box(sx - 0.9, 0.8, sz - 0.25, sx - 0.4, 0.9, sz + 0.25, 0xf6f6f6);
      R.lamp = this.themedLamp(T, bx, bz, sgn); g.add(R.lamp);
      R.mats = { wallM, bedM }; R.bed = { x: bx, z: bz }; R.desk = { x: dx, z: dz };
      P(bx + bw / 2 + 0.5, bz, 1.5, type === 'suite' ? 'Dormir dans la suite parentale' : `Se reposer (${name})`, () => this.sleepMenu(name), id);
      P(ax - 0.8, az, 1.2, 'Ouvrir l’armoire (garde-robe)', () => this.wardrobe && this.wardrobe.show(false), id);
      P(dx - 0.8, dz, 1.2, 'Travailler au bureau', () => this.activity('Travail au bureau', 1, { energy: -5 }, 'Tu avances sur tes dossiers.'), id);
      P(sx, sz, 1.2, 'Prendre une douche (salle de bain privée)', () => this.activity('Douche', 0.3, { hygiene: 100 }, 'Douche rafraîchissante dans ta salle de bain privée.'), id);
      P(cx, front - sgn * -1.6, 1.2, `Changer la décoration (${T[0]})`, () => this.cycleDecor(id), id);
      if (type === 'suite') { const [kx, kz] = at(0, d - 0.9); b.box(kx - 1.6, 0, kz - 0.3, kx + 1.6, 2.3, kz + 0.3, 0x5a3a22); P(kx, kz - sgn * 1, 1.3, 'Dressing de la suite (garde-robe)', () => this.wardrobe && this.wardrobe.show(false), id); }
      return;
    }
    if (type === 'salon') {
      for (const [u, v, rw, rd] of [[-3, d - 3, 5, 1.0], [-6.2, d - 6, 1.0, 4], [0.2, d - 6, 1.0, 4]]) { const [x, z] = at(u, v); b.box(x - rw / 2, 0, z - rd / 2, x + rw / 2, 0.45, z + rd / 2, 0x2a2d33); b.box(x - rw / 2 + 0.05, 0.45, z - rd / 2 + 0.05, x + rw / 2 - 0.05, 0.6, z + rd / 2 - 0.05, 0xe9dcc0); solid(x - rw / 2, z - rd / 2, x + rw / 2, z + rd / 2, 0.6); }
      const [tx, tz] = at(-3, d - 6); b.box(tx - 1.2, 0.35, tz - 0.6, tx + 1.2, 0.42, tz + 0.6, 0xd8a830); solid(tx - 1.2, tz - 0.6, tx + 1.2, tz + 0.6, 0.45);
      // écran géant remplacé par la Smart TV 100 pouces de NOVA TV (mission 020, voir novatv.js)
      b.box(cx + w / 2 - 1.6, 0, z0 + 1, cx + w / 2 - 0.4, 1.0, z1 - 1, 0x3a2416);                               // piano / buffet
      P(...at(-3, d - 4.2), 1.8, 'S’installer dans le grand salon', () => this.activity('Détente au salon', 1, { energy: 8 }, 'Moment de détente dans le grand salon.'), id);
      P(cx + w / 2 - 2.3, cz, 1.5, 'Jouer du piano', () => this.activity('Piano', 0.5, {}, 'Quelques notes résonnent dans la villa 🎹'), id);
      return;
    }
    if (type === 'manger') {
      const [x, z] = at(0, d / 2); solid(x - 1.0, z - 3.2, x + 1.0, z + 3.2, 0.8); // table familiale et 12 chaises rembourrées : mobilier de luxe (luxe.js, mission 020)
      P(x + 1.9, z, 1.8, 'Prendre un repas à la table familiale (plats du cuisinier)', () => this.meal(), id);
      return;
    }
    if (type === 'cuisine') {
      b.box(x0 + 0.3, 0, z0 === 10 ? z1 - 1.0 : z0 + 0.3, x1 - 0.3, 0.92, z0 === 10 ? z1 - 0.3 : z0 + 1.0, 0xd8dde2); solid(x0 + 0.3, z1 - 1.0, x1 - 0.3, z1 - 0.3, 0.95);   // plans de travail inox
      b.box(cx - 2.5, 0, cz - 0.7, cx + 2.5, 0.92, cz + 0.7, 0x2a2d33); b.box(cx - 2.5, 0.92, cz - 0.7, cx + 2.5, 0.97, cz + 0.7, 0xeeeeee); solid(cx - 2.5, cz - 0.7, cx + 2.5, cz + 0.7, 1);   // îlot central
      b.box(x1 - 1.4, 0, z0 + 0.4, x1 - 0.4, 2.1, z0 + 1.4, 0xd8dde2); solid(x1 - 1.4, z0 + 0.4, x1 - 0.4, z0 + 1.4, 2.1);                          // réfrigérateur américain
      for (let k = 0; k < 4; k++) b.box(x0 + 1 + k * 2.8, 1.5, z1 - 0.6, x0 + 3.4 + k * 2.8, 2.3, z1 - 0.3, 0xf2efe8);                          // placards hauts
      P(cx, cz - 1.5, 1.8, 'Cuisiner (cuisine professionnelle)', () => (this.kitchen ? this.kitchen.toggle(true) : null), id);
      P(x1 - 0.9, z0 + 2.2, 1.3, 'Ouvrir le réfrigérateur', () => (this.kitchen ? this.kitchen.toggle(true) : null), id);
      return;
    }
    if (type === 'bureau') {
      const [x, z] = at(0, d - 3); b.box(x - 1.4, 0.75, z - 0.6, x + 1.4, 0.82, z + 0.6, 0x3a2416); solid(x - 1.4, z - 0.6, x + 1.4, z + 0.6, 0.85);
      b.box(x - 0.4, 0.82, z + 0.2, x + 0.4, 1.3, z + 0.25, 0x111111); for (let k = 0; k < 3; k++) b.box(x0 + 0.2, 0, z0 + 1 + k * 2, x0 + 0.6, 2.4, z0 + 2.8 + k * 2, 0x5a3a22);
      P(x, z - 1.4, 1.6, 'Ouvrir NOVA Gestion (bureau personnel)', () => this.bizUI && this.bizUI.toggle(true), id);
      const [bx2, bz2] = at(-w / 2 + 1.9, 0.12); b.box(bx2 - 0.75, 1.25, bz2 - 0.04, bx2 + 0.75, 2.1, bz2 + 0.04, 0x111111); (this.screens ||= []).push({ id: 'bureau', name: 'TV du bureau du PDG', room: id, x: bx2, y: 1.675, z: bz2, nx: 0, nz: sgn, w: 1.45, h: 0.8 }); // écran d'information
      return;
    }
    if (type === 'cinema') {
      const [sx, sz] = at(0, 0.4); b.box(sx - 4.5, 0.6, sz - 0.05, sx + 4.5, 2.9, sz + 0.05, 0xf6f6f6);
      for (let r = 0; r < 3; r++) for (let k = 0; k < 5; k++) { const [x, z] = at(-4 + k * 2, 5 + r * 3); b.box(x - 0.6, 0.15 * r, z - 0.6, x + 0.6, 0.55 + 0.15 * r, z + 0.6, 0x6a1a2a); b.box(x - 0.6, 0.55 + 0.15 * r, z + sgn * 0.5, x + 0.6, 1.1 + 0.15 * r, z + sgn * 0.6, 0x6a1a2a); }
      this.cineScreen = { x: sx, z: sz, room: id }; (this.screens ||= []).push({ id: 'cinema', name: 'Écran de la salle de cinéma', room: id, x: sx, y: 1.75, z: sz, nx: 0, nz: sgn, w: 8.9, h: 2.2, far: true });
      P(...at(0, 6.5), 2, 'Regarder un film (salle de cinéma)', () => this.activity('Séance de cinéma', 2, { energy: 6 }, 'Film projeté sur grand écran (programme fictif) 🍿'), id);
      return;
    }
    if (type === 'sport') {
      for (let k = 0; k < 3; k++) { const [x, z] = at(-4 + k * 2.4, 2.5); b.box(x - 0.45, 0, z - 1, x + 0.45, 1.2, z + 1, 0x111111); solid(x - 0.45, z - 1, x + 0.45, z + 1, 1.2); }
      const [x, z] = at(2.5, 9); b.box(x - 1.2, 0, z - 0.4, x + 1.2, 2.2, z + 0.4, 0x8a8f96); b.box(x0 + 0.1, 0.4, z0 + 1, x0 + 0.15, 2.6, z1 - 1, 0xc8d8e0); // banc, miroir
      P(...at(-1.6, 4.4), 1.8, 'S’entraîner (tapis de course)', () => this.activity('Entraînement', 1, { energy: -12, hygiene: -15 }, 'Bonne séance : forme physique en hausse 💪'), id);
      P(x, z - sgn * 1.2, 1.5, 'Musculation', () => this.activity('Musculation', 1, { energy: -10, hygiene: -12 }, 'Séance de musculation terminée.'), id);
      return;
    }
    if (type === 'jeux') {
      const [x, z] = at(-2, 5); b.box(x - 1.3, 0.7, z - 0.7, x + 1.3, 0.85, z + 0.7, 0x0b6e4f); b.box(x - 1.3, 0, z - 0.7, x + 1.3, 0.7, z + 0.7, 0x4a2a16); solid(x - 1.3, z - 0.7, x + 1.3, z + 0.7, 0.85);  // billard
      const [fx, fz] = at(3, 10); b.box(fx - 0.6, 0, fz - 1, fx + 0.6, 0.9, fz + 1, 0x1f4e9c); solid(fx - 0.6, fz - 1, fx + 0.6, fz + 1, 0.9);                                  // baby-foot
      const [cx2, cz2] = at(4.5, 2); b.box(cx2 - 0.05, 1, cz2 - 0.8, cx2 + 0.05, 1.8, cz2 + 0.8, 0x111111); (this.screens ||= []).push({ id: 'jeux', name: 'TV de la salle de jeux', room: id, x: cx2, y: 1.4, z: cz2, nx: -1, nz: 0, w: 1.55, h: 0.76 });
      P(x, z - sgn * 1.3, 1.7, 'Jouer au billard', () => this.activity('Billard', 0.5, {}, 'Belle partie de billard 🎱'), id);
      P(fx - 1, fz, 1.4, 'Jouer au baby-foot', () => this.activity('Baby-foot', 0.3, {}, 'But ! ⚽'), id);
      P(cx2 - 1.2, cz2, 1.3, 'Jouer à la console', () => this.activity('Console', 0.5, { energy: 2 }, 'Partie de jeu vidéo (jeu fictif) 🎮'), id);
      return;
    }
    if (type === 'buanderie') {
      for (let k = 0; k < 3; k++) b.box(x0 + 0.5 + k * 1.1, 0, z1 - 1.2, x0 + 1.4 + k * 1.1, 0.95, z1 - 0.4, 0xf2f2f2);
      b.box(cx - 1, 0.85, cz - 0.3, cx + 1, 0.9, cz + 0.3, 0x8a8f96);
      P(x0 + 2.2, z1 - 2, 1.5, 'Lancer une lessive', () => this.activity('Lessive', 0.5, {}, 'Le linge tourne dans la machine 🧺'), id);
      P(cx, cz - 1, 1.3, 'Repasser des vêtements', () => this.activity('Repassage', 0.5, { energy: -3 }, 'Chemises impeccables pour la semaine.'), id);
      return;
    }
    if (type === 'sdb') {
      b.box(x0 + 0.4, 0, z0 + 0.4, x0 + 2.2, 0.6, z0 + 2.4, 0xf6f6f6); b.box(x1 - 1.5, 0, z0 + 0.3, x1 - 0.3, 2.2, z0 + 1.5, 0x9ab8c4); b.box(cx - 0.4, 0.8, z1 - 0.5, cx + 0.4, 0.9, z1 - 0.3, 0xf6f6f6);
      P(x0 + 1.3, z0 + 3, 1.5, 'Prendre un bain', () => this.activity('Bain', 0.6, { hygiene: 100, energy: 6 }, 'Bain relaxant 🛁'), id);
      P(x1 - 0.9, z0 + 2.4, 1.3, 'Prendre une douche', () => this.activity('Douche', 0.3, { hygiene: 100 }, 'Douche rafraîchissante.'), id);
      return;
    }
    if (type === 'personnel') {
      { const [px, pz] = at(w / 2 - 0.15, d / 2); b.box(px - 0.05, 1.1, pz - 0.6, px + 0.05, 1.75, pz + 0.6, 0x111111); (this.screens ||= []).push({ id: 'personnel', name: 'TV de l’espace du personnel', room: id, x: px, y: 1.425, z: pz, nx: -1, nz: 0, w: 1.15, h: 0.6 }); }
      b.box(cx - 1, 0.72, cz - 0.8, cx + 1, 0.78, cz + 0.8, 0xe8dcc4); for (let k = 0; k < 4; k++) b.box(x0 + 0.3, 0, z0 + 1 + k * 1.2, x0 + 0.9, 1.9, z0 + 2 + k * 1.2, 0x8a8f96);
      P(cx, cz - 1.4, 1.5, 'Espace du personnel (planning de la maison)', () => this.ui.toast('Espace du personnel : vestiaires, planning et pause. Le recrutement du personnel arrive à l’étape 3.', 3.5), id);
    }
  }
  themedLamp(T, bx, bz, sgn) { const l = new THREE.Mesh(new THREE.SphereGeometry(0.16, 10, 8), new THREE.MeshBasicMaterial({ color: 0xfff0c8, toneMapped: false })); l.position.set(bx + 1.5, 0.9, bz + sgn * 1.0); return l; }
  // ------------------------------------------------------------------ décoration personnalisable
  cycleDecor(id) {
    const R = this.rooms[id]; if (!R || !R.mats) return; const k = ((this.decor[id] || 0) + 1) % THEMES.length; this.decor[id] = k;
    R.mats.wallM.color.setHex(THEMES[k][1]); R.mats.bedM.color.setHex(THEMES[k][2]);
    this.ui.toast(`🎨 ${R.name} : décoration « ${THEMES[k][0]} »`, 2); this.onSave && this.onSave();
  }
  applyDecor() { for (const [id, k] of Object.entries(this.decor)) { const R = this.rooms[id]; if (R && R.mats) { R.mats.wallM.color.setHex(THEMES[k][1]); R.mats.bedM.color.setHex(THEMES[k][2]); } } }
  // ------------------------------------------------------------------ entrer / sortir de l'aile
  enter(roomId) {
    const { O, Y, LV } = VILLA, pl = this.player, R = roomId && this.rooms[roomId];
    this.inside = true; this.inGroup.visible = true; this.world.collision.level = LV; pl.floorY = Y; pl.vy = 0;
    const p = R ? R.door : { x: -34.5, z: 8 }; pl.pos.set(O.x + p.x, Y, O.z + p.z); pl.facing = R ? (R.z0 === 10 ? 0 : PI) : PI / 2; pl.mesh.position.copy(pl.pos);
    if (this.tpc && this.tpc.snap) this.tpc.snap(pl.pos); this.lightRig(true);
    this.ui.toast(R ? `🏛️ ${R.name}` : '🏛️ Aile principale de la VILLA NOVA : salon, salle à manger, cuisine, cinéma, sport, jeux, 9 chambres…', 3);
    if (this.audio && this.audio.ctx) this.audio.door();
  }
  exit(silent) {
    const pl = this.player; this.inside = false; this.inGroup.visible = false; this.world.collision.level = 0; pl.floorY = 0; pl.vy = 0;
    pl.pos.set(DOOR.x, 0, DOOR.z + 1.4); pl.facing = 0; pl.mesh.position.copy(pl.pos); if (this.tpc && this.tpc.snap) this.tpc.snap(pl.pos); this.lightRig(false);
    if (!silent) this.ui.toast('Tu es sur la terrasse de la villa.', 1.6); if (this.audio && this.audio.ctx) this.audio.door();
  }
  lightRig(on) { // les 3 lampes de la maison éclairent l'aile quand le joueur s'y trouve (pas de lumière ajoutée)
    const ls = this.home && this.home.lights; if (!ls) return; if (!this._orig) this._orig = ls.map((l) => ({ p: l.position.clone(), d: l.distance }));
    if (on) { const P = this.player.pos; this._follow = true; ls.forEach((l) => { l.distance = 18; l.decay = 1.1; }); this.followLights(P); }
    else if (this._follow) { this._follow = false; ls.forEach((l, i) => { l.position.copy(this._orig[i].p); l.distance = this._orig[i].d; l.decay = 1.6; l.intensity = 0; l.color.setHex(0xffe8c8); }); }
  }
  followLights(P) { const ls = this.home.lights, { Y } = VILLA; ls.forEach((l, i) => { l.position.set(P.x - 6 + i * 6, Y + 3.0, P.z + (i === 1 ? 4 : -2)); l.intensity = 10 * Math.min(1, 0.4 + this.env.lightsOn); }); if (this.ambiance) this.ambiance.light(P, ls, 10 * Math.min(1, 0.4 + this.env.lightsOn)); }
  // ------------------------------------------------------------------ activités
  activity(label, hours, eff, msg) {
    if (this.act) return; this.act = { label, t: 0, hours, eff, msg }; this.ui.fade && this.ui.fade(true);
  }
  sleepMenu(name) { const toMorning = ((7 - this.env.time) + 24) % 24 || 24; this.ui.openMenu(`🛏️ ${name}`, 'Repos', [{ label: 'Faire une sieste (2 h)', desc: 'Énergie +30', action: () => this.activity('Sieste', 2, { energy: 30 }, 'Sieste réparatrice.') }, { label: `Dormir jusqu’à 7 h (${toMorning.toFixed(1)} h)`, desc: 'Énergie au maximum', action: () => this.activity('Nuit', toMorning, { energy: 100, set: true }, 'Bonjour ! Belle nuit dans la villa.') }]); }
  meal() { if (this.cook) return this.cook.eat(); this.ui.toast('🍽️ La salle à manger familiale est prête. Le cuisinier personnel (étape 2) servira petit-déjeuner, déjeuner et dîner ; en attendant, la cuisine professionnelle est à ta disposition.', 4); }
  swim() { if (this.act) return; if (this.staff && this.staff.state.piscine < 25) this.ui.toast('L’eau est un peu trouble : demande au jardinier de nettoyer la piscine.', 3); this.act = { label: 'Baignade', t: 0, hours: 0.5, eff: { hygiene: 30, energy: -8 }, msg: 'Quelques longueurs dans la piscine 🏊', swim: true }; }
  finishAct() {
    const a = this.act, n = this.needs, e = a.eff;
    this.env.time = (this.env.time + a.hours) % 24;
    if (n) { if (e.energy) n.energy = e.set ? 100 : Math.max(0, Math.min(100, n.energy + e.energy)); if (e.hygiene) n.hygiene = e.hygiene >= 100 ? 100 : Math.max(0, Math.min(100, n.hygiene + e.hygiene)); if (a.hours >= 1) n.hunger = Math.max(0, n.hunger - a.hours * 1.5); }
    this.ui.fade && this.ui.fade(false); this.ui.toast(`${a.msg} (${this.env.clock})`, 3); this.act = null;
    if (a.swim) { const pl = this.player; pl.pos.set(POOL.x0 - 1.2, 0, (POOL.z0 + POOL.z1) / 2); pl.mesh.visible = true; pl.mesh.position.copy(pl.pos); pl.mesh.rotation.set(0, 0, 0); }
    this.onSave && this.onSave();
  }
  // ------------------------------------------------------------------ interactions
  nearest(x, z) {
    if (this.inside) {
      const { O } = VILLA; let best = null;
      for (const p of this.points) { const d = Math.hypot(x - (O.x + p.x), z - (O.z + p.z)); if (d < p.r && (!best || d < best.d)) best = { d, it: { label: () => p.label, action: p.action } }; }
      const ck = this.cook && this.cook.nearest(x, z); if (ck && (!best || ck.d - 0.3 < best.d)) return ck;
      if (this.deco && this.deco.placing) return null;
      const dc = this.deco && this.deco.nearest(x, z); if (dc && (!best || dc.d < best.d)) best = dc;
      const fu = this.furniture && this.furniture.nearest(x, z); if (fu && (!best || fu.d < best.d)) best = fu;
      const sw = this.ambiance && this.ambiance.nearest(x, z); if (sw && (!best || sw.d < best.d)) best = sw;
      const tv = this.tv && this.tv.nearest(x, z); if (tv && (!best || tv.d - 0.2 < best.d)) best = tv;
      const fm = this.family && this.family.nearest(x, z); if (fm && (!best || fm.d - 0.3 < best.d)) return fm;
      const sf = this.staff && this.staff.nearest(x, z); if (sf && (!best || sf.d - 0.3 < best.d)) return sf;
      return best;
    }
    const dd = Math.hypot(x - DOOR.x, z - (DOOR.z + 0.9)); if (dd < 1.8) return { d: dd, it: { label: () => 'Entrer dans l’aile principale de la villa', action: () => this.enter() } };
    const P = POOL; const px = Math.max(P.x0, Math.min(P.x1, x)), pz = Math.max(P.z0, Math.min(P.z1, z)), dp = Math.hypot(x - px, z - pz);
    if (dp < 1.3) return { d: dp + 0.3, it: { label: () => 'Se baigner dans la piscine', action: () => this.swim() } };
    return null;
  }
  // ------------------------------------------------------------------ boucle
  update(dt) {
    const pl = this.player, P = pl.pos, t = performance.now() / 1000;
    // eau de la piscine : légère ondulation (seulement à proximité)
    if (Math.hypot(P.x - (POOL.x0 + POOL.x1) / 2, P.z - (POOL.z0 + POOL.z1) / 2) < 70) { this.water.material.emissiveIntensity = (this.poolLights && this.env.lightsOn > 0.3 ? 0.9 : 0.25) + Math.sin(t * 2) * 0.05; this.water.position.y = 0.36 + Math.sin(t * 1.3) * 0.01; }
    const night = this.env.lightsOn > 0.3; for (const l of this.lanterns.concat(this.bollards)) l.visible = night;
    // portail et portillon automatiques (ouverture à l'approche, fermeture après passage)
    const H = this.home;
    if (this.autoGate && H && H.pedGate && !this.inside) {
      const foot = !pl.inCar, dPed = Math.hypot(P.x + 44.5, P.z - 110), car = pl.inCar && pl.inCar.pos, dCar = car ? Math.hypot(car.x + 32, car.z - 110) : 99;
      if (foot && dPed < 3.2 && H.pedGate.target < 0.5) { H.pedGate.toggle(); this._pedAuto = true; }
      else if (this._pedAuto && dPed > 6 && H.pedGate.target > 0.5) { H.pedGate.toggle(); this._pedAuto = false; }
      if (dCar < 9 && H.carGate.target < 0.5) { H.carGate.toggle(); this._carAuto = true; }
      else if (this._carAuto && dCar > 14 && Math.hypot(P.x + 32, P.z - 110) > 14 && H.carGate.target > 0.5) { H.carGate.toggle(); this._carAuto = false; }
    }
    if (this.inside) {
      this.followLights(P); if (this.luxe) this.luxe.update(this.env.time);
      if (Math.abs((P.y || VILLA.Y) - VILLA.Y) > 6 || Math.hypot(P.x - VILLA.O.x, P.z - VILLA.O.z) > 60) { this.inside = false; this.inGroup.visible = false; this.world.collision.level = 0; pl.floorY = 0; this.lightRig(false); } // sortie par un autre moyen
    }
    if (this.act) {
      const a = this.act; a.t += dt;
      if (a.swim) { const k = (a.t * 0.25) % 2, zz = POOL.z0 + 0.8 + (k < 1 ? k : 2 - k) * (POOL.z1 - POOL.z0 - 1.6); pl.mesh.visible = true; pl.mesh.position.set((POOL.x0 + POOL.x1) / 2, -0.2, zz); pl.mesh.rotation.set(-1.2, k < 1 ? 0 : PI, 0, 'YXZ'); pl.pos.set((POOL.x0 + POOL.x1) / 2, 0, zz); if (pl.char && pl.char.animate) pl.char.animate(dt, 1.4); if (a.t > 8) this.finishAct(); }
      else if (a.t > 2.2) this.finishAct();
    }
  }
  get busy() { return !!this.act; }
  // ------------------------------------------------------------------ application « Ma Villa »
  renderApp(b) {
    const groups = [['Pièces de vie', ['salon', 'manger', 'cuisine', 'bureau', 'cinema', 'sport', 'jeux', 'buanderie', 'sdb', 'personnel']], ['Chambres (9, chacune avec salle de bain privée)', ['suite', 'enf1', 'enf2', 'enf3', 'inv1', 'inv2', 'inv3', 'inv4', 'ch_perso']]];
    b.innerHTML = `<h4>🏛️ Ma Villa — VILLA NOVA</h4><p class="ph-note">Maison d’origine conservée + aile principale (porte au dos de la maison) + piscine, terrasse, jardin, abri 2 véhicules. Garage : 4 places (maison, limousine, abri).</p>
      <div class="ph-chips"><button data-ph="lum">💡 Éclairage et ambiance</button><button data-ph="deco">🛋️ Décoration intérieure</button><button data-ph="tv">📺 NOVA TV</button><button data-vl="gate" class="${this.autoGate ? 'on' : ''}">🚪 Portail automatique : ${this.autoGate ? 'oui' : 'non'}</button><button data-vl="pool" class="${this.poolLights ? 'on' : ''}">💡 Éclairage piscine : ${this.poolLights ? 'oui' : 'non'}</button></div>
      ${groups.map(([t, ids]) => `<h5>${t}</h5><div class="ph-list">${ids.map((id) => { const R = this.rooms[id]; return `<div class="ph-row"><span><b>${R.name}</b><small>${R.mats ? `Décoration : ${THEMES[this.decor[id] || 0][0]}` : 'Pièce équipée'}${this.family && this.family.roomOwner(id) ? ` • chambre de ${this.family.roomOwner(id)}` : ''}</small></span><span class="pp-acts">${R.mats ? `<button class="ph-mini" data-vl="deco:${id}">🎨</button>` : ''}<button class="ph-mini" data-vl="go:${id}">Y aller</button></span></div>`; }).join('')}</div>`).join('')}
      ${this.peopleBlock()}`;
  }
  peopleBlock() { // gestion de la résidence : personnel et famille (raccourcis vers les applications dédiées)
    const st = this.staff, ck = this.cook, fm = this.family, clean = st ? Math.round(Object.values(st.state).reduce((a, b) => a + b, 0) / Object.keys(st.state).length) : null;
    return `<h5>Personnel de la résidence</h5><div class="ph-list">
      <div class="ph-row"><span><b>👩🏿‍🍳 Cuisinier personnel</b><small>${ck && ck.hired ? `${ck.hired.name} • salaire ${ck.hired.salary.toLocaleString('fr-FR')} FCFA / 7 jours` : 'Non recruté'}</small></span><button class="ph-mini" data-ph="chef">Ouvrir</button></div>
      <div class="ph-row"><span><b>🏠 Personnel domestique</b><small>${st ? `${st.team.length} employé(s) • état de la maison ${clean} %` : '—'}</small></span><button class="ph-mini" data-ph="dom">Ouvrir</button></div>
      <div class="ph-row"><span><b>🛡️ Sécurité et 🚘 chauffeur</b><small>Gardes du corps, limousine, chauffeur personnel</small></span><button class="ph-mini" data-ph="secu">Ouvrir</button></div></div>
      <h5>Famille</h5><div class="ph-list"><div class="ph-row"><span><b>👨‍👩‍👧 Vie familiale</b><small>${fm && fm.children.length ? fm.children.map((c) => `${c.first} (${c.age} ans, ${this.rooms[c.room].name.toLowerCase()})`).join(', ') : 'Aucun enfant à la maison'}${fm && fm.poolFence ? ' • piscine sécurisée' : ''}</small></span><button class="ph-mini" data-ph="fam">Ouvrir</button></div>
      <div class="ph-row"><span><b>🎒 Vie scolaire</b><small>Écoles, inscription, bulletins</small></span><button class="ph-mini" data-ph="ecole">Ouvrir</button></div></div>`;
  }
  onPhone(v) {
    const [a, id] = v.split(':');
    if (a === 'gate') this.autoGate = !this.autoGate;
    else if (a === 'pool') this.poolLights = !this.poolLights;
    else if (a === 'deco') this.cycleDecor(id);
    else if (a === 'go') { const P = this.player.pos; if (this.inside || Math.hypot(P.x + 44, P.z - 126) < 40) { this.economy.togglePhone(false); return this.enter(id); } return this.ui.toast('Rends-toi d’abord à ta résidence (la limousine peut t’y conduire).', 2.5); }
    this.onSave && this.onSave(); this.economy.renderPhone();
  }
  serialize() { return { decor: this.decor, autoGate: this.autoGate, poolLights: this.poolLights }; }
  restore(s) { if (!s) return; this.decor = s.decor || {}; this.autoGate = s.autoGate !== false; this.poolLights = s.poolLights !== false; this.applyDecor(); }
}
