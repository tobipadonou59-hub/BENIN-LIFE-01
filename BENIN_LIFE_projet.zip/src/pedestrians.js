// Piétons pilotés par l'IA du jeu :
//  - promeneurs qui suivent les trottoirs, s'arrêtent devant les boutiques et traversent aux passages piétons
//    (attente que la voie soit libre / que les voitures aient le feu rouge) ;
//  - personnes assises (arrêts de bus, bancs, grillades), vendeuses du marché, zémidjans en attente.
// Optimisation : animation pleine cadence près du joueur, réduite au loin, coupée hors de vue.
import * as THREE from 'three';
import { createCharacter, SKINS } from './character.js';
import { createMotoMesh } from './vehicles.js';
import { mulberry32 } from './util.js';
import { VENDORS, vendorSpots } from './market-data.js';

const GOODS = [0xe8a020, 0xd23a2a, 0x3a9a3a, 0xf0e0b0];
const BASINS = [0x2a7ad0, 0xc8202a, 0xe8e8e8, 0x2aa060];
const PANTS = [0x2a2f3a, 0x5a4a3a, 0x1f3a5a, 0x3a3a3a, 0x6a6a5a];

// position sur le contour d'un îlot (rectangle) à l'abscisse curviligne s
function perim(b) { return 2 * (b.x1 - b.x0) + 2 * (b.z1 - b.z0); }
function atS(b, s, out) {
  const w = b.x1 - b.x0, d = b.z1 - b.z0, L = 2 * w + 2 * d;
  s = ((s % L) + L) % L;
  if (s < w) { out.x = b.x0 + s; out.z = b.z0; out.dx = 1; out.dz = 0; }
  else if (s < w + d) { out.x = b.x1; out.z = b.z0 + (s - w); out.dx = 0; out.dz = 1; }
  else if (s < 2 * w + d) { out.x = b.x1 - (s - w - d); out.z = b.z1; out.dx = -1; out.dz = 0; }
  else { out.x = b.x0; out.z = b.z1 - (s - 2 * w - d); out.dx = 0; out.dz = -1; }
  return out;
}
function project(b, x, z) {
  const w = b.x1 - b.x0, d = b.z1 - b.z0;
  const c = [[Math.abs(z - b.z0), x - b.x0], [Math.abs(x - b.x1), w + (z - b.z0)], [Math.abs(z - b.z1), w + d + (b.x1 - x)], [Math.abs(x - b.x0), 2 * w + d + (b.z1 - z)]];
  c.sort((p, q) => p[0] - q[0]);
  return c[0][1];
}

// ---- mission 015 : profils d'habitants ----
const KAKI = 0xb8a070;
export const PROFILES = [
  { id: 'adulte', label: 'Habitant', w: 30, phone: 0.3 },
  { id: 'jeune', label: 'Jeune', w: 14, speed: 1.12, phone: 0.6, look: (R) => ({ shirtColor: [0xf2f2f2, 0x1a1a1a, 0xc8102e, 0x2f80ed, 0x2fa04a][Math.floor(R() * 5)], pants: 0x2a3a5a }) },
  { id: 'age', label: 'Personne âgée', w: 9, speed: 0.68, look: (R, f) => (f ? { headwrap: true } : { robe: true }) },
  { id: 'eleve', label: 'Élève', w: 9, speed: 1.05, look: () => ({ shirtColor: KAKI, pants: KAKI }) },
  { id: 'etudiant', label: 'Étudiant', w: 8, phone: 0.5, look: (R) => ({ shirtColor: [0xe8e2d6, 0x1f4e9c, 0x7a2a8a][Math.floor(R() * 3)], pants: 0x22252a }) },
  { id: 'bureau', label: 'Employé de bureau', w: 10, phone: 0.4, look: (R) => ({ shirtColor: [0xf6f6f6, 0xc8dcf0, 0xe8e8f0][Math.floor(R() * 3)], pants: 0x1a1d24 }) },
  { id: 'commercante', label: 'Commerçante', w: 9, female: true },
  { id: 'travailleur', label: 'Travailleur', w: 6, look: () => ({ shirtColor: 0xe46a1f, pants: 0x2a2f3a }) },
  { id: 'parent', label: 'Parent et enfant', w: 5 },
];
function pickProfile(R) { const tot = PROFILES.reduce((a, p) => a + p.w, 0); let r = R() * tot; for (const p of PROFILES) { r -= p.w; if (r <= 0) return p; } return PROFILES[0]; }
function addAccessory(c, id) {
  const b = c.bones; if (!b) return;
  const mat = (col) => new THREE.MeshStandardMaterial({ color: col, roughness: 0.8 });
  if (id === 'eleve' || id === 'etudiant') { const bp = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.36, 0.14), mat(id === 'eleve' ? 0x1f4e9c : 0x2a2a2a)); bp.position.set(0, 0.0, -0.17); b.chest.add(bp); }
  if (id === 'bureau') { const bc = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.26, 0.36), mat(0x2a1a10)); bc.position.set(0, -0.3, 0); b.foreR.add(bc); }
  if (id === 'age') { const cane = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.9, 6), mat(0x6a4a2a)); cane.position.set(0, -0.45, 0.05); b.foreR.add(cane); }
}

export class Pedestrians {
  constructor(scene, world, count = 44) {
    const R = this.R = mulberry32(77);
    this.world = world;
    const blocks = world.blocks.filter((b) => b.x1 > -165 && b.x0 < 165 && b.z1 > -165 && b.z0 < 160);
    this.blocks = blocks;
    // passages piétons rattachés aux îlots qu'ils relient
    const inside = (b, p) => p[0] >= b.x0 - 0.3 && p[0] <= b.x1 + 0.3 && p[1] >= b.z0 - 0.3 && p[1] <= b.z1 + 0.3;
    this.crossings = [];
    for (const cw of world.crosswalks) {
      const ba = blocks.find((b) => inside(b, cw.a)), bb = blocks.find((b) => inside(b, cw.b));
      if (ba && bb && ba !== bb) {
        this.crossings.push({ from: ba, to: bb, a: cw.a, b: cw.b, cw }, { from: bb, to: ba, a: cw.b, b: cw.a, cw });
      }
    }
    for (const b of blocks) b.cross = this.crossings.filter((c) => c.from === b);
    const make = (opts) => createCharacter({
      pagne: Math.floor(R() * 6), skin: SKINS[Math.floor(R() * SKINS.length)], pants: PANTS[Math.floor(R() * PANTS.length)],
      carryColor: BASINS[Math.floor(R() * BASINS.length)], goodsColor: GOODS[Math.floor(R() * GOODS.length)], ...opts,
    });
    this.list = [];
    // mission 015 : profils d'habitants (tenues, accessoires, allure) ; certains sont accompagnés d'un enfant
    this.scene = scene;
    for (let i = 0; i < count; i++) {
      const b = blocks[Math.floor(R() * blocks.length)];
      const prof = pickProfile(R);
      const female = prof.female ?? R() < 0.5, carry = prof.id === 'commercante';
      const c = make({ female, carry, ...(prof.look ? prof.look(R, female) : {}) });
      scene.add(c.group);
      const p = { c, b, prof, s: R() * perim(b), dir: R() < 0.5 ? 1 : -1, speed: (carry ? 1.0 + R() * 0.3 : 1.1 + R() * 0.55) * (prof.speed || 1), state: 'walk', t: 0, cool: R() * 10, x: 0, z: 0, h: 0, acc: 0, active: true, phone: prof.phone ? R() < prof.phone : false };
      addAccessory(c, prof.id);
      if (prof.id === 'parent') { const k = createCharacter({ female: R() < 0.5, skin: SKINS[Math.floor(R() * SKINS.length)], shirtColor: [0xf2c200, 0xc8102e, 0x2f80ed, 0x2fa04a][Math.floor(R() * 4)], pants: 0x2a2f3a, shorts: true }); k.group.scale.setScalar(0.62); scene.add(k.group); p.child = k; p.speed = Math.min(p.speed, 1.1); }
      this.list.push(p);
    }
    // personnes immobiles : assises, en groupe, vendeuses, zémidjans
    this.idle = [];
    const addIdle = (c, x, y, z, ry) => { c.group.position.set(x, y, z); c.group.rotation.y = ry; scene.add(c.group); this.idle.push({ c, x, z, acc: 0 }); };
    for (const st of world.seats) if (R() < 0.75) { const c = make({ female: R() < 0.5 }); c.sit(false); addIdle(c, st.x, st.y, st.z, st.ry); }
    for (const sp of world.shopFronts.filter((_, i) => i % 4 === 0).slice(0, 8)) {
      const n = 2 + Math.floor(R() * 2);
      for (let k = 0; k < n; k++) {
        const a = (k / n) * Math.PI * 2 + R() * 0.4, x = sp.x + Math.cos(a) * 0.65, z = sp.z + Math.sin(a) * 0.65;
        addIdle(make({ female: R() < 0.5 }), x, 0, z, Math.atan2(sp.x - x, sp.z - z));
      }
    }
    for (const sp of world.plazaSpots || []) {
      for (let k = 0; k < 2 + Math.floor(R() * 2); k++) {
        const x = sp.x + (R() - 0.5) * 1.6, z = sp.z + (R() - 0.5) * 1.2;
        const tg = sp.target || [world.amazone.x, world.amazone.z];
        addIdle(make({ female: R() < 0.5 }), x, 0, z, Math.atan2(tg[0] - x, tg[1] - z));
      }
    }
    for (const sp of world.idleSpots || []) addIdle(make({ female: sp.carry || R() < 0.5, carry: !!sp.carry }), sp.x, 0, sp.z, sp.ry);
    // vendeuses et vendeurs des 60 étals de Dantokpa (même sexe que sur leur étiquette), affichés de près seulement
    this.vendorIdle = [];
    vendorSpots(world).forEach((sp, i) => { addIdle(make({ female: VENDORS[i] ? VENDORS[i].female : R() < 0.7 }), sp.x, 0, sp.z, sp.ry); const q = this.idle[this.idle.length - 1]; q.vis = 42; q.vendor = true; q.ry0 = sp.ry; q.gt = R() * 6; q.sale = 0; this.vendorIdle[i] = q; });
    // zémidjans garés avec leurs conducteurs qui attendent les clients
    this.zems = [];
    world.zemSpots.forEach((z, i) => {
      const m = createMotoMesh(4000 + i, { passenger: false });
      m.group.position.set(z.x, 0, z.z); m.group.rotation.set(0, z.h + (i % 2 ? 0.08 : -0.08), 0.1);
      scene.add(m.group); this.zems.push(m.group);
    });
    this.crossingPeds = [];
    // devantures (portes des boutiques) atteignables depuis le trottoir
    this.fronts = (world.shopFronts || []).filter((f) => blocks.some((b) => f.x > b.x0 - 2.5 && f.x < b.x1 + 2.5 && f.z > b.z0 - 2.5 && f.z < b.z1 + 2.5));
    this._o = { x: 0, z: 0, dx: 0, dz: 0 };
  }

  obstacles() {
    const out = [];
    for (const p of this.idle) out.push({ x: p.x, z: p.z, r: 0.3 });
    return out;
  }

  // piétons sur la chaussée : les véhicules doivent s'arrêter
  blockers() { return this.crossingPeds; }

  roadClear(cr, traffic, lights) {
    const cx = cr.cw.cx, cz = cr.cw.cz;
    for (const v of traffic.vehicles) {
      const dx = cx - v.x, dz = cz - v.z, d2 = dx * dx + dz * dz;
      if (d2 > 22 * 22) continue;
      const toward = (dx * v.fx + dz * v.fz) / Math.sqrt(d2 || 1);
      if (d2 < 6 * 6 || (toward > 0.3 && v.speed > 0.5)) return false;
    }
    if (this.playerCar) { const c = this.playerCar; if ((c.pos.x - cx) ** 2 + (c.pos.z - cz) ** 2 < 15 * 15 && Math.abs(c.speed) > 1) return false; }
    // aux carrefours à feux : on traverse quand les voitures de la rue traversée ont le rouge
    if (lights) for (const it of lights.list) if (Math.abs(it.x - cx) < 12 && Math.abs(it.z - cz) < 12) {
      const axis = cr.cw.alongX ? 'ns' : 'ew'; // on coupe une rue verticale => ce sont les véhicules « ns » qui doivent être au rouge
      if (lights.state(it, axis) !== 'red') return false;
    }
    return true;
  }

  update(dt, player, traffic, lights, playerCar = null) {
    this.playerCar = playerCar;
    const o = this._o;
    this.crossingPeds.length = 0;
    for (const p of this.list) {
      if (!p.active) { p.c.group.visible = false; if (p.child) p.child.group.visible = false; continue; }
      const d2 = (player.x - p.x) ** 2 + (player.z - p.z) ** 2;
      const far = d2 > 110 * 110;
      let v = 0;
      p.t += dt; p.cool -= dt;
      if (p.state === 'walk') {
        const nearPlayer = d2 < 1.4;
        v = nearPlayer ? 0 : p.speed;
        p.s += v * dt * p.dir;
        atS(p.b, p.s, o);
        // les coins d'îlot situés sous le rond-point ne sont pas des trottoirs : demi-tour
        if (o.x * o.x + o.z * o.z < 24 * 24) {
          const f = atS(p.b, p.s + 0.5 * p.dir, { x: 0, z: 0 }), bk = atS(p.b, p.s - 0.5 * p.dir, { x: 0, z: 0 });
          if (bk.x * bk.x + bk.z * bk.z > f.x * f.x + f.z * f.z) p.dir = -p.dir; // repart dans le sens qui s'éloigne du rond-point
          p.s += Math.max(v, 1) * dt * p.dir; atS(p.b, p.s, o);
        }
        p.x = o.x; p.z = o.z; p.h = Math.atan2(o.dx * p.dir, o.dz * p.dir);
        // envie de traverser au prochain passage piéton
        if (p.cool <= 0) for (const cr of p.b.cross) {
          if ((cr.a[0] - p.x) ** 2 + (cr.a[1] - p.z) ** 2 < 0.5) {
            if (this.R() < 0.55) { p.state = 'wait'; p.cr = cr; p.t = 0; p.x = cr.a[0]; p.z = cr.a[1]; p.h = Math.atan2(cr.b[0] - cr.a[0], cr.b[1] - cr.a[1]); }
            p.cool = 6; break;
          }
        }
        // petite pause devant une vitrine
        if (p.state === 'walk' && p.cool <= 0 && this.R() < dt * 0.04) { p.state = 'browse'; p.t = 0; p.dur = 2 + this.R() * 4; p.h += p.dir * Math.PI / 2 * (this.R() < 0.5 ? 1 : -1); p.cool = 8; }
        // entrer dans une boutique ou un bâtiment (disparaît à l'intérieur quelques secondes)
        if (p.state === 'walk' && p.cool <= 0 && !p.child && this.R() < dt * 0.35) for (const f of this.fronts) {
          if ((f.x - p.x) ** 2 + (f.z - p.z) ** 2 < 2.2) { p.state = 'inside'; p.t = 0; p.dur = 6 + this.R() * 14; p.cool = 20; this.enterCount = (this.enterCount || 0) + 1; break; }
        }
        // téléphone : appels pendant la marche
        if (p.phone && this.R() < dt * 0.02) p.onCall = p.onCall ? 0 : 6 + this.R() * 10;
      } else if (p.state === 'inside') {
        v = 0; if (p.t > p.dur) { p.state = 'walk'; p.dir = this.R() < 0.5 ? 1 : -1; }
      } else if (p.state === 'chat' || p.state === 'talk') {
        v = 0; if (p.state === 'chat' && p.t > p.dur) { p.state = 'walk'; p.cool = 15; if (this.R() < 0.5) p.dir = -p.dir; }
        if (p.face) p.h = Math.atan2(p.face.x - p.x, p.face.z - p.z);
      } else if (p.state === 'browse') {
        if (p.t > p.dur) { p.state = 'walk'; if (this.R() < 0.3) p.dir = -p.dir; }
      } else if (p.state === 'wait') {
        if (p.t > 0.8 && this.roadClear(p.cr, traffic, lights)) { p.state = 'cross'; p.t = 0; }
        else if (p.t > 25) { p.state = 'walk'; p.cool = 10; } // abandonne et continue sur le trottoir
      } else if (p.state === 'cross') {
        const cr = p.cr, L = Math.hypot(cr.b[0] - cr.a[0], cr.b[1] - cr.a[1]);
        v = Math.max(1.35, p.speed * 1.2);
        const k = Math.min(1, (p.t * v) / L);
        p.x = cr.a[0] + (cr.b[0] - cr.a[0]) * k; p.z = cr.a[1] + (cr.b[1] - cr.a[1]) * k;
        this.crossingPeds.push({ x: p.x, z: p.z, r: 0.6, ped: true });
        if (k >= 1) { p.state = 'walk'; p.b = cr.to; p.s = project(p.b, cr.b[0], cr.b[1]); p.dir = this.R() < 0.5 ? 1 : -1; p.cool = 12; }
      }
      if (p.onCall > 0) p.onCall -= dt;
      const hidden = p.state === 'inside';
      p.c.group.visible = !far && !hidden;
      if (p.child) p.child.group.visible = !far && !hidden;
      if (far || hidden) continue;
      if (p.px || p.pz) { const k = Math.exp(-1.2 * dt); p.px = (p.px || 0) * k; p.pz = (p.pz || 0) * k; if (Math.abs(p.px) + Math.abs(p.pz) < 0.01) p.px = p.pz = 0; }
      p.c.group.position.set(p.x + (p.px || 0), 0, p.z + (p.pz || 0));
      p.c.group.rotation.y = p.h;
      // animation : pleine cadence < 35 m, une image sur trois au-delà
      p.acc += dt;
      if (d2 < 35 * 35 || (p.frame = (p.frame || 0) + 1) % 3 === 0) {
        p.c.animate(p.acc, v); const bn = p.c.bones;
        if (bn) {
          if (p.prof.id === 'age') { bn.spine.rotation.x += 0.18; bn.foreR.rotation.x = -0.5; }
          if (p.onCall > 0 || p.state === 'talk') { if (p.onCall > 0) { bn.armR.rotation.x = -0.4; bn.armR.rotation.z = -1.0; bn.foreR.rotation.x = -2.3; } }
          if (p.state === 'chat' || p.state === 'talk') { const g = Math.sin(p.t * 3 + p.s); bn.armL.rotation.x = -0.5 + g * 0.3; bn.foreL.rotation.x = -0.9; bn.head.rotation.x = Math.sin(p.t * 2) * 0.08; }
        }
        if (p.child) {
          const rx = Math.cos(p.h) * 0.75, rz = -Math.sin(p.h) * 0.75;
          p.child.group.position.set(p.x + rx + (p.px || 0), 0, p.z + rz + (p.pz || 0)); p.child.group.rotation.y = p.h;
          p.child.animate(p.acc || 0.016, v * 1.4); const cb = p.child.bones; if (cb) { cb.armL.rotation.z = 0.9; cb.armL.rotation.x = -0.2; }
        }
        p.acc = 0;
      }
    }
    // conversations : deux passants qui se croisent s'arrêtent parfois pour discuter
    this._chatT = (this._chatT || 0) - dt;
    if (this._chatT <= 0) {
      this._chatT = 0.5;
      const L = this.list;
      for (let i = 0; i < L.length; i++) { const a = L[i]; if (!a.active || a.state !== 'walk' || a.cool > 0 || a.child) continue;
        for (let j = i + 1; j < L.length; j++) { const b = L[j]; if (!b.active || b.state !== 'walk' || b.cool > 0 || b.child || b.b !== a.b) continue;
          if ((a.x - b.x) ** 2 + (a.z - b.z) ** 2 < 1.8 && this.R() < 0.35) { const dur = 6 + this.R() * 8; for (const [m, o] of [[a, b], [b, a]]) { m.state = 'chat'; m.t = 0; m.dur = dur; m.face = o; } break; }
          if ((a.x - b.x) ** 2 + (a.z - b.z) ** 2 < 1.8) { a.cool = 4; b.cool = 4; }
        } }
    }
    for (const p of this.idle) {
      const d2 = (player.x - p.x) ** 2 + (player.z - p.z) ** 2;
      const far = d2 > (p.vis || 90) ** 2;
      p.c.group.visible = !far && !p.away;
      if (far) continue;
      p.acc += dt;
      if (d2 < 30 * 30 || (p.frame = (p.frame || 0) + 1) % 4 === 0) { const st = p.acc; p.c.animate(p.acc, 0); p.acc = 0; if (p.vendor) this.vendorGesture(p, st, player, d2); }
    }
    for (const z of this.zems) z.visible = (player.x - z.position.x) ** 2 + (player.z - z.position.z) ** 2 < 120 * 120;
  }

  // mission 016 : animation de vente des marchands de Dantokpa (appel des passants, accueil du joueur, rangement, remise de l'article)
  vendorGesture(p, dt, player, d2) {
    const b = p.c.bones; if (!b) return;
    p.gt += dt; p.sale = Math.max(0, p.sale - dt);
    const near = d2 < 16, want = near ? Math.atan2(player.x - p.x, player.z - p.z) : p.ry0;
    let r = p.c.group.rotation.y, dd = ((want - r + Math.PI * 3) % (Math.PI * 2)) - Math.PI; p.c.group.rotation.y = r + dd * Math.min(1, dt * 4);
    const cyc = p.gt % 9;
    if (p.sale > 0) { const k = Math.sin(Math.min(1, (1.6 - p.sale) / 0.4) * Math.PI / 2); b.armR.rotation.x = -1.3 * k; b.foreR.rotation.x = -0.2 * k; b.head.rotation.x = 0.15 * k; } // tend l'article au client
    else if (near && cyc < 2.2) { const w = Math.sin(p.gt * 9); b.armR.rotation.x = -2.6; b.armR.rotation.z = -0.25 + w * 0.25; b.foreR.rotation.x = -0.4; } // salue le joueur
    else if (!near && d2 < 400 && cyc < 1.6) { b.armR.rotation.x = -2.0 + Math.sin(p.gt * 6) * 0.25; b.foreR.rotation.x = -0.6; b.head.rotation.y = Math.sin(p.gt * 1.5) * 0.4; } // appelle les passants
    else if (cyc > 5 && cyc < 7) { const k = Math.sin((cyc - 5) / 2 * Math.PI); b.spine.rotation.x = 0.35 * k; b.armL.rotation.x = b.armR.rotation.x = -0.9 * k; b.foreL.rotation.x = b.foreR.rotation.x = -0.5 * k; b.head.rotation.x = 0.3 * k; } // range ses marchandises
  }
  vendorSale(i) { const p = this.vendorIdle && this.vendorIdle[i]; if (p) p.sale = 1.6; }
  // voyageur qui attend à un arrêt (debout ou assis sur le banc)
  addWaiting(x, z, ry, seated) {
    const c = createCharacter({ female: this.R() < 0.5, skin: SKINS[Math.floor(this.R() * SKINS.length)], pagne: Math.floor(this.R() * 6), pants: PANTS[Math.floor(this.R() * PANTS.length)] });
    if (seated) c.sit(false);
    c.group.position.set(x, seated ? -0.48 : 0, z); c.group.rotation.y = ry; this.scene.add(c.group);
    const p = { c, x, z, acc: 0 }; this.idle.push(p); return p;
  }
  // ---- mission 015 : pooling — nombre de promeneurs actifs selon l'heure et la densité ----
  setDensity(target, P) {
    const L = this.list, act = L.filter((p) => p.active), d2 = (p) => (p.x - P.x) ** 2 + (p.z - P.z) ** 2;
    if (act.length > target) {
      for (const p of act.filter((q) => d2(q) > 55 * 55 && q.state !== 'talk').sort((a, b) => d2(b) - d2(a)).slice(0, act.length - target)) { p.active = false; p.c.group.visible = false; if (p.child) p.child.group.visible = false; }
    } else if (act.length < target) {
      for (const p of L.filter((q) => !q.active).slice(0, target - act.length)) {
        for (let k = 0; k < 10; k++) {
          const b = this.blocks[Math.floor(this.R() * this.blocks.length)], s = this.R() * perim(b), o = atS(b, s, { x: 0, z: 0 });
          if ((o.x - P.x) ** 2 + (o.z - P.z) ** 2 < 45 * 45 || o.x * o.x + o.z * o.z < 26 * 26) continue;
          Object.assign(p, { b, s, x: o.x, z: o.z, state: 'walk', t: 0, cool: 3, active: true }); break;
        }
      }
    }
  }
  // fait apparaître un passant près d'un point (passager qui descend d'un bus) ; renvoie true si c'est possible
  spawnNear(x, z) {
    const p = this.list.find((q) => !q.active) || null; if (!p) return false;
    let best = null; for (const b of this.blocks) { const s = project(b, x, z), o = atS(b, s, { x: 0, z: 0 }), d = (o.x - x) ** 2 + (o.z - z) ** 2; if (!best || d < best.d) best = { d, b, s, o }; }
    if (!best || best.d > 15 * 15) return false;
    Object.assign(p, { b: best.b, s: best.s, x: best.o.x, z: best.o.z, state: 'walk', t: 0, cool: 6, active: true, dir: this.R() < 0.5 ? 1 : -1 });
    return true;
  }

  // Effet de jeu (pouvoirs) : écarte les passants autour d'un point ; ils reviennent ensuite à leur trajet
  push(x, z, radius, strength = 2) {
    let n = 0;
    for (const p of this.list) {
      const dx = p.x + (p.px || 0) - x, dz = p.z + (p.pz || 0) - z, d = Math.hypot(dx, dz);
      if (d > radius || d < 0.01) continue;
      const k = strength * (1 - d / radius) / d;
      p.px = Math.max(-3, Math.min(3, (p.px || 0) + dx * k)); p.pz = Math.max(-3, Math.min(3, (p.pz || 0) + dz * k));
      n++;
    }
    return n;
  }
}
