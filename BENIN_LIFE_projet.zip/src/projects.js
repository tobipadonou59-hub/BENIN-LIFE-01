// Mission 016, phase 5 — projets personnels du PDG (onglet « Projets » de NOVA Gestion, au bureau du PDG ou sur
// l'ordinateur de la maison) : création (budget débité de NOVA BOOK), équipe affectée, travail personnel du PDG,
// étapes à valider, délai, livraison et revenus. Plusieurs projets peuvent avancer en même temps.
import { JOBS, BOOKS } from './nova-data.js';
import { fcfa } from './food-data.js';

export const PROJECT_TYPES = [
  { id: 'livre', label: 'Création d’un livre', dept: 'Édition', jobs: ['maquettiste', 'correcteur', 'graphiste'], budget: 400000, days: 5, revenue: 1500000, steps: ['Rédaction du contenu', 'Correction', 'Mise en page', 'Validation finale'], names: BOOKS.filter((n) => !/roman/.test(n)) },
  { id: 'roman', label: 'Écriture d’un roman fictif', dept: 'Édition', jobs: ['correcteur', 'maquettiste'], budget: 300000, days: 6, revenue: 1300000, steps: ['Plan de l’histoire', 'Écriture des chapitres', 'Relecture', 'Bon à tirer'], names: ['Le Pêcheur de Ganvié (roman)', 'Les Lumières du Golfe (roman)', 'Sous le flamboyant (roman)', 'La Route de Porto-Novo (roman)'] },
  { id: 'manuel', label: 'Création d’un manuel scolaire', dept: 'Édition', jobs: ['maquettiste', 'correcteur', 'graphiste'], budget: 600000, days: 7, revenue: 2400000, steps: ['Programme et sommaire', 'Rédaction des leçons', 'Illustrations', 'Mise en page', 'Validation pédagogique'], names: ['Français CE1 — manuel', 'Sciences CM1 — manuel', 'Histoire-géographie 6e — manuel', 'Mathématiques 3e — manuel'] },
  { id: 'couverture', label: 'Conception d’une couverture', dept: 'Graphisme', jobs: ['graphiste'], budget: 100000, days: 2, revenue: 450000, steps: ['Recherche graphique', 'Maquette', 'Finalisation'], names: ['Couverture — recueil de contes', 'Couverture — guide touristique', 'Couverture — magazine économique'] },
  { id: 'mise_en_page', label: 'Mise en page d’un ouvrage', dept: 'Édition', jobs: ['maquettiste'], budget: 150000, days: 3, revenue: 600000, steps: ['Gabarit', 'Mise en page', 'Corrections'], names: ['Mise en page — rapport annuel', 'Mise en page — livre de recettes béninoises', 'Mise en page — annuaire'] },
  { id: 'affiche', label: 'Création d’une affiche', dept: 'Graphisme', jobs: ['graphiste'], budget: 80000, days: 2, revenue: 350000, steps: ['Concept', 'Création', 'Épreuve d’impression'], names: ['Affiche — festival de musique', 'Affiche — salon du livre', 'Affiche — campagne de santé'] },
  { id: 'dev', label: 'Projet de développement informatique', dept: 'Informatique', jobs: ['developpeur'], budget: 500000, days: 6, revenue: 2200000, steps: ['Cahier des charges', 'Développement', 'Tests', 'Mise en ligne'], names: ['Application de lecture NOVA', 'Site de vente de livres', 'Logiciel de gestion de bibliothèque'] },
  { id: 'video', label: 'Production d’une vidéo', dept: 'Audiovisuel', jobs: ['monteur'], budget: 450000, days: 5, revenue: 1800000, steps: ['Scénario', 'Tournage', 'Montage', 'Livraison'], names: ['Bande-annonce d’un roman', 'Documentaire — l’édition au Bénin', 'Clip promotionnel NOVA'] },
  { id: 'comm', label: 'Projet de communication', dept: 'Commercial', jobs: ['commercial', 'graphiste'], budget: 250000, days: 4, revenue: 1000000, steps: ['Stratégie', 'Création des supports', 'Diffusion'], names: ['Campagne de rentrée scolaire', 'Lancement d’une collection', 'Communication du salon du livre'] },
  { id: 'impression', label: 'Projet d’impression', dept: 'Impression', jobs: ['imprimeur'], budget: 350000, days: 3, revenue: 1200000, steps: ['Préparation des fichiers', 'Impression', 'Façonnage', 'Livraison'], names: ['Impression — 2 000 manuels', 'Impression — catalogue', 'Impression — calendriers 2027'] },
];
const TYPE = Object.fromEntries(PROJECT_TYPES.map((t) => [t.id, t]));
const MAX_TEAM = 4, WORK_PTS = 5, CEO_PTS = 15;

export class Projects {
  constructor(ctx) {
    Object.assign(this, ctx); // company, economy, env, needs, ui, onSave
    this.list = []; this.uid = 1; this.sel = null; this.view = 'list'; this.lastT = null; this.cool = 0;
  }
  emp(id) { return this.company.staff.find((e) => e.id === id); }
  busy(eid) { return this.list.find((p) => p.state !== 'livré' && p.team.includes(eid)); }
  day() { return this.company.day; }
  create(tid) {
    const T = TYPE[tid], C = this.company; if (!T) return;
    if (C.cash < T.budget) return this.ui.toast(`Trésorerie de NOVA BOOK insuffisante (budget ${fcfa(T.budget)}).`, 2.5);
    const used = new Set(this.list.map((p) => p.name)), name = T.names.find((n) => !used.has(n)) || `${T.label} n°${this.uid}`;
    C.post(`Projet « ${name} » — budget`, -T.budget, 'invest');
    const p = { id: this.uid++, type: tid, name, desc: `${T.label} • département ${T.dept}`, dept: T.dept, budget: T.budget, revenue: T.revenue, start: this.day(), due: this.day() + T.days, team: [], steps: T.steps.map((l) => ({ label: l, prog: 0, ok: false })), cur: 0, state: 'en attente', ceo: 0 };
    this.list.unshift(p); this.sel = p.id; this.view = 'detail';
    this.ui.toast(`🗂️ Projet créé : ${name} (budget ${fcfa(T.budget)}, délai ${T.days} jours)`, 3);
    this.onSave && this.onSave();
  }
  get(id) { return this.list.find((p) => p.id === id); }
  step(p) { return p.steps[p.cur]; }
  addProgress(p, pts) {
    const s = this.step(p); if (!s || s.ok) return;
    s.prog = Math.min(100, s.prog + pts);
    if (p.state === 'en attente') p.state = 'en cours';
    if (s.prog >= 100 && !s.notified) { s.notified = true; this.economy.notify(`🗂️ ${p.name} : étape « ${s.label} » terminée, à valider par le PDG`); }
  }
  work(id) { // le PDG travaille lui-même sur le projet
    const p = this.get(id); if (!p || p.state === 'terminé' || p.state === 'livré') return;
    if (performance.now() < this.cool) return this.ui.toast('Tu viens de travailler : fais une courte pause avant de reprendre.', 1.8);
    if (this.needs && this.needs.energy < 10) return this.ui.toast('Tu es trop fatigué(e) pour travailler : repose-toi d’abord.', 2.2);
    const s = this.step(p); if (s.prog >= 100) return this.ui.toast('Cette étape est terminée : valide-la pour passer à la suivante.', 2.2);
    this.cool = performance.now() + 4000; this.addProgress(p, CEO_PTS); p.ceo++;
    if (this.needs) this.needs.energy = Math.max(0, this.needs.energy - 3);
    this.env.time = (this.env.time + 0.5) % 24; // 30 minutes de travail
    this.ui.toast(`Tu as travaillé 30 min sur « ${s.label} » : +${CEO_PTS} % • énergie −3`, 2.2);
    this.onSave && this.onSave();
  }
  validate(id) {
    const p = this.get(id), s = p && this.step(p); if (!s || s.prog < 100 || s.ok) return;
    s.ok = true; p.cur++;
    if (p.cur >= p.steps.length) { p.state = 'terminé'; this.ui.toast(`✅ ${p.name} : toutes les étapes sont validées. Le projet peut être livré.`, 3); }
    else this.ui.toast(`Étape validée. Suivante : ${this.step(p).label}`, 2.2);
    this.onSave && this.onSave();
  }
  deliver(id) {
    const p = this.get(id); if (!p || p.state !== 'terminé') return;
    const late = this.day() > p.due, rev = Math.round(p.revenue * (late ? 0.7 : 1) / 5000) * 5000;
    this.company.post(`Projet livré : ${p.name}${late ? ' (en retard, −30 %)' : ''}`, rev, 'ca');
    p.state = 'livré'; p.paid = rev; p.team = [];
    for (const e of this.company.staff) if (e.lastProject === p.id) e.morale = Math.min(100, e.morale + 4);
    this.economy.notify(`💼 Projet livré : ${p.name} • revenu ${fcfa(rev)} versé à NOVA BOOK${late ? ' (retard −30 %)' : ''}`);
    this.onSave && this.onSave();
  }
  assign(id, eid) {
    const p = this.get(id), e = this.emp(eid); if (!p || !e || p.state === 'livré') return;
    if (p.team.includes(eid)) { p.team = p.team.filter((q) => q !== eid); return this.onSave && this.onSave(); }
    if (p.team.length >= MAX_TEAM) return this.ui.toast(`Équipe complète (${MAX_TEAM} personnes maximum).`, 2);
    const other = this.busy(eid); if (other) return this.ui.toast(`${e.name} travaille déjà sur « ${other.name} ».`, 2.2);
    p.team.push(eid); e.lastProject = p.id; if (p.state === 'en attente') p.state = 'en cours';
    this.onSave && this.onSave();
  }
  // avancement de l'équipe : chaque heure de travail (7 h – 19 h)
  update() {
    const h = this.env.time;
    if (this.lastT === null) { this.lastT = h; return; }
    let dh = h - this.lastT; if (dh < 0) dh += 24; if (dh <= 0) return;
    const hours = Math.floor(this.lastT + dh) - Math.floor(this.lastT); this.lastT = h;
    for (let k = 0; k < hours && k < 24; k++) {
      const hh = (Math.floor(h) - k + 24) % 24; if (hh < 7 || hh >= 19) continue;
      for (const p of this.list) if (p.state === 'en cours' && p.team.length) {
        const pts = p.team.reduce((a, id) => { const e = this.emp(id); return a + (e ? this.company.prod(e) : 0); }, 0) * WORK_PTS;
        this.addProgress(p, pts);
      }
    }
    for (const p of this.list) p.team = p.team.filter((id) => this.emp(id)); // employé licencié
  }
  // ------------------------------------------------------------------ interface (onglet de NOVA Gestion)
  bar(v) { return `<span class="pj-bar"><i style="width:${Math.round(v)}%"></i></span>`; }
  total(p) { return Math.round(p.steps.reduce((a, s) => a + (s.ok ? 100 : s.prog), 0) / p.steps.length); }
  stateTag(p) { const late = p.state !== 'livré' && this.day() > p.due; return `<em class="pj-st ${p.state.replace(/ /g, '-')}">${p.state}${late ? ' • en retard' : ''}</em>`; }
  render() {
    if (this.view === 'new') {
      return `<button class="bz-back" data-a="pjlist">← Mes projets</button><h4 class="bz-h">Nouveau projet <small>Le budget est débité de la trésorerie de NOVA BOOK (${fcfa(this.company.cash)})</small></h4>
        ${PROJECT_TYPES.map((t) => `<div class="bz-row"><span><b>${t.label}</b><small>${t.dept} • ${t.steps.length} étapes • délai ${t.days} jours • métiers : ${t.jobs.map((j) => JOBS[j].label).join(', ')}</small></span><em>budget ${fcfa(t.budget)}<br>revenu prévu ${fcfa(t.revenue)}</em><span class="bz-btns"><button data-a="pjnew:${t.id}" ${this.company.cash >= t.budget ? '' : 'disabled'}>Créer</button></span></div>`).join('')}`;
    }
    const p = this.view === 'detail' && this.get(this.sel);
    if (p) {
      const T = TYPE[p.type], s = this.step(p), cands = this.company.staff.filter((e) => T.jobs.includes(e.job) || p.team.includes(e.id));
      const teamPts = p.team.reduce((a, id) => { const e = this.emp(id); return a + (e ? this.company.prod(e) : 0); }, 0) * WORK_PTS;
      return `<button class="bz-back" data-a="pjlist">← Mes projets</button><h4 class="bz-h">${p.name} ${this.stateTag(p)} <small>${p.desc}</small></h4>
        <div class="bz-grid">${this.kpi('Progression', `${this.total(p)} %`)}${this.kpi('Budget engagé', fcfa(p.budget))}${this.kpi('Revenu prévu', fcfa(p.revenue))}${this.kpi('Délai', `jour ${p.due} (aujourd’hui : ${this.day()})`, this.day() > p.due && p.state !== 'livré' ? 'neg' : '')}${this.kpi('Équipe', `${p.team.length} / ${MAX_TEAM}`)}${this.kpi('Avancement de l’équipe', p.team.length ? `≈ ${Math.round(teamPts)} % / heure de travail` : '—')}</div>
        <h5>Étapes de réalisation</h5>${p.steps.map((st, i) => `<div class="bz-row"><span><b>${st.ok ? '✅' : i === p.cur ? '▶️' : '⏳'} ${i + 1}. ${st.label}</b>${this.bar(st.ok ? 100 : st.prog)}</span><em>${st.ok ? 'validée' : `${Math.round(st.prog)} %`}</em></div>`).join('')}
        <div class="bz-row"><span><b>Actions du PDG</b><small>Travailler soi-même : +${CEO_PTS} % sur l’étape en cours (30 min, énergie −3). Une étape terminée doit être validée.</small></span><span class="bz-btns">
          ${p.state === 'terminé' ? `<button data-a="pjdeliver:${p.id}" class="on">📦 Livrer le projet</button>` : p.state === 'livré' ? `<button disabled>Livré • ${fcfa(p.paid || 0)}</button>` : `<button data-a="pjwork:${p.id}" ${s && s.prog < 100 ? '' : 'disabled'}>💻 Travailler sur le projet</button><button data-a="pjok:${p.id}" ${s && s.prog >= 100 ? 'class="on"' : 'disabled'}>✔ Valider l’étape</button>`}</span></div>
        ${p.state !== 'livré' ? `<h5>Équipe affectée (métiers utiles : ${T.jobs.map((j) => JOBS[j].label).join(', ')})</h5>
        ${cands.map((e) => { const on = p.team.includes(e.id), other = !on && this.busy(e.id); return `<div class="bz-row"><span><b>${on ? '🟢 ' : ''}${e.name}</b><small>${JOBS[e.job].label} • compétence ${e.skill} • moral ${Math.round(e.morale)}${other ? ` • déjà sur « ${other.name} »` : ''}</small></span><span class="bz-btns"><button data-a="pjteam:${p.id}|${e.id}" ${other ? 'disabled' : ''}>${on ? 'Retirer' : 'Affecter'}</button></span></div>`; }).join('') || '<p class="bz-note">Aucun employé de ce métier.</p>'}
        <div class="bz-row"><span><b>Besoin d’un spécialiste ?</b><small>Recrute un ${T.jobs.map((j) => JOBS[j].label.toLowerCase()).join(' ou ')} dans l’onglet Recrutement, puis affecte-le ici.</small></span><span class="bz-btns"><button data-tab="recrut">🤝 Recruter</button></span></div>` : ''}`;
    }
    const act = this.list.filter((p) => p.state !== 'livré'), done = this.list.filter((p) => p.state === 'livré');
    return `<div class="bz-row"><span><b>Mes projets</b><small>${act.length} en cours • ${done.length} livré(s) • plusieurs projets peuvent avancer en même temps</small></span><span class="bz-btns"><button data-a="pjnewview" class="on">＋ Nouveau projet</button></span></div>
      ${[...act, ...done].map((p) => `<div class="bz-row pj-card" data-a="pjopen:${p.id}"><span><b>${p.name} ${this.stateTag(p)}</b><small>${p.desc} • équipe ${p.team.length} • délai jour ${p.due}</small>${this.bar(this.total(p))}</span><em>${this.total(p)} %</em></div>`).join('') || '<p class="bz-note">Aucun projet : crée ton premier projet.</p>'}`;
  }
  kpi(l, v, cls = '') { return `<div class="bz-k ${cls}"><small>${l}</small><b>${v}</b></div>`; }
  onAction(a, v) {
    const [x, y] = (v || '').split('|');
    if (a === 'pjlist') { this.view = 'list'; return true; }
    if (a === 'pjnewview') { this.view = 'new'; return true; }
    if (a === 'pjnew') { this.create(v); return true; }
    if (a === 'pjopen') { this.sel = +v; this.view = 'detail'; return true; }
    if (a === 'pjwork') { this.work(+v); return true; }
    if (a === 'pjok') { this.validate(+v); return true; }
    if (a === 'pjdeliver') { this.deliver(+v); return true; }
    if (a === 'pjteam') { this.assign(+x, +y); return true; }
    return false;
  }
  serialize() { return { list: this.list, uid: this.uid }; }
  restore(s) { if (!s) return; this.list = Array.isArray(s.list) ? s.list : []; this.uid = s.uid || this.list.length + 1; }
}
