// Mission 021, étape 2 — vols : réservation (classe économique ou affaires, bagages, aller simple ou aller-retour),
// enregistrement au comptoir (carte d'embarquement, place attribuée), contrôle de sûreté, embarquement à la porte,
// voyage dans une cabine d'avion visitable (décollage, croisière, repas, divertissement, descente, atterrissage) et
// arrivée. Compagnies, vols, horaires et tarifs FICTIFS. Les villes étrangères ne sont pas encore jouables : à
// l'arrivée, le jeu le dit clairement et propose le vol retour vers Cotonou.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { colorize } from './vehicles.js';
import { createCharacter, SKINS } from './character.js';
import { fcfa } from './food-data.js';
import { AIRLINES, DEST_BY_ID, departures, hh } from './travel-data.js';
import { TERM } from './terminal.js';

const PI = Math.PI;
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const pick = (a) => a[Math.floor(Math.random() * a.length)];
export const CABIN = { LV: 190, Y: 680, O: { x: -680, z: 141 } };
const BAG_FEE = 25000, FREE_BAGS = { eco: 1, biz: 2 }, CLS = { eco: 'Économique', biz: 'Affaires' };
const ECO_Z = [-1.75, -1.25, -0.75, 0.75, 1.25, 1.75], BIZ_Z = [-1.5, -0.85, 0.85, 1.5];
const ecoX = (r) => 5.4 - r * 0.86, bizX = (r) => 10.8 - r * 1.5; // rangées 10–31 (éco), 1–3 (affaires)
const dur = (h) => (h < 1 ? `${Math.round(h * 60)} min` : `${Math.floor(h)} h${Math.round((h % 1) * 60) ? ` ${String(Math.round((h % 1) * 60)).padStart(2, '0')}` : ''}`);
const STATE = { reserve: ['Réservé', '#fcd116'], enregistre: ['Enregistré', '#2fd08a'], controle: ['Contrôle passé', '#2fd08a'], vol: ['En vol', '#2f80ed'], arrive: ['Arrivé', '#2f80ed'], termine: ['Terminé', '#8a8f96'], manque: ['Vol manqué', '#e8112d'], annule: ['Annulé', '#8a8f96'] };

export class Flights {
  constructor(ctx) {
    Object.assign(this, ctx); // T (terminal), scene, world, player, ui, audio, env, economy, needs, tpc, home, onSave
    this.bookings = []; this.history = []; this.cur = null; this.seq = 1; this.inside = false; this.seated = false; this.points = []; this.people = []; this.bk = { cls: 'eco', bags: 1, ret: false, i: 0 };
    if (this.T) { this.T.flights = this; this.T.hasBiz = () => this.bookings.some((b) => b.cls === 'biz' && ['enregistre', 'controle'].includes(b.state)); if (this.T._fl) this.restore(this.T._fl); }
    this.dom = document.getElementById('sitbar');
    if (this.dom) this.dom.addEventListener('click', (e) => { const b = e.target.closest('[data-fl]'); if (b) { e.stopPropagation(); this.act(b.dataset.fl); } });
    this.build();
  }
  abs() { return this.T.abs(); }
  save() { this.onSave && this.onSave(); }
  D(b) { return DEST_BY_ID[b.dest]; }
  num(b) { const D = this.D(b), [c, n] = D.num.split(' '); return b.back ? `${c} ${+n + 1}` : D.num; }
  route(b) { const D = this.D(b); return b.back ? `${D.city} → Cotonou` : `Cotonou → ${D.city}`; }
  local(D, t = this.env.time) { return `${hh(t + D.tz)}${D.dst ? ' (heure d’hiver)' : ''}`; }
  active() { return this.bookings.filter((b) => ['reserve', 'enregistre', 'controle'].includes(b.state)); }
  // ------------------------------------------------------------------ temps qui passe (attente, vol)
  waitUntil(target, msg, after) {
    const hrs = target - this.abs(); if (!(hrs > 0.01)) { after && after(); return; }
    if (hrs > 20) return this.ui.toast('Attente trop longue : reviens plus tard.', 2.5);
    this.ui.fade && this.ui.fade(true);
    setTimeout(() => { this.skip(hrs); this.ui.fade && this.ui.fade(false); if (msg) this.ui.toast(msg, 3.5); after && after(); }, 650);
  }
  skip(hrs) {
    this.env.time = (this.env.time + hrs) % 24; if (this.economy.update) this.economy.update(0); // jour du jeu mis à jour tout de suite
    const n = this.needs; if (n) { n.hunger = Math.max(5, n.hunger - hrs * 1.5); n.hygiene = Math.max(5, n.hygiene - hrs * 0.8); n.energy = Math.max(5, Math.min(100, n.energy + (this.seated ? hrs * 2 : -hrs * 1.2))); }
  }
  // ------------------------------------------------------------------ réservation
  options(D, minLead = 1) { const a = this.abs(); return departures(a, 72).filter((d) => d.D.id === D.id && d.at - a >= minLead).slice(0, 4); }
  price(D, cls, bags, ret) { return Math.round(D[cls] * (ret ? 1.9 : 1)) + Math.max(0, bags - FREE_BAGS[cls]) * BAG_FEE * (ret ? 2 : 1); }
  book(D, dep, cls, bags, ret, where) {
    if (this.bookings.some((b) => b.dest === D.id && b.at === dep.at && b.state !== 'annule')) return this.ui.toast('Tu as déjà un billet pour ce vol.', 2.5), false;
    const price = this.price(D, cls, bags, ret);
    if (!this.economy.pay(price, `Billet ${D.num} Cotonou → ${D.city} (${CLS[cls]}${ret ? ', aller-retour' : ''})`, where || 'NOVA TRAVEL')) return this.ui.toast('Solde insuffisant.', 2), false;
    const b = { ref: `NT${String(this.seq++).padStart(4, '0')}`, dest: D.id, at: dep.at, cls, bags, ret, price, state: 'reserve', seat: null, made: this.economy.stamp() };
    this.bookings.unshift(b); this.bookings.length = Math.min(this.bookings.length, 40);
    this.T.spend('Billets', price, `${D.num} → ${D.city} (${CLS[cls]})`);
    this.ui.toast(`🎫 Billet réservé : ${D.num} → ${D.city}, ${hh(dep.h)} (${this.dayLabel(dep.at)}), classe ${CLS[cls]}. Référence ${b.ref}. Enregistrement au comptoir ${AIRLINES[D.air].name} à partir de ${hh(dep.at - 3)}.`, 6);
    this.save(); return b;
  }
  dayLabel(at) { const d = Math.floor(at / 24) - Math.floor(this.abs() / 24); return d <= 0 ? 'aujourd’hui' : d === 1 ? 'demain' : `dans ${d} jours`; }
  cancel(b) {
    if (b.state !== 'reserve' || b.at - this.abs() < 3) return this.ui.toast('Annulation possible jusqu’à 3 h avant le départ, avant l’enregistrement.', 3);
    const r = Math.round(b.price * 0.7); b.state = 'annule'; this.economy.earn(r, `Remboursement billet ${b.ref} (70 %)`, 'NOVA TRAVEL'); this.T.spend('Remboursements', -r, `Annulation ${b.ref}`); this.ui.toast(`Billet ${b.ref} annulé : ${fcfa(r)} remboursés.`, 3); this.save();
  }
  rebook(b) {
    const D = this.D(b), n = this.options(D, 1)[0]; if (!n) return; const fee = Math.round(b.price * 0.25);
    if (!this.economy.pay(fee, `Report du billet ${b.ref} (vol manqué)`, 'NOVA TRAVEL')) return this.ui.toast('Solde insuffisant.', 2);
    b.at = n.at; b.state = 'reserve'; b.seat = null; this.T.spend('Billets', fee, `Report ${b.ref}`); this.ui.toast(`🎫 ${b.ref} reporté sur le vol de ${hh(n.h)} (${this.dayLabel(n.at)}).`, 4); this.save();
  }
  // ------------------------------------------------------------------ terminal : comptoir, sûreté, porte
  checkin(k) {
    const a = this.abs(), mine = this.active().filter((b) => b.state === 'reserve' && this.D(b).air === k), items = [];
    for (const b of mine) {
      const D = this.D(b), open = b.at - 3, close = b.at - 0.5, lab = `${D.num} → ${D.city} • ${hh(b.at)} (${this.dayLabel(b.at)}) • ${CLS[b.cls]}`;
      if (a >= open && a <= close) items.push({ label: `🧳 Enregistrer : ${lab}`, desc: `${b.bags} bagage${b.bags > 1 ? 's' : ''} en soute • carte d’embarquement`, action: () => this.doCheckin(b) });
      else if (a < open) items.push({ label: `⏳ ${lab}`, desc: `Enregistrement à partir de ${hh(open)} — patienter dans le hall`, action: () => this.waitUntil(open, `⏳ Il est ${this.env.clock} : l’enregistrement du vol ${D.num} est ouvert.`) });
    }
    items.push({ label: '🎫 Acheter un billet au comptoir', desc: `Vols ${AIRLINES[k].name} des prochaines 24 h`, action: () => this.counterSale(k) });
    this.ui.openMenu(`🧳 Comptoir ${AIRLINES[k].name}`, 'Compagnie fictive • enregistrement de 3 h à 30 min avant le départ', items);
  }
  doCheckin(b) {
    const used = new Set(this.bookings.map((q) => q.seat)); let seat;
    do { seat = b.cls === 'biz' ? `${1 + Math.floor(Math.random() * 3)}${pick(['A', 'C', 'D', 'F'])}` : `${10 + Math.floor(Math.random() * 22)}${pick(['A', 'B', 'C', 'D', 'E', 'F'])}`; } while (used.has(seat));
    b.seat = seat; b.state = 'enregistre'; this.env.time = (this.env.time + 0.1) % 24; const D = this.D(b);
    if (this.T.inside) this.T.vipDoor.disabled = this.T.vipOk();
    this.ui.toast(`🎟️ Carte d’embarquement ${D.num} → ${D.city} : place ${seat}, porte ${D.gate}, embarquement à ${hh(b.at - 0.75)}. ${b.bags ? `${b.bags} bagage${b.bags > 1 ? 's' : ''} enregistré${b.bags > 1 ? 's' : ''}.` : 'Bagage cabine seulement.'} Passe ensuite le contrôle de sûreté.${b.cls === 'biz' ? ' Accès au salon VIP inclus.' : ''}`, 6.5); this.save();
  }
  counterSale(k) {
    const a = this.abs(), list = departures(a, 24).filter((d) => d.D.air === k && d.at - a >= 0.6).slice(0, 6);
    if (!list.length) return this.ui.toast('Aucun vol disponible à la vente pour le moment.', 2.5);
    this.ui.openMenu(`🎫 Vente de billets ${AIRLINES[k].name}`, 'Bagages inclus : 1 (économique), 2 (affaires)', list.map((d) => ({ label: `${hh(d.h)} ${d.D.num} → ${d.D.city} (${this.dayLabel(d.at)})`, desc: `Éco ${fcfa(d.D.eco)} • Affaires ${fcfa(d.D.biz)}`, action: () =>
      this.ui.openMenu(`${d.D.num} → ${d.D.city}`, `Départ ${hh(d.h)} • porte ${d.D.gate}`, [['eco', 1], ['biz', 2]].map(([c, bg]) => ({ label: `Classe ${CLS[c]}`, desc: fcfa(this.price(d.D, c, bg, false)), action: () => this.book(d.D, d, c, bg, false, `Comptoir ${AIRLINES[k].name}`) }))) })));
  }
  security() {
    const list = this.active().filter((b) => b.state === 'enregistre');
    if (!list.length) return this.ui.toast(this.active().some((b) => b.state === 'reserve') ? '🛂 Enregistre-toi d’abord au comptoir de ta compagnie pour obtenir ta carte d’embarquement.' : '🛂 Contrôle de sûreté : aucun vol à contrôler. (Boutiques et restaurant restent accessibles.)', 4);
    for (const b of list) b.state = 'controle'; this.env.time = (this.env.time + 0.15) % 24; this.save();
    const b = list[0], D = this.D(b); this.ui.toast(`🛂 Carte d’embarquement et pièce d’identité vérifiées, portique franchi, bagage cabine aux rayons X : c’est bon ! Rends-toi porte ${D.gate} (embarquement ${hh(b.at - 0.75)}).`, 5);
  }
  gate(gt) {
    const a = this.abs(), b = this.active().find((q) => this.D(q).gate === gt && q.state !== 'reserve');
    if (!b) return false; const D = this.D(b), dt = b.at - a;
    if (b.state === 'enregistre') { this.ui.toast(`Porte ${gt} : passe d’abord le contrôle de sûreté avec ta carte d’embarquement.`, 3); return true; }
    if (dt > 0.75) { this.ui.openMenu(`🛫 Porte ${gt} • ${D.num} → ${D.city}`, `Embarquement à ${hh(b.at - 0.75)} • place ${b.seat}`, [{ label: `⏳ Patienter en salle d’embarquement jusqu’à ${hh(b.at - 0.75)}`, action: () => this.waitUntil(b.at - 0.74, `📢 « Embarquement immédiat du vol ${D.num} à destination de ${D.city}, porte ${gt}. »`) }, { label: 'Plus tard', action: () => {} }]); return true; }
    this.ui.openMenu(`🛫 Porte ${gt} • ${D.num} → ${D.city}`, `Embarquement en cours • place ${b.seat} • classe ${CLS[b.cls]}`, [{ label: '🎟️ Présenter la carte d’embarquement et embarquer', action: () => this.board(b) }, { label: 'Plus tard (porte fermée 15 min avant le départ)', action: () => {} }]); return true;
  }
  board(b) {
    if (b.at - this.abs() < 0.25) return this.ui.toast('Porte fermée.', 2);
    b.state = 'vol'; this.cur = { ref: b.ref, back: false, dep: b.at, arr: b.at + this.D(b).dur, phase: 'board' }; this.save();
    this.ui.fade && this.ui.fade(true); setTimeout(() => { this.T.exit(true); this.enterCabin(false); this.ui.fade && this.ui.fade(false); }, 650);
  }
  curB() { return this.cur && this.bookings.find((b) => b.ref === this.cur.ref); }
  // ------------------------------------------------------------------ cabine d'avion (intérieur isolé)
  build() {
    const { LV, Y, O } = CABIN, g = new THREE.Group(); g.position.set(O.x, Y, O.z); g.visible = false; this.scene.add(g); this.group = g;
    const parts = [], glow = [], win = [], col = this.world.collision, H = 2.3;
    const box = (x0, y0, z0, x1, y1, z1, c, arr = parts) => arr.push(colorize(new THREE.BoxGeometry(Math.abs(x1 - x0) || 0.01, Math.abs(y1 - y0) || 0.01, Math.abs(z1 - z0) || 0.01).translate((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), c));
    const solid = (x0, z0, x1, z1, h = H) => { const o = col.addBox(O.x + Math.min(x0, x1), O.z + Math.min(z0, z1), O.x + Math.max(x0, x1), O.z + Math.max(z0, z1), Y + h); o.lv = LV; return o; };
    const P = (x, z, r, label, action, when) => this.points.push({ x, z, r, label, action, when });
    // fuselage : plancher, moquette, allée, parois, cloisons d'extrémité
    box(-16.2, -0.1, -2.35, 16.2, 0, 2.35, 0x2a3446); box(-14, 0.001, -0.42, 15, 0.006, 0.42, 0x4a3a5a);
    for (const s of [-1, 1]) { box(-16.2, 0, s * 2.2, 16.2, H, s * 2.35, 0xe8e6e0); solid(-16.2, s * 2.2, 16.2, s * 2.35); box(-16, 0, s * 2.05, 16, 0.35, s * 2.2, 0x9aa0a8); }
    box(-16.2, 0, -2.35, -16, H, 2.35, 0xe8e6e0); solid(-16.2, -2.35, -16, 2.35); box(16, 0, -2.35, 16.2, H, 2.35, 0xe8e6e0); solid(16, -2.35, 16.2, 2.35);
    box(15.9, 0, -0.45, 16, 2.0, 0.45, 0x3a3d42); P(15.2, 0, 1.0, 'Poste de pilotage (accès réservé à l’équipage)', () => this.ui.toast('🔒 Porte du poste de pilotage verrouillée : accès réservé aux pilotes.', 2.5));
    // hublots (couleur du ciel mise à jour en vol)
    for (let x = -12.6; x <= 12; x += 0.86) for (const s of [-1, 1]) box(x - 0.17, 0.95, s * 2.19, x + 0.17, 1.42, s * 2.2, 0xffffff, win);
    // office avant (repas, boissons) et porte d'embarquement
    for (const s of [-1, 1]) { box(12.4, 0, s * 1.35, 15, 1.0, s * 2.2, 0xc8ccd2); box(12.4, 1.0, s * 1.35, 15, 1.05, s * 2.2, 0x8a8f96); solid(12.4, s * 1.35, 15, s * 2.2, 1.1); }
    box(13.1, 0.35, 1.15, 13.6, 1.0, 1.35, 0x8a8f96); P(12.2, 0.8, 1.1, 'Office : demander une boisson à l’équipage', () => this.drink());
    box(13.8, 0, -2.36, 15, 2.0, -2.34, 0x8a8f96); P(13.9, -0.9, 1.0, 'Porte de l’avion', () => this.door());
    // classe affaires : 3 rangées de fauteuils-lits (2 + 2), rideau de séparation
    this.seats = {};
    for (let r = 0; r < 3; r++) { const x = bizX(r); BIZ_Z.forEach((z, i) => { box(x - 0.36, 0.25, z - 0.29, x + 0.36, 0.48, z + 0.29, 0xd8c8a8); box(x - 0.46, 0.25, z - 0.29, x - 0.34, 1.2, z + 0.29, 0xd8c8a8); box(x - 0.36, 0.48, z - 0.31, x + 0.2, 0.62, z - 0.27, 0x5a3a22); box(x + 0.55, 0.3, z - 0.22, x + 0.7, 0.62, z + 0.22, 0x3a2416); this.seats[`${r + 1}${'ACDF'[i]}`] = { x, z }; });
      for (const s of [-1, 1]) solid(x - 0.46, s * 0.55, x + 0.7, s * 1.8, 1.2); }
    for (const s of [-1, 1]) { box(6.55, 0, s * 0.55, 6.65, 2.05, s * 2.2, 0x6a1a2a); solid(6.55, s * 0.55, 6.65, s * 2.2, 2.05); }
    // classe économique : rangées 10 à 31 (3 + 3)
    for (let r = 0; r < 22; r++) { const x = ecoX(r); ECO_Z.forEach((z, i) => { box(x - 0.22, 0.25, z - 0.22, x + 0.22, 0.45, z + 0.22, 0x1f4e9c); box(x - 0.3, 0.25, z - 0.23, x - 0.2, 1.12, z + 0.23, 0x1f4e9c); box(x - 0.31, 0.98, z - 0.18, x - 0.29, 1.08, z + 0.18, 0xf2f0ea); this.seats[`${r + 10}${'ABCDEF'[i]}`] = { x, z }; });
      for (const s of [-1, 1]) solid(x - 0.3, s * 0.55, x + 0.22, s * 2.0, 1.12); }
    // toilettes et office arrière
    for (const s of [-1, 1]) { box(-15.95, 0, s * 0.6, -14.2, H - 0.05, s * 0.66, 0xd8dde2); box(-14.26, 0, s * 0.6, -14.2, H - 0.05, s * 2.2, 0xd8dde2); solid(-16, s * 0.6, -14.2, s * 2.2); box(-15.4, 0, s * 1.2, -14.8, 0.45, s * 1.7, 0xf6f6f6); P(-13.7, s * 1.0, 0.9, 'Toilettes (se rafraîchir)', () => this.wc()); }
    box(-16, 0, -0.55, -15.95, 1.0, 0.55, 0xc8ccd2);
    for (let x = -12; x <= 12; x += 3) box(x - 0.2, 0.004, -0.06, x + 0.2, 0.008, 0.06, 0xfff4e0, glow); // balisage lumineux de l'allée
    const mk = (arr, m) => { const ms = new THREE.Mesh(mergeGeometries(arr), m); ms.receiveShadow = true; g.add(ms); return ms; };
    mk(parts, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.65 })); mk(glow, new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false }));
    this.winMat = new THREE.MeshBasicMaterial({ color: 0x8ec8f0, toneMapped: false }); mk(win, this.winMat);
    P(0, 0, 0, '', null, 'seat'); // point de la place du joueur (position mise à jour)
  }
  seatPos(b) { return this.seats[(b && b.seat) || '20C'] || this.seats['20C']; }
  enterCabin(seated) {
    const { Y, LV, O } = CABIN, pl = this.player, b = this.curB(); this.inside = true; this.group.visible = true; this.world.collision.level = LV; pl.floorY = Y; pl.vy = 0;
    const sp = this.points.find((p) => p.when === 'seat'), s = this.seatPos(b); sp.x = s.x + 0.1; sp.z = 0; sp.r = 0.7; sp.label = `S’asseoir à ma place ${b ? b.seat : ''}`; sp.action = () => this.sit();
    pl.pos.set(O.x + 13.4, Y, O.z - 0.3); pl.facing = -PI / 2; pl.mesh.position.copy(pl.pos); if (this.tpc) { this.tpc.yaw = PI / 2; this.tpc.snap && this.tpc.snap(pl.pos); }
    this.spawn(b); this.hum(true); this._ann = {};
    if (seated) this.sit(true);
    else this.ui.toast(`✈️ Bienvenue à bord du vol ${this.num(b)} (${this.route(b)}). Ta place : ${b.seat} (${b.cls === 'biz' ? 'classe affaires, à l’avant' : `rangée ${parseInt(b.seat, 10)}, ${/[AF]/.test(b.seat.slice(-1)) ? 'hublot' : /[CD]/.test(b.seat.slice(-1)) ? 'couloir' : 'milieu'}`}). Suis l’allée.`, 5);
  }
  leaveCabin() {
    if (this.seated) this.unsit(true); this.inside = false; this.group.visible = false; this.world.collision.level = 0; this.player.floorY = 0; this.clearPeople(); this.hum(false); this.ui.setActivity && this.ui.setActivity('');
    if (this.T) this.T.lightOff();
  }
  clearPeople() { for (const p of this.people) p.c.group.parent && p.c.group.parent.remove(p.c.group); this.people = []; }
  spawn(b) {
    this.clearPeople(); const mine = b && b.seat, keys = Object.keys(this.seats).filter((k) => k !== mine);
    const add = (o, d) => { const c = createCharacter({ skin: pick(SKINS), ...o }); this.group.add(c.group); const p = { c, ...d }; c.group.position.set(p.x, 0, p.z); c.group.rotation.y = p.h || 0; this.people.push(p); return p; };
    for (let i = 0; i < 30; i++) { const k = keys.splice(Math.floor(Math.random() * keys.length), 1)[0], s = this.seats[k], f = Math.random() < 0.5, biz = /^[1-3][A-F]$/.test(k);
      const p = add({ female: f, shirtColor: biz ? pick([0x1a1a1e, 0x2a2d33, 0x6a1a2a]) : pick([0xfcd116, 0x2f80ed, 0xe8112d, 0x0b6e4f, 0xe46a1f, 0xf6f6f6]), pants: pick([0x1f2a44, 0x2a2d33]), jacket: biz && Math.random() < 0.6, headwrap: f && Math.random() < 0.3 }, { x: s.x - 0.08, z: s.z, h: PI / 2, name: f ? 'Passagère' : 'Passager', seat: true });
      p.c.sit(false); p.c.group.position.y = biz ? -0.12 : -0.17; }
    const names = ['Hôtesse Sika', 'Hôtesse Mariam', 'Steward Josué'];
    for (let i = 0; i < 3; i++) add({ female: i < 2, shirtColor: 0xf6f6f6, jacket: true, pants: 0x0a1a3a, collar: true, skirt: i < 2 }, { x: 11 - i * 9, z: 0, h: -PI / 2, name: names[i], crew: true, tx: 11 - i * 9, wait: 1 + i * 2, speed: 0.9 });
  }
  sit(auto) {
    const b = this.curB(), s = this.seatPos(b), pl = this.player, { O, Y } = CABIN, biz = b && b.cls === 'biz';
    this.seated = true; pl.pos.set(O.x + s.x - 0.08, Y, O.z + s.z); pl.facing = PI / 2; pl.mesh.position.set(pl.pos.x, Y + (biz ? -0.12 : -0.17), pl.pos.z); pl.mesh.rotation.set(0, PI / 2, 0);
    if (pl.char && pl.char.sit) pl.char.sit(false); if (this.tpc) this.tpc.yaw = -PI / 2 + (s.z > 0 ? 0.5 : -0.5);
    this.bar(); if (auto) this.ui.toast(`🪑 Installé à ta place ${b ? b.seat : ''}, ceinture attachée.`, 2.5);
  }
  unsit(force) {
    const ph = this.phase(); if (!force && (ph === 'takeoff' || ph === 'descent')) return this.ui.toast('🔔 Consigne lumineuse allumée : reste assis, ceinture attachée.', 2.5);
    const s = this.seatPos(this.curB()), pl = this.player, { O, Y } = CABIN; this.seated = false; if (pl.char && pl.char.stand) pl.char.stand();
    pl.pos.set(O.x + s.x + 0.1, Y, O.z); pl.mesh.position.copy(pl.pos); pl.mesh.rotation.set(0, pl.facing, 0); if (this.dom) this.dom.classList.remove('show');
  }
  phase() { const c = this.cur; if (!c) return null; const a = this.abs(); return a < c.dep ? 'board' : a < c.dep + 0.25 ? 'takeoff' : a < c.arr - 0.4 ? 'cruise' : a < c.arr ? 'descent' : 'landed'; }
  actions() {
    const ph = this.phase(), out = [];
    if (ph === 'board') out.push(['wait', '⏳ Décollage']);
    if (ph !== 'landed') out.push(['meal', '🍽️ Repas'], ['drink', '🥤 Boisson'], ['film', '🎬 Film 2 h'], ['sleep', '😴 Dormir'], ['skip', '⏩ Atterrir']);
    else out.push(['door', this.cur && this.cur.back ? '🚶 Débarquer' : '🛬 Arrivée']);
    out.push(['info', 'ℹ️ Vol']); if (ph !== 'takeoff' && ph !== 'descent') out.push(['up', '🚶 Debout']); return out;
  }
  bar() { if (!this.dom || !this.seated) return; const k = this.actions().map((a) => a[0]).join(); if (this._bk === k && this.dom.classList.contains('show')) return; this._bk = k; this.dom.innerHTML = this.actions().map(([a, l]) => `<button data-fl="${a}">${l}</button>`).join(''); this.dom.classList.add('show'); }
  act(k) {
    const c = this.cur, a = this.abs(); if (!c) return;
    if (k === 'up') return this.unsit(); if (k === 'info') return this.info(); if (k === 'drink') return this.drink(); if (k === 'door') return this.door();
    if (k === 'wait') return this.waitUntil(c.dep, '🛫 Décollage imminent : ceinture attachée.');
    if (k === 'skip') return this.waitUntil(c.arr + 0.005, null);
    if (k === 'meal') { const b = this.curB(), biz = b && b.cls === 'biz'; if (this.needs) this.needs.hunger = Math.min(100, this.needs.hunger + (biz ? 55 : 40)); this.env.time = (this.env.time + 0.3) % 24; return this.ui.toast(biz ? '🍽️ Repas gastronomique servi à la place : poulet yassa, riz parfumé, salade de fruits, jus de bissap (inclus).' : '🍽️ Plateau-repas : riz au poulet, pain, dessert et jus de fruits (inclus dans le billet).', 4); }
    if (k === 'film' || k === 'sleep') { const h = k === 'film' ? 2 : Math.min(6, Math.max(0.5, c.arr - 0.45 - a)); if (c.arr - 0.4 - a < 0.4) return this.ui.toast('Nous approchons : plus assez de temps avant la descente.', 2.5);
      return this.waitUntil(Math.min(a + h, c.arr - 0.45), k === 'film' ? '🎬 Film terminé sur l’écran de ton siège (programme fictif).' : '😴 Tu te réveilles reposé.', () => { if (k === 'sleep' && this.needs) this.needs.energy = Math.min(100, this.needs.energy + 25); }); }
  }
  info() {
    const c = this.cur, b = this.curB(); if (!c || !b) return; const D = this.D(b), a = this.abs(), ph = this.phase(), to = c.back ? null : D;
    const left = c.arr - a, lab = { board: `Embarquement — décollage à ${hh(c.dep)}`, takeoff: 'Décollage', cruise: 'Croisière', descent: 'Descente', landed: 'Au sol' }[ph];
    this.ui.toast(`ℹ️ ${AIRLINES[D.air].name} ${this.num(b)} • ${this.route(b)} • place ${b.seat} (${CLS[b.cls]}) • ${lab}${ph !== 'landed' ? ` • arrivée dans ${dur(Math.max(0, left))}` : ''} • heure de Cotonou ${this.env.clock}${to ? ` • heure locale de ${to.city} ${this.local(to)}` : ''}`, 6);
  }
  drink() { if (this.needs) this.needs.hunger = Math.min(100, this.needs.hunger + 6); this.ui.toast(`🥤 ${pick(['Jus d’orange', 'Jus de bissap', 'Eau minérale', 'Soda', 'Thé chaud', 'Café'])} servi par l’équipage (sans alcool, inclus).`, 2.5); }
  wc() { if (this.needs) this.needs.hygiene = Math.min(100, this.needs.hygiene + 15); this.ui.toast('🚻 Tu te rafraîchis dans les toilettes de l’avion.', 2); }
  door() {
    const c = this.cur, ph = this.phase(); if (!c) return;
    if (ph !== 'landed') return this.ui.toast(ph === 'board' ? '🚪 Porte en cours de fermeture : l’avion va bientôt partir.' : '🚪 Porte verrouillée en vol.', 2.5);
    if (c.back) return this.arriveCotonou();
    const b = this.curB(), D = this.D(b), items = [{ label: `🧭 Découvrir ${D.city}`, desc: 'Pas encore jouable dans le jeu', action: () => this.ui.toast(`🧭 ${D.city} (${D.country}) n’est pas encore développée dans BENIN LIFE : visites et séjours à l’étranger arriveront dans une prochaine étape, sous forme d’aperçus clairement annoncés. Pour l’instant, seuls le vol et l’arrivée sont simulés.`, 7) }];
    if (b.ret) items.push({ label: '✈️ Prendre mon vol retour vers Cotonou (inclus)', desc: `Classe ${CLS[b.cls]} • transit d’environ 1 h 30`, action: () => this.goBack(b.cls, 0) });
    else for (const cl of ['eco', 'biz']) items.push({ label: `✈️ Vol retour vers Cotonou — classe ${CLS[cl]}`, desc: `${fcfa(D[cl])} • transit d’environ 1 h 30`, action: () => this.goBack(cl, D[cl]) });
    items.push({ label: 'Rester à bord pour le moment', action: () => {} });
    this.ui.openMenu(`🛬 Arrivée à ${D.city} (${D.country})`, `Heure locale ${this.local(D)} • il est ${this.env.clock} à Cotonou. Ville pas encore jouable.`, items);
  }
  goBack(cls, price) {
    const b = this.curB(), D = this.D(b); if (price && !this.economy.pay(price, `Billet retour ${D.city} → Cotonou (${CLS[cls]})`, 'NOVA TRAVEL')) return this.ui.toast('Solde insuffisant.', 2);
    if (price) this.T.spend('Billets', price, `Retour ${D.city} → Cotonou`); b.state = 'termine';
    const r = { ref: `NT${String(this.seq++).padStart(4, '0')}`, dest: D.id, back: true, at: this.abs() + 1.5, cls, bags: b.bags, ret: false, price, state: 'vol', seat: null, made: this.economy.stamp(), of: b.ref };
    r.seat = b.seat && ((cls === 'biz') === /^[1-3][A-F]$/.test(b.seat)) ? b.seat : (cls === 'biz' ? '2A' : '18F'); this.bookings.unshift(r);
    this.history.unshift({ dest: D.id, cls: b.cls, out: b.at, t: this.economy.stamp() }); this.history.length = Math.min(this.history.length, 40);
    this.cur = { ref: r.ref, back: true, dep: r.at, arr: r.at + D.dur, phase: 'board' }; this.save();
    this.waitUntil(r.at - 0.3, `🛫 Après un transit à l’aéroport de ${D.city}, tu embarques sur le vol ${this.num(r)} vers Cotonou.`, () => { this.spawn(r); this._ann = {}; this.sit(true); });
  }
  arriveCotonou() {
    const b = this.curB(); if (b) b.state = 'termine'; const h = this.history.find((q) => b && q.dest === b.dest); if (h) h.back = this.economy.stamp(); this.cur = null; this.save();
    this.ui.fade && this.ui.fade(true);
    setTimeout(() => { this.leaveCabin(); this.T.enter(); const { O, Y } = TERM; this.player.pos.set(O.x + 30, Y, O.z - 6); this.player.mesh.position.copy(this.player.pos); this.ui.fade && this.ui.fade(false); this.ui.toast('🇧🇯 Bienvenue à Cotonou ! Bagages récupérés. Sortie du terminal à l’est du hall.', 4); }, 650);
  }
  // ------------------------------------------------------------------ interactions dans la cabine
  nearest(x, z) {
    if (!this.inside || this.seated) return null; const O = CABIN.O; let best = null;
    for (const p of this.points) { if (!p.action) continue; const d = Math.hypot(x - (O.x + p.x), z - (O.z + p.z)); if (d < p.r && (!best || d < best.d)) best = { d, it: { label: () => p.label, action: p.action } }; }
    for (const p of this.people) { if (!p.crew) continue; const d = Math.hypot(x - (O.x + p.x), z - (O.z + p.z)); if (d < 1.2 && (!best || d < best.d - 0.2)) best = { d, it: { label: () => `Parler à ${p.name}`, action: () => this.ui.toast(`${p.name} : « ${pick(['Puis-je vous servir une boisson ?', 'Le repas sera servi après le décollage.', 'Merci de garder la ceinture attachée lorsque vous êtes assis.', 'Bon voyage avec nous !'])} »`, 3) } }; }
    return best;
  }
  handleKeys(input) { if (input.hit('KeyE') || input.hit('Escape')) this.unsit(); }
  zoneLabel() { if (!this.inside) return null; const b = this.curB(); return b ? `En vol — ${this.num(b)} ${this.route(b)}` : 'Cabine d’avion'; }
  hum(on) {
    const A = this.audio; try { if (!on) { if (this._hum) { this._hum.g.gain.setTargetAtTime(0, A.ctx.currentTime, 0.3); const s = this._hum.s; setTimeout(() => { try { s.stop(); } catch (e) { /* déjà arrêté */ } }, 1500); this._hum = null; } return; }
      if (!A || !A.ctx || this._hum || !A.white) return; const s = A.loop(A.white), f = A.filter('lowpass', 260, 0.7), g = A.gain(0); s.connect(f).connect(g).connect(A.sfx); A.set(g.gain, 0.09, 0.8); this._hum = { s, g };
    } catch (e) { this._hum = null; }
  }
  announce(key, msg) { if (this._ann[key]) return; this._ann[key] = 1; this.ui.toast(msg, 5); }
  // ------------------------------------------------------------------ boucle
  update(dt) {
    this._chk = (this._chk || 0) - dt;
    if (this._chk < 0) { this._chk = 2; const a = this.abs(); for (const b of this.active()) if (a > b.at - 0.25) { b.state = 'manque'; this.ui.toast(`❌ Vol ${b.ref} (${this.D(b).num} → ${this.D(b).city}) manqué : porte fermée. Report possible dans NOVA TRAVEL.`, 5); this.save(); } }
    if (!this.inside) { if (this.cur && this.resume && !this.T.inside) { this.resume = false; this.enterCabin(true); } return; }
    const c = this.cur, P = this.player.pos; if (!c) { this.leaveCabin(); return; }
    if (Math.abs((P.y || CABIN.Y) - CABIN.Y) > 6 || Math.hypot(P.x - CABIN.O.x, P.z - CABIN.O.z) > 40) { this.inside = false; this.group.visible = false; this.world.collision.level = 0; this.player.floorY = 0; this.seated = false; this.clearPeople(); this.hum(false); this.ui.setActivity && this.ui.setActivity(''); return; }
    const ls = this.home && this.home.lights; if (ls) { if (this.T && !this.T._orig) this.T._orig = ls.map((l) => ({ p: l.position.clone(), d: l.distance })); ls.forEach((l, i) => { l.position.set(P.x - 5 + i * 5, CABIN.Y + 2.1, CABIN.O.z + (i === 1 ? 1 : -1)); l.distance = 12; l.decay = 1.2; l.intensity = 2.2; l.color.setHex(this.phase() === 'cruise' && (this.env.time > 20 || this.env.time < 6) ? 0x9a8cff : 0xfff0dc); }); }
    const b = this.curB(), D = b && this.D(b), ph = this.phase(), a = this.abs(), t = this.env.time;
    // hublots : tarmac au sol, ciel selon l'heure en vol
    const night = t > 19.2 || t < 5.6, dusk = (t > 17.6 && t <= 19.2) || (t >= 5.6 && t < 7);
    this.winMat.color.setHex(ph === 'board' || ph === 'landed' ? (night ? 0x1a2230 : 0x9aa6b0) : night ? 0x0a1430 : dusk ? 0xf0a060 : 0x8ec8f0);
    if (ph === 'board') this.announce('b', `🎙️ Commandant de bord : « Mesdames et messieurs, bienvenue à bord du vol ${this.num(b)} ${AIRLINES[D.air].name} à destination de ${c.back ? 'Cotonou' : D.city}. Durée prévue : ${dur(D.dur)}. »`);
    if (ph === 'takeoff') { if (!this.seated) this.sit(true); this.announce('t', '🛫 Décollage ! Les moteurs rugissent, l’avion s’élève au-dessus du golfe.'); }
    if (ph === 'cruise') this.announce('c', '🔔 Consigne lumineuse éteinte : tu peux te déplacer. Le service à bord commence.');
    if (ph === 'descent') { if (!this.seated) this.sit(true); this.announce('d', `🎙️ « Nous entamons notre descente vers ${c.back ? 'Cotonou' : D.city}. Merci de regagner vos sièges. »`); }
    if (ph === 'landed' && !this._ann.l) { this.announce('l', c.back ? '🛬 Atterrissage à Cotonou ! Bienvenue au Bénin. Utilise la porte de l’avion pour débarquer.' : `🛬 Atterrissage à ${D.city} ! Heure locale ${this.local(D)}. Ouvre la porte de l’avion ou « 🛬 Arrivée ».`); if (!c.back && b.state === 'vol') { b.state = 'arrive'; this.save(); } }
    if (this.ui.setActivity) this.ui.setActivity(`✈️ ${this.num(b)} ${this.route(b)} • ${{ board: `embarquement, décollage ${hh(c.dep)}`, takeoff: 'décollage', cruise: `croisière • arrivée dans ${dur(Math.max(0, c.arr - a))}`, descent: 'descente', landed: 'au sol' }[ph]}${ph === 'takeoff' || ph === 'descent' ? ' • 🔔 ceinture' : ''}`);
    if (this.seated) { if (this.ui.menuOpen && this.ui.menuOpen()) { if (this.dom) this.dom.classList.remove('show'); } else this.bar(); }
    for (const p of this.people) {
      if (p.seat) continue; if (p.wait > 0) { p.wait -= dt; p.c.animate(dt, 0); continue; }
      if (ph === 'takeoff' || ph === 'descent') { p.c.animate(dt, 0); continue; }
      const dx = p.tx - p.x; if (Math.abs(dx) < 0.1) { p.tx = -12 + Math.random() * 24; p.wait = 2 + Math.random() * 5; continue; }
      const s = Math.min(Math.abs(dx), p.speed * dt) * Math.sign(dx); p.x += s; p.h = dx > 0 ? PI / 2 : -PI / 2; p.c.group.position.set(p.x, 0, 0); p.c.group.rotation.y = p.h; p.c.animate(dt, p.speed);
    }
  }
  // ------------------------------------------------------------------ application NOVA TRAVEL (onglets réservation et « Mes voyages »)
  renderBook(id) {
    const D = DEST_BY_ID[id]; if (!D) return ''; const opts = this.options(D, 1), k = this.bk; if (k.i >= opts.length) k.i = 0; const dep = opts[k.i];
    const chip = (key, val, lab) => `<button data-tr="bk:${key}:${val}" class="${String(k[key]) === String(val) ? 'on' : ''}">${lab}</button>`;
    return `<h5>Réserver : Cotonou → ${esc(D.city)} (${esc(D.country)})</h5><p class="ph-note">${AIRLINES[D.air].name} ${D.num} • environ ${dur(D.dur)} • porte ${D.gate} • heure locale à l’arrivée affichée à bord. Passager : toi (voyages en famille à une prochaine étape).</p>
      <p class="ph-note"><b>Départ</b></p><div class="ph-chips">${opts.map((d, i) => chip('i', i, `${hh(d.h)} ${this.dayLabel(d.at)}`)).join('')}</div>
      <p class="ph-note"><b>Classe</b></p><div class="ph-chips">${chip('cls', 'eco', `Économique ${fcfa(D.eco)}`)}${chip('cls', 'biz', `Affaires ${fcfa(D.biz)}`)}</div>
      <p class="ph-note"><b>Bagages en soute</b> (inclus : ${FREE_BAGS[k.cls]} ; ${fcfa(BAG_FEE)} par bagage en plus)</p><div class="ph-chips">${[0, 1, 2, 3].map((n) => chip('bags', n, String(n))).join('')}</div>
      <p class="ph-note"><b>Trajet</b></p><div class="ph-chips">${chip('ret', false, 'Aller simple')}${chip('ret', true, 'Aller-retour (−10 % sur le retour)')}</div>
      ${dep ? `<div class="ph-row"><span><b>Total : ${fcfa(this.price(D, k.cls, k.bags, k.ret))}</b><small>${hh(dep.h)} ${this.dayLabel(dep.at)} • ${CLS[k.cls]} • ${k.bags} bagage${k.bags > 1 ? 's' : ''}${k.ret ? ' • retour à prendre à l’arrivée' : ''}</small></span><button class="ph-mini" data-tr="pay:${id}">Payer</button></div>` : '<p class="ph-note">Aucun départ disponible.</p>'}
      <div class="ph-chips"><button data-tr="tab:dest">← Destinations</button></div>`;
  }
  renderTrips() {
    const a = this.abs(), up = this.bookings.filter((b) => !['termine', 'annule'].includes(b.state)), past = this.bookings.filter((b) => ['termine', 'annule'].includes(b.state)).slice(0, 12);
    const row = (b) => { const D = this.D(b), [st, sc] = STATE[b.state] || ['', '#fff']; let btn = '';
      if (b.state === 'reserve' && b.at - a >= 3) btn = `<button class="ph-mini" data-tr="cancel:${b.ref}">Annuler (−30 %)</button>`;
      if (b.state === 'manque' && this.options(D, 1).length) btn = `<button class="ph-mini" data-tr="rebook:${b.ref}">Reporter (${fcfa(Math.round(b.price * 0.25))})</button>`;
      return `<div class="ph-row"><span><b>${this.num(b)} • ${esc(this.route(b))}</b><small>${b.ref} • ${hh(b.at)} ${['termine', 'annule'].includes(b.state) ? '' : this.dayLabel(b.at)} • ${CLS[b.cls]}${b.seat ? ` • place ${b.seat}` : ''}${b.ret ? ' • aller-retour' : ''} • ${fcfa(b.price)}</small></span><em style="color:${sc}">${st}</em>${btn}</div>`; };
    return `<h5>Voyages à venir</h5>${up.map(row).join('') || '<p class="ph-note">Aucune réservation. Choisis une destination pour réserver.</p>'}
      <p class="ph-note">Étapes : réserver → enregistrement au comptoir (de 3 h à 30 min avant) → contrôle de sûreté → porte (embarquement 45 min avant, fermeture 15 min avant).</p>
      <h5>Voyages passés</h5>${past.map(row).join('') || '<p class="ph-note">Aucun voyage passé.</p>'}`;
  }
  onPhone(a, arg, arg2) {
    if (a === 'book') { this.T.sel = arg; this.T.view = 'book'; this.bk.i = 0; }
    else if (a === 'bk') this.bk[arg] = arg === 'cls' ? arg2 : arg === 'ret' ? arg2 === 'true' : +arg2;
    else if (a === 'pay') { const D = DEST_BY_ID[arg], dep = this.options(D, 1)[this.bk.i]; if (dep && this.book(D, dep, this.bk.cls, this.bk.bags, this.bk.ret)) this.T.view = 'resa'; }
    else if (a === 'cancel' || a === 'rebook') { const b = this.bookings.find((q) => q.ref === arg); if (b) this[a](b); }
    else return false;
    return true;
  }
  serialize() { return { bookings: this.bookings, history: this.history, cur: this.cur, seq: this.seq }; }
  restore(s) { if (!s) return; this.bookings = s.bookings || []; this.history = s.history || []; this.cur = s.cur || null; this.seq = s.seq || 1; this.resume = !!this.cur; }
}
