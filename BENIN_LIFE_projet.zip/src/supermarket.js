// Mission 013, étape 3 — supermarché fictif « LAGUNA » (nom inventé, aucun lien avec une enseigne réelle).
// Bâtiment visitable : portes automatiques, rayons, réfrigérateurs, fruits et légumes, caisses avec caissières,
// panier, ticket de caisse, paiement en FCFA ; alarme si l'on sort sans passer à la caisse.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { SUPER_LOT } from './world.js';
import { FOOD_BY_ID, fcfa, stockOf } from './food-data.js';
import { ARTICLE_BY_ID } from './market-data.js';

const PI = Math.PI;
const NAME = 'LAGUNA';
const OPEN_H = 7, CLOSE_H = 22;
// bâtiment
const B = { x0: 25, x1: 59, z0: -141, z1: -119, h: 6 };
const DOOR = { x0: 40, x1: 44 };
const GOND = [41, 45.5, 50, 54.5];            // gondoles (axe x), de z -137 à -127
const G_Z0 = -137, G_Z1 = -127, G_W = 1.2;
const CHECKOUTS = [{ x: 28, staffed: false }, { x: 31.5, staffed: true }, { x: 35, staffed: true }];
const CK_Z = -123;

export const SECTIONS = {
  fruits: { label: 'Fruits & légumes', icon: '🥭', items: ['tomate', 'oignon', 'piment', 'gombo', 'feuilles', 'amarante', 'corete', 'aubergine', 'carotte', 'chou', 'laitue', 'poivron', 'concombre', 'ail', 'gingembre_racine', 'plantain', 'igname', 'manioc', 'patate_douce', 'taro', 'mangue', 'ananas', 'banane', 'orange', 'papaye', 'coco', 'pasteque', 'avocat', 'goyave', 'corossol', 'citron', 'mandarine', 'pomme_cajou', 'tamarin', 'pain_singe', 'pamplemousse'] },
  epicerie: { label: 'Épicerie', icon: '🥫', items: ['riz', 'farine_mais', 'mais_grains', 'mil', 'sorgho', 'fonio', 'farine_mil', 'farine_manioc', 'farine_ble', 'gari', 'tapioca', 'cossettes', 'haricots_secs', 'haricots_rouges', 'soja', 'voandzou', 'spaghetti', 'macaroni', 'concentre_tomate', 'sucre', 'sel', 'huile_rouge', 'huile_arachide', 'arachide', 'sardines', 'thon', 'lait_poudre', 'miel', 'margarine', 'afitin', 'poivre_guinee', 'girofle', 'piment_poudre', 'cube', 'laurier', 'crevettes_sechees', 'poisson_seche'] },
  boissons: { label: 'Boissons', icon: '🥤', items: ['eau', 'eau_sachet', 'soda', 'jus_orange', 'jus_ananas', 'jus_mangue', 'jus_tamarin', 'jus_corossol', 'citronnade', 'eau_coco', 'bissap', 'baobab', 'gingembre'] },
  snacks: { label: 'Pain & en-cas', icon: '🥖', items: ['pain', 'biscuits', 'chocolat', 'chips_plantain', 'nougat_arachide', 'noix_cajou', 'kuli_kuli', 'atchomon', 'arachides_grillees'] },
  hygiene: { label: 'Hygiène & maison', icon: '🧼', items: ['savon_noir', 'karite', 'dentifrice', 'gel_douche', 'lessive', 'papier_toilette', 'piles', 'bougies', 'lampe_solaire'] },
  frais: { label: 'Produits frais', icon: '🧊', items: ['lait', 'yaourt', 'degue', 'lait_caille', 'oeufs', 'fromage_soja', 'wagashi', 'poulet_frais', 'pintade', 'canard', 'boeuf', 'chevre', 'mouton', 'porc', 'aulacode', 'poisson_frais', 'tilapia', 'capitaine', 'bar', 'silure', 'maquereau', 'crevettes', 'crabes', 'poisson_fume'] },
  traiteur: { label: 'Traiteur (plats à emporter)', icon: '🍲', items: ['pate_rouge', 'pate_blanche', 'telibo', 'piron', 'to', 'yekeyeke', 'akassa', 'amiwo', 'watche', 'atassi', 'riz_gras', 'adowe', 'toubani', 'dakouin', 'sauce_arachide', 'sauce_gombo', 'sauce_crincrin', 'fontete', 'calalou', 'dja', 'sauce_graine', 'poisson_frit', 'poulet_grille', 'brochettes'] },
};
const GOND_SECTION = ['epicerie', 'boissons', 'snacks', 'hygiene'];
const r25 = (n) => Math.max(25, Math.round(n / 25) * 25);

// géométrie colorée par sommet (fusionnée en un seul maillage)
function colored(geo, hex, jitter = 0) {
  const g = geo.index ? geo.toNonIndexed() : geo, c = new THREE.Color(hex), n = g.attributes.position.count, a = new Float32Array(n * 3);
  const j = jitter ? 1 - jitter + Math.random() * jitter * 2 : 1;
  for (let i = 0; i < n; i++) { a[i * 3] = c.r * j; a[i * 3 + 1] = c.g * j; a[i * 3 + 2] = c.b * j; }
  g.setAttribute('color', new THREE.BufferAttribute(a, 3));
  if (g.attributes.uv) g.deleteAttribute('uv');
  return g;
}
function signTexture(lines, w = 1024, h = 256, bg = '#0b6e4f', fg = '#ffffff', accent = '#f2c200') {
  const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d');
  x.fillStyle = bg; x.fillRect(0, 0, w, h); x.fillStyle = accent; x.fillRect(0, h - 14, w, 14);
  x.fillStyle = fg; x.textAlign = 'center'; x.textBaseline = 'middle';
  x.font = `900 ${Math.round(h * (lines[1] ? 0.4 : 0.5))}px Arial`; x.fillText(lines[0], w / 2, lines[1] ? h * 0.38 : h * 0.47);
  if (lines[1]) { x.fillStyle = accent; x.font = `700 ${Math.round(h * 0.17)}px Arial`; x.fillText(lines[1], w / 2, h * 0.74); }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; return t;
}
const distRect = (x, z, r) => Math.hypot(Math.max(r.x0 - x, 0, x - r.x1), Math.max(r.z0 - z, 0, z - r.z1));

export class Supermarket {
  constructor(ctx) {
    Object.assign(this, ctx); // scene, world ; puis economy, kitchen, audio, ui, env, player (branchés ensuite)
    this.open = false; this.mode = 'shelf'; this.section = null; this.sel = null; this.basket = {};
    this.inside = false; this.wasInside = false; this.alarmT = 0;
    this.fixtures = [];
    this.stock = {}; this.stockDay = -1; this.restock();
    this.build();
    this.addPeople();
  }
  static get LOT() { return SUPER_LOT; }
  isOpenHour() { const h = this.env.time; return h >= OPEN_H && h < CLOSE_H; }
  isInside(x, z) { return x > B.x0 && x < B.x1 && z > B.z0 && z < B.z1; }
  price(id) { const f = FOOD_BY_ID[id]; return f ? r25(f.price * 1.1) : ARTICLE_BY_ID[id].price; }
  itemName(id) { return FOOD_BY_ID[id] ? FOOD_BY_ID[id].name : ARTICLE_BY_ID[id].name; }
  // stock du magasin : quantités limitées, réassort chaque matin à 7 h
  restock() { for (const S of Object.values(SECTIONS)) for (const id of S.items) this.stock[id] = FOOD_BY_ID[id] ? stockOf(FOOD_BY_ID[id]) : 15; }
  left(id) { return Math.max(0, (this.stock[id] ?? 0) - (this.basket[id] || 0)); }
  serialize() { return { stock: { ...this.stock }, day: this.stockDay }; }
  restore(s) { if (!s || !s.stock) return; for (const [k, v] of Object.entries(s.stock)) if (k in this.stock) this.stock[k] = Math.max(0, v | 0); this.stockDay = s.day ?? -1; }
  basketCount() { return Object.values(this.basket).reduce((a, b) => a + b, 0); }
  basketTotal() { return Object.entries(this.basket).reduce((a, [id, n]) => a + this.price(id) * n, 0); }

  // ------------------------------------------------------------------ construction
  build() {
    const L = SUPER_LOT, col = this.world.collision, g = new THREE.Group();
    this.group = g; this.upper = new THREE.Group(); g.add(this.upper);
    const parts = { std: [], shiny: [], glow: [] };
    const box = (w, h, d, x, y, z, hex, kind = 'std', j = 0) => parts[kind].push(colored(new THREE.BoxGeometry(w, h, d).translate(x, y, z), hex, j));
    // sol : parking et dalle intérieure
    box(L.x1 - L.x0, 0.06, L.z1 - L.z0, (L.x0 + L.x1) / 2, 0.03, (L.z0 + L.z1) / 2, 0x55585c);
    box(B.x1 - B.x0, 0.08, B.z1 - B.z0, (B.x0 + B.x1) / 2, 0.05, (B.z0 + B.z1) / 2, 0xbcb8ae);
    for (let i = 0; i < 17; i++) box(0.04, 0.005, B.z1 - B.z0, B.x0 + 2 * i, 0.093, (B.z0 + B.z1) / 2, 0xa8a49a); // joints de carrelage
    for (let i = 0; i < 9; i++) box(0.12, 0.02, 4.6, 27 + i * 3.6, 0.075, -113.6, 0xf2f2f2); // places de parking
    box(L.x1 - L.x0 - 6, 0.02, 0.15, (L.x0 + L.x1) / 2, 0.075, -116.2, 0xf2f2f2);
    // murs (fond, côtés) ; façade vitrée avec ouverture pour les portes
    const W = 0xf4f1ea, H = B.h, T = 0.3;
    box(B.x1 - B.x0, H, T, (B.x0 + B.x1) / 2, H / 2, B.z0, W);
    box(T, H, B.z1 - B.z0, B.x0, H / 2, (B.z0 + B.z1) / 2, W);
    box(T, H, B.z1 - B.z0, B.x1, H / 2, (B.z0 + B.z1) / 2, W);
    // bandeau vert à la base des murs (intérieur et extérieur)
    box(B.x1 - B.x0, 0.9, T + 0.04, (B.x0 + B.x1) / 2, 0.45, B.z0, 0x0b6e4f);
    for (const x of [B.x0, B.x1]) box(T + 0.04, 0.9, B.z1 - B.z0, x, 0.45, (B.z0 + B.z1) / 2, 0x0b6e4f);
    // façade : piliers + allège + linteau ; vitres dans un maillage à part
    for (const x of [B.x0, 30, 35, DOOR.x0, DOOR.x1, 49, 54, B.x1]) box(0.4, H, 0.4, x, H / 2, B.z1, 0x2a2d33);
    for (const [a, b] of [[B.x0, DOOR.x0], [DOOR.x1, B.x1]]) { box(b - a, 0.5, 0.3, (a + b) / 2, 0.25, B.z1, 0x2a2d33); }
    box(B.x1 - B.x0, 1.6, 0.5, (B.x0 + B.x1) / 2, H - 0.8, B.z1, 0x0b6e4f);
    // auvent au-dessus de l'entrée
    box(10, 0.25, 3, (DOOR.x0 + DOOR.x1) / 2, 3.6, B.z1 + 1.5, 0xf2c200);
    for (const x of [DOOR.x0 - 3, DOOR.x1 + 3]) box(0.15, 3.6, 0.15, x, 1.8, B.z1 + 2.9, 0x2a2d33);
    // collisions des murs et de la façade (ouverture libre entre DOOR.x0 et DOOR.x1)
    col.addBox(B.x0 - 0.2, B.z0 - 0.2, B.x1 + 0.2, B.z0 + 0.2, H);
    col.addBox(B.x0 - 0.2, B.z0, B.x0 + 0.2, B.z1, H);
    col.addBox(B.x1 - 0.2, B.z0, B.x1 + 0.2, B.z1, H);
    col.addBox(B.x0, B.z1 - 0.25, DOOR.x0 - 0.1, B.z1 + 0.25, H);
    col.addBox(DOOR.x1 + 0.1, B.z1 - 0.25, B.x1, B.z1 + 0.25, H);
    this.doorCol = col.addBox(DOOR.x0, B.z1 - 0.2, DOOR.x1, B.z1 + 0.2, H); this.doorCol.disabled = true;

    // ---- gondoles (rayonnages doubles) avec produits ----
    const palettes = { epicerie: [0xf6f4ee, 0x1f4e9c, 0xd82a1a, 0xf2e2a0, 0x8a5a3a, 0xd8461a, 0xc8102e], boissons: [0xd8eef8, 0xc8102e, 0xf08a20, 0x8a1030, 0x2a8a3a, 0xf2c200], snacks: [0xd8a050, 0xf2c200, 0x5a3a1a, 0xe8762a, 0x2f80ed], hygiene: [0x2f80ed, 0xffffff, 0x7a2a8a, 0x2a8a8a, 0xf2a0c0, 0xf2c200] };
    GOND.forEach((gx, gi) => {
      const sec = GOND_SECTION[gi], pal = palettes[sec], len = G_Z1 - G_Z0, cz = (G_Z0 + G_Z1) / 2;
      box(G_W, 0.15, len, gx, 0.08, cz, 0x3a3d42);              // socle
      box(0.08, 1.9, len, gx, 1.0, cz, 0xd8d8d8, 'shiny');      // dos
      for (const ez of [G_Z0, G_Z1]) box(G_W, 2.0, 0.08, gx, 1.0, ez, 0x0b6e4f); // têtes de gondole
      for (let lv = 0; lv < 4; lv++) {
        const y = 0.25 + lv * 0.45;
        box(G_W, 0.04, len, gx, y, cz, 0xcfd2d6, 'shiny');
        for (const s of [-1, 1]) {
          let z = G_Z0 + 0.15;
          while (z < G_Z1 - 0.3) {
            const w = 0.12 + Math.random() * 0.18, ph = 0.14 + Math.random() * 0.22, c = pal[Math.floor(Math.random() * pal.length)];
            const n = 1 + Math.floor(Math.random() * 3);
            for (let k = 0; k < n; k++) {
              if (sec === 'boissons' && Math.random() < 0.6) parts.std.push(colored(new THREE.CylinderGeometry(0.045, 0.045, ph + 0.08, 8).translate(gx + s * (0.15 + k * 0.14), y + 0.06 + (ph + 0.08) / 2, z + w / 2), c, 0.1));
              else box(0.12, ph, w * 0.9, gx + s * (0.15 + k * 0.14), y + 0.02 + ph / 2, z + w / 2, c, 'std', 0.12);
            }
            z += w + 0.02;
          }
        }
      }
      col.addBox(gx - G_W / 2, G_Z0 - 0.05, gx + G_W / 2, G_Z1 + 0.05, 2);
      this.fixtures.push({ sec, rect: { x0: gx - G_W / 2, x1: gx + G_W / 2, z0: G_Z0, z1: G_Z1 } });
    });
    // ---- réfrigérateurs vitrés au fond ----
    const FZ = B.z0 + 0.8;
    box(19, 2.2, 1.0, 48.5, 1.1, FZ, 0xf2f2f2, 'shiny');
    box(19, 0.25, 1.05, 48.5, 2.3, FZ, 0x2f80ed);
    for (let k = 0; k < 4; k++) for (let i = 0; i < 46; i++) {
      const c = [0xffffff, 0x2f80ed, 0xf6e8f0, 0xf2e8d8, 0xf0d0b8, 0x9aa4ac, 0xf2c200][Math.floor(Math.random() * 7)];
      box(0.3, 0.22 + Math.random() * 0.12, 0.3, 39.4 + i * 0.4, 0.35 + k * 0.48, FZ + 0.1, c, 'std', 0.1);
    }
    col.addBox(39, FZ - 0.5, 58, FZ + 0.55, 2.4);
    this.fixtures.push({ sec: 'frais', rect: { x0: 39, x1: 48.5, z0: FZ - 0.5, z1: FZ + 0.5 } });
    this.fixtures.push({ sec: 'traiteur', rect: { x0: 48.5, x1: 58, z0: FZ - 0.5, z1: FZ + 0.5 } });
    // ---- fruits et légumes : étals inclinés ----
    const fruitC = [0xd82a1a, 0xf0a020, 0xf2d230, 0x5a9a2a, 0xf08a20, 0xc89a6a, 0x2f7a2a, 0x6a4a2a, 0xe89a30];
    for (const [x, z] of [[29, -137.5], [34, -137.5], [29, -132.5], [34, -132.5]]) {
      box(3.6, 0.8, 2.2, x, 0.4, z, 0x8a5a3a);
      for (let i = 0; i < 6; i++) {
        const c = fruitC[Math.floor(Math.random() * fruitC.length)], cx = x - 1.5 + (i % 3) * 1.5, cz = z - 0.5 + Math.floor(i / 3) * 1.0;
        for (let k = 0; k < 9; k++) parts.std.push(colored(new THREE.IcosahedronGeometry(0.09 + Math.random() * 0.05, 0).translate(cx + (Math.random() - 0.5) * 1.0, 0.88 + Math.random() * 0.12, cz + (Math.random() - 0.5) * 0.7), c, 0.15));
      }
      col.addBox(x - 1.8, z - 1.1, x + 1.8, z + 1.1, 1);
      this.fixtures.push({ sec: 'fruits', rect: { x0: x - 1.8, x1: x + 1.8, z0: z - 1.1, z1: z + 1.1 } });
    }
    // ---- caisses ----
    for (const ck of CHECKOUTS) {
      box(0.9, 0.95, 2.6, ck.x, 0.48, CK_Z, 0x2a2d33);
      box(0.92, 0.06, 2.62, ck.x, 0.98, CK_Z, 0x8a8f96, 'shiny');
      box(0.5, 0.3, 0.4, ck.x - 0.15, 1.15, CK_Z - 0.7, 0x111418, 'shiny'); // terminal
      box(0.06, 1.6, 0.06, ck.x + 0.35, 1.8, CK_Z + 1.25, 0x2a2d33);
      parts.glow.push(colored(new THREE.BoxGeometry(0.1, 0.35, 0.5).translate(ck.x + 0.35, 2.75, CK_Z + 1.25), ck.staffed ? 0x2fd05a : 0xc8102e));
      col.addBox(ck.x - 0.45, CK_Z - 1.3, ck.x + 0.45, CK_Z + 1.3, 1.1);
      if (ck.staffed) this.fixtures.push({ sec: 'caisse', rect: { x0: ck.x + 0.45, x1: ck.x + 1.6, z0: CK_Z - 1.3, z1: CK_Z + 1.3 } });
    }
    // chariots rangés près de l'entrée
    for (let i = 0; i < 5; i++) { const x = 56 - i * 0.35; box(0.6, 0.55, 0.9, x, 0.7, -121.5, 0xb8bcc2, 'shiny'); }
    col.addBox(54.2, -122, 56.4, -121, 1);

    const mStd = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.75 });
    const mShiny = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.3, metalness: 0.2 });
    const mGlow = new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false });
    this.mats = { mStd };
    for (const [k, m] of [['std', mStd], ['shiny', mShiny], ['glow', mGlow]]) {
      if (!parts[k].length) continue;
      const mesh = new THREE.Mesh(mergeGeometries(parts[k]), m); mesh.castShadow = k !== 'glow'; mesh.receiveShadow = true; g.add(mesh);
    }
    // vitres de façade
    const glass = new THREE.MeshStandardMaterial({ color: 0x1a2a34, metalness: 0.3, roughness: 0.05, transparent: true, opacity: 0.45, depthWrite: false });
    const gl = [];
    for (const [a, b] of [[B.x0, DOOR.x0], [DOOR.x1, B.x1]]) gl.push(new THREE.BoxGeometry(b - a, H - 2.1, 0.06).translate((a + b) / 2, 0.5 + (H - 2.1) / 2, B.z1));
    const gm = new THREE.Mesh(mergeGeometries(gl), glass); gm.renderOrder = 2; g.add(gm);
    // portes coulissantes automatiques
    this.doors = [-1, 1].map((s) => { const m = new THREE.Mesh(new THREE.BoxGeometry(2, 3.2, 0.06), glass); m.position.set((DOOR.x0 + DOOR.x1) / 2 + s, 1.65, B.z1 - 0.12); m.renderOrder = 2; g.add(m); return { m, s }; });
    this.doorOpen = 0;
    // toit (masqué quand on est à l'intérieur) + plafonniers
    const roof = new THREE.Mesh(new THREE.BoxGeometry(B.x1 - B.x0 + 0.6, 0.3, B.z1 - B.z0 + 0.6), new THREE.MeshStandardMaterial({ color: 0x8a8f96, roughness: 0.8 }));
    roof.position.set((B.x0 + B.x1) / 2, H + 0.15, (B.z0 + B.z1) / 2); roof.castShadow = true; this.upper.add(roof);
    // enseigne principale (fictive)
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(14, 2.4), new THREE.MeshBasicMaterial({ map: signTexture([NAME, 'SUPERMARCHÉ • OUVERT DE 7 H À 22 H']), toneMapped: false }));
    sign.position.set((B.x0 + B.x1) / 2, H + 1.4, B.z1 + 0.3); g.add(sign);
    const sb = new THREE.Mesh(new THREE.BoxGeometry(14.4, 2.8, 0.3), new THREE.MeshStandardMaterial({ color: 0x0b6e4f })); sb.position.set((B.x0 + B.x1) / 2, H + 1.4, B.z1 + 0.12); g.add(sb);
    // totem sur le parking
    const totem = new THREE.Mesh(new THREE.BoxGeometry(0.4, 5, 0.4), new THREE.MeshStandardMaterial({ color: 0x2a2d33 })); totem.position.set(L.x1 - 3, 2.5, L.z1 - 1.5); g.add(totem);
    const tp = new THREE.Mesh(new THREE.PlaneGeometry(3.4, 1.6), new THREE.MeshBasicMaterial({ map: signTexture([NAME, 'supermarché'], 512, 256), toneMapped: false, side: THREE.DoubleSide }));
    tp.position.set(L.x1 - 3, 5.2, L.z1 - 1.5); g.add(tp); col.addCircle(L.x1 - 3, L.z1 - 1.5, 0.3, 5);
    // panneaux suspendus des rayons (visibles de l'intérieur)
    // panneaux de rayon posés sur les têtes de gondole et les murs (ne gênent pas la caméra plongeante)
    const hang = (label, x, y, z, w = 1.5, ry = 0) => { const p = new THREE.Mesh(new THREE.PlaneGeometry(w, w * 0.23), new THREE.MeshBasicMaterial({ map: signTexture([label], 512, 118), toneMapped: false })); p.position.set(x, y, z); p.rotation.y = ry; g.add(p); };
    GOND.forEach((gx, i) => hang(SECTIONS[GOND_SECTION[i]].label.toUpperCase(), gx, 1.55, G_Z1 + 0.05, 1.15));
    hang('FRUITS & LÉGUMES', B.x0 + 0.17, 3.0, -134.5, 4, PI / 2); hang('PRODUITS FRAIS', 43.7, 3.1, B.z0 + 0.17, 4.2); hang('TRAITEUR', 53.3, 3.1, B.z0 + 0.17, 4.2); hang('CAISSES', 31.5, 3.6, B.z1 - 0.2, 4, PI);
    this.scene.add(g);
  }
  // caissières et clients (personnages du système de piétons existant)
  addPeople() {
    const idle = this.world.idleSpots;
    for (const ck of CHECKOUTS) if (ck.staffed) idle.push({ x: ck.x - 0.85, z: CK_Z - 0.2, ry: PI / 2 });
    for (const [x, z, ry] of [[43.2, -133, PI / 2], [47.6, -130, -PI / 2], [52.2, -135, PI / 2], [33, -129.8, PI], [45, -138.6, PI]]) idle.push({ x, z, ry, carry: false });
  }

  // ------------------------------------------------------------------ interaction
  nearest(x, z) {
    if (!this.isInside(x, z)) {
      // devant les portes fermées
      if (!this.isOpenHour() && Math.abs(x - 42) < 3 && z > B.z1 && z < B.z1 + 3) return { d: z - B.z1, it: { label: () => `${NAME} est fermé (ouvert de ${OPEN_H} h à ${CLOSE_H} h)`, action: () => this.ui.toast(`Le supermarché ouvre à ${OPEN_H} h.`, 2) } };
      return null;
    }
    let best = null;
    for (const f of this.fixtures) { const d = distRect(x, z, f.rect); if (d < 1.4 && (!best || d < best.d)) best = { d, f }; }
    if (!best) return null;
    const sec = best.f.sec;
    if (sec === 'caisse') return { d: best.d, it: { label: () => this.basketCount() ? `Passer à la caisse (${this.basketCount()} article${this.basketCount() > 1 ? 's' : ''})` : 'Caisse (ton panier est vide)', action: () => this.toggle(true, 'caisse') } };
    return { d: best.d, it: { label: () => `Rayon ${SECTIONS[sec].label}`, action: () => this.toggle(true, 'shelf', sec) } };
  }

  update(dt, P, playerObj) {
    if (this.economy && this.economy.day !== this.stockDay) { if (this.stockDay !== -1) this.restock(); this.stockDay = this.economy.day; }
    // panier abandonné (téléportation, portail…) : reposé en rayon
    if (this.basketCount() && Math.hypot(P.x - 42, P.z + 130) > 40) { this.basket = {}; this.renderHud(); this.ui.toast('Les articles du panier ont été reposés en rayon.', 2.5); }
    const near = Math.hypot(P.x - 42, P.z + 130) < 140;
    this.group.visible = near;
    if (!near) { this.inside = false; this.lightRig(false); return; }
    const inside = !playerObj.inCar && this.isInside(P.x, P.z);
    this.inside = inside; this.upper.visible = !inside;
    // portes : s'ouvrent à l'approche (de l'extérieur seulement aux heures d'ouverture)
    const open = this.isOpenHour() || inside;
    const want = open && Math.abs(P.x - 42) < 4 && Math.abs(P.z - B.z1) < 4.5 ? 1 : 0;
    this.doorOpen += (want - this.doorOpen) * Math.min(1, dt * 5);
    for (const d of this.doors) d.m.position.x = (DOOR.x0 + DOOR.x1) / 2 + d.s * (1 + this.doorOpen * 1.9);
    this.doorCol.disabled = this.doorOpen > 0.6;
    // éclairage intérieur la nuit (pas de lumière dynamique : émission douce des matériaux)
    this.mats.mStd.emissive.setRGB(0.35, 0.35, 0.33); this.mats.mStd.emissiveIntensity = inside ? 0.04 + this.env.lightsOn * 0.1 : this.env.lightsOn * 0.12;
    // la nuit, les 3 lampes de la maison (éteintes car loin) éclairent l'intérieur : aucune lumière en plus
    this.lightRig(inside && this.env.lightsOn > 0.05);
    // sortie sans payer : alarme et retour à l'intérieur
    if (this.wasInside && !inside && this.basketCount() && !playerObj.inCar && P.z > B.z1 && P.z < B.z1 + 3) {
      P.z = B.z1 - 0.9; P.x = Math.min(DOOR.x1 - 0.6, Math.max(DOOR.x0 + 0.6, P.x));
      this.ui.toast('🚨 Passe d’abord à la caisse pour payer ton panier (ou repose les articles à la caisse).', 3);
      this.alarm();
    } else this.wasInside = inside;
  }
  lightRig(on) {
    const ls = this.home && this.home.lights; if (!ls) return;
    if (!this._orig) this._orig = ls.map((l) => ({ p: l.position.clone(), d: l.distance }));
    if (on) ls.forEach((l, i) => { l.position.set(31 + i * 11, 5.2, -130); l.distance = 19; l.decay = 1.2; l.intensity = 24 * Math.min(1, this.env.lightsOn * 1.5); });
    else if (this._borrowed) ls.forEach((l, i) => { l.position.copy(this._orig[i].p); l.distance = this._orig[i].d; l.decay = 1.6; l.intensity = 0; });
    this._borrowed = on;
  }
  alarm() {
    const a = this.audio; if (!a || !a.ctx) return;
    for (let k = 0; k < 6; k++) a.tone(k % 2 ? 1250 : 950, 0.16, 0.08, 'square', a.sfx, k * 0.17);
  }
  beep() { const a = this.audio; if (a && a.ctx) a.tone(2100, 0.07, 0.05, 'square'); }

  // ------------------------------------------------------------------ interface
  toggle(on = !this.open, mode = this.mode, sec = this.section) {
    this.open = on; this.dom.classList.toggle('show', on);
    if (on) {
      this.mode = mode; this.section = sec;
      if (mode === 'shelf') this.sel = SECTIONS[sec].items[0];
      if (this.kitchen && !this.kitchen.icons) this.kitchen.makeIcons();
      this._last = ''; this.renderUI();
      clearInterval(this._poll); this._poll = setInterval(() => { if (this.open) this.renderUI(); else clearInterval(this._poll); }, 400);
    } else clearInterval(this._poll);
    this.renderHud();
  }
  icon(id) {
    if (!FOOD_BY_ID[id]) return `<span class="mk-emo">${ARTICLE_BY_ID[id].icon}</span>`;
    const k = this.kitchen && this.kitchen.icons && this.kitchen.icons[id];
    return k ? `<img src="${k}" alt="">` : '<img alt="" style="visibility:hidden">';
  }
  desc(id) { return FOOD_BY_ID[id] ? FOOD_BY_ID[id].desc : ARTICLE_BY_ID[id].desc; }
  addBasket(id, d) {
    const n = Math.max(0, (this.basket[id] || 0) + d);
    if (d > 0 && this.basketCount() >= 40) { this.ui.toast('Ton panier est plein (40 articles).', 1.6); return; }
    if (d > 0 && this.left(id) <= 0) { this.ui.toast('Rupture de stock : réassort demain matin à 7 h.', 1.8); return; }
    if (n) this.basket[id] = n; else delete this.basket[id];
    if (d > 0 && this.audio && this.audio.ctx) this.audio.tone(660, 0.05, 0.04, 'triangle');
  }
  pay() {
    const n = this.basketCount(); if (!n) return;
    const total = this.basketTotal();
    if (!this.economy.pay(total, `Supermarché ${NAME} (${n} article${n > 1 ? 's' : ''})`, `${NAME} • caisse`)) return;
    let food = 0, other = 0;
    for (const [id, k] of Object.entries(this.basket)) { this.stock[id] = Math.max(0, (this.stock[id] ?? 0) - k); if (FOOD_BY_ID[id]) { this.economy.addToBag(id, k); food += k; } else { this.economy.addItem(id, k); other += k; } }
    this.receipt = { lines: Object.entries(this.basket).map(([id, k]) => [this.itemName(id), k, this.price(id) * k]), total, t: this.economy.stamp() };
    this.basket = {}; this.beep();
    this.economy.notify(`🧾 Merci de votre visite chez ${NAME} !${food ? ` ${food} aliment${food > 1 ? 's' : ''} dans ton sac` : ''}${other ? `, ${other} article${other > 1 ? 's' : ''} dans « Mes articles »` : ''}`);
    this.renderUI(); this.renderHud(); this.onSave && this.onSave();
  }
  renderHud() {
    const el = this.hud; if (!el) return;
    const n = this.basketCount();
    el.classList.toggle('show', n > 0);
    if (n) el.textContent = `🛒 ${n} article${n > 1 ? 's' : ''} • ${fcfa(this.basketTotal())}`;
  }
  renderUI() {
    const n = this.basketCount(), tot = this.basketTotal();
    let body;
    if (this.mode === 'shelf') {
      const S = SECTIONS[this.section], id = this.sel, q = this.basket[id] || 0;
      body = `<div class="mk-main">
        <div class="mk-grid">${S.items.map((it) => `<button class="mk-card${it === id ? ' sel' : ''}" data-it="${it}">${this.icon(it)}<b>${this.itemName(it)}</b><i>${this.left(it) || this.basket[it] ? fcfa(this.price(it)) : 'Rupture'}${this.basket[it] ? ` • 🛒${this.basket[it]}` : ''}</i></button>`).join('')}</div>
        <div class="mk-detail">${this.icon(id)}<h3>${this.itemName(id)}</h3><p>${this.desc(id)}</p>
          <p class="mk-price">Prix affiché : <b>${fcfa(this.price(id))}</b> • En rayon : <b>${this.left(id)}</b></p>
          <div class="mk-offer"><span>Dans le panier</span><button data-b="-1">−</button><b>${q}</b><button data-b="1">+</button></div>
          <button class="mk-buy" data-b="1" ${this.left(id) ? '' : 'disabled'}>${this.left(id) ? '🛒 AJOUTER AU PANIER' : 'RUPTURE DE STOCK'}</button>
          <p class="mk-note">Prix fixes : pas de négociation au supermarché. Paie à la caisse avant de sortir.</p>
        </div></div>`;
    } else {
      const rows = Object.entries(this.basket);
      body = `<div class="sm-receipt">${rows.length ? `<div class="sm-lines">${rows.map(([id, k]) => `<div class="sm-line"><span>${this.itemName(id)}</span><span class="sm-q"><button data-r="${id}:-1">−</button>${k}<button data-r="${id}:1">+</button></span><b>${fcfa(this.price(id) * k)}</b></div>`).join('')}</div>
          <div class="sm-total"><span>TOTAL</span><b>${fcfa(tot)}</b></div>
          <button class="mk-buy" data-pay ${this.economy.balance >= tot ? '' : 'disabled'}>${this.economy.balance >= tot ? `PAYER ${fcfa(tot)}` : 'SOLDE INSUFFISANT : retire des articles'}</button>
          <button class="mk-neg" data-clear>Reposer tous les articles</button>`
        : this.receipt ? `<div class="sm-ticket"><b>${NAME} — TICKET DE CAISSE</b><small>${this.receipt.t}</small>${this.receipt.lines.map(([nm, k, p]) => `<div class="sm-line"><span>${nm} ×${k}</span><b>${fcfa(p)}</b></div>`).join('')}<div class="sm-total"><span>PAYÉ</span><b>${fcfa(this.receipt.total)}</b></div><small>Merci de votre visite !</small></div>`
        : '<p class="mk-note">Ton panier est vide. Choisis des produits dans les rayons (E devant un rayon).</p>'}</div>`;
    }
    const html = `<div class="mk-box sm-box">
      <div class="mk-head"><span class="mk-av" style="background:#0b6e4f">${this.mode === 'shelf' ? SECTIONS[this.section].icon : '🧾'}</span>
        <div><h2>${this.mode === 'shelf' ? `Rayon ${SECTIONS[this.section].label}` : 'Caisse'}</h2><small>Supermarché ${NAME} (enseigne fictive)</small></div>
        <span class="mk-bal">🛒 ${n} • ${fcfa(tot)}</span><span class="mk-bal">💰 ${fcfa(this.economy.balance)}</span><button class="mk-x" data-close>✕</button></div>
      ${body}</div>`;
    if (html !== this._last) { const sc = this.dom.querySelector('.mk-grid, .sm-lines'); const st = sc ? sc.scrollTop : 0; this.dom.innerHTML = html; this._last = html; const g = this.dom.querySelector('.mk-grid, .sm-lines'); if (g) g.scrollTop = st; }
  }
  onClick(e) {
    const b = e.target.closest('[data-close],[data-it],[data-b],[data-r],[data-pay],[data-clear]');
    if (!b) { if (e.target === this.dom) this.toggle(false); return; }
    e.stopPropagation();
    if (this.audio && this.audio.ctx) this.audio.click();
    if (b.dataset.close !== undefined) return this.toggle(false);
    if (b.dataset.it) this.sel = b.dataset.it;
    else if (b.dataset.b) this.addBasket(this.sel, +b.dataset.b);
    else if (b.dataset.r) { const [id, d] = b.dataset.r.split(':'); this.addBasket(id, +d); }
    else if (b.dataset.pay !== undefined) return this.pay();
    else if (b.dataset.clear !== undefined) { this.basket = {}; this.receipt = null; }
    this.renderUI(); this.renderHud();
  }
  bindDom() {
    this.dom = document.querySelector('#shop'); this.hud = document.querySelector('#basket');
    this.dom.addEventListener('click', (e) => this.onClick(e));
  }
  handleKeys(input) { if (input.hit('Escape') || input.hit('KeyE')) this.toggle(false); }
}
