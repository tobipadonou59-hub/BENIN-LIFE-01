// Mission 014, étape 1 — siège de NOVA BOOK : immeuble moderne visitable (rez-de-chaussée + 5 étages),
// ascenseur et escaliers, réception, départements aménagés, employés au travail, machines d'impression animées,
// bureau du PDG (s'asseoir, éclairage personnalisable, écran mural de statistiques).
// Tout est procédural (aucune ressource payante). Seul l'étage où se trouve le joueur est affiché et animé.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { createCharacter, SKINS } from './character.js';
import { createCarMesh } from './vehicles.js';
import { NOVA_LOT } from './world.js';
import { FLOORS, JOBS, START_STAFF, BOOKS, GREETINGS, FEMALE } from './nova-data.js';

const PI = Math.PI;
export const NB = { x0: 42, x1: 76, z0: 16, z1: 40, fh: 4.2, levels: 6, doorX0: 57, doorX1: 61 };
const CORE_Z = 33.4;
const ELEV = { x: 45.5, z: 32.4 }, STAIRS = { x: 51.5, z: 32.4 };
const pick = (a) => a[Math.floor(Math.random() * a.length)];

export function colored(geo, hex) {
  const g = geo.index ? geo.toNonIndexed() : geo, c = new THREE.Color(hex), n = g.attributes.position.count, a = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { a[i * 3] = c.r; a[i * 3 + 1] = c.g; a[i * 3 + 2] = c.b; }
  g.setAttribute('color', new THREE.BufferAttribute(a, 3)); if (g.attributes.uv) g.deleteAttribute('uv'); return g;
}
export function canvasTex(w, h, draw) { const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; return t; }
// écrans des logiciels fictifs
function appScreen(name, accent, kind) {
  return canvasTex(256, 160, (x, w, h) => {
    x.fillStyle = '#16181d'; x.fillRect(0, 0, w, h); x.fillStyle = accent; x.fillRect(0, 0, w, 16);
    x.fillStyle = '#fff'; x.font = 'bold 11px sans-serif'; x.fillText(name, 6, 12);
    x.fillStyle = '#23262d'; x.fillRect(0, 16, 34, h); x.fillRect(w - 46, 16, 46, h);
    for (let i = 0; i < 6; i++) { x.fillStyle = ['#e46a1f', '#2f80ed', '#0b6e4f', '#f2c200', '#c8102e', '#7a2a8a'][i]; x.fillRect(8, 24 + i * 18, 18, 12); }
    if (kind === 'cover') { x.fillStyle = '#f4efe6'; x.fillRect(80, 24, 80, 120); x.fillStyle = accent; x.fillRect(80, 24, 80, 50); x.fillStyle = '#111'; x.font = 'bold 10px serif'; x.fillText('LES RIVES', 92, 92); x.fillText('DE LA LAGUNE', 86, 106); }
    else if (kind === 'page') { for (let p = 0; p < 2; p++) { x.fillStyle = '#f4f4f0'; x.fillRect(46 + p * 82, 24, 76, 112); x.fillStyle = '#999'; for (let l = 0; l < 14; l++) x.fillRect(52 + p * 82, 34 + l * 7, 60 - (l % 4) * 6, 2); } }
    else if (kind === 'code') { for (let l = 0; l < 13; l++) { x.fillStyle = ['#6ad1ff', '#f2c200', '#9be37a', '#e8e8e8'][l % 4]; x.fillRect(44 + (l % 3) * 10, 24 + l * 10, 60 + ((l * 37) % 90), 4); } }
    else if (kind === 'video') { x.fillStyle = '#2a4a6a'; x.fillRect(44, 22, 160, 80); x.fillStyle = '#f2c200'; x.beginPath(); x.moveTo(110, 48); x.lineTo(110, 76); x.lineTo(134, 62); x.fill(); for (let tr = 0; tr < 3; tr++) { x.fillStyle = ['#e46a1f', '#2f80ed', '#0b6e4f'][tr]; x.fillRect(44 + tr * 20, 110 + tr * 14, 110 - tr * 18, 10); } }
    else { x.fillStyle = '#2f80ed'; for (let b = 0; b < 8; b++) x.fillRect(50 + b * 18, 130 - b * 11, 12, b * 11 + 6); }
  });
}

export class NovaBook {
  constructor(ctx) {
    Object.assign(this, ctx); // scene, world, player, ui, audio, env, home, tpc, onSave
    this.level = 0; this.inside = false; this.open = false; this.seated = null; this.light = 0;
    this.points = []; this.workers = []; this.machines = []; this.screensLive = [];
    this.root = new THREE.Group(); this.scene.add(this.root);
    this.mats = {
      std: new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.75 }),
      shiny: new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.25, metalness: 0.3 }),
      glow: new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false }),
      glass: new THREE.MeshStandardMaterial({ color: 0x9fc4d8, roughness: 0.05, metalness: 0.2, transparent: true, opacity: 0.28, depthWrite: false }),
      facade: new THREE.MeshStandardMaterial({ color: 0x24465a, roughness: 0.08, metalness: 0.55, transparent: true, opacity: 0.62, depthWrite: false }),
    };
    this.tex = {
      design: appScreen('NovaDesign', '#e46a1f', 'cover'), page: appScreen('NovaPage', '#2f80ed', 'page'),
      code: appScreen('NovaCode', '#0b6e4f', 'code'), cut: appScreen('NovaCut', '#7a2a8a', 'video'), press: appScreen('NovaPress', '#c8102e', 'chart'), chart: appScreen('NovaGestion', '#1f4e9c', 'chart'),
    };
    this.buildSite();
    this.floors = FLOORS.map((f) => this.buildFloor(f.lv));
    this.staff = START_STAFF.map(([name, job, lv, seat]) => ({ name, job, lv, seat }));
    this.buildDom();
    this.setVisibility();
  }

  // ------------------------------------------------------------------ extérieur
  buildSite() {
    const L = NOVA_LOT, col = this.world.collision, g = new THREE.Group(); this.site = g; this.root.add(g);
    const P = { std: [], shiny: [], glow: [] };
    const box = (w, h, d, x, y, z, c, k = 'std') => P[k].push(colored(new THREE.BoxGeometry(w, h, d).translate(x, y, z), c));
    // parvis, parking réservé (à l'est), bordures
    box(L.x1 - L.x0, 0.06, L.z1 - L.z0, (L.x0 + L.x1) / 2, 0.03, (L.z0 + L.z1) / 2, 0xbdb7ad);
    box(12, 0.07, 44, 83.5, 0.04, 34, 0x45474c);
    for (let i = 0; i < 8; i++) box(5, 0.02, 0.12, 82, 0.085, 16 + i * 5, 0xf2f2f2);
    for (const [x, z] of [[40, 12], [40, 56], [88.5, 56]]) box(1, 0.9, 1, x, 0.45, z, 0x6a6e74);
    // auvent d'entrée, jardinières
    box(10, 0.3, 4, 59, 4.0, 14, 0x1d1f24, 'shiny');
    for (const x of [54.6, 63.4]) box(0.25, 4, 0.25, x, 2, 12.2, 0x1d1f24, 'shiny');
    for (const x of [46, 50, 68, 72]) { box(2.4, 0.6, 1.2, x, 0.3, 13, 0x8a8f96); box(2.2, 0.5, 1, x, 0.85, 13, 0x2f7a2a); }
    for (const x of [46, 50, 68, 72]) col.addBox(x - 1.2, 12.4, x + 1.2, 13.6, 1);
    // façade : bandeaux d'étage opaques, poteaux, toit avec acrotère
    const W = NB.x1 - NB.x0, D = NB.z1 - NB.z0, cx = (NB.x0 + NB.x1) / 2, cz = (NB.z0 + NB.z1) / 2;
    this.shellLv = [];
    for (let lv = 0; lv < NB.levels; lv++) {
      const sg = new THREE.Group(), y0 = lv * NB.fh, parts = { std: [], shiny: [] }, glass = [];
      const sbox = (w, h, d, x, y, z, c, k = 'std') => parts[k].push(colored(new THREE.BoxGeometry(w, h, d).translate(x, y, z), c));
      sbox(W + 0.4, 0.6, 0.5, cx, y0 + NB.fh - 0.15, NB.z0, 0xe8e6e0); sbox(W + 0.4, 0.6, 0.5, cx, y0 + NB.fh - 0.15, NB.z1, 0xe8e6e0);
      sbox(0.5, 0.6, D, NB.x0, y0 + NB.fh - 0.15, cz, 0xe8e6e0); sbox(0.5, 0.6, D, NB.x1, y0 + NB.fh - 0.15, cz, 0xe8e6e0);
      for (let x = NB.x0; x <= NB.x1 + 0.01; x += W / 6) for (const z of [NB.z0, NB.z1]) sbox(0.35, NB.fh, 0.4, x, y0 + NB.fh / 2, z, 0x2a2d33, 'shiny');
      for (let z = NB.z0; z <= NB.z1 + 0.01; z += D / 4) for (const x of [NB.x0, NB.x1]) sbox(0.4, NB.fh, 0.35, x, y0 + NB.fh / 2, z, 0x2a2d33, 'shiny');
      // vitrages (rez-de-chaussée : ouverture des portes)
      const gh = NB.fh - 0.6, gy = y0 + gh / 2;
      if (lv === 0) { glass.push(new THREE.BoxGeometry(NB.doorX0 - NB.x0, gh, 0.06).translate((NB.x0 + NB.doorX0) / 2, gy, NB.z0)); glass.push(new THREE.BoxGeometry(NB.x1 - NB.doorX1, gh, 0.06).translate((NB.doorX1 + NB.x1) / 2, gy, NB.z0)); }
      else glass.push(new THREE.BoxGeometry(W, gh, 0.06).translate(cx, gy, NB.z0));
      glass.push(new THREE.BoxGeometry(W, gh, 0.06).translate(cx, gy, NB.z1)); glass.push(new THREE.BoxGeometry(0.06, gh, D).translate(NB.x0, gy, cz)); glass.push(new THREE.BoxGeometry(0.06, gh, D).translate(NB.x1, gy, cz));
      for (const k of ['std', 'shiny']) { const m = new THREE.Mesh(mergeGeometries(parts[k]), this.mats[k]); m.castShadow = true; sg.add(m); }
      const gm = new THREE.Mesh(mergeGeometries(glass), this.mats.facade); gm.renderOrder = 2; sg.add(gm);
      // murs (collisions) de cet étage, ouverture des portes au rez-de-chaussée
      const t = 0.3, add = (a, b, c2, d) => { const o = col.addBox(a, b, c2, d, 50); o.lv = lv; };
      if (lv === 0) { add(NB.x0 - t, NB.z0 - t, NB.doorX0, NB.z0 + t); add(NB.doorX1, NB.z0 - t, NB.x1 + t, NB.z0 + t); }
      else add(NB.x0 - t, NB.z0 - t, NB.x1 + t, NB.z0 + t);
      add(NB.x0 - t, NB.z1 - t, NB.x1 + t, NB.z1 + t); add(NB.x0 - t, NB.z0, NB.x0 + t, NB.z1); add(NB.x1 - t, NB.z0, NB.x1 + t, NB.z1);
      this.root.add(sg); this.shellLv.push(sg);
    }
    // à l'extérieur, le bâtiment entier bloque le passage sauf par la porte (étage 0 seulement)
    // toit, acrotère, enseigne lumineuse NOVA BOOK, enseigne verticale
    const roof = new THREE.Group(), top = NB.levels * NB.fh;
    const rp = [];
    rp.push(colored(new THREE.BoxGeometry(W + 0.6, 0.4, D + 0.6).translate(cx, top + 0.2, cz), 0x8a8f96));
    for (const [w, d, x, z] of [[W + 0.6, 0.3, cx, NB.z0], [W + 0.6, 0.3, cx, NB.z1], [0.3, D + 0.6, NB.x0, cz], [0.3, D + 0.6, NB.x1, cz]]) rp.push(colored(new THREE.BoxGeometry(w, 1.2, d).translate(x, top + 0.8, z), 0xe8e6e0));
    rp.push(colored(new THREE.BoxGeometry(6, 2.4, 5).translate(48, top + 1.4, 36), 0xb8bcc2));
    roof.add(new THREE.Mesh(mergeGeometries(rp), this.mats.std));
    this.signMat = new THREE.MeshBasicMaterial({ map: canvasTex(1024, 256, (x, w, h) => { x.fillStyle = '#0b1220'; x.fillRect(0, 0, w, h); x.fillStyle = '#ffffff'; x.font = '900 150px Arial'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('NOVA', w * 0.33, h * 0.52); x.fillStyle = '#f2c200'; x.fillText('BOOK', w * 0.74, h * 0.52); x.fillStyle = '#e46a1f'; x.fillRect(w * 0.12, h - 22, w * 0.76, 8); }), toneMapped: false });
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(16, 4), this.signMat); sign.position.set(cx, top + 3.2, NB.z0 - 0.05); sign.rotation.y = PI; roof.add(sign);
    const sb = new THREE.Mesh(new THREE.BoxGeometry(16.4, 4.4, 0.3), new THREE.MeshStandardMaterial({ color: 0x0b1220 })); sb.position.set(cx, top + 3.2, NB.z0 + 0.15); roof.add(sb);
    const vMat = new THREE.MeshBasicMaterial({ map: canvasTex(128, 512, (x, w, h) => { x.fillStyle = '#e46a1f'; x.fillRect(0, 0, w, h); x.fillStyle = '#fff'; x.font = '900 64px Arial'; x.textAlign = 'center'; [...'NOVA'].forEach((ch, i) => x.fillText(ch, w / 2, 90 + i * 110)); }), toneMapped: false });
    const vs = new THREE.Mesh(new THREE.BoxGeometry(1.4, 14, 1.4), [this.mats.std, this.mats.std, this.mats.std, this.mats.std, vMat, vMat]); vs.position.set(NB.x1 - 0.2, 12, NB.z0 - 0.9); roof.add(vs);
    const entry = new THREE.Mesh(new THREE.PlaneGeometry(6, 1), new THREE.MeshBasicMaterial({ map: canvasTex(512, 96, (x, w, h) => { x.fillStyle = '#0b1220'; x.fillRect(0, 0, w, h); x.fillStyle = '#fff'; x.font = 'bold 44px Arial'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('NOVA BOOK • ACCUEIL', w / 2, h / 2); }), toneMapped: false }));
    entry.position.set(59, 4.6, 12.1); entry.rotation.y = PI; roof.add(entry);
    const ps = new THREE.Mesh(new THREE.PlaneGeometry(3.6, 1.2), new THREE.MeshBasicMaterial({ map: canvasTex(384, 128, (x, w, h) => { x.fillStyle = '#1f4e9c'; x.fillRect(0, 0, w, h); x.fillStyle = '#fff'; x.font = 'bold 34px Arial'; x.textAlign = 'center'; x.fillText('P  NOVA BOOK', w / 2, 52); x.font = '22px Arial'; x.fillText('employés et visiteurs', w / 2, 96); }), toneMapped: false, side: THREE.DoubleSide }));
    ps.position.set(83.5, 2.4, 11.2); roof.add(ps);
    this.root.add(roof); this.roof = roof;
    for (const k of ['std', 'shiny']) { const m = new THREE.Mesh(mergeGeometries(P[k]), this.mats[k]); m.receiveShadow = true; g.add(m); }
    // voitures garées sur le parking
    for (const [x, z, c] of [[82, 18.5, 0xf2f2f2], [82, 28.5, 0x1a1a1a], [82, 38.5, 0x7a1010], [82, 48.5, 0x9aa0a6]]) { const m = createCarMesh(c, 'sedan'); m.group.position.set(x, 0, z); m.group.rotation.y = PI / 2; g.add(m.group); col.addBox(x - 2.3, z - 1, x + 2.3, z + 1, 1.5); }
    // ---- entrée principale (complément mission 015) : allée piétonne, bornes lumineuses, appliques, totem, barrière ----
    this.extGlow = new THREE.MeshBasicMaterial({ color: 0xfff0c8, toneMapped: false });
    const ent = [], glowG = [];
    ent.push(colored(new THREE.BoxGeometry(6, 0.05, 6.2).translate(59, 0.075, 12.9), 0x2a2d33));                       // allée en pierre sombre
    for (let k = 0; k < 6; k++) ent.push(colored(new THREE.BoxGeometry(5.6, 0.02, 0.12).translate(59, 0.105, 10.4 + k * 1.0), 0xf2c200)); // bandes de guidage
    for (const x of [55.6, 62.4]) for (const z of [10.6, 12.6, 14.6]) { ent.push(colored(new THREE.CylinderGeometry(0.1, 0.12, 0.9, 10).translate(x, 0.45, z), 0x1d1f24)); glowG.push(new THREE.CylinderGeometry(0.105, 0.105, 0.18, 10).translate(x, 0.82, z)); col.addCircle(x, z, 0.15, 1); }
    for (const x of [56.2, 61.8]) { ent.push(colored(new THREE.BoxGeometry(0.3, 0.5, 0.18).translate(x, 3.1, NB.z0 - 0.15), 0x1d1f24)); glowG.push(new THREE.BoxGeometry(0.22, 0.12, 0.2).translate(x, 2.9, NB.z0 - 0.2)); } // appliques
    // lampadaires du parking et du parvis
    for (const [x, z] of [[78.5, 14], [78.5, 34], [78.5, 54], [44, 11]]) { ent.push(colored(new THREE.CylinderGeometry(0.07, 0.09, 5, 8).translate(x, 2.5, z), 0x2a2d33)); glowG.push(new THREE.BoxGeometry(0.7, 0.12, 0.3).translate(x, 5.05, z)); col.addCircle(x, z, 0.15, 5); }
    // barrière du parking (accès véhicules)
    ent.push(colored(new THREE.BoxGeometry(0.4, 1.1, 0.4).translate(78.6, 0.55, 11.4), 0xc8102e));
    const arm = new THREE.Mesh(new THREE.BoxGeometry(4.6, 0.1, 0.1), new THREE.MeshStandardMaterial({ color: 0xf2f2f2 })); arm.position.set(81.1, 1.0, 11.4); g.add(arm); this.barrier = arm;
    for (let k = 0; k < 4; k++) { const st = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.105, 0.11), new THREE.MeshBasicMaterial({ color: 0xc8102e })); st.position.set(79.4 + k * 1.1, 1.0, 11.4); g.add(st); this.barrierStripes = (this.barrierStripes || []).concat(st); }
    g.add(new THREE.Mesh(mergeGeometries(ent), this.mats.std));
    g.add(new THREE.Mesh(mergeGeometries(glowG), this.extGlow));
    // totem à l'entrée du parvis + panneau « ENTRÉE PRINCIPALE » au-dessus des portes
    const totemTex = canvasTex(256, 640, (x, w, h) => { x.fillStyle = '#0b1220'; x.fillRect(0, 0, w, h); x.fillStyle = '#ffffff'; x.font = '900 64px Arial'; x.textAlign = 'center'; x.fillText('NOVA', w / 2, 120); x.fillStyle = '#f2c200'; x.fillText('BOOK', w / 2, 190); x.fillStyle = '#e46a1f'; x.fillRect(40, 220, w - 80, 6); x.fillStyle = '#fff'; x.font = 'bold 26px Arial'; ['Siège social', 'Édition', 'Graphisme', 'Impression', '', 'Accueil →', 'Parking →'].forEach((t, i) => x.fillText(t, w / 2, 290 + i * 44)); });
    const totem = new THREE.Mesh(new THREE.BoxGeometry(1.2, 3.0, 0.4), [this.mats.std, this.mats.std, this.mats.std, this.mats.std, new THREE.MeshBasicMaterial({ map: totemTex, toneMapped: false }), new THREE.MeshBasicMaterial({ map: totemTex, toneMapped: false })]);
    totem.position.set(53.4, 1.5, 10.9); totem.rotation.y = PI; g.add(totem); col.addBox(52.8, 10.7, 54, 11.1, 3);
    const ep = new THREE.Mesh(new THREE.PlaneGeometry(4.4, 0.55), new THREE.MeshBasicMaterial({ map: canvasTex(512, 64, (x, w, h) => { x.fillStyle = '#f2c200'; x.fillRect(0, 0, w, h); x.fillStyle = '#0b1220'; x.font = '900 40px Arial'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('ENTRÉE PRINCIPALE', w / 2, h / 2 + 2); }), toneMapped: false }));
    ep.position.set(59, 3.55, NB.z0 - 0.06); ep.rotation.y = PI; g.add(ep);
    const pk = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 0.5), new THREE.MeshBasicMaterial({ map: canvasTex(256, 80, (x, w, h) => { x.fillStyle = '#1f4e9c'; x.fillRect(0, 0, w, h); x.fillStyle = '#fff'; x.font = 'bold 34px Arial'; x.textAlign = 'center'; x.fillText('P ENTRÉE', w / 2, 52); }), toneMapped: false, side: THREE.DoubleSide }));
    pk.position.set(78.6, 1.45, 11.2); g.add(pk);
    // portes coulissantes de l'entrée
    this.doors = [-1, 1].map((s) => { const m = new THREE.Mesh(new THREE.BoxGeometry(2, 3.2, 0.06), this.mats.facade); m.position.set(59 + s, 1.6, NB.z0 + 0.12); this.root.add(m); return { m, s }; });
    this.doorOpen = 0;
  }

  // ------------------------------------------------------------------ intérieurs
  buildFloor(lv) {
    const y0 = lv * NB.fh, col = this.world.collision, fg = new THREE.Group();
    const P = { std: [], shiny: [], glow: [] }, screens = {}, glass = [];
    const box = (w, h, d, x, y, z, c, k = 'std') => P[k].push(colored(new THREE.BoxGeometry(w, h, d).translate(x, y0 + y, z), c));
    const solid = (x0, z0, x1, z1, h = 1.2) => { const o = col.addBox(x0, z0, x1, z1, y0 + h); o.lv = lv; };
    const screen = (tex, w, h, x, y, z, ry = 0) => { const g = new THREE.PlaneGeometry(w, h); g.rotateY(ry); g.translate(x, y0 + y, z); (screens[tex] || (screens[tex] = [])).push(g); };
    const pane = (w, h, d, x, y, z) => glass.push(new THREE.BoxGeometry(w, h, d).translate(x, y0 + y, z));
    // sol, plafond (dalle de l'étage supérieur), noyau (ascenseur, escalier, sanitaires)
    box(NB.x1 - NB.x0, 0.12, NB.z1 - NB.z0, (NB.x0 + NB.x1) / 2, 0.06, (NB.z0 + NB.z1) / 2, [0x8e877c, 0x7c8590, 0x8a6a4c, 0x6c727c, 0x75797f, 0x5a3e2a][lv]); // sols : pierre, gris bleuté, parquet, gris, béton, bois sombre
    if (lv === 5) box(15.6, 0.02, 16.8, 68, 0.13, 24.6, 0x2a3a4a); // moquette du bureau du PDG
    box(12.6, NB.fh, 0.25, 48.3, NB.fh / 2, CORE_Z, 0xe8e6e0); box(0.25, NB.fh, NB.z1 - CORE_Z, 54.6, NB.fh / 2, (CORE_Z + NB.z1) / 2, 0xe8e6e0);
    box(2.2, 2.6, 0.08, ELEV.x, 1.3, CORE_Z - 0.14, 0xb8bcc2, 'shiny'); box(0.3, 0.5, 0.06, ELEV.x + 1.5, 1.4, CORE_Z - 0.16, 0x111418, 'shiny');
    P.glow.push(colored(new THREE.PlaneGeometry(0.5, 0.25).rotateY(PI).translate(ELEV.x, y0 + 2.9, CORE_Z - 0.2), 0xf2c200));
    for (let k = 0; k < 8; k++) box(2.6, 0.18, 0.5, STAIRS.x, 0.09 + k * 0.18, CORE_Z + 0.4 + k * 0.5, 0x8a8f96); // départ d'escalier
    box(0.08, 1.0, 4, STAIRS.x - 1.4, 0.9, CORE_Z + 2, 0x2a2d33, 'shiny');
    solid(NB.x0, CORE_Z - 0.2, 54.8, NB.z1, 50);
    // sanitaires Hommes / Femmes : construits par NovaPlus (mission 016)
    // panneau de l'étage
    const lab = new THREE.Mesh(new THREE.PlaneGeometry(3.4, 0.7), new THREE.MeshBasicMaterial({ map: canvasTex(512, 104, (x, w, h) => { x.fillStyle = '#0b1220'; x.fillRect(0, 0, w, h); x.fillStyle = '#f2c200'; x.font = 'bold 40px Arial'; x.fillText(FLOORS[lv].name.toUpperCase(), 14, 44); x.fillStyle = '#fff'; x.font = '28px Arial'; x.fillText(FLOORS[lv].sub, 14, 86); }), toneMapped: false }));
    lab.position.set(50.3, y0 + 3.2, CORE_Z - 0.16); lab.rotation.y = PI; fg.add(lab);
    // mobilier utilitaires
    const desk = (x, z, ry, mon = 1, tex = 'page', extra = null) => {
      const dz = ry === PI ? 1 : -1; // l'employé est du côté +z du bureau s'il regarde vers −z (ry = π)
      box(1.8, 0.06, 0.9, x, 0.76, z, 0xe8e2d6); box(0.06, 0.74, 0.8, x - 0.85, 0.37, z, 0x3a3d42); box(0.06, 0.74, 0.8, x + 0.85, 0.37, z, 0x3a3d42);
      for (let m = 0; m < mon; m++) { const mx = x + (m - (mon - 1) / 2) * 0.62; box(0.6, 0.38, 0.04, mx, 1.12, z - dz * 0.25, 0x111418, 'shiny'); box(0.06, 0.3, 0.06, mx, 0.92, z - dz * 0.25, 0x2a2d33); screen(tex, 0.56, 0.34, mx, 1.12, z - dz * 0.25 + dz * 0.025, ry === PI ? 0 : PI); }
      box(0.45, 0.02, 0.15, x, 0.8, z + dz * 0.15, 0x22252a);
      if (extra === 'tablet') { box(0.32, 0.015, 0.22, x + 0.55, 0.8, z + dz * 0.1, 0x111418, 'shiny'); P.glow.push(colored(new THREE.PlaneGeometry(0.26, 0.17).rotateX(-PI / 2).translate(x + 0.55, y0 + 0.81, z + dz * 0.1), 0x4a90c8)); }
      // chaise
      box(0.5, 0.08, 0.5, x, 0.48, z + dz * 0.75, 0x1d1f24); box(0.5, 0.6, 0.06, x, 0.82, z + dz * 1.0, 0x1d1f24); box(0.06, 0.44, 0.06, x, 0.24, z + dz * 0.75, 0x8a8f96);
      solid(x - 0.95, z - 0.47, x + 0.95, z + 0.47);
      return { x, z: z + dz * 0.72, ry: ry === PI ? PI : 0 };
    };
    const shelf = (x, z, w, rot = 0, books = true) => {
      const W2 = rot ? 0.4 : w, D2 = rot ? w : 0.4; box(W2, 2.2, D2, x, 1.1, z, 0x6a4a32);
      if (books) for (let r = 0; r < 4; r++) for (let i = 0; i < w / 0.12 - 1; i++) { const c = [0xc8102e, 0x1f4e9c, 0xf2c200, 0x0b6e4f, 0xe46a1f, 0xf2f2f2][(i * 7 + r * 3) % 6]; const off = -w / 2 + 0.12 + i * 0.12; box(rot ? 0.3 : 0.1, 0.32, rot ? 0.1 : 0.3, x + (rot ? 0 : off), 0.35 + r * 0.5, z + (rot ? off : 0), c); }
      solid(x - W2 / 2, z - D2 / 2, x + W2 / 2, z + D2 / 2, 2.2);
    };
    const plant = (x, z) => { box(0.5, 0.5, 0.5, x, 0.25, z, 0xe8e2d6); P.std.push(colored(new THREE.SphereGeometry(0.55, 8, 6).scale(1, 1.4, 1).translate(x, y0 + 1.2, z), 0x2f7a2a)); solid(x - 0.3, z - 0.3, x + 0.3, z + 0.3); };
    const sofa = (x, z, w, ry = 0) => { const rot = Math.abs(Math.sin(ry)) > 0.5; const W2 = rot ? 0.9 : w, D2 = rot ? w : 0.9; box(W2, 0.45, D2, x, 0.3, z, 0x2a3a4a); const bx = rot ? x + Math.sin(ry) * -0.38 : x, bz = rot ? z : z - Math.cos(ry) * 0.38; box(rot ? 0.2 : w, 0.9, rot ? w : 0.2, bx, 0.55, bz, 0x223040); solid(x - W2 / 2, z - D2 / 2, x + W2 / 2, z + D2 / 2, 1); return { x, z, ry }; };
    const table = (x, z, w, d, c = 0xe8e2d6) => { box(w, 0.06, d, x, 0.75, z, c); box(0.1, 0.72, 0.1, x, 0.36, z, 0x3a3d42); solid(x - w / 2, z - d / 2, x + w / 2, z + d / 2); };
    const chairAt = (x, z) => { box(0.48, 0.08, 0.48, x, 0.47, z, 0x1d1f24); box(0.06, 0.44, 0.06, x, 0.24, z, 0x8a8f96); };
    const glassRoom = (x0, z0, x1, z1, doorSide = 'e') => {
      const h = NB.fh - 0.3, y = h / 2;
      if (doorSide !== 'n') pane(x1 - x0, h, 0.05, (x0 + x1) / 2, y, z0); else { pane((x1 - x0) / 2 - 0.6, h, 0.05, x0 + ((x1 - x0) / 2 - 0.6) / 2, y, z0); pane((x1 - x0) / 2 - 0.6, h, 0.05, x1 - ((x1 - x0) / 2 - 0.6) / 2, y, z0); }
      if (doorSide !== 's') pane(x1 - x0, h, 0.05, (x0 + x1) / 2, y, z1); else { pane((x1 - x0) / 2 - 0.6, h, 0.05, x0 + ((x1 - x0) / 2 - 0.6) / 2, y, z1); pane((x1 - x0) / 2 - 0.6, h, 0.05, x1 - ((x1 - x0) / 2 - 0.6) / 2, y, z1); }
      if (doorSide !== 'e') pane(0.05, h, z1 - z0, x1, y, (z0 + z1) / 2); else { pane(0.05, h, (z1 - z0) / 2 - 0.6, x1, y, z0 + ((z1 - z0) / 2 - 0.6) / 2); pane(0.05, h, (z1 - z0) / 2 - 0.6, x1, y, z1 - ((z1 - z0) / 2 - 0.6) / 2); }
      const wd = doorSide && doorSide.w; // ouverture d'une porte sur la paroi ouest : [z début, z fin]
      if (wd) { pane(0.05, h, wd[0] - z0, x0, y, (z0 + wd[0]) / 2); pane(0.05, h, z1 - wd[1], x0, y, (wd[1] + z1) / 2); pane(0.05, h - 2.4, wd[1] - wd[0], x0, 2.4 + (h - 2.4) / 2, (wd[0] + wd[1]) / 2); }
      else pane(0.05, h, z1 - z0, x0, y, (z0 + z1) / 2);
      const t = 0.08, mid = (a, b) => (a + b) / 2;
      if (doorSide === 'n') { solid(x0, z0 - t, mid(x0, x1) - 0.6, z0 + t, 50); solid(mid(x0, x1) + 0.6, z0 - t, x1, z0 + t, 50); } else solid(x0, z0 - t, x1, z0 + t, 50);
      if (doorSide === 's') { solid(x0, z1 - t, mid(x0, x1) - 0.6, z1 + t, 50); solid(mid(x0, x1) + 0.6, z1 - t, x1, z1 + t, 50); } else solid(x0, z1 - t, x1, z1 + t, 50);
      if (doorSide === 'e') { solid(x1 - t, z0, x1 + t, mid(z0, z1) - 0.6, 50); solid(x1 - t, mid(z0, z1) + 0.6, x1 + t, z1, 50); } else solid(x1 - t, z0, x1 + t, z1, 50);
      if (wd) { solid(x0 - t, z0, x0 + t, wd[0], 50); solid(x0 - t, wd[1], x0 + t, z1, 50); } else solid(x0 - t, z0, x0 + t, z1, 50);
      box(x1 - x0, 0.1, 0.12, mid(x0, x1), NB.fh - 0.35, z0, 0x2a2d33, 'shiny'); box(x1 - x0, 0.1, 0.12, mid(x0, x1), NB.fh - 0.35, z1, 0x2a2d33, 'shiny');
    };
    const posterWall = (x, z, ry, n, w = 1.2) => { for (let i = 0; i < n; i++) { const c = [0xe46a1f, 0x2f80ed, 0xc8102e, 0x0b6e4f, 0xf2c200, 0x7a2a8a][i % 6]; const off = (i - (n - 1) / 2) * (w + 0.3); P.glow.push(colored(new THREE.PlaneGeometry(w, w * 1.4).rotateY(ry).translate(x + (Math.abs(Math.sin(ry)) > 0.5 ? 0 : off), y0 + 2, z + (Math.abs(Math.sin(ry)) > 0.5 ? off : 0)), c)); } };
    const seats = []; // postes de travail (x, z, ry) dans l'ordre des employés
    const pts = (label, x, z, action, r = 1.6) => this.points.push({ lv, x, z, r, label, action });

    if (lv === 0) {
      // réception, mur logo, espace d'attente, présentation des livres, commercial & clientèle, salle de réunion
      box(6, 1.1, 0.8, 59, 0.55, 22, 0xf2f2f2, 'shiny'); box(6.2, 0.06, 1.0, 59, 1.13, 22, 0x2a2d33, 'shiny'); box(0.8, 1.1, 1.6, 56.4, 0.55, 23, 0xf2f2f2, 'shiny'); box(0.8, 1.1, 1.6, 61.6, 0.55, 23, 0xf2f2f2, 'shiny');
      solid(55.9, 21.5, 62.1, 23.8, 1.2);
      seats.push({ x: 59, z: 23.6, ry: PI, stand: true });
      box(8, 3.4, 0.3, 59, 1.7, 27.6, 0x0b1220); const logo = new THREE.Mesh(new THREE.PlaneGeometry(6.4, 1.6), this.signMat); logo.position.set(59, y0 + 2.2, 27.44); logo.rotation.y = PI; fg.add(logo);
      solid(55, 27.4, 63, 27.8, 50);
      sofa(46, 19.4, 3, 0); sofa(46, 23.6, 3, PI); table(46, 21.5, 2, 1, 0x6a4a32); plant(43, 18); plant(53, 18);
      for (const x of [66.5, 70, 73.5]) { box(1.4, 1.0, 1.4, x, 0.5, 21, 0xf2f2f2, 'shiny'); for (let k = 0; k < 4; k++) box(0.3, 0.05 + k * 0.03, 0.42, x - 0.4 + k * 0.26, 1.05, 21, [0xc8102e, 0x1f4e9c, 0xf2c200, 0x0b6e4f][k]); solid(x - 0.7, 20.3, x + 0.7, 21.7); }
      shelf(70, 17.0, 8, 0);
      seats.push(desk(67.5, 28.5, PI, 2, 'chart'), desk(72.5, 28.5, PI, 2, 'chart'));
      const sv = new THREE.Mesh(new THREE.PlaneGeometry(4.4, 0.6), new THREE.MeshBasicMaterial({ map: canvasTex(512, 72, (x, w, h) => { x.fillStyle = '#0b6e4f'; x.fillRect(0, 0, w, h); x.fillStyle = '#fff'; x.font = 'bold 30px Arial'; x.textAlign = 'center'; x.fillText('SERVICE COMMERCIAL • CLIENTÈLE', w / 2, 46); }), toneMapped: false }));
      sv.position.set(70, y0 + 3.2, CORE_Z - 0.16); sv.rotation.y = PI; fg.add(sv);
      glassRoom(43, 25.2, 53.6, 31.2, 'e'); table(48.3, 28.2, 5, 1.4, 0x6a4a32); // couloir dégagé (z 31,2 → 33,4) vers l'ascenseur
      for (const x of [46.5, 48.3, 50.1]) { chairAt(x, 27.1); chairAt(x, 29.3); }
      box(0.08, 1.6, 2.8, 43.15, 1.9, 28.2, 0x111418, 'shiny');
      this.meetScreen = new THREE.Mesh(new THREE.PlaneGeometry(2.7, 1.5), new THREE.MeshBasicMaterial({ color: 0x111418, toneMapped: false })); this.meetScreen.position.set(43.22, y0 + 1.9, 28.2); this.meetScreen.rotation.y = PI / 2; fg.add(this.meetScreen);
      pts('Écran interactif de la salle de réunion', 44.5, 28.2, () => this.toggleMeetScreen(), 1.6);
      pts('Livres publiés par NOVA BOOK', 70, 19.6, () => this.ui.toast(`Présentoir : ${BOOKS.slice(0, 4).join(' • ')}`, 4), 1.6);
      pts('Parler à la réceptionniste', 59, 20.6, () => { this.ui.toast('Réceptionniste : « Bonjour, PDG ! Votre bureau est au 5e étage, la Direction. Prenez l’ascenseur au fond du hall à gauche, puis la porte « BUREAU DU PDG ». »', 5); if (this.audio && this.audio.ctx) for (let k = 0; k < 4; k++) this.audio.tone(260 + Math.random() * 60, 0.07, 0.04, 'triangle', this.audio.sfx, k * 0.08); }, 1.4);
      // signalétique du hall : direction de l'ascenseur et du bureau du PDG
      const dir = new THREE.Mesh(new THREE.PlaneGeometry(3.2, 0.7), new THREE.MeshBasicMaterial({ map: canvasTex(512, 112, (x, w, h) => { x.fillStyle = '#0b1220'; x.fillRect(0, 0, w, h); x.fillStyle = '#f2c200'; x.font = 'bold 36px Arial'; x.fillText('ASCENSEURS →', 16, 46); x.fillStyle = '#fff'; x.font = '26px Arial'; x.fillText('Direction • Bureau du PDG : 5e étage', 16, 92); }), toneMapped: false }));
      dir.position.set(54.3, y0 + 2.75, 24.6); dir.rotation.y = Math.PI; dir.scale.setScalar(0.45); fg.add(dir); // panneau suspendu au-dessus du couloir menant aux ascenseurs
    } else if (lv === 1) {
      for (const z of [21, 28]) for (const x of [46, 52.5, 59, 65.5]) seats.push(desk(x, z, PI, 1, 'design', 'tablet'));
      for (let i = 0; i < 3; i++) { box(2.2, 1.5, 0.08, 73.5, 1.6, 18 + i * 2.6, 0xf2f2f2); } // tableaux de couvertures
      posterWall(75.6, 22, -PI / 2, 4, 1.0); posterWall(42.4, 22, PI / 2, 4, 1.1);
      table(72.5, 27.5, 3, 2, 0xf2f2f2); for (let k = 0; k < 6; k++) box(0.42, 0.02, 0.6, 71.4 + (k % 3) * 1.1, 0.8, 27 + Math.floor(k / 3) * 1, [0xe46a1f, 0x1f4e9c, 0xc8102e, 0x0b6e4f, 0xf2c200, 0x7a2a8a][k]);
      plant(43, 32.5); plant(68, 32.5);
    } else if (lv === 2) {
      for (const x of [46, 52.5, 59]) seats.push(desk(x, 21, PI, 2, 'page'));
      for (const x of [50, 60]) { table(x, 28.3, 4, 1.6, 0xd8c8a8); for (let k = 0; k < 5; k++) box(0.3, 0.08 + (k % 3) * 0.06, 0.42, x - 1.4 + k * 0.7, 0.82, 28.3, 0xf4efe6); }
      seats.push({ x: 50, z: 29.5, ry: PI, pose: 'read' }, { x: 60, z: 29.5, ry: PI, pose: 'read' }); chairAt(50, 29.5); chairAt(60, 29.5);
      shelf(75.4, 22, 9, 1); shelf(42.6, 22, 9, 1); shelf(66, 17.0, 8, 0);
      plant(68, 32.5);
    } else if (lv === 3) {
      for (const x of [46, 52.5, 59]) seats.push(desk(x, 21, PI, 3, 'code'));
      glassRoom(43, 25.2, 50, 31.2, 'e');
      for (const z of [25.9, 27.4, 28.9]) { box(0.8, 2.1, 1.2, 44.1, 1.05, z + 0.3, 0x1d1f24, 'shiny'); for (let k = 0; k < 6; k++) P.glow.push(colored(new THREE.BoxGeometry(0.02, 0.05, 0.05).translate(44.52, y0 + 0.4 + k * 0.28, z + 0.0 + (k % 3) * 0.25), k % 2 ? 0x2fd05a : 0x2f80ed)); solid(43.6, z - 0.3, 44.6, z + 0.9, 2.2); }
      table(48, 28.2, 1.6, 2.2, 0xf2f2f2); box(0.5, 0.35, 0.4, 48, 0.95, 28, 0x2a2d33, 'shiny');
      const tl = new THREE.Mesh(new THREE.PlaneGeometry(3.4, 0.6), new THREE.MeshBasicMaterial({ map: canvasTex(512, 90, (x, w, h) => { x.fillStyle = '#0b6e4f'; x.fillRect(0, 0, w, h); x.fillStyle = '#fff'; x.font = 'bold 30px Arial'; x.fillText('SALLE TESTS & MAINTENANCE', 12, 56); }), toneMapped: false })); tl.position.set(46.5, y0 + 3.4, 25.5); tl.rotation.y = PI; fg.add(tl);
      for (const x of [66, 72.5]) seats.push(desk(x, 21, PI, 2, 'cut'));
      // studio : fond vert, caméra sur trépied, projecteurs, micro
      box(9, 3.2, 0.1, 61.5, 1.6, 32.9, 0x2fa04a); box(9, 0.05, 3, 61.5, 0.13, 31.3, 0x2fa04a);
      box(0.3, 0.3, 0.5, 61.5, 1.5, 27.6, 0x111418, 'shiny'); for (const a of [0, 2.1, 4.2]) box(0.04, 1.5, 0.04, 61.5 + Math.cos(a) * 0.35, 0.75, 27.6 + Math.sin(a) * 0.35, 0x2a2d33);
      for (const x of [57.8, 65.2]) { box(0.05, 2, 0.05, x, 1, 28.5, 0x2a2d33); P.glow.push(colored(new THREE.BoxGeometry(0.9, 0.7, 0.1).translate(x, y0 + 2.2, 28.5), 0xfff2d0)); solid(x - 0.3, 28.2, x + 0.3, 28.8, 2); }
      box(0.04, 1.6, 0.04, 63.5, 0.8, 30.5, 0x2a2d33); box(0.12, 0.2, 0.12, 63.5, 1.7, 30.4, 0x111418);
      solid(61.1, 27.2, 61.9, 28, 2);
      const st = new THREE.Mesh(new THREE.PlaneGeometry(3.4, 0.6), new THREE.MeshBasicMaterial({ map: canvasTex(512, 90, (x, w, h) => { x.fillStyle = '#7a2a8a'; x.fillRect(0, 0, w, h); x.fillStyle = '#fff'; x.font = 'bold 30px Arial'; x.fillText('STUDIO • AUDIOVISUEL', 12, 56); }), toneMapped: false })); st.position.set(61.5, y0 + 3.6, 32.8); st.rotation.y = PI; fg.add(st);
    } else if (lv === 4) {
      // presse offset (rouleaux animés), traceur grand format (chariot), relieuse, massicot (lame), plastifieuse, contrôle qualité, papier, emballage (tapis)
      const mg = new THREE.Group(); fg.add(mg); this.machineGroup = mg;
      const mBox = (w, h, d, x, y, z, c) => { const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), new THREE.MeshStandardMaterial({ color: c, roughness: 0.4, metalness: 0.4 })); m.position.set(x, y0 + y, z); mg.add(m); return m; };
      box(9, 1.6, 2.6, 49, 0.8, 19.6, 0x2f4a6a, 'shiny'); box(9.2, 0.2, 2.8, 49, 1.7, 19.6, 0xe46a1f); solid(44.5, 18.3, 53.5, 20.9, 2);
      const rollers = []; for (let k = 0; k < 5; k++) { const r = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 2.4, 14).rotateX(PI / 2), new THREE.MeshStandardMaterial({ color: k % 2 ? 0x9aa0a6 : 0x2a2d33, metalness: 0.7, roughness: 0.3 })); r.position.set(45.3 + k * 1.8, y0 + 2.0, 19.6); mg.add(r); rollers.push(r); }
      const sheet = mBox(0.9, 0.02, 1.3, 54.2, 1.0, 19.6, 0xf8f8f4); const stack = mBox(0.9, 0.3, 1.3, 54.2, 0.85, 19.6, 0xf2f2ee);
      this.machines.push({ name: 'Presse offset', x: 49, z: 22, run: 0, rollers, sheet, stack });
      box(6, 1.2, 1.2, 61, 0.6, 18.6, 0x2a2d33, 'shiny'); box(6.2, 0.1, 1.3, 61, 1.25, 18.6, 0xf2f2f2); solid(57.9, 17.9, 64.1, 19.3, 1.6);
      const carriage = mBox(0.4, 0.25, 0.5, 58.5, 1.45, 18.6, 0xc8102e); const poster = mBox(4.8, 0.02, 1.4, 61, 0.65, 19.7, 0x2f80ed); poster.rotation.x = -0.6;
      this.machines.push({ name: 'Traceur grand format', x: 61, z: 20.8, run: 0, carriage });
      box(4, 1.3, 1.6, 68.5, 0.65, 19.3, 0x3a5a3a, 'shiny'); solid(66.4, 18.4, 70.6, 20.2, 1.6); const block = mBox(0.6, 0.3, 0.8, 67, 1.45, 19.3, 0xf4efe6);
      this.machines.push({ name: 'Relieuse', x: 68.5, z: 21.5, run: 0, block });
      box(2.4, 1.0, 1.6, 73.6, 0.5, 19.3, 0x5a5e64, 'shiny'); box(0.12, 1.4, 1.6, 72.5, 1.5, 19.3, 0x5a5e64); box(0.12, 1.4, 1.6, 74.7, 1.5, 19.3, 0x5a5e64); solid(72.3, 18.4, 74.9, 20.2, 2);
      const blade = mBox(2.2, 0.12, 0.2, 73.6, 1.9, 19.3, 0xd8d8d8);
      this.machines.push({ name: 'Massicot', x: 73.6, z: 21.4, run: 0, blade });
      box(3, 1.0, 1.4, 46, 0.5, 27, 0x6a4a8a, 'shiny'); solid(44.4, 26.2, 47.6, 27.8, 1.2); const lam = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.15, 1.3, 12).rotateX(PI / 2), new THREE.MeshStandardMaterial({ color: 0xd8d8d8, metalness: 0.6 })); lam.position.set(46, y0 + 1.1, 27); mg.add(lam);
      this.machines.push({ name: 'Plastifieuse', x: 46, z: 28.6, run: 0, rollers: [lam] });
      table(53.5, 27.2, 3, 1.4, 0xf2f2f2); for (let k = 0; k < 4; k++) box(0.3, 0.12, 0.42, 52.4 + k * 0.7, 0.85, 27.2, [0xc8102e, 0x1f4e9c, 0xf2c200, 0x0b6e4f][k]);
      P.glow.push(colored(new THREE.BoxGeometry(0.6, 0.05, 0.4).translate(55, y0 + 0.81, 27.2), 0xfff8e0));
      for (const [x, z] of [[58.5, 27], [61, 27], [58.5, 30], [61, 30]]) { box(1.8, 0.15, 1.2, x, 0.08, z, 0x8a6a42); box(1.6, 1.0, 1.0, x, 0.65, z, 0xf8f8f4); solid(x - 0.9, z - 0.6, x + 0.9, z + 0.6, 1.2); }
      box(8, 0.8, 1, 69.5, 0.4, 27, 0x2a2d33, 'shiny'); box(8, 0.06, 1.05, 69.5, 0.83, 27, 0x111418); solid(65.5, 26.5, 73.5, 27.5, 1);
      const boxes = []; for (let k = 0; k < 4; k++) boxes.push(mBox(0.6, 0.45, 0.6, 66 + k * 2, 1.08, 27, 0xb8945a));
      this.machines.push({ name: 'Tapis d’emballage', x: 69.5, z: 28.6, run: 0, boxes, conveyor: true });
      for (let k = 0; k < 6; k++) box(0.6, 0.45, 0.6, 66 + (k % 3) * 0.65, 0.23 + Math.floor(k / 3) * 0.45, 30.6, 0xb8945a); solid(65.6, 30.2, 68.2, 31, 1);
      for (const m of this.machines) pts(`Lancer : ${m.name}`, m.x, m.z, () => this.runMachine(m), 1.4);
      seats.push({ x: 49, z: 22.1, ry: PI, pose: 'machine' }, { x: 61, z: 20.3, ry: PI, pose: 'machine' }, { x: 68.5, z: 21.1, ry: PI, pose: 'machine' }, { x: 53.5, z: 28.4, ry: PI, pose: 'machine' });
    } else if (lv === 5) {
      // bureau du PDG (vitré), salle du conseil, administration, espace de repos
      glassRoom(60.2, 16.3, 75.7, 33.0, { w: [29, 31] });
      // ---- porte du bureau du PDG : battant en bois, poignée animée, plaque, fermeture automatique ----
      this.buildCeoDoor(fg, y0);
      pts('Ouvrir / fermer la porte du BUREAU DU PDG', 59.3, 30, () => this.toggleCeoDoor(), 1.2);
      pts('Ouvrir / fermer la porte du bureau', 61.2, 30.2, () => this.toggleCeoDoor(), 1.0);
      box(3.4, 0.08, 1.4, 68, 0.8, 22.2, 0x3a2416, 'shiny'); box(3.2, 0.74, 0.08, 68, 0.39, 22.85, 0x3a2416); box(0.08, 0.74, 1.3, 66.35, 0.39, 22.2, 0x3a2416); box(0.08, 0.74, 1.3, 69.65, 0.39, 22.2, 0x3a2416);
      for (let m = 0; m < 3; m++) { const mx = 67 + m * 1.0, ry2 = (m - 1) * -0.3; box(0.9, 0.5, 0.04, mx, 1.15, 22.6, 0x111418, 'shiny'); screen('press', 0.84, 0.46, mx, 1.15, 22.57, PI + ry2 * 0); }
      box(0.25, 0.08, 0.2, 69.2, 0.88, 21.9, 0x111418); // téléphone
      box(0.7, 0.12, 0.7, 68, 0.55, 20.9, 0x111418); box(0.7, 1.1, 0.12, 68, 1.1, 20.5, 0x111418); // fauteuil
      solid(66.2, 21.4, 69.8, 22.95);
      sofa(74.8, 28.5, 3.4, -PI / 2); table(72.8, 28.5, 1.2, 2, 0x3a2416);
      table(64, 28.5, 2.4, 1.4, 0xf2f2f2); for (const [x, z] of [[62.6, 28.5], [65.4, 28.5], [64, 27.4], [64, 29.6]]) chairAt(x, z);
      shelf(60.6, 21, 7, 1); plant(75, 17); plant(61, 32.4);
      for (let i = 0; i < 2; i++) P.glow.push(colored(new THREE.PlaneGeometry(1.4, 1.0).rotateY(-PI / 2).translate(75.6, y0 + 2.1, 20 + i * 3), [0xe46a1f, 0x2f80ed][i]));
      this.ceil = new THREE.Mesh(new THREE.BoxGeometry(6, 0.06, 3), new THREE.MeshBasicMaterial({ color: 0xffffff, toneMapped: false })); this.ceil.position.set(68, y0 + NB.fh - 0.4, 24); fg.add(this.ceil);
      this.statsTex = canvasTex(512, 288, () => {}); this.statsScreen = new THREE.Mesh(new THREE.PlaneGeometry(5, 2.8), new THREE.MeshBasicMaterial({ map: this.statsTex, toneMapped: false })); this.statsScreen.position.set(65, y0 + 2.1, 32.85); this.statsScreen.rotation.y = PI; fg.add(this.statsScreen);
      box(5.3, 3.1, 0.1, 65, 2.1, 32.92, 0x111418);
      pts('S’asseoir au bureau de direction', 68, 20.4, () => this.sit('desk'), 1.2);
      pts('Changer l’éclairage du bureau', 61.2, 31.6, () => this.cycleLight(), 1.1);
      pts('S’asseoir dans le canapé', 74.2, 28.5, () => this.sit('sofa'), 1.3);
      pts('Écran des statistiques NOVA BOOK', 65, 31.6, () => this.ui.toast('Écran mural : les statistiques s’actualisent en direct.', 2), 1.0);
      const pl = new THREE.Mesh(new THREE.PlaneGeometry(2.6, 0.5), new THREE.MeshBasicMaterial({ map: canvasTex(512, 96, (x, w, h) => { x.fillStyle = '#3a2416'; x.fillRect(0, 0, w, h); x.fillStyle = '#f2c200'; x.font = 'bold 40px serif'; x.textAlign = 'center'; x.fillText('PRÉSIDENT-DIRECTEUR GÉNÉRAL', w / 2, 62); }), toneMapped: false })); pl.position.set(60.1, y0 + 2.9, 30); pl.rotation.y = -PI / 2; fg.add(pl);
      // administration (comptable, RH, secrétaire de direction), salle du conseil, espace de repos
      for (const x of [44.5, 48.5, 52.5]) seats.push(desk(x, 18.6, 0, 2, 'chart'));
      glassRoom(43, 22.2, 58.8, 26.8, 'n'); table(50.9, 24.5, 7, 1.6, 0x3a2416); for (let k = 0; k < 5; k++) { chairAt(48.1 + k * 1.4, 23.3); chairAt(48.1 + k * 1.4, 25.7); }
      const cs = new THREE.Mesh(new THREE.PlaneGeometry(2.6, 1.4), new THREE.MeshBasicMaterial({ map: this.tex.press, toneMapped: false })); cs.position.set(43.1, y0 + 1.8, 24.5); cs.rotation.y = PI / 2; fg.add(cs);
      sofa(46, 30.6, 3, 0); sofa(52, 30.6, 3, 0); table(49, 29, 1.6, 0.9, 0x6a4a32); box(0.6, 1.5, 0.5, 57.5, 0.75, 32.6, 0x2a2d33, 'shiny'); P.glow.push(colored(new THREE.PlaneGeometry(0.3, 0.2).rotateY(PI).translate(57.5, y0 + 1.2, 32.34), 0xe46a1f));
      solid(57.2, 32.3, 57.8, 32.9, 2); plant(43, 32.4);
      seats.push({ x: 55.5, z: 29.5, ry: -PI / 2, pose: 'stand', broom: true });
      pts('Pause café (espace de repos)', 57.5, 31.8, () => { this.ui.toast('Un bon café de l’espace de repos ☕ Énergie +5', 2); if (this.needs) this.needs.energy = Math.min(100, this.needs.energy + 5); }, 1.2);
      pts('Réunion dans la salle du conseil', 50.9, 27.6, () => (this.onMeeting ? this.onMeeting() : this.ui.toast('La salle du conseil est prête.', 2)), 1.4);
    }
    // ascenseur et escaliers (tous les étages)
    pts('Ascenseur', ELEV.x, ELEV.z, () => this.toggle(true, 'elev'), 1.3);
    pts(lv === 0 ? 'Escaliers (monter)' : lv === NB.levels - 1 ? 'Escaliers (descendre)' : 'Escaliers', STAIRS.x, STAIRS.z, () => this.toggle(true, 'stairs'), 1.3);
    // fusion par matériau
    for (const k of ['std', 'shiny', 'glow']) if (P[k].length) { const m = new THREE.Mesh(mergeGeometries(P[k]), this.mats[k]); m.castShadow = k !== 'glow'; m.receiveShadow = true; fg.add(m); if (k === 'std') this.stdMesh = m; }
    for (const [tk, list] of Object.entries(screens)) { const m = new THREE.Mesh(mergeGeometries(list), new THREE.MeshBasicMaterial({ map: this.tex[tk], toneMapped: false })); fg.add(m); }
    if (glass.length) { const gm = new THREE.Mesh(mergeGeometries(glass), this.mats.glass); gm.renderOrder = 3; fg.add(gm); }
    this.root.add(fg);
    return { lv, group: fg, seats, people: null };
  }

  // ------------------------------------------------------------------ employés
  spawnPeople(f) {
    if (f.people) return;
    f.people = [];
    const staff = this.staff.filter((s) => s.lv === f.lv);
    staff.forEach((s, i) => {
      const seat = s.seat === 'reception' ? f.seats[0] : f.seats[f.lv === 0 ? s.seat + 1 : s.seat]; if (!seat) return;
      const job = JOBS[s.job], female = FEMALE.has(s.name.split(' ')[0]);
      const c = createCharacter({ female, skin: SKINS[i % SKINS.length], shirtColor: [0xf2f2f2, 0x1f4e9c, 0x0b6e4f, 0xe8e2d6, 0x7a2a8a, 0xc8102e][(i + f.lv) % 6], pants: 0x22252a });
      const pose = seat.pose || job.pose, stand = seat.stand || pose === 'machine' || pose === 'stand';
      if (!stand) c.sit(false);
      c.group.position.set(seat.x, f.lv * NB.fh + (stand ? 0 : -0.47), seat.z); c.group.rotation.y = seat.ry;
      if (pose === 'edit') { const hp = new THREE.Mesh(new THREE.TorusGeometry(0.13, 0.025, 6, 12, PI), new THREE.MeshStandardMaterial({ color: 0x111418 })); hp.position.y = 0.16; c.bones.head.add(hp); }
      if (seat.broom) { const br = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 1.3, 6), new THREE.MeshStandardMaterial({ color: 0x8a6a42 })); br.position.set(0, -0.5, 0.15); c.bones.foreR.add(br); }
      f.group.add(c.group);
      f.people.push({ c, s, pose, stand, t: Math.random() * 10, seat });
      const o = this.world.collision.addCircle(seat.x, seat.z, 0.35, f.lv * NB.fh + 1.8); o.lv = f.lv; f.cols = (f.cols || []).concat(o);
      this.points.push({ lv: f.lv, x: seat.x, z: seat.z, r: 1.7, person: true, label: `Parler à ${s.name} (${job.label})`, action: () => this.greet(s) });
    });
  }
  animatePeople(f, dt) {
    for (const p of f.people || []) {
      p.t += dt; const b = p.c.bones, t = p.t;
      if (p.stand) { p.c.animate(dt, 0); }
      if (p.pose === 'type' || p.pose === 'draw') {
        b.armL.rotation.x = b.armR.rotation.x = -0.75; b.foreL.rotation.x = -0.9 + Math.sin(t * 14) * 0.08; b.foreR.rotation.x = -0.9 + Math.sin(t * 13 + 1) * (p.pose === 'draw' ? 0.03 : 0.08);
        if (p.pose === 'draw') { b.armR.rotation.z = -0.25 + Math.sin(t * 2.2) * 0.12; b.head.rotation.x = 0.25; }
        else b.head.rotation.y = Math.sin(t * 0.4) * 0.15;
      } else if (p.pose === 'edit') { b.armL.rotation.x = b.armR.rotation.x = -0.7; b.foreL.rotation.x = -0.95; b.foreR.rotation.x = -0.95 + Math.sin(t * 6) * 0.1; b.head.rotation.x = 0.05 + Math.sin(t * 0.7) * 0.05; }
      else if (p.pose === 'read') { b.armL.rotation.x = b.armR.rotation.x = -0.9; b.foreL.rotation.x = b.foreR.rotation.x = -0.6; b.head.rotation.x = 0.45; b.armR.rotation.z = Math.sin(t * 0.5) * 0.1; }
      else if (p.pose === 'machine') { b.armL.rotation.x = -0.9 + Math.sin(t * 2) * 0.2; b.armR.rotation.x = -1.1 + Math.sin(t * 2.3 + 1) * 0.25; b.foreL.rotation.x = b.foreR.rotation.x = -0.6; b.head.rotation.x = 0.3; }
      else if (p.seat.broom) { b.armR.rotation.x = -0.5 + Math.sin(t * 2.5) * 0.35; b.foreR.rotation.x = -0.4; b.head.rotation.x = 0.3; }
    }
  }
  // postes de travail disponibles à un étage (pour placer les nouvelles recrues)
  seatCount(lv) { const f = this.floors[lv]; return f ? f.seats.length - (lv === 0 ? 1 : 0) : 0; } // au rez-de-chaussée, la réception est réservée à la réceptionniste
  // l'effectif a changé (embauche, licenciement) : les personnages seront recréés à la prochaine visite de l'étage
  refreshPeople() {
    for (const f of this.floors) {
      if (f.people) for (const p of f.people) { f.group.remove(p.c.group); p.c.mesh.geometry.dispose(); }
      for (const o of f.cols || []) o.disabled = true;
      f.people = null; f.cols = [];
    }
    this.points = this.points.filter((p) => !p.person);
    if (this.inside) this.spawnPeople(this.floors[this.level]); else if (this.near) this.spawnPeople(this.floors[0]);
  }
  greet(s) {
    if (this.talk) return this.talk.openByName(s.name); // mission 017 : vraie conversation
    const job = JOBS[s.job];
    const lines = { graphiste: 'Je finalise une couverture sur NovaDesign.', maquettiste: 'Je mets en page un manuel scolaire.', correcteur: 'Je relis un manuscrit de roman.', developpeur: 'Je corrige un module du site de commande.', monteur: 'Je monte une vidéo promotionnelle.', imprimeur: 'La machine tourne bien aujourd’hui.', commercial: 'Un client attend un devis d’impression.', comptable: 'Je prépare les comptes du mois.', secretaire: 'Votre agenda est à jour.', entretien: 'Tout est propre à cet étage !', rh: 'Je prépare les prochains recrutements.', directeur: 'L’équipe création avance bien.' }[s.job] || '';
    this.ui.toast(`${s.name} (${job.label}) : « ${pick(GREETINGS)} ${lines} »`, 3.5);
    if (this.audio && this.audio.ctx) for (let k = 0; k < 3; k++) this.audio.tone(200 + Math.random() * 80, 0.07, 0.04, 'triangle', this.audio.sfx, k * 0.08);
  }

  // ------------------------------------------------------------------ porte du bureau du PDG
  buildCeoDoor(fg, y0) {
    const piv = new THREE.Group(); piv.position.set(60.2, y0, 29.0); fg.add(piv);
    const wood = new THREE.MeshStandardMaterial({ color: 0x4a2c18, roughness: 0.45 }), steel = new THREE.MeshStandardMaterial({ color: 0xd8dcdf, metalness: 0.9, roughness: 0.2 });
    const leaf = new THREE.Mesh(new THREE.BoxGeometry(0.06, 2.35, 2.0), wood); leaf.position.set(0, 1.18, 1.0); leaf.castShadow = true; piv.add(leaf);
    for (const z of [0.2, 1.8]) { const strip = new THREE.Mesh(new THREE.BoxGeometry(0.07, 2.2, 0.03), steel); strip.position.set(0, 1.18, z); piv.add(strip); }
    const handle = new THREE.Group(); handle.position.set(0, 1.05, 1.75); piv.add(handle);
    for (const s of [-1, 1]) { const h = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.03, 0.18), steel); h.position.set(s * 0.06, 0, -0.07); handle.add(h); }
    const plate = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 0.36), new THREE.MeshBasicMaterial({ map: canvasTex(360, 144, (x, w, h) => { x.fillStyle = '#c8a24a'; x.fillRect(0, 0, w, h); x.fillStyle = '#2a1a08'; x.font = 'bold 34px serif'; x.textAlign = 'center'; x.fillText('BUREAU DU PDG', w / 2, 58); x.font = '24px serif'; x.fillText('PDG — NOVA BOOK', w / 2, 100); x.font = 'italic 16px serif'; x.fillText('Accès réservé', w / 2, 128); }), toneMapped: false }));
    plate.position.set(-0.04, 1.75, 1.0); plate.rotation.y = -Math.PI / 2; piv.add(plate);
    const plate2 = plate.clone(); plate2.position.x = 0.04; plate2.rotation.y = Math.PI / 2; piv.add(plate2);
    const o = this.world.collision.addBox(60.1, 29.0, 60.3, 31.0, 5 * NB.fh + 2.4); o.lv = 5;
    this.ceo = { piv, handle, col: o, open: 0, target: 0, wiggle: 0 };
  }
  toggleCeoDoor() {
    const d = this.ceo; d.target = d.target > 0.5 ? 0 : 1; d.wiggle = 0.35;
    if (this.audio && this.audio.ctx) { this.audio.tone(d.target ? 520 : 380, 0.06, 0.04, 'triangle'); this.audio.burst && this.audio.burst(0.05, 'lowpass', 900, 1, 0.12); }
    this.ui.toast(d.target ? 'Bureau du PDG : porte ouverte' : 'Porte du bureau du PDG fermée', 1.4);
  }
  updateCeoDoor(dt, P) {
    const d = this.ceo; if (!d) return;
    // fermeture automatique quand le PDG s'éloigne (détection de proximité)
    if (d.target > 0.5 && (this.level !== 5 || Math.hypot(P.x - 60.2, P.z - 30) > 7)) { d.target = 0; if (this.audio && this.audio.ctx && this.level === 5) this.audio.tone(380, 0.06, 0.03, 'triangle'); }
    d.open += (d.target - d.open) * Math.min(1, dt * 4); d.piv.rotation.y = d.open * 1.45;
    d.wiggle = Math.max(0, d.wiggle - dt); d.handle.rotation.x = -Math.sin(Math.min(1, d.wiggle / 0.35) * Math.PI) * 0.6;
    d.col.disabled = d.open > 0.55;
  }

  // ------------------------------------------------------------------ actions
  runMachine(m) { m.run = 12; this.ui.toast(`${m.name} en marche (démonstration de production).`, 2); if (this.audio && this.audio.ctx) this.audio.tone(90, 0.6, 0.08, 'sawtooth'); }
  toggleMeetScreen() {
    const s = this.meetScreen; s.material.dispose();
    s.userData.on = !s.userData.on;
    s.material = s.userData.on ? new THREE.MeshBasicMaterial({ map: canvasTex(512, 288, (x, w, h) => { x.fillStyle = '#0b1220'; x.fillRect(0, 0, w, h); x.fillStyle = '#f2c200'; x.font = 'bold 30px Arial'; x.fillText('NOVA BOOK — Catalogue', 20, 44); x.fillStyle = '#fff'; x.font = '22px Arial'; BOOKS.forEach((b, i) => x.fillText('• ' + b, 24, 92 + i * 32)); }), toneMapped: false }) : new THREE.MeshBasicMaterial({ color: 0x111418 });
    this.ui.toast(s.userData.on ? 'Écran interactif allumé : catalogue NOVA BOOK.' : 'Écran éteint.', 1.6);
  }
  cycleLight() {
    const L = [['Blanc neutre', 0xffffff, 0.06], ['Chaleureux', 0xffd8a0, 0.12], ['Bleu NOVA', 0x8ab8ff, 0.1], ['Tamisé', 0x806040, 0.02]];
    this.light = (this.light + 1) % L.length; const [n, c] = L[this.light];
    this.ceil.material.color.setHex(c); this.ui.toast(`Éclairage du bureau : ${n}`, 1.5);
  }
  sit(kind) {
    const pl = this.player, y = 5 * NB.fh;
    this.seated = kind; pl.char.sit && pl.char.sit(false);
    if (kind === 'desk') { pl.mesh.position.set(68, y - 0.47 + 0.2, 20.85); pl.mesh.rotation.set(0, 0, 0); if (this.onDesk) this.onDesk(); else this.ui.toast('Tu es à ton bureau de PDG. (E pour te lever)', 3); }
    else { pl.mesh.position.set(74.6, y - 0.47 + 0.05, 28.5); pl.mesh.rotation.set(0, -PI / 2, 0); this.ui.toast('Tu te reposes dans le canapé. (E pour te lever)', 2); }
  }
  stand() { const pl = this.player; this.seated = null; pl.char.stand && pl.char.stand(); pl.mesh.position.copy(pl.pos); }
  goTo(lv, how) {
    const pl = this.player;
    this.level = lv; this.world.collision.level = lv; pl.floorY = lv * NB.fh;
    const p = how === 'stairs' ? STAIRS : ELEV;
    pl.pos.set(p.x, lv * NB.fh, p.z - 0.6); pl.vy = 0; pl.mesh.position.copy(pl.pos);
    this.toggle(false); this.setVisibility();
    this.ui.toast(`${FLOORS[lv].name} — ${FLOORS[lv].sub}`, 2);
    if (this.audio && this.audio.ctx) { this.audio.tone(880, 0.12, 0.05, 'sine'); this.audio.tone(1175, 0.18, 0.05, 'sine', this.audio.sfx, 0.14); }
  }

  // ------------------------------------------------------------------ interface (ascenseur / escaliers)
  buildDom() {
    this.dom = document.querySelector('#nova');
    this.dom.addEventListener('click', (e) => { const b = e.target.closest('[data-nv]'); if (!b) { if (e.target === this.dom) this.toggle(false); return; } e.stopPropagation(); if (b.dataset.nv === 'x') return this.toggle(false); this.goTo(+b.dataset.nv, this.mode); });
  }
  toggle(on, mode = this.mode) {
    this.open = on; this.mode = mode; this.dom.classList.toggle('show', on);
    if (!on) return;
    const list = mode === 'stairs' ? FLOORS.filter((f) => Math.abs(f.lv - this.level) === 1) : FLOORS;
    this.dom.innerHTML = `<div class="nv-box"><div class="nv-head"><b>${mode === 'stairs' ? '🪜 Escaliers' : '🛗 Ascenseur'} — NOVA BOOK</b><button data-nv="x">✕</button></div>
      ${[...list].reverse().map((f) => `<button class="nv-fl${f.lv === this.level ? ' on' : ''}" data-nv="${f.lv}" ${f.lv === this.level ? 'disabled' : ''}><i>${f.lv === 0 ? 'RDC' : f.lv}</i><span><b>${f.name}</b><small>${f.sub}</small></span></button>`).join('')}</div>`;
  }
  handleKeys(input) { if (input.hit('Escape') || input.hit('KeyE')) this.toggle(false); }

  // ------------------------------------------------------------------ boucle
  nearest(x, z) {
    if (!this.inside && !(this.level === 0 && x > NB.x0 && x < NB.x1 && z > NB.z0 && z < NB.z1)) return null;
    let best = null;
    for (const p of this.points) { if (p.lv !== this.level) continue; const d = Math.hypot(x - p.x, z - p.z); if (d < p.r && (!best || d < best.d)) best = { d, p }; }
    return best ? { d: best.d, it: { label: () => best.p.label, action: best.p.action } } : null;
  }
  setVisibility() {
    const L = this.inside ? this.level : -1;
    this.floors.forEach((f, i) => { f.group.visible = this.inside ? i === L : i === 0 && this.near; });
    this.shellLv.forEach((s, i) => { s.visible = !this.inside || i <= L; });
    this.roof.visible = !this.inside;
    if (this.inside) this.spawnPeople(this.floors[L]); else if (this.near) this.spawnPeople(this.floors[0]);
  }
  update(dt, P, playerObj) {
    const d = Math.hypot(P.x - 59, P.z - 28);
    const near = d < 160; if (near !== this.near) { this.near = near; this.setVisibility(); }
    this.root.visible = d < 600;
    if (!this.root.visible) return;
    const inside = !playerObj.inCar && P.x > NB.x0 && P.x < NB.x1 && P.z > NB.z0 && P.z < NB.z1;
    if (inside !== this.inside) { this.inside = inside; this.setVisibility(); }
    // portes automatiques
    const want = this.level === 0 && Math.abs(P.x - 59) < 3.5 && Math.abs(P.z - NB.z0) < 4 ? 1 : 0;
    this.doorOpen += (want - this.doorOpen) * Math.min(1, dt * 5);
    for (const dd of this.doors) dd.m.position.x = 59 + dd.s * (1 + this.doorOpen * 1.9);
    // éclairage extérieur (bornes, appliques, lampadaires) et barrière du parking
    this.extGlow.color.setScalar(0.25 + this.env.lightsOn * 0.9);
    const car = playerObj.inCar, wantUp = car && Math.hypot(car.pos.x - 83.5, car.pos.z - 11.4) < 12 ? 1 : 0;
    this.barUp = (this.barUp || 0) + (wantUp - (this.barUp || 0)) * Math.min(1, dt * 3);
    if (this.barrier) { const a = this.barUp * 1.4; const px = 78.6, len = 4.6; this.barrier.rotation.z = a; this.barrier.position.set(px + Math.cos(a) * len / 2, 1.0 + Math.sin(a) * len / 2, 11.4); this.barrierStripes.forEach((st, k) => { const r = 0.8 + k * 1.1; st.rotation.z = a; st.position.set(px + Math.cos(a) * r, 1.0 + Math.sin(a) * r, 11.4); }); }
    // enseigne lumineuse : plus brillante la nuit
    this.signMat.color.setScalar(0.75 + this.env.lightsOn * 0.6);
    // éclairage intérieur (pas de lumière dynamique ajoutée) + lampes empruntées à la maison
    const f = this.floors[this.inside ? this.level : 0];
    this.mats.std.emissive.setRGB(0.3, 0.3, 0.28); this.mats.std.emissiveIntensity = this.inside ? 0.01 + this.env.lightsOn * 0.1 : 0.0;
    this.lightRig(this.inside && this.env.lightsOn > 0.05);
    if (this.inside || this.near) this.animatePeople(f, dt);
    if (this.inside && this.level === 4) this.animateMachines(dt);
    this.updateCeoDoor(dt, P);
    if (this.inside && this.level === 5) { this._st = (this._st || 0) - dt; if (this._st <= 0) { this._st = 2; this.drawStats(); } }
    if (this.seated) { const pl = this.player; pl.char.sit && pl.char.sit(false); }
    // sorti du bâtiment autrement que par l'escalier (transport, pouvoir…) : retour au niveau du sol
    if (!inside && this.level !== 0) { this.level = 0; this.world.collision.level = 0; this.player.floorY = 0; this.setVisibility(); }
  }
  lightRig(on) {
    const ls = this.home && this.home.lights; if (!ls) return;
    if (!this._orig) this._orig = ls.map((l) => ({ p: l.position.clone(), d: l.distance }));
    if (on) { const y = this.level * NB.fh + NB.fh - 0.6; ls.forEach((l, i) => { l.position.set(48 + i * 11, y, 24); l.distance = 16; l.decay = 1.2; l.intensity = 22 * Math.min(1, this.env.lightsOn * 1.5); }); }
    else if (this._borrowed) ls.forEach((l, i) => { l.position.copy(this._orig[i].p); l.distance = this._orig[i].d; l.decay = 1.6; l.intensity = 0; });
    this._borrowed = on;
  }
  animateMachines(dt) {
    for (const m of this.machines) {
      const k = m.run > 0 ? 1 : 0.25; m.run = Math.max(0, m.run - dt); m.ph = (m.ph || 0) + dt * k;
      if (m.rollers) for (const r of m.rollers) r.rotation.z += dt * 9 * k;
      if (m.sheet) { const u = (m.ph * 1.2) % 1; m.sheet.position.y = this.level * NB.fh + 1.0 + u * 0.4; m.sheet.visible = k > 0.5; m.stack.scale.y = 1 + ((m.ph * 0.05) % 1); }
      if (m.carriage) m.carriage.position.x = 61 + Math.sin(m.ph * 2.4) * 2.6;
      if (m.block) m.block.position.x = 67 + ((m.ph * 0.6) % 1) * 3;
      if (m.blade) m.blade.position.y = this.level * NB.fh + 1.35 + Math.abs(Math.sin(m.ph * 1.5)) * 0.55;
      if (m.boxes) m.boxes.forEach((b, i) => { b.position.x = 66 + ((i * 2 + m.ph * 1.2) % 8); });
    }
  }
  drawStats() {
    const c = this.statsTex.image, x = c.getContext('2d'), w = c.width, h = c.height;
    x.fillStyle = '#0b1220'; x.fillRect(0, 0, w, h);
    x.fillStyle = '#f2c200'; x.font = 'bold 26px Arial'; x.fillText('NOVA BOOK — Tableau de bord', 18, 36);
    x.fillStyle = '#9fb2c0'; x.font = '16px Arial'; x.fillText(`${this.env.clock} • ${this.company ? this.company.staff.length : this.staff.length} employés • 6 niveaux`, 18, 60);
    const by = {}; for (const s of this.staff) by[JOBS[s.job].dept] = (by[JOBS[s.job].dept] || 0) + 1;
    Object.entries(by).forEach(([k, n], i) => { const y = 86 + i * 22; x.fillStyle = '#fff'; x.font = '17px Arial'; x.fillText(k, 18, y); x.fillStyle = ['#e46a1f', '#2f80ed', '#0b6e4f', '#f2c200', '#c8102e', '#7a2a8a', '#2aa0a0', '#9aa0a6'][i % 8]; x.fillRect(190, y - 13, n * 40, 14); x.fillStyle = '#fff'; x.fillText(String(n), 196 + n * 40, y); });
    const C = this.company, mass = C ? C.massSalary() : this.staff.reduce((a, s) => a + JOBS[s.job].salary, 0);
    if (C) { x.fillStyle = '#2fd05a'; x.font = 'bold 16px Arial'; x.fillText(`Trésorerie ${C.cash.toLocaleString('fr-FR')} FCFA • CA du mois ${C.cur().ca.toLocaleString('fr-FR')} • ${C.orders.length} commande(s)`, 18, h - 30); }
    x.fillStyle = '#9fb2c0'; x.font = '16px Arial'; x.fillText(`Masse salariale mensuelle : ${mass.toLocaleString('fr-FR')} FCFA`, 18, h - 10);
    this.statsTex.needsUpdate = true;
  }
}
