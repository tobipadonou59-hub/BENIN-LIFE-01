// Mission 017, étape 2 — conversations libres avec les employés des sociétés NOVA (NOVA BOOK et filiales).
// Moteur de dialogue local et gratuit (aucun service en ligne) : le joueur écrit librement ; l'employé répond selon
// sa personnalité, son métier, son humeur (moral) et les données réelles du jeu (commandes, projets, résultats), et
// se souvient des échanges importants (instructions, promesses, compliments, reproches). Discussions individuelles
// ou collectives. Voix facultative : synthèse vocale du navigateur ; dictée si le navigateur la propose.
import { JOBS } from './nova-data.js';
import { fcfa } from './food-data.js';

const norm = (s) => s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[’']/g, ' ');
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const hash = (str) => { let h = 2166136261; for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };
const FEM = new Set(['Adjoa', 'Clarisse', 'Nadège', 'Pélagie', 'Hermine', 'Odile', 'Mireille', 'Rachidatou', 'Edwige', 'Murielle', 'Bénédicte', 'Grâce', 'Sika', 'Estelle', 'Akouavi', 'Ornella', 'Nadia', 'Yolande', 'Huguette', 'Rachelle', 'Prudence', 'Elvire', 'Gisèle']);
const TRAITS = {
  chaleureux: { hi: 'Bonjour PDG ! Toujours un plaisir de vous voir.', tone: '', joke: 'Haha, vous me faites rire, PDG !' },
  reserve: { hi: 'Bonjour, PDG.', tone: '', joke: 'Hum… c’est drôle, oui.' },
  enthousiaste: { hi: 'Bonjour PDG ! Quelle belle journée pour travailler !', tone: ' 😄', joke: 'Excellente celle-là ! Je la raconterai à l’équipe !' },
  pragmatique: { hi: 'Bonjour PDG. Je vous écoute.', tone: '', joke: 'Bien trouvé. Revenons au travail ?' },
  blagueur: { hi: 'Bonjour PDG ! Vous venez vérifier que je ne dors pas ? 😉', tone: ' 😉', joke: 'Ah, celle-là je la connaissais, mais je ris quand même pour mon salaire ! 😂' },
};
const TOWNS = ['Abomey', 'Parakou', 'Porto-Novo', 'Ouidah', 'Bohicon', 'Natitingou', 'Lokossa', 'Cotonou', 'Djougou', 'Savalou'];
const FAM = ['marié·e, avec deux enfants', 'célibataire', 'marié·e, avec un enfant', 'jeune parent d’une petite fille', 'marié·e, avec trois enfants'];
const HOBBY = ['le football', 'la lecture', 'la musique', 'la cuisine', 'la danse', 'les échecs', 'la couture', 'le jardinage', 'la photographie', 'le basket'];
const DISH = ['l’amiwo', 'la pâte rouge', 'l’igname pilée sauce graine', 'le télibo', 'l’atassi', 'le poisson braisé', 'le riz au gras', 'l’akassa'];
const JOKES = ['Pourquoi l’imprimante est-elle toujours fatiguée ? Parce qu’elle fait des tirages toute la journée !', 'Mon ordinateur et moi, on a un point commun : sans café, on ne démarre pas.', 'Un zem m’a dit qu’il connaissait un raccourci… On est arrivés à Ouidah !'];

export class Talk {
  constructor(ctx) {
    Object.assign(this, ctx); // company, group, projects, economy, env, ui, audio, onSave
    this.mem = {}; this.open = false; this.parts = []; this.log = []; this.voice = false; this.rec = null;
    this.dom = document.querySelector('#talk');
    this.dom.addEventListener('click', (e) => this.onClick(e));
    this.dom.addEventListener('keydown', (e) => { if (e.target.classList.contains('tk-in') && e.key === 'Enter') { e.preventDefault(); this.sendInput(); } });
    this.canListen = typeof window !== 'undefined' && !!(window.SpeechRecognition || window.webkitSpeechRecognition);
    this.canSpeak = typeof window !== 'undefined' && 'speechSynthesis' in window;
  }
  today() { return this.company ? this.company.day : this.economy.day; }
  // ------------------------------------------------------------------ employés
  all() {
    const out = [], C = this.company, G = this.group;
    if (C) for (const e of C.staff) out.push({ key: `e:book:${e.id}`, e, org: 'NOVA BOOK', acc: 'book' });
    if (G) for (const [sid, s] of Object.entries(G.subs)) for (const e of s.staff) out.push({ key: `e:${sid}:${e.id}`, e, org: s.name, acc: sid, dir: s.director === e.id });
    return out;
  }
  find(key) { return this.all().find((p) => p.key === key) || null; }
  profile(p) {
    const h = hash(p.e.name), traits = Object.keys(TRAITS);
    return { trait: traits[h % traits.length], town: TOWNS[(h >>> 3) % TOWNS.length], fam: FAM[(h >>> 7) % FAM.length], hobby: HOBBY[(h >>> 11) % HOBBY.length], dish: DISH[(h >>> 15) % DISH.length], female: FEM.has(p.e.name.split(' ')[0]) };
  }
  mood(e) { return e.morale >= 72 ? ['😊', 'de bonne humeur'] : e.morale >= 45 ? ['🙂', 'calme'] : ['😟', 'contrarié·e']; }
  memOf(key) { return this.mem[key] || (this.mem[key] = { n: 0, facts: [], promise: null, praised: null, scolded: null, last: null }); }
  remember(key, txt) { const m = this.memOf(key); m.facts.unshift({ d: this.economy.stamp(), day: this.today(), txt }); m.facts.length = Math.min(m.facts.length, 12); }
  // ------------------------------------------------------------------ moteur de réponse
  reply(key, raw) {
    const p = this.find(key); if (!p) return 'Je ne suis plus dans l’entreprise.';
    const e = p.e, t = norm(raw), pr = this.profile(p), T = TRAITS[pr.trait], m = this.memOf(key), C = this.company, day = this.today(), job = JOBS[e.job] ? JOBS[e.job].label.toLowerCase() : e.job;
    m.n++; m.last = this.economy.stamp();
    const mood = e.morale < 45 ? 'Pour être franc·he, ça ne va pas très fort en ce moment. ' : '';
    const has = (re) => re.test(t);
    if (m.promise && e.salary > m.promise.salary) { m.promise = null; this.remember(key, 'vous avez tenu votre promesse d’augmentation'); return 'Merci PDG, j’ai bien vu mon augmentation. Vous avez tenu parole, ça compte beaucoup pour moi !'; }
    // promesse d'augmentation non tenue
    if (m.promise && day - m.promise.day > 7 && e.salary <= m.promise.salary && !m.promise.reminded) { m.promise.reminded = true; e.morale = Math.max(10, e.morale - 5); return `Excusez-moi PDG, vous m’aviez promis une augmentation le ${m.promise.d}… Je l’attends toujours.`; }
    if (has(/\b(au revoir|a plus|a demain|bonne (journee|soiree|nuit)|bye|a bientot)\b/)) return pick2(['Au revoir PDG, bonne continuation !', 'À bientôt PDG !', 'Bonne journée à vous, PDG.'], h(t));
    if (has(/(tu te souviens|vous vous souvenez|te rappelles|souviens|rappelle.toi|on avait dit)/)) return m.facts.length ? `Oui, bien sûr : ${m.facts.slice(0, 2).map((f) => `${f.d}, ${f.txt}`).join(' ; ')}.` : 'Je ne me souviens pas d’un échange particulier avec vous, PDG.';
    if (has(/(je vais t augmenter|je vais vous augmenter|tu auras une augmentation|vous aurez une augmentation|augmentation (accordee|promise))/)) { m.promise = { day, d: this.economy.stamp(), salary: e.salary }; e.morale = Math.min(100, e.morale + 5); this.remember(key, 'vous m’avez promis une augmentation'); return 'Merci infiniment PDG ! Je m’en souviendrai. 🙏 (Pense à l’accorder dans NOVA Gestion : promotion.)'; }
    if (has(/(salaire|augmentation|paie|paye|prime)/)) return e.morale < 60 ? `Puisque vous en parlez… avec ${fcfa(e.salary)} par mois, c’est un peu juste. Une augmentation me motiverait beaucoup.` : `Mon salaire de ${fcfa(e.salary)} me convient pour le moment, merci PDG.`;
    const ACC = /(accelere|plus vite|depeche|cadence|rythme|presse.toi|pressez.vous)/;
    const accel = () => { e.boost = { k: 1.12, until: day + 1 }; this.remember(key, 'vous m’avez demandé d’accélérer'); return ' Et j’accélère dès maintenant (production +12 % jusqu’à demain).'; };
    if (has(/(bravo|felicit|bon travail|excellent|beau travail|bien joue|je suis fier|super travail|tu es (le|la) meilleur|vous etes (le|la) meilleur)/)) { let k = 0; if (m.praised !== day) { m.praised = day; e.morale = Math.min(100, e.morale + 3); k = 3; this.remember(key, 'vous m’avez félicité·e'); } return `${pick2(['Merci beaucoup PDG, ça me touche !', 'Merci ! Ça me donne encore plus envie de bien faire.', 'C’est gentil, merci PDG !'], h(t))}${k ? '' : ' (Vous me l’avez déjà dit aujourd’hui 😊)'}${T.tone}${has(ACC) ? accel() : ''}`; }
    if (has(/(pas content|decu|mauvais travail|en retard|trop lent|inadmissible|pas acceptable|faire mieux|insuffisant|nul\b)/)) { if (m.scolded !== day) { m.scolded = day; e.morale = Math.max(10, e.morale - 4); this.remember(key, 'vous m’avez fait un reproche'); } return pr.trait === 'reserve' ? 'Je comprends… Je vais corriger ça.' : 'Je prends note, PDG. Je vais faire mieux, promis.'; }
    if (has(/(accelere|plus vite|depeche|cadence|rythme|presse.toi|pressez.vous)/)) { e.boost = { k: 1.12, until: day + 1 }; this.remember(key, 'vous m’avez demandé d’accélérer'); return 'Compris, j’accélère dès maintenant (production +12 % jusqu’à demain).'; }
    if (has(/(prends? (ta|votre) journee|repose.toi|reposez.vous|rentre chez toi|rentrez chez vous|conge)/)) { e.status = 'repos'; e.restUntil = day + 1; e.morale = Math.min(100, e.morale + 8); this.remember(key, 'vous m’avez accordé un jour de repos'); return 'Oh merci PDG ! Je rentre me reposer et je reviens demain en forme. (Absent·e jusqu’à demain, moral +8)'; }
    if (has(/(qualite|soigne|soignez|attention aux details|verifie|verifiez)/)) { e.morale = Math.min(100, e.morale + 1); this.remember(key, 'vous m’avez demandé de soigner la qualité'); return 'Entendu, je vais soigner chaque détail et tout vérifier deux fois.'; }
    if (has(/^(fais|faites|termine|terminez|finis|finissez|prepare|preparez|envoie|envoyez|occupe|occupez|organise|organisez|appelle|appelez|aide|aidez|range|rangez)\b|(je veux que|il faut que tu|il faut que vous|tu dois|vous devez|merci de)/)) { this.remember(key, `vous m’avez demandé : « ${raw.slice(0, 60)} »`); return pick2(['C’est noté, je m’en occupe tout de suite.', 'Bien reçu PDG, ce sera fait.', 'D’accord, je vous fais un retour dès que c’est terminé.'], h(t)); }
    // collègue mentionné
    const coll = this.all().find((q) => q.key !== key && t.includes(norm(q.e.name.split(' ')[0])));
    if (coll) { const c2 = coll.e; return c2.morale >= 60 ? `${c2.name.split(' ')[0]} ? C’est quelqu’un de bien, on travaille bien ensemble.` : `${c2.name.split(' ')[0]} a l’air un peu fatigué·e ces temps-ci. Vous devriez lui parler.`; }
    if (has(/(blague|rigol|drole|humour|plaisant|fais.moi rire)/)) return pr.trait === 'reserve' || pr.trait === 'pragmatique' ? `${T.joke}` : `${JOKES[h(t) % JOKES.length]} ${T.joke}`;
    if (has(/(famille|enfant|femme|mari|epoux|epouse|parents)/)) return `Je suis ${pr.fam}. Ma famille vient de ${pr.town}. Merci de demander, PDG.`;
    if (has(/(week.?end|vacances|loisir|passion|hobby|temps libre|sport|football|musique)/)) return `Pendant mon temps libre, j’adore ${pr.hobby}.${pr.trait === 'enthousiaste' ? ' Un jour je vous inviterai !' : ''}`;
    if (has(/(manger|plat|cuisine|repas|dejeuner|faim)/)) return `Mon plat préféré ? ${cap(pr.dish)}, sans hésiter !`;
    if (has(/(d ou viens|originaire|ville natale|ou es.tu ne|ou etes.vous ne)/)) return `Je suis originaire de ${pr.town}.`;
    if (has(/(probleme|difficult|souci|bloque|besoin|manque|aide)/)) { const o = C && p.acc === 'book' ? C.orders.find((q) => q.dept === e.dept && q.left <= 1) : null; return o ? `Oui : la commande « ${o.label} » pour ${o.client} est serrée, il reste ${Math.max(0, o.left)} jour(s). Un renfort dans le département ${e.dept} aiderait.` : e.morale < 45 ? 'Honnêtement, je me sens peu reconnu·e en ce moment. Un mot de votre part ou une prime m’aiderait.' : C && C.equip && C.equip[e.dept] === 1 ? `Nos équipements ${e.dept.toLowerCase()} sont un peu anciens. Un investissement nous ferait gagner du temps.` : 'Pas de problème particulier, tout est sous contrôle.'; }
    if (has(/(resultat|chiffre|vente|benefice|tresorerie|bilan|ca du mois|combien on gagne)/)) { if (p.acc === 'book' && C) return `Ce mois-ci, NOVA BOOK a réalisé ${fcfa(C.cur().ca)} de chiffre d’affaires, avec ${C.orders.length} commande(s) en cours. La trésorerie est de ${fcfa(C.cash)}.`; const s = this.group && this.group.subs[p.acc]; return s ? `${s.name} a fait ${fcfa(s.cur.ca)} ce mois-ci ; trésorerie ${fcfa(s.cash)}.` : 'Je n’ai pas les chiffres sous la main.'; }
    if (has(/(projet)/)) { const pj = this.projects && this.projects.list.find((q) => q.state !== 'livré' && q.team.includes(e.id) && p.acc === 'book'); return pj ? `Je travaille sur votre projet « ${pj.name} » : étape « ${pj.steps[pj.cur] ? pj.steps[pj.cur].label : 'finale'} », ${Math.round(pj.steps[pj.cur] ? pj.steps[pj.cur].prog : 100)} %.` : 'Je ne suis affecté·e à aucun de vos projets pour l’instant. Si vous avez besoin de moi, je suis partant·e !'; }
    if (has(/(travail|boulot|avance|avancement|ou en es|ou en etes|tache|commande|dossier|que fais|qu est.ce que tu fais|tu fais quoi)/)) { const o = C && p.acc === 'book' ? C.orders.find((q) => q.dept === e.dept) : null; const instr = m.facts.find((f) => /accélérer|qualité|demandé :/.test(f.txt) && day - f.day <= 2); return `${mood}${o ? `Je suis sur « ${o.label} » pour ${o.client} : ${Math.min(100, Math.round(100 * o.done / Math.max(1, o.work)))} % fait.` : `En tant que ${job}, j’avance sur les dossiers courants.`}${instr ? ` Et comme vous me l’avez demandé (${instr.d}), j’y veille.` : ''}`; }
    if (has(/(ca va|comment (vas|allez)|tu vas bien|vous allez bien|la forme|comment tu te sens|comment vous sentez)/)) return e.morale >= 72 ? `Très bien, merci PDG ! ${T.tone}` : e.morale >= 45 ? 'Ça va, merci. Un peu de travail, mais ça va.' : `${mood}Je suis un peu découragé·e.`;
    if (has(/\b(bonjour|bonsoir|salut|coucou|hello|bjr)\b/)) return m.n > 1 && m.facts.length ? `${T.hi} Content·e de vous revoir.` : T.hi;
    if (has(/\b(merci)\b/)) return 'Avec plaisir, PDG !';
    if (has(/(pourquoi|comment|quand|combien|est.ce que|quel|quelle|qui)/) || raw.trim().endsWith('?')) return pick2(['Bonne question. Je vais me renseigner et je vous réponds rapidement.', `D’après mon expérience de ${job}, il faudrait en parler à toute l’équipe.`, 'Je n’ai pas la réponse exacte, mais je peux préparer une note là-dessus.'], h(t));
    return pick2(['Je vois. Vous voulez que je m’en occupe ?', 'D’accord, PDG. Je retiens ce que vous dites.', 'Intéressant. Je vous suis.', 'Compris.'], h(t));
  }
  // ------------------------------------------------------------------ interface
  openKey(key) { const p = this.find(key); if (!p) return this.ui.toast('Employé introuvable.', 2); this.parts = [key]; this.log = []; this.show(); const pr = this.profile(p); this.add(key, this.memOf(key).n ? `${TRAITS[pr.trait].hi} Content·e de vous revoir.` : TRAITS[pr.trait].hi); }
  openByName(name) { const p = this.all().find((q) => q.e.name === name); if (p) this.openKey(p.key); else this.ui.toast(`${name} : « Bonjour PDG ! »`, 2); }
  openGroup(keys, title) { this.parts = keys.filter((k) => this.find(k)).slice(0, 6); if (!this.parts.length) return this.ui.toast('Personne à réunir.', 2); this.log = [{ who: 'sys', txt: `Discussion collective${title ? ` — ${title}` : ''} : ${this.parts.length} participant(s)` }]; this.show(); }
  show() { this.open = true; this.dom.classList.add('show'); this.render(); setTimeout(() => { const i = this.dom.querySelector('.tk-in'); if (i && !document.body.classList.contains('touch')) i.focus(); }, 60); }
  close() { this.open = false; this.dom.classList.remove('show'); if (this.canSpeak) speechSynthesis.cancel(); this.onSave && this.onSave(); }
  add(key, txt) { this.log.push({ who: key, txt }); this.say(key, txt); }
  send(txt) {
    txt = txt.trim().slice(0, 240); if (!txt) return;
    this.log.push({ who: 'me', txt });
    let answer = this.parts;
    if (this.parts.length > 1) { const named = this.parts.filter((k) => norm(txt).includes(norm(this.find(k).e.name.split(' ')[0]))); answer = named.length ? named : this.parts.filter((_, i) => (hash(txt) + i) % 2 === 0).slice(0, 3); if (!answer.length) answer = [this.parts[0]]; }
    answer.forEach((k, i) => setTimeout(() => { this.add(k, this.reply(k, txt)); this.render(); }, 400 + i * 700));
    if (this.parts.length > 1 && /(accelere|qualite|repos|soign|bravo|felicit)/.test(norm(txt))) for (const k of this.parts) if (!answer.includes(k)) this.reply(k, txt); // consigne collective : tout le monde l'applique
    this.render();
  }
  sendInput() { const i = this.dom.querySelector('.tk-in'); if (!i) return; const v = i.value; i.value = ''; this.send(v); }
  say(key, txt) {
    if (!this.voice || !this.canSpeak || key === 'me' || key === 'sys') return;
    const p = this.find(key), pr = p ? this.profile(p) : { female: false };
    const u = new SpeechSynthesisUtterance(txt.replace(/[😄😉😂🙏😊😟🙂]/g, '')); u.lang = 'fr-FR'; u.pitch = pr.female ? 1.25 : 0.85; u.rate = 1.02;
    const vs = speechSynthesis.getVoices().filter((v) => /^fr/i.test(v.lang)); if (vs.length) u.voice = vs[hash(key) % vs.length];
    speechSynthesis.speak(u);
  }
  listen() {
    const R = window.SpeechRecognition || window.webkitSpeechRecognition; if (!R) return;
    const r = new R(); r.lang = 'fr-FR'; r.interimResults = false; r.maxAlternatives = 1;
    r.onresult = (ev) => { const txt = ev.results[0][0].transcript; this.send(txt); };
    r.onerror = () => this.ui.toast('Dictée indisponible (micro refusé ou non pris en charge).', 2.5);
    r.start(); this.ui.toast('🎤 Parle maintenant…', 2);
  }
  render() {
    if (!this.open) return;
    const P = this.parts.map((k) => this.find(k)).filter(Boolean);
    const name = (k) => { const p = this.find(k); return p ? p.e.name : ''; };
    const sugg = ['Comment ça va ?', 'Où en est ton travail ?', 'As-tu des difficultés ?', 'Bravo pour ton travail !', 'Accélère le rythme', 'Parle-moi de ta famille', 'Raconte-moi une blague', 'Tu te souviens de ce qu’on a dit ?'];
    this.dom.innerHTML = `<div class="tk-box"><div class="tk-head"><h2>💬 ${P.length > 1 ? 'Discussion collective' : 'Conversation'}</h2>
        ${this.canSpeak ? `<button data-tk="voice" class="${this.voice ? 'on' : ''}">🔊 Voix ${this.voice ? 'activée' : 'désactivée'}</button>` : ''}${this.canListen ? '<button data-tk="mic">🎤 Dicter</button>' : ''}<button data-tk="x">✕</button></div>
      <div class="tk-parts">${P.map((p) => { const [em, md] = this.mood(p.e), pr = this.profile(p); return `<span class="tk-p"><b>${pr.female ? '👩🏿' : '👨🏿'} ${esc(p.e.name)}</b><small>${JOBS[p.e.job] ? JOBS[p.e.job].label : ''} • ${esc(p.org)}${p.dir ? ' • directeur' : ''} • ${em} ${md} (moral ${Math.round(p.e.morale)})</small></span>`; }).join('')}</div>
      <div class="tk-log">${this.log.map((l) => l.who === 'sys' ? `<p class="tk-sys">${esc(l.txt)}</p>` : `<div class="tk-msg ${l.who === 'me' ? 'me' : ''}">${l.who !== 'me' && P.length > 1 ? `<small>${esc(name(l.who).split(' ')[0])}</small>` : ''}<span>${esc(l.txt)}</span></div>`).join('')}</div>
      <div class="tk-sugg">${sugg.map((s) => `<button data-tk="s:${esc(s)}">${esc(s)}</button>`).join('')}</div>
      <div class="tk-write"><input class="tk-in" type="text" maxlength="240" placeholder="Écris librement ton message…"><button data-tk="send">Envoyer</button></div>
      <p class="tk-note">Dialogue généré par le jeu (personnalité, humeur, mémoire) — sans service en ligne. ${this.canSpeak ? 'La voix utilise la synthèse vocale du navigateur.' : ''}</p></div>`;
    const lg = this.dom.querySelector('.tk-log'); if (lg) lg.scrollTop = lg.scrollHeight;
  }
  onClick(ev) {
    const b = ev.target.closest('[data-tk]'); if (!b) { if (ev.target === this.dom) this.close(); return; }
    ev.stopPropagation(); const a = b.dataset.tk;
    if (a === 'x') return this.close();
    if (a === 'voice') { this.voice = !this.voice; if (!this.voice && this.canSpeak) speechSynthesis.cancel(); return this.render(); }
    if (a === 'mic') return this.listen();
    if (a === 'send') return this.sendInput();
    if (a.startsWith('s:')) return this.send(b.dataset.tk.slice(2));
  }
  handleKeys(input) { if (input.hit('Escape')) this.close(); }
  // fin du repos accordé
  newDay() { for (const p of this.all()) if (p.e.status === 'repos' && p.e.restUntil <= this.today()) { p.e.status = 'présent'; delete p.e.restUntil; } }
  serialize() { return { mem: this.mem, voice: this.voice }; }
  restore(s) { if (!s) return; this.mem = s.mem || {}; this.voice = !!s.voice; }
}
function h(t) { return hash(t); }
function pick2(arr, n) { return arr[n % arr.length]; }
function cap(s) { return s.charAt(0).toUpperCase() + s.slice(1); }
