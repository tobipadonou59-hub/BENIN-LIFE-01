// Mission 013, étape 6 — géographie de la région (Cotonou, Porto-Novo, Ouidah, Pahou, Cocotomey) à l'échelle 1:5.
// Toutes les positions viennent de src/region-data.js (OpenStreetMap / Natural Earth, voir tools/region/build_region.py).
// Raccords « de jeu » (non géographiques), signalés ici : le littoral est ramené à la plage existante du jeu
// près de la ville (|x| < 1 500 m) et la RNIE 1 est reliée aux boulevards de la ville du jeu.
import { REGION } from './region-data.js';

export { REGION };
export const SEA_Z_CITY = 192;
const smooth = (a, b, v) => { const t = Math.max(0, Math.min(1, (v - a) / (b - a))); return t * t * (3 - 2 * t); };
const COAST = REGION.coast; // trié par x croissant
function realCoast(x) {
  if (x <= COAST[0][0]) { const [a, b] = [COAST[0], COAST[1]]; return a[1] + (x - a[0]) * (b[1] - a[1]) / (b[0] - a[0]); }
  for (let i = 0; i < COAST.length - 1; i++) { const a = COAST[i], b = COAST[i + 1]; if (x <= b[0]) return a[1] + (x - a[0]) * (b[1] - a[1]) / (b[0] - a[0]); }
  const a = COAST[COAST.length - 2], b = COAST[COAST.length - 1]; return b[1] + (x - b[0]) * (b[1] - a[1]) / (b[0] - a[0]);
}
// z du trait de côte (la mer est au sud, z plus grand)
export function coastZ(x) { const k = smooth(450, 1500, Math.abs(x)); return SEA_Z_CITY * (1 - k) + realCoast(x) * k; }

// ---- grille d'eau (lacs) et de routes : tests en O(1) ----
const CELL = 10;
const GX0 = -9600, GZ0 = -4400, GW = 1650, GH = 700; // couvre x −9 600 → 6 900, z −4 400 → 2 600
const lake = new Uint8Array(GW * GH), road = new Uint8Array(GW * GH);
function fillPoly(pts, grid, val) {
  let z0 = Infinity, z1 = -Infinity; for (const p of pts) { z0 = Math.min(z0, p[1]); z1 = Math.max(z1, p[1]); }
  for (let j = Math.max(0, Math.floor((z0 - GZ0) / CELL)); j <= Math.min(GH - 1, Math.ceil((z1 - GZ0) / CELL)); j++) {
    const z = GZ0 + (j + 0.5) * CELL, xs = [];
    for (let i = 0, k = pts.length - 1; i < pts.length; k = i++) {
      const a = pts[i], b = pts[k];
      if ((a[1] > z) !== (b[1] > z)) xs.push(a[0] + (z - a[1]) * (b[0] - a[0]) / (b[1] - a[1]));
    }
    xs.sort((p, q) => p - q);
    for (let m = 0; m + 1 < xs.length; m += 2) for (let i = Math.max(0, Math.ceil((xs[m] - GX0) / CELL - 0.5)); i <= Math.min(GW - 1, Math.floor((xs[m + 1] - GX0) / CELL - 0.5)); i++) grid[j * GW + i] = val;
  }
}
REGION.lakes.forEach((l, i) => fillPoly(l.pts, lake, i + 1));
// routes : cellules à moins de ~16 m de l'axe
for (const r of REGION.roads) for (let i = 0; i < r.pts.length - 1; i++) {
  const [ax, az] = r.pts[i], [bx, bz] = r.pts[i + 1], L = Math.hypot(bx - ax, bz - az);
  for (let s = 0; s <= L; s += CELL * 0.5) {
    const x = ax + (bx - ax) * s / L, z = az + (bz - az) * s / L;
    for (let dj = -2; dj <= 2; dj++) for (let di = -2; di <= 2; di++) {
      const ci = Math.floor((x - GX0) / CELL) + di, cj = Math.floor((z - GZ0) / CELL) + dj;
      if (ci >= 0 && cj >= 0 && ci < GW && cj < GH && Math.hypot(di, dj) <= 1.7) road[cj * GW + ci] = 1;
    }
  }
}
const cellOf = (x, z) => { const i = Math.floor((x - GX0) / CELL), j = Math.floor((z - GZ0) / CELL); return i < 0 || j < 0 || i >= GW || j >= GH ? -1 : j * GW + i; };
export function inLake(x, z) { const c = cellOf(x, z); return c >= 0 && lake[c] > 0; }
export function lakeName(x, z) { const c = cellOf(x, z); return c >= 0 && lake[c] > 0 ? REGION.lakes[lake[c] - 1].name : null; }
export function nearRoad(x, z) { const c = cellOf(x, z); return c >= 0 && road[c] === 1; }
// jetées du port (mission 012, étape 4) : surfaces praticables au-dessus de la mer
export const PIERS = [];
export const onPier = (x, z, m = 0) => PIERS.some((r) => x > r.x0 - m && x < r.x1 + m && z > r.z0 - m && z < r.z1 + m);
export function isWater(x, z) { return (z > coastZ(x) - 1 || inLake(x, z)) && !onPier(x, z); }

// limites de déplacement au sol (ville + aéroport + région)
export const LAND = { minX: -9000, maxX: 6200, minZ: -3900 };
// garde un objet (joueur, voiture) sur la terre ferme : bords de la région, mer et lacs
export function landClamp(obj, margin = 1) {
  const p = obj.pos;
  p.x = Math.max(LAND.minX, Math.min(LAND.maxX, p.x));
  if (onPier(p.x, p.z)) return; // sur une jetée du port
  if ((obj.floorY || 0) > 50) return; // espaces intérieurs placés en hauteur (ponts des navires, sociétés…)
  p.z = Math.max(LAND.minZ, Math.min(coastZ(p.x) - margin, p.z));
  if (inLake(p.x, p.z)) { if (obj._dry) { p.x = obj._dry.x; p.z = obj._dry.z; if (obj.speed) obj.speed *= -0.2; } }
  else { if (!obj._dry) obj._dry = { x: 0, z: 0 }; obj._dry.x = p.x; obj._dry.z = p.z; }
}

// ---- villes ----
export const TOWNS = REGION.towns.filter((t) => t.name !== 'Cotonou').map((t) => ({
  ...t, r: { 'Porto-Novo': 520, Ouidah: 420, Pahou: 230, Cocotomey: 280 }[t.name] || 250,
  sub: { 'Porto-Novo': 'Capitale du Bénin', Ouidah: 'Commune de Ouidah', Pahou: 'Arrondissement de Pahou (Ouidah)', Cocotomey: 'Abomey-Calavi' }[t.name] || '',
}));
// point de la RNIE 1 le plus proche
export function nearestOnRoad(x, z) {
  let best = null;
  REGION.roads.forEach((r, ri) => {
    let acc = 0;
    for (let i = 0; i < r.pts.length - 1; i++) {
      const [ax, az] = r.pts[i], [bx, bz] = r.pts[i + 1], L = Math.hypot(bx - ax, bz - az) || 1e-6;
      const t = Math.max(0, Math.min(1, ((x - ax) * (bx - ax) + (z - az) * (bz - az)) / (L * L)));
      const px = ax + (bx - ax) * t, pz = az + (bz - az) * t, d = Math.hypot(x - px, z - pz);
      if (!best || d < best.d) best = { d, x: px, z: pz, road: ri, s: acc + t * L, h: Math.atan2(bx - ax, bz - az) };
      acc += L;
    }
  });
  return best;
}
export function regionZone(x, z) {
  for (const t of TOWNS) if (Math.hypot(x - t.x, z - t.z) < t.r) return t.name;
  if (Math.abs(x) < 200 && z > -200) return null; // ville du jeu : noms de quartiers existants
  if (inLake(x, z)) return lakeName(x, z);
  if (nearRoad(x, z)) return 'RNIE 1';
  if (x < -9000 || x > 6200) return null;
  return x < -400 && z > -100 ? null : 'Environs de Cotonou';
}
