// Vie quotidienne : jauges (faim, énergie, propreté) et sauvegarde de la partie (localStorage).
export class Needs {
  constructor() { this.hunger = 80; this.energy = 85; this.hygiene = 80; }
  // gameHours : heures de jeu écoulées ; effort : 0 (repos) à 1 (course)
  update(gameHours, effort = 0) {
    this.hunger = Math.max(0, this.hunger - gameHours * (4 + effort * 4));
    this.energy = Math.max(0, this.energy - gameHours * (3 + effort * 5));
    this.hygiene = Math.max(0, this.hygiene - gameHours * (2.5 + effort * 4));
  }
  get canRun() { return this.energy > 12; }
  serialize() { return { hunger: this.hunger, energy: this.energy, hygiene: this.hygiene }; }
  restore(s) { if (s) { this.hunger = s.hunger ?? this.hunger; this.energy = s.energy ?? this.energy; this.hygiene = s.hygiene ?? this.hygiene; } }
}

const KEY = 'beninlife.save.v1';
let locked = false; // après « Nouvelle partie », plus aucune écriture jusqu'au rechargement
export const SaveGame = {
  load() { try { const s = JSON.parse(localStorage.getItem(KEY) || 'null'); return s && s.version === 1 ? s : null; } catch (e) { return null; } },
  save(data) { if (locked) return false; try { localStorage.setItem(KEY, JSON.stringify({ version: 1, savedAt: Date.now(), ...data })); return true; } catch (e) { return false; } },
  clear() { locked = true; try { localStorage.removeItem(KEY); } catch (e) { /* stockage indisponible */ } },
};
