// Mission 012 — étape 1 : garage, véhicules du garage (modèles 3D procéduraux, portes, feux, tableau de bord,
// caméra intérieure, dégâts visuels, couleurs, sauvegarde des véhicules possédés, chargement à proximité).
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { DrivableCar, extrudeProfile, colorize, glassMat, paintMat, wheelMat, wheelGeometry } from './vehicles.js';
import { CARS, CAR_BY_ID, COLOR_NAMES } from './cars-data.js';
import { clamp, damp } from './util.js';
import { MAP, SEA_Z, GARAGE_LOT, BOUNDS } from './world.js';
import { landClamp } from './region-geo.js';

const PI = Math.PI;
const BLACK = 0x161718, CHROME = 0xc8ccd0, DARK = 0x0d0d0f;
const geoCache = {};
const cached = (k, f) => geoCache[k] || (geoCache[k] = f());

// ---------- construction 3D ----------
function buildBody(spec, hex) {
  const parts = [], W = spec.width, L = spec.len / 2;
  const add = (g, c) => parts.push(colorize(g, c));
  const box = (w, h, d, x, y, z, c, rx = 0) => add(new THREE.BoxGeometry(w, h, d).rotateX(rx).translate(x, y, z), c);
  const cyl = (r, h, x, y, z, c, axis = 'z', seg = 14) => { const g = new THREE.CylinderGeometry(r, r, h, seg); if (axis === 'z') g.rotateX(PI / 2); else if (axis === 'x') g.rotateZ(PI / 2); add(g.translate(x, y, z), c); };
  add(extrudeProfile(spec.lower, W, spec.wedge ? 0.03 : 0.06), hex);
  if (spec.roof) box(W - 0.14, 0.06, spec.roof[2], 0, spec.roof[1], spec.roof[0], spec.blackRoof ? BLACK : hex);
  // bas de caisse, pare-chocs, passages de roue
  box(W - 0.2, 0.18, spec.len - 0.7, 0, (spec.lower[0][1]) + 0.02, 0, 0x111111);
  const E = L + 0.06; // la caisse extrudée dépasse le profil de la valeur du biseau
  box(W + 0.02, 0.2, 0.16, 0, spec.lower[0][1] + 0.12, E, spec.wedge ? hex : BLACK);
  box(W + 0.02, 0.2, 0.16, 0, spec.lower[0][1] + 0.12, -E, spec.wedge ? hex : BLACK);
  for (const z of spec.wheelZ) for (const s of [-1, 1]) {
    const arch = new THREE.CylinderGeometry(spec.wheelR + 0.08, spec.wheelR + 0.08, 0.08, 16, 1, false, 0, PI).rotateZ(PI / 2).rotateX(-PI / 2);
    add(arch.translate(s * (W / 2 - 0.02), spec.wheelR, z), spec.flares ? BLACK : 0x0a0a0a);
  }
  // rétroviseurs, poignées
  const cabFront = spec.cabin ? spec.cabin[spec.cabin.length - 1][0] : 1.0;
  for (const s of [-1, 1]) {
    box(0.08, 0.1, 0.2, s * (W / 2 + 0.07), spec.belt + 0.08, cabFront - 0.2, spec.blackRoof ? BLACK : hex);
    box(0.03, 0.04, 0.22, s * (W / 2 + 0.01), spec.belt - 0.12, cabFront - spec.doorZ[1] * 0.7, CHROME);
  }
  // calandres
  const gy = spec.headY - 0.12;
  if (spec.grille === 'kidney') for (const s of [-1, 1]) box(0.26, 0.24, 0.05, s * 0.16, gy, E + 0.01, DARK);
  else if (spec.grille === 'tall') { box(0.62, 0.5, 0.06, 0, gy + 0.1, E + 0.01, CHROME); for (let i = -4; i <= 4; i++) box(0.02, 0.46, 0.07, i * 0.065, gy + 0.1, E + 0.03, 0x8a8e92); }
  else if (spec.grille === 'wide') box(1.0, 0.32, 0.05, 0, gy - 0.02, E + 0.01, DARK);
  else if (!spec.wedge) box(0.8, 0.14, 0.05, 0, gy, E + 0.01, DARK);
  if (spec.sideIntake) for (const s of [-1, 1]) box(0.04, 0.22, 0.5, s * (W / 2), 0.62, -0.75, DARK);
  if (spec.hoodScoop) box(0.5, 0.08, 0.6, 0, spec.lower[4] ? spec.lower[4][1] + 0.04 : 1.02, 1.5, BLACK);
  if (spec.stripes) for (const s of [-1, 1]) box(0.16, 0.012, spec.len - 0.5, s * 0.16, 1.015, 0.05, 0x111111);
  if (spec.chromeLine) for (const s of [-1, 1]) box(0.02, 0.03, spec.len - 1.2, s * (W / 2 + 0.005), spec.belt - 0.04, 0, CHROME);
  // ailerons
  if (spec.spoiler === 'wing') { box(W - 0.3, 0.04, 0.32, 0, 1.18, -L + 0.25, BLACK); for (const s of [-1, 1]) box(0.04, 0.22, 0.12, s * 0.55, 1.06, -L + 0.25, BLACK); }
  else if (spec.spoiler === 'duck') box(W - 0.5, 0.05, 0.25, 0, 0.9, -L + 0.3, hex);
  else if (spec.spoiler === 'lip') box(W - 0.6, 0.03, 0.12, 0, spec.lower[1][1] + 0.02, -L + 0.12, BLACK);
  // accessoires tout-terrain
  if (spec.spare) cyl(0.38, 0.24, 0, 1.0, -E - 0.12, BLACK);
  if (spec.roofRack) { box(W - 0.3, 0.05, 2.2, 0, 1.98, -0.85, BLACK); for (const s of [-1, 1]) box(0.04, 0.12, 2.2, s * (W / 2 - 0.15), 2.02, -0.85, BLACK); }
  if (spec.snorkel) { box(0.1, 0.9, 0.1, W / 2 + 0.06, 1.45, 1.25, BLACK); box(0.12, 0.1, 0.22, W / 2 + 0.06, 1.92, 1.32, BLACK); }
  if (spec.bullbar) { box(W - 0.5, 0.06, 0.06, 0, 0.95, L + 0.2, BLACK); for (const s of [-1, 1]) box(0.06, 0.5, 0.06, s * 0.45, 0.72, L + 0.2, BLACK); }
  if (spec.bed) { for (const s of [-1, 1]) box(0.06, 0.42, 2.05, s * (W / 2 - 0.04), 1.2, -1.6, hex); box(W, 0.42, 0.06, 0, 1.2, -L + 0.03, hex); box(W - 0.12, 0.04, 2.0, 0, 0.98, -1.6, 0x222222); }
  if (spec.boxy) { box(W + 0.04, 0.05, 0.05, 0, 1.15, 0, BLACK); for (const s of [-1, 1]) box(0.08, 0.06, 0.6, s * (W / 2 + 0.02), 0.62, 0.0, BLACK); }
  // échappements
  for (let i = 0; i < (spec.exhaust || 0); i++) { const n = spec.exhaust, x = (i - (n - 1) / 2) * (n > 2 ? 0.22 : 0.8); cyl(0.05, 0.12, x, spec.lower[0][1] + 0.1, -E - 0.04, CHROME); }
  return mergeGeometries(parts);
}

function wedgeGlass(spec) {
  // vitrage du pick-up électrique : plaques latérales + pare-brise sur la pente avant
  const W = spec.width, parts = [];
  const side = new THREE.Shape([[-1.25, 1.38], [-0.32, 1.88], [1.05, 1.5], [1.0, 1.36]].map(([z, y]) => new THREE.Vector2(z, y)));
  for (const s of [-1, 1]) { const g = new THREE.ShapeGeometry(side); g.rotateY(-PI / 2 * s); g.translate(s * (W / 2 + 0.006), 0, 0); parts.push(g); }
  const a = new THREE.Vector3(0, 1.98, -0.3), b = new THREE.Vector3(0, 1.32, 2.0);
  const p0 = a.clone().lerp(b, 0.08), p1 = a.clone().lerp(b, 0.62);
  const len = p0.distanceTo(p1), ang = Math.atan2(b.y - a.y, b.z - a.z);
  const ws = new THREE.PlaneGeometry(W - 0.25, len).rotateX(-PI / 2).rotateX(-ang).translate(0, (p0.y + p1.y) / 2 + 0.015, (p0.z + p1.z) / 2);
  parts.push(ws);
  return mergeGeometries(parts.map((g) => g.index ? g.toNonIndexed() : g));
}

export function buildCarMesh(spec, hex, opts = {}) {
  const g = new THREE.Group(), W = spec.width, L = spec.len / 2 + (spec.wedge ? 0.03 : 0.06) + 0.02; // feux posés devant le biseau de la caisse
  const bodyGeo = buildBody(spec, hex);
  const body = new THREE.Mesh(bodyGeo, paintMat()); body.castShadow = true; body.receiveShadow = true; g.add(body);
  const glass = new THREE.Mesh(cached('glass_' + spec.id, () => spec.wedge ? wedgeGlass(spec) : extrudeProfile(spec.cabin, W - 0.1, 0.04)), glassMat());
  g.add(glass);
  // roues (pivot de braquage + rotation)
  const wg = cached('wheel_' + spec.wheelR, () => wheelGeometry(spec.wheelR));
  const wheels = [];
  for (const z of spec.wheelZ) for (const s of [1, -1]) {
    const pivot = new THREE.Group(); pivot.position.set(s * spec.wheelX, spec.wheelR, z); g.add(pivot);
    const spin = new THREE.Mesh(wg, wheelMat()); spin.castShadow = true; spin.scale.x = 1.15; pivot.add(spin);
    wheels.push({ pivot, spin });
  }
  // feux (matériaux propres à chaque véhicule pour allumer / freiner / casser)
  const headMat = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xfff2d0, emissiveIntensity: 0.15, roughness: 0.2 });
  const tailMat = new THREE.MeshStandardMaterial({ color: 0x8a0a0a, emissive: 0xff1010, emissiveIntensity: 0.15, roughness: 0.3 });
  const revMat = new THREE.MeshStandardMaterial({ color: 0xdddddd, emissive: 0xffffff, emissiveIntensity: 0, roughness: 0.3 });
  const heads = [], tails = [];
  const lamp = (geo, mat, arr) => { const m = new THREE.Mesh(geo, mat); g.add(m); arr && arr.push(m); return m; };
  if (spec.lightbar) {
    lamp(new THREE.BoxGeometry(W - 0.1, 0.04, 0.04).translate(0, spec.headY + 0.08, L + 0.01), headMat, heads);
    lamp(new THREE.BoxGeometry(W - 0.1, 0.05, 0.04).translate(0, spec.tailY, -L - 0.01), tailMat, tails);
  } else {
    for (const s of [-1, 1]) {
      const hg = spec.roundLights ? new THREE.CylinderGeometry(0.11, 0.11, 0.06, 16).rotateX(PI / 2) : new THREE.BoxGeometry(0.36, 0.11, 0.06);
      lamp(hg.translate(s * (W / 2 - 0.3), spec.headY, L + 0.02), headMat, heads);
      if (spec.quadTail) for (const k of [0, 1]) lamp(new THREE.CylinderGeometry(0.08, 0.08, 0.05, 14).rotateX(PI / 2).translate(s * (W / 2 - 0.22 - k * 0.22), spec.tailY, -L - 0.02), tailMat, tails);
      else if (spec.tripleTail) for (const k of [0, 1, 2]) lamp(new THREE.BoxGeometry(0.06, 0.16, 0.05).translate(s * (W / 2 - 0.2 - k * 0.1), spec.tailY, -L - 0.02), tailMat, tails);
      else lamp(new THREE.BoxGeometry(0.34, 0.12, 0.05).translate(s * (W / 2 - 0.26), spec.tailY, -L - 0.02), tailMat, tails);
    }
    if (spec.lightbarRear) lamp(new THREE.BoxGeometry(W - 0.6, 0.03, 0.04).translate(0, spec.tailY + 0.02, -L - 0.02), tailMat, tails);
  }
  for (const s of [-1, 1]) lamp(new THREE.BoxGeometry(0.1, 0.06, 0.04).translate(s * 0.35, spec.tailY - 0.14, -L - 0.02), revMat);
  // portes avant (panneau peint articulé sur l'avant)
  const doors = [];
  const cabFront = spec.wedge ? 1.0 : spec.cabin[spec.cabin.length - 1][0];
  const dLen = spec.doorZ[1], dTop = spec.belt + (spec.wedge ? 0.5 : 0.02), dBot = spec.lower[0][1] + 0.12;
  for (const s of [1, -1]) {
    const pivot = new THREE.Group(); pivot.position.set(s * (W / 2 + 0.012), 0, cabFront - 0.05); g.add(pivot);
    const panel = new THREE.Mesh(colorize(new THREE.BoxGeometry(0.035, dTop - dBot, dLen).translate(0, (dTop + dBot) / 2, -dLen / 2), hex), paintMat());
    panel.castShadow = true; pivot.add(panel);
    const handle = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.04, 0.2).translate(s * 0.02, spec.belt - 0.12, -dLen * 0.7), new THREE.MeshStandardMaterial({ color: CHROME, metalness: 0.8, roughness: 0.25 }));
    pivot.add(handle);
    doors.push({ pivot, side: s, open: 0, target: 0 });
  }
  // intérieur : sièges, planche de bord, volant (visibles en vue intérieure)
  const inter = new THREE.Group(); g.add(inter);
  const im = new THREE.MeshStandardMaterial({ color: opts.interior || 0x2a2420, roughness: 0.8 });
  const seatZ = spec.seatZ, seatY = spec.lower[0][1] + 0.25;
  for (const s of [1, -1]) {
    inter.add(new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.14, 0.52).translate(s * W * 0.22, seatY, seatZ), im));
    inter.add(new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.62, 0.12).rotateX(-0.2).translate(s * W * 0.22, seatY + 0.35, seatZ - 0.28), im));
  }
  const dashZ = cabFront - 0.25;
  inter.add(new THREE.Mesh(new THREE.BoxGeometry(W - 0.25, 0.22, 0.4).translate(0, spec.belt - 0.04, dashZ), new THREE.MeshStandardMaterial({ color: 0x18181a, roughness: 0.7 })));
  const gauge = new THREE.Mesh(new THREE.PlaneGeometry(0.26, 0.08), new THREE.MeshBasicMaterial({ color: 0x2a8ab0, toneMapped: false }));
  gauge.position.set(W * 0.22, spec.belt + 0.03, dashZ - 0.21); gauge.rotation.x = -0.35; gauge.rotation.y = PI; inter.add(gauge);
  const wheelS = new THREE.Group(); wheelS.position.set(W * 0.22, spec.belt - 0.08, dashZ - 0.3); wheelS.rotation.x = -0.6; inter.add(wheelS);
  const sw = new THREE.Mesh(new THREE.TorusGeometry(0.17, 0.022, 8, 24), new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.5 }));
  wheelS.add(sw, new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.03, 0.02), sw.material));
  return { group: g, body, wheels, doors, headMat, tailMat, revMat, heads, steeringWheel: sw, interior: inter, eye: new THREE.Vector3(W * 0.22, spec.eyeY + 0.04, seatZ + 0.02), bodyColors: bodyGeo.attributes.color.array.slice() };
}

// ---------- véhicule conduisible du garage ----------
export class GarageCar extends DrivableCar {
  constructor(scene, { x, z, h, model, color, damage = 0 }) {
    super(scene, { x, z, h, color, model: 'sedan' });
    scene.remove(this.mesh); this.mesh.children[0].geometry.dispose(); // carrosserie provisoire de la classe de base
    this.spec = CAR_BY_ID[model]; this.modelId = model; this.color = color;
    const m = buildCarMesh(this.spec, color);
    this.parts = m; this.mesh = m.group; this.wheels = m.wheels;
    this.model = { wheelR: this.spec.wheelR };
    this.sound = this.spec.sound; this.hornFreqs = this.spec.horn;
    this.vel = new THREE.Vector2(); this.rpm = 900; this.gear = 0; this.braking = false; this.throttle = 0;
    this.damage = 0; this.brokenHead = [false, false];
    this.doorT = 0; this.scene = scene;
    scene.add(this.mesh);
    if (damage > 0) this.addDamage(damage, new THREE.Vector3(0, 0.8, this.spec.len / 2), true);
    this.sync();
  }
  enableHeadlight() { /* phare dynamique partagé géré par le garage */ }
  circles() {
    const f = this.forward, o = this.spec.len / 2 - 1.0, r = this.spec.width / 2 + 0.05;
    return [{ x: this.pos.x + f.x * o, z: this.pos.z + f.z * o, r }, { x: this.pos.x - f.x * o, z: this.pos.z - f.z * o, r }, { x: this.pos.x, z: this.pos.z, r }];
  }
  onEnter() { this.doorT = 1.1; }
  onExit() { this.doorT = 1.1; }
  update(dt, input, world, obstacles) {
    const S = this.spec.stats, vmaxF = this.damage > 70 ? 0.75 : 1;
    const VMAX = (S.vmax / 3.6) * vmaxF, A0 = (27.8 / S.t100) * 1.2, REV = 9;
    const f = this.forward;
    let thr = 0, st = 0, hb = false;
    if (this.occupied && input) {
      thr = (input.down('KeyW') || input.down('ArrowUp') ? 1 : 0) - (input.down('KeyS') || input.down('ArrowDown') ? 1 : 0);
      st = (input.down('KeyA') || input.down('ArrowLeft') ? 1 : 0) - (input.down('KeyD') || input.down('ArrowRight') ? 1 : 0);
      hb = input.down('Space');
    }
    let v = this.speed; // vitesse longitudinale (le long des roues)
    this.braking = false;
    if (thr > 0) { if (v < -0.3) { v += S.brake * dt; this.braking = true; } else v += A0 * Math.max(0, 1 - (v / VMAX) ** 2) * dt; }
    else if (thr < 0) { if (v > 0.3) { v -= S.brake * dt; this.braking = true; } else v -= 5 * (1 + v / REV) * dt; }
    else v -= Math.sign(v) * Math.min(Math.abs(v), (1.5 + Math.abs(v) * 0.04) * dt);
    if (hb) { v -= Math.sign(v) * Math.min(Math.abs(v), 9 * dt); this.braking = true; }
    this.throttle = Math.max(0, thr);
    const maxSteer = S.steer / (1 + Math.abs(v) * 0.05) * (this.damage > 70 ? 0.85 : 1);
    this.steer = damp(this.steer, st * maxSteer + (this.damage > 70 ? Math.sin(performance.now() / 300) * 0.02 : 0), 9, dt);
    const L = this.spec.wheelZ[0] - this.spec.wheelZ[1];
    // vecteur vitesse actuel (avant + glisse latérale), puis rotation du véhicule
    const r0 = { x: f.z, z: -f.x }, lat0 = this.lat || 0;
    const wx = f.x * v + r0.x * lat0, wz = f.z * v + r0.z * lat0;
    this.heading += (v / L) * Math.tan(this.steer) * dt * (hb ? 1.35 : 1);
    const f2 = this.forward, r2 = { x: f2.z, z: -f2.x };
    // adhérence : la part latérale du mouvement disparaît vite (glisse au frein à main)
    const grip = hb && Math.abs(v) > 6 ? 1.4 : S.grip;
    const prev = this.speed;
    this.speed = wx * f2.x + wz * f2.z;
    this.lat = (wx * r2.x + wz * r2.z) * Math.exp(-grip * dt);
    this.slip = Math.abs(this.lat);
    this.vel.set(f2.x * this.speed + r2.x * this.lat, f2.z * this.speed + r2.z * this.lat);
    this.pos.x += this.vel.x * dt; this.pos.z += this.vel.y * dt;
    // collisions
    let impact = 0, hitOff = 0;
    const o = this.spec.len / 2 - 1.0, r = this.spec.width / 2 + 0.05;
    for (const off of [o, -o]) {
      const c = { x: this.pos.x + f2.x * off, z: this.pos.z + f2.z * off };
      const n = world.collision.resolve(c, r, obstacles);
      if (n) {
        this.pos.x += c.x - (this.pos.x + f2.x * off); this.pos.z += c.z - (this.pos.z + f2.z * off);
        const vn = (f2.x * n.x + f2.z * n.z) * Math.sign(this.speed);
        if (vn < -0.2 && Math.abs(this.speed) > impact) { impact = Math.abs(this.speed); hitOff = off; }
        const keep = vn < -0.5 ? -0.25 : 0.96;
        this.vel.multiplyScalar(keep); this.speed *= keep; this.lat = (this.lat || 0) * 0.5;
      }
    }
    landClamp(this, 3);
    if (impact > 4 && this.occupied) this.addDamage(impact * 1.6, new THREE.Vector3(0, 0.75, Math.sign(hitOff) * this.spec.len / 2));
    // boîte de vitesses et régime moteur (tableau de bord + son)
    const av = Math.abs(this.speed), G = this.spec.gears;
    if (G <= 1) { this.gear = 1; this.rpm = av / VMAX; }
    else {
      const top = VMAX * 1.02; let g = Math.min(G, 1 + Math.floor((av / top) ** 0.8 * G));
      this.gear = g;
      const lo = top * ((g - 1) / G) ** 1.25, hi = top * (g / G) ** 1.25;
      const fr = clamp((av - lo) / Math.max(1, hi - lo), 0, 1);
      const target = av < 0.3 ? 850 + this.throttle * 2500 : 1800 + fr * 5200 + this.throttle * 300;
      this.rpm += (target - this.rpm) * Math.min(1, dt * 8);
    }
    const acc = dt > 0 ? (this.speed - prev) / dt : 0;
    this.pitch = damp(this.pitch, clamp(-acc * 0.004, -0.045, 0.045), 6, dt);
    this.sync(dt);
    return impact;
  }
  addDamage(amount, localPt, silent = false) {
    const before = this.damage;
    this.damage = Math.min(100, this.damage + amount);
    // rayures et salissures autour du point de choc (couleurs de sommets de la carrosserie)
    const col = this.parts.body.geometry.attributes.color, pos = this.parts.body.geometry.attributes.position;
    const R2 = 1.1 + amount * 0.03;
    for (let i = 0; i < pos.count; i++) {
      const dx = pos.getX(i) - localPt.x, dy = pos.getY(i) - localPt.y, dz = pos.getZ(i) - localPt.z;
      const d2 = dx * dx * 0.25 + dy * dy + dz * dz;
      if (d2 > R2 * R2) continue;
      const n = Math.abs(Math.sin(i * 12.9898 + amount) * 43758.5453) % 1;
      const k = 0.55 + n * 0.35;
      col.setXYZ(i, col.getX(i) * k + 0.04, col.getY(i) * k + 0.03, col.getZ(i) * k + 0.02);
    }
    col.needsUpdate = true;
    if (localPt.z > 0 && this.damage > 35 && !this.brokenHead[0]) { this.brokenHead[0] = true; if (this.parts.heads[0]) this.parts.heads[0].visible = false; }
    if (localPt.z > 0 && this.damage > 60 && !this.brokenHead[1]) { this.brokenHead[1] = true; if (this.parts.heads[1]) this.parts.heads[1].visible = false; }
    if (!silent && this.onDamage) this.onDamage(this, before);
  }
  repair() {
    this.damage = 0; this.brokenHead = [false, false];
    for (const h of this.parts.heads) h.visible = true;
    const col = this.parts.body.geometry.attributes.color; col.array.set(this.parts.bodyColors); col.needsUpdate = true;
  }
  sync(dt = 0) {
    super.sync(dt);
    if (!this.parts) return;
    // portes : s'ouvrent pendant l'entrée / la sortie
    if (this.doorT > 0) this.doorT -= dt;
    const want = this.doorT > 0.25 ? 1 : 0;
    for (const d of this.parts.doors) {
      const t = d.side === 1 ? want : 0; // portière conducteur (côté gauche)
      d.open = damp(d.open, t, 9, dt || 0.016);
      d.pivot.rotation.y = d.side * d.open * 1.05;
    }
    this.parts.steeringWheel.rotation.z = -this.steer * 4;
  }
  setLights(on) {
    const p = this.parts;
    p.headMat.emissiveIntensity = on ? 2.4 : 0.12;
    p.tailMat.emissiveIntensity = this.braking ? 2.6 : on ? 0.9 : 0.12;
    p.revMat.emissiveIntensity = this.speed < -0.3 ? 1.6 : 0;
  }
  dispose(scene) { scene.remove(this.mesh); this.mesh.traverse((o) => { if (o.geometry && o === this.parts.body) o.geometry.dispose(); }); }
}

// ---------- concession / garage ----------
const PAD = [{ x: -48, z: -114.5, h: 0 }, { x: -42, z: -114.5, h: 0 }, { x: -36, z: -114.5, h: 0 }];
const REPAIR = { x: -27, z: -121 };
const COUNTER = { x: -42, z: -127.5 };
const DISPLAY = [{ x: -53, z: -122 }, { x: -42, z: -121 }, { x: -31, z: -122 }].map((p) => ({ ...p, z: p.z }));

function textTexture(lines, w = 1024, h = 256, bg = '#111', fg = '#fcd116') {
  const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d');
  x.fillStyle = bg; x.fillRect(0, 0, w, h);
  x.fillStyle = '#008751'; x.fillRect(0, h - 18, w * 0.4, 18); x.fillStyle = '#fcd116'; x.fillRect(w * 0.4, h - 18, w * 0.3, 18); x.fillStyle = '#e8112d'; x.fillRect(w * 0.7, h - 18, w * 0.3, 18);
  x.fillStyle = fg; x.textAlign = 'center'; x.textBaseline = 'middle';
  x.font = `900 ${Math.round(h * 0.42)}px Arial`; x.fillText(lines[0], w / 2, h * 0.38);
  if (lines[1]) { x.fillStyle = '#ffffff'; x.font = `700 ${Math.round(h * 0.16)}px Arial`; x.fillText(lines[1], w / 2, h * 0.74); }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}

export class Garage {
  constructor(ctx) {
    Object.assign(this, ctx); // scene, renderer, world, player, ui, audio, env, cars, particles, onSave
    this.owned = []; this.live = new Map(); this.uid = 1;
    this.open = false; this.tab = 'shop'; this.sel = CARS[0].id; this.color = CARS[0].colors[0];
    this.interior = false; this.repairT = 0; this.displayT = 0; this.displayIdx = 0; this.display = [];
    this.spot = new THREE.SpotLight(0xfff2d0, 0, 55, 0.55, 0.5, 1.2); this.spot.castShadow = false;
    this.scene.add(this.spot, this.spot.target);
    this.buildLot();
    this.buildDom();
  }

  // ---------- bâtiment ----------
  buildLot() {
    const L = GARAGE_LOT, g = new THREE.Group(), col = this.world.collision;
    const conc = new THREE.MeshStandardMaterial({ color: 0xbfbab0, roughness: 0.85 });
    const wall = new THREE.MeshStandardMaterial({ color: 0xf2efe8, roughness: 0.7 });
    const dark = new THREE.MeshStandardMaterial({ color: 0x22252a, roughness: 0.6 });
    const glass = new THREE.MeshStandardMaterial({ color: 0x1a2a34, metalness: 0.3, roughness: 0.05, transparent: true, opacity: 0.55 });
    const add = (geo, m, x, y, z) => { const o = new THREE.Mesh(geo, m); o.position.set(x, y, z); o.castShadow = o.receiveShadow = true; g.add(o); return o; };
    add(new THREE.BoxGeometry(L.x1 - L.x0, 0.06, L.z1 - L.z0), conc, (L.x0 + L.x1) / 2, 0.03, (L.z0 + L.z1) / 2).castShadow = false;
    // showroom (fond du terrain), façade vitrée vers la rue
    const bx = (L.x0 + L.x1) / 2, bz = L.z0 + 6.5, bw = 34, bd = 11;
    add(new THREE.BoxGeometry(bw, 0.3, bd), dark, bx, 6.6, bz);
    add(new THREE.BoxGeometry(bw, 6.5, 0.3), wall, bx, 3.25, bz - bd / 2);
    for (const s of [-1, 1]) add(new THREE.BoxGeometry(0.3, 6.5, bd), wall, bx + s * bw / 2, 3.25, bz);
    add(new THREE.BoxGeometry(bw - 0.4, 6.2, 0.08), glass, bx, 3.2, bz + bd / 2).castShadow = false;
    for (let i = -3; i <= 3; i++) add(new THREE.BoxGeometry(0.18, 6.4, 0.2), dark, bx + i * 5.4, 3.2, bz + bd / 2);
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(16, 3), new THREE.MeshBasicMaterial({ map: textTexture(['AUTO CONCEPT', 'GARAGE • CONCESSION • RÉPARATION — COTONOU']), toneMapped: false }));
    sign.position.set(bx, 8.4, bz + bd / 2 + 0.05); g.add(sign);
    add(new THREE.BoxGeometry(16.4, 3.4, 0.3), dark, bx, 8.4, bz + bd / 2 - 0.12);
    col.addBox(bx - bw / 2, bz - bd / 2 - 0.2, bx + bw / 2, bz - bd / 2 + 0.3, 7);
    col.addBox(bx - bw / 2 - 0.2, bz - bd / 2, bx - bw / 2 + 0.2, bz + bd / 2, 7);
    col.addBox(bx + bw / 2 - 0.2, bz - bd / 2, bx + bw / 2 + 0.2, bz + bd / 2, 7);
    // comptoir d'accueil (sous l'auvent)
    const cnt = add(new THREE.BoxGeometry(3, 1.1, 0.9), new THREE.MeshStandardMaterial({ color: 0x008751, roughness: 0.6 }), COUNTER.x, 0.55, COUNTER.z);
    col.addBox(COUNTER.x - 1.5, COUNTER.z - 0.45, COUNTER.x + 1.5, COUNTER.z + 0.45, 1.1);
    const cSign = new THREE.Mesh(new THREE.PlaneGeometry(2.6, 0.6), new THREE.MeshBasicMaterial({ map: textTexture(['ACCUEIL', 'choisir un véhicule'], 512, 128, '#008751', '#ffffff'), toneMapped: false }));
    cSign.position.set(COUNTER.x, 1.5, COUNTER.z + 0.46); g.add(cSign);
    // plateformes d'exposition, zone de livraison, atelier de réparation
    this.turntables = DISPLAY.map((p) => add(new THREE.CylinderGeometry(3, 3, 0.18, 40), new THREE.MeshStandardMaterial({ color: 0x2a2d33, metalness: 0.4, roughness: 0.4 }), p.x, 0.12, p.z));
    let lay = 0; // chaque marquage un peu plus haut que le précédent (pas de scintillement)
    const paint = (w, d, x, z, color) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(w, d), new THREE.MeshBasicMaterial({ color, polygonOffset: true, polygonOffsetFactor: -1 - lay, polygonOffsetUnits: -4 - lay * 2 })); m.rotation.x = -PI / 2; m.position.set(x, 0.075 + (lay++ % 2) * 0.008, z); m.receiveShadow = false; g.add(m); };
    for (const p of PAD) { paint(2.6, 5.6, p.x, p.z, 0xfcd116); paint(2.3, 5.3, p.x, p.z, 0x2a2d33); }
    paint(4.6, 7, REPAIR.x, REPAIR.z, 0x2f80ed); paint(4.2, 6.6, REPAIR.x, REPAIR.z, 0x1c2a3c);
    const rSign = new THREE.Mesh(new THREE.PlaneGeometry(4, 1), new THREE.MeshBasicMaterial({ map: textTexture(['ATELIER', 'arrête-toi ici pour réparer'], 512, 128, '#2f80ed', '#ffffff'), toneMapped: false }));
    rSign.position.set(REPAIR.x, 3.2, REPAIR.z - 3.6); g.add(rSign);
    add(new THREE.BoxGeometry(0.2, 3.6, 0.2), dark, REPAIR.x - 2, 1.8, REPAIR.z - 3.6); add(new THREE.BoxGeometry(0.2, 3.6, 0.2), dark, REPAIR.x + 2, 1.8, REPAIR.z - 3.6);
    this.scene.add(g); this.lotGroup = g;
  }

  // ---------- possession, chargement à proximité ----------
  take(modelId, color = CAR_BY_ID[modelId].colors[0]) {
    const pad = PAD.find((p) => !this.carNear(p.x, p.z, 2.5)) || PAD[0];
    const rec = { uid: this.uid++, model: modelId, color, x: pad.x, z: pad.z, h: pad.h, damage: 0 };
    this.owned.push(rec); this.spawn(rec);
    this.ui.toast(`${CAR_BY_ID[modelId].name} t’attend sur la zone de livraison jaune (E pour monter)`, 3);
    if (this.audio && this.audio.ctx) this.audio.tone(880, 0.15, 0.06, 'triangle');
    this.onSave && this.onSave();
  }
  carNear(x, z, r) { for (const c of this.cars) if (Math.hypot(c.pos.x - x, c.pos.z - z) < r) return true; return false; }
  spawn(rec) {
    if (this.live.has(rec.uid)) return;
    const car = new GarageCar(this.scene, rec);
    car.uid = rec.uid; car.onDamage = (c, before) => { if (Math.floor(c.damage / 25) > Math.floor(before / 25)) this.ui.toast(`Carrosserie abîmée : ${Math.round(c.damage)} % — l’atelier AUTO CONCEPT répare gratuitement`, 2.2); };
    this.live.set(rec.uid, car); this.cars.push(car);
  }
  despawn(uid) {
    const car = this.live.get(uid); if (!car || car.occupied) return;
    this.sync(car); car.dispose(this.scene); this.live.delete(uid);
    const i = this.cars.indexOf(car); if (i >= 0) this.cars.splice(i, 1);
  }
  sync(car) { const r = this.owned.find((o) => o.uid === car.uid); if (r) { r.x = car.pos.x; r.z = car.pos.z; r.h = car.heading; r.damage = Math.round(car.damage); } }
  remove(uid) { this.despawn(uid); if (this.live.has(uid)) return; this.owned = this.owned.filter((o) => o.uid !== uid); this.renderMenu(); this.onSave && this.onSave(); }
  deliver(uid) {
    const rec = this.owned.find((o) => o.uid === uid); if (!rec) return;
    const car = this.live.get(uid); if (car && car.occupied) return;
    const pad = PAD.find((p) => !this.carNear(p.x, p.z, 2.5)) || PAD[0];
    this.despawn(uid); Object.assign(rec, { x: pad.x, z: pad.z, h: pad.h });
    this.spawn(rec); this.ui.toast(`${CAR_BY_ID[rec.model].name} livrée sur la zone jaune`, 2); this.renderMenu(); this.onSave && this.onSave();
  }

  // interaction « E » au comptoir
  nearest(x, z) {
    const d = Math.hypot(x - COUNTER.x, z - (COUNTER.z + 1.2));
    return d < 2.6 ? { d, it: { label: () => 'Choisir un véhicule (AUTO CONCEPT)', action: () => this.toggle(true) } } : null;
  }

  update(dt, t, focus) {
    const P = this.player.pos;
    // chargement / déchargement selon la distance
    for (const rec of this.owned) {
      const car = this.live.get(rec.uid);
      const d = Math.hypot((car ? car.pos.x : rec.x) - P.x, (car ? car.pos.z : rec.z) - P.z);
      if (!car && d < 220) this.spawn(rec); else if (car && d > 280 && !car.occupied) this.despawn(rec.uid);
    }
    for (const car of this.live.values()) { car.setLights(this.env.lightsOn > 0.3 || car.occupied && this.env.lightsOn > 0.1); if (car.damage > 65 && Math.random() < dt * 14) this.smoke(car); }
    // phare dynamique unique, porté par le véhicule conduit
    const cur = this.player.inCar && this.player.inCar.spec ? this.player.inCar : null;
    if (cur) {
      const f = cur.forward, on = this.env.lightsOn > 0.2 && !cur.brokenHead[0] + !cur.brokenHead[1] > 0;
      this.spot.position.set(cur.pos.x + f.x * (cur.spec.len / 2), 0.9, cur.pos.z + f.z * (cur.spec.len / 2));
      this.spot.target.position.set(cur.pos.x + f.x * 16, 0, cur.pos.z + f.z * 16);
      this.spot.intensity = on ? this.env.lightsOn * 60 * ((!cur.brokenHead[0] ? 0.5 : 0) + (!cur.brokenHead[1] ? 0.5 : 0)) : 0;
      // atelier : réparation à l'arrêt sur la zone bleue
      if (Math.abs(cur.pos.x - REPAIR.x) < 2.4 && Math.abs(cur.pos.z - REPAIR.z) < 3.5 && Math.abs(cur.speed) < 0.5 && cur.damage > 0) {
        this.repairT += dt;
        if (this.repairT > 0.2 && Math.random() < dt * 20) this.particles.emit(2, new THREE.Vector3(cur.pos.x + (Math.random() - 0.5) * 2, 0.8, cur.pos.z + (Math.random() - 0.5) * 3), () => ({ v: [Math.random() - 0.5, 1.5, Math.random() - 0.5], c: [1, 0.85, 0.4], life: 0.5, g: 6 }));
        if (this.repairT > 2) { cur.repair(); this.repairT = 0; this.ui.toast('Véhicule réparé à neuf par l’atelier AUTO CONCEPT', 2.5); if (this.audio.ctx) this.audio.tone(1046, 0.3, 0.06, 'triangle'); this.onSave && this.onSave(); }
      } else this.repairT = 0;
    } else this.spot.intensity = 0;
    // bâtiment affiché seulement à moins de 170 m ; voitures d'exposition à moins de 90 m
    const dG = Math.hypot(P.x - COUNTER.x, P.z - COUNTER.z);
    this.lotGroup.visible = dG < 170;
    const near = dG < 90;
    if (near && !this.display.length) this.buildDisplay();
    else if (!near && this.display.length) { for (const m of this.display) this.scene.remove(m); this.display = []; }
    if (this.display.length) {
      this.displayT += dt;
      if (this.displayT > 25) { this.displayT = 0; this.displayIdx = (this.displayIdx + 3) % CARS.length; for (const m of this.display) this.scene.remove(m); this.display = []; this.buildDisplay(); }
      this.display.forEach((m, i) => { m.rotation.y += dt * 0.35; this.turntables[i].rotation.y = m.rotation.y; });
    }
    this.updateDash();
    if (this.open) this.renderPreview(t);
    // sauvegarde légère des positions
    this._sT = (this._sT || 0) + dt; if (this._sT > 5) { this._sT = 0; for (const c of this.live.values()) this.sync(c); }
  }
  buildDisplay() {
    DISPLAY.forEach((p, i) => {
      const spec = CARS[(this.displayIdx + i) % CARS.length];
      const m = buildCarMesh(spec, spec.colors[0]).group;
      m.position.set(p.x, 0.21, p.z); this.scene.add(m); this.display.push(m);
    });
  }
  smoke(car) {
    const f = car.forward, o = car.spec.len / 2 - 0.9;
    this.particles.emit(1, new THREE.Vector3(car.pos.x + f.x * o, 1.0, car.pos.z + f.z * o), () => ({ v: [Math.random() * 0.4 - 0.2, 1.2, Math.random() * 0.4 - 0.2], c: [0.35, 0.35, 0.36], life: 1.6, g: -0.4, drag: 0.5 }));
  }

  // ---------- caméra intérieure ----------
  applyInterior(camera, tpc) {
    const car = this.player.inCar;
    if (!this.interior || !car || !car.spec) return false;
    car.mesh.updateMatrixWorld(true);
    const eye = car.parts.eye.clone(); car.mesh.localToWorld(eye);
    let rel = tpc.yaw - (car.heading + PI); while (rel > PI) rel -= 2 * PI; while (rel < -PI) rel += 2 * PI;
    rel = clamp(rel, -1.4, 1.4);
    const yaw = car.heading - rel, pitch = clamp(-(tpc.pitch - 0.3) * 0.8, -0.5, 0.4);
    camera.position.copy(eye);
    camera.lookAt(eye.x + Math.sin(yaw) * Math.cos(pitch) * 10, eye.y + Math.sin(pitch) * 10, eye.z + Math.cos(yaw) * Math.cos(pitch) * 10);
    return true;
  }

  // ---------- tableau de bord ----------
  updateDash() {
    const car = this.player.inCar, el = this.dom.dash;
    const on = !!(car && car.spec);
    if (on !== this._dashOn) { this._dashOn = on; el.classList.toggle('show', on); document.body.classList.toggle('gcar', on); }
    if (!on) return;
    const kmh = Math.round(Math.abs(car.speed) * 3.6), S = car.spec.stats;
    const gear = car.speed < -0.3 ? 'R' : Math.abs(car.speed) < 0.3 && car.throttle === 0 ? 'N' : car.spec.gears <= 1 ? 'D' : String(car.gear);
    const rpmF = car.spec.gears <= 1 ? Math.abs(car.speed) / (S.vmax / 3.6) : clamp(car.rpm / 7500, 0, 1);
    const key = kmh + gear + Math.round(rpmF * 40) + Math.round(car.damage) + (this.interior ? 'i' : 'e') + (this.env.lightsOn > 0.3 ? 'L' : '');
    if (key === this._dashKey) return; this._dashKey = key;
    el.querySelector('.d-name').textContent = car.spec.name;
    el.querySelector('.d-spd').textContent = kmh;
    el.querySelector('.d-gear').textContent = gear;
    el.querySelector('.d-rpm i').style.width = (rpmF * 100).toFixed(0) + '%';
    el.querySelector('.d-rpm').classList.toggle('red', rpmF > 0.88);
    el.querySelector('.d-rpm-l').textContent = car.spec.gears <= 1 ? 'PUISSANCE' : `${Math.round(car.rpm / 100) * 100} tr/min`;
    const dmg = el.querySelector('.d-dmg i'); dmg.style.width = (100 - car.damage).toFixed(0) + '%'; dmg.style.background = car.damage > 65 ? '#e8112d' : car.damage > 30 ? '#fcd116' : '#2fb07a';
    el.querySelector('.d-icons').innerHTML = `${this.env.lightsOn > 0.3 ? '<b title="Phares">💡</b>' : ''}<b title="Vue (V)">${this.interior ? '🪟 intérieure' : '🎥 extérieure'}</b>`;
  }

  // ---------- menu de la concession ----------
  buildDom() {
    const $ = (s) => document.querySelector(s);
    this.dom = { root: $('#gar'), dash: $('#dash') };
    this.dom.dash.innerHTML = `<div class="d-name"></div><div class="d-main"><span class="d-spd">0</span><small>km/h</small><span class="d-gear">N</span></div>
      <div class="d-rpm"><i></i></div><div class="d-rpm-l"></div><div class="d-row"><span>ÉTAT</span><div class="d-dmg"><i></i></div></div><div class="d-icons"></div>`;
    const r = this.dom.root;
    r.innerHTML = `<div class="g-box"><div class="g-head"><h2>AUTO CONCEPT <span>COTONOU</span></h2>
        <div class="g-tabs"><button data-gt="shop">Concession (13)</button><button data-gt="mine">Mes véhicules</button></div><button class="g-x">✕</button></div>
      <div class="g-main"><div class="g-list"></div>
        <div class="g-detail"><canvas class="g-pv" width="360" height="200"></canvas><div class="g-name"></div><div class="g-type"></div>
          <div class="g-stats"></div><div class="g-colors"></div><button class="g-take">PRENDRE CE VÉHICULE</button>
          <p class="g-note">Marques et modèles fictifs, inspirés de catégories de véhicules réelles.</p></div></div></div>`;
    r.querySelector('.g-x').addEventListener('click', (e) => { e.stopPropagation(); this.toggle(false); });
    r.querySelectorAll('[data-gt]').forEach((b) => b.addEventListener('click', (e) => { e.stopPropagation(); this.tab = b.dataset.gt; this.renderMenu(); }));
    r.querySelector('.g-list').addEventListener('click', (e) => {
      const b = e.target.closest('[data-act]'); if (b) { e.stopPropagation(); const uid = +b.dataset.uid; if (b.dataset.act === 'deliver') this.deliver(uid); if (b.dataset.act === 'repair') this.repairOwned(uid); if (b.dataset.act === 'del') this.remove(uid); return; }
      const c = e.target.closest('[data-car]'); if (!c) return; e.stopPropagation();
      this.sel = c.dataset.car; this.color = CAR_BY_ID[this.sel].colors[0]; this.renderMenu();
    });
    r.querySelector('.g-colors').addEventListener('click', (e) => { const b = e.target.closest('[data-col]'); if (!b) return; e.stopPropagation(); this.color = +b.dataset.col; this.renderMenu(); });
    r.querySelector('.g-take').addEventListener('click', (e) => {
      e.stopPropagation(); const bt = e.currentTarget;
      if (this.fortune) { // mission 017 : achat avec le compte personnel, confirmation obligatoire
        if (!bt.dataset.sure) { bt.dataset.sure = '1'; bt.textContent = `CONFIRMER L’ACHAT • ${(this.fortune.priceOf(this.sel)).toLocaleString('fr-FR')} FCFA`; return; }
        delete bt.dataset.sure; if (!this.fortune.payCar(this.sel)) { this.renderMenu(); return; }
      }
      this.take(this.sel, this.color); this.toggle(false);
    });
  }
  repairOwned(uid) {
    const rec = this.owned.find((o) => o.uid === uid); if (!rec) return;
    rec.damage = 0; const car = this.live.get(uid); if (car) car.repair();
    this.ui.toast(`${CAR_BY_ID[rec.model].name} réparée`, 1.8); this.renderMenu(); this.onSave && this.onSave();
  }
  toggle(on = !this.open) { this.open = on; this.dom.root.classList.toggle('show', on); if (on) this.renderMenu(); else this.onSave && this.onSave(); }
  renderMenu() {
    const r = this.dom.root;
    { const tb = r.querySelector('.g-take'); if (tb) { delete tb.dataset.sure; tb.textContent = this.fortune ? `ACHETER • ${this.fortune.priceOf(this.sel).toLocaleString('fr-FR')} FCFA` : 'PRENDRE CE VÉHICULE'; } }
    r.querySelectorAll('[data-gt]').forEach((b) => b.classList.toggle('on', b.dataset.gt === this.tab));
    r.querySelector('[data-gt="mine"]').textContent = `Mes véhicules (${this.owned.length})`;
    const list = r.querySelector('.g-list');
    if (this.tab === 'shop') {
      list.innerHTML = CARS.map((c) => `<button class="g-card${c.id === this.sel ? ' sel' : ''}" data-car="${c.id}"><b>${c.name}</b><small>${c.type}</small>
        <span class="g-mini">${Math.round(c.stats.vmax)} km/h • 0-100 en ${c.stats.t100} s</span></button>`).join('');
    } else {
      const P = this.player.pos;
      list.innerHTML = this.owned.length ? this.owned.map((o) => {
        const c = CAR_BY_ID[o.model], car = this.live.get(o.uid), x = car ? car.pos.x : o.x, z = car ? car.pos.z : o.z, dmg = car ? car.damage : o.damage;
        return `<div class="g-card g-own${o.model === this.sel ? ' sel' : ''}" data-car="${o.model}"><b><i style="background:#${o.color.toString(16).padStart(6, '0')}"></i>${c.name}</b>
          <small>État ${Math.round(100 - dmg)} % • à ${Math.round(Math.hypot(x - P.x, z - P.z))} m${car && car.occupied ? ' • tu conduis' : ''}</small>
          <span class="g-acts"><button data-act="deliver" data-uid="${o.uid}">Livrer ici</button><button data-act="repair" data-uid="${o.uid}">Réparer</button><button data-act="del" data-uid="${o.uid}">Retirer</button></span></div>`;
      }).join('') : '<p class="g-empty">Tu ne possèdes encore aucun véhicule du garage. Choisis-en un dans l’onglet Concession.</p>';
    }
    const c = CAR_BY_ID[this.sel], S = c.stats;
    r.querySelector('.g-name').textContent = c.name;
    r.querySelector('.g-type').textContent = c.type;
    const bar = (k, v, max, txt) => `<div><span>${k}</span><i><b style="width:${Math.round(v / max * 100)}%"></b></i><em>${txt}</em></div>`;
    r.querySelector('.g-stats').innerHTML = bar('Vitesse max', S.vmax, 220, S.vmax + ' km/h') + bar('Accélération', 11 - S.t100, 8.5, '0-100 : ' + S.t100 + ' s')
      + bar('Tenue de route', S.grip, 10, S.grip >= 9 ? 'excellente' : S.grip >= 7.5 ? 'très bonne' : 'bonne') + bar('Freinage', S.brake, 12.5, S.brake + ' m/s²')
      + `<div><span>Moteur</span><em class="g-wide">${{ ev: 'Électrique', v8: 'V8', v12: 'V12', v6: 'V6 biturbo', i6: '6 cylindres en ligne', flat6: '6 cylindres à plat', diesel: 'Diesel' }[c.sound.type]} • ${S.mass} kg</em></div>`;
    r.querySelector('.g-colors').innerHTML = c.colors.map((col) => `<button data-col="${col}" class="${col === this.color ? 'on' : ''}" title="${COLOR_NAMES[col]}" style="background:#${col.toString(16).padStart(6, '0')}"></button>`).join('');
    this._pvKey = null;
  }
  // aperçu 3D tournant (rendu hors écran avec le moteur du jeu)
  renderPreview(t) {
    const key = this.sel + this.color;
    if (key !== this._pvKey) {
      this._pvKey = key;
      if (!this.studio) {
        const sc = new THREE.Scene(); sc.add(new THREE.HemisphereLight(0xffffff, 0x404040, 1.4)); const d = new THREE.DirectionalLight(0xffffff, 2.5); d.position.set(4, 6, 5); sc.add(d);
        const cam = new THREE.PerspectiveCamera(28, 360 / 200, 0.1, 60);
        const rt = new THREE.WebGLRenderTarget(360, 200);
        const lut = new Uint8ClampedArray(256); for (let i = 0; i < 256; i++) { const v = i / 255; lut[i] = Math.round(255 * (v <= 0.0031308 ? v * 12.92 : 1.055 * Math.pow(v, 1 / 2.4) - 0.055)); }
        this.studio = { sc, cam, rt, lut, px: new Uint8Array(360 * 200 * 4), img: new ImageData(360, 200) };
      }
      if (this.studio.car) this.studio.sc.remove(this.studio.car);
      this.studio.car = buildCarMesh(CAR_BY_ID[this.sel], this.color).group; this.studio.sc.add(this.studio.car);
    }
    if ((this._pvF = (this._pvF || 0) + 1) % 2) return; // 1 image sur 2 suffit
    const { sc, cam, rt, lut, px, img } = this.studio, r = this.renderer;
    sc.environment = this.scene.environment;
    this.studio.car.rotation.y = t * 0.6;
    cam.position.set(0, 2.2, 8.6); cam.lookAt(0, 0.75, 0);
    const prev = r.getRenderTarget(), pc = r.getClearColor(new THREE.Color()), pa = r.getClearAlpha();
    r.setRenderTarget(rt); r.setClearColor(0x000000, 0); r.clear(); r.render(sc, cam); r.readRenderTargetPixels(rt, 0, 0, 360, 200, px);
    r.setRenderTarget(prev); r.setClearColor(pc, pa);
    for (let y = 0; y < 200; y++) for (let x = 0; x < 360; x++) {
      const s = ((199 - y) * 360 + x) * 4, o = (y * 360 + x) * 4, a = px[s + 3], un = a ? 255 / a : 0;
      img.data[o] = lut[Math.min(255, (px[s] * un) | 0)]; img.data[o + 1] = lut[Math.min(255, (px[s + 1] * un) | 0)]; img.data[o + 2] = lut[Math.min(255, (px[s + 2] * un) | 0)]; img.data[o + 3] = a;
    }
    this.dom.root.querySelector('.g-pv').getContext('2d').putImageData(img, 0, 0);
  }
  handleKeys(input) {
    if (input.hit('Escape')) { this.toggle(false); return; }
    if (this.tab === 'shop') {
      let i = CARS.findIndex((c) => c.id === this.sel);
      if (input.hit('ArrowDown') || input.hit('KeyS')) i = Math.min(CARS.length - 1, i + 1);
      if (input.hit('ArrowUp') || input.hit('KeyW') || input.hit('KeyZ')) i = Math.max(0, i - 1);
      if (CARS[i].id !== this.sel) { this.sel = CARS[i].id; this.color = CARS[i].colors[0]; this.renderMenu(); }
      const cols = CAR_BY_ID[this.sel].colors; let ci = cols.indexOf(this.color);
      if (input.hit('ArrowRight') || input.hit('KeyD')) { this.color = cols[(ci + 1) % cols.length]; this.renderMenu(); }
      if (input.hit('ArrowLeft') || input.hit('KeyA') || input.hit('KeyQ')) { this.color = cols[(ci + cols.length - 1) % cols.length]; this.renderMenu(); }
      if (input.hit('Enter')) { this.take(this.sel, this.color); this.toggle(false); }
    }
    if (input.hit('Tab')) { this.tab = this.tab === 'shop' ? 'mine' : 'shop'; this.renderMenu(); }
  }

  serialize() { for (const c of this.live.values()) this.sync(c); return { owned: this.owned.map((o) => ({ ...o })), uid: this.uid }; }
  restore(s) {
    if (!s || !Array.isArray(s.owned)) return;
    this.owned = s.owned.filter((o) => CAR_BY_ID[o.model]); this.uid = Math.max(s.uid || 1, ...this.owned.map((o) => o.uid + 1));
  }
}
