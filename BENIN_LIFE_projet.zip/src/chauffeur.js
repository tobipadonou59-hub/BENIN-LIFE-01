// Mission 018, étape 4 — conducteur personnel permanent et transport avec chauffeur.
// Augustin Sossou-Gbèdo (personnage fictif) : costume, casquette de chauffeur, poli, personnalité propre, mémoire des
// trajets, conversations libres (téléphone ou face à face). Application « Chauffeur personnel » : appeler le conducteur,
// il arrive avec LA limousine (l'unique objet BL-LIMO-1, jamais une copie), s'arrête devant le joueur, ouvre la portière
// arrière ; le joueur monte à l'arrière, choisit une destination (entreprises, restaurants, hôtels, aéroport, port,
// marchés, événements, réunions, n'importe quel lieu ou point de la carte) ; trajet automatique sur le réseau routier
// (itinéraires du système de transport existant), dépose près de l'entrée. Secours : contournement des bouchons, puis
// déplacement direct si la route reste bloquée ; dépose au plus près si la destination est loin de toute route.
// « Rentre à la maison » : bouton, message ou commande vocale facultative (reconnaissance vocale du navigateur).
import * as THREE from 'three';
import { createCharacter, SKINS } from './character.js';
import { planRoute, lanePath, sample, snap } from './transport.js';
import { HOME } from './home.js';
import { LIMO_SPOT } from './limousine.js';
import { regionZone } from './region-geo.js';

const PI = Math.PI, SPEED = 14;
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const norm = (s) => s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[’']/g, ' ');
const pick = (a) => a[Math.floor(Math.random() * a.length)];
export const DRIVER = { key: 'drv:1', name: 'Augustin Sossou-Gbèdo', first: 'Augustin', age: 46, origin: 'Abomey', years: 18, family: 'marié, trois enfants (deux garçons et une fille)', hobby: 'le football et la radio', dish: 'l’amiwo de sa femme' };
const HOME_STOP = { id: 'home', label: 'Ma maison', x: HOME.entry.x, z: HOME.entry.z - 5, cat: 'maison' };
const GROUPS = [['maison', '🏠 Ma maison'], ['entreprise', '🏢 Mes entreprises'], ['agenda', '📅 Réunions et événements'], ['restaurant', '🍲 Restaurants'], ['services', '🏨 Hôtels, banques, services'], ['transport', '✈️ Aéroport, port, transports'], ['marche', '🛒 Marchés et centres commerciaux'], ['monument', '🗿 Monuments et places'], ['loisirs', '🌴 Loisirs et nature'], ['ville', '🏙️ Villes'], ['quartier', '🏘️ Quartiers'], ['visitable', '🚪 Autres bâtiments']];

export class Chauffeur {
  constructor(ctx) {
    Object.assign(this, ctx); // scene, world, player, ui, audio, env, economy, limo, security, events, meetings, tpc, traffic, phonePlus, onSave
    this.ride = null; this.trips = []; this.mem = { n: 0, last: null }; this.grp = 'entreprise'; this.open = false; this.salon = false;
    this.hud = document.querySelector('#chauf'); this.hud.addEventListener('click', (e) => { const b = e.target.closest('[data-ch]'); if (!b) return; e.stopPropagation(); this.onHud(b.dataset.ch); });
    // le conducteur : costume sombre, chemise blanche, cravate bordeaux, casquette de chauffeur
    this.c = createCharacter({ skin: SKINS[1], shirtColor: 0xf6f6f6, pants: 0x14161a, jacket: 0x14161a, tie: 0x6a1a2a, collar: true, shoes: 0x0a0a0a, hat: 'cap', hatColor: 0x14161a, watch: 0xd8a830 });
    this.seat(true);
  }
  get riding() { return !!this.ride && this.ride.phase === 'riding'; }
  get busy() { return !!this.ride; }
  car() { return this.limo.car; }
  // conducteur assis au volant (dans la limousine) ou debout à côté
  seat(on) {
    const c = this.c, m = this.car().mesh;
    if (on) { c.sit(false); m.add(c.group); c.group.position.set(-0.42, -0.3, 1.5); c.group.rotation.set(0, 0, 0); c.group.visible = !this.player.inCar || this.player.inCar !== this.car(); }
    else { c.stand && c.stand(); this.scene.add(c.group); }
    this.seated = on;
  }
  // ------------------------------------------------------------------ destinations
  entrance(p) { // point d'entrée connu (sièges NOVA, maison) sinon le lieu lui-même
    if (p.cat === 'maison' || /maison/i.test(p.name)) return HOME_STOP;
    const S = this.security && this.security.sites.find((q) => q.id !== 'maison' && (p.name === q.name || (q.id === 'book' && /NOVA BOOK/.test(p.name))));
    return S ? { ...p, x: S.door.x, z: S.door.z } : p;
  }
  dests(grp) {
    if (grp === 'maison') return [HOME_STOP];
    if (grp === 'agenda') {
      const out = [];
      for (const e of (this.events ? this.events.list : []).filter((q) => q.status === 'acceptée')) out.push({ id: `evt:${e.id}`, label: `🎟️ ${e.title.replace(' (événement fictif)', '')} — J${e.day} ${Math.floor(e.hour)} h`, x: e.place.x, z: e.place.z, cat: 'agenda' });
      for (const m of (this.meetings ? this.meetings.list : []).filter((q) => q.status === 'prévue' && q.room !== 'visio')) {
        const site = m.room.startsWith('f:') ? this.security.site(m.room.slice(2)) : this.security.site('book');
        if (site) out.push({ id: `mtg:${m.id}`, label: `📅 ${m.title} — J${m.day} ${Math.floor(m.hour)} h (${site.name})`, x: site.door.x, z: site.door.z, cat: 'agenda' });
      }
      return out;
    }
    return (this.ui.pois || []).filter((q) => q.cat === grp && !q.small).map((q) => ({ id: q.id, label: q.name, x: q.x, z: q.z, cat: q.cat })).sort((a, b) => a.label.localeCompare(b.label));
  }
  // ------------------------------------------------------------------ appel et trajet
  call(dest, quiet) {
    if (this.player.inCar === this.car()) return this.ui.toast('Vous êtes déjà au volant de la limousine.', 2.2);
    if (this.limo.cabin) this.limo.leaveSalon();
    if (this.ride) { if (dest && this.ride.phase !== 'riding') { this.ride.dest = dest; this.renderHud(); } return; }
    const P = this.player.pos, rt = planRoute(P, P), car = this.car(), near = Math.hypot(car.pos.x - P.x, car.pos.z - P.z);
    this.ride = { phase: 'coming', dest: dest || null, t: Math.max(6, Math.min(25, near / 40)), wait: 0 };
    if (!quiet) this.ui.toast(`📞 ${DRIVER.first} : « Bien, Monsieur le PDG. J’arrive avec la limousine dans ${Math.ceil(this.ride.t)} secondes. Attendez-moi au bord de la route. »`, 3.5);
    if (this.audio && this.audio.ctx) this.audio.tone(990, 0.08, 0.05, 'sine');
    this.economy.phoneOpen && this.economy.togglePhone(false); this.renderHud(); this.onSave && this.onSave();
  }
  arriveForPickup() { // la limousine arrive sur la route la plus proche et s'arrête devant le joueur
    const r = this.ride, P = this.player.pos, S = snap(P.x, P.z);
    const e = S.e, L = Math.hypot(e[2] - e[0], e[3] - e[1]) || 1, ux = (e[2] - e[0]) / L, uz = (e[3] - e[1]) / L;
    const back = { x: S.x - ux * 45, z: S.z - uz * 45 };
    const rt = planRoute(back, { x: S.x, z: S.z }); r.path = lanePath(rt.axis); r.s = 0; r.speed = 9; r.phase = 'approach';
    const car = this.car(); this.limo.door.t = 0; const p = sample(r.path, 0); car.pos.set(p.x, 0, p.z); car.heading = p.h; car.sync();
    if (!this.seated) this.seat(true); this.c.group.visible = true;
  }
  stopAndOpen() {
    const r = this.ride; r.phase = 'waiting'; r.wait = 150; r.speed = 0; this.car().speed = 0;
    this.limo.doors.r.t = 1; if (this.audio && this.audio.ctx) { this.audio.horn(this.car().pos.x, this.car().pos.z, 'car', true); this.audio.door(); }
    // le conducteur descend et se tient près de la portière arrière (côté trottoir)
    this.seat(false); const p = this.limo.local(1.6, 0.4); this.c.group.position.set(p.x, 0, p.z); this.c.group.rotation.y = this.car().heading - PI / 2;
    this.ui.toast(`🚘 ${DRIVER.first} vous ouvre la portière arrière : « Je vous en prie, Monsieur le PDG. » (E pour monter)`, 3.5); this.renderHud();
  }
  nearest(x, z) {
    const r = this.ride, car = this.car();
    if (r && r.phase === 'waiting') { const d = Math.hypot(x - car.pos.x, z - car.pos.z); if (d < 5.5) return { d: Math.max(0, d - 2), it: { label: () => `Monter à l’arrière de la limousine${r.dest ? ` → ${r.dest.label}` : ''}`, action: () => this.board() } }; }
    if (!this.seated && this.c.group.visible) { const d = Math.hypot(x - this.c.group.position.x, z - this.c.group.position.z); if (d < 1.8) return { d, it: { label: () => `Parler à ${DRIVER.name} (conducteur)`, action: () => this.talkMenu() } }; }
    return null;
  }
  board() {
    const r = this.ride; if (!r) return;
    const car = this.car(); this.seat(true); this.limo.doors.r.t = 0; this.player.mesh.visible = false; this.player.pos.set(car.pos.x, 0, car.pos.z); if (this.audio && this.audio.ctx) this.audio.door();
    if (!r.dest) { r.phase = 'choose'; this.show(); this.ui.toast(`${DRIVER.first} : « Où allons-nous, Monsieur le PDG ? »`, 2.5); this.renderHud(); return; }
    this.go(r.dest);
  }
  go(dest) {
    const r = this.ride || (this.ride = {}); r.dest = dest; r.phase = 'riding'; this.close(true);
    const car = this.car(), from = { x: car.pos.x, z: car.pos.z }, rt = planRoute(from, dest);
    r.path = lanePath(rt.axis); r.s = 0; r.speed = r.speed || 0; r.stuck = 0; r.blocked = 0; r.far = rt.D.d; r.len = rt.len;
    this.limo.route = `→ ${dest.label}`; this.tpc.yaw = car.heading + PI;
    this.ui.toast(`${DRIVER.first} : « ${pick(['Très bien, nous partons pour', 'C’est parti pour', 'Direction'])} ${dest.label}. ${rt.len > 2500 ? 'Le trajet sera un peu long, installez-vous confortablement.' : 'Nous y serons rapidement.'} »`, 3);
    this.renderHud(); this.onSave && this.onSave();
  }
  goHome() { const home = HOME_STOP; if (this.riding || (this.ride && this.ride.phase === 'choose')) this.go(home); else if (this.ride) { this.ride.dest = home; this.ui.toast(`${DRIVER.first} : « Entendu, je vous ramène à la maison dès que vous montez. »`, 2.5); } else if (this.player.inCar !== this.car()) this.call(home); this.renderHud(); }
  skip() {
    const r = this.ride; if (!this.riding) return;
    this.env.time = (this.env.time + Math.min(1, ((r.path.length - r.s) / (SPEED * 0.85)) * this.env.rate)) % 24;
    r.s = r.path.length; const p = sample(r.path, r.s); this.place(p.x, p.z, p.h); this.dropOff();
  }
  place(x, z, h) { const c = this.car(); c.pos.set(x, 0, z); c.heading = h; c.speed = this.ride ? this.ride.speed : 0; c.sync(); }
  dropOff() {
    const r = this.ride, car = this.car(), pl = this.player, d = r.dest;
    const rx = Math.cos(car.heading), rz = -Math.sin(car.heading);
    let placed = false;
    for (const k of [-3.4, -4.6, 3.4, -6.5]) { const x = car.pos.x + rx * k, z = car.pos.z + rz * k; if (!this.world.collision.pointBlocked(x, 1, z)) { pl.pos.set(x, 0, z); placed = true; break; } }
    if (!placed) pl.pos.set(car.pos.x, 0, car.pos.z);
    pl.mesh.visible = true; pl.mesh.position.copy(pl.pos); pl.facing = Math.atan2(d.x - pl.pos.x, d.z - pl.pos.z);
    if (this.salon) this.toggleSalon(false);
    const walk = Math.round(Math.hypot(d.x - pl.pos.x, d.z - pl.pos.z));
    this.trips.unshift({ t: this.economy.stamp(), to: d.label }); this.trips.length = Math.min(this.trips.length, 20); this.mem.last = d.label;
    this.ui.toast(`${DRIVER.first} : « Nous sommes arrivés : ${d.label}. ${walk > 40 ? `Je ne peux pas aller plus près en voiture : c’est à environ ${walk} m à pied.` : 'Je vous dépose au plus près de l’entrée.'} Je reste à proximité, appelez-moi quand vous voulez. »`, 4);
    if (this.audio && this.audio.ctx) this.audio.door();
    r.phase = 'parked'; r.parkT = 0; this.limo.route = null; this.renderHud(); this.onSave && this.onSave();
  }
  dismiss() { // le conducteur ramène la limousine au garage de la résidence
    if (this.player.inCar === this.car()) return;
    this.ride = null; this.limo.park(); this.seat(true); this.limo.doors.l.t = this.limo.doors.r.t = 0;
    this.ui.toast(`${DRIVER.first} : « Je ramène la limousine au garage. Appelez-moi quand vous voulez. »`, 2.5); this.renderHud(); this.onSave && this.onSave();
  }
  toggleSalon(on) { this.salon = on; const L = this.limo; L.side = 'r'; if (on) { L.cabin = true; L.glass.visible = false; L.roof.visible = false; L.car.mesh.children[0].visible = false; } else { L.cabin = false; L.glass.visible = true; L.roof.visible = true; L.car.mesh.children[0].visible = true; if (L._fov && L.camera) { L.camera.fov = L._fov; L.camera.updateProjectionMatrix(); L._fov = null; } } this.renderHud(); }
  // ------------------------------------------------------------------ boucle
  update(dt) {
    const r = this.ride, car = this.car();
    if (this.seated) this.c.group.visible = this.player.inCar !== car;
    else this.c.animate && this.c.animate(dt, 0);
    if (!r) return;
    if (r.phase === 'coming') { r.t -= dt; if (r.t <= 0) this.arriveForPickup(); this.renderHud(); return; }
    if (r.phase === 'approach') {
      const left = r.path.length - r.s; r.speed = Math.min(9, Math.sqrt(2 * 3 * Math.max(0, left - 0.2)) + 0.3); r.s = Math.min(r.path.length, r.s + r.speed * dt);
      const p = sample(r.path, r.s); this.place(p.x, p.z, p.h); car.wheelSpin += r.speed * dt / 0.36;
      if (left < 0.3) this.stopAndOpen(); return;
    }
    if (r.phase === 'waiting') { r.wait -= dt; if (r.wait <= 0) { this.ui.toast(`${DRIVER.first} : « Je ramène la limousine au garage ; rappelez-moi quand vous voulez. »`, 3); this.dismiss(); } return; }
    if (r.phase === 'parked' || r.phase === 'choose') return;
    // ---- en route ----
    const T = this.traffic, p = sample(r.path, r.s + 1.5, {}), fx = Math.sin(p.h), fz = Math.cos(p.h);
    const q2 = sample(r.path, r.s + 10, {}), turn = Math.abs(Math.atan2(Math.sin(q2.h - p.h), Math.cos(q2.h - p.h)));
    let target = SPEED * (1 - Math.min(0.6, turn * 0.7));
    if (!(r.ghost > 0) && T) { for (const o of T.obstacles()) { const dx = o.x - car.pos.x, dz = o.z - car.pos.z, ahead = dx * fx + dz * fz, side = Math.abs(dx * fz - dz * fx); if (ahead > 0.5 && ahead < 10 && side < 1.7 + o.r * 0.5) { target = 0; break; } } } else r.ghost -= dt;
    r.stuck = target === 0 && r.speed < 0.3 ? r.stuck + dt : 0; r.blocked = target === 0 ? r.blocked + dt : Math.max(0, r.blocked - dt * 0.5);
    if (r.stuck > 2.5) { r.ghost = 2.5; r.stuck = 0; } // contournement prudent du bouchon
    if (r.blocked > 25) { r.blocked = 0; r.s = Math.min(r.path.length, r.s + 60); this.ui.toast(`${DRIVER.first} : « La route est bloquée, je prends un détour. »`, 2.5); } // secours
    const left = r.path.length - r.s;
    target = Math.min(target, Math.sqrt(2 * 3.5 * Math.max(0, left - 0.3)));
    r.speed = target < r.speed ? Math.max(target, r.speed - 7 * dt) : r.speed + Math.min(target - r.speed, 3 * dt);
    r.s += r.speed * dt;
    const c = sample(r.path, r.s, {}); const dh = Math.atan2(Math.sin(c.h - car.heading), Math.cos(c.h - car.heading));
    this.place(c.x, c.z, car.heading + dh * (1 - Math.exp(-8 * dt))); car.wheelSpin += r.speed * dt / 0.36;
    this.limo.st.km += r.speed * dt / 1000;
    this.player.pos.set(c.x, 0, c.z);
    if (left < 0.4 && r.speed < 0.25) this.dropOff();
  }
  camInfo() { return { heading: this.car().heading, speed: this.ride ? this.ride.speed : 0, dist: 11 }; }
  handleRideKeys(input) { if (input.hit('Space')) this.skip(); if (input.hit('KeyH')) this.goHome(); }
  // ------------------------------------------------------------------ bandeau
  renderHud() {
    const r = this.ride, el = this.hud; el.classList.toggle('show', !!r);
    if (!r) { this._h = ''; return; }
    const html = r.phase === 'coming' ? `🚘 ${DRIVER.first} arrive avec la limousine • ${Math.ceil(r.t)} s <button data-ch="cancel">Annuler</button>`
      : r.phase === 'approach' ? '🚘 La limousine arrive…'
      : r.phase === 'waiting' ? `🚘 La limousine vous attend • E pour monter${r.dest ? ` → ${esc(r.dest.label)}` : ''} <button data-ch="dests">Destination</button><button data-ch="dismiss">Renvoyer au garage</button>`
      : r.phase === 'choose' ? '🚘 Choisissez une destination <button data-ch="dests">Destinations</button><button data-ch="home">🏠 Maison</button>'
      : r.phase === 'riding' ? `🚘 En route → ${esc(r.dest.label)} <button data-ch="skip">⏩ Passer</button><button data-ch="salon">${this.salon ? '🚘 Vue route' : '🛋️ Vue salon'}</button><button data-ch="home">🏠 Rentre à la maison</button>${this.canVoice() ? '<button data-ch="mic">🎤</button>' : ''}`
      : `🚘 ${DRIVER.first} vous attend près d’ici <button data-ch="call">Remonter</button><button data-ch="dests">Autre destination</button><button data-ch="dismiss">Retour au garage</button>`;
    if (html !== this._h) { el.innerHTML = html; this._h = html; }
  }
  onHud(a) {
    if (a === 'cancel') { this.ride = null; this.limo.park(); this.seat(true); this.renderHud(); }
    else if (a === 'dests') this.show();
    else if (a === 'home') this.goHome();
    else if (a === 'skip') this.skip();
    else if (a === 'salon') this.toggleSalon(!this.salon);
    else if (a === 'dismiss') this.dismiss();
    else if (a === 'mic') this.listen();
    else if (a === 'call') { const r = this.ride; if (r && r.phase === 'parked') { const P = this.player.pos, car = this.car(); if (Math.hypot(P.x - car.pos.x, P.z - car.pos.z) < 25) { r.phase = 'waiting'; r.wait = 150; r.dest = null; this.stopAndOpen(); } else { this.ride = null; this.call(); } } }
  }
  // ------------------------------------------------------------------ commande vocale facultative
  canVoice() { return typeof window !== 'undefined' && !!(window.SpeechRecognition || window.webkitSpeechRecognition); }
  listen() {
    const R = window.SpeechRecognition || window.webkitSpeechRecognition; if (!R) return this.ui.toast('Commande vocale non disponible sur ce navigateur : utilisez les boutons.', 2.5);
    const rec = new R(); rec.lang = 'fr-FR'; rec.onresult = (e) => this.command(e.results[0][0].transcript); rec.onerror = () => this.ui.toast('Micro indisponible ou refusé.', 2); rec.start(); this.ui.toast('🎤 Dites par exemple « rentre à la maison » ou « emmène-moi à NOVA BOOK ».', 2.5);
  }
  command(txt) { // commandes en langage naturel (voix ou message)
    const t = norm(txt);
    if (/(rentre|rentrons|ramene.moi|retour).*(maison|chez moi)|a la maison/.test(t)) { this.goHome(); return 'Entendu, je vous ramène à la maison, Monsieur le PDG.'; }
    const m = t.match(/(emmene.moi|conduis.moi|allons|va|direction|amene.moi)\s+(a|au|aux|chez|vers|a la|a l)?\s*(.+)/);
    if (m) { const q = m[3].trim(); const all = GROUPS.flatMap(([g]) => this.dests(g)); const d = all.find((x) => norm(x.label).includes(q)) || all.find((x) => q.split(' ').filter((w) => w.length > 3).some((w) => norm(x.label).includes(w))); if (d) { const dest = this.entrance({ ...d, name: d.label }); dest.label = d.label; if (this.riding || (this.ride && this.ride.phase === 'choose')) this.go(dest); else this.call(dest, true); return `Très bien, direction ${d.label}.`; } return 'Je ne connais pas ce lieu, Monsieur le PDG. Pouvez-vous le choisir dans l’application ?'; }
    if (/(viens|venez).*(chercher)|j ai besoin de (toi|vous)|appel/.test(t)) { this.call(); return 'J’arrive tout de suite avec la limousine.'; }
    return null;
  }
  // ------------------------------------------------------------------ conversation libre
  reply(txt) {
    this.mem.n++; const t = norm(txt), h = this.env.time, cmd = this.command(txt); if (cmd) return cmd;
    if (/\b(bonjour|bonsoir|salut)\b/.test(t)) return h >= 18 ? 'Bonsoir Monsieur le PDG, toujours à votre service.' : 'Bonjour Monsieur le PDG ! La limousine est prête.';
    if (/(ca va|comment (vas|allez)|la forme)/.test(t)) return pick(['Très bien, merci Monsieur le PDG. Et vous ?', 'Ça va bien, Dieu merci. La journée est belle.']);
    if (/(famille|enfant|femme|epouse)/.test(t)) return `Je suis ${DRIVER.family}. Mon aîné veut devenir ingénieur !`;
    if (/(d ou viens|originaire|ville natale)/.test(t)) return `Je suis d’${DRIVER.origin}, la ville des rois. Je conduis à Cotonou depuis ${DRIVER.years} ans.`;
    if (/(loisir|passion|week.?end|football|match)/.test(t)) return `J’aime ${DRIVER.hobby}. Le dimanche, je ne rate jamais un match !`;
    if (/(manger|plat|cuisine|faim)/.test(t)) return `Mon plat préféré ? ${DRIVER.dish.charAt(0).toUpperCase() + DRIVER.dish.slice(1)}. Rien ne la vaut !`;
    if (/(circulation|bouchon|embouteillage|route)/.test(t)) return h > 7 && h < 9.5 || h > 17 && h < 19.5 ? 'C’est l’heure de pointe : beaucoup de zems et de taxis, je prendrai les grands axes.' : 'La circulation est fluide en ce moment.';
    if (/(musique|radio|chanson)/.test(t)) { this.limo.st.screen = 'musique'; this.limo.applyState(); return 'Je mets la radio dans le salon arrière. Un peu de rythme pour la route !'; }
    if (/(clim|chaud|froid|temperature)/.test(t)) { this.limo.st.ac = true; this.limo.applyState(); return `La climatisation est réglée à ${this.limo.st.temp} °C. Dites-moi si vous voulez plus frais.`; }
    if (/(tu te souviens|dernier trajet|ou etait|derniere fois)/.test(t)) return this.mem.last ? `La dernière fois, je vous ai conduit à : ${this.mem.last}. ${this.trips.length} trajet(s) ensemble jusqu’ici.` : 'Nous n’avons pas encore fait de trajet ensemble, j’ai hâte !';
    if (/(merci|bravo|bon travail)/.test(t)) return 'C’est un honneur de vous conduire, Monsieur le PDG.';
    if (/(blague|drole)/.test(t)) return 'Un zem m’a dit un jour : « Ta voiture est trop longue, elle arrive à destination avant toi ! » Hahaha !';
    if (/(au revoir|a plus|bonne nuit)/.test(t)) return 'À votre service, Monsieur le PDG. Bonne continuation !';
    if (txt.trim().endsWith('?')) return pick(['Bonne question, Monsieur le PDG. Je me renseigne.', 'Je ne saurais pas vous dire exactement, mais je peux vous y conduire !']);
    return pick(['Bien noté, Monsieur le PDG.', 'Entendu.', 'Je suis à votre disposition.']);
  }
  contact() { return { key: DRIVER.key, kind: 'sec', driver: true, name: DRIVER.name, role: 'Conducteur personnel • limousine BL-LIMO-1', icon: '🧑🏿‍✈️' }; }
  talkMenu() {
    this.ui.openMenu(`🧑🏿‍✈️ ${DRIVER.name}`, `Conducteur personnel (personnage fictif) • ${this.trips.length} trajet(s) ensemble`, [
      { label: '🗺️ Choisir une destination', action: () => this.show() },
      { label: '🏠 Rentrons à la maison', action: () => this.goHome() },
      { label: '💬 Discuter (messagerie)', action: () => { this.economy.togglePhone(true); this.phonePlus.sel = DRIVER.key; this.economy.app = 'chat'; this.economy.renderPhone(); } },
      { label: '🅿️ Ramenez la limousine au garage', action: () => this.dismiss() },
    ]);
  }
  // ------------------------------------------------------------------ application « Chauffeur personnel »
  renderApp(b) {
    const r = this.ride, car = this.car(), P = this.player.pos, st = !r ? (Math.hypot(car.pos.x - LIMO_SPOT.x, car.pos.z - LIMO_SPOT.z) < 3 ? 'au garage de la résidence, disponible' : 'disponible') : { coming: 'en route vers vous', approach: 'arrive', waiting: 'vous attend', choose: 'attend votre destination', riding: `en route → ${r.dest ? r.dest.label : ''}`, parked: 'stationné près de vous' }[r.phase];
    b.innerHTML = `<h4>🚘 Chauffeur personnel</h4><div class="ph-row"><span><b>🧑🏿‍✈️ ${DRIVER.name}</b><small>Conducteur personnel (fictif) • ${esc(st)} • limousine BL-LIMO-1 • ${this.trips.length} trajet(s)</small></span></div>
      <div class="ph-chips"><button class="ph-go" data-drv="call">📞 Appeler mon conducteur</button><button data-drv="home">🏠 Rentrer à la maison</button><button data-drv="pick">🗺️ Choisir sur la carte</button>${this.canVoice() ? '<button data-drv="mic">🎤 Commande vocale</button>' : ''}${r ? '<button data-drv="dismiss">🅿️ Retour au garage</button>' : ''}</div>
      <h5>Destinations</h5><div class="ph-chips">${GROUPS.map(([g, l]) => `<button data-drv="grp:${g}" class="${this.grp === g ? 'on' : ''}">${l}</button>`).join('')}</div>
      <div class="ph-list">${this.dests(this.grp).map((d) => `<div class="ph-row" data-drv="go:${esc(d.id)}"><span><b>${esc(d.label)}</b><small>${(Math.hypot(d.x - P.x, d.z - P.z) / 1000).toFixed(2).replace('.', ',')} km à vol d’oiseau</small></span></div>`).join('') || '<p class="ph-note">Aucun lieu dans cette catégorie.</p>'}</div>
      <p class="ph-note">Service gratuit (conducteur salarié fictif). Sur la carte, touche un lieu ou un point libre puis « Y aller en limousine ».</p>
      ${this.trips.length ? `<h5>Derniers trajets</h5>${this.trips.slice(0, 4).map((x) => `<p class="ph-note">${x.t} → ${esc(x.to)}</p>`).join('')}` : ''}`;
  }
  findDest(id) { for (const [g] of GROUPS) { const d = this.dests(g).find((x) => x.id === id); if (d) { const e = this.entrance({ ...d, name: d.label }); e.label = d.label; return e; } } return null; }
  onPhone(v) {
    const i = v.indexOf(':'), a = i < 0 ? v : v.slice(0, i), arg = i < 0 ? '' : v.slice(i + 1);
    if (a === 'grp') { this.grp = arg; return this.economy.renderPhone(); }
    if (a === 'call') return this.call();
    if (a === 'home') { this.economy.togglePhone(false); return this.goHome(); }
    if (a === 'mic') return this.listen();
    if (a === 'dismiss') { this.dismiss(); return this.economy.renderPhone(); }
    if (a === 'pick') { this.economy.togglePhone(false); this.ui.toggleMap && this.ui.toggleMap(true); this.ui.toast('Touche un lieu ou un point libre de la carte, puis « 🚘 Y aller en limousine ».', 3.5); return; }
    if (a === 'go') { const d = this.findDest(arg); if (!d) return; this.economy.togglePhone(false); this.toDest(d); }
  }
  toDest(d) { // destination choisie (téléphone, carte, panneau)
    const r = this.ride;
    if (r && (r.phase === 'choose' || r.phase === 'riding')) return this.go(d);
    if (r && r.phase === 'parked') { this.ride = null; }
    if (r && (r.phase === 'waiting' || r.phase === 'coming' || r.phase === 'approach')) { r.dest = d; this.ui.toast(`${DRIVER.first} : « Noté : ${d.label}. »`, 2); return this.renderHud(); }
    this.call(d);
  }
  fromMap(p) { const d = this.entrance({ ...p }); d.label = p.name; this.ui.toggleMap && this.ui.toggleMap(false); this.toDest(d); }
  // panneau de destinations (en voiture)
  show() { this.open = true; this.economy.togglePhone(true); this.economy.app = 'drv'; this.economy.renderPhone(); }
  close() { this.open = false; }
  serialize() { return { trips: this.trips, mem: this.mem, grp: this.grp }; }
  restore(s) { if (!s) return; this.trips = s.trips || []; this.mem = s.mem || this.mem; this.grp = s.grp || 'entreprise'; }
}
