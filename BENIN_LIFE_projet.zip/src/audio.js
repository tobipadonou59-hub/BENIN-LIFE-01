// Système audio 100 % synthétisé (Web Audio API) : aucun fichier son, fonctionne hors-ligne.
// Ambiances (ville, vagues, vent, oiseaux, grillons, marché), pas du joueur selon le sol,
// moteur de voiture à régime variable, zémidjans et voitures spatialisés, klaxons,
// chocs, portières, interface, et musique du menu (rythme de cloche gankogui, tradition fon/ewe).
import { LINES_X, LINES_Z, ROAD_HALF, SEA_Z, BEACH_Z, ROUND_R } from './world.js';

const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

export class AudioSystem {
  constructor(settings) {
    this.settings = settings;
    this.ctx = null;
    this.t = 0;
    this.nextBird = 2; this.nextFarHorn = 6;
    this.hornCooldown = 0;
    this.honked = new WeakMap();
    this.musicOn = false;
  }

  // ---------- initialisation (après une action de l'utilisateur, exigé par les navigateurs) ----------
  init() {
    if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    let ctx;
    try { ctx = this.ctx = new AC(); } catch (e) { return; }
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -16; comp.ratio.value = 4; comp.attack.value = 0.005; comp.release.value = 0.2;
    this.master = ctx.createGain();
    this.master.connect(comp).connect(ctx.destination);
    this.sfx = this.bus(0.9); this.amb = this.bus(0.8); this.music = this.bus(0);
    // réverbération légère (rues entre les façades)
    this.verb = ctx.createConvolver();
    this.verb.buffer = this.impulse(1.4, 3);
    const vg = ctx.createGain(); vg.gain.value = 0.22;
    this.verb.connect(vg).connect(this.master);
    this.sfxSend = ctx.createGain(); this.sfxSend.gain.value = 0.35;
    this.sfx.connect(this.sfxSend).connect(this.verb);

    this.white = this.noiseBuffer(2, false);
    this.brown = this.noiseBuffer(4, true);
    this.setupAmbience();
    this.setupEngine();
    this.setupTrafficVoices();
    this.applyVolume();
    this.startMusicScheduler();
  }

  bus(v) { const g = this.ctx.createGain(); g.gain.value = v; g.connect(this.master); return g; }

  noiseBuffer(sec, brown) {
    const ctx = this.ctx, n = Math.floor(ctx.sampleRate * sec);
    const b = ctx.createBuffer(1, n, ctx.sampleRate), d = b.getChannelData(0);
    let last = 0;
    for (let i = 0; i < n; i++) {
      const w = Math.random() * 2 - 1;
      if (brown) { last = (last + 0.02 * w) / 1.02; d[i] = last * 3.5; } else d[i] = w;
    }
    return b;
  }

  impulse(sec, decay) {
    const ctx = this.ctx, n = Math.floor(ctx.sampleRate * sec);
    const b = ctx.createBuffer(2, n, ctx.sampleRate);
    for (let c = 0; c < 2; c++) {
      const d = b.getChannelData(c);
      for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, decay);
    }
    return b;
  }

  loop(buffer) { const s = this.ctx.createBufferSource(); s.buffer = buffer; s.loop = true; s.loopStart = 0; s.start(0, Math.random() * buffer.duration); return s; }
  filter(type, f, q = 1) { const x = this.ctx.createBiquadFilter(); x.type = type; x.frequency.value = f; x.Q.value = q; return x; }
  gain(v = 0) { const g = this.ctx.createGain(); g.gain.value = v; return g; }
  set(param, v, tc = 0.15) { param.setTargetAtTime(v, this.ctx.currentTime, tc); }

  applyVolume() {
    if (!this.ctx) return;
    const v = this.settings.muted ? 0 : (this.settings.volume ?? 0.8);
    this.set(this.master.gain, v, 0.05);
  }

  // ---------- ambiances en boucle ----------
  setupAmbience() {
    const ctx = this.ctx;
    const chain = (src, ...nodes) => { let n = src; for (const x of nodes) { n.connect(x); n = x; } return n; };
    this.rumbleG = this.gain(); chain(this.loop(this.brown), this.filter('lowpass', 260), this.rumbleG, this.amb);
    this.windG = this.gain(); this.windF = this.filter('bandpass', 700, 0.6); chain(this.loop(this.white), this.windF, this.windG, this.amb);
    this.wavesG = this.gain(); chain(this.loop(this.brown), this.filter('lowpass', 750), this.wavesG, this.amb);
    this.hissG = this.gain(); chain(this.loop(this.white), this.filter('highpass', 2600), this.hissG, this.amb);
    // pluie : bruit blanc filtré (large bande) + crépitement plus grave
    this.rainG = this.gain(); chain(this.loop(this.white), this.filter('highpass', 450), this.filter('lowpass', 7000), this.rainG, this.amb);
    this.rainLowG = this.gain(); chain(this.loop(this.brown), this.filter('lowpass', 900), this.rainLowG, this.amb);
    // grillons : porteuse aiguë modulée en amplitude
    const car = ctx.createOscillator(); car.frequency.value = 4350; car.start();
    const am = this.gain(0.5);
    const lfo = ctx.createOscillator(); lfo.type = 'square'; lfo.frequency.value = 27; lfo.start();
    const lfoG = this.gain(0.5); lfo.connect(lfoG).connect(am.gain);
    const gate = ctx.createOscillator(); gate.frequency.value = 0.9; gate.start();
    this.crickG = this.gain();
    const gateG = this.gain(0.5); const gateOff = this.gain(0.5);
    car.connect(am); am.connect(gateOff); gate.connect(gateG).connect(gateOff.gain);
    gateOff.connect(this.crickG).connect(this.amb);
    // brouhaha du marché : voix formantiques modulées au rythme des syllabes
    this.marketG = this.gain();
    const lp = this.filter('lowpass', 2800);
    lp.connect(this.marketG).connect(this.amb);
    this.voices = [];
    for (let i = 0; i < 7; i++) {
      const f1 = this.filter('bandpass', 350 + Math.random() * 500, 4);
      const f2 = this.filter('bandpass', 1200 + Math.random() * 1200, 6);
      const env = this.gain();
      const src = this.loop(this.white);
      src.connect(f1); src.connect(f2); f1.connect(env); f2.connect(env);
      const p = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
      if (p) { p.pan.value = Math.random() * 1.6 - 0.8; env.connect(p).connect(lp); } else env.connect(lp);
      this.voices.push({ env, f1, f2, next: 0 });
    }
  }

  surfaceAt(x, z) {
    if (z > BEACH_Z) return 'sand';
    if (Math.hypot(x, z) < ROUND_R) return 'asphalt';
    for (const l of LINES_Z) if (Math.abs(z - l) < ROAD_HALF) return 'asphalt';
    for (const l of LINES_X) if (Math.abs(x - l) < ROAD_HALF) return Math.abs(l) === 100 ? 'pave' : 'asphalt';
    if (x > 10 && x < 90 && z > -90 && z < -10) return 'grass';
    // trottoir sur les 3 m en bordure d'îlot, sinon latérite
    const near = (v, lines) => lines.some((l) => Math.abs(Math.abs(v - l) - ROAD_HALF - 1.5) < 1.6);
    if (near(x, LINES_X) || near(z, LINES_Z)) return 'concrete';
    return 'dirt';
  }

  // ---------- pas, sauts, chocs, portières ----------
  burst(dur, type, f, q, vol, dest = this.sfx, when = 0) {
    const ctx = this.ctx, t = ctx.currentTime + when;
    const s = ctx.createBufferSource(); s.buffer = this.white;
    const fl = this.filter(type, f, q), g = this.gain();
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(vol, t + 0.004); g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    s.connect(fl).connect(g).connect(dest);
    s.start(t, Math.random() * 1.5); s.stop(t + dur + 0.05);
  }
  // tonnerre : craquement puis grondement grave qui roule
  thunder(delay = 1) {
    if (!this.ctx) return;
    const vol = 0.35 + Math.random() * 0.4;
    this.burst(0.5, 'lowpass', 2400, 0.7, vol * 0.5, this.amb, delay);
    this.burst(4.5 + Math.random() * 2, 'lowpass', 160, 0.8, vol * 1.6, this.amb, delay + 0.08);
    this.burst(3, 'lowpass', 90, 1, vol * 1.4, this.amb, delay + 0.6 + Math.random() * 0.8);
  }
  tone(freq, dur, vol, type = 'sine', dest = this.sfx, when = 0, freqEnd = null) {
    const ctx = this.ctx, t = ctx.currentTime + when;
    const o = ctx.createOscillator(); o.type = type; o.frequency.setValueAtTime(freq, t);
    if (freqEnd) o.frequency.exponentialRampToValueAtTime(freqEnd, t + dur);
    const g = this.gain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(vol, t + 0.005); g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    o.connect(g).connect(dest); o.start(t); o.stop(t + dur + 0.05);
  }

  footstep(x, z, speed) {
    if (!this.ctx) return;
    const s = this.surfaceAt(x, z), k = clamp(0.5 + speed / 8, 0.5, 1.2);
    const v = 0.9 + Math.random() * 0.25;
    switch (s) {
      case 'sand': this.burst(0.14, 'lowpass', 900, 0.7, 0.25 * k * v); break;
      case 'grass': this.burst(0.1, 'bandpass', 2600, 0.8, 0.13 * k * v); this.burst(0.06, 'lowpass', 500, 1, 0.12 * k); break;
      case 'dirt': this.burst(0.09, 'lowpass', 1400, 0.8, 0.22 * k * v); break;
      default: this.burst(0.05, 'bandpass', 2200 + Math.random() * 600, 1.2, 0.22 * k * v); this.tone(110, 0.04, 0.12 * k, 'sine', this.sfx, 0, 60);
    }
  }
  land() { if (!this.ctx) return; this.tone(90, 0.12, 0.35, 'sine', this.sfx, 0, 45); this.burst(0.08, 'lowpass', 900, 1, 0.25); }
  impact(strength) {
    if (!this.ctx) return;
    const k = clamp(strength / 20, 0.25, 1);
    this.burst(0.35, 'lowpass', 700, 0.8, 0.8 * k);
    this.tone(70, 0.3, 0.5 * k, 'sine', this.sfx, 0, 35);
    for (const f of [640, 913, 1350]) this.tone(f * (0.95 + Math.random() * 0.1), 0.45, 0.06 * k, 'square');
  }
  door() { if (!this.ctx) return; this.burst(0.06, 'lowpass', 1200, 1, 0.35); this.tone(130, 0.08, 0.3, 'sine', this.sfx, 0, 70); this.burst(0.04, 'bandpass', 3000, 2, 0.08, this.sfx, 0.05); }
  click() { if (!this.ctx) return; this.tone(880, 0.06, 0.12, 'triangle'); this.tone(1320, 0.05, 0.06, 'sine', this.sfx, 0.03); }
  hover() { if (!this.ctx) return; this.tone(1200, 0.03, 0.03, 'sine'); }

  // ---------- bruits en boucle (douche, cuisson) ----------
  startLoop(kind) {
    if (!this.ctx) return;
    this.stopLoop();
    const s = this.loop(this.white);
    const f = kind === 'shower' ? this.filter('bandpass', 3800, 0.6) : this.filter('highpass', 2500, 0.8);
    const g = this.gain(); this.set(g.gain, kind === 'shower' ? 0.16 : 0.07, 0.2);
    const lfo = this.ctx.createOscillator(); lfo.frequency.value = kind === 'shower' ? 7 : 13; const lg = this.gain(0.03); lfo.connect(lg).connect(g.gain); lfo.start();
    s.connect(f).connect(g).connect(this.sfx);
    this._loop = { s, g, lfo };
  }
  stopLoop() {
    if (!this._loop) return;
    const { s, g, lfo } = this._loop; this.set(g.gain, 0, 0.1);
    setTimeout(() => { try { s.stop(); lfo.stop(); } catch (e) { /* déjà arrêté */ } }, 400);
    this._loop = null;
  }

  // ---------- klaxons ----------
  panner(x, y, z) {
    const p = this.ctx.createPanner();
    p.panningModel = 'equalpower'; p.distanceModel = 'inverse'; p.refDistance = 5; p.rolloffFactor = 1.1; p.maxDistance = 400;
    this.setPos(p, x, y, z);
    p.connect(this.sfx);
    return p;
  }
  setPos(node, x, y, z) {
    if (node.positionX) { node.positionX.value = x; node.positionY.value = y; node.positionZ.value = z; } else node.setPosition(x, y, z);
  }
  horn(x, z, kind = 'car', direct = false) {
    if (!this.ctx) return;
    const ctx = this.ctx, dest = direct ? this.sfx : this.panner(x, 1, z);
    const custom = Array.isArray(kind);
    const lp = this.filter('lowpass', kind === 'moto' ? 3500 : custom ? 3000 : 2400); lp.connect(dest);
    const pattern = kind === 'moto' ? [[0, 0.11], [0.17, 0.11]] : custom ? [[0, 0.45]] : Math.random() < 0.5 ? [[0, 0.4]] : [[0, 0.16], [0.24, 0.3]];
    const freqs = kind === 'moto' ? [540, 680] : custom ? kind : [370, 466];
    for (const [t0, d] of pattern) for (const f of freqs) {
      const t = ctx.currentTime + t0;
      const o = ctx.createOscillator(); o.type = 'square'; o.frequency.value = f * (0.98 + Math.random() * 0.04);
      const g = this.gain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.09, t + 0.01); g.gain.setValueAtTime(0.09, t + d); g.gain.linearRampToValueAtTime(0, t + d + 0.03);
      o.connect(g).connect(lp); o.start(t); o.stop(t + d + 0.06);
    }
  }

  // ---------- oiseaux ----------
  bird(x, z) {
    const ctx = this.ctx, p = this.panner(x, 6 + Math.random() * 6, z);
    const base = 2200 + Math.random() * 2600, n = 2 + Math.floor(Math.random() * 5);
    let t = 0;
    for (let i = 0; i < n; i++) {
      const d = 0.05 + Math.random() * 0.09;
      const o = ctx.createOscillator(), g = this.gain(), t0 = ctx.currentTime + t;
      const f0 = base * (0.85 + Math.random() * 0.3);
      o.frequency.setValueAtTime(f0, t0); o.frequency.exponentialRampToValueAtTime(f0 * (Math.random() < 0.5 ? 1.5 : 0.7), t0 + d);
      g.gain.setValueAtTime(0, t0); g.gain.linearRampToValueAtTime(0.06, t0 + 0.01); g.gain.exponentialRampToValueAtTime(0.001, t0 + d);
      o.connect(g).connect(p); o.start(t0); o.stop(t0 + d + 0.02);
      t += d + 0.03 + Math.random() * 0.08;
    }
  }

  // ---------- moteur de la voiture du joueur ----------
  setupEngine() {
    const ctx = this.ctx;
    const shaper = ctx.createWaveShaper();
    const curve = new Float32Array(1024);
    for (let i = 0; i < 1024; i++) { const x = i / 512 - 1; curve[i] = Math.tanh(x * 2.5); }
    shaper.curve = curve;
    this.engLP = this.filter('lowpass', 600, 2);
    this.engG = this.gain();
    this.engGains = [];
    this.eng = ['sawtooth', 'square', 'sine'].map((type, i) => {
      const o = ctx.createOscillator(); o.type = type; o.frequency.value = 30; o.start();
      const g = this.gain([0.5, 0.25, 0.8][i]); o.connect(g).connect(shaper);
      this.engGains.push(g);
      return o;
    });
    // bruit d'admission
    this.intakeG = this.gain();
    this.intakeF = this.filter('bandpass', 800, 1.5);
    this.loop(this.white).connect(this.intakeF).connect(this.intakeG).connect(this.engLP);
    shaper.connect(this.engLP).connect(this.engG).connect(this.sfx);
    this.rpm = 900;
    // crissement des pneus
    this.screechG = this.gain();
    this.loop(this.white).connect(this.filter('bandpass', 2300, 3)).connect(this.screechG).connect(this.sfx);
  }

  updateEngine(car, throttle, handbrake, active) {
    if (!active || !car) { this.set(this.engG.gain, 0, 0.2); this.set(this.screechG.gain, 0, 0.1); this.set(this.intakeG.gain, 0, 0.2); return; }
    const v = Math.abs(car.speed);
    // profils sonores des véhicules du garage (V8, V12, électrique, diesel…)
    const snd = car.sound || null, prof = snd ? snd.type : 'base';
    if (prof !== this._engProf) {
      this._engProf = prof;
      const G = { base: [0.5, 0.25, 0.8], v8: [0.55, 0.35, 0.9], v12: [0.65, 0.2, 0.35], v6: [0.5, 0.3, 0.6], i6: [0.45, 0.25, 0.55], flat6: [0.55, 0.4, 0.5], diesel: [0.3, 0.55, 0.9], ev: [0, 0, 0.5], jet: [0.1, 0.04, 0.22], prop: [0.6, 0.45, 0.35], heli: [0.7, 0.5, 0.3] }[prof] || [0.5, 0.25, 0.8];
      G.forEach((g, i) => this.set(this.engGains[i].gain, g, 0.1));
    }
    // avions : grondement de réacteur (souffle + sifflement) ou bourdonnement d'hélice
    if (prof === 'heli') { // rotor : battement grave des pales + sifflement de turbine
      const r = car.rpm || 0, th = car.throttle || 0, beat = 0.5 + 0.5 * Math.sin(performance.now() / 1000 * Math.PI * 2 * (2 + r * 9));
      this.set(this.eng[0].frequency, 38 + r * 30, 0.1); this.set(this.eng[1].frequency, 19 + r * 15, 0.1); this.set(this.eng[2].frequency, 76 + r * 60, 0.1);
      this.set(this.engLP.frequency, 300 + th * 500, 0.1);
      this.set(this.engG.gain, (0.03 + r * 0.1) * (0.55 + beat * 0.45), 0.05);
      this.set(this.intakeF.frequency, 1400 + r * 1800, 0.1); this.set(this.intakeG.gain, r * 0.08, 0.15);
      this.set(this.screechG.gain, 0, 0.1);
      return;
    }
    if (prof === 'jet' || prof === 'prop') {
      const th = car.throttle || 0, jet = prof === 'jet';
      const fa = jet ? 220 + th * 560 : 70 + th * 95;
      this.set(this.eng[0].frequency, fa, 0.1); this.set(this.eng[1].frequency, fa / 2, 0.1); this.set(this.eng[2].frequency, fa / 4, 0.1);
      this.set(this.engLP.frequency, jet ? 1600 + th * 2600 : 700 + th * 900, 0.1);
      this.set(this.engG.gain, 0.05 + th * 0.08, 0.15);
      this.set(this.intakeF.frequency, jet ? 900 + th * 2200 : 400 + th * 300, 0.1);
      this.set(this.intakeG.gain, jet ? 0.12 + th * 0.5 : 0.04 + th * 0.06, 0.15);
      this.set(this.screechG.gain, 0, 0.1);
      return;
    }
    let f;
    if (car.rpm != null) {
      this.rpm = car.rpm;
      f = prof === 'ev' ? (160 + v * 24) * 4 : (this.rpm / 30) * (snd ? snd.mul : 1); // électrique : sifflement qui monte avec la vitesse
    } else {
      const bands = [0, 7, 13, 19, 25, 40];
      let gear = 0; while (gear < 4 && v > bands[gear + 1]) gear++;
      const frac = clamp((v - bands[gear]) / (bands[gear + 1] - bands[gear]), 0, 1);
      const target = gear === 0 ? 900 + frac * 4600 : 2200 + frac * 3400 + throttle * 300;
      this.rpm += (target - this.rpm) * 0.12;
      f = this.rpm / 30 * (car.isMoto ? 1.7 : 1); // moto : monocylindre plus aigu
    }
    this.set(this.eng[0].frequency, f, 0.03); this.set(this.eng[1].frequency, f / 2, 0.03); this.set(this.eng[2].frequency, f / 4, 0.03);
    this.set(this.engLP.frequency, 350 + throttle * 1600 + this.rpm * 0.12, 0.05);
    this.set(this.engG.gain, 0.045 + throttle * 0.055 + (this.rpm / 6000) * 0.04, 0.08);
    this.set(this.intakeF.frequency, 500 + this.rpm * 0.3, 0.05);
    this.set(this.intakeG.gain, throttle * (prof === 'ev' ? 0.02 : 0.25), 0.08);
    const skid = (handbrake && v > 5) ? 0.14 : (Math.abs(car.steer) > 0.3 && v > 13 ? 0.07 : 0);
    this.set(this.screechG.gain, skid, 0.05);
  }

  // ---------- circulation : 6 voix spatialisées attribuées aux véhicules les plus proches ----------
  setupTrafficVoices() {
    const ctx = this.ctx;
    this.tvoices = [];
    for (let i = 0; i < 6; i++) {
      const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = 50; o.start();
      const o2 = ctx.createOscillator(); o2.type = 'square'; o2.frequency.value = 25; o2.start();
      const f = this.filter('lowpass', 500, 1.5), g = this.gain();
      const g2 = this.gain(0.4); o2.connect(g2).connect(f);
      const p = ctx.createPanner();
      p.panningModel = 'equalpower'; p.distanceModel = 'inverse'; p.refDistance = 4; p.rolloffFactor = 1.3;
      o.connect(f).connect(g).connect(p).connect(this.sfx);
      this.tvoices.push({ o, o2, f, g, p });
    }
  }

  updateTraffic(vehicles, lx, lz, active, dt) {
    const near = [];
    if (active) for (const v of vehicles) {
      const d = (v.x - lx) ** 2 + (v.z - lz) ** 2;
      if (d < 55 * 55) near.push([d, v]);
    }
    near.sort((a, b) => a[0] - b[0]);
    this.tvoices.forEach((tv, i) => {
      const e = near[i];
      if (!e) { this.set(tv.g.gain, 0, 0.2); return; }
      const v = e[1];
      this.setPos(tv.p, v.x, 0.8, v.z);
      if (v.moto) {
        // moteur deux-temps de zémidjan : bourdonnement aigu
        this.set(tv.o.frequency, 62 + v.speed * 7.5, 0.1); this.set(tv.o2.frequency, 31 + v.speed * 3.7, 0.1);
        this.set(tv.f.frequency, 1100 + v.speed * 60, 0.1);
        this.set(tv.g.gain, 0.05 + v.speed * 0.007, 0.15);
      } else {
        this.set(tv.o.frequency, 32 + v.speed * 3.2, 0.1); this.set(tv.o2.frequency, 16 + v.speed * 1.6, 0.1);
        this.set(tv.f.frequency, 380 + v.speed * 25, 0.1);
        this.set(tv.g.gain, (v.kind === 'minibus' ? 0.1 : 0.07) + v.speed * 0.005, 0.15);
      }
    });
    if (!active) return;
    // klaxons : impatients quand le joueur bloque, et de temps en temps (on est à Cotonou !)
    for (const [d, v] of near) {
      const last = this.honked.get(v) || -99;
      if (this.t - last < 4) continue;
      if ((v.blockedT || 0) > 1.2 || (v.moto && Math.random() < dt * 0.03)) {
        this.honked.set(v, this.t);
        this.horn(v.x, v.z, v.moto ? 'moto' : 'car');
      }
    }
  }

  // ---------- musique du menu : cloche gankogui (12/8), tambour, hochet ----------
  startMusicScheduler() {
    this.step = 0; this.nextNote = this.ctx.currentTime + 0.1;
    const bell = [1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1];
    const drum = [1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0];
    const slap = [0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0];
    const stepDur = 60 / 118 / 3; // croches de 12/8
    this.musicTimer = setInterval(() => {
      if (!this.musicOn) { this.nextNote = this.ctx.currentTime + 0.05; return; }
      while (this.nextNote < this.ctx.currentTime + 0.12) {
        const s = this.step % 12, when = this.nextNote - this.ctx.currentTime, bar = Math.floor(this.step / 12);
        if (bell[s]) this.bell(s === 0 ? 590 : 880, when);
        if (drum[s]) this.drum(s === 0 ? 92 : 70, when, 0.5);
        if (slap[s] || (bar % 4 === 3 && s > 8)) this.slap(when);
        this.shaker(when, s % 3 === 0 ? 0.05 : 0.025);
        if (s === 0 && bar % 2 === 1) this.drum(140, when + stepDur * 1.5, 0.25);
        this.nextNote += stepDur;
        this.step++;
      }
    }, 25);
  }
  bell(f, when) {
    for (const [m, v, d] of [[1, 0.09, 0.5], [2.76, 0.04, 0.25], [5.4, 0.02, 0.12]]) this.tone(f * m, d, v, 'sine', this.music, when);
  }
  drum(f, when, v) { this.tone(f * 1.6, 0.35, v, 'sine', this.music, when, f); }
  slap(when) { this.burst(0.08, 'bandpass', 1800, 1, 0.25, this.music, when); this.tone(320, 0.06, 0.15, 'triangle', this.music, when, 200); }
  shaker(when, v) { this.burst(0.05, 'highpass', 6000, 0.7, v, this.music, when); }

  setListener(camera) {
    const L = this.ctx.listener, p = camera.position;
    const f = camera.getWorldDirection(this._f || (this._f = camera.position.clone()));
    if (L.positionX) {
      L.positionX.value = p.x; L.positionY.value = p.y; L.positionZ.value = p.z;
      L.forwardX.value = f.x; L.forwardY.value = f.y; L.forwardZ.value = f.z;
      L.upX.value = 0; L.upY.value = 1; L.upZ.value = 0;
    } else { L.setPosition(p.x, p.y, p.z); L.setOrientation(f.x, f.y, f.z, 0, 1, 0); }
  }

  // ---------- mise à jour à chaque image ----------
  update(dt, info) {
    if (!this.ctx) return;
    this.t += dt;
    const { state, night, x, z, camera } = info;
    const day = 1 - night, playing = state === 'playing';
    this.setListener(camera);
    // musique uniquement dans le menu
    const wantMusic = state === 'menu' && this.settings.music !== false;
    if (wantMusic !== this.musicOn) { this.musicOn = wantMusic; }
    this.set(this.music.gain, wantMusic ? 0.55 : 0, 0.6);
    this.set(this.amb.gain, playing ? 0.85 : state === 'menu' ? 0.35 : 0.25, 0.5);

    const beach = clamp(1 - (SEA_Z - z) / 110, 0, 1) ** 1.6;
    const t = this.t;
    this.set(this.rumbleG.gain, 0.16 * (0.35 + 0.65 * day) * (1 - beach * 0.6), 0.5);
    this.set(this.windG.gain, (0.025 + 0.02 * Math.sin(t * 0.37) + beach * 0.03), 0.4);
    this.set(this.windF.frequency, 600 + Math.sin(t * 0.23) * 200, 0.4);
    const swell = Math.max(0, Math.sin(t * 0.85)) ** 2 * 0.7 + Math.max(0, Math.sin(t * 0.53 + 1.3)) ** 2 * 0.5;
    this.set(this.wavesG.gain, beach * (0.12 + 0.4 * swell), 0.25);
    this.set(this.hissG.gain, beach * 0.07 * swell, 0.2);
    const rain = info.rain || 0, muff = info.indoor ? 0.45 : 1;
    this.set(this.rainG.gain, rain * 0.16 * muff, 0.8);
    this.set(this.rainLowG.gain, rain * (info.indoor ? 0.22 : 0.1), 0.8);
    this.set(this.crickG.gain, night * 0.03 * (1 - beach * 0.5) * (1 - rain), 1);

    const mk = clamp(1 - Math.hypot(x + 50, z - 50) / 75, 0, 1) ** 1.4;
    const crowd = (info.crowd || 0) * 0.22 * (0.3 + 0.7 * day) * (info.indoor ? 0.3 : 1); // foule des rues (mission 015)
    this.set(this.marketG.gain, Math.max(mk * 0.55 * (0.25 + 0.75 * day), crowd), 0.4);
    if (mk > 0.01 || crowd > 0.01) for (const v of this.voices) {
      if (t > v.next) {
        v.next = t + 0.09 + Math.random() * 0.2;
        this.set(v.env.gain, Math.random() < 0.3 ? 0 : Math.random() ** 2 * 0.5, 0.03);
        if (Math.random() < 0.3) { this.set(v.f1.frequency, 300 + Math.random() * 600, 0.05); this.set(v.f2.frequency, 1100 + Math.random() * 1400, 0.05); }
      }
    }

    if (playing) {
      if (day > 0.4 && rain < 0.3 && t > this.nextBird) {
        this.nextBird = t + 1.5 + Math.random() * 5 * (1 + beach);
        const a = Math.random() * 6.28, r = 12 + Math.random() * 25;
        this.bird(x + Math.cos(a) * r, z + Math.sin(a) * r);
      }
      if (t > this.nextFarHorn) {
        this.nextFarHorn = t + 5 + Math.random() * 10;
        const a = Math.random() * 6.28, r = 70 + Math.random() * 60;
        if (beach < 0.6) this.horn(x + Math.cos(a) * r, z + Math.sin(a) * r, Math.random() < 0.6 ? 'moto' : 'car');
      }
    }
    this.updateEngine(info.car, info.throttle, info.handbrake, playing && !!info.car);
    this.updateTraffic(info.traffic || [], x, z, playing, dt);
  }
}
