// Mission 016 (compléments) — intérieurs visitables des restaurants, hôtels et banques des 5 villes.
// Restaurant : salle avec tables et chaises, comptoir, cuisinier, serveur qui apporte l'assiette à table, clients.
// Hôtel : réception, salon (espace commun), coin restaurant, couloir et chambre (lit, télévision, salle d'eau) — la
// chambre s'ouvre avec la clé remise à la réception. Banque : 2 guichets avec employés, 2 distributeurs, attente.
// Un seul intérieur à la fois, construit à l'entrée au-dessus de l'établissement (collisions isolées, niveau 130).
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { createCharacter, SKINS } from './character.js';
import { buildFoodModel } from './food.js';
import { TYPES } from './venues.js';

const PI = Math.PI, LV = 130, Y = 450;
function colored(geo, hex) {
  const g = geo.index ? geo.toNonIndexed() : geo, c = new THREE.Color(hex), n = g.attributes.position.count, a = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { a[i * 3] = c.r; a[i * 3 + 1] = c.g; a[i * 3 + 2] = c.b; }
  g.setAttribute('color', new THREE.BufferAttribute(a, 3)); if (g.attributes.uv) g.deleteAttribute('uv'); return g;
}
function canvasTex(w, h, draw) { const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t; }

export class Interiors {
  constructor(ctx) {
    Object.assign(this, ctx); // scene, world, ui, audio, player, venues, needs, env, home, tpc, onSave
    this.mats = {
      std: new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.75, emissive: 0x2a2622, emissiveIntensity: 1 }),
      shiny: new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.2, metalness: 0.3, emissive: 0x1a1a1a, emissiveIntensity: 1 }),
      glow: new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false }),
      glass: new THREE.MeshStandardMaterial({ color: 0xbfe0f0, roughness: 0.05, transparent: true, opacity: 0.3, depthWrite: false }),
    };
    this.inside = null; this.v = null; this.g = null; this.cols = []; this.people = []; this.points = []; this.seated = null; this.key = null; this.plate = null;
    this.venues.interiors = this; this.venues.onHere = (v, foods) => this.serve(foods);
  }
  // ------------------------------------------------------------------ construction
  build(v) {
    this.clear();
    const O = { x: v.x, z: v.z }, P = { std: [], shiny: [], glow: [] }, glass = [], col = this.world.collision, g = new THREE.Group(); this.scene.add(g); this.g = g;
    const box = (w, h, d, x, y, z, c, k = 'std') => P[k].push(colored(new THREE.BoxGeometry(w, h, d).translate(O.x + x, Y + y, O.z + z), c));
    const solid = (x0, z0, x1, z1, h = 3) => { const o = col.addBox(O.x + x0, O.z + z0, O.x + x1, O.z + z1, Y + h); o.lv = LV; this.cols.push(o); return o; };
    const pts = (x, z, r, label, action) => this.points.push({ x, z, r, label, action });
    const T = TYPES[v.type], accent = new THREE.Color(T.color).getHex();
    // coque : sol, murs (porte au sud), éclairage
    box(20, 0.1, 14, 0, 0.05, 0, v.type === 'banque' ? 0xd8d8d2 : v.type === 'hotel' ? 0x8a6a4c : 0xb8784a);
    box(20.4, 3.4, 0.2, 0, 1.7, -7.1, 0xeee8dc); box(0.2, 3.4, 14, -10.1, 1.7, 0, 0xeee8dc); box(0.2, 3.4, 14, 10.1, 1.7, 0, 0xeee8dc);
    box(8.8, 3.4, 0.2, -5.6, 1.7, 7.1, 0xeee8dc); box(8.8, 3.4, 0.2, 5.6, 1.7, 7.1, 0xeee8dc); box(2.4, 1.2, 0.2, 0, 2.8, 7.1, 0xeee8dc);
    solid(-10.2, -7.2, 10.2, -7.0); solid(-10.2, -7.2, -10.0, 7.2); solid(10.0, -7.2, 10.2, 7.2); solid(-10.2, 7.0, -1.2, 7.2); solid(1.2, 7.0, 10.2, 7.2);
    box(20, 0.25, 0.22, 0, 0.12, -6.98, accent); box(2.3, 2.2, 0.05, 0, 1.1, 7.0, 0x6a8ea8, 'glow');
    for (const x of [-6, 0, 6]) for (const z of [-3, 3]) box(1.6, 0.04, 0.5, x, 3.35, z, 0xfff2d8, 'glow');
    pts(0, 6.3, 1.3, `Sortir de ${v.name}`, () => this.exit());
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(6, 0.9), new THREE.MeshBasicMaterial({ map: canvasTex(640, 96, (x, w, h) => { x.fillStyle = T.color; x.fillRect(0, 0, w, h); x.fillStyle = '#fff'; x.font = '900 46px Arial'; x.textAlign = 'center'; x.fillText(`${T.icon} ${v.name.replace(/ — .*/, '')}`, w / 2, 62); }), toneMapped: false }));
    sign.position.set(O.x, Y + 2.85, O.z - 6.98); g.add(sign);
    this.tables = [];
    const table = (x, z, n) => { box(1.3, 0.06, 0.9, x, 0.76, z, 0x6a4a32); box(0.1, 0.74, 0.1, x, 0.37, z, 0x3a2a1a); for (const s of [-1, 1]) { box(0.46, 0.06, 0.46, x, 0.46, z + s * 0.75, 0x2a5aa8); box(0.46, 0.5, 0.06, x, 0.72, z + s * 0.98, 0x2a5aa8); } solid(x - 0.68, z - 0.48, x + 0.68, z + 0.48, 1); const t = { x, z, n }; this.tables.push(t); return t; };
    const person = (x, z, ry, opts = {}, sit = false) => { const c = createCharacter({ female: Math.random() < 0.5, skin: SKINS[Math.floor(Math.random() * SKINS.length)], shirtColor: opts.shirt, pants: opts.pants ?? 0x22252a, pagne: opts.shirt === undefined ? Math.floor(Math.random() * 6) : undefined, ...opts.extra }); if (sit) c.sit(false); c.group.position.set(O.x + x, Y + (sit ? -0.37 : 0.1), O.z + z); c.group.rotation.y = ry; g.add(c.group); const p = { c, sit, t: Math.random() * 5, x, z }; this.people.push(p); const o = col.addCircle(O.x + x, O.z + z, 0.32, Y + 1.8); o.lv = LV; this.cols.push(o); return p; };
    if (v.type === 'restaurant') {
      box(12, 1.05, 0.8, 0, 0.53, -5.6, 0xf2f2f2, 'shiny'); box(12.2, 0.06, 1.0, 0, 1.08, -5.6, 0x3a2416); solid(-6.1, -6.1, 6.1, -5.1, 1.2);
      for (let k = 0; k < 6; k++) box(0.5, 0.4, 0.5, -4 + k * 1.6, 1.3, -6.5, [0xc8c8c4, 0x8a8f96][k % 2], 'shiny'); // marmites
      const menu = new THREE.Mesh(new THREE.PlaneGeometry(3, 1.6), new THREE.MeshBasicMaterial({ map: canvasTex(420, 224, (x, w, h) => { x.fillStyle = '#1a1a1a'; x.fillRect(0, 0, w, h); x.fillStyle = '#f2c200'; x.font = 'bold 30px Arial'; x.fillText('MENU DU JOUR', 20, 42); x.fillStyle = '#fff'; x.font = '20px Arial'; this.venues.items(v).slice(0, 5).forEach((id, i) => x.fillText(`• ${this.venues.nameOf(v, id).slice(0, 34)}`, 20, 80 + i * 28)); }), toneMapped: false }));
      menu.position.set(O.x - 7.5, Y + 2.1, O.z - 6.97); g.add(menu);
      [[-6, -1.5], [0, -1.5], [6, -1.5], [-6, 2.5], [6, 2.5], [0, 2.5]].forEach(([x, z], i) => table(x, z, i + 1));
      this.cook = person(0, -6.5, 0, { shirt: 0xf2f2f2, extra: { hat: 'toque', hatColor: 0xffffff, sleeves: 'long' } });
      this.waiter = person(3, -4.4, PI, { shirt: 0x1a1a1a, pants: 0x1a1a1a, extra: { collar: 0xffffff } }); this.waiter.home = { x: 3, z: -4.4 };
      for (const t of this.tables.filter((q) => q.n === 3 || q.n === 4)) person(t.x, t.z - 0.75, 0, {}, true); // clients attablés
      this.tables = this.tables.filter((q) => q.n !== 3 && q.n !== 4);
      pts(0, -4.5, 1.6, 'Comptoir : commander (sur place ou à emporter)', () => this.venues.toggle(true, v));
      for (const t of this.tables) pts(t.x, t.z + 1.25, 0.9, `S’asseoir à la table ${t.n} et commander`, () => this.sit(t));
    } else if (v.type === 'hotel') {
      box(4, 1.1, 0.9, 5, 0.55, 2.6, 0xf2f2f2, 'shiny'); box(4.2, 0.06, 1.1, 5, 1.12, 2.6, 0x3a2416); solid(2.9, 2.1, 7.1, 3.1, 1.2);
      box(2.4, 1.4, 0.05, 5, 2.2, 1.0, 0x2a2416); for (let k = 0; k < 8; k++) box(0.12, 0.18, 0.04, 4.1 + (k % 4) * 0.6, 1.9 + Math.floor(k / 4) * 0.5, 1.04, 0xd8a830, 'shiny'); // tableau à clés
      person(5, 1.6, 0, { shirt: 0x7a2a8a, extra: { collar: true, sleeves: 'long' } });
      for (const [x, z, ry] of [[-6.5, 5.6, PI], [-8.8, 3.6, PI / 2]]) { box(ry === PI ? 3 : 0.9, 0.45, ry === PI ? 0.9 : 3, x, 0.3, z, 0x5a2a4a); solid(x - (ry === PI ? 1.5 : 0.45), z - (ry === PI ? 0.45 : 1.5), x + (ry === PI ? 1.5 : 0.45), z + (ry === PI ? 0.45 : 1.5), 1); }
      box(1.2, 0.06, 0.7, -6.5, 0.45, 3.8, 0x6a4a32); solid(-7.1, 3.45, -5.9, 4.15, 0.6);
      pts(5, 4.2, 1.6, 'Réception : réserver une chambre, repos, douche', () => this.venues.toggle(true, v));
      pts(-6.5, 4.6, 1.2, 'Salon de l’hôtel : s’asseoir (espace commun)', () => { this.ui.toast('Tu te détends dans le salon de l’hôtel. Énergie +3', 2); this.needs.energy = Math.min(100, this.needs.energy + 3); });
      // coin restaurant de l'hôtel
      for (const [x, z, n] of [[2, -0.6, 1], [6.5, -0.6, 2]]) table(x, z, n);
      const resto = this.venues.list.find((q) => q.town === v.town && q.type === 'restaurant');
      this.hotelResto = resto;
      for (const t of this.tables) pts(t.x, t.z + 1.25, 0.9, `Restaurant de l’hôtel : table ${t.n}`, () => this.sit(t, resto));
      this.waiter = person(9, -1.6, -PI / 2, { shirt: 0x1a1a1a, pants: 0x1a1a1a, extra: { collar: 0xffffff } }); this.waiter.home = { x: 9, z: -1.6 };
      // couloir et chambre 12 (z −7 → −2,5)
      box(9.2, 3.4, 0.2, -5.6, 1.7, -2.5, 0xe8dcc8); box(4.6, 3.4, 0.2, 2.3, 1.7, -2.5, 0xe8dcc8); box(1.4, 1.2, 0.2, -0.3, 2.8, -2.5, 0xe8dcc8); box(0.2, 3.4, 4.5, 4.6, 1.7, -4.75, 0xe8dcc8);
      solid(-10, -2.6, -1.0, -2.4); solid(0.4, -2.6, 4.7, -2.4); solid(4.5, -7, 4.7, -2.5);
      const lab = new THREE.Mesh(new THREE.PlaneGeometry(0.6, 0.25), new THREE.MeshBasicMaterial({ map: canvasTex(128, 54, (x, w, h) => { x.fillStyle = '#d8a830'; x.fillRect(0, 0, w, h); x.fillStyle = '#1a1a1a'; x.font = 'bold 30px serif'; x.textAlign = 'center'; x.fillText('N° 12', w / 2, 38); }), toneMapped: false }));
      lab.position.set(O.x - 1.4, Y + 2.0, O.z - 2.38); g.add(lab);
      this.roomDoor = solid(-1.0, -2.6, 0.4, -2.4); const leaf = new THREE.Mesh(colored(new THREE.BoxGeometry(1.4, 2.2, 0.06), 0x5a3a22), this.mats.std); leaf.position.set(O.x - 0.3, Y + 1.15, O.z - 2.5); g.add(leaf); this.roomLeaf = leaf;
      pts(-0.3, -1.6, 1.0, () => (this.key ? 'Ouvrir la chambre n° 12 (clé)' : 'Chambre n° 12 — réservation à la réception'), () => this.openRoom());
      // chambre : lit, chevets, télévision, armoire, salle d'eau
      box(2.2, 0.5, 2.4, -7.6, 0.3, -5.6, 0xf2f2f2); box(2.2, 0.9, 0.12, -7.6, 0.75, -6.85, 0x6a4a32); box(2.25, 0.12, 1.6, -7.6, 0.6, -5.2, 0x7a2a8a); solid(-8.7, -6.9, -6.5, -4.4, 0.8);
      for (const x of [-9.3, -5.9]) box(0.5, 0.5, 0.5, x, 0.25, -6.5, 0x6a4a32);
      box(1.6, 0.9, 0.05, -7.6, 1.8, -2.62, 0x111418, 'shiny'); box(1.5, 0.8, 0.01, -7.6, 1.8, -2.65, 0x2f5a8a, 'glow');
      box(1.6, 2.2, 0.6, -3.0, 1.1, -6.6, 0x8a6a4c); solid(-3.8, -6.9, -2.2, -6.3, 2.2);
      box(2.6, 0.05, 2.3, 2.9, 0.12, -5.6, 0xcfe0e8); box(0.05, 2.2, 2.3, 1.6, 1.1, -5.6, 0xcfe0e8, 'shiny'); box(0.3, 0.2, 0.1, 2.9, 2.2, -6.85, 0xc8ccd0, 'shiny');
      pts(-7.6, -3.9, 1.1, () => (this.key && this.key.kind !== 'shower' ? `Se coucher (${this.key.kind === 'rest' ? 'repos de 2 h' : 'dormir jusqu’à 7 h'})` : 'Lit (réservé aux clients de la nuit)'), () => this.bed());
      pts(2.9, -4.6, 1.0, () => 'Salle d’eau : prendre une douche', () => this.shower());
    } else if (v.type === 'banque') {
      for (const x of [-3, 3]) { box(3, 1.15, 0.8, x, 0.58, -5.2, 0xe8e2d6, 'shiny'); glass.push(new THREE.BoxGeometry(3, 1.0, 0.04).translate(O.x + x, Y + 1.7, O.z - 5.2)); solid(x - 1.5, -5.6, x + 1.5, -4.8, 2.2); person(x, -6.0, 0, { shirt: 0x1f4e9c, extra: { collar: true, sleeves: 'long', tie: 0xc8102e } }); }
      for (const [x, n] of [[-3, 1], [3, 2]]) { const pl = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 0.3), new THREE.MeshBasicMaterial({ map: canvasTex(200, 50, (c, w, h) => { c.fillStyle = '#1f4e9c'; c.fillRect(0, 0, w, h); c.fillStyle = '#fff'; c.font = 'bold 28px Arial'; c.textAlign = 'center'; c.fillText(`GUICHET ${n}`, w / 2, 36); }), toneMapped: false })); pl.position.set(O.x + x, Y + 2.45, O.z - 5.18); g.add(pl); pts(x, -3.9, 1.3, `Guichet ${n} : dépôts, retraits, comptes`, () => this.venues.toggle(true, v, false)); }
      for (const z of [-1.5, 1.5]) { box(0.6, 1.7, 0.6, 9.5, 0.85, z, 0x2a2d33, 'shiny'); box(0.03, 0.35, 0.4, 9.18, 1.3, z, 0x4ab8ff, 'glow'); box(0.04, 0.05, 0.25, 9.17, 1.0, z, 0x111111); solid(9.2, z - 0.32, 9.85, z + 0.32, 2); pts(8.6, z, 1.1, '🏧 Distributeur : dépôt ou retrait', () => this.venues.toggle(true, v, true)); }
      for (let k = 0; k < 4; k++) { box(0.5, 0.45, 0.5, -8 + k * 0.7, 0.25, 3.5, 0x2a2d33); }
      solid(-8.3, 3.2, -5.6, 3.8, 0.6);
      for (const x of [-1.2, 1.2]) box(0.06, 1.0, 0.06, x, 0.5, -2.6, 0xc8ccd0, 'shiny');
      box(2.4, 0.05, 0.05, 0, 0.9, -2.6, 0xc8102e);
      person(-7, 3.5, 0, {}, true); person(-1.6, 6.0, PI, { shirt: 0x2a2d33, extra: { hat: 'cap', hatColor: 0x1a1a1a } }); // client en attente, agent d'accueil
    }
    for (const k of ['std', 'shiny', 'glow']) if (P[k].length) g.add(new THREE.Mesh(mergeGeometries(P[k]), this.mats[k]));
    if (glass.length) { const gm = new THREE.Mesh(mergeGeometries(glass), this.mats.glass); gm.renderOrder = 3; g.add(gm); }
  }
  clear() {
    if (this.g) { this.scene.remove(this.g); this.g.traverse((o) => { if (o.geometry) o.geometry.dispose(); if (o.material && !Object.values(this.mats).includes(o.material)) { if (o.material.map) o.material.map.dispose(); o.material.dispose && o.material.dispose(); } }); }
    for (const o of this.cols) o.disabled = true;
    this.g = null; this.cols = []; this.people = []; this.points = []; this.tables = []; this.waiter = null; this.cook = null; this.plate = null; this.roomDoor = null; this.roomLeaf = null;
  }
  // ------------------------------------------------------------------ entrer / sortir
  enter(v) {
    if (!this.venues.isOpen(v)) return this.ui.toast(`${v.name} est fermé (${this.venues.hoursText(v)}).`, 2.5);
    this.v = v; this.inside = v.type; this.build(v);
    const pl = this.player; this.world.collision.level = LV; pl.floorY = Y; pl.pos.set(v.x, Y, v.z + 5.6); pl.vy = 0; pl.facing = PI; pl.mesh.position.copy(pl.pos);
    if (this.tpc && this.tpc.snap) this.tpc.snap(pl.pos);
    this.lightRig(true);
    this.ui.toast(`Bienvenue à ${v.name} (${v.town})`, 2.2);
  }
  exit(silent) {
    const v = this.v; if (!v) return;
    if (this.seated) this.stand();
    if (this.venues.open) this.venues.toggle(false);
    const pl = this.player; this.world.collision.level = 0; pl.floorY = 0; pl.pos.set(v.x, 0, v.z); pl.vy = 0; pl.mesh.position.copy(pl.pos);
    if (this.tpc && this.tpc.snap) this.tpc.snap(pl.pos);
    this.clear(); this.lightRig(false); this.inside = null; this.v = null;
    if (!silent) this.ui.toast(`Tu sors de ${v.name}.`, 1.6);
  }
  lightRig(on) {
    const ls = this.home && this.home.lights; if (!ls) return;
    if (!this._orig) this._orig = ls.map((l) => ({ p: l.position.clone(), d: l.distance }));
    if (on && this.v) { ls.forEach((l, i) => { l.position.set(this.v.x - 6 + i * 6, Y + 3.0, this.v.z); l.distance = 14; l.decay = 1.2; l.intensity = 20 * Math.min(1, (this.env ? this.env.lightsOn : 1) * 1.5); }); this._borrowed = true; }
    else if (this._borrowed) { ls.forEach((l, i) => { l.position.copy(this._orig[i].p); l.distance = this._orig[i].d; l.decay = 1.6; l.intensity = 0; }); this._borrowed = false; }
  }
  // ------------------------------------------------------------------ restaurant : à table
  sit(t, menuVenue) {
    const pl = this.player, v = this.v;
    this.seated = t; pl.pos.set(v.x + t.x, Y, v.z + t.z + 0.75); pl.facing = PI; pl.mesh.rotation.set(0, PI, 0); pl.char.sit && pl.char.sit(false); pl.mesh.position.set(pl.pos.x, Y - 0.37, pl.pos.z);
    this.ui.toast('Tu es à table : choisis ton plat « Manger ici ». (E pour te lever)', 2.8);
    this.venues.toggle(true, menuVenue || v);
  }
  stand() { const pl = this.player; this.seated = null; pl.char.stand && pl.char.stand(); pl.mesh.position.copy(pl.pos); if (this.plate) { this.g && this.g.remove(this.plate); this.plate = null; } }
  // le serveur apporte l'assiette à la table du joueur
  serve(foods) {
    if (!this.seated || !this.waiter || !this.g) return;
    const t = this.seated, w = this.waiter;
    w.task = { foods, path: [{ x: t.x + 0.9, z: t.z + 0.3 }], back: false, wait: 0 };
  }
  // ------------------------------------------------------------------ hôtel
  giveKey(v, kind) {
    if (kind === 'shower') this.key = this.key && this.key.kind !== 'shower' ? this.key : { vid: v.id, kind: 'shower' };
    else this.key = { vid: v.id, kind };
    this.ui.toast(`🔑 Clé de la chambre n° 12 remise (${{ rest: 'repos de 2 h', night: 'nuit en chambre standard', comfort: 'nuit en chambre confort', shower: 'accès à la salle d’eau' }[kind]}). La chambre est au fond du hall.`, 3.5);
    this.onSave && this.onSave();
  }
  openRoom() {
    if (!this.key || this.key.vid !== (this.v && this.v.id)) return this.ui.toast('Chambre réservée aux clients : réserve à la réception.', 2.5);
    if (this.roomDoor) { this.roomDoor.disabled = true; if (this.roomLeaf) { this.roomLeaf.rotation.y = 1.3; this.roomLeaf.position.x -= 0.5; this.roomLeaf.position.z += 0.5; } }
    if (this.audio && this.audio.ctx) this.audio.tone(520, 0.08, 0.04, 'triangle');
    this.ui.toast('Chambre ouverte. Bon séjour !', 1.8);
  }
  bed() {
    const k = this.key; if (!k || k.kind === 'shower') return this.ui.toast('Le lit est réservé aux clients ayant réservé un repos ou une nuit.', 2.5);
    this.key = k.kind === 'comfort' ? { ...k, kind: 'shower' } : null; // après la nuit, la salle d'eau reste accessible (confort)
    this.venues.startSleep(this.v, k.kind); this.onSave && this.onSave();
  }
  shower() {
    if (!this.key) return this.ui.toast('Réserve une chambre ou une douche à la réception.', 2.5);
    this.needs.hygiene = 100; this.ui.toast('Douche prise : propreté 100 %', 2.2); if (this.key.kind === 'shower') this.key = null;
  }
  // ------------------------------------------------------------------ boucle
  nearest(x, z) {
    if (!this.inside) return null;
    const lx = x - this.v.x, lz = z - this.v.z; let best = null;
    for (const p of this.points) { const d = Math.hypot(lx - p.x, lz - p.z); if (d < p.r && (!best || d < best.d)) best = { d, p }; }
    if (!best) return null; const p = best.p;
    return { d: best.d, it: { label: () => (typeof p.label === 'function' ? p.label() : p.label), action: p.action } };
  }
  update(dt, P) {
    if (!this.inside) return;
    if (!this.seated && (Math.hypot(P.x - this.v.x, P.z - this.v.z) > 16 || Math.abs((P.y || Y) - Y) > 6)) { this.clear(); this.lightRig(false); this.inside = null; this.v = null; this.world.collision.level = 0; this.player.floorY = 0; return; }
    if (this.seated) { const pl = this.player; pl.char.sit && pl.char.sit(false); }
    for (const p of this.people) {
      p.t += dt;
      if (p.sit) { const b = p.c.bones; b.armR.rotation.x = -0.9 + Math.sin(p.t * 2) * 0.25; b.foreR.rotation.x = -1.0; b.head.rotation.x = 0.2 + Math.sin(p.t) * 0.05; continue; }
      const w = p.task;
      if (w && p === this.waiter) {
        const tgt = w.back ? p.home : w.path[0], dx = tgt.x - p.x, dz = tgt.z - p.z, d = Math.hypot(dx, dz);
        if (d > 0.1 && w.wait <= 0) { const sp = Math.min(d, dt * 1.6); p.x += dx / d * sp; p.z += dz / d * sp; p.c.group.position.set(this.v.x + p.x, Y + 0.1, this.v.z + p.z); p.c.group.rotation.y = Math.atan2(dx, dz); p.c.animate(dt, 1.6); }
        else if (!w.back) { w.wait += dt; p.c.animate(dt, 0); const b = p.c.bones; b.armR.rotation.x = -1.2; if (w.wait > 0.8) { this.putPlate(w.foods); w.back = true; w.wait = 0; this.ui.toast('Le serveur apporte ton plat. Bon appétit !', 2); } }
        else { p.c.animate(dt, 0); p.task = null; p.c.group.rotation.y = PI; }
      } else p.c.animate(dt, 0);
    }
  }
  putPlate(foods) {
    if (!this.seated || !this.g) return; if (this.plate) this.g.remove(this.plate);
    const m = buildFoodModel(foods.filter((f) => f), true), t = this.seated; m.position.set(this.v.x + t.x, Y + 0.8, this.v.z + t.z + 0.15); this.g.add(m); this.plate = m;
  }
  serialize() { return { key: this.key }; }
  restore(s) { if (s && s.key) this.key = s.key; }
}
