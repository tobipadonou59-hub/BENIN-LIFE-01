// Mission 014 — NOVA BOOK : étages, métiers, équipe de départ (personnes fictives), logiciels fictifs.
export const FLOORS = [
  { lv: 0, name: 'Rez-de-chaussée', sub: 'Accueil & administration' },
  { lv: 1, name: '1er étage', sub: 'Graphisme & création visuelle' },
  { lv: 2, name: '2e étage', sub: 'Maquettisme & édition' },
  { lv: 3, name: '3e étage', sub: 'Développement & montage vidéo' },
  { lv: 4, name: '4e étage', sub: 'Impression & production' },
  { lv: 5, name: '5e étage', sub: 'Direction (bureau du PDG)' },
];
// métiers : salaire mensuel de base (FCFA, valeurs du jeu), département, pose de travail
export const JOBS = {
  graphiste: { label: 'Graphiste', salary: 180000, dept: 'Graphisme', pose: 'draw' },
  maquettiste: { label: 'Maquettiste', salary: 170000, dept: 'Édition', pose: 'type' },
  correcteur: { label: 'Correcteur', salary: 160000, dept: 'Édition', pose: 'read' },
  developpeur: { label: 'Développeur', salary: 300000, dept: 'Informatique', pose: 'type' },
  monteur: { label: 'Monteur vidéo', salary: 220000, dept: 'Audiovisuel', pose: 'edit' },
  imprimeur: { label: 'Imprimeur', salary: 150000, dept: 'Impression', pose: 'machine' },
  commercial: { label: 'Responsable commercial', salary: 200000, dept: 'Commercial', pose: 'type' },
  comptable: { label: 'Comptable', salary: 250000, dept: 'Administration', pose: 'type' },
  secretaire: { label: 'Secrétaire', salary: 120000, dept: 'Administration', pose: 'type' },
  entretien: { label: 'Agent d’entretien', salary: 80000, dept: 'Services généraux', pose: 'stand' },
  rh: { label: 'Responsable RH', salary: 250000, dept: 'Administration', pose: 'type' },
  directeur: { label: 'Directeur de département', salary: 450000, dept: 'Direction', pose: 'type' },
  // métiers des autres sociétés du groupe (étape 4)
  chauffeur: { label: 'Chauffeur-livreur', salary: 130000, dept: 'Transport', pose: 'stand', other: true },
  logisticien: { label: 'Logisticien', salary: 170000, dept: 'Logistique', pose: 'type', other: true },
  vendeur: { label: 'Vendeur', salary: 110000, dept: 'Ventes', pose: 'stand', other: true },
  agent_immo: { label: 'Agent immobilier', salary: 180000, dept: 'Immobilier', pose: 'type', other: true },
};
// équipe de départ : nom fictif, métier, étage, poste de travail (index dans les postes de l'étage)
export const START_STAFF = [
  ['Adjoa Kpodékon', 'secretaire', 0, 'reception'], ['Romuald Agbodji', 'commercial', 0, 0], ['Clarisse Houénou', 'commercial', 0, 1],
  ['Serge Ahouandjinou', 'directeur', 1, 0], ['Nadège Akpovi', 'graphiste', 1, 1], ['Wilfried Dossou-Yovo', 'graphiste', 1, 2], ['Pélagie Gnancadja', 'graphiste', 1, 3], ['Ulrich Sossa', 'graphiste', 1, 4],
  ['Hermine Zinsou', 'maquettiste', 2, 0], ['Arnaud Tchibozo', 'maquettiste', 2, 1], ['Brice Kiki', 'maquettiste', 2, 2], ['Odile Hounsa', 'correcteur', 2, 3], ['Fabrice Adjovi', 'correcteur', 2, 4],
  ['Gildas Amoussou', 'developpeur', 3, 0], ['Mireille Fanou', 'developpeur', 3, 1], ['Kévin Ahyi', 'developpeur', 3, 2], ['Rachidatou Bello', 'monteur', 3, 3], ['Landry Dégbo', 'monteur', 3, 4],
  ['Cyriaque Hounkpè', 'imprimeur', 4, 0], ['Sylvestre Gbaguidi', 'imprimeur', 4, 1], ['Edwige Kossou', 'imprimeur', 4, 2], ['Rodrigue Assogba', 'imprimeur', 4, 3],
  ['Murielle Ahossi', 'comptable', 5, 0], ['Josué Lokossou', 'rh', 5, 1], ['Bénédicte Avocè', 'secretaire', 5, 2], ['Grâce Hounyè', 'entretien', 5, 3],
];
export const SOFTWARE = { 1: 'NovaDesign', 2: 'NovaPage', 3: 'NovaCode / NovaCut', 4: 'NovaPress' };
export const BOOKS = ['Les Rives de la Lagune (roman)', 'Mathématiques CM2 — manuel scolaire', 'Contes du soir (jeunesse)', 'Guide de l’entrepreneur béninois', 'Atlas illustré du Bénin', 'Poèmes du Golfe'];
export const GREETINGS = ['Bonjour, Direction !', 'Bonjour ! Tout avance bien ici.', 'Bonjour ! Le travail est en cours.', 'Bonne arrivée, PDG !', 'Bonjour, on termine ce dossier aujourd’hui.'];
export const FEMALE = new Set(['Adjoa', 'Clarisse', 'Nadège', 'Pélagie', 'Hermine', 'Odile', 'Mireille', 'Rachidatou', 'Edwige', 'Murielle', 'Bénédicte', 'Grâce']);
