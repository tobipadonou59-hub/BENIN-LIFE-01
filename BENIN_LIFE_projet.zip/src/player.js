// Joueur à pied : déplacements relatifs à la caméra, course, saut, collisions.
import * as THREE from 'three';
import { createCharacter } from './character.js';
import { clamp, damp, dampAngle } from './util.js';
import { MAP, SEA_Z, BOUNDS } from './world.js';
import { landClamp } from './region-geo.js';

export class Player {
  constructor(scene) {
    this.onStep = null; this.onLand = null;
    this.scene = scene;
    this.kind = 'male';
    this.char = Player.proceduralChar('male', (v) => this.onStep && this.onStep(v));
    this.mesh = this.char.group;
    scene.add(this.mesh);
    this.pos = new THREE.Vector3(8.6, 0, 36);
    this.vel = new THREE.Vector3();
    this.vy = 0;
    this.onGround = true;
    this.facing = Math.PI;
    this.inCar = null;
    this.radius = 0.38;
    this.stamina = 1;
  }

  static proceduralChar(kind, onStep) {
    return kind === 'female'
      ? createCharacter({ female: true, pagne: 2, skin: 0x5a3a26, onStep })
      : createCharacter({ pagne: 0, skin: 0x4e3122, pants: 0x2b3442, onStep });
  }

  // Remplace l'apparence du joueur (personnage procédural ou modèle GLB) sans toucher aux déplacements
  setCharacter(kind, char = null) {
    const visible = this.mesh.visible;
    this.scene.remove(this.mesh);
    this.kind = kind;
    this.char = char || Player.proceduralChar(kind, (v) => this.onStep && this.onStep(v));
    this.mesh = this.char.group;
    this.mesh.visible = visible;
    this.mesh.position.copy(this.pos);
    this.mesh.rotation.y = this.facing;
    this.scene.add(this.mesh);
  }

  update(dt, input, camYaw, world, obstacles) {
    const f = (input.down('KeyW') || input.down('ArrowUp') ? 1 : 0) - (input.down('KeyS') || input.down('ArrowDown') ? 1 : 0);
    const r = (input.down('KeyD') || input.down('ArrowRight') ? 1 : 0) - (input.down('KeyA') || input.down('ArrowLeft') ? 1 : 0);
    // repère caméra : avant = -(sin yaw, cos yaw), droite = (cos yaw, -sin yaw)
    let mx = -Math.sin(camYaw) * f + Math.cos(camYaw) * r;
    let mz = -Math.cos(camYaw) * f - Math.sin(camYaw) * r;
    if (this.frozen) { mx = 0; mz = 0; } // animation de pouvoir en cours
    const len = Math.hypot(mx, mz);
    const running = input.down('ShiftLeft') || input.down('ShiftRight');
    if (running && len > 0 && !this.staminaLock) this.stamina = Math.max(0, this.stamina - dt * 0.12);
    else this.stamina = Math.min(1, this.stamina + dt * 0.2 * (this.staminaMul || 1));
    const speed = (running && this.stamina > 0.02 && this.canRun !== false ? 6.2 : 2.6) * (this.speedMul || 1);
    this.running = speed > 3 && len > 0;
    if (len > 0) { mx /= len; mz /= len; this.facing = dampAngle(this.facing, Math.atan2(mx, mz), 12, dt); }
    const accel = this.onGround ? 12 : 3;
    this.vel.x = damp(this.vel.x, mx * speed * (len > 0 ? 1 : 0), accel, dt);
    this.vel.z = damp(this.vel.z, mz * speed * (len > 0 ? 1 : 0), accel, dt);

    if (input.hit('Space') && this.onGround && !this.frozen) { this.vy = 5.2 * (this.jumpMul || 1); this.onGround = false; }
    this.vy -= 15 * (this.gravMul || 1) * dt;
    this.pos.y += this.vy * dt;
    const fy = this.floorY || 0; // plancher de l'étage courant (bâtiments à étages)
    if (this.pos.y <= fy) {
      if (!this.onGround && this.vy < -3 && this.onLand) this.onLand();
      this.pos.y = fy; this.vy = 0; this.onGround = true;
    }

    this.pos.x += this.vel.x * dt;
    this.pos.z += this.vel.z * dt;
    world.collision.resolve(this.pos, this.radius, obstacles);
    landClamp(this, 1); // région : terre ferme (mer, lacs, limites)

    this.mesh.position.copy(this.pos);
    this.mesh.rotation.y = this.facing;
    const hs = Math.hypot(this.vel.x, this.vel.z);
    if (this.onGround) this.char.animate(dt, hs); else this.char.jumpPose();
    return hs;
  }
}
