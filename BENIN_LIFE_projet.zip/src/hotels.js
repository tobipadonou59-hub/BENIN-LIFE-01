// Mission 021, étape 4 — hôtels de luxe (établissements FICTIFS) dans des bâtiments existants : 2 à Cotonou, 1 à
// Porto-Novo, 1 à Ouidah. Intérieur commun (niveau isolé) habillé aux couleurs de chaque hôtel : hall en marbre avec
// fontaine, réception, conciergerie, bar du lobby (sans alcool), restaurant gastronomique, piscine et transats, salle
// de sport, spa (massage, sauna, jacuzzi), ascenseurs vers l'aile des chambres (chambre standard, suite, suite
// présidentielle). Personnel et clients. Réservation (NOVA TRAVEL ou réception), paiement, séjour (clé, nuits,
// petit-déjeuner, service en chambre), départ. Extérieur : enseigne, marquise d'entrée, parking signalé.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { colorize } from './vehicles.js';
import { createCharacter, SKINS } from './character.js';
import { fcfa } from './food-data.js';

const PI = Math.PI;
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const pick = (a) => a[Math.floor(Math.random() * a.length)];
export const HI = { LV: 210, Y: 760, O: { x: 220, z: -240 } };
export const HOTELS = [
  { id: 'golfe', name: 'GOLFE PALACE COTONOU', short: 'Golfe Palace', town: 'Cotonou', stars: 5, fp: [64.5, 77.4, 79.5, 89.4], c1: '#0b2a4a', c2: '#d8a830', price: { std: 120000, suite: 450000, pres: 1500000 } },
  { id: 'lagune', name: 'RÉSIDENCE LAGUNE ROYALE', short: 'Lagune Royale', town: 'Cotonou', stars: 5, fp: [-89, 11, -53, 23], c1: '#1f4e9c', c2: '#f2efe8', price: { std: 95000, suite: 380000, pres: 1200000 } },
  { id: 'capitale', name: 'GRAND HÔTEL DE LA CAPITALE', short: 'Grand Hôtel de la Capitale', town: 'Porto-Novo', stars: 4, c1: '#6a1a2a', c2: '#fcd116', price: { std: 70000, suite: 250000, pres: 800000 } },
  { id: 'ouidah', name: 'OUIDAH BEACH RESORT', short: 'Ouidah Beach Resort', town: 'Ouidah', stars: 5, c1: '#0b6e4f', c2: '#f2e6c8', price: { std: 85000, suite: 320000, pres: 1000000 } },
];
const HBY = Object.fromEntries(HOTELS.map((h) => [h.id, h]));
export const ROOMS = { std: { name: 'Chambre deluxe', num: '512', door: [15, 17] }, suite: { name: 'Suite junior', num: '804', door: [3, 5] }, pres: { name: 'Suite présidentielle', num: '1201', door: [-13, -11] } };
const DAY_PASS = 25000;
const MENU = [['Menu dégustation du chef (5 plats)', 45000, 60], ['Filet de capitaine grillé, sauce moyo', 18000, 45], ['Agneau rôti, purée d’igname', 22000, 50], ['Assiette de fruits exotiques', 6000, 15], ['Cocktail de fruits sans alcool', 5000, 6]];
const SPA = [['Massage relaxant (1 h)', 35000, 1, { energy: 30, hygiene: 20 }], ['Sauna et hammam (45 min)', 15000, 0.75, { hygiene: 40, energy: 10 }], ['Jacuzzi (30 min)', 10000, 0.5, { energy: 15, hygiene: 15 }], ['Soin du visage (45 min)', 25000, 0.75, { hygiene: 30 }]];

export class Hotels {
  constructor(ctx) {
    Object.assign(this, ctx); // T, scene, world, region, player, ui, audio, env, economy, needs, tpc, home, bizUI, driver, onSave
    this.res = []; this.seq = 1; this.inside = null; this.points = []; this.people = []; this.view = 'list'; this.sel = { h: 'golfe', room: 'std', n: 1 }; this.passes = {};
    if (this.T) { this.T.hotels = this; if (this.T._hot) this.restore(this.T._hot); }
    this.buildOutsides(); this.buildInside();
  }
  get(id) { return HBY[id]; }
  abs() { return this.T.abs(); }
  day() { return this.economy.day || 1; }
  save() { this.onSave && this.onSave(); }
  label(t, sub, w, h, bg, fg) {
    const c = document.createElement('canvas'); c.width = 1024; c.height = Math.round(1024 * h / w); const x = c.getContext('2d');
    x.fillStyle = bg; x.fillRect(0, 0, c.width, c.height); x.strokeStyle = fg; x.lineWidth = 8; x.strokeRect(10, 10, c.width - 20, c.height - 20);
    x.fillStyle = fg; x.textAlign = 'center'; x.textBaseline = 'middle'; x.font = `900 ${Math.round(c.height * (sub ? 0.36 : 0.5))}px Georgia`; x.fillText(t, c.width / 2, c.height * (sub ? 0.4 : 0.5), c.width - 40);
    if (sub) { x.font = `700 ${Math.round(c.height * 0.17)}px Arial`; x.fillText(sub, c.width / 2, c.height * 0.76, c.width - 40); }
    const tx = new THREE.CanvasTexture(c); tx.colorSpace = THREE.SRGBColorSpace; return new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ map: tx, side: THREE.DoubleSide }));
  }
  // ------------------------------------------------------------------ extérieurs : bâtiments existants réutilisés
  buildOutsides() {
    const col = this.world.collision;
    for (const H of HOTELS) {
      let faces;
      if (H.fp) { const [a, b, c, d] = H.fp, cx = (a + c) / 2, cz = (b + d) / 2; faces = [[cx, d, 0, 1, c - a], [cx, b, 0, -1, c - a], [c, cz, 1, 0, d - b], [a, cz, -1, 0, d - b]]; }
      else {
        const T = this.region && this.region.towns.find((t) => t.name === H.town); if (!T) continue;
        const hs = T.houses.filter((h) => !h.school && !h.hotel && Math.hypot(h.x - T.x, h.z - T.z) < T.r * 0.5 && h.w > 11 && h.d > 11).sort((p, q) => Math.hypot(p.x - T.x + 30, p.z - T.z) - Math.hypot(q.x - T.x + 30, q.z - T.z));
        let F = null; for (const h of hs) { const sx = Math.sin(h.ry), cr = Math.cos(h.ry), e = Math.max(h.w, h.d) * 0.4;
          for (const f of [[h.x + sx * e, h.z + cr * e, sx, cr, e * 2], [h.x - sx * e, h.z - cr * e, -sx, -cr, e * 2], [h.x + cr * e, h.z - sx * e, cr, -sx, e * 2], [h.x - cr * e, h.z + sx * e, -cr, sx, e * 2]]) { let sc = 0; for (const dd of [1.4, 3, 5, 7, 9]) if (!col.pointBlocked(f[0] + f[2] * dd, 0.5, f[1] + f[3] * dd)) sc++; if (sc === 5) { F = f; break; } }
          if (F) { h.hotel = H.id; break; } }
        if (!F) continue; faces = [F];
      }
      let best = null; for (const [fx, fz, nx, nz, wid] of faces) { let sc = 0; for (const dd of [1.4, 3, 5, 7, 9]) if (!col.pointBlocked(fx + nx * dd, 0.5, fz + nz * dd)) sc++; if (!best || sc > best.sc) best = { fx, fz, nx, nz, wid, sc }; }
      const ry = Math.atan2(best.nx, best.nz), lx = Math.cos(ry), lz = -Math.sin(ry), wx = best.fx + best.nx * 0.14, wz = best.fz + best.nz * 0.14, g = new THREE.Group(); this.scene.add(g);
      const W = Math.min(11, best.wid - 1), sign = this.label(H.name, `${'★'.repeat(H.stars)} • hôtel fictif`, W, W * 0.16, H.c1, H.c2); sign.position.set(wx, 4.6, wz); sign.rotation.y = ry; g.add(sign);
      const door = new THREE.Mesh(new THREE.PlaneGeometry(2.6, 2.5), new THREE.MeshStandardMaterial({ color: 0x2a4a5a, roughness: 0.1, metalness: 0.3 })); door.position.set(wx + best.nx * 0.03, 1.25, wz + best.nz * 0.03); door.rotation.y = ry; g.add(door);
      // marquise d'entrée sur 4 colonnes, tapis, parking marqué
      const gold = new THREE.MeshStandardMaterial({ color: new THREE.Color(H.c2), metalness: 0.4, roughness: 0.4 }), dark = new THREE.MeshStandardMaterial({ color: new THREE.Color(H.c1) });
      for (const k of [-2.2, 2.2]) { const p = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, 3.2, 10), gold); p.position.set(wx + best.nx * 3.4 + lx * k, 1.6, wz + best.nz * 3.4 + lz * k); g.add(p); col.addCircle(p.position.x, p.position.z, 0.2, 3.2); }
      const roof = new THREE.Mesh(new THREE.BoxGeometry(5.4, 0.25, 4.2), dark); roof.position.set(wx + best.nx * 1.9, 3.3, wz + best.nz * 1.9); roof.rotation.y = ry; g.add(roof);
      const mat = new THREE.Mesh(new THREE.PlaneGeometry(1.8, 3.6), new THREE.MeshStandardMaterial({ color: 0x8a1a2a })); mat.rotation.set(-PI / 2, 0, ry); mat.position.set(wx + best.nx * 1.9, 0.02, wz + best.nz * 1.9); g.add(mat);
      const pk = this.label('P', 'Parking de l’hôtel', 1.4, 1.0, '#1f4e9c', '#ffffff'); pk.position.set(wx + best.nx * 6 + lx * 6.5, 2.2, wz + best.nz * 6 + lz * 6.5); pk.rotation.y = ry; g.add(pk);
      const line = new THREE.MeshBasicMaterial({ color: 0xf2f2f2 }); for (let k = 0; k < 5; k++) { const s = new THREE.Mesh(new THREE.PlaneGeometry(0.12, 4.5), line); s.rotation.set(-PI / 2, 0, ry); s.position.set(wx + best.nx * 8 + lx * (4.5 + k * 2.6), 0.03, wz + best.nz * 8 + lz * (4.5 + k * 2.6)); g.add(s); }
      H.doorPt = { x: wx + best.nx * 1.6, z: wz + best.nz * 1.6 }; H.face = { nx: best.nx, nz: best.nz }; H.ext = g;
      if (this.ui.pois && !this.ui.pois.some((q) => q.id === `hotel_${H.id}`)) this.ui.pois.push({ id: `hotel_${H.id}`, name: H.name, cat: 'services', x: H.doorPt.x, z: H.doorPt.z, status: 'fictif', access: true, address: H.town, note: `Hôtel ${H.stars} étoiles fictif • réservation dans NOVA TRAVEL` });
    }
  }
  // ------------------------------------------------------------------ intérieur commun
  buildInside() {
    const { LV, Y, O } = HI, g = new THREE.Group(); g.position.set(O.x, Y, O.z); g.visible = false; this.scene.add(g); this.ig = g;
    const parts = [], glass = [], glow = [], acc = [], water = [], C = this.world.collision, Hh = 6; this.doors = {};
    const box = (x0, y0, z0, x1, y1, z1, c, arr = parts) => arr.push(colorize(new THREE.BoxGeometry(Math.abs(x1 - x0) || 0.01, Math.abs(y1 - y0) || 0.01, Math.abs(z1 - z0) || 0.01).translate((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), c));
    const solid = (x0, z0, x1, z1, h = Hh) => { const o = C.addBox(O.x + Math.min(x0, x1), O.z + Math.min(z0, z1), O.x + Math.max(x0, x1), O.z + Math.max(z0, z1), Y + h); o.lv = LV; return o; };
    const wall = (x0, z0, x1, z1, c = 0xe8e0d0, h = Hh) => { box(x0, 0, z0, x1, h, z1, c); solid(x0, z0, x1, z1, h); };
    const gwall = (x0, z0, x1, z1) => { box(x0, 0, z0, x1, 2.8, z1, 0x9ab8c4, glass); solid(x0, z0, x1, z1, 2.8); };
    const P = (x, z, r, label, action) => this.points.push({ x, z, r, label, action });
    const sofa = (x0, z0, x1, z1, c, back) => { box(x0, 0.2, z0, x1, 0.48, z1, c); if (back === 'n') box(x0, 0.48, z0, x1, 0.95, z0 + 0.22, c); if (back === 's') box(x0, 0.48, z1 - 0.22, x1, 0.95, z1, c); if (back === 'w') box(x0, 0.48, z0, x0 + 0.22, 0.95, z1, c); if (back === 'e') box(x1 - 0.22, 0.48, z0, x1, 0.95, z1, c); solid(x0, z0, x1, z1, 0.95); };
    // ---- bâtiment principal (x −35…35, z −22…22) ----
    box(-35, -0.1, -22, 35, 0, 22, 0xe8e2d6); for (let x = -34; x < 35; x += 3) box(x, 0.001, -22, x + 0.04, 0.004, 22, 0xc8c0b0);
    box(-2, 0.002, 6, 2, 0.006, 21.5, 0x8a1a2a, acc); // tapis d'entrée (couleur de l'hôtel)
    wall(-35, 21.8, -2.5, 22.1); wall(2.5, 21.8, 35, 22.1); wall(-35, -22.1, 35, -21.8); wall(-35.1, -22, -34.8, 22); wall(34.8, -22, 35.1, 9.5); wall(34.8, 14.5, 35.1, 22);
    box(-2.5, 0, 21.85, 2.5, 3, 21.95, 0x2a4a5a, glass); P(0, 20.4, 1.5, 'Sortir de l’hôtel', () => this.exit());
    // fontaine, lustres, plantes
    box(-2.6, 0, -4.6, 2.6, 0.6, 0.6, 0xd8d0c0); box(-2.2, 0.55, -4.2, 2.2, 0.6, 0.2, 0x4aa8d8, water); box(-0.3, 0.6, -2.3, 0.3, 2.0, -1.7, 0xd8d0c0); solid(-2.6, -4.6, 2.6, 0.6, 0.8);
    for (const [x, z] of [[0, 10], [-8, 4], [8, 4]]) { box(x - 1.2, 4.8, z - 1.2, x + 1.2, 5.0, z + 1.2, 0xf2c860, glow); box(x - 0.05, 5.0, z - 0.05, x + 0.05, 6, z + 0.05, 0xd8a830); }
    for (const [x, z] of [[-4, 20.6], [4, 20.6], [-12.6, 20.6], [33.6, 20.6], [-12.6, 3.2], [22.4, -6.8]]) { box(x - 0.45, 0, z - 0.45, x + 0.45, 0.8, z + 0.45, 0x3a3d42); box(x - 0.7, 0.8, z - 0.7, x + 0.7, 2.6, z + 0.7, 0x2f7a3a); solid(x - 0.5, z - 0.5, x + 0.5, z + 0.5, 2.6); }
    // salons du hall
    for (const s of [-1, 1]) { sofa(s * 8 - 2.5, 12, s * 8 + 2.5, 12.9, 0xece6dc, 'n'); sofa(s * 8 - 2.5, 15.6, s * 8 + 2.5, 16.5, 0xece6dc, 's'); box(s * 8 - 1.2, 0.4, 13.7, s * 8 + 1.2, 0.45, 14.8, 0x3a2416); solid(s * 8 - 1.2, 13.7, s * 8 + 1.2, 14.8, 0.5); }
    P(-8, 11.3, 1.2, 'Salon du hall : s’asseoir et se détendre', () => this.relax()); P(8, 11.3, 1.2, 'Salon du hall : s’asseoir et se détendre', () => this.relax());
    // réception, tableau, conciergerie
    box(9, 0, 9, 17, 1.1, 10.2, 0x3a2416); box(8.9, 1.1, 8.9, 17.1, 1.18, 10.3, 0xf2efe8); box(9, 0.2, 10.2, 17, 0.9, 10.25, 0xd8a830, acc); solid(9, 9, 17, 10.2, 1.2);
    box(9.5, 1.6, 7.6, 16.5, 4.2, 7.7, 0x2a2416); this.recSign = { x: 13, y: 3.2, z: 7.75 };
    P(13, 11.6, 1.6, 'Réception : réservation, arrivée, départ', () => this.reception());
    box(18, 0, 2, 21, 1.05, 3, 0x3a2416); solid(18, 2, 21, 3, 1.1); P(19.5, 4.2, 1.3, 'Conciergerie : chauffeur, informations, excursions', () => this.concierge());
    // bar du lobby
    box(22, 0, 18.2, 31, 1.1, 19.2, 0x2a2416); box(21.9, 1.1, 18.1, 31.1, 1.16, 19.3, 0xd8d0c0); solid(22, 18.2, 31, 19.2, 1.2); for (let k = 0; k < 10; k++) box(22.6 + k * 0.85, 1.6, 21.4, 22.9 + k * 0.85, 2.0, 21.7, [0xe46a1f, 0xfcd116, 0xe8112d, 0x2fb04a][k % 4], glow);
    for (let k = 0; k < 4; k++) { const x = 23.5 + k * 2; box(x - 0.25, 0, 16.9, x + 0.25, 0.75, 17.4, 0x1a1a1e); solid(x - 0.28, 16.88, x + 0.28, 17.42, 0.8); }
    P(26.5, 15.8, 1.6, 'Bar du lobby (cocktails sans alcool, jus frais)', () => this.bar());
    // ascenseurs (mur est)
    box(34.7, 0, 9.5, 34.8, 3, 14.5, 0xc8ccd2); box(34.6, 0.2, 10.1, 34.7, 2.6, 11.9, 0x8a8f96); box(34.6, 0.2, 12.1, 34.7, 2.6, 13.9, 0x8a8f96); solid(34.6, 9.5, 35.1, 14.5);
    P(33.4, 12, 1.4, 'Ascenseurs : monter aux chambres', () => this.lift(true));
    // restaurant (ouest, cloison vitrée avec entrée)
    box(-35, 0.001, 2, -14, 0.006, 21.8, 0x6a4a32); gwall(-14.1, 2, -13.9, 8); gwall(-14.1, 12.5, -13.9, 21.8); gwall(-35, 1.9, -14, 2.1);
    for (let i = 0; i < 8; i++) { const x = -30 + (i % 4) * 4.4, z = 6.5 + Math.floor(i / 4) * 6; box(x - 0.7, 0.72, z - 0.7, x + 0.7, 0.78, z + 0.7, 0xf6f6f6); box(x - 0.08, 0, z - 0.08, x + 0.08, 0.72, z + 0.08, 0xd8a830); solid(x - 0.7, z - 0.7, x + 0.7, z + 0.7, 0.8); for (const dz of [-1.05, 1.05]) { box(x - 0.24, 0, z + dz - 0.24, x + 0.24, 0.48, z + dz + 0.24, 0x6a1a2a); box(x - 0.24, 0.48, z + dz + (dz > 0 ? 0.16 : -0.24), x + 0.24, 1.0, z + dz + (dz > 0 ? 0.24 : -0.16), 0x6a1a2a); } }
    box(-34.5, 0, 14, -32.5, 1.0, 21, 0xd8d0c0); solid(-34.5, 14, -32.5, 21, 1.0); for (let k = 0; k < 6; k++) box(-34.2, 1.0, 14.4 + k * 1.1, -32.8, 1.2, 15.1 + k * 1.1, [0xe46a1f, 0xf2c200, 0x2fb04a, 0xc8102e][k % 4]);
    P(-19, 10.2, 1.8, 'Restaurant gastronomique : commander', () => this.restaurant()); P(-31.4, 17.5, 1.3, 'Buffet du petit-déjeuner', () => this.breakfast());
    // piscine (nord-ouest), transats, bar de la piscine
    box(-35, 0.001, -22, -4, 0.006, -4, 0xb08050); gwall(-35, -4.1, -20, -3.9); gwall(-16, -4.1, -4, -3.9); gwall(-4.1, -22, -3.9, -4);
    box(-30.5, -0.05, -19.5, -11.5, 0.15, -9.5, 0xe8e2d6); box(-30, 0.1, -19, -12, 0.14, -10, 0x2a9ad8, water); solid(-30.5, -19.5, -11.5, -9.5, 1.2);
    for (let k = 0; k < 7; k++) { const x = -29.5 + k * 2.8; box(x - 0.35, 0.25, -7.6, x + 0.35, 0.38, -6.0, 0xf6f6f6); box(x - 0.35, 0.38, -6.2, x + 0.35, 0.8, -6.0, 0xf6f6f6); solid(x - 0.38, -7.6, x + 0.38, -6.0, 0.8); if (k % 2) { box(x + 0.9, 0, -7, x + 1.0, 2.2, -6.9, 0x8a8f96); box(x - 0.2, 2.2, -8.1, x + 2.1, 2.3, -5.8, [0xfcd116, 0xf6f6f6][k % 2 ? 0 : 1]); } }
    box(-10, 0, -20.5, -6, 1.1, -18.5, 0x8a6440); solid(-10, -20.5, -6, -18.5, 1.2); P(-8, -17.2, 1.3, 'Bar de la piscine (jus, smoothies)', () => this.bar());
    P(-21, -8.6, 1.6, 'Piscine : se baigner', () => this.swim()); P(-24, -5.3, 1.2, 'Transat : bronzer et se reposer', () => this.sunbath());
    // salle de sport (nord-est)
    box(6, 0.001, -22, 22, 0.006, -8, 0x2a2d33); gwall(5.9, -22, 6.1, -8); gwall(6, -8.1, 12, -7.9); gwall(15, -8.1, 22, -7.9);
    for (let k = 0; k < 3; k++) { const x = 8 + k * 2.4; box(x - 0.45, 0, -21.5, x + 0.45, 0.25, -19.7, 0x1a1a1e); box(x - 0.4, 0.25, -21.4, x + 0.4, 1.35, -21.3, 0x8a8f96); solid(x - 0.45, -21.5, x + 0.45, -19.7, 1.3); }
    for (let k = 0; k < 2; k++) { const x = 16 + k * 2.6; box(x - 0.3, 0, -21, x + 0.3, 1.0, -19.6, 0x3a3d42); solid(x - 0.3, -21, x + 0.3, -19.6, 1.0); }
    box(8, 0, -13, 10.5, 0.45, -12, 0x1a1a1e); for (let k = 0; k < 6; k++) box(8.1 + k * 0.4, 0.45, -12.9, 8.35 + k * 0.4, 0.75, -12.1, 0x8a8f96); solid(8, -13, 10.5, -12, 0.8); box(21.9, 0.4, -21, 22, 2.4, -10, 0xc8e0f0, glass);
    P(13.5, -16, 1.8, 'Salle de sport : s’entraîner (1 h)', () => this.gym());
    // spa (est)
    box(24, 0.001, -22, 35, 0.006, -4, 0xc8c0b0); wall(23.9, -22, 24.1, -11, 0xd8d0c0, 3.2); wall(23.9, -7.5, 24.1, -4, 0xd8d0c0, 3.2); wall(24, -4.1, 35, -3.9, 0xd8d0c0, 3.2);
    for (const z of [-20, -16.5]) { box(26, 0, z - 0.4, 28, 0.75, z + 0.4, 0xf6f6f6); solid(26, z - 0.4, 28, z + 0.4, 0.8); }
    box(30.5, 0, -21.6, 34.6, 2.4, -18.2, 0x8a5a32); solid(30.5, -21.6, 34.6, -18.2, 2.4); box(30.5, 0, -15.5, 34.5, 0.6, -11.5, 0xe8e2d6); box(30.8, 0.55, -15.2, 34.2, 0.6, -11.8, 0x6ad8e8, water); solid(30.5, -15.5, 34.5, -11.5, 0.8);
    P(27.8, -9.3, 1.8, 'Spa : massages, sauna, jacuzzi', () => this.spa());
    // ---- aile des chambres (x 37…71), accessible par les ascenseurs ----
    box(37, -0.1, -22, 71, 0, 22, 0x6a5a4a); box(37, 0.001, -22, 41, 0.006, 22, 0x8a1a2a, acc);
    wall(36.8, -22.2, 37, 22.2); wall(37, 22, 71.2, 22.2); wall(37, -22.2, 71.2, -22); wall(71, -22, 71.2, 22);
    box(37, 0, 10, 37.1, 3, 14, 0xc8ccd2); P(38.4, 12, 1.3, 'Ascenseurs : descendre au hall', () => this.lift(false));
    // cloisons des chambres (portes sur le couloir x = 41)
    wall(40.9, -22, 41.1, -13, 0xe8e0d0, 3.2); wall(40.9, -11, 41.1, 3, 0xe8e0d0, 3.2); wall(40.9, 5, 41.1, 15, 0xe8e0d0, 3.2); wall(40.9, 17, 41.1, 22, 0xe8e0d0, 3.2);
    wall(41, 11.4, 71, 11.6, 0xe8e0d0, 3.2); wall(41, -2.6, 71, -2.4, 0xe8e0d0, 3.2); wall(52, 11.6, 52.2, 22, 0xe8e0d0, 3.2); wall(56, -2.4, 56.2, 11.4, 0xe8e0d0, 3.2);
    box(52.2, 0, 11.6, 71, 3.2, 22, 0x2a2a2e); solid(52.2, 11.6, 71, 22, 3.2); box(56.2, 0, -2.4, 71, 3.2, 11.4, 0x2a2a2e); solid(56.2, -2.4, 71, 11.4, 3.2); // volumes techniques (non accessibles)
    for (const [k, R] of Object.entries(ROOMS)) { const [z0, z1] = R.door; this.doors[k] = solid(40.85, z0, 41.15, z1, 3.2); box(40.88, 0, z0, 40.92, 2.4, z1, 0x5a3a22); P(39.6, (z0 + z1) / 2, 1.2, () => (this.key && this.key.room === k ? `Ouvrir : ${R.name} n° ${R.num}` : `${R.name} n° ${R.num} (réservée)`), () => this.openDoor(k)); }
    // chambre deluxe (x 41–52, z 11,6–22)
    box(41.1, 0.001, 11.6, 52, 0.006, 22, 0xc8b89a); box(46, 0, 18.5, 50.5, 0.55, 21.8, 0xf6f4ee); box(46, 0.55, 21.5, 50.5, 1.4, 21.8, 0x5a3a22); box(46.5, 0.55, 18.5, 50, 0.6, 19.6, 0x8a1a2a, acc); solid(46, 18.5, 50.5, 21.8, 0.7);
    box(43, 1.2, 11.8, 45.5, 2.6, 11.85, 0x0a0a0c); box(43.1, 1.3, 11.86, 45.4, 2.5, 11.87, 0x16324a, glow); box(49, 0, 11.8, 51.8, 0.8, 12.6, 0x5a3a22); solid(49, 11.8, 51.8, 12.6, 0.8);
    P(47.5, 17.3, 1.3, 'Lit : dormir', () => this.sleep()); P(44.3, 13.4, 1.1, 'Télévision', () => this.tv()); P(50.4, 13.8, 1.1, 'Service en chambre et minibar', () => this.roomService());
    // suite junior (x 41–56, z −2,4–11,4)
    box(41.1, 0.001, -2.4, 56, 0.006, 11.4, 0xb8a888); wall(48.5, -2.4, 48.7, 3.5, 0xe8e0d0, 3.2); wall(48.5, 6.5, 48.7, 11.4, 0xe8e0d0, 3.2);
    sofa(42.5, 8.4, 46.5, 9.4, 0xece6dc, 's'); box(43.5, 0.4, 6.4, 45.5, 0.45, 7.4, 0x3a2416); solid(43.5, 6.4, 45.5, 7.4, 0.5); box(41.3, 1.2, 1.2, 41.35, 2.6, 4.4, 0x0a0a0c);
    box(51, 0, 5, 55.8, 0.55, 10.8, 0xf6f4ee); box(55.5, 0.55, 5, 55.8, 1.5, 10.8, 0x5a3a22); box(51.5, 0.55, 5.5, 53.5, 0.6, 10.3, 0x8a1a2a, acc); solid(51, 5, 55.8, 10.8, 0.7);
    box(51, 0, -2.2, 55.8, 0.6, 0.6, 0xf2f2f2); box(51.3, 0.5, -1.9, 55.5, 0.55, 0.3, 0x6ad8e8, water); solid(51, -2.2, 55.8, 0.6, 0.7);
    P(44.5, 5.4, 1.2, 'Salon de la suite : se détendre', () => this.relax()); P(52, 4.1, 1.2, 'Lit king size : dormir', () => this.sleep()); P(53, 1.5, 1.1, 'Baignoire : prendre un bain', () => this.bath()); P(46.8, 1.3, 1.1, 'Service en chambre et minibar', () => this.roomService());
    // suite présidentielle (x 41–71, z −22–−2,6)
    box(41.1, 0.001, -22, 71, 0.006, -2.6, 0xd8ccb0); wall(52, -22, 52.2, -14.5, 0xe8e0d0, 3.2); wall(52, -10.5, 52.2, -2.6, 0xe8e0d0, 3.2); wall(62, -22, 62.2, -14.5, 0xe8e0d0, 3.2); wall(62, -10.5, 62.2, -2.6, 0xe8e0d0, 3.2);
    sofa(42.5, -4.4, 48.5, -3.4, 0xf4f0e6, 's'); sofa(42.2, -9.5, 43.2, -5.5, 0xf4f0e6, 'w'); box(44.5, 0.4, -8, 47.5, 0.45, -6, 0x2a1a12); solid(44.5, -8, 47.5, -6, 0.5);
    box(43, 0.72, -20.5, 49, 0.78, -17.5, 0x2a1a12); solid(43, -20.5, 49, -17.5, 0.8); for (let k = 0; k < 4; k++) for (const z of [-21.2, -16.8]) box(43.6 + k * 1.5, 0, z - 0.25, 44.1 + k * 1.5, 0.95, z + 0.25, 0x6a1a2a);
    box(41.2, 1.2, -16, 41.25, 3.0, -9, 0x0a0a0c); box(41.26, 1.3, -15.9, 41.27, 2.9, -9.1, 0x16324a, glow);
    box(53.5, 0.72, -21.6, 57.5, 0.78, -19.8, 0x3a2416); solid(53.5, -21.6, 57.5, -19.8, 0.8); box(55, 0, -19.2, 56, 1.1, -18.4, 0x1a1a1e);
    box(56, 0, -9, 61.8, 0.6, -2.8, 0xf6f4ee); box(56, 0.6, -3.1, 61.8, 1.6, -2.8, 0x5a3a22); box(56.5, 0.6, -8.5, 61.3, 0.66, -5.5, 0x8a1a2a, acc); solid(56, -9, 61.8, -2.8, 0.8);
    box(63, 0, -21.5, 70.5, 0.6, -15, 0xe8e2d6); box(63.4, 0.5, -21.1, 70.1, 0.56, -15.4, 0x2a9ad8, water); solid(63, -21.5, 70.5, -15, 1.0);
    box(64, 0, -6, 70.5, 0.6, -3, 0xf2f2f2); box(64.3, 0.5, -5.7, 70.2, 0.55, -3.3, 0x6ad8e8, water); solid(64, -6, 70.5, -3, 0.7);
    P(45.5, -10.5, 1.4, 'Grand salon : se détendre', () => this.relax()); P(46, -15.5, 1.4, 'Salle à manger privée : dîner servi', () => this.roomService(true));
    P(55.5, -17.4, 1.2, 'Bureau : NOVA Gestion', () => this.bizUI && this.bizUI.toggle(true)); P(58.9, -10.6, 1.3, 'Lit king size : dormir', () => this.sleep());
    P(66.7, -13.4, 1.4, 'Piscine privée de la terrasse : se baigner', () => this.swim(true)); P(67.2, -7.5, 1.3, 'Jacuzzi de la salle de bain', () => this.bath());
    const mk = (arr, m) => { if (!arr.length) return null; const ms = new THREE.Mesh(mergeGeometries(arr), m); ms.receiveShadow = true; g.add(ms); return ms; };
    mk(parts, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.5 })); mk(glass, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.05, metalness: 0.2, transparent: true, opacity: 0.3, depthWrite: false }));
    mk(glow, new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false })); mk(water, new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false, transparent: true, opacity: 0.85 }));
    this.accMat = new THREE.MeshStandardMaterial({ color: 0x8a1a2a, roughness: 0.6 }); mk(acc, this.accMat); // éléments aux couleurs de l'hôtel
  }
  // ------------------------------------------------------------------ entrer / sortir, ascenseur
  enter(H) {
    const { Y, LV, O } = HI, pl = this.player; this.inside = H.id; this.ig.visible = true; this.world.collision.level = LV; pl.floorY = Y; pl.vy = 0;
    pl.pos.set(O.x, Y, O.z + 19.5); pl.facing = PI; pl.mesh.position.copy(pl.pos); if (this.tpc) { this.tpc.yaw = 0; this.tpc.snap && this.tpc.snap(pl.pos); }
    this.accMat.color.set(H.c1); if (this.sign) this.ig.remove(this.sign); this.sign = this.label(H.name, `${'★'.repeat(H.stars)} • hôtel fictif`, 6.8, 1.1, H.c1, H.c2); this.sign.position.set(this.recSign.x, this.recSign.y, this.recSign.z); this.ig.add(this.sign);
    for (const k of Object.keys(ROOMS)) this.doors[k].disabled = false; this.spawn(H);
    const r = this.myRes(H.id); this.ui.toast(`🏨 Bienvenue au ${H.name} (${H.town}, hôtel ${H.stars} étoiles fictif).${r ? ` Ta réservation : ${ROOMS[r.room].name}, ${r.nights} nuit${r.nights > 1 ? 's' : ''}.` : ' Réception à droite du hall.'}`, 4); if (this.audio && this.audio.ctx) this.audio.door();
  }
  exit() {
    const H = HBY[this.inside], pl = this.player; this.leaveInside(); if (!H) return;
    pl.pos.set(H.doorPt.x + H.face.nx * 1.6, 0, H.doorPt.z + H.face.nz * 1.6); pl.floorY = 0; pl.facing = Math.atan2(H.face.nx, H.face.nz); pl.mesh.position.copy(pl.pos); if (this.tpc && this.tpc.snap) this.tpc.snap(pl.pos); this.ui.toast(`Tu sors du ${H.short}.`, 1.5);
  }
  leaveInside() { this.inside = null; this.ig.visible = false; this.world.collision.level = 0; this.player.floorY = 0; this.clearPeople(); this.key = null; if (this.T) this.T.lightOff(); }
  lift(up) {
    const H = HBY[this.inside]; if (!H) return; const pl = this.player, { O, Y } = HI;
    if (up && !this.key && !this.myRes(H.id, true)) return this.ui.toast('🛗 Ascenseurs réservés aux clients : réserve ou présente-toi à la réception pour obtenir ta clé.', 3);
    this.ui.fade && this.ui.fade(true); setTimeout(() => { if (up) pl.pos.set(O.x + 38.6, Y, O.z + 12); else pl.pos.set(O.x + 33, Y, O.z + 12); pl.facing = up ? PI / 2 : -PI / 2; pl.mesh.position.copy(pl.pos); if (this.tpc && this.tpc.snap) this.tpc.snap(pl.pos); this.ui.fade && this.ui.fade(false); this.ui.toast(up ? `🛗 Étage des chambres.${this.key ? ` Ta ${ROOMS[this.key.room].name} : n° ${ROOMS[this.key.room].num}.` : ''}` : '🛗 Hall de l’hôtel.', 2.5); }, 500);
  }
  openDoor(k) { if (!this.key || this.key.room !== k) return this.ui.toast(`🔒 ${ROOMS[k].name} n° ${ROOMS[k].num} : réservée à d’autres clients.`, 2.5); this.doors[k].disabled = true; this.ui.toast(`🔑 Porte n° ${ROOMS[k].num} ouverte.`, 1.8); if (this.audio && this.audio.ctx) this.audio.door(); }
  // ------------------------------------------------------------------ réservations
  myRes(hid, active) { return this.res.find((r) => r.hotel === hid && (r.state === 'en cours' || (!active && r.state === 'réservée'))); }
  book(hid, room, nights, where) {
    const H = HBY[hid]; if (!H || !ROOMS[room]) return null; if (this.res.some((r) => ['réservée', 'en cours'].includes(r.state) && r.hotel === hid)) return this.ui.toast('Tu as déjà une réservation dans cet hôtel.', 2.5), null;
    const price = H.price[room] * nights; if (!this.economy.pay(price, `${H.short} : ${ROOMS[room].name}, ${nights} nuit${nights > 1 ? 's' : ''}`, H.name)) return this.ui.toast('Solde insuffisant.', 2), null;
    const r = { ref: `HT${String(this.seq++).padStart(4, '0')}`, hotel: hid, room, nights, left: nights, price, state: 'réservée', made: this.economy.stamp(), day: this.day() };
    this.res.unshift(r); this.res.length = Math.min(this.res.length, 30); this.T.spend('Hôtels', price, `${H.short} — ${ROOMS[room].name}`);
    this.ui.toast(`🏨 Réservation ${r.ref} : ${ROOMS[room].name} au ${H.name}, ${nights} nuit${nights > 1 ? 's' : ''} (petit-déjeuner, piscine, salle de sport inclus). Présente-toi à la réception.`, 5.5); this.save(); return r;
  }
  cancel(r) { if (r.state !== 'réservée') return; const back = Math.round(r.price * 0.8); r.state = 'annulée'; this.economy.earn(back, `Annulation ${r.ref} (80 % remboursés)`, HBY[r.hotel].name); this.T.spend('Remboursements', -back, `Annulation ${r.ref}`); this.ui.toast(`Réservation ${r.ref} annulée : ${fcfa(back)} remboursés.`, 3); this.save(); }
  reception() {
    const H = HBY[this.inside]; if (!H) return; const r = this.myRes(H.id), items = [];
    if (r && r.state === 'réservée') items.push({ label: `🔑 Arrivée : ${ROOMS[r.room].name} (${r.nights} nuit${r.nights > 1 ? 's' : ''})`, desc: `Réservation ${r.ref} • clé remise`, action: () => this.checkin(r) });
    if (r && r.state === 'en cours') { items.push({ label: `🔑 Ma clé : ${ROOMS[r.room].name} n° ${ROOMS[r.room].num}`, desc: `${r.left} nuit${r.left > 1 ? 's' : ''} restante${r.left > 1 ? 's' : ''}`, action: () => { this.key = { room: r.room, ref: r.ref }; this.ui.toast('🔑 Voici ta clé. Ascenseurs à droite du bar.', 2.5); } });
      items.push({ label: '➕ Prolonger d’une nuit', desc: fcfa(H.price[r.room]), action: () => { if (!this.economy.pay(H.price[r.room], `${H.short} : nuit supplémentaire`, H.name)) return; r.nights++; r.left++; r.price += H.price[r.room]; this.T.spend('Hôtels', H.price[r.room], `${H.short} — nuit supplémentaire`); this.ui.toast('Séjour prolongé d’une nuit.', 2); this.save(); } });
      items.push({ label: '🧳 Départ (libérer la chambre)', action: () => this.checkout(r) }); }
    if (!r) for (const k of Object.keys(ROOMS)) items.push({ label: `🛏️ ${ROOMS[k].name} — 1 nuit`, desc: `${fcfa(H.price[k])} • petit-déjeuner et équipements inclus`, action: () => { const nr = this.book(H.id, k, 1, 'Réception'); if (nr) this.checkin(nr); } });
    if (!r && !this.passOk(H.id)) items.push({ label: '🏊 Pass journée (piscine, salle de sport)', desc: fcfa(DAY_PASS), action: () => { if (!this.economy.pay(DAY_PASS, `${H.short} : pass journée`, H.name)) return; this.passes[H.id] = this.day(); this.T.spend('Hôtels', DAY_PASS, `${H.short} — pass journée`); this.ui.toast('🏊 Pass journée activé : piscine et salle de sport.', 2.5); this.save(); } });
    this.ui.openMenu(`🛎️ Réception — ${H.name}`, `Hôtel ${H.stars} étoiles fictif • ${H.town} • tarifs par nuit (monnaie virtuelle)`, items);
  }
  checkin(r) { r.state = 'en cours'; this.key = { room: r.room, ref: r.ref }; const H = HBY[r.hotel]; this.ui.toast(`🔑 Bienvenue ! ${ROOMS[r.room].name} n° ${ROOMS[r.room].num}. Le bagagiste monte tes valises. Petit-déjeuner servi de 6 h à 10 h 30.`, 4.5); this.save(); return H; }
  checkout(r) { r.state = 'terminée'; r.out = this.economy.stamp(); this.key = null; for (const k of Object.keys(ROOMS)) if (this.doors[k]) this.doors[k].disabled = false; this.ui.toast(`🧳 Départ enregistré : merci de ton séjour au ${HBY[r.hotel].name} !`, 3); this.save(); }
  guest() { const r = this.inside && this.myRes(this.inside, true); return r || null; }
  passOk(hid) { return this.passes[hid] === this.day(); }
  access(what) { if (this.guest() || this.passOk(this.inside)) return true; this.ui.toast(`${what} : réservé aux clients de l’hôtel ou avec le pass journée (réception, ${fcfa(DAY_PASS)}).`, 3); return false; }
  // ------------------------------------------------------------------ services
  passTime(h, msg, fx = {}) {
    this.ui.fade && this.ui.fade(true);
    setTimeout(() => { this.env.time = (this.env.time + h) % 24; if (this.economy.update) this.economy.update(0); const n = this.needs; if (n) for (const [k, v] of Object.entries(fx)) n[k] = Math.max(0, Math.min(100, (n[k] || 0) + v)); this.ui.fade && this.ui.fade(false); this.ui.toast(msg, 3); }, 550);
  }
  relax() { this.passTime(0.5, '😌 Un moment de détente dans un fauteuil moelleux.', { energy: 8 }); }
  bar() { this.ui.openMenu('🍹 Bar', 'Boissons sans alcool', [['Cocktail Lagune (ananas, gingembre, citron vert)', 6000], ['Jus de bissap glacé', 3500], ['Smoothie mangue-passion', 5000], ['Café et mignardises', 4000]].map(([n, p]) => ({ label: n, desc: fcfa(p), action: () => { if (!this.economy.pay(p, n, HBY[this.inside].name)) return; if (this.needs) this.needs.hunger = Math.min(100, this.needs.hunger + 8); this.T.spend('Hôtels', p, n); this.ui.toast(`🍹 ${n} servi. Santé !`, 2); } }))); }
  restaurant() { const H = HBY[this.inside]; this.ui.openMenu(`🍽️ Restaurant gastronomique — ${H.short}`, 'Cuisine béninoise et internationale (carte fictive)', MENU.map(([n, p, f]) => ({ label: n, desc: fcfa(p), action: () => { if (!this.economy.pay(p, n, H.name)) return; this.T.spend('Hôtels', p, n); this.passTime(0.6, `🍽️ ${n} : un délice, servi avec élégance.`, { hunger: f }); } }))); }
  breakfast() { const t = this.env.time; if (!(t >= 6 && t <= 10.5)) return this.ui.toast('🥐 Petit-déjeuner servi de 6 h à 10 h 30.', 2.5); if (!this.guest()) return this.ui.toast('🥐 Buffet réservé aux clients de l’hôtel (inclus dans la nuit).', 2.5); this.passTime(0.4, '🥐 Buffet : fruits frais, bouillie, akassa, omelette, pain, jus d’orange (inclus).', { hunger: 45 }); }
  swim(priv) { if (!priv && !this.access('🏊 Piscine')) return; this.passTime(0.75, priv ? '🏊 Baignade dans la piscine privée de ta suite, vue sur la ville.' : '🏊 Quelques longueurs dans la piscine de l’hôtel : rafraîchissant !', { energy: -5, hygiene: 10 }); }
  sunbath() { if (!this.access('🏖️ Transats')) return; this.passTime(1, '🏖️ Une heure de repos au bord de la piscine.', { energy: 12 }); }
  gym() { if (!this.access('🏋️ Salle de sport')) return; this.passTime(1, '🏋️ Séance de sport avec le coach : cardio et renforcement. Belle forme !', { energy: -15, hunger: -10, hygiene: -15 }); }
  spa() { const H = HBY[this.inside]; this.ui.openMenu(`💆 Spa — ${H.short}`, 'Soins du spa (prix fictifs)', SPA.map(([n, p, h, fx]) => ({ label: n, desc: fcfa(p), action: () => { if (!this.economy.pay(p, n, H.name)) return; this.T.spend('Hôtels', p, n); this.passTime(h, `💆 ${n} : tu te sens parfaitement détendu.`, fx); } }))); }
  concierge() { const H = HBY[this.inside]; this.ui.openMenu('🎩 Conciergerie', `${H.name}`, [
    { label: '🚘 Appeler mon chauffeur', action: () => this.ui.toast(this.driver ? 'Ton chauffeur t’attend devant l’entrée (téléphone, application Chauffeur).' : 'Service de chauffeur non disponible.', 3) },
    { label: '🗺️ Excursions et visites', action: () => this.ui.toast('🗺️ Les visites touristiques du Bénin seront proposées à la prochaine étape (plages, sites historiques, marchés).', 3.5) },
    { label: '✈️ NOVA TRAVEL : vols et hôtels', action: () => { this.T.view = 'hotels'; this.T.openApp('hotels'); } } ]); }
  roomService(dinner) { this.ui.openMenu(dinner ? '🍽️ Dîner privé servi en suite' : '🛎️ Service en chambre', 'Livré par le personnel de l’hôtel', MENU.map(([n, p, f]) => ({ label: n, desc: fcfa(Math.round(p * 1.15)), action: () => { const q = Math.round(p * 1.15); if (!this.economy.pay(q, `Service en chambre : ${n}`, HBY[this.inside].name)) return; this.T.spend('Hôtels', q, n); this.passTime(0.6, `🛎️ On frappe : « Service en chambre ! » ${n} servi.`, { hunger: f }); } })).concat([{ label: '🧃 Minibar : jus de fruits et eau (inclus)', action: () => { if (this.needs) this.needs.hunger = Math.min(100, this.needs.hunger + 5); this.ui.toast('🧃 Jus de fruits frais du minibar.', 2); } }])); }
  tv() { this.passTime(1, '📺 Une heure de télévision dans ta chambre.', { energy: 5 }); }
  bath() { this.passTime(0.5, '🛁 Bain relaxant : propreté 100 %.', { hygiene: 100, energy: 10 }); }
  sleep() {
    const r = this.guest(); if (!r) return this.ui.toast('Lit réservé aux clients de la chambre.', 2);
    const t = this.env.time; if (!(t >= 18 || t < 5)) return this.passTime(2, '😴 Sieste de 2 heures dans un lit douillet.', { energy: 35 });
    if (r.left <= 0) return this.ui.toast('Ton séjour est terminé : prolonge à la réception pour dormir une nuit de plus.', 3);
    const hrs = t >= 18 ? 31 - t : 7 - t; r.left--; this.save();
    this.passTime(hrs, `☀️ Bonjour ! Il est 07:00. Bonne nuit au ${HBY[r.hotel].short}.${r.left ? ` Encore ${r.left} nuit${r.left > 1 ? 's' : ''}.` : ' Dernière nuit : départ avant midi à la réception.'}`, { energy: 100, hunger: -hrs * 1.2 });
  }
  // ------------------------------------------------------------------ personnel et clients
  clearPeople() { for (const p of this.people) p.c.group.parent && p.c.group.parent.remove(p.c.group); this.people = []; }
  spawn(H) {
    this.clearPeople(); const c1 = new THREE.Color(H.c1).getHex();
    const add = (o, d) => { const c = createCharacter({ skin: pick(SKINS), ...o }); this.ig.add(c.group); const p = { c, ...d }; c.group.position.set(p.x, 0, p.z); c.group.rotation.y = p.h || 0; this.people.push(p); return p; };
    const staff = (x, z, h, role, name, o = {}) => add({ shirtColor: c1, jacket: true, collar: true, pants: 0x1a1d24, ...o }, { x, z, h, role, name, staff: true });
    staff(11.5, 8.3, 0, 'rec', 'Mme Aurore Houéto, réceptionniste', { female: true, skirt: true }); staff(14.5, 8.3, 0, 'rec', 'M. Cyrille Dègbé, réceptionniste');
    staff(19.5, 1.4, 0, 'conc', 'M. Hubert Kpossou, concierge', { hat: 'cap', hatColor: c1 }); staff(4, 19.6, PI, 'groom', 'Bagagiste Jules', { hat: 'cap', hatColor: 0xd8a830 });
    staff(26.5, 20, PI, 'bar', 'Barman Nestor', { shirtColor: 0xf6f6f6 }); staff(-31.4, 13.2, PI, 'chef', 'Chef Gisèle Agbo', { female: true, shirtColor: 0xffffff, jacket: false, hat: 'cap', hatColor: 0xffffff });
    staff(-22, 4.4, 0, 'serveur', 'Serveur Arsène', { shirtColor: 0x1a1a1a }); staff(-8, -16.5, 0, 'bar', 'Serveuse Mireille (piscine)', { female: true, shirtColor: 0xf6f6f6 }); staff(-11, -8.6, 0, 'mns', 'Maître-nageur Ignace', { shirtColor: 0xe8112d, jacket: false, collar: false });
    staff(13.5, -18.5, 0, 'coach', 'Coach Sylvain', { shirtColor: 0x1a1a1e, jacket: false }); staff(29, -18, -PI / 2, 'spa', 'Mme Bénédicte, praticienne du spa', { female: true, shirtColor: 0xf6f6f6, jacket: false }); staff(33.4, 16.2, -PI / 2, 'secu', 'Agent de sécurité Basile', { shirtColor: 0x1a2a44 });
    staff(39, -6, 0, 'menage', 'Femme de chambre Rosine', { female: true, shirtColor: 0xd8dde2, jacket: false });
    // clients : assis au restaurant, aux salons, sur les transats ; d'autres se promènent dans le hall
    const guestO = () => ({ female: Math.random() < 0.5, shirtColor: pick([0xf6f6f6, 0x1a1a1e, 0x6a1a2a, 0xfcd116, 0x2f80ed, 0x0b6e4f]), pants: pick([0x1f2a44, 0x2a2d33, 0xd8c8a8]), headwrap: Math.random() < 0.2 });
    for (const [x, z, h] of [[-30, 5.45, 0], [-25.6, 7.55, PI], [-21.2, 11.45, 0], [-16.8, 13.55, PI], [8, 12.45, PI], [-8, 16.05, 0]]) { const p = add(guestO(), { x, z, h, name: 'Client de l’hôtel', seat: true }); p.c.sit(false); p.c.group.position.y = -0.05; }
    for (const x of [-26.7, -21.1, -15.5]) { const p = add({ ...guestO(), shirtColor: pick([0x2f80ed, 0xe8112d, 0xfcd116]) }, { x, z: -6.9, h: PI, name: 'Client au bord de la piscine', seat: true }); p.c.sit(false); p.c.group.position.y = -0.12; }
    const lanes = [[[-11, 6], [22, 6]], [[-11, 6], [-11, 19]], [[-30, -5.4], [-6.5, -5.4]], [[24, 6], [24, 15]]];
    for (let i = 0; i < 6; i++) { const L = lanes[i % lanes.length], t = Math.random(); add(guestO(), { x: L[0][0] + (L[1][0] - L[0][0]) * t, z: L[0][1] + (L[1][1] - L[0][1]) * t, name: 'Client de l’hôtel', lane: L, dir: Math.random() < 0.5 ? 0 : 1, speed: 0.9 + Math.random() * 0.3, wait: 0 }); }
  }
  talk(p) {
    const L = { rec: 'Bienvenue ! Puis-je vous aider pour votre réservation ?', conc: 'Je peux organiser votre chauffeur ou vos sorties. À votre service.', groom: 'Je m’occupe de vos bagages, monsieur.', bar: 'Un cocktail de fruits frais, sans alcool ?', chef: 'Ce soir : capitaine grillé et sauce moyo, produits du marché.', serveur: 'Une table pour vous ? Je vous apporte la carte.', mns: 'L’eau est à 28 °C. Profitez bien, je surveille le bassin.', coach: 'On commence par 10 minutes de vélo pour s’échauffer ?', spa: 'Massage relaxant ou soin du visage ? Le spa vous attend.', secu: 'Bonne journée, tout est calme.', menage: 'Votre chambre sera prête dans un instant.' };
    this.ui.toast(`${p.name} : « ${L[p.role] || pick(['Bonjour !', 'Superbe hôtel, n’est-ce pas ?', 'Je suis en voyage d’affaires.', 'La piscine est magnifique.'])} »`, 3.5);
  }
  nearest(x, z) {
    if (!this.inside) { if (this.player.floorY > 1) return null; let best = null; for (const H of HOTELS) { if (!H.doorPt) continue; const d = Math.hypot(x - H.doorPt.x, z - H.doorPt.z); if (d < 2.4 && (!best || d < best.d)) best = { d, it: { label: () => `🏨 Entrer : ${H.name}`, action: () => this.enter(H) } }; } return best; }
    const O = HI.O; let best = null;
    for (const p of this.points) { const d = Math.hypot(x - (O.x + p.x), z - (O.z + p.z)); if (d < p.r && (!best || d < best.d)) best = { d, it: { label: () => (typeof p.label === 'function' ? p.label() : p.label), action: p.action } }; }
    for (const p of this.people) { const d = Math.hypot(x - (O.x + p.x), z - (O.z + p.z)); if (d < 1.3 && (!best || d < best.d - 0.2)) best = { d, it: { label: () => `Parler à ${p.name}`, action: () => this.talk(p) } }; }
    return best;
  }
  zoneLabel() {
    if (!this.inside) return null; const H = HBY[this.inside], P = this.player.pos, x = P.x - HI.O.x, z = P.z - HI.O.z;
    const zn = x > 36 ? (x < 41 ? 'étage des chambres' : z > 11.5 && x < 52 ? 'chambre deluxe' : z > -2.5 && z < 11.5 && x > 41 ? 'suite junior' : z < -2.5 && x > 41 ? 'suite présidentielle' : 'étage des chambres') : x < -14 && z > 2 ? 'restaurant' : x < -4 && z < -4 ? 'piscine' : x > 6 && x < 22 && z < -8 ? 'salle de sport' : x > 24 && z < -4 ? 'spa' : 'hall';
    return `${H.short} — ${zn}`;
  }
  update(dt) {
    this._ck = (this._ck || 0) - dt; if (this._ck < 0) { this._ck = 4; for (const r of this.res) if (r.state === 'en cours' && r.left <= 0 && this.env.time >= 12 && this.env.time < 18 && r.day !== this.day()) { this.checkout(r); } }
    if (!this.inside) return; const P = this.player.pos;
    if (Math.abs((P.y || HI.Y) - HI.Y) > 6 || Math.hypot(P.x - HI.O.x - 18, P.z - HI.O.z) > 70) { this.leaveInside(); return; }
    const ls = this.home && this.home.lights; if (ls) { if (this.T && !this.T._orig) this.T._orig = ls.map((l) => ({ p: l.position.clone(), d: l.distance })); ls.forEach((l, i) => { l.position.set(P.x - 7 + i * 7, HI.Y + 4.5, P.z + (i === 1 ? 4 : -3)); l.distance = 20; l.decay = 1.2; l.intensity = 3.2; l.color.setHex(0xfff0d8); }); }
    for (const p of this.people) {
      if (!p.lane) { if (!p.seat) p.c.animate(dt, 0); continue; }
      if (p.wait > 0) { p.wait -= dt; p.c.animate(dt, 0); continue; }
      const [tx, tz] = p.lane[p.dir], dx = tx - p.x, dz = tz - p.z, d = Math.hypot(dx, dz);
      if (d < 0.15) { p.dir = 1 - p.dir; p.wait = 1.5 + Math.random() * 4; continue; }
      const s = Math.min(d, p.speed * dt); p.x += dx / d * s; p.z += dz / d * s; p.h = Math.atan2(dx, dz); p.c.group.position.set(p.x, 0, p.z); p.c.group.rotation.y = p.h; p.c.animate(dt, p.speed);
    }
  }
  // ------------------------------------------------------------------ application NOVA TRAVEL, onglet « Hôtels »
  renderApp() {
    const S = this.sel, H = HBY[S.h]; let h = '<p class="ph-note">Hôtels FICTIFS installés dans des bâtiments du jeu (Cotonou, Porto-Novo, Ouidah) ; tarifs par nuit en monnaie virtuelle. Petit-déjeuner, piscine et salle de sport inclus.</p>';
    h += `<div class="ph-chips">${HOTELS.map((q) => `<button data-tr="htl:h:${q.id}" class="${q.id === S.h ? 'on' : ''}">${q.short}</button>`).join('')}</div>`;
    h += `<div class="ph-row"><span><b>${esc(H.name)} ${'★'.repeat(H.stars)}</b><small>${H.town} • réception, restaurant gastronomique, piscine, salle de sport, spa, bar, parking</small></span>${H.doorPt && this.driver ? `<button class="ph-mini" data-tr="htl:go:${H.id}">🚘 Y aller</button>` : ''}</div>`;
    h += `<p class="ph-note"><b>Chambre</b></p><div class="ph-chips">${Object.entries(ROOMS).map(([k, R]) => `<button data-tr="htl:room:${k}" class="${S.room === k ? 'on' : ''}">${R.name} • ${fcfa(H.price[k])}</button>`).join('')}</div>`;
    h += `<p class="ph-note"><b>Nuits</b></p><div class="ph-chips">${[1, 2, 3, 5, 7].map((n) => `<button data-tr="htl:n:${n}" class="${S.n === n ? 'on' : ''}">${n}</button>`).join('')}</div>`;
    h += `<div class="ph-row"><span><b>Total : ${fcfa(H.price[S.room] * S.n)}</b><small>${ROOMS[S.room].name} • ${S.n} nuit${S.n > 1 ? 's' : ''} à partir d’aujourd’hui</small></span><button class="ph-mini" data-tr="htl:pay:1">Réserver</button></div>`;
    h += `<h5>Mes réservations d’hôtel</h5>${this.res.slice(0, 12).map((r) => `<div class="ph-row"><span><b>${esc(HBY[r.hotel].short)} • ${ROOMS[r.room].name}</b><small>${r.ref} • ${r.nights} nuit${r.nights > 1 ? 's' : ''}${r.state === 'en cours' ? ` (reste ${r.left})` : ''} • ${fcfa(r.price)} • ${r.made}</small></span><em>${r.state}</em>${r.state === 'réservée' ? `<button class="ph-mini" data-tr="htl:cancel:${r.ref}">Annuler (−20 %)</button>` : ''}</div>`).join('') || '<p class="ph-note">Aucune réservation.</p>'}`;
    return h;
  }
  onPhone(a, b) {
    const S = this.sel;
    if (a === 'h' && HBY[b]) S.h = b; else if (a === 'room' && ROOMS[b]) S.room = b; else if (a === 'n') S.n = +b || 1;
    else if (a === 'pay') this.book(S.h, S.room, S.n, 'NOVA TRAVEL');
    else if (a === 'cancel') { const r = this.res.find((q) => q.ref === b); if (r) this.cancel(r); }
    else if (a === 'go' && this.driver) { const H = HBY[b]; this.economy.togglePhone(false); this.driver.toDest({ id: `hotel_${H.id}`, label: H.name, x: H.doorPt.x + H.face.nx * 3, z: H.doorPt.z + H.face.nz * 3 }); return false; }
    return true;
  }
  serialize() { return { res: this.res, seq: this.seq, passes: this.passes }; }
  restore(s) { if (!s) return; this.res = s.res || []; this.seq = s.seq || 1; this.passes = s.passes || {}; }
}
