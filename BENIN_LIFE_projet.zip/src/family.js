// Mission 019, étape 6 — adoption fictive et responsable, puis vie familiale à la VILLA NOVA (application « Vie familiale »).
// L'adoption n'est JAMAIS un achat : aucune étape n'est payante, les dons au centre n'ont aucune influence, et l'intérêt de
// l'enfant passe avant tout. Démarche encadrée par la responsable de la protection de l'enfance du centre NOVA SOLIDARITÉ
// (personnage fictif) : réunion d'information, présentation d'un enfant par l'équipe (pas de « choix sur catalogue »),
// rencontres adaptées au rythme de l'enfant, évaluation de la famille, visite du domicile, validation (avec l'accord de
// l'enfant), intégration progressive (journée, week-end, arrivée). L'enfant peut avoir besoin de plus de temps, ou dire
// non : sa parole est respectée. Ensuite : chambre à lui/elle dans la villa, journée rythmée (repas, devoirs, jeux,
// coucher), moments partagés, indicateurs de bien-être, journal de famille, messages pour les plus grands.
import * as THREE from 'three';
import { createCharacter, SKINS } from './character.js';
import { fcfa } from './food-data.js';
import { VILLA, POOL } from './villa.js';
import { LEVELS } from './orphanage.js';
import { TOWNS } from './region-geo.js';

const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const pick = (a) => a[Math.floor(Math.random() * a.length)];
const clamp = (v) => Math.max(0, Math.min(100, v));
export const STEPS = [
  ['info', 'Réunion d’information'], ['pres', 'Présentation d’un enfant par l’équipe'], ['renc', 'Rencontres adaptées'], ['eval', 'Évaluation de la famille'],
  ['dom', 'Visite du domicile'], ['valid', 'Validation par la protection de l’enfance'], ['integ', 'Intégration progressive'],
];
const KID_ROOMS = ['enf1', 'enf2', 'enf3'];
const INTEG = [['journee', 'Journée d’accueil à la villa (10 h – 17 h)', 10, 17], ['weekend', 'Week-end à la villa (15 h → lendemain 11 h)', 15, 35], ['arrivee', 'Arrivée définitive (10 h)', 10, 10]];
const MEETS = [
  [['Faire connaissance à la bibliothèque', 'parler'], ['Dessiner ensemble', 'dessin'], ['Lire une histoire ensemble', 'lecture']],
  [['Jouer à son jeu préféré', 'jeu'], ['L’aider pour ses devoirs', 'math'], ['Un petit match dans la cour', 'football']],
  [['Goûter ensemble (jus de bissap et beignets)', 'gouter'], ['Lui montrer un album photo de la villa et de sa future chambre', 'album'], ['Parler de ses rêves et de l’avenir', 'avenir']],
];
const EVALQ = [
  ['Pourquoi souhaitez-vous accueillir un enfant ?', [['Pour lui offrir un foyer stable, de l’attention et de l’affection.', 2], ['Pour avoir quelqu’un à qui transmettre mon entreprise.', 0, 'On n’accueille pas un enfant pour soi ou pour une succession : il a ses propres rêves.'], ['Pour mon image publique.', 0, 'L’image publique ne doit jamais entrer en compte.']]],
  ['Comment organiserez-vous votre temps ?', [['Je réserve mes soirées et mes week-ends à la famille, et j’allège mon agenda.', 2], ['Le personnel de maison s’en occupera.', 1, 'Le personnel aide, mais un enfant a besoin de la présence de son parent.'], ['Je n’ai pas le temps, mais les moyens suffiront.', 0, 'Les moyens matériels ne remplacent pas la présence.']]],
  ['Comment parlerez-vous de son histoire et de ses origines ?', [['Je respecterai son histoire, son prénom et ses souvenirs, et je répondrai à ses questions.', 2], ['Il vaut mieux ne plus en parler.', 0, 'Son histoire lui appartient : elle doit être respectée.'], ['J’attendrai qu’il ou elle pose des questions.', 1, 'C’est bien d’écouter, mais il faut aussi lui dire qu’on peut en parler.']]],
  ['Comment suivrez-vous sa scolarité et sa santé ?', [['Suivi des devoirs, réunions à l’école, visites chez le médecin : je serai présent·e.', 2], ['Je paierai la meilleure école, ça suffira.', 1, 'Une bonne école aide, mais l’accompagnement compte davantage.'], ['Il ou elle se débrouillera.', 0, 'Un enfant a besoin d’être accompagné.']]],
  ['Si les débuts sont difficiles (colère, tristesse, retrait) ?', [['Patience, écoute, et l’aide de professionnels si besoin.', 2], ['Je serai très strict·e.', 1, 'Des règles, oui, mais avec beaucoup de douceur au début.'], ['Je le ou la ramènerai au centre.', 0, 'Un enfant n’est jamais « rendu » : c’est un engagement pour la vie.']]],
];
const OUTINGS = [
  { id: 'plage', label: '🏖️ Après-midi à la plage', hours: 3, cost: 10000, eff: { bonheur: 10, confiance: 4 }, msg: 'Châteaux de sable et grands éclats de rire au bord de l’océan.' },
  { id: 'glace', label: '🍦 Glace et promenade en ville', hours: 2, cost: 6000, eff: { bonheur: 7, confiance: 3 }, msg: 'Promenade tranquille et glace à la vanille.' },
  { id: 'cinema', label: '🎬 Soirée cinéma à la villa', hours: 2, cost: 0, eff: { bonheur: 6, confiance: 4 }, msg: 'Film d’animation (programme fictif) dans la salle de cinéma, avec du pop-corn.', evening: true },
  { id: 'jeux', label: '🎲 Après-midi jeux de société', hours: 1.5, cost: 0, eff: { bonheur: 5, confiance: 5 }, msg: 'Partie de awalé (adji) puis de dames : on a bien rigolé.' },
  { id: 'cuisine', label: '👩🏿‍🍳 Cuisiner ensemble (avec le cuisinier)', hours: 1.5, cost: 0, eff: { bonheur: 6, sante: 3, confiance: 3 }, msg: 'Préparation de beignets et d’un jus de bissap maison.', cook: true },
];

// cadeaux (achat virtuel ; l'attention compte plus que le cadeau : effet réduit si l'on en offre trop)
export const GIFTS = [
  { id: 'peluche', label: '🧸 Peluche', cost: 5000, min: 3, max: 8, tags: /x^/ }, { id: 'livre', label: '📚 Livres illustrés et contes', cost: 8000, min: 3, max: 13, tags: /lecture|chant/ },
  { id: 'dessin', label: '🎨 Kit de dessin et peinture', cost: 7000, min: 3, max: 15, tags: /dessin/ }, { id: 'ballon', label: '⚽ Ballon de football', cost: 9000, min: 4, max: 18, tags: /football/ },
  { id: 'jeu', label: '🎲 Jeu de société', cost: 12000, min: 5, max: 18, tags: /jeux/ }, { id: 'tenue', label: '👗 Tenue de fête en pagne', cost: 15000, min: 3, max: 18, tags: /danse/ },
  { id: 'djembe', label: '🥁 Petit djembé', cost: 25000, min: 5, max: 18, tags: /musique|chant|danse/ }, { id: 'science', label: '🔬 Coffret de sciences', cost: 30000, min: 8, max: 18, tags: /sciences|math/ },
  { id: 'velo', label: '🚲 Vélo et casque', cost: 75000, min: 5, max: 18, tags: /football|sport/ }, { id: 'tablette', label: '💻 Tablette éducative (contrôle parental)', cost: 90000, min: 7, max: 18, tags: /informatique/ },
];
// vacances en famille dans les villes de la région (hôtels fictifs)
const TRIPS = [
  { town: 'Ouidah', label: 'Ouidah : plage, musées et balade en ville (dans le respect des lieux et des traditions)', night: 60000 },
  { town: 'Porto-Novo', label: 'Porto-Novo : musées, jardin des plantes et marché', night: 55000 },
  { town: 'Pahou', label: 'Pahou : nature, lagune et repos', night: 40000 },
];

export class Family {
  constructor(ctx) {
    Object.assign(this, ctx); // villa, orphanage, cook, staff, kitchen, economy, env, ui, audio, player, events, phonePlus, driver, onSave
    this.proc = null; this.children = []; this.journal = []; this.poolFence = false; this.cooldown = 0; this.view = 'famille'; this.lastDay = null; this.chars = {}; this.officer = null;
  }
  // ------------------------------------------------------------------ outils
  day() { return this.economy.day || 1; }
  abs() { return this.day() * 24 + this.env.time; }
  kid(id) { return this.orphanage.roster.find((k) => k.id === id) || null; }
  kidIdx(id) { return this.orphanage.roster.findIndex((k) => k.id === id); }
  il(k) { return k.female ? 'elle' : 'il'; }
  le(k) { return k.female ? 'la' : 'le'; }
  e(k) { return k.female ? 'e' : ''; }
  log(txt) { this.journal.unshift({ t: this.economy.stamp(), txt }); this.journal.length = Math.min(this.journal.length, 80); }
  freeRoom() { return KID_ROOMS.find((r) => !this.children.some((c) => c.room === r) && !(this.proc && this.proc.room === r)) || null; }
  roomOwner(id) { const c = this.children.find((q) => q.room === id); return c ? c.first : this.proc && this.proc.room === id && this.proc.step === 'integ' ? `${this.kid(this.proc.kidId).first} (bientôt)` : null; }
  isChild(id) { return this.children.some((c) => c.id === id); }
  // l'enfant n'est pas visible au centre s'il vit à la villa ou s'il y passe une période d'intégration
  awayFromCentre(id) { return this.isChild(id) || !!(this.proc && this.proc.kidId === id && this.integWindow()); }
  integWindow() { const p = this.proc; if (!p || p.step !== 'integ' || !p.win) return false; const a = this.abs(); return a >= p.win[0] && a < p.win[1]; }
  officerName() { return 'Mme Carine Zossou'; }
  // ------------------------------------------------------------------ démarche : au centre (responsable de la protection de l'enfance)
  officerItems(s) {
    if (!s.id.startsWith('pro') && s.id !== 'dir') return [];
    const P = this.proc, items = [];
    if (!P) {
      if (this.children.length >= KID_ROOMS.length) return [{ label: '👨‍👩‍👧 Accueillir un enfant', action: () => this.say(s, 'Vos trois chambres d’enfants sont déjà occupées. Prenez le temps de profiter de votre famille.') }];
      items.push({ label: '👨‍👩‍👧 Je souhaite accueillir un enfant (adoption)', action: () => this.infoMeeting(s) });
    } else {
      items.push({ label: '📁 Où en est mon dossier ?', action: () => this.say(s, this.statusText()) });
      if (P.step === 'pres') items.push({ label: `🧒 Revoir la présentation de ${this.kid(P.kidId).first}`, action: () => this.present(s) });
      if (P.step === 'eval') items.push({ label: '📝 Passer l’entretien d’évaluation', action: () => this.evaluation(s) });
      if (P.step === 'dom' && !P.homeDay) items.push({ label: '🏠 Fixer la visite du domicile', action: () => this.bookHome() });
    }
    items.push({ label: '💶 Faut-il payer quelque chose ?', action: () => this.say(s, 'Non, jamais. L’adoption n’est ni un achat ni un échange : aucune somme n’est demandée, à aucune étape. Les dons faits au centre n’ont aucune influence sur une démarche d’adoption.') });
    return items;
  }
  say(s, txt) { this.ui.toast(`${s ? s.name || s : this.officerName()} : « ${txt} »`, Math.min(9, 3 + txt.length / 45)); }
  infoMeeting(s) {
    if (this.day() < this.cooldown) return this.say(s, `Prenons un peu de recul avant une nouvelle démarche. Revenez me voir à partir du jour ${this.cooldown}.`);
    this.ui.openMenu('👨‍👩‍👧 Réunion d’information — adoption (fictive)', 'Une adoption, c’est donner une famille à un enfant, pas l’inverse. Étapes : présentation par l’équipe, rencontres à son rythme, évaluation, visite du domicile, validation avec son accord, intégration progressive. Aucune somme n’est jamais demandée.', [
      { label: 'J’ai compris. Je souhaite ouvrir un dossier.', desc: 'L’équipe vous proposera un enfant dont le profil peut vous convenir', action: () => this.prefMenu(s) },
      { label: 'Et si l’enfant ne se sent pas prêt ?', action: () => this.say(s, 'Alors on attend, ou on arrête. Dès 7 ans, l’enfant donne son avis, et cet avis est respecté. Ce n’est jamais un échec : c’est son intérêt.') },
      { label: 'Je préfère réfléchir encore.', action: () => this.say(s, 'C’est une sage décision. Ma porte reste ouverte.') },
    ]);
  }
  prefMenu(s) {
    const go = (a, b, l) => () => this.open(s, a, b, l);
    this.ui.openMenu('📁 Ouverture du dossier', 'Quel âge d’enfant pensez-vous pouvoir accompagner au mieux ? (L’équipe garde le dernier mot.)', [
      { label: 'Petite enfance (3 – 6 ans)', action: go(3, 6, 'petite enfance') }, { label: 'Enfance (7 – 12 ans)', action: go(7, 12, 'enfance') },
      { label: 'Adolescence (13 – 17 ans)', desc: 'Les grands attendent souvent plus longtemps une famille', action: go(13, 17, 'adolescence') }, { label: 'Je fais confiance à l’équipe', action: go(3, 17, 'sans préférence') },
    ]);
  }
  open(s, a, b, label) {
    const room = this.freeRoom(); if (!room) return this.say(s, 'Il faut une chambre libre à la villa pour accueillir un enfant.');
    const O = this.orphanage, vis = O.roster.slice(0, Math.min(16, O.present)).filter((k) => !this.isChild(k.id) && k.age >= a && k.age <= b);
    const pool = vis.length ? vis : O.roster.slice(0, Math.min(16, O.present)).filter((k) => !this.isChild(k.id));
    if (!pool.length) return this.say(s, 'Aucun enfant n’est en attente d’une famille pour le moment.');
    pool.sort((x, y) => x.since - y.since); const k = pool[Math.floor(Math.random() * Math.min(3, pool.length))]; // l'équipe privilégie les enfants qui attendent depuis longtemps
    this.proc = { step: 'pres', kidId: k.id, pref: label, room, opened: this.day(), meets: 0, lastMeet: null, comfort: 10 + (k.trait.startsWith('joyeu') || k.trait.startsWith('bavard') ? 10 : 0), evalTry: 0, evalAfter: 0, homeDay: null, validDay: null, integ: 0, win: null, hist: [] };
    this.log(`Ouverture d’un dossier d’adoption au centre NOVA SOLIDARITÉ (préférence : ${label}). Chambre prévue : ${this.villa.rooms[room].name}.`);
    this.onSave && this.onSave(); this.present(s);
  }
  present(s) {
    const P = this.proc, k = this.kid(P.kidId);
    this.ui.openMenu(`🧒 Présentation : ${k.first}, ${k.age} ans`, `${LEVELS(k.age)} • ${k.trait} • aime ${k.hobby} • rêve de ${k.dream} • au centre depuis ${k.since}. L’équipe pense que vous pourriez vous convenir. Ce n’est pas un choix sur catalogue : ${k.first} aura son mot à dire.`, [
      { label: `Commencer les rencontres avec ${k.first}`, desc: 'Encadrées par l’équipe, une par jour au maximum', action: () => { P.step = 'renc'; this.log(`Présentation de ${k.first} (${k.age} ans). Début des rencontres.`); this.say(s, `${k.first} sait qu’une personne aimerait ${this.le(k)} rencontrer. Venez lui dire bonjour dans le centre, nous resterons à côté. Une rencontre par jour, pas plus.`); this.onSave && this.onSave(); } },
      { label: 'Je ne me sens pas prêt·e', desc: 'Le dossier est refermé, sans conséquence', action: () => this.stop('Vous avez préféré refermer le dossier. C’est une décision responsable.', 3) },
    ]);
  }
  stop(msg, days = 7) { const P = this.proc; if (!P) return; const k = this.kid(P.kidId); this.proc = null; this.cooldown = this.day() + days; this.log(`Démarche arrêtée (${k ? k.first : ''}) : ${msg}`); this.ui.toast(`📁 ${msg}`, 4); this.onSave && this.onSave(); }
  // rencontres : depuis le menu de l'enfant au centre
  kidItems(K) {
    const P = this.proc; if (!P || P.kidId !== K.k.id || P.step !== 'renc') return [];
    const ok = this.env.time >= 9 && this.env.time < 19 && this.orphanage.schedule().where !== 'dortoirs';
    return [{ label: `🤝 Rencontre encadrée n°${P.meets + 1} (avec ${this.officerName()})`, desc: P.lastMeet === this.day() ? 'Une rencontre par jour : revenez demain' : ok ? 'Choisir une activité à son rythme' : 'Entre 9 h et 19 h, hors temps calme', action: () => this.meet(K) }];
  }
  meet(K) {
    const P = this.proc, k = K.k;
    if (P.lastMeet === this.day()) return this.ui.toast(`${this.officerName()} : « ${k.first} a besoin de temps entre deux rencontres. Revenez demain. »`, 3.5);
    if (!(this.env.time >= 9 && this.env.time < 19) || this.orphanage.schedule().where === 'dortoirs') return this.ui.toast('Les rencontres ont lieu entre 9 h et 19 h, en dehors du temps calme.', 3);
    const set = MEETS[Math.min(2, P.meets)];
    this.ui.openMenu(`🤝 Rencontre n°${P.meets + 1} avec ${k.first}`, `${k.first} est ${k.trait} et aime ${k.hobby}. Une éducatrice reste à proximité.`, set.map(([label, tag]) => ({ label, action: () => this.doMeet(K, label, tag) })));
  }
  doMeet(K, label, tag) {
    const P = this.proc, k = K.k, hob = k.hobby;
    const match = (tag === 'dessin' && /dessin/.test(hob)) || (tag === 'lecture' && /lecture|chant/.test(hob)) || (tag === 'jeu' && /jeux|informatique/.test(hob)) || (tag === 'math' && /math|sciences/.test(hob)) || (tag === 'football' && /football|danse/.test(hob)) || ['album', 'avenir', 'gouter', 'parler'].includes(tag);
    const shy = /timide|calme/.test(k.trait), gain = 18 + (match ? 9 : 0) - (shy ? 7 : 0) + Math.round(Math.random() * 6);
    P.comfort = Math.min(100, P.comfort + gain); P.meets++; P.lastMeet = this.day(); this.env.time = (this.env.time + 1) % 24;
    const lines = P.comfort < 35 ? [`${k.first} reste un peu en retrait, mais ${this.il(k)} vous a souri à la fin.`, `${k.first} parle peu. L’éducatrice vous rassure : « C’est normal, il faut du temps. »`] : P.comfort < 65 ? [`${k.first} se détend et vous pose des questions sur vous.`, `${k.first} rit à vos blagues et vous montre ses affaires.`] : [`${k.first} vous attendait à la porte et vous prend la main.`, `${k.first} : « Tu reviens demain ? »`];
    P.hist.push(`J${this.day()} : ${label}`); this.log(`Rencontre n°${P.meets} avec ${k.first} : ${label.toLowerCase()}.`);
    this.ui.toast(`🤝 ${label} — ${pick(lines)}`, 5);
    if (P.meets >= 3 && P.comfort >= 60) { P.step = 'eval'; this.economy.notify(`📁 ${this.officerName()} : les rencontres avec ${k.first} se passent bien. Prochaine étape : l’entretien d’évaluation de la famille (au centre).`); }
    else if (P.meets >= 3 && P.meets < 6) this.economy.notify(`📁 ${this.officerName()} : ${k.first} a besoin d’un peu plus de temps. Continuons les rencontres à son rythme.`);
    else if (P.meets >= 6 && P.comfort < 60) { this.ui.toast(`${this.officerName()} : « ${k.first} nous a dit qu’${this.il(k)} ne se sent pas prêt${this.e(k)}. Nous respectons sa parole. Merci pour votre patience et votre douceur. »`, 7); this.stop(`${k.first} ne se sent pas prêt${this.e(k)} ; sa parole est respectée.`, 5); return; }
    this.onSave && this.onSave();
  }
  // évaluation de la famille (entretien en 5 questions)
  evaluation(s) {
    const P = this.proc; if (this.day() < P.evalAfter) return this.say(s, `Reprenons l’entretien à partir du jour ${P.evalAfter}, le temps d’y réfléchir.`);
    const ans = []; const ask = (i) => {
      if (i >= EVALQ.length) return this.evalDone(s, ans);
      const [q, opts] = EVALQ[i]; this.ui.openMenu(`📝 Évaluation (${i + 1}/${EVALQ.length})`, q, opts.map(([t, sc, note]) => ({ label: t, action: () => { ans.push([sc, note]); setTimeout(() => ask(i + 1), 30); } })));
    }; ask(0);
  }
  evalDone(s, ans) {
    const P = this.proc, k = this.kid(P.kidId), sc = ans.reduce((a, [v]) => a + v, 0), notes = ans.filter(([, , n]) => n).map(([, , n]) => n);
    P.evalTry++;
    if (sc >= 8) { P.step = 'dom'; this.log(`Évaluation de la famille réussie (${sc}/10).`); this.say(s, `Merci pour vos réponses sincères (${sc}/10). ${notes.length ? notes[0] + ' ' : ''}Prochaine étape : je viendrai visiter la villa et la chambre prévue pour ${k.first}.`); this.bookHome(true); }
    else { P.evalAfter = this.day() + (sc >= 5 ? 2 : 6); this.log(`Évaluation à approfondir (${sc}/10).`); this.say(s, `Nous allons prendre le temps d’en reparler (${sc}/10). ${notes.slice(0, 2).join(' ')} Revenez me voir à partir du jour ${P.evalAfter}.`); }
    this.onSave && this.onSave();
  }
  // visite du domicile
  checks() {
    const P = this.proc, room = P ? P.room : this.freeRoom(), st = this.staff ? this.staff.state : null, clean = st ? Math.round((st.vie + st.chambres + st.bains + st.cuisine) / 4) : 70;
    const fridge = this.kitchen && this.kitchen.stock ? Object.values(this.kitchen.stock).reduce((a, b) => a + b, 0) : 0;
    return [
      ['chambre', `Chambre préparée (${room ? this.villa.rooms[room].name : '—'} : décoration choisie dans « Ma Villa »)`, !!room && this.villa.decor[room] !== undefined],
      ['propre', `Maison propre et rangée (${clean} %)`, clean >= 50],
      ['piscine', 'Piscine sécurisée (barrière de sécurité)', this.poolFence],
      ['repas', `Repas assurés (cuisinier personnel ou réfrigérateur garni : ${fridge} aliments)`, !!(this.cook && this.cook.hired) || fridge >= 5],
    ];
  }
  bookHome(silent) { const P = this.proc; if (!P || P.step !== 'dom') return; P.homeDay = this.day() + 1; if (!silent) this.ui.toast(`🏠 Visite du domicile fixée au jour ${P.homeDay}, entre 10 h et 13 h. Soyez à la villa.`, 3.5); this.economy.notify(`🏠 ${this.officerName()} viendra visiter la villa le jour ${P.homeDay} entre 10 h et 13 h. Points vérifiés : chambre préparée, propreté, sécurité de la piscine, repas.`); this.onSave && this.onSave(); }
  homeVisit() {
    const P = this.proc, k = this.kid(P.kidId), C = this.checks(), ok = C.every((c) => c[2]); P.homeDay = null; P.officerOn = false; setTimeout(() => this.spawnOfficer(false), 4000);
    this.ui.openMenu(`🏠 Visite du domicile — ${this.officerName()}`, ok ? `Tout est prêt pour accueillir ${k.first}. Le dossier part en validation (décision dans 2 jours).` : 'Quelques points sont à revoir avant d’aller plus loin. Rien de grave : reprogrammez la visite quand ce sera prêt (application « Vie familiale »).', C.map(([, l, v]) => ({ label: `${v ? '✅' : '❌'} ${l}`, action: () => {} })));
    if (ok) { P.step = 'valid'; P.validDay = this.day() + 2; this.log('Visite du domicile : avis favorable.'); }
    else this.log(`Visite du domicile : points à revoir (${C.filter((c) => !c[2]).map((c) => c[0]).join(', ')}).`);
    this.onSave && this.onSave();
  }
  buyFence() {
    if (this.poolFence) return; if (!this.economy.pay(450000, 'Barrière de sécurité de piscine (achat pour la maison)', 'Équipement maison')) return this.ui.toast('Solde personnel insuffisant.', 2);
    this.poolFence = true; this.buildFence(); this.ui.toast('🛡️ Barrière de sécurité installée autour de la piscine (portillon côté ouest).', 3); this.onSave && this.onSave();
  }
  buildFence() {
    if (this.fence || !this.poolFence) return; const g = new THREE.Group(), m = new THREE.MeshStandardMaterial({ color: 0xf2f2f2, roughness: 0.5 }), glass = new THREE.MeshStandardMaterial({ color: 0x9ad0e6, transparent: true, opacity: 0.35, roughness: 0.1 });
    const x0 = POOL.x0 - 0.75, x1 = POOL.x1 + 0.75, z0 = POOL.z0 - 0.75, z1 = POOL.z1 + 0.75, zc = (z0 + z1) / 2, segs = [[x0, z0, x1, z0], [x0, z1, x1, z1], [x1, z0, x1, z1], [x0, z0, x0, zc - 0.7], [x0, zc + 0.7, x0, z1]];
    const col = this.villa.world && this.villa.world.collision;
    for (const [a, b, c, d] of segs) {
      const lx = Math.max(0.06, Math.abs(c - a)), lz = Math.max(0.06, Math.abs(d - b)), cx = (a + c) / 2, cz = (b + d) / 2;
      const p = new THREE.Mesh(new THREE.BoxGeometry(lx, 0.9, lz), glass); p.position.set(cx, 0.45, cz); g.add(p);
      const r = new THREE.Mesh(new THREE.BoxGeometry(lx + 0.04, 0.06, lz + 0.04), m); r.position.set(cx, 0.93, cz); g.add(r);
      if (col) col.addBox(Math.min(a, c) - 0.03, Math.min(b, d) - 0.03, Math.max(a, c) + 0.03, Math.max(b, d) + 0.03, 0.95);
    }
    this.villa.scene.add(g); this.fence = g;
  }
  // ------------------------------------------------------------------ intégration progressive puis arrivée
  planInteg() {
    const P = this.proc; if (!P || P.step !== 'integ') return; if (P.win) return this.ui.toast('Une étape d’intégration est déjà planifiée.', 2.5);
    const [, label, a, b] = INTEG[P.integ], d = this.day() + 1; P.win = [d * 24 + a, d * 24 + b]; P.winDay = d;
    const k = this.kid(P.kidId); this.economy.notify(`🧳 ${label} : ${k.first} viendra le jour ${d}. Le chauffeur du centre l’accompagne.`); this.ui.toast(`🧳 Planifié pour le jour ${d} : ${label}.`, 3); this.onSave && this.onSave();
  }
  adopt() {
    const P = this.proc, k = this.kid(P.kidId), i = this.kidIdx(k.id);
    this.children.push({ id: k.id, first: k.first, female: k.female, age: k.age, trait: k.trait, hobby: k.hobby, dream: k.dream, room: P.room, since: this.day(), bonheur: 75, confiance: Math.max(55, P.comfort), sante: 80, etudes: 55, last: {}, lastInter: this.day(), idx: i });
    this.orphanage.present = Math.max(0, this.orphanage.present - 1); this.proc = null;
    this.log(`🏡 ${k.first} est arrivé${this.e(k)} à la maison, dans sa chambre (${this.villa.rooms[P.room].name}). Bienvenue !`);
    this.economy.notify(`🏡 ${k.first} est arrivé${this.e(k)} à la VILLA NOVA. Le centre NOVA SOLIDARITÉ continuera de prendre des nouvelles pendant quelques mois (suivi fictif). Application « Vie familiale » disponible.`);
    if (this.events) this.events.repAdd('generosite', 1);
    this.onSave && this.onSave();
  }
  // ------------------------------------------------------------------ vie familiale à la villa
  present_() { // enfants actuellement « à la maison » (vivant à la villa, ou en période d'intégration)
    const out = this.children.map((c) => ({ c, visit: false }));
    if (this.integWindow()) { const k = this.kid(this.proc.kidId); out.push({ c: { id: k.id, first: k.first, female: k.female, age: k.age, room: this.proc.room, idx: this.kidIdx(k.id), last: {}, visit: true }, visit: true }); }
    return out;
  }
  plan(c, visit) { // où se trouve l'enfant selon l'heure
    const h = this.env.time, week = (this.schools ? this.schools.dow() : this.day() % 7) < 5 && !visit, bed = c.age < 10 ? 20.5 : 21.5, st = !visit && this.schools ? this.schools.status(c) : null;
    if (!visit && this.onTrip()) return { away: true, label: `en vacances à ${this.trip.town} avec toi (non affiché pendant le voyage)` };
    if (h < 6.5 || h >= bed) return { room: c.room, sleep: true, label: 'dort' };
    if (h < 7.3) return { room: c.room, label: 'se prépare' };
    if (h < 8) return { room: 'manger', label: 'petit-déjeuner' };
    if (st) { if (st.absent && h < 16) return { room: c.room, label: `reste à la maison (${st.absent})` }; if (st.atSchool) return { away: true, label: st.label }; }
    else if (week && h < 16 && h >= 7.6) return { away: true, label: 'au soutien scolaire du centre NOVA SOLIDARITÉ (pas encore inscrit·e dans une école : application « Vie scolaire »)' };
    if (h < 12) return { room: 'jeux', label: 'joue dans la salle de jeux' };
    if (h < 13) return { room: 'manger', label: 'déjeuner' };
    if (h < 16) return { room: 'salon', label: 'se repose au salon' };
    if (h < 17.5) return { room: 'jeux', label: 'joue dans la salle de jeux' };
    if (h < 19.5) return { room: c.room, desk: true, label: 'fait ses devoirs dans sa chambre' };
    if (h < 20.3) return { room: 'manger', label: 'dîner en famille' };
    return { room: 'salon', label: 'veillée au salon' };
  }
  charFor(c) {
    let ch = this.chars[c.id]; if (ch) return ch;
    const i = c.idx >= 0 ? c.idx : 0, C = createCharacter({ female: c.female, skin: SKINS[(i + 2) % SKINS.length], shirtColor: [0xfcd116, 0x2f80ed, 0xe8112d, 0x0b6e4f, 0xe46a1f, 0x7a2a8a][i % 6], pants: 0x1f3a5a, skirt: c.female, headwrap: false, shorts: !c.female });
    C.group.scale.setScalar(0.55 + Math.min(14, c.age) * 0.03); this.villa.inGroup.add(C.group);
    const R = this.villa.rooms[c.room]; ch = this.chars[c.id] = { c: C, x: R.cx, z: R.cz, path: [], key: null, h: 0 }; return ch;
  }
  target(c, p) {
    const R = this.villa.rooms[p.room]; if (!R) return [0, 0];
    if (p.sleep && R.bed) return [R.bed.x, R.bed.z]; if (p.desk && R.desk) return [R.desk.x - 0.7, R.desk.z];
    const n = (c.idx % 3) - 1; return this.freeSpot(R, R.cx + n * 1.3, R.cz + (p.room === 'manger' ? 0.9 : 0.4));
  }
  freeSpot(R, x, z) { // évite les meubles (collisions de l'aile, niveau isolé de la villa)
    const col = this.villa.world && this.villa.world.collision; if (!col) return [x, z];
    const lv = col.level; col.level = VILLA.LV; const bad = (a, b) => a < R.x0 + 0.6 || a > R.x1 - 0.6 || b < R.z0 + 0.6 || b > R.z1 - 0.6 || [[0, 0], [0.35, 0], [-0.35, 0], [0, 0.35], [0, -0.35]].some(([u, v]) => col.pointBlocked(VILLA.O.x + a + u, VILLA.Y + 0.3, VILLA.O.z + b + v));
    let out = [x, z];
    if (bad(x, z)) { out = null; for (let r = 0.6; r < 4 && !out; r += 0.6) for (let k = 0; k < 12 && !out; k++) { const a = x + Math.cos(k * Math.PI / 6) * r, b = z + Math.sin(k * Math.PI / 6) * r; if (!bad(a, b)) out = [a, b]; } }
    col.level = lv; return out || [R.cx, R.cz];
  }
  nearest(x, z) {
    if (!this.villa.inside) return null; const O = VILLA.O; let best = null;
    for (const { c } of this.present_()) { const ch = this.chars[c.id]; if (!ch || !ch.c.group.visible) continue; const d = Math.hypot(x - (O.x + ch.x), z - (O.z + ch.z)); if (d < 1.6 && (!best || d < best.d)) best = { d, it: { label: () => (c.visit ? `Parler à ${c.first} (en visite)` : `Parler à ${c.first}`), action: () => this.childMenu(c) } }; }
    if (this.officerC && this.officerC.group.visible) { const R = this.villa.rooms.salon, d = Math.hypot(x - (O.x + R.cx + 2), z - (O.z + R.cz)); if (d < 1.8 && (!best || d < best.d)) best = { d, it: { label: () => `Parler à ${this.officerName()} (visite du domicile)`, action: () => this.homeVisit() } }; }
    return best;
  }
  childMenu(c) {
    const p = this.plan(c, c.visit), d = this.day(), h = this.env.time, once = (k) => c.last[k] === d;
    if (p.sleep) return this.ui.toast(`${c.first} dort. Chut… 🌙`, 2);
    const lines = c.visit ? [`C’est grand ici ! C’est vraiment ma chambre ?`, 'Il y a une piscine ! On pourra se baigner ensemble ?', 'J’ai un peu peur… mais je suis content' + (c.female ? 'e' : '') + '.'] : this.mood(c);
    const act = (k, label, hours, eff, msg) => () => { if (once(k)) return this.ui.toast(`${c.first} : « On l’a déjà fait aujourd’hui ! Demain ? »`, 2.5); c.last[k] = d; c.lastInter = d; this.villa.activity(label, hours, {}, msg); this.applyEff(c, eff); };
    const items = [{ label: '💬 Discuter', action: () => { if (!once('talk')) { c.last.talk = d; c.lastInter = d; this.applyEff(c, { confiance: 2, bonheur: 1 }); } this.ui.toast(`${c.first} : « ${pick(lines)} »`, 4); } }];
    if (c.visit) items.push({ label: '🏠 Lui faire visiter la maison', action: act('tour', 'Visite de la maison', 0.75, { confiance: 4 }, `${c.first} découvre la villa, le jardin et sa chambre.`) });
    else {
      const ss = this.schools && this.schools.status(c), e = this.schools && this.schools.enr[c.id];
      if (ss && e && this.schools.schoolDay() && !ss.absent && h >= 6.5 && h < 7.6 && e.escortDay !== d) items.push({ label: `🎒 L’accompagner à l’école (${ss.school.short})`, desc: 'Trajet ensemble jusqu’au portail', action: () => { this.schools.escort(c); c.lastInter = d; this.villa.activity('Trajet vers l’école', Math.max(0.2, 7.7 - h), {}, `Tu accompagnes ${c.first} jusqu’au portail de ${ss.school.short}. « À ce soir ! »`); this.applyEff(c, { bonheur: 3, confiance: 3 }); this.log(`🎒 Accompagnement de ${c.first} à l’école (${ss.school.short}).`); } });
      if (c.age >= 6) items.push({ label: '📚 L’aider à faire ses devoirs', desc: 'Études +4', action: act('devoirs', 'Devoirs', 1, { etudes: 4, confiance: 2 }, `${c.first} a fini ses devoirs (${LEVELS(c.age)}).`) });
      items.push({ label: '🎲 Jouer ensemble', desc: 'Bonheur +6', action: act('jeu', 'Jeu en famille', 0.75, { bonheur: 6, confiance: 2 }, pick(['Partie de baby-foot acharnée !', 'Course de petites voitures dans le couloir.', 'Partie de awalé : tu as perdu !'])) });
      if (h >= 19.5 && c.age < 11) items.push({ label: '📖 Raconter une histoire du soir', action: act('histoire', 'Histoire du soir', 0.5, { bonheur: 4, confiance: 4 }, 'L’histoire de la tortue et du léopard… les yeux se ferment.') });
      items.push({ label: '🎁 Lui offrir un cadeau', action: () => this.giftMenu(c) });
      if (this.partyOk(c)) items.push({ label: `🎂 Organiser sa fête d’anniversaire (${c.age} ans)`, action: () => this.partyMenu(c) });
      items.push({ label: '🤗 L’encourager', action: () => { if (!once('enc')) { c.last.enc = d; c.lastInter = d; this.applyEff(c, { bonheur: 2, confiance: 2 }); } this.ui.toast(`Tu dis à ${c.first} que tu es fier/fière de ${c.female ? 'elle' : 'lui'}. ${c.first} sourit.`, 3); } });
      if (this.cook && this.cook.hired && p.room === 'manger') items.push({ label: '🍽️ Manger ensemble', action: () => { this.applyEff(c, { bonheur: 3, sante: 2 }); c.lastInter = d; this.cook.eat(); } });
    }
    this.ui.openMenu(`${c.female ? '👧🏿' : '👦🏿'} ${c.first}, ${c.age} ans`, `${c.visit ? 'Période d’intégration' : 'Ton enfant'} • en ce moment : ${p.label}`, items);
  }
  // ------------------------------------------------------------------ cadeaux, anniversaires, vacances
  giftMenu(c) {
    const list = GIFTS.filter((g) => c.age >= g.min && c.age <= g.max);
    this.ui.openMenu(`🎁 Un cadeau pour ${c.first}`, `${c.age} ans, aime ${c.hobby}. Un seul cadeau par jour ; le temps passé ensemble compte plus que les cadeaux.`, list.map((g) => ({ label: `${g.label}${(c.gifts || []).includes(g.id) ? ' (déjà offert)' : ''}`, desc: fcfa(g.cost), action: () => this.give(c, g.id) })));
  }
  give(c, id) {
    const g = GIFTS.find((q) => q.id === id), d = this.day(); if (!g) return;
    if (c.age < g.min || c.age > g.max) return this.ui.toast('Ce cadeau n’est pas adapté à son âge.', 2.5);
    if (c.giftDay === d) return this.ui.toast(`${c.first} a déjà reçu un cadeau aujourd’hui.`, 2.5);
    if ((c.gifts || []).includes(id)) return this.ui.toast(`${c.first} a déjà ce cadeau.`, 2.5);
    if (!this.economy.pay(g.cost, `Cadeau pour ${c.first} : ${g.label.slice(2).trim()}`, 'Boutique (fictive)')) return this.ui.toast('Solde personnel insuffisant.', 2);
    c.gifts = [...(c.gifts || []), id]; c.giftDay = d; c.giftLog = [...(c.giftLog || []).filter((x) => x > d - 7), d];
    const many = c.giftLog.length > 3, match = g.tags.test(c.hobby), bday = c.bdayDay != null && d - c.bdayDay <= 1;
    const gain = many ? 1 : 4 + (match ? 5 : 0) + (bday ? 4 : 0); this.applyEff(c, { bonheur: gain, confiance: many ? 0 : 1, etudes: id === 'livre' || id === 'science' || id === 'tablette' ? 2 : 0 }); c.lastInter = d;
    this.log(`🎁 Cadeau pour ${c.first} : ${g.label.slice(2).trim()}${bday ? ' (anniversaire)' : ''}.`);
    this.ui.toast(many ? `${c.first} : « Merci… mais tu sais, je préfère quand on passe du temps ensemble. »` : `${c.first} : « ${match ? 'Waouh, c’est exactement ce que je voulais !' : 'Merci beaucoup !'} » 🎁`, 4);
  }
  partyOk(c) { return c.bdayDay != null && this.day() - c.bdayDay <= 1 && !c.party; }
  partyMenu(c) {
    if (!this.partyOk(c)) return this.ui.toast('La fête se prépare le jour de l’anniversaire ou le lendemain.', 3);
    const e = this.schools && this.schools.enr[c.id];
    this.ui.openMenu(`🎂 Fête de ${c.first} (${c.age} ans)`, 'Gâteau, décoration et musique à la villa. Boissons sans alcool.', [
      { label: '🎈 Fête en famille à la villa', desc: `${fcfa(40000)} • gâteau, décoration, jus de bissap et d’ananas`, action: () => this.party(c, false, 40000) },
      ...(e ? [{ label: `🎉 Fête avec ses camarades de classe (${c.age < 12 ? 'goûter' : 'après-midi'})`, desc: `${fcfa(90000)} • invitations par l’école, animation, goûter`, action: () => this.party(c, true, 90000) }] : []),
    ]);
  }
  party(c, friends, cost) {
    if (!this.economy.pay(cost, `Fête d’anniversaire de ${c.first} (${c.age} ans)`, 'VILLA NOVA')) return this.ui.toast('Solde personnel insuffisant.', 2);
    c.party = true; c.lastInter = this.day(); this.economy.togglePhone(false);
    this.villa.activity(friends ? 'Fête d’anniversaire avec les camarades' : 'Fête d’anniversaire en famille', 3, { energy: -6 }, friends ? `Les camarades de ${c.first} chantent « Joyeux anniversaire » autour du gâteau 🎂` : `${c.first} souffle ses ${c.age} bougies sous les applaudissements 🎂`);
    this.applyEff(c, { bonheur: friends ? 20 : 15, confiance: 5 }); this.children.filter((q) => q !== c).forEach((q) => this.applyEff(q, { bonheur: 4 }));
    this.log(`🎂 Fête d’anniversaire de ${c.first} (${c.age} ans)${friends ? ' avec ses camarades' : ' en famille'}.`);
  }
  onTrip() { const t = this.trip; if (!t) return false; const d = this.day(), end = t.start + t.nights; return d >= t.start && (d < end || (d === end && this.env.time < 18)); }
  tripDaysOk(start, nights) { if (!this.schools || !this.children.some((c) => this.schools.enr[c.id])) return true; for (let d = start; d <= start + nights; d++) if (this.schools.schoolDay(d)) return false; return true; }
  planTrip(town, nights) {
    const T = TRIPS.find((q) => q.town === town); if (!T || !this.children.length) return this.ui.toast('Aucun enfant à la maison pour le moment.', 2.5);
    if (this.trip && this.day() <= this.trip.start + this.trip.nights) return this.ui.toast('Des vacances sont déjà prévues.', 2.5);
    let start = this.day() + 1; for (let k = 0; k < 40 && !this.tripDaysOk(start, nights); k++) start++;
    if (!this.tripDaysOk(start, nights)) return this.ui.toast('Pas de période sans cours assez longue pour le moment.', 3);
    const cost = T.night * nights; if (!this.economy.pay(cost, `Vacances en famille à ${town} (${nights} nuit${nights > 1 ? 's' : ''}, hôtel fictif)`, town)) return this.ui.toast('Solde personnel insuffisant.', 2);
    this.trip = { town, nights, start, cost, visited: {} }; this.log(`🧳 Vacances prévues à ${town} du jour ${start} au jour ${start + nights} (${nights} nuit${nights > 1 ? 's' : ''}).`);
    this.economy.notify(`🧳 Vacances en famille à ${town} : départ le jour ${start}, retour le jour ${start + nights} à 18 h. Rends-toi à ${town} chaque jour du séjour (le chauffeur peut t’y conduire) pour en profiter avec les enfants.`); this.onSave && this.onSave();
  }
  cancelTrip() { const t = this.trip; if (!t || this.day() >= t.start) return; this.economy.earn(t.cost, `Remboursement des vacances à ${t.town} (annulées avant le départ)`, t.town); this.trip = null; this.log('Vacances annulées avant le départ (remboursées).'); this.onSave && this.onSave(); }
  tripTick() {
    const t = this.trip; if (!t || !this.onTrip()) return; const d = this.day(), T = TOWNS.find((q) => q.name === t.town), P = this.player.pos;
    if (!t.visited[d] && T && Math.hypot(P.x - T.x, P.z - T.z) < T.r && this.env.time >= 8 && this.env.time < 20) {
      t.visited[d] = true; this.children.forEach((c) => { this.applyEff(c, { bonheur: 8, confiance: 4 }); c.lastInter = d; });
      const msg = pick(['Baignade surveillée et châteaux de sable.', 'Visite d’un musée : les enfants posent mille questions.', 'Balade au marché et dégustation de beignets.', 'Après-midi au calme au bord de l’eau.']);
      this.log(`🧳 Journée de vacances à ${t.town} : ${msg}`); this.ui.toast(`🧳 Vacances à ${t.town} avec ${this.children.map((c) => c.first).join(' et ')} : ${msg}`, 4.5);
    }
  }
  tripDaily(prev) { // bilan de la veille pendant le séjour
    const t = this.trip; if (!t) return; const end = t.start + t.nights;
    if (prev >= t.start && prev <= end && !t.visited[prev]) { this.children.forEach((c) => this.applyEff(c, { bonheur: -4 })); this.economy.notify(`🧳 Les enfants t’ont attendu à ${t.town} hier… Rejoins-les pendant le séjour.`); }
    if (prev >= end) { this.log(`🧳 Retour de vacances (${t.town}).`); this.trip = null; }
  }
  mood(c) {
    if (c.bonheur < 35) return ['Tu travailles tout le temps… tu me manques.', 'Je m’ennuie un peu ici.'];
    if (c.sante < 40) return ['J’ai faim… on mange quand ?', 'Je ne me sens pas très bien.'];
    if (c.age < 7) return ['Tu me portes ? 🙂', `Regarde mon dessin !`, 'On joue à cache-cache ?', 'Je veux un câlin.', `J’aime trop ma chambre !`];
    if (c.age < 13) return [`Aujourd’hui j’ai fait ${c.hobby} !`, `Plus tard, je veux ${c.dream}.`, 'Je suis bien à la maison.', 'Tu viens jouer avec moi ?', 'On peut aller à la plage ce week-end ?'];
    return [`Je pense à ${c.dream}… tu crois que j’y arriverai ?`, 'Je peux sortir avec mes amis samedi ? (on rentre avant 18 h)', 'J’ai un exposé à préparer, tu m’aides ?', 'Merci pour tout, sincèrement.', `En ce moment je me passionne pour ${c.hobby}.`];
  }
  applyEff(c, e) { for (const [k, v] of Object.entries(e)) if (k in c) c[k] = clamp(c[k] + v); this.onSave && this.onSave(); }
  outing(id) {
    const o = OUTINGS.find((q) => q.id === id); if (!o) return; const d = this.day(), h = this.env.time, kids = this.children;
    if (!kids.length) return this.ui.toast('Aucun enfant à la maison pour le moment.', 2.5);
    if (this.lastOuting === d) return this.ui.toast('Une sortie par jour : on se repose aussi !', 2.5);
    const busy = kids.filter((c) => { const p = this.plan(c, false); return p.away || p.sleep; }); if (busy.length) return this.ui.toast(`${busy.map((c) => c.first).join(' et ')} ${busy.length > 1 ? 'sont' : 'est'} ${this.plan(busy[0], false).sleep ? 'couché' : 'à l’école'} en ce moment.`, 3);
    if (o.evening && h < 17) return this.ui.toast('La soirée cinéma, c’est à partir de 17 h.', 2.5);
    if (o.cook && !(this.cook && this.cook.hired)) return this.ui.toast('Il faut un cuisinier personnel (application « Mon cuisinier »).', 2.5);
    if (o.cost && !this.economy.pay(o.cost, `Sortie en famille — ${o.label.slice(2)}`, 'Loisirs')) return this.ui.toast('Solde personnel insuffisant.', 2);
    this.lastOuting = d; this.economy.togglePhone(false); this.villa.activity(o.label.slice(2).trim(), o.hours, { energy: -4 }, o.msg);
    kids.forEach((c) => { this.applyEff(c, o.eff); c.lastInter = d; }); this.log(`${o.label} avec ${kids.map((c) => c.first).join(', ')}.`);
  }
  // messages (enfants de 8 ans et plus)
  contacts() { return this.children.filter((c) => c.age >= 8).map((c) => ({ key: `fam:${c.id}`, kind: 'fam', name: c.first, role: `Mon enfant (${c.age} ans) • VILLA NOVA`, icon: c.female ? '👧🏿' : '👦🏿', fam: c.id })); }
  reply(id, txt) {
    const c = this.children.find((q) => q.id === id); if (!c) return 'Message non distribué.'; const p = this.plan(c, false);
    if (/journée|journee/i.test(txt)) return p.away ? 'Je suis encore en cours, je te raconte ce soir !' : pick([`Super ! J’ai fait ${c.hobby}.`, 'Bien ! La maîtresse m’a félicité' + (c.female ? 'e' : '') + '.', 'Un peu fatigant, mais ça va.']);
    if (/devoir/i.test(txt)) return c.last.devoirs === this.day() ? 'Oui, on les a faits ensemble 😊' : 'Pas encore… tu m’aides ce soir ?';
    if (/fier|fière|❤/i.test(txt)) { this.applyEff(c, { bonheur: 2, confiance: 1 }); return 'Merci ❤️ Moi aussi je t’aime.'; }
    if (p.sleep) return 'Zzz… (message lu au réveil) Bonne nuit !';
    return pick(this.mood(c));
  }
  // ------------------------------------------------------------------ boucle
  update(dt) {
    const d = this.day(), h = this.env.time, P = this.proc;
    if (this.lastDay === null) this.lastDay = d;
    if (d > this.lastDay) { this.lastDay = d; this.tripDaily(d - 1); this.daily(d); }
    this.tripTick();
    if (P) {
      if (P.step === 'dom' && P.homeDay && d === P.homeDay && h >= 10 && h < 13 && !P.officerOn) {
        const pl = this.player.pos; if (this.villa.inside || Math.hypot(pl.x - VILLA.O.x, pl.z - VILLA.O.z) < 45) { P.officerOn = true; this.spawnOfficer(true); this.ui.toast(`🏠 ${this.officerName()} est arrivée pour la visite du domicile. Elle t’attend dans le grand salon.`, 4); }
      }
      if (P.step === 'dom' && P.homeDay && (d > P.homeDay || (d === P.homeDay && h >= 13)) && !P.officerOn) { P.homeDay = null; this.economy.notify(`🏠 ${this.officerName()} est passée à la villa mais tu n’étais pas là. Reprogramme la visite dans l’application « Vie familiale ».`); this.onSave && this.onSave(); }
      if (P.officerOn && (P.step !== 'dom' || (d === P.homeDay && h >= 13) || (P.homeDay && d > P.homeDay))) { P.officerOn = false; this.spawnOfficer(false); if (P.step === 'dom' && P.homeDay) { P.homeDay = null; this.economy.notify(`🏠 La visite n’a pas pu être faite : ${this.officerName()} est repartie. Reprogramme-la dans « Vie familiale ».`); } }
      if (P.step === 'valid' && d >= P.validDay && h >= 9) {
        const k = this.kid(P.kidId);
        if (k.age >= 7 && P.comfort < 60) { this.stop(`${k.first} a dit ne pas être prêt${this.e(k)}. Sa parole est respectée.`, 7); }
        else { P.step = 'integ'; P.integ = 0; this.log(`Validation de la protection de l’enfance (fictive) : avis favorable${k.age >= 7 ? `, et ${k.first} a dit oui` : ''}.`); this.economy.notify(`✅ ${this.officerName()} : la commission (fictive) donne un avis favorable${k.age >= 7 ? ` et ${k.first} est d’accord` : ''}. L’intégration se fera progressivement : journée, week-end, puis arrivée. À planifier dans « Vie familiale ».`); this.onSave && this.onSave(); }
      }
      if (P.step === 'integ' && P.win && this.abs() >= P.win[1]) {
        const k = this.kid(P.kidId), [, label] = INTEG[P.integ]; P.win = null;
        if (P.integ === 2) return this.adopt();
        P.integ++; P.comfort = Math.min(100, P.comfort + 10); this.log(`${label} avec ${k.first} : terminé.`); this.economy.notify(`🧳 ${k.first} est reparti${this.e(k)} au centre après « ${label.split(' (')[0].toLowerCase()} ». ${k.first} : « Je reviens bientôt ? » Prochaine étape à planifier dans « Vie familiale ».`); this.onSave && this.onSave();
      }
    }
    // personnages à la villa
    const here = this.present_(), ids = new Set(here.map((q) => q.c.id));
    for (const [id, ch] of Object.entries(this.chars)) if (!ids.has(id)) ch.c.group.visible = false;
    for (const { c, visit } of here) {
      const ch = this.charFor(c), p = this.plan(c, visit), key = `${p.room}|${p.sleep ? 's' : p.desk ? 'd' : ''}|${p.away ? 'a' : ''}`;
      ch.c.group.visible = !p.away;
      if (p.away) { ch.key = null; continue; }
      if (key !== ch.key) { ch.key = key; const [tx, tz] = this.target(c, p); ch.tx = tx; ch.tz = tz; ch.path = !this.villa.inside || !this.staff ? [[tx, tz]] : this.staff.pathIn({ x: ch.x, z: ch.z }, tx, tz); if (!this.villa.inside) { ch.x = tx; ch.z = tz; ch.path = []; } }
      let sp = 0; const tg = ch.path.length ? ch.path[0] : [ch.tx, ch.tz], dx = tg[0] - ch.x, dz = tg[1] - ch.z, dd = Math.hypot(dx, dz);
      if (dd > 0.15) { const st = Math.min(dd, 1.4 * dt); ch.x += dx / dd * st; ch.z += dz / dd * st; ch.h = Math.atan2(dx, dz); sp = 1.4; } else if (ch.path.length) ch.path.shift();
      ch.c.group.position.set(ch.x, 0, ch.z);
      if (p.sleep && !ch.path.length && dd <= 0.15) { ch.c.group.rotation.set(-Math.PI / 2, 0, 0); ch.c.group.position.y = 0.66; }
      else { ch.c.group.rotation.set(0, ch.h || 0, 0); if (ch.c.animate) ch.c.animate(dt, sp); }
    }
    if (this.officerC && this.officerC.animate) this.officerC.animate(dt, 0);
  }
  spawnOfficer(on) {
    if (on && !this.officerC) { this.officerC = createCharacter({ female: true, skin: SKINS[2 % SKINS.length], shirtColor: 0x0b6e4f, pants: 0x2a2d33, skirt: false }); this.villa.inGroup.add(this.officerC.group); }
    if (this.officerC) { const R = this.villa.rooms.salon; this.officerC.group.position.set(R.cx + 2, 0, R.cz); this.officerC.group.rotation.y = -Math.PI / 2; this.officerC.group.visible = on; }
  }
  daily(d) {
    for (const c of this.children) {
      const meals = !!(this.cook && this.cook.hired) || (this.kitchen && this.kitchen.stock && Object.values(this.kitchen.stock).reduce((a, b) => a + b, 0) >= 3);
      c.bonheur = clamp(c.bonheur - 1 - (c.lastInter < d - 1 ? 5 : 0)); c.confiance = clamp(c.confiance - (c.lastInter < d - 2 ? 3 : 0));
      c.sante = clamp(c.sante + (meals ? 2 : -6)); if (this.staff && (this.staff.state.vie + this.staff.state.chambres) / 2 < 30) c.bonheur = clamp(c.bonheur - 2);
      c.etudes = clamp(c.etudes - (c.last.devoirs && c.last.devoirs >= d - 2 ? 0 : 1));
      if ((d - c.since) > 0 && (d - c.since) % 90 === 0) { c.age = Math.min(18, c.age + 1); c.bonheur = clamp(c.bonheur + 10); c.bdayDay = d; c.party = false; this.log(`🎂 Anniversaire de ${c.first} : ${c.age} ans !`); this.economy.notify(`🎂 C’est l’anniversaire de ${c.first} (${c.age} ans) ! Organise sa fête (aujourd’hui ou demain) depuis « Vie familiale ».`); }
      if (!meals) this.economy.notify(`🍽️ ${c.first} n’a pas eu de vrai repas : recrute un cuisinier ou remplis le réfrigérateur.`);
      else if (c.bonheur < 35 && c.age >= 8 && this.phonePlus) this.phonePlus.receive(`fam:${c.id}`, 'Tu rentres quand ? Tu me manques…');
    }
    if (this.children.length) this.onSave && this.onSave();
  }
  // ------------------------------------------------------------------ application « Vie familiale »
  statusText() {
    const P = this.proc; if (!P) return 'Aucune démarche en cours.'; const k = this.kid(P.kidId);
    return { pres: `L’équipe vous a présenté ${k.first}. À vous de décider si vous commencez les rencontres.`, renc: `${P.meets} rencontre(s) avec ${k.first}. Une par jour, à son rythme (au moins 3).`, eval: `Les rencontres se passent bien. Prochaine étape : l’entretien d’évaluation, avec moi, au centre${P.evalAfter > this.day() ? ` (à partir du jour ${P.evalAfter})` : ''}.`, dom: P.homeDay ? `Visite du domicile prévue le jour ${P.homeDay}, entre 10 h et 13 h.` : 'Visite du domicile à reprogrammer.', valid: `Dossier en validation : décision le jour ${P.validDay}${k.age >= 7 ? `, après avoir entendu ${k.first}` : ''}.`, integ: `Intégration progressive : étape ${P.integ + 1}/3 (${INTEG[P.integ][1]})${P.win ? ` prévue le jour ${P.winDay}` : ' à planifier'}.` }[P.step] || '';
  }
  bar(l, v) { return `<div><span>${l}</span><i><b style="width:${Math.round(v)}%"></b></i><em>${Math.round(v)}</em></div>`; }
  renderApp(b) {
    const tabs = [['famille', 'Ma famille'], ['adoption', 'Adoption'], ['activites', 'Activités'], ['journal', 'Journal']], v = this.view;
    let html = `<h4>👨‍👩‍👧 Vie familiale</h4><div class="ph-chips">${tabs.map(([k, l]) => `<button data-fm="tab:${k}" class="${k === v ? 'on' : ''}">${l}</button>`).join('')}</div>`;
    if (v === 'famille') {
      html += this.children.length ? this.children.map((c) => { const p = this.plan(c, false); return `<div class="ph-row"><span><b>${c.female ? '👧🏿' : '👦🏿'} ${esc(c.first)}, ${c.age} ans</b><small>${LEVELS(c.age)} • ${esc(this.villa.rooms[c.room].name)} • en ce moment : ${esc(p.label)}</small><small>Aime ${esc(c.hobby)} • rêve de ${esc(c.dream)} • à la maison depuis le jour ${c.since}</small></span><button class="ph-mini" data-fm="go:${c.room}">Sa chambre</button></div><div class="ev-rep">${this.bar('😊 Bonheur', c.bonheur)}${this.bar('🤝 Confiance', c.confiance)}${this.bar('🩺 Santé', c.sante)}${this.bar('📚 Études', c.etudes)}</div>`; }).join('')
        : '<p class="ph-note">Aucun enfant à la maison pour le moment. Une démarche d’adoption (fictive) commence au centre NOVA SOLIDARITÉ, auprès de la responsable de la protection de l’enfance.</p>';
      if (this.children.length) html += '<p class="ph-note">Le bien-être dépend de ta présence (discussions, devoirs, jeux, histoires), des repas et d’une maison bien tenue. École, notes et bulletins : application « Vie scolaire ».</p>';
    } else if (v === 'adoption') {
      const P = this.proc, cur = P ? STEPS.findIndex(([k]) => k === P.step) : -1;
      html += '<p class="ph-note">Adoption fictive et responsable : jamais un achat, aucune somme demandée, les dons n’ont aucune influence. L’intérêt de l’enfant passe avant tout ; dès 7 ans, son avis est respecté.</p>';
      html += `<div class="ph-list">${STEPS.map(([, l], i) => `<div class="ph-row"><span><b>${P ? (i < cur ? '✅' : i === cur ? '▶️' : '⬜') : '⬜'} ${l}</b></span></div>`).join('')}</div>`;
      if (!P) html += `<p class="ph-note">${this.children.length >= 3 ? 'Les trois chambres d’enfants sont occupées.' : this.day() < this.cooldown ? `Nouvelle démarche possible à partir du jour ${this.cooldown}.` : 'Rends-toi au centre NOVA SOLIDARITÉ et parle à la responsable de la protection de l’enfance (accueil).'}</p>${this.driver ? '<button class="ph-mini" data-fm="drive:1">🚘 M’y conduire (chauffeur)</button>' : ''}`;
      else {
        const k = this.kid(P.kidId); html += `<h5>${esc(k.first)}, ${k.age} ans — ${esc(LEVELS(k.age))}</h5><p class="ph-note">${esc(this.statusText())}</p>`;
        if (['renc', 'eval', 'valid', 'integ'].includes(P.step)) html += `<div class="ev-rep">${this.bar(`Lien avec ${esc(k.first)}`, P.comfort)}</div>`;
        if (P.step === 'dom' || P.step === 'eval' || P.step === 'renc') html += `<h5>Préparer la maison (visite du domicile)</h5>${this.checks().map(([id, l, ok]) => `<div class="ph-row"><span><b>${ok ? '✅' : '⬜'} ${esc(l)}</b></span>${!ok && id === 'piscine' ? `<button class="ph-mini" data-fm="fence:1">Installer • ${fcfa(450000)}</button>` : !ok && id === 'chambre' ? `<button class="ph-mini" data-fm="deco:${P.room}">🎨 Décorer</button>` : ''}</div>`).join('')}<p class="ph-note">Ces achats concernent la maison ; l’adoption elle-même reste gratuite.</p>`;
        if (P.step === 'dom' && !P.homeDay) html += '<button class="ph-go" data-fm="home:1">🏠 Fixer la visite du domicile (demain 10 h – 13 h)</button>';
        if (P.step === 'integ') html += `<div class="ph-list">${INTEG.map(([, l], i) => `<div class="ph-row"><span><b>${i < P.integ ? '✅' : i === P.integ ? '▶️' : '⬜'} ${l}</b></span></div>`).join('')}</div>${P.win ? '' : `<button class="ph-go" data-fm="integ:1">🧳 Planifier pour demain : ${INTEG[P.integ][1]}</button>`}`;
        html += '<button class="ph-mini" data-fm="stop:1">Mettre fin à la démarche</button>';
      }
    } else if (v === 'activites') {
      if (!this.children.length) html += '<p class="ph-note">Les activités en famille seront disponibles quand un enfant vivra à la villa.</p>';
      else {
        html += `<h5>Sorties et moments partagés</h5><p class="ph-note">Un moment partagé par jour (hors école et heures de sommeil). Résumé du moment, l’heure avance.</p>${OUTINGS.map((o) => `<div class="ph-row"><span><b>${o.label}</b><small>${o.hours} h${o.cost ? ` • ${fcfa(o.cost)}` : ' • gratuit'}</small></span><button class="ph-mini" data-fm="out:${o.id}">Y aller</button></div>`).join('')}`;
        html += `<h5>Cadeaux</h5>${this.children.map((c) => `<div class="ph-row"><span><b>${esc(c.first)}</b><small>${(c.gifts || []).length ? `Déjà offerts : ${(c.gifts || []).map((id) => GIFTS.find((g) => g.id === id).label).join(', ')}` : 'Aucun cadeau pour le moment'}</small></span><button class="ph-mini" data-fm="gift:${c.id}">🎁 Choisir</button></div>`).join('')}`;
        html += `<h5>Anniversaires</h5>${this.children.map((c) => { const n = c.since + 90 * Math.max(1, Math.ceil((this.day() - c.since + 0.01) / 90)); return `<div class="ph-row"><span><b>🎂 ${esc(c.first)} (${c.age} ans)</b><small>${this.partyOk(c) ? 'C’est son anniversaire !' : `Prochain anniversaire : jour ${n} (${c.age + 1} ans)`}</small></span>${this.partyOk(c) ? `<button class="ph-mini" data-fm="party:${c.id}">Organiser la fête</button>` : ''}</div>`; }).join('')}`;
        const t = this.trip;
        html += `<h5>Vacances en famille</h5>${t ? `<p class="ph-note">🧳 ${esc(t.town)} : du jour ${t.start} au jour ${t.start + t.nights} (retour à 18 h)${this.onTrip() ? ' — en cours' : ''}. Jours passés ensemble : ${Object.keys(t.visited).length}.</p>${this.driver ? `<button class="ph-mini" data-fm="tripgo:1">🚘 M’y conduire</button>` : ''}${this.day() < t.start ? '<button class="ph-mini" data-fm="tripx:1">Annuler (remboursé)</button>' : ''}` : `<p class="ph-note">Pendant le week-end ou les vacances scolaires. Les enfants voyagent avec toi (ils ne sont pas affichés pendant le séjour) : rends-toi sur place chaque jour pour en profiter.</p>${TRIPS.map((T) => `<div class="ph-row"><span><b>${esc(T.label)}</b><small>${fcfa(T.night)} la nuit (hôtel fictif)</small></span><span class="pp-acts"><button class="ph-mini" data-fm="trip:${T.town}|1">1 nuit</button><button class="ph-mini" data-fm="trip:${T.town}|2">2 nuits</button></span></div>`).join('')}`}`;
      }
    } else html += this.journal.slice(0, 30).map((j) => `<p class="ph-note">${j.t} • ${esc(j.txt)}</p>`).join('') || '<p class="ph-note">Le journal de famille est vide.</p>';
    b.innerHTML = html;
  }
  onPhone(v) {
    const [a, arg] = v.split(':');
    if (a === 'tab') this.view = arg;
    else if (a === 'go') return this.villa.onPhone(`go:${arg}`);
    else if (a === 'deco') { this.villa.cycleDecor(arg); this.villa.onSave && this.villa.onSave(); }
    else if (a === 'fence') this.buyFence();
    else if (a === 'home') this.bookHome();
    else if (a === 'integ') this.planInteg();
    else if (a === 'out') return this.outing(arg);
    else if (a === 'gift' || a === 'party') { const c = this.children.find((q) => q.id === arg); this.economy.togglePhone(false); if (c) return a === 'gift' ? this.giftMenu(c) : this.partyMenu(c); return; }
    else if (a === 'trip') { const [t, n] = arg.split('|'); this.planTrip(t, +n); }
    else if (a === 'tripx') this.cancelTrip();
    else if (a === 'tripgo' && this.trip && this.driver) { const T = TOWNS.find((q) => q.name === this.trip.town); this.economy.togglePhone(false); return this.driver.toDest({ id: `vac_${T.name}`, label: `${T.name} (vacances)`, x: T.x, z: T.z }); }
    else if (a === 'drive' && this.driver) { this.economy.togglePhone(false); const O = this.orphanage; return this.driver.toDest({ id: 'orphelinat', label: 'NOVA SOLIDARITÉ (centre d’accueil)', x: O.doorPt.x, z: O.doorPt.z }); }
    else if (a === 'stop') { const k = this.proc && this.kid(this.proc.kidId); if (k) this.ui.openMenu('Mettre fin à la démarche ?', `L’équipe expliquera la situation à ${k.first} avec douceur.`, [{ label: 'Oui, mettre fin à la démarche', action: () => { this.stop('Démarche arrêtée à ta demande. L’équipe accompagne l’enfant.', 7); this.economy.renderPhone(); } }, { label: 'Non, continuer', action: () => {} }]); return; }
    this.economy.renderPhone();
  }
  serialize() { return { proc: this.proc ? { ...this.proc, officerOn: false } : null, children: this.children, journal: this.journal, poolFence: this.poolFence, cooldown: this.cooldown, lastDay: this.lastDay, lastOuting: this.lastOuting ?? null, trip: this.trip || null }; }
  restore(s) {
    if (!s) return; this.proc = s.proc || null; this.children = (s.children || []).map((c) => ({ last: {}, ...c })); this.journal = s.journal || []; this.poolFence = !!s.poolFence; this.cooldown = s.cooldown || 0; this.lastDay = s.lastDay ?? null; this.lastOuting = s.lastOuting ?? null; this.trip = s.trip || null;
    this.buildFence();
  }
}
