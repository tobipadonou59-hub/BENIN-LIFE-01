// Mission 015, phase 1 (Cotonou) — population et circulation vivantes :
// densité selon l'heure, la fréquentation et le réglage du joueur (faible / moyenne / élevée), réutilisation des
// personnages et des véhicules (pooling), montée et descente aux arrêts de bus, conversations avec les habitants
// (directions, quartier, achats aux commerçantes), ambiance sonore (foule, klaxons dans les bouchons).
import * as THREE from 'three';
import { FOOD_BY_ID, fcfa } from './food-data.js';
import { regionZone, TOWNS } from './region-geo.js';

export const DENSITY = { low: { label: 'Faible', k: 0.5 }, medium: { label: 'Moyenne', k: 0.78 }, high: { label: 'Élevée', k: 1 } };
// fréquentation selon l'heure : nuit calme, pointes du matin et du soir
export function hourFactor(h) {
  if (h < 5) return 0.18; if (h < 6.5) return 0.4; if (h < 9) return 1; if (h < 12) return 0.75; if (h < 14) return 0.85;
  if (h < 16.5) return 0.7; if (h < 19.5) return 1; if (h < 22) return 0.55; return 0.28;
}
export function rushFactor(h) { return (h > 7 && h < 9.2) || (h > 17 && h < 19.5) ? 1 : (h > 6.5 && h < 10) || (h > 16 && h < 20) ? 0.5 : 0; }
const PLACES = [
  ['Ma maison', -44.5, 114], ['Marché Dantokpa', -50, 50], ['Supermarché LAGUNA', 42, -120], ['Garage AUTO CONCEPT', -42, -126],
  ['Siège de NOVA BOOK', 59, 12], ['Place des Martyrs', 50, 126], ['Jardin de Cadjèhoun', 50, -50], ['Plage', 0, 175], ['Aéroport', -462, 113],
  ...TOWNS.map((t) => [t.name, t.x, t.z]),
];
const GREET = ['Bonne arrivée !', 'On dit quoi ?', 'Bonjour, ça va un peu ?', 'Ah, bonjour mon frère !', 'Bonjour, bonne journée à toi !', 'Bonsoir, la famille va bien ?'];
const SMALLTALK = ['Il fait chaud aujourd’hui, hein ! Faut boire de l’eau.', 'Le marché Dantokpa est plein ce matin, ça bouge beaucoup.', 'Les zems roulent vite par ici, fais attention en traversant.', 'Courage pour la journée !', 'Doucement doucement, on va y arriver.', 'Le soir, la Marina est belle, va voir le coucher du soleil.'];
const BYE = ['À tout à l’heure !', 'Bonne route !', 'Que la journée soit bonne !', 'On se voit !'];
const pick = (a) => a[Math.floor(Math.random() * a.length)];
function compass(dx, dz) {
  const a = Math.atan2(dx, -dz) * 180 / Math.PI, dirs = ['le nord', 'le nord-est', 'l’est', 'le sud-est', 'le sud', 'le sud-ouest', 'l’ouest', 'le nord-ouest'];
  return dirs[Math.round(((a + 360) % 360) / 45) % 8];
}

export class CityLife {
  constructor(ctx) {
    Object.assign(this, ctx); // world, peds, traffic, env, ui, audio, economy, settings, player
    this.t = 0; this.talking = null;
    // arrêts : centres des abribus (sièges « bus » regroupés)
    const seats = (this.world.seats || []).filter((s) => s.kind === 'bus'), stops = [];
    for (const s of seats) { const st = stops.find((q) => Math.hypot(q.x - s.x, q.z - s.z) < 3); if (st) { st.n++; st.x += (s.x - st.x) / st.n; st.z += (s.z - st.z) / st.n; } else stops.push({ x: s.x, z: s.z, n: 1 }); }
    // ligne de bus : arrêts placés sur le trottoir de droite des boucles empruntées par les bus (loin des carrefours)
    const busRoutes = [...new Set(this.traffic.vehicles.filter((v) => v.role === 'bus').map((v) => v.route))];
    const q = { x: 0, z: 0, h: 0 };
    for (const r of busRoutes) for (const f of [0.08, 0.3, 0.55, 0.8]) {
      for (let k = 0; k < 8; k++) {
        const pt = r.sample(r.length * (f + k * 0.012), q), fx = Math.sin(pt.h), fz = Math.cos(pt.h);
        const x = pt.x - fz * 5.6, z = pt.z + fx * 5.6;
        const nearX = Math.min(...[-100, 0, 100].map((L) => Math.abs(pt.x - L))), nearZ = Math.min(...[-100, 0, 100, 152].map((L) => Math.abs(pt.z - L)));
        const alongX = Math.abs(fx) > Math.abs(fz), distInter = alongX ? Math.min(...[-100, 0, 100].map((L) => Math.abs(pt.x - L))) : Math.min(...[-100, 0, 100, 152].map((L) => Math.abs(pt.z - L)));
        void nearX; void nearZ;
        if (distInter < 22 || Math.hypot(x, z) < 40 || stops.some((s2) => Math.hypot(s2.x - x, s2.z - z) < 30)) continue;
        stops.push({ x, z, n: 0, ry: pt.h + Math.PI / 2, line: true }); break;
      }
    }
    this.stops = stops;
    this.traffic.stops = stops;
    this.buildStops(stops.filter((st) => st.line));
    this.traffic.onArrive = (st, v) => this.busArrive(st, v);
    this.stats = { boarded: 0, alighted: 0 };
  }
  buildStops(list) {
    if (!this.scene || !list.length) return;
    const col = this.world.collision;
    const mat = new THREE.MeshStandardMaterial({ color: 0x2a2d33, roughness: 0.5, metalness: 0.4 }), bench = new THREE.MeshStandardMaterial({ color: 0x8a5a36 });
    const sign = new THREE.MeshBasicMaterial({ map: (() => { const c = document.createElement('canvas'); c.width = 128; c.height = 128; const x = c.getContext('2d'); x.fillStyle = '#1f6aa8'; x.fillRect(0, 0, 128, 128); x.fillStyle = '#fff'; x.font = 'bold 54px Arial'; x.textAlign = 'center'; x.fillText('BUS', 64, 62); x.font = 'bold 20px Arial'; x.fillText('LIGNE 1', 64, 100); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t; })(), toneMapped: false, side: THREE.DoubleSide });
    for (const st of list) {
      const g = new THREE.Group(); g.position.set(st.x, 0, st.z); g.rotation.y = st.ry;
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 2.6, 8), mat); pole.position.set(1.2, 1.3, 0); g.add(pole);
      const sg = new THREE.Mesh(new THREE.PlaneGeometry(0.6, 0.6), sign); sg.position.set(1.2, 2.45, 0); sg.rotation.y = Math.PI / 2; g.add(sg);
      const bs = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.08, 0.45), bench); bs.position.set(-0.4, 0.45, 0.3); g.add(bs);
      for (const sx of [-1.2, 0.4]) { const l = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.45, 0.4), mat); l.position.set(sx, 0.22, 0.3); g.add(l); }
      this.scene.add(g);
      const o = new THREE.Vector3(-0.4, 0, 0.3).applyEuler(g.rotation).add(g.position); col.addCircle(o.x, o.z, 0.5, 0.6);
      // voyageurs qui attendent
      const n = 1 + Math.floor(Math.random() * 3);
      for (let k = 0; k < n; k++) { const seated = k < 2, lx = seated ? -0.9 + k * 0.9 : 0.6, lz = seated ? 0.4 : -0.3; const w = new THREE.Vector3(lx, 0, lz).applyEuler(g.rotation).add(g.position); this.peds.addWaiting(w.x, w.z, st.ry + Math.PI, seated); }
    }
  }
  get density() { return DENSITY[this.settings.density] || DENSITY.medium; }

  // ---- arrêts de bus : les personnes qui attendent montent, des passagers descendent ----
  busArrive(st, v) {
    const waiting = this.peds.idle.filter((p) => !p.away && Math.hypot(p.x - st.x, p.z - st.z) < 3.2);
    const nb = Math.min(waiting.length, 1 + Math.floor(Math.random() * 2));
    for (const p of waiting.slice(0, nb)) { p.away = 60 + Math.random() * 90; p.c.group.visible = false; this.stats.boarded++; }
    v.passengers = (v.passengers || 0) + nb;
    const off = Math.min(v.passengers, Math.floor(Math.random() * 3));
    for (let k = 0; k < off; k++) if (this.peds.spawnNear(st.x, st.z, this.player.pos)) { v.passengers--; this.stats.alighted++; }
  }

  // ---- conversations avec les habitants ----
  nearest(x, z) {
    if (this.talking) return null;
    let best = null;
    for (const p of this.peds.list) {
      if (!p.active || p.state === 'inside' || p.state === 'cross' || !p.c.group.visible) continue;
      const d = Math.hypot(p.x - x, p.z - z); if (d < 1.9 && (!best || d < best.d)) best = { d, p };
    }
    if (!best) return null;
    const p = best.p;
    return { d: best.d + 0.5, it: { label: () => `Parler à ${p.prof.id === 'parent' ? 'un parent' : p.prof.label.toLowerCase()}`, action: () => this.talk(p) } };
  }
  talk(p) {
    const pl = this.player.pos;
    p.prevState = p.state; p.state = 'talk'; p.t = 0; p.face = { x: pl.x, z: pl.z }; this.talking = p;
    const zone = regionZone(p.x, p.z) || this.world.zoneName(p.x, p.z);
    const items = [
      { label: '💬 Discuter', action: () => this.say(p, pick(SMALLTALK)) },
      { label: '🧭 Demander son chemin', action: () => setTimeout(() => this.directions(p), 0) },
      { label: '🏘️ Infos sur le quartier', action: () => this.say(p, this.zoneInfo(zone)) },
    ];
    if (p.prof.id === 'commercante') {
      for (const id of ['banane', 'orange', 'mangue']) { const f = FOOD_BY_ID[id]; if (!f) continue; items.push({ label: `🧺 Acheter : ${f.name} (${fcfa(f.price)})`, action: () => { if (this.economy.pay(f.price, `${f.name} (vendeuse ambulante)`, zone)) { this.economy.addToBag(id, 1); this.say(p, 'Merci beaucoup ! C’est bien mûr, tu vas te régaler.'); } } }); }
    }
    items.push({ label: '👋 Au revoir', action: () => this.say(p, pick(BYE)) });
    this.ui.openMenu(`${pick(GREET)}`, `${p.prof.label} • ${zone}`, items, () => this.endTalk());
    this.voice(p);
  }
  say(p, txt) { this.ui.toast(`« ${txt} »`, 4); this.voice(p); }
  voice(p) { const a = this.audio; if (!a || !a.ctx) return; const base = p.c && p.prof.id === 'eleve' ? 320 : 180 + Math.random() * 90; for (let k = 0; k < 4; k++) a.tone(base * (0.9 + Math.random() * 0.3), 0.07, 0.04, 'triangle', a.sfx, k * 0.08); }
  endTalk() { const p = this.talking; this.talking = null; if (p) { p.state = 'walk'; p.cool = 8; p.face = null; } }
  townItem(w) { return w ? { d: w.d + 0.5, it: { label: () => `Parler à ${w.w.prof.label.toLowerCase()}`, action: () => this.talk(w.w) } } : null; }
  directions(p) {
    this.ui.openMenu('Demander son chemin', 'Où veux-tu aller ?', PLACES.map(([n, x, z]) => ({
      label: n, action: () => {
        const dx = x - p.x, dz = z - p.z, d = Math.hypot(dx, dz);
        const txt = d < 25 ? `${n} ? Mais c’est juste ici !` : `${n} ? C’est à environ ${d < 1000 ? Math.round(d / 10) * 10 + ' m' : (d / 1000).toFixed(1).replace('.', ',') + ' km'} vers ${compass(dx, dz)}. ${d > 300 ? 'Prends plutôt un zem ou un taxi (téléphone, touche N).' : 'Tu peux y aller à pied, suis le boulevard.'}`;
        this.say(p, txt);
      },
    })), () => this.endTalk());
  }
  zoneInfo(zone) {
    if (zone === 'Porto-Novo') return 'Porto-Novo, c’est la capitale du Bénin ! Ici c’est plus calme que Cotonou, la ville est belle.';
    if (zone === 'Ouidah') return 'Ouidah est une ville d’histoire : la Route des Esclaves mène à la plage et à la Porte du Non-Retour. Il faut visiter avec respect.';
    if (zone === 'Pahou') return 'Pahou, c’est sur la route de Ouidah. Les voyageurs s’arrêtent ici pour acheter à manger.';
    if (zone === 'Cocotomey') return 'Cocotomey, c’est à l’entrée ouest de Cotonou, côté Abomey-Calavi. Il y a toujours du monde sur la route !';
    if (zone === 'RNIE 1') return 'Ici c’est la RNIE 1, la grande route de la côte. Les camions et les taxis roulent vite, fais attention.';
    if (/Dantokpa/.test(zone)) return 'Ici c’est Dantokpa, le grand marché : on y trouve de tout, il faut négocier les prix !';
    if (/Martyrs/.test(zone)) return 'La place des Martyrs, c’est un lieu de mémoire. Le soir les familles viennent s’y promener.';
    if (/Jardin/.test(zone)) return 'Le jardin est calme, les gens viennent courir ou jouer au foot.';
    if (/Marina|Plage/.test(zone)) return 'La Marina longe la mer. Attention, la baignade est dangereuse avec les vagues.';
    if (/NOVA/.test(zone)) return 'C’est le siège de NOVA BOOK, la maison d’édition. Ils impriment beaucoup de livres !';
    if (/LAGUNA/.test(zone)) return 'Le supermarché LAGUNA est ouvert de 7 h à 22 h, les prix sont fixes là-bas.';
    if (/Quartier/.test(zone)) return `${zone.replace('Quartier ', '')}, c’est un quartier vivant : boutiques, maquis et zems à chaque coin de rue.`;
    return 'Ici à Cotonou, ça bouge du matin au soir. Les zems, les marchés… c’est la vie !';
  }

  // ---- boucle : densité, réveil des passagers, sons ----
  update(dt) {
    this.t -= dt;
    const h = this.env.time, k = this.density.k * hourFactor(h);
    this.traffic.rush = rushFactor(h) * (this.settings.density === 'low' ? 0.6 : 1);
    if (this.t <= 0) {
      this.t = 2;
      const P = this.player.pos;
      this.traffic.setDensity(Math.max(6, Math.round(this.traffic.vehicles.length * k)), P);
      this.peds.setDensity(Math.max(6, Math.round(this.peds.list.length * Math.min(1, k * 1.05))), P);
    }
    for (const p of this.peds.idle) if (p.away > 0) { p.away -= dt; if (p.away <= 0) { p.away = 0; p.c.group.visible = true; } }
    // klaxons des bouchons
    const a = this.audio;
    if (this.traffic.horns.length) { const hn = this.traffic.horns.shift(); this.traffic.horns.length = 0; if (a && a.ctx) a.horn(hn.x, hn.z, hn.kind); }
    // brouhaha de la foule proportionnel au nombre de passants proches
    let n = 0; const P = this.player.pos;
    for (const p of this.peds.list) if (p.active && p.state !== 'inside' && (p.x - P.x) ** 2 + (p.z - P.z) ** 2 < 625) n++;
    this.crowd = Math.min(1, n / 8);
  }
}
