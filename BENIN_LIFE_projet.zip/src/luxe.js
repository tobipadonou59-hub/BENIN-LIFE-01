// Mission 020 — mobilier de luxe de la VILLA NOVA (aile principale, niveau isolé).
// Étape 2 : salon, salle à manger, hall d'entrée et couloirs. Le mobilier est fusionné par « finition » (mat, satiné,
// brillant, métal, verre, lumineux) : ~7 appels de rendu pour toute la villa, couleurs par sommet (performances PC).
// Les tableaux sont des œuvres originales dessinées par le jeu (atlas unique, aucune image externe).
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { colorize } from './vehicles.js';
import { VILLA } from './villa.js';

const PI = Math.PI;
const C = { // palette
  wood: 0x3a2416, walnut: 0x5a3a22, oak: 0x8a6440, marble: 0xece6dc, marbleB: 0x1e1e22, gold: 0xc9a24a, chrome: 0xc8ccd2, leather: 0x6a4630, cognac: 0x8a5a32,
  cream: 0xe9dcc0, ivory: 0xf4eedf, velvet: 0x1f4a3a, burgundy: 0x6a1a2a, navy: 0x1f2a44, sand: 0xd8c8a8, plant: 0x2f7a3a, plant2: 0x3f9a4a, pot: 0xb4532a, potB: 0x2a2d33, warm: 0xffe2a8, glass: 0xa8d8ea,
};
export class Luxe {
  constructor(ctx) {
    Object.assign(this, ctx); // villa, world
    this.parts = { matte: [], satin: [], gloss: [], metal: [], glass: [], glow: [], art: [] }; this.seats = []; this.storage = [];
    this.art = this.artAtlas();
    this.clocks = [];
    this.lighting();
    this.salon(); this.dining(); this.halls(); this.bedrooms(); this.office(); this.kitchen(); this.cinema(); this.games(); this.gym(); this.service();
    this.build();
    this.exterior();
  }
  // ------------------------------------------------------------------ outils
  box(f, x0, y0, z0, x1, y1, z1, c) { this.parts[f].push(colorize(new THREE.BoxGeometry(Math.abs(x1 - x0) || 0.01, Math.abs(y1 - y0) || 0.01, Math.abs(z1 - z0) || 0.01).translate((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), c)); }
  cyl(f, x, y0, z, r0, r1, h, c, seg = 14) { this.parts[f].push(colorize(new THREE.CylinderGeometry(r0, r1, h, seg).translate(x, y0 + h / 2, z), c)); }
  sph(f, x, y, z, r, c, sy = 1) { this.parts[f].push(colorize(new THREE.SphereGeometry(r, 12, 8).scale(1, sy, 1).translate(x, y, z), c)); }
  solid(x0, z0, x1, z1, h = 1) { const o = this.world.collision.addBox(VILLA.O.x + Math.min(x0, x1), VILLA.O.z + Math.min(z0, z1), VILLA.O.x + Math.max(x0, x1), VILLA.O.z + Math.max(z0, z1), VILLA.Y + h); o.lv = VILLA.LV; }
  // objet orienté : f(u, v) en repère local (u : largeur, v : profondeur vers l'avant), rotation ry autour de (x, z)
  rot(x, z, ry) { const c = Math.cos(ry), s = Math.sin(ry); return (u, v) => [x + u * c + v * s, z - u * s + v * c]; }
  obox(f, x, z, ry, u0, y0, v0, u1, y1, v1, c) { const g = new THREE.BoxGeometry(Math.abs(u1 - u0) || 0.01, Math.abs(y1 - y0), Math.abs(v1 - v0) || 0.01).translate((u0 + u1) / 2, (y0 + y1) / 2, (v0 + v1) / 2).rotateY(ry).translate(x, 0, z); this.parts[f].push(colorize(g, c)); }
  build(target = this.villa.inGroup, parts = this.parts, tag = 'luxe') {
    const mats = {
      matte: new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.85 }), satin: new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.5 }),
      gloss: new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.18, metalness: 0.05 }), metal: new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.28, metalness: 0.85 }),
      glass: new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.05, transparent: true, opacity: 0.28, depthWrite: false }), glow: new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false }),
      art: new THREE.MeshBasicMaterial({ map: this.art.tex, toneMapped: false }),
    };
    this.meshes = this.meshes || {};
    this.mats = mats;
    if (target === this.villa.inGroup && parts.glow.length) { // luminaires regroupés par pièce (réglables : ambiance.js) ; écrans et fenêtres non teintés
      const fixed = [0xcfe8f0, 0x6ad0ff, 0xbfe8ff, 0xe8112d, 0x2f80ed].map((h) => new THREE.Color(h)), zones = {}, rooms = Object.values(this.villa.rooms);
      for (const g of parts.glow) { const c = g.attributes.color, col = new THREE.Color(c.getX(0), c.getY(0), c.getZ(0)); g.computeBoundingBox(); const bb = g.boundingBox, x = (bb.min.x + bb.max.x) / 2, z = (bb.min.z + bb.max.z) / 2;
        const isFixed = fixed.some((f) => Math.abs(f.r - col.r) + Math.abs(f.g - col.g) + Math.abs(f.b - col.b) < 0.02), R = rooms.find((q) => x >= q.x0 && x <= q.x1 && z >= q.z0 && z <= q.z1), key = isFixed ? 'fixe' : R ? R.id : 'couloirs'; (zones[key] ||= []).push(g); }
      this.glowByZone = {}; for (const [k, list] of Object.entries(zones)) { const m = new THREE.Mesh(mergeGeometries(list), new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false })); m.name = `luxe_glow_${k}`; target.add(m); this.glowByZone[k] = m; }
      parts = { ...parts, glow: [] };
    }
    for (const [k, list] of Object.entries(parts)) { if (!list.length) continue; const m = new THREE.Mesh(mergeGeometries(list), mats[k]); m.name = `${tag}_${k}`; if (k !== 'glass' && k !== 'glow' && k !== 'art') m.receiveShadow = true; target.add(m); if (target === this.villa.inGroup) this.meshes[k] = m; }
  }
  // ------------------------------------------------------------------ tableaux (atlas de 8 œuvres originales)
  artAtlas() {
    const c = document.createElement('canvas'); c.width = 1024; c.height = 1024; const g = c.getContext('2d'), T = 256;
    const tile = (i, fn) => { g.save(); g.translate((i % 4) * T, Math.floor(i / 4) * T); g.beginPath(); g.rect(0, 0, T, T); g.clip(); fn(g); g.restore(); };
    const sky = (g, a, b) => { const gr = g.createLinearGradient(0, 0, 0, T); gr.addColorStop(0, a); gr.addColorStop(1, b); g.fillStyle = gr; g.fillRect(0, 0, T, T); };
    const palm = (g, x, y, h, col = '#1a1a14') => { g.strokeStyle = col; g.lineWidth = 4; g.beginPath(); g.moveTo(x, y); g.quadraticCurveTo(x + 8, y - h / 2, x + 4, y - h); g.stroke(); g.fillStyle = col; for (let a = 0; a < 6; a++) { g.beginPath(); g.ellipse(x + 4, y - h, 26, 5, a * 0.55, 0, 7); g.fill(); } };
    tile(0, (g) => { sky(g, '#f7b267', '#c8501a'); g.fillStyle = '#ffd27a'; g.beginPath(); g.arc(128, 120, 34, 0, 7); g.fill(); g.fillStyle = '#7a3a1a'; g.fillRect(0, 160, T, 96); g.fillStyle = 'rgba(255,210,122,0.35)'; for (let i = 0; i < 8; i++) g.fillRect(100 - i * 4, 168 + i * 10, 56 + i * 8, 3); g.fillStyle = '#2a140a'; for (const [x, y] of [[60, 190], [170, 205]]) { g.beginPath(); g.moveTo(x - 30, y); g.lineTo(x + 30, y); g.lineTo(x + 22, y + 8); g.lineTo(x - 22, y + 8); g.fill(); g.fillRect(x - 2, y - 26, 3, 26); } for (let i = 0; i < 4; i++) { g.fillRect(i * 64 + 6, 128, 40, 30); g.fillRect(i * 64 + 4, 120, 44, 10); for (let k = 0; k < 4; k++) g.fillRect(i * 64 + 8 + k * 10, 158, 2, 30); } }); // lagune au couchant, maisons sur pilotis et pirogues
    tile(1, (g) => { sky(g, '#7cc6f0', '#d6eef8'); g.fillStyle = '#2a8ab0'; g.fillRect(0, 140, T, 50); g.fillStyle = '#f0dcb0'; g.fillRect(0, 186, T, 70); g.fillStyle = '#fff'; for (let i = 0; i < 5; i++) g.fillRect(i * 56, 182, 34, 3); palm(g, 40, 230, 120); palm(g, 200, 240, 140); palm(g, 150, 236, 95); }); // plage et cocotiers
    tile(2, (g) => { sky(g, '#9fd0ff', '#e8f4ff'); const cols = ['#e8b04a', '#d06a4a', '#5aa0c8', '#e8d8b0', '#7ab06a']; for (let i = 0; i < 5; i++) { g.fillStyle = cols[i]; g.fillRect(i * 52, 90 - (i % 2) * 20, 50, 170); g.fillStyle = '#5a3a22'; g.fillRect(i * 52 + 18, 210, 14, 46); g.fillStyle = '#fff8'; for (let k = 0; k < 2; k++) g.fillRect(i * 52 + 8 + k * 22, 120 - (i % 2) * 20, 12, 18); g.fillStyle = '#7a3a22'; g.beginPath(); g.moveTo(i * 52 - 4, 92 - (i % 2) * 20); g.lineTo(i * 52 + 25, 66 - (i % 2) * 20); g.lineTo(i * 52 + 54, 92 - (i % 2) * 20); g.fill(); } }); // façades colorées d'une ville historique (stylisées)
    tile(3, (g) => { g.fillStyle = '#f2ead8'; g.fillRect(0, 0, T, T); const cols = ['#c8102e', '#fcd116', '#0b6e4f', '#1a1a1a', '#e46a1f']; for (let i = 0; i < 12; i++) { g.fillStyle = cols[i % 5]; const x = (i * 53) % 220, y = (i * 97) % 220; if (i % 3) g.fillRect(x, y, 40 + (i % 4) * 14, 30 + (i % 3) * 20); else { g.beginPath(); g.arc(x + 20, y + 20, 22, 0, 7); g.fill(); } } g.strokeStyle = '#1a1a1a'; g.lineWidth = 5; g.strokeRect(20, 20, 216, 216); }); // composition géométrique contemporaine
    tile(4, (g) => { sky(g, '#e46a1f', '#fcd116'); g.fillStyle = '#3a2416'; g.beginPath(); g.arc(128, 104, 42, 0, 7); g.fill(); g.fillStyle = '#0b6e4f'; g.beginPath(); g.ellipse(128, 70, 56, 26, 0, PI, 0); g.fill(); g.fillStyle = '#1f4e9c'; g.beginPath(); g.moveTo(60, 256); g.quadraticCurveTo(128, 120, 196, 256); g.fill(); g.fillStyle = '#fcd116'; for (let i = 0; i < 6; i++) { g.beginPath(); g.arc(90 + i * 16, 220 - (i % 2) * 14, 5, 0, 7); g.fill(); } }); // portrait stylisé en pagne (personnage imaginaire)
    tile(5, (g) => { g.fillStyle = '#e8d8b8'; g.fillRect(0, 0, T, T); const cols = ['#c8102e', '#fcd116', '#0b6e4f', '#e46a1f', '#1f4e9c', '#7a2a8a']; for (let i = 0; i < 16; i++) { const x = (i % 4) * 64 + 8, y = Math.floor(i / 4) * 64 + 14; g.fillStyle = cols[i % 6]; g.beginPath(); g.moveTo(x, y + 30); g.lineTo(x + 24, y); g.lineTo(x + 48, y + 30); g.fill(); g.fillStyle = '#5a3a22'; g.fillRect(x + 22, y + 30, 4, 18); g.fillStyle = cols[(i + 2) % 6]; g.beginPath(); g.arc(x + 12, y + 46, 6, 0, 7); g.arc(x + 36, y + 46, 6, 0, 7); g.fill(); } }); // marché coloré (parasols et paniers)
    tile(6, (g) => { sky(g, '#f8d090', '#e8a050'); g.fillStyle = '#c89040'; g.fillRect(0, 170, T, 86); g.fillStyle = '#4a2a16'; g.fillRect(118, 110, 22, 70); g.beginPath(); g.moveTo(108, 112); g.lineTo(129, 70); g.lineTo(150, 112); g.fill(); g.fillStyle = '#3a6a2a'; g.beginPath(); g.ellipse(129, 80, 70, 26, 0, 0, 7); g.fill(); for (const x of [30, 210]) { g.fillStyle = '#5a3a1a'; g.fillRect(x, 140, 6, 40); g.fillStyle = '#5a7a3a'; g.beginPath(); g.ellipse(x + 3, 140, 22, 10, 0, 0, 7); g.fill(); } }); // savane du nord et grand arbre
    tile(7, (g) => { g.fillStyle = '#121214'; g.fillRect(0, 0, T, T); g.strokeStyle = '#d8b04a'; for (let i = 0; i < 14; i++) { g.lineWidth = 2 + (i % 3) * 2; g.beginPath(); g.arc(128, 128, 14 + i * 9, i * 0.4, i * 0.4 + 2.2); g.stroke(); } g.fillStyle = '#d8b04a'; g.beginPath(); g.arc(128, 128, 10, 0, 7); g.fill(); }); // abstrait or et noir
    const txt = (g, s, x, y, f = '900 22px Arial', col = '#1a1a1a') => { g.fillStyle = col; g.font = f; g.textAlign = 'center'; g.fillText(s, x, y); g.textAlign = 'left'; };
    tile(8, (g) => { g.fillStyle = '#0b6e4f'; g.fillRect(0, 0, T, T); g.strokeStyle = '#fcd116'; g.lineWidth = 8; g.beginPath(); g.arc(128, 104, 58, 0, 7); g.stroke(); txt(g, 'N', 128, 124, '900 64px Arial', '#fcd116'); txt(g, 'NOVA GROUPE', 128, 200, '900 26px Arial', '#fff'); txt(g, 'Vision • Travail • Excellence', 128, 228, '700 13px Arial', '#e8dcc4'); }); // affiche du groupe (fictif)
    tile(9, (g) => { g.fillStyle = '#f6f0e0'; g.fillRect(0, 0, T, T); g.strokeStyle = '#c9a24a'; g.lineWidth = 10; g.strokeRect(12, 12, T - 24, T - 24); txt(g, 'CERTIFICAT', 128, 70, '900 26px Georgia'); txt(g, 'Prix de l’entrepreneur', 128, 110, '700 17px Georgia'); txt(g, 'de l’année (fictif)', 128, 132, '700 17px Georgia'); g.fillStyle = '#c8102e'; g.beginPath(); g.arc(128, 190, 24, 0, 7); g.fill(); g.fillStyle = '#c9a24a'; g.beginPath(); g.arc(128, 190, 14, 0, 7); g.fill(); }); // distinction encadrée (fictive)
    tile(10, (g) => { g.fillStyle = '#10141c'; g.fillRect(0, 0, T, T); g.strokeStyle = '#2a3446'; g.lineWidth = 1; for (let i = 1; i < 8; i++) { g.beginPath(); g.moveTo(20, i * 30); g.lineTo(236, i * 30); g.stroke(); } const ys = [200, 185, 190, 160, 150, 120, 110, 80, 60]; g.fillStyle = '#1f4e9c'; ys.forEach((y, i) => g.fillRect(28 + i * 24, y, 14, 220 - y)); g.strokeStyle = '#2fd08a'; g.lineWidth = 4; g.beginPath(); ys.forEach((y, i) => (i ? g.lineTo(35 + i * 24, y - 20) : g.moveTo(35, y - 20))); g.stroke(); txt(g, 'Croissance du groupe (fictif)', 128, 245, '700 14px Arial', '#e8dcc4'); }); // graphique
    tile(11, (g) => { g.fillStyle = '#1f4e9c'; g.fillRect(0, 0, T, T); g.strokeStyle = '#d6e6f2'; g.lineWidth = 2; g.strokeRect(30, 40, 196, 150); g.strokeRect(30, 40, 90, 70); g.strokeRect(120, 40, 106, 110); g.strokeRect(30, 110, 90, 80); g.beginPath(); g.arc(120, 150, 30, -PI / 2, 0); g.stroke(); txt(g, 'VILLA NOVA — plan', 128, 222, '700 16px Arial', '#d6e6f2'); }); // plan d'architecte
    tile(12, (g) => { sky(g, '#9fd0ff', '#f0e0b0'); g.fillStyle = '#e8d8b0'; g.fillRect(0, 196, T, 60); g.fillStyle = '#a07a50'; g.fillRect(70, 70, 116, 126); g.fillStyle = '#9fd0ff'; g.fillRect(100, 110, 56, 86); g.beginPath(); g.arc(128, 110, 28, PI, 0); g.fill(); g.fillStyle = '#7a5a3a'; for (let i = 0; i < 5; i++) g.fillRect(76 + i * 22, 78, 14, 20); txt(g, 'Arche du souvenir (illustration)', 128, 240, '700 13px Arial'); }); // arche commémorative au bord de mer (illustration)
    tile(13, (g) => { sky(g, '#bfe0f4', '#e8f4fa'); g.fillStyle = '#3a8ab0'; g.fillRect(0, 150, T, 106); for (let i = 0; i < 4; i++) { const x = 20 + i * 60; g.fillStyle = '#6a4a2a'; for (let k = 0; k < 4; k++) g.fillRect(x + 4 + k * 12, 120, 3, 60); g.fillStyle = '#8a6a3a'; g.fillRect(x, 92, 52, 30); g.fillStyle = '#5a3a1a'; g.beginPath(); g.moveTo(x - 6, 94); g.lineTo(x + 26, 66); g.lineTo(x + 58, 94); g.fill(); } g.fillStyle = '#2a140a'; g.fillRect(90, 205, 70, 7); }); // village sur pilotis
    tile(14, (g) => { sky(g, '#0a1030', '#2a2a5a'); for (let i = 0; i < 9; i++) { const h = 40 + ((i * 37) % 90), x = i * 29; g.fillStyle = '#141824'; g.fillRect(x, 230 - h, 26, h + 26); g.fillStyle = '#ffd27a'; for (let k = 0; k < 6; k++) if ((i + k) % 3) g.fillRect(x + 5 + (k % 2) * 10, 236 - h + Math.floor(k / 2) * 16, 5, 6); } g.fillStyle = '#ffd27a33'; g.fillRect(0, 230, T, 26); g.fillStyle = '#fff'; g.beginPath(); g.arc(200, 40, 12, 0, 7); g.fill(); }); // la ville la nuit
    tile(15, (g) => { sky(g, '#9fd0ff', '#f6efe0'); g.fillStyle = '#e8c070'; g.fillRect(40, 90, 176, 140); g.fillStyle = '#c86a4a'; g.fillRect(40, 84, 176, 12); for (let i = 0; i < 5; i++) { g.fillStyle = ['#2f9a6a', '#1f6ab0', '#c8102e', '#2f9a6a', '#1f6ab0'][i]; g.fillRect(52 + i * 32, 130, 20, 50); g.beginPath(); g.arc(62 + i * 32, 130, 10, PI, 0); g.fill(); } g.fillStyle = '#e8c070'; g.fillRect(118, 50, 20, 40); g.beginPath(); g.arc(128, 50, 12, PI, 0); g.fill(); }); // façade afro-brésilienne stylisée
    const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 4;
    return { tex, names: ['Coucher de soleil sur la lagune', 'Plage et cocotiers', 'Façades colorées', 'Composition contemporaine', 'Portrait en pagne', 'Le marché coloré', 'La savane du nord', 'Or et nuit', 'Affiche NOVA GROUPE', 'Certificat (fictif)', 'Graphique de croissance', 'Plan de la villa', 'Arche du souvenir (illustration)', 'Village sur pilotis', 'La ville la nuit', 'Façade afro-brésilienne'] };
  }
  // tableau encadré (i : œuvre de l'atlas), centré en (x, y, z), orienté vers ry, largeur w, hauteur h
  painting(x, y, z, ry, w, h, i, frame = C.gold) {
    const T = 0.04, nx = Math.sin(ry), nz = Math.cos(ry), u0 = (i % 4) / 4, v1 = 1 - Math.floor(i / 4) / 4, v0 = v1 - 0.25;
    const pl = new THREE.PlaneGeometry(w, h); const uv = pl.attributes.uv; for (let k = 0; k < uv.count; k++) uv.setXY(k, u0 + uv.getX(k) * 0.25, v0 + uv.getY(k) * 0.25);
    pl.rotateY(ry).translate(x + nx * (T + 0.012), y, z + nz * (T + 0.012)); this.parts.art.push(pl);
    this.obox('metal', x, z, ry, -w / 2 - 0.06, y - h / 2 - 0.06, 0, w / 2 + 0.06, y + h / 2 + 0.06, T, frame);
  }
  plant(x, z, s = 1, big = false) {
    this.cyl('satin', x, 0, z, 0.26 * s, 0.2 * s, 0.55 * s, big ? C.potB : C.pot); this.cyl('matte', x, 0.4 * s, z, 0.04, 0.05, (big ? 1.4 : 0.8) * s, C.wood, 6);
    for (let k = 0; k < (big ? 7 : 5); k++) { const a = k * 1.3, r = 0.18 * s; this.sph('matte', x + Math.cos(a) * r, (big ? 1.5 : 1.0) * s + (k % 3) * 0.16 * s, z + Math.sin(a) * r, 0.32 * s, k % 2 ? C.plant : C.plant2, 0.7); }
    this.solid(x - 0.28 * s, z - 0.28 * s, x + 0.28 * s, z + 0.28 * s, 1.2);
  }
  sconce(x, y, z, ry) { this.obox('metal', x, z, ry, -0.08, y - 0.12, 0, 0.08, y + 0.12, 0.06, C.gold); this.obox('glow', x, z, ry, -0.06, y + 0.12, 0.02, 0.06, y + 0.24, 0.12, C.warm); }
  sofa(x, z, ry, len, col, deep = 0.95, arm = true) { // canapé (cadre, assise, dossier, accoudoirs, coussins)
    const L = len / 2; this.obox('satin', x, z, ry, -L, 0.08, -deep / 2, L, 0.42, deep / 2, col); this.obox('satin', x, z, ry, -L, 0.42, -deep / 2, L, 1.0, -deep / 2 + 0.24, col);
    if (arm) for (const s of [-1, 1]) this.obox('satin', x, z, ry, s * L - (s > 0 ? 0.2 : 0), 0.42, -deep / 2, s * L + (s > 0 ? 0 : 0.2), 0.68, deep / 2, col);
    const n = Math.max(2, Math.round(len / 0.9)); for (let k = 0; k < n; k++) { const u = -L + 0.25 + (k + 0.5) * ((len - 0.5) / n); this.obox('satin', x, z, ry, u - (len - 0.5) / n / 2 + 0.03, 0.42, -deep / 2 + 0.26, u + (len - 0.5) / n / 2 - 0.03, 0.55, deep / 2 - 0.04, C.cream); this.seats.push({ ...this.at(x, z, ry, u, 0.1), ry, kind: len <= 1.1 ? 'fauteuil' : 'canapé' }); }
    for (const s of [-1, 1]) for (const v of [-deep / 2 + 0.08, deep / 2 - 0.08]) this.obox('metal', x, z, ry, s * (L - 0.1) - 0.03, 0, v - 0.03, s * (L - 0.1) + 0.03, 0.08, v + 0.03, C.gold);
    const p = this.rot(x, z, ry), a = p(-L, -deep / 2), b = p(L, deep / 2); this.solid(Math.min(a[0], b[0]), Math.min(a[1], b[1]), Math.max(a[0], b[0]), Math.max(a[1], b[1]), 1.0);
  }
  at(x, z, ry, u, v) { const [px, pz] = this.rot(x, z, ry)(u, v); return { x: px, z: pz }; }
  armchair(x, z, ry, col) { this.sofa(x, z, ry, 1.0, col, 0.9, true); }
  sideTable(x, z, r = 0.32, h = 0.55, top = C.marble) { this.cyl('gloss', x, h - 0.04, z, r, r, 0.04, top); this.cyl('metal', x, 0, z, 0.04, 0.05, h - 0.04, C.gold, 8); this.cyl('metal', x, 0, z, r * 0.6, r * 0.6, 0.02, C.gold); this.solid(x - r, z - r, x + r, z + r, h); }
  lamp(x, y, z) { this.cyl('metal', x, y, z, 0.06, 0.09, 0.32, C.gold, 10); this.cyl('glow', x, y + 0.3, z, 0.12, 0.18, 0.24, C.warm, 14); }
  vase(x, y, z, c = C.ivory) { this.sph('gloss', x, y + 0.18, z, 0.13, c, 1.4); this.cyl('gloss', x, y + 0.3, z, 0.05, 0.07, 0.14, c, 10); for (let k = 0; k < 4; k++) this.sph('matte', x + Math.cos(k * 1.6) * 0.06, y + 0.5 + (k % 2) * 0.08, z + Math.sin(k * 1.6) * 0.06, 0.07, [0xe8112d, 0xfcd116, 0xf6f6f6, 0xe46a1f][k]); }
  books(x0, y, z0, x1, z1, seed = 1) { // rangée de livres le long d'une étagère (axe x ou z)
    const alongX = Math.abs(x1 - x0) > Math.abs(z1 - z0), L = alongX ? x1 - x0 : z1 - z0; let t = 0, k = seed;
    const cols = [0x6a1a2a, 0x1f2a44, 0x0b6e4f, 0xd8a830, 0xe8dcc4, 0x3a2416, 0x8a2a1a, 0x2a4a6a];
    while (t < L - 0.1) { k = (k * 9301 + 49297) % 233280; const w = 0.035 + (k % 5) * 0.012, h = 0.24 + (k % 7) * 0.03; if (k % 11 === 0) { t += 0.18; continue; } const d = alongX ? [x0 + t, z0 - 0.12, x0 + t + w, z0 + 0.12] : [x0 - 0.12, z0 + t, x0 + 0.12, z0 + t + w]; this.box('matte', d[0], y, d[1], d[2], y + h, d[3], cols[k % cols.length]); t += w + 0.006; }
  }
  bookcase(x0, z0, x1, z1, h = 2.8, seed = 1) { // grande bibliothèque contre un mur
    const alongX = Math.abs(x1 - x0) > Math.abs(z1 - z0); this.box('satin', x0, 0, z0, x1, h, z1, C.walnut);
    const n = 6; for (let s = 0; s < n; s++) { const y = 0.12 + s * ((h - 0.2) / n); this.box('satin', x0 - (alongX ? 0 : 0.01), y, z0, x1, y + 0.03, z1, C.oak); if (s > 0) { if (alongX) this.books(x0 + 0.1, y + 0.03, (z0 + z1) / 2 + (z1 > z0 ? 0.06 : -0.06) * 0, x1 - 0.1, (z0 + z1) / 2, seed + s); else this.books((x0 + x1) / 2, y + 0.03, z0 + 0.1, (x0 + x1) / 2, z1 - 0.1, seed + s); } }
    this.solid(Math.min(x0, x1), Math.min(z0, z1), Math.max(x0, x1), Math.max(z0, z1), h);
  }
  vitrine(x0, z0, x1, z1, h = 2.2) { // vitrine décorative : cadre doré, verre, étagères éclairées, objets
    this.box('metal', x0, 0, z0, x1, 0.12, z1, C.gold); this.box('metal', x0, h - 0.08, z0, x1, h, z1, C.gold); this.box('glass', x0 + 0.02, 0.12, z0 + 0.02, x1 - 0.02, h - 0.08, z1 - 0.02, C.glass);
    const alongX = Math.abs(x1 - x0) > Math.abs(z1 - z0), L = alongX ? x1 - x0 : z1 - z0;
    for (let s = 1; s <= 3; s++) { const y = s * (h / 4); this.box('glass', x0 + 0.03, y, z0 + 0.03, x1 - 0.03, y + 0.02, z1 - 0.03, 0xffffff); this.box('glow', x0 + 0.05, y - 0.02, z0 + 0.05, x1 - 0.05, y, z1 - 0.05, C.warm); for (let k = 0; k < 3; k++) { const t = (k + 0.5) / 3; const px = alongX ? x0 + t * L : (x0 + x1) / 2, pz = alongX ? (z0 + z1) / 2 : z0 + t * L; if ((s + k) % 2) this.sph('gloss', px, y + 0.14, pz, 0.1, [C.gold, 0x1f4e9c, C.ivory][k], 1.3); else this.cyl('gloss', px, y + 0.02, pz, 0.07, 0.09, 0.26, [C.ivory, C.burgundy, C.gold][k], 10); } }
    this.solid(Math.min(x0, x1), Math.min(z0, z1), Math.max(x0, x1), Math.max(z0, z1), h);
  }
  rug(x0, z0, x1, z1, c, border = C.gold) { this.box('matte', x0, 0.021, z0, x1, 0.03, z1, border); this.box('matte', x0 + 0.18, 0.022, z0 + 0.18, x1 - 0.18, 0.032, z1 - 0.18, c); this.box('matte', x0 + 0.45, 0.023, z0 + 0.45, x1 - 0.45, 0.034, z1 - 0.45, border); this.box('matte', x0 + 0.5, 0.024, z0 + 0.5, x1 - 0.5, 0.035, z1 - 0.5, c); }
  chandelier(x, z, y = 3.05, r = 0.9) { this.cyl('metal', x, y - 0.5, z, 0.02, 0.02, 0.5, C.gold, 6); for (const [rr, yy] of [[r, y - 0.62], [r * 0.6, y - 0.78]]) { this.parts.metal.push(colorize(new THREE.TorusGeometry(rr, 0.025, 6, 32).rotateX(PI / 2).translate(x, yy, z), C.gold)); for (let k = 0; k < 10; k++) { const a = k * PI / 5; this.sph('glow', x + Math.cos(a) * rr, yy - 0.06, z + Math.sin(a) * rr, 0.05, C.warm); this.box('glass', x + Math.cos(a) * rr - 0.01, yy - 0.3, z + Math.sin(a) * rr - 0.01, x + Math.cos(a) * rr + 0.01, yy - 0.08, z + Math.sin(a) * rr + 0.01, 0xffffff); } } }
  // ------------------------------------------------------------------ salon principal (Smart TV et canapé d'angle : novatv.js)
  salon() {
    const R = this.villa.rooms.salon; if (!R) return; const { x0, z0, x1, z1 } = R;
    this.rug(-31.6, z0 + 1.5, -24.6, z0 + 8.6, 0xe8dcc4, C.gold);              // grand tapis du coin TV
    this.rug(-31.8, 18.6, -24.2, 24.8, C.burgundy, C.gold);                    // tapis du salon de réception
    // salon de réception : canapés existants + fauteuils de luxe, tables d'appoint, lampes
    this.armchair(-28.9, 17.6, 0, C.velvet); this.armchair(-27.1, 17.6, 0, C.velvet); // passages libres de chaque côté vers les canapés
    this.sideTable(-24.9, z0 + 5.6, 0.3); this.lamp(-24.9, 0.55, z0 + 5.6); this.sideTable(-31.0, 23.5, 0.28); this.lamp(-31.0, 0.55, 23.5); this.sideTable(-25.0, 23.5, 0.28);
    // coin lecture (fauteuils face à face, guéridon), grande bibliothèque murale
    this.armchair(-22.8, 20.6, PI / 2, C.cognac); this.armchair(-19.8, 20.6, -PI / 2, C.cognac); this.sideTable(-21.3, 20.6, 0.36, 0.5, C.marbleB); this.vase(-21.3, 0.5, 20.6);
    this.bookcase(-24.3, z1 - 0.55, -19.9, z1 - 0.1, 2.8, 3);
    // mur ouest : vitrines et bibliothèque
    this.vitrine(x0 + 0.1, z0 + 1.0, x0 + 0.6, z0 + 2.8); this.bookcase(x0 + 0.1, 16.4, x0 + 0.55, 21.4, 2.8, 7); this.vitrine(x0 + 0.1, 23.3, x0 + 0.6, 25.1);
    // console d'entrée, miroir, plantes
    this.box('gloss', -23.7, 0.78, z0 + 0.12, -21.3, 0.84, z0 + 0.55, C.marble); for (const x of [-23.6, -21.4]) this.box('metal', x - 0.04, 0, z0 + 0.15, x + 0.04, 0.78, z0 + 0.5, C.gold); this.solid(-23.7, z0 + 0.1, -21.3, z0 + 0.56, 0.85); this.vase(-22.1, 0.84, z0 + 0.33); this.lamp(-23.2, 0.84, z0 + 0.33);
    this.box('metal', -23.3, 1.25, z0 + 0.1, -21.7, 2.45, z0 + 0.14, C.gold); this.box('gloss', -23.22, 1.33, z0 + 0.14, -21.78, 2.37, z0 + 0.15, 0xd8e4ea);
    this.plant(x0 + 0.7, z0 + 4.0, 1.1, true); this.plant(-20.7, z0 + 0.8, 0.9); this.plant(-19.3, z1 - 0.7, 1.15, true);
    // baie vitrée du jardin (vue lumineuse) et grands rideaux
    this.box('glow', -31.3, 0.7, z1 - 0.1, -26.7, 2.9, z1 - 0.08, 0xcfe8f0); this.box('metal', -31.4, 2.95, z1 - 0.2, -26.6, 3.0, z1 - 0.15, C.gold);
    for (const [a, b] of [[-31.9, -31.25], [-26.75, -26.1]]) for (let k = 0; k < 4; k++) this.box('satin', a + k * (b - a) / 4, 0.02, z1 - 0.26 + (k % 2) * 0.06, a + (k + 1) * (b - a) / 4, 2.95, z1 - 0.16 + (k % 2) * 0.06, C.burgundy);
    // œuvres d'art
    this.painting(-21.6, 1.9, z1 - 0.1, PI, 2.0, 1.2, 0); this.painting(x1 - 0.12, 2.25, 15.0, -PI / 2, 1.6, 1.0, 6);
    this.chandelier(-28.0, 21.4); this.chandelier(-28.0, 15.0, 3.05, 0.7);
    for (const z of [12.5, 17.5, 22.5]) this.sconce(x1 - 0.1, 2.3, z, -PI / 2);
  }
  // ------------------------------------------------------------------ salle à manger
  dining() {
    const R = this.villa.rooms.manger; if (!R) return; const { x0, z0, x1, z1, cx } = R, tz = (z0 + z1) / 2;
    this.rug(cx - 2.6, tz - 4.4, cx + 2.6, tz + 4.4, C.navy, C.gold);
    // grande table familiale 12 places (plateau noyer et marbre, deux piètements), même emprise que la table d'origine
    this.box('gloss', cx - 1.1, 0.74, tz - 3.3, cx + 1.1, 0.8, tz + 3.3, C.walnut); this.box('gloss', cx - 0.35, 0.8, tz - 3.0, cx + 0.35, 0.805, tz + 3.0, C.marble);
    for (const s of [-1, 1]) { this.box('metal', cx - 0.7, 0, tz + s * 2.0 - 0.18, cx + 0.7, 0.06, tz + s * 2.0 + 0.18, C.gold); this.box('satin', cx - 0.12, 0.06, tz + s * 2.0 - 0.12, cx + 0.12, 0.74, tz + s * 2.0 + 0.12, C.wood); }
    for (let k = 0; k < 6; k++) for (const s of [-1, 1]) {
      const z = tz - 2.7 + k * 1.08, x = cx + s * 1.45, ry = s > 0 ? -PI / 2 : PI / 2; // chaises rembourrées face à la table
      this.obox('satin', x, z, ry, -0.24, 0.42, -0.24, 0.24, 0.52, 0.24, C.cream); this.obox('satin', x, z, ry, -0.24, 0.52, -0.3, 0.24, 1.15, -0.22, C.cream); this.obox('metal', x, z, ry, -0.25, 1.1, -0.31, 0.25, 1.16, -0.21, C.gold);
      for (const [u, v] of [[-0.2, -0.2], [0.2, -0.2], [-0.2, 0.2], [0.2, 0.2]]) this.obox('satin', x, z, ry, u - 0.025, 0, v - 0.025, u + 0.025, 0.42, v + 0.025, C.wood);
      this.cyl('gloss', cx + s * 0.62, 0.8, z, 0.15, 0.15, 0.015, 0xf6f6f6, 16); this.cyl('glass', cx + s * 0.78, 0.8, z + 0.18, 0.035, 0.03, 0.14, C.glass, 8); this.seats.push({ x, z, ry, kind: 'chaise' });
    }
    for (let k = 0; k < 3; k++) { this.vase(cx, 0.805, tz - 2 + k * 2, [C.ivory, C.gold, C.ivory][k]); }
    // grand buffet (mur ouest), vitrine à vaisselle (mur est), décoration murale, lustre linéaire
    this.box('satin', x0 + 0.1, 0, tz - 3, x0 + 0.62, 0.9, tz + 3, C.wood); this.box('gloss', x0 + 0.08, 0.9, tz - 3.05, x0 + 0.66, 0.95, tz + 3.05, C.marbleB); for (let k = 0; k < 6; k++) this.box('metal', x0 + 0.62, 0.42, tz - 2.6 + k * 1.0, x0 + 0.64, 0.5, tz - 2.3 + k * 1.0, C.gold); this.solid(x0 + 0.08, tz - 3.05, x0 + 0.66, tz + 3.05, 0.95);
    this.storage.push({ id: 'buffet', name: 'grand buffet de la salle à manger', x: x0 + 1.25, z: tz }); this.lamp(x0 + 0.35, 0.95, tz - 2.4); this.lamp(x0 + 0.35, 0.95, tz + 2.4); this.sph('gloss', x0 + 0.35, 1.08, tz, 0.16, C.gold, 0.5);
    this.vitrine(x1 - 0.62, z0 + 1.6, x1 - 0.1, z0 + 4.8, 2.3); for (let s = 1; s <= 3; s++) for (let k = 0; k < 6; k++) this.cyl('gloss', x1 - 0.36, s * 0.575 + 0.02, z0 + 1.9 + k * 0.5, 0.16, 0.16, 0.012, 0xf8f8f8, 14);
    this.vitrine(x1 - 0.62, z1 - 4.8, x1 - 0.1, z1 - 1.6, 2.3);
    this.painting(cx, 1.95, z1 - 0.1, PI, 3.0, 1.6, 1); this.painting(x0 + 0.12, 2.15, tz - 1.6, PI / 2, 1.2, 0.9, 4); this.painting(x0 + 0.12, 2.15, tz + 1.6, PI / 2, 1.2, 0.9, 5);
    this.box('metal', cx - 0.05, 2.35, tz - 2.6, cx + 0.05, 2.4, tz + 2.6, C.gold); this.box('metal', cx - 0.01, 2.4, tz - 0.01, cx + 0.01, 3.2, tz + 0.01, C.gold);
    for (let k = 0; k < 7; k++) { const z = tz - 2.4 + k * 0.8; this.box('metal', cx - 0.005, 2.0, z - 0.005, cx + 0.005, 2.35, z + 0.005, C.gold); this.cyl('glow', cx, 1.82, z, 0.07, 0.11, 0.2, C.warm, 12); }
    this.plant(x0 + 0.7, z1 - 0.7, 1.1, true); this.plant(x1 - 0.7, z1 - 0.7, 1.1, true); this.plant(x1 - 0.7, z0 + 0.8, 0.85);
    for (const z of [13, 23]) this.sconce(x0 + 0.1, 2.3, z, PI / 2);
  }
  // ------------------------------------------------------------------ chambres (9, dont la suite) : repère de la pièce
  // u : travers (−w/2 … w/2, ouest → est), v : profondeur depuis la porte (0 … d) ; le lit, l'armoire, le bureau, la TV murale
  // et la salle de bain privée d'origine sont conservés (villa.js) ; on ajoute autour sans bloquer les accès.
  frame(R) { const w = R.x1 - R.x0, d = R.z1 - R.z0, sgn = R.z0 === 10 ? 1 : -1, F = (u, v) => [R.cx + u, R.z0 === 10 ? R.z0 + v : R.z1 - v]; return { w, d, sgn, F, back: sgn > 0 ? 0 : PI, door: sgn > 0 ? PI : 0 }; }
  bedrooms() {
    for (const R of Object.values(this.villa.rooms)) {
      if (R.type !== 'chambre' && R.type !== 'suite') continue;
      const { w, d, sgn, F, back, door } = this.frame(R), suite = R.type === 'suite', kid = /^enf/.test(R.id), bw = suite ? 2.4 : 1.6, bc = -w / 2 + bw / 2 + 1.0, bL = bc - bw / 2, bR = bc + bw / 2;
      const P = (u, v) => F(u, v), wood = suite ? C.wood : kid ? C.oak : C.walnut;
      // tapis sous le lit
      { const [ax, az] = P(bL - 0.6, d - 4.7), [bx2, bz2] = P(bR + 0.9, d - 0.9); this.rug(Math.min(ax, bx2), Math.min(az, bz2), Math.max(ax, bx2), Math.max(az, bz2), kid ? [0x2f80ed, 0xe46a1f, 0x0b8a8a][+R.id.slice(3) % 3] : suite ? C.cream : C.sand, kid ? C.ivory : C.gold); }
      // lit : grande tête de lit capitonnée, oreillers, plaid, banc en bout de lit
      { const [hx, hz] = P(bc, d - 1.05); this.obox('satin', hx, hz, back, -bw / 2 - 0.25, 0.4, -0.06, bw / 2 + 0.25, suite ? 1.9 : 1.6, 0.06, suite ? C.cream : kid ? 0xf2e6c8 : C.sand); for (let k = 0; k < (suite ? 5 : 3); k++) { const uu = -bw / 2 + 0.05 + (k + 0.5) * ((bw + 0.4) / (suite ? 5 : 3)) - 0.2; this.obox('metal', hx, hz, back, uu - 0.01, 0.55, -0.075, uu + 0.01, suite ? 1.8 : 1.5, -0.065, C.gold); } }
      for (let k = 0; k < (suite ? 3 : 2); k++) { const uu = bL + (k + 0.5) * (bw / (suite ? 3 : 2)), [px, pz] = P(uu, d - 1.45); this.obox('satin', px, pz, back, -0.32, 0.62, -0.18, 0.32, 0.8, 0.18, C.ivory); }
      { const [px, pz] = P(bc, d - 3.0); this.obox('satin', px, pz, back, -bw / 2 - 0.02, 0.6, -0.3, bw / 2 + 0.02, 0.7, 0.3, suite ? C.gold : kid ? 0xfcd116 : C.burgundy); }
      { const [px, pz] = P(bc, d - 3.75); this.obox('satin', px, pz, back, -bw / 2 + 0.1, 0.32, -0.2, bw / 2 - 0.1, 0.48, 0.2, suite ? C.velvet : C.cream); for (const s of [-1, 1]) this.obox('metal', px, pz, back, s * (bw / 2 - 0.2) - 0.03, 0, -0.15, s * (bw / 2 - 0.2) + 0.03, 0.32, 0.15, C.gold); const a = P(bL + 0.1, d - 3.95), b = P(bR - 0.1, d - 3.55); this.solid(Math.min(a[0], b[0]), Math.min(a[1], b[1]), Math.max(a[0], b[0]), Math.max(a[1], b[1]), 0.5); this.seats.push({ x: px, z: pz, ry: door, kind: 'banc' }); }
      // tables de chevet (à droite : sous la lampe d'ambiance d'origine)
      for (const u of [bL - 0.42, bc + 1.5]) { const [nx, nz] = P(u, d - 1.3); this.box('satin', nx - 0.27, 0, nz - 0.22, nx + 0.27, 0.58, nz + 0.22, wood); this.box('gloss', nx - 0.29, 0.58, nz - 0.24, nx + 0.29, 0.62, nz + 0.24, C.marble); this.box('metal', nx - 0.1, 0.36, nz - 0.23 * sgn - 0.005, nx + 0.1, 0.38, nz - 0.23 * sgn + 0.005, C.gold); this.solid(nx - 0.29, nz - 0.24, nx + 0.29, nz + 0.24, 0.62); if (u < bc) this.lamp(nx, 0.62, nz); else this.cyl('metal', nx, 0.62, nz, 0.04, 0.06, 0.14, C.gold, 8); }
      // tableau au-dessus du lit, fenêtre et rideaux sur le mur du fond
      { const [px, pz] = P(bc, d - 0.13); this.painting(px, 2.35, pz, door, Math.min(1.8, bw + 0.2), 0.7, kid ? 3 : suite ? 0 : [1, 6, 2, 5, 4, 7, 13][(R.x0 + 40) % 7]); }
      { const u0 = Math.max(bc + 1.95, suite ? 2.0 : -9), u1 = w / 2 - 1.2; if (u1 - u0 > 1.6) { const wc = (u0 + u1) / 2, ww = Math.min(2.4, u1 - u0 - 0.6), [gx, gz] = P(wc, d - 0.1); this.obox('glow', gx, gz, door, -ww / 2, 0.8, -0.01, ww / 2, 2.8, 0.01, 0xcfe8f0); this.obox('metal', gx, gz, door, -ww / 2 - 0.5, 2.85, 0.02, ww / 2 + 0.5, 2.9, 0.08, C.gold); for (const s of [-1, 1]) for (let k = 0; k < 3; k++) this.obox('satin', gx, gz, door, s * (ww / 2 + 0.08 + k * 0.14) - 0.07, 0.02, 0.06 + (k % 2) * 0.05, s * (ww / 2 + 0.08 + k * 0.14) + 0.07, 2.85, 0.12 + (k % 2) * 0.05, kid ? 0x5aa0c8 : suite ? C.cream : C.burgundy); } }
      // mur est : commode et miroir, dressing ouvert, fauteuil de lecture et lampadaire
      { const [cx2, cz2] = P(w / 2 - 0.4, d / 2 - 0.5), L = 1.0; this.box('satin', cx2 - 0.25, 0, cz2 - L, cx2 + 0.25, 0.85, cz2 + L, wood); this.box('gloss', cx2 - 0.27, 0.85, cz2 - L - 0.02, cx2 + 0.27, 0.89, cz2 + L + 0.02, C.marble); for (let k = 0; k < 3; k++) for (const s of [-1, 1]) this.box('metal', cx2 - 0.26, 0.2 + k * 0.25, cz2 + s * 0.5 - 0.08, cx2 - 0.255, 0.23 + k * 0.25, cz2 + s * 0.5 + 0.08, C.gold); this.solid(cx2 - 0.27, cz2 - L - 0.02, cx2 + 0.27, cz2 + L + 0.02, 0.9); this.vase(cx2, 0.89, cz2 + 0.5); { const [sx, sz] = P(w / 2 - 1.05, d / 2 - 0.5); this.storage.push({ id: `${R.id}_commode`, name: `commode — ${R.name.toLowerCase()}`, x: sx, z: sz }); } this.box('metal', cx2 + 0.2, 1.2, cz2 - 0.8, cx2 + 0.24, 2.5, cz2 + 0.8, C.gold); this.box('gloss', cx2 + 0.18, 1.27, cz2 - 0.73, cx2 + 0.2, 2.43, cz2 + 0.73, 0xd8e4ea); }
      { const [dx, dz] = P(w / 2 - 0.4, d - 4.3); this.box('satin', dx - 0.3, 0, dz - 1.05, dx + 0.3, 2.3, dz + 1.05, wood); this.box('satin', dx - 0.28, 0.05, dz - 1.0, dx + 0.0, 2.25, dz + 1.0, 0x2a1a10); this.box('metal', dx - 0.2, 1.85, dz - 0.95, dx - 0.17, 1.88, dz + 0.95, C.chrome); for (let k = 0; k < 8; k++) this.box('matte', dx - 0.24, 1.0 + (k % 3) * 0.06, dz - 0.9 + k * 0.23, dx - 0.12, 1.84, dz - 0.75 + k * 0.23, [C.navy, C.ivory, C.burgundy, 0x2f80ed, C.sand, 0x1a1a1a, C.velvet, C.gold][k]); for (let k = 0; k < 4; k++) this.box('matte', dx - 0.25, 0.12 + k * 0.03, dz - 0.9 + k * 0.4, dx - 0.05, 0.22 + k * 0.03, dz - 0.6 + k * 0.4, [0x1a1a1a, 0x6a4630, C.ivory, C.burgundy][k]); this.solid(dx - 0.3, dz - 1.05, dx + 0.3, dz + 1.05, 2.3); const [sx, sz] = P(w / 2 - 1.05, d - 4.3); this.storage.push({ id: `${R.id}_dressing`, name: `dressing — ${R.name.toLowerCase()}`, x: sx, z: sz }); }
      { const [cx3, cz3] = P(w / 2 - 1.35, 1.6); this.obox('satin', cx3, cz3, PI / 2, -0.22, 0.42, -0.22, 0.22, 0.52, 0.22, C.cream); this.obox('satin', cx3, cz3, PI / 2, -0.22, 0.52, -0.28, 0.22, 1.0, -0.2, C.cream); this.cyl('metal', cx3, 0, cz3, 0.025, 0.025, 0.42, C.chrome, 6); this.seats.push({ x: cx3, z: cz3, ry: PI / 2, kind: 'chaise de bureau' }); }
      { const [ax, az] = P(w / 2 - 1.6, d / 2 + 1.5); this.armchair(ax, az, -PI / 2, suite ? C.velvet : kid ? 0xe46a1f : C.cognac); const [lx, lz] = P(w / 2 - 0.45, d / 2 + 1.95); this.cyl('metal', lx, 0, lz, 0.14, 0.16, 0.04, C.gold); this.cyl('metal', lx, 0.04, lz, 0.02, 0.02, 1.45, C.gold, 6); this.cyl('glow', lx, 1.45, lz, 0.16, 0.22, 0.3, C.warm); this.solid(lx - 0.16, lz - 0.16, lx + 0.16, lz + 0.16, 1.7); }
      // meuble TV sous l'écran mural (mur ouest)
      { const [tx, tz] = P(-w / 2 + 0.32, d / 2 - 0.4); this.box('satin', tx - 0.22, 0, tz - 1.0, tx + 0.22, 0.5, tz + 1.0, wood); this.box('gloss', tx - 0.24, 0.5, tz - 1.02, tx + 0.24, 0.53, tz + 1.02, C.marbleB); this.solid(tx - 0.24, tz - 1.02, tx + 0.24, tz + 1.02, 0.55); }
      if (kid) { const [kx, kz] = P(-w / 2 + 0.45, d / 2 + 2.6); this.box('satin', kx - 0.3, 0, kz - 0.5, kx + 0.3, 0.5, kz + 0.5, [0x2f80ed, 0xe8112d, 0x0b8a8a][+R.id.slice(3) % 3]); for (let k = 0; k < 4; k++) this.sph('gloss', kx + (k % 2 - 0.5) * 0.25, 0.6, kz - 0.3 + k * 0.2, 0.09, [0xfcd116, 0xe8112d, 0x2fd08a, 0x3aa0ff][k]); this.solid(kx - 0.3, kz - 0.5, kx + 0.3, kz + 0.5, 0.6); }
      if (suite) { // causeuse face à la TV, table basse, coiffeuse avec miroir
        const [sx, sz] = P(-1.0, d / 2 - 0.4); this.sofa(sx, sz, -PI / 2, 2.2, C.cream, 0.9); const [tx, tz] = P(-2.4, d / 2 - 0.4); this.box('gloss', tx - 0.4, 0.36, tz - 0.6, tx + 0.4, 0.42, tz + 0.6, C.marble); this.box('metal', tx - 0.3, 0, tz - 0.5, tx + 0.3, 0.36, tz + 0.5, C.gold); this.solid(tx - 0.4, tz - 0.6, tx + 0.4, tz + 0.6, 0.45);
        const [vx, vz] = P(w / 2 - 0.35, 3.6); this.box('satin', vx - 0.25, 0.7, vz - 0.7, vx + 0.25, 0.76, vz + 0.7, C.ivory); for (const s of [-1, 1]) this.box('metal', vx - 0.2, 0, vz + s * 0.62 - 0.03, vx + 0.2, 0.7, vz + s * 0.62 + 0.03, C.gold); this.box('gloss', vx + 0.2, 0.9, vz - 0.5, vx + 0.23, 1.9, vz + 0.5, 0xd8e4ea); this.parts.metal.push(colorize(new THREE.TorusGeometry(0.55, 0.03, 6, 24).scale(1, 1, 1).rotateY(PI / 2).translate(vx + 0.22, 1.4, vz), C.gold)); this.solid(vx - 0.25, vz - 0.7, vx + 0.25, vz + 0.7, 0.8);
        this.plant(...P(-w / 2 + 3.2, 0.6), 1.0, true); this.chandelier(...P(bc, d - 3.0), 3.05, 0.6);
      }
    }
  }
  // ------------------------------------------------------------------ bureau personnel du PDG
  office() {
    const R = this.villa.rooms.bureau; if (!R) return; const { w, d, sgn, F, back, door } = this.frame(R);
    // bureau de direction d'origine (plateau 2,8 m) : sous-main en cuir, filets dorés, lampe, globe, plaque, porte-documents
    const [ox, oz] = F(0, d - 3); this.box('satin', ox - 0.9, 0.82, oz - 0.35, ox + 0.9, 0.83, oz + 0.35, C.leather); this.box('metal', ox - 1.42, 0.78, oz - 0.62, ox + 1.42, 0.8, oz - 0.6, C.gold); this.box('metal', ox - 1.42, 0.78, oz + 0.6, ox + 1.42, 0.8, oz + 0.62, C.gold);
    this.lamp(ox - 1.1, 0.82, oz); this.sph('gloss', ox + 1.05, 1.02, oz, 0.16, 0x2f80ed); this.cyl('metal', ox + 1.05, 0.82, oz, 0.05, 0.07, 0.04, C.gold, 8); this.box('metal', ox - 0.25, 0.83, oz - sgn * 0.5 - 0.03, ox + 0.25, 0.92, oz - sgn * 0.5 + 0.03, C.gold);
    for (let k = 0; k < 3; k++) this.box('matte', ox + 0.45, 0.83 + k * 0.03, oz - 0.2, ox + 0.75, 0.86 + k * 0.03, oz + 0.15, [C.ivory, 0xd8dde2, C.ivory][k]);
    // fauteuil ergonomique de luxe (derrière le bureau, côté fond)
    { const [cx2, cz2] = F(0, d - 1.75); this.obox('satin', cx2, cz2, door, -0.32, 0.42, -0.3, 0.32, 0.58, 0.3, 0x1a1a1a); this.obox('satin', cx2, cz2, door, -0.32, 0.58, -0.36, 0.32, 1.45, -0.24, 0x1a1a1a); for (const s of [-1, 1]) this.obox('satin', cx2, cz2, door, s * 0.36 - 0.05, 0.6, -0.2, s * 0.36 + 0.05, 0.75, 0.2, 0x1a1a1a); this.cyl('metal', cx2, 0.06, cz2, 0.04, 0.04, 0.36, C.chrome, 8); for (let k = 0; k < 5; k++) { const a = k * 1.256; this.box('metal', cx2 + Math.cos(a) * 0.15 - 0.15, 0.02, cz2 + Math.sin(a) * 0.15 - 0.02, cx2 + Math.cos(a) * 0.15 + 0.15, 0.06, cz2 + Math.sin(a) * 0.15 + 0.02, C.chrome); } this.seats.push({ x: cx2, z: cz2, ry: door, kind: 'fauteuil de direction' }); }
    // bibliothèque murale derrière le bureau (mur du fond)
    { const a = F(-w / 2 + 0.3, d - 0.5), b = F(w / 2 - 0.3, d - 0.08); this.bookcase(Math.min(a[0], b[0]), Math.min(a[1], b[1]), Math.max(a[0], b[0]), Math.max(a[1], b[1]), 2.9, 11); }
    // canapé de réception et table basse (mur est), vitrines (trophées), table de réunion (6 places)
    { const [sx, sz] = F(w / 2 - 0.55, 8.3); this.sofa(sx, sz, -PI / 2, 2.4, C.leather, 0.95); const [tx, tz] = F(w / 2 - 2.3, 8.3); this.box('gloss', tx - 0.35, 0.38, tz - 0.6, tx + 0.35, 0.44, tz + 0.6, C.marbleB); this.box('metal', tx - 0.3, 0, tz - 0.55, tx + 0.3, 0.38, tz + 0.55, C.gold); this.solid(tx - 0.35, tz - 0.6, tx + 0.35, tz + 0.6, 0.45); }
    { const [sx, sz] = F(w / 2 - 1.2, 2.9); this.storage.push({ id: 'bureau_vitrine', name: 'vitrine du bureau du PDG', x: sx, z: sz }); }
    for (const v of [11.3, 2.9]) { const a = F(w / 2 - 0.6, v - 1.1), b = F(w / 2 - 0.1, v + 1.1); this.vitrine(Math.min(a[0], b[0]), Math.min(a[1], b[1]), Math.max(a[0], b[0]), Math.max(a[1], b[1]), 2.2); }
    { const [mx, mz] = F(-2.1, 4.6); this.box('gloss', mx - 0.5, 0.74, mz - 1.3, mx + 0.5, 0.8, mz + 1.3, C.walnut); this.box('satin', mx - 0.1, 0, mz - 1.0, mx + 0.1, 0.74, mz + 1.0, C.wood); this.solid(mx - 0.5, mz - 1.3, mx + 0.5, mz + 1.3, 0.8);
      for (const [du, dv, ry] of [[-0.85, -0.65, PI / 2], [-0.85, 0.65, PI / 2], [0.85, -0.65, -PI / 2], [0.85, 0.65, -PI / 2], [0, -1.65 * sgn, 0], [0, 1.65 * sgn, PI]]) { const x = mx + du, z = mz + dv; this.obox('satin', x, z, ry, -0.24, 0.42, -0.24, 0.24, 0.52, 0.24, 0x1a1a1a); this.obox('satin', x, z, ry, -0.24, 0.52, -0.3, 0.24, 1.1, -0.22, 0x1a1a1a); this.cyl('metal', x, 0, z, 0.03, 0.03, 0.42, C.chrome, 6); this.seats.push({ x, z, ry, kind: 'chaise de réunion' }); }
      const [px, pz] = F(-w / 2 + 0.12, 4.6); this.painting(px, 2.0, pz, PI / 2, 1.6, 1.0, 10); }
    // décorations professionnelles : affiche du groupe, certificat, plan ; plantes, tapis, appliques
    { const [ax, az] = F(w / 2 - 0.12, 5.6); this.painting(ax, 2.0, az, -PI / 2, 1.0, 1.0, 8); const [bx2, bz2] = F(w / 2 - 0.12, 14.0); this.painting(bx2, 1.9, bz2, -PI / 2, 0.8, 0.8, 9); const [cx2, cz2] = F(2.4, 0.12); this.painting(cx2, 1.9, cz2, back, 1.1, 0.8, 11); }
    { const a = F(-2.2, d - 5.2), b = F(2.2, d - 0.8); this.rug(Math.min(a[0], b[0]), Math.min(a[1], b[1]), Math.max(a[0], b[0]), Math.max(a[1], b[1]), C.navy, C.gold); }
    this.plant(...F(-w / 2 + 0.6, d - 0.9), 1.0, true); this.plant(...F(w / 2 - 0.6, 0.7), 0.9); this.chandelier(...F(0, d - 3.0), 3.05, 0.55);
  }
  // ------------------------------------------------------------------ étape 5 : éclairage intégré (LED de plafond, spots, indirect, LED derrière les TV)
  lighting() {
    const LED = 0xfff4e0;
    for (const R of Object.values(this.villa.rooms)) {
      const { x0, x1, z0, z1 } = R, y = 3.08, k = 0.14;
      for (const [a, b, c, d] of [[x0 + k, z0 + k, x1 - k, z0 + k + 0.05], [x0 + k, z1 - k - 0.05, x1 - k, z1 - k], [x0 + k, z0 + k, x0 + k + 0.05, z1 - k], [x1 - k - 0.05, z0 + k, x1 - k, z1 - k]]) this.box('glow', a, y, b, c, y + 0.04, d, LED); // gorge LED périphérique
      const nx = Math.max(1, Math.round((x1 - x0) / 4)), nz = Math.max(1, Math.round((z1 - z0) / 4));
      for (let i = 0; i < nx; i++) for (let j = 0; j < nz; j++) { const x = x0 + (i + 0.5) * (x1 - x0) / nx, z = z0 + (j + 0.5) * (z1 - z0) / nz; this.cyl('glow', x, 3.13, z, 0.07, 0.07, 0.02, LED, 12); } // spots encastrés
    }
    for (const [x0, x1] of [[-36.8, 36.8]]) for (const z of [6.2, 9.8, -10.2, -13.8]) this.box('glow', x0, 3.08, z - 0.02, x1, 3.12, z + 0.02, LED); // couloirs
    // LED derrière les téléviseurs murales (halo sur le mur)
    for (const s of this.villa.screens || []) { if (s.far) continue; const ry = Math.atan2(s.nx, s.nz); this.obox('glow', s.x - s.nx * 0.03, s.z - s.nz * 0.03, ry, -s.w / 2 - 0.14, s.y - s.h / 2 - 0.14, -0.01, s.w / 2 + 0.14, s.y + s.h / 2 + 0.14, 0.0, 0x8ab8ff); }
    // éclairage indirect : têtes de lit, sous le meuble TV du salon, sous le buffet, sous les placards de la cuisine
    for (const R of Object.values(this.villa.rooms)) { if (R.type !== 'chambre' && R.type !== 'suite') continue; const { w, d, F, back } = this.frame(R), bw = R.type === 'suite' ? 2.4 : 1.6, bc = -w / 2 + bw / 2 + 1.0, [hx, hz] = F(bc, d - 1.0); this.obox('glow', hx, hz, back, -bw / 2 - 0.2, (R.type === 'suite' ? 1.9 : 1.6) + 0.005, 0.0, bw / 2 + 0.2, (R.type === 'suite' ? 1.9 : 1.6) + 0.03, 0.05, LED); }
    const S = this.villa.rooms.salon; if (S) this.box('glow', S.cx - 5.3, 0.01, S.z0 + 0.66, S.cx - 0.7, 0.03, S.z0 + 0.7, LED);
    const M = this.villa.rooms.manger; if (M) this.box('glow', M.x0 + 0.66, 0.01, (M.z0 + M.z1) / 2 - 3, M.x0 + 0.7, 0.03, (M.z0 + M.z1) / 2 + 3, LED);
    const K = this.villa.rooms.cuisine; if (K) this.box('glow', K.x0 + 1, 1.48, K.z1 - 0.62, K.x1 - 1, 1.5, K.z1 - 0.58, LED);
  }
  // ------------------------------------------------------------------ horloges murales (aiguilles à l'heure du jeu)
  clock(x, y, z, ry, r = 0.28, face = C.ivory) {
    const nx = Math.sin(ry), nz = Math.cos(ry);
    this.parts.gloss.push(colorize(new THREE.CylinderGeometry(r, r, 0.04, 28).rotateX(PI / 2).rotateY(ry).translate(x + nx * 0.03, y, z + nz * 0.03), face));
    this.parts.metal.push(colorize(new THREE.TorusGeometry(r, 0.025, 6, 28).rotateY(ry).translate(x + nx * 0.05, y, z + nz * 0.05), C.gold));
    for (let k = 0; k < 12; k++) { const a = k * PI / 6, g = new THREE.BoxGeometry(k % 3 ? 0.015 : 0.03, r * 0.16, 0.01).translate(0, r * 0.8, 0).rotateZ(-a).rotateY(ry).translate(x + nx * 0.055, y, z + nz * 0.055); this.parts.metal.push(colorize(g, 0x1a1a1a)); }
    const grp = new THREE.Group(); grp.position.set(x + nx * 0.065, y, z + nz * 0.065); grp.rotation.y = ry; this.villa.inGroup.add(grp);
    const mat = new THREE.MeshBasicMaterial({ color: 0x1a1a1a }), hh = new THREE.Mesh(new THREE.BoxGeometry(0.03, r * 0.5, 0.01).translate(0, r * 0.22, 0), mat), mm = new THREE.Mesh(new THREE.BoxGeometry(0.018, r * 0.78, 0.01).translate(0, r * 0.36, 0.006), mat); grp.add(hh, mm);
    this.clocks.push({ hh, mm });
  }
  update(time) { for (const c of this.clocks) { c.hh.rotation.z = -((time % 12) / 12) * PI * 2; c.mm.rotation.z = -((time % 1)) * PI * 2; } }
  // ------------------------------------------------------------------ cuisine (postes du cuisinier laissés libres : îlot côté sud, réfrigérateur, plans de travail)
  kitchen() {
    const R = this.villa.rooms.cuisine; if (!R) return; const { x0, x1, z0, z1, cx, cz } = R;
    for (let k = 0; k < 4; k++) { const x = cx - 1.8 + k * 1.2, z = cz + 1.25; this.cyl('satin', x, 0.72, z, 0.2, 0.2, 0.08, C.leather); this.cyl('metal', x, 0.02, z, 0.03, 0.03, 0.7, C.chrome, 6); this.cyl('metal', x, 0, z, 0.18, 0.18, 0.02, C.chrome); this.seats.push({ x, z, ry: PI, kind: 'tabouret' }); }
    for (let k = 0; k < 3; k++) { const x = cx - 1.5 + k * 1.5; this.cyl('metal', x, 2.25, cz, 0.006, 0.006, 0.95, 0x1a1a1a, 4); this.cyl('metal', x, 2.05, cz, 0.05, 0.2, 0.2, C.gold); this.cyl('glow', x, 2.02, cz, 0.17, 0.17, 0.02, C.warm); }
    this.box('gloss', cx - 0.6, 0.925, z1 - 0.95, cx + 0.6, 0.935, z1 - 0.4, 0x0a0a0c); for (const [a, b] of [[-0.35, -0.15], [0.15, 0.35]]) for (const v of [-0.8, -0.55]) this.cyl('metal', cx + (a + b) / 2, 0.935, z1 + v, 0.09, 0.09, 0.004, 0x3a3a3a, 12);
    this.box('metal', cx - 0.75, 2.0, z1 - 0.8, cx + 0.75, 2.25, z1 - 0.3, C.chrome); this.box('metal', cx - 0.2, 2.25, z1 - 0.6, cx + 0.2, 3.2, z1 - 0.3, C.chrome);
    this.box('gloss', x0 + 1.9, 0.86, z1 - 0.9, x0 + 3.1, 0.93, z1 - 0.45, 0x5a5f66); this.cyl('metal', x0 + 2.5, 0.93, z1 - 0.42, 0.02, 0.02, 0.35, C.chrome, 6); this.box('metal', x0 + 2.48, 1.26, z1 - 0.6, x0 + 2.52, 1.28, z1 - 0.42, C.chrome);
    for (let k = 0; k < 7; k++) this.sph('gloss', cx - 0.25 + (k % 3) * 0.2, 1.04 + Math.floor(k / 3) * 0.08, cz + 0.2 + (k % 2) * 0.12, 0.08, [0xfcd116, 0xe46a1f, 0x2fb04a, 0xe8112d][k % 4]); this.cyl('gloss', cx, 0.97, cz + 0.25, 0.3, 0.18, 0.08, C.ivory);
    for (let k = 0; k < 3; k++) { this.cyl('satin', x0 + 4.2 + k * 0.4, 0.92, z1 - 0.55, 0.09, 0.07, 0.15, C.pot); this.sph('matte', x0 + 4.2 + k * 0.4, 1.12, z1 - 0.55, 0.11, C.plant2); }
    { const x = x0 + 1.4, z = z0 + 3.2; this.cyl('gloss', x, 0.72, z, 0.6, 0.6, 0.05, C.marble, 24); this.cyl('metal', x, 0, z, 0.06, 0.06, 0.72, C.gold, 8); this.cyl('metal', x, 0, z, 0.35, 0.35, 0.03, C.gold); this.solid(x - 0.6, z - 0.6, x + 0.6, z + 0.6, 0.78); for (const a of [0.6, 2.7, 4.6]) { const sx = x + Math.cos(a) * 0.95, sz = z + Math.sin(a) * 0.95, ry = Math.atan2(x - sx, z - sz); this.obox('satin', sx, sz, ry, -0.22, 0.44, -0.22, 0.22, 0.52, 0.22, C.cream); this.obox('satin', sx, sz, ry, -0.22, 0.52, -0.28, 0.22, 1.0, -0.2, C.cream); this.cyl('metal', sx, 0, sz, 0.025, 0.025, 0.44, C.gold, 6); this.seats.push({ x: sx, z: sz, ry, kind: 'chaise' }); } this.vase(x, 0.77, z); }
    for (const y of [1.45, 1.9]) { this.box('satin', x0 + 0.1, y, cz - 2, x0 + 0.38, y + 0.04, cz + 2, C.oak); for (let k = 0; k < 8; k++) this.cyl('glass', x0 + 0.24, y + 0.04, cz - 1.75 + k * 0.5, 0.08, 0.08, 0.2, C.glass, 10), this.cyl('satin', x0 + 0.24, y + 0.04, cz - 1.75 + k * 0.5, 0.06, 0.06, 0.12, [0xe8112d, 0xfcd116, 0x6a4630, 0xe8dcc4][k % 4], 8); }
    this.clock(x0 + 0.09, 2.3, cz + 3.6, PI / 2); this.painting(x1 - 0.12, 2.0, cz + 2.5, -PI / 2, 1.6, 1.1, 5); this.plant(x0 + 0.7, z1 - 2.6, 0.95);
  }
  // ------------------------------------------------------------------ salle de cinéma : panneaux acoustiques en bois, tapis, éclairage des marches, bar à collations, affiches
  cinema() {
    const R = this.villa.rooms.cinema; if (!R) return; const { x0, x1, z0, z1 } = R;
    for (const x of [x0 + 0.1, x1 - 0.1]) for (let z = z0 + 0.8; z < z1 - 1.6; z += 0.28) this.box('satin', x - 0.05, 0.25, z, x + 0.05, 2.9, z + 0.16, 0x5a3a22);
    this.rug(x0 + 1.4, z0 + 0.4, x1 - 1.4, z1 - 1.4, 0x2a0e12, C.gold);
    for (let r = 0; r < 3; r++) { const z = z1 - 5 - r * 3 + 0.66; this.box('glow', x0 + 1.6, 0.03 + 0.15 * r, z - 0.02, x1 - 1.6, 0.05 + 0.15 * r, z + 0.02, 0xffb060); }
    this.box('satin', x0 + 1.4, 0, z0 + 0.35, x0 + 4.9, 1.0, z0 + 0.95, C.burgundy); this.box('gloss', x0 + 1.35, 1.0, z0 + 0.3, x0 + 4.95, 1.05, z0 + 1.0, C.marbleB); this.solid(x0 + 1.35, z0 + 0.3, x0 + 4.95, z0 + 1.0, 1.05);
    this.box('satin', x0 + 1.7, 1.05, z0 + 0.45, x0 + 2.3, 1.75, z0 + 0.85, 0xc8102e); this.box('glass', x0 + 1.75, 1.1, z0 + 0.5, x0 + 2.25, 1.6, z0 + 0.8, C.glass); this.box('glow', x0 + 1.8, 1.1, z0 + 0.55, x0 + 2.2, 1.2, z0 + 0.75, 0xfff0b0);
    this.box('satin', x0 + 5.4, 0, z0 + 0.3, x0 + 6.4, 1.8, z0 + 0.95, 0x1a1a1a); this.box('glow', x0 + 5.5, 0.15, z0 + 0.94, x0 + 6.3, 1.7, z0 + 0.96, 0xbfe8ff); this.solid(x0 + 5.4, z0 + 0.3, x0 + 6.4, z0 + 0.95, 1.8);
    [[x0 + 8.5, 14], [x0 + 10.4, 7], [x0 + 12.3, 0]].forEach(([x, i]) => this.painting(x, 1.75, z0 + 0.1, 0, 1.1, 1.5, i, 0x1a1a1a));
    for (const z of [z0 + 3, z0 + 8, z1 - 3]) { this.sconce(x0 + 0.16, 2.2, z, PI / 2); this.sconce(x1 - 0.16, 2.2, z, -PI / 2); }
  }
  // ------------------------------------------------------------------ salle de jeux : canapé face à la TV, bornes d'arcade, table de cartes, bar à jus, fléchettes, queues de billard
  games() {
    const R = this.villa.rooms.jeux; if (!R) return; const { x0, x1, z0, z1 } = R;
    this.sofa(x0 + 7.6, z1 - 2.0, PI / 2, 2.2, C.navy, 0.9); this.sideTable(x0 + 7.6, z1 - 3.55, 0.24, 0.5);
    for (const [z, c] of [[z0 + 0.8, 0xe8112d], [z0 + 2.1, 0x2f80ed]]) { this.box('satin', x0 + 0.1, 0, z - 0.4, x0 + 0.9, 1.75, z + 0.4, 0x1a1a1a); this.box('satin', x0 + 0.85, 0.85, z - 0.36, x0 + 1.15, 0.95, z + 0.36, c); this.box('glow', x0 + 0.86, 1.1, z - 0.3, x0 + 0.88, 1.55, z + 0.3, 0x6ad0ff); this.box('glow', x0 + 0.3, 1.75, z - 0.4, x0 + 0.95, 1.95, z + 0.4, c); this.solid(x0 + 0.1, z - 0.4, x0 + 1.15, z + 0.4, 1.95); }
    { const x = x0 + 3.5, z = z0 + 4.0; this.cyl('satin', x, 0.7, z, 0.75, 0.75, 0.05, 0x0b5a3a, 24); this.cyl('satin', x, 0.68, z, 0.78, 0.78, 0.04, C.wood, 24); this.cyl('satin', x, 0, z, 0.08, 0.1, 0.7, C.wood, 8); this.solid(x - 0.78, z - 0.78, x + 0.78, z + 0.78, 0.75); for (let k = 0; k < 4; k++) { const a = k * PI / 2 + 0.4, sx = x + Math.cos(a) * 1.15, sz = z + Math.sin(a) * 1.15, ry = Math.atan2(x - sx, z - sz); this.obox('satin', sx, sz, ry, -0.22, 0.44, -0.22, 0.22, 0.52, 0.22, C.burgundy); this.obox('satin', sx, sz, ry, -0.22, 0.52, -0.28, 0.22, 0.95, -0.2, C.burgundy); this.cyl('satin', sx, 0, sz, 0.03, 0.03, 0.44, C.wood, 6); this.seats.push({ x: sx, z: sz, ry, kind: 'chaise' }); } }
    { const xa = x1 - 1.1; this.box('satin', xa - 0.4, 0, z0 + 0.6, xa + 0.4, 1.05, z0 + 3.6, C.walnut); this.box('gloss', xa - 0.45, 1.05, z0 + 0.55, xa + 0.45, 1.1, z0 + 3.65, C.marble); this.solid(xa - 0.45, z0 + 0.55, xa + 0.45, z0 + 3.65, 1.1);
      for (let k = 0; k < 10; k++) this.cyl('glass', x1 - 0.2, 1.4 + Math.floor(k / 5) * 0.45, z0 + 0.9 + (k % 5) * 0.6, 0.05, 0.05, 0.28, [0xe46a1f, 0xfcd116, 0xe8112d, 0x2fb04a, 0x8a2a6a][k % 5], 8); for (const y of [1.38, 1.83]) this.box('satin', x1 - 0.32, y, z0 + 0.6, x1 - 0.08, y + 0.03, z0 + 3.6, C.oak);
      for (let k = 0; k < 3; k++) { const z = z0 + 1.2 + k * 1.0, x = xa - 0.85; this.cyl('satin', x, 0.74, z, 0.2, 0.2, 0.08, C.leather); this.cyl('metal', x, 0.02, z, 0.03, 0.03, 0.72, C.chrome, 6); this.seats.push({ x, z, ry: PI / 2, kind: 'tabouret' }); } }
    this.parts.gloss.push(colorize(new THREE.CylinderGeometry(0.24, 0.24, 0.04, 20).rotateZ(PI / 2).translate(x0 + 0.1, 1.73, z1 - 8.5), 0x1a1a1a)); for (const [rr, c] of [[0.18, 0xe8112d], [0.12, 0xf2e6c8], [0.06, 0x0b6e4f], [0.025, 0xe8112d]]) this.parts.gloss.push(colorize(new THREE.CylinderGeometry(rr, rr, 0.01, 20).rotateZ(PI / 2).translate(x0 + 0.125 + (0.24 - rr) * 0.01, 1.73, z1 - 8.5), c));
    for (let k = 0; k < 6; k++) this.box('satin', x0 + 0.12, 0.2, z1 - 6.3 + k * 0.12, x0 + 0.15, 1.65, z1 - 6.28 + k * 0.12, 0xc89a5a); this.box('satin', x0 + 0.08, 0.95, z1 - 6.45, x0 + 0.2, 1.05, z1 - 5.55, C.wood);
    this.painting(x1 - 0.12, 1.95, z1 - 7, -PI / 2, 1.4, 1.0, 3); this.painting(x0 + 4, 1.95, z0 + 0.1, 0, 1.4, 1.0, 7); this.plant(x1 - 0.6, z1 - 0.7, 0.9);
    const neon = this.neonSign('SALLE DE JEUX', '#ff3ad0'); neon.position.set(x0 + 7.5, 2.4, z0 + 0.06); this.villa.inGroup.add(neon);
  }
  neonSign(text, col) { const c = document.createElement('canvas'); c.width = 512; c.height = 96; const g = c.getContext('2d'); g.shadowColor = col; g.shadowBlur = 18; g.fillStyle = col; g.font = '900 56px Arial'; g.textAlign = 'center'; g.fillText(text, 256, 68); g.fillText(text, 256, 68); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return new THREE.Mesh(new THREE.PlaneGeometry(2.8, 0.52), new THREE.MeshBasicMaterial({ map: t, transparent: true, toneMapped: false, depthWrite: false })); }
  // ------------------------------------------------------------------ salle de sport : sol amortissant, haltères, vélos, sac de frappe, tapis de yoga, fontaine, serviettes
  gym() {
    const R = this.villa.rooms.sport; if (!R) return; const { x0, x1, z0, z1 } = R;
    this.box('matte', x0 + 0.4, 0.021, z0 + 0.4, x1 - 0.4, 0.035, z0 + 5.4, 0x1a1d22);
    { const x = x1 - 0.45; this.box('metal', x - 0.3, 0, z0 + 2.2, x + 0.3, 0.9, z0 + 4.8, 0x2a2d33); for (let r = 0; r < 2; r++) for (let k = 0; k < 6; k++) { const z = z0 + 2.45 + k * 0.42, y = 0.42 + r * 0.38, s = 0.06 + k * 0.012; for (const dx of [-0.13, 0.13]) this.parts.metal.push(colorize(new THREE.CylinderGeometry(s, s, 0.06, 10).rotateZ(PI / 2).translate(x + dx, y, z), 0x1a1a1a)); this.parts.metal.push(colorize(new THREE.CylinderGeometry(0.018, 0.018, 0.22, 6).rotateZ(PI / 2).translate(x, y, z), C.chrome)); } this.solid(x - 0.3, z0 + 2.2, x + 0.3, z0 + 4.8, 0.9); }
    for (const x of [x0 + 1.5, x0 + 3.2]) { const z = z0 + 1.2; this.box('metal', x - 0.12, 0, z - 0.6, x + 0.12, 0.08, z + 0.6, 0x2a2d33); this.box('metal', x - 0.06, 0.08, z - 0.35, x + 0.06, 0.9, z - 0.25, 0x2a2d33); this.box('satin', x - 0.15, 0.9, z - 0.42, x + 0.15, 0.97, z - 0.18, 0x1a1a1a); this.box('metal', x - 0.05, 0.08, z + 0.3, x + 0.05, 1.15, z + 0.4, 0x2a2d33); this.box('metal', x - 0.3, 1.12, z + 0.32, x + 0.3, 1.16, z + 0.42, C.chrome); this.parts.metal.push(colorize(new THREE.CylinderGeometry(0.25, 0.25, 0.08, 18).rotateZ(PI / 2).translate(x, 0.35, z + 0.15), 0xe8112d)); this.solid(x - 0.3, z - 0.6, x + 0.3, z + 0.6, 1.2); }
    { const x = x0 + 6.2, z = z0 + 1.6; this.cyl('metal', x, 1.75, z, 0.01, 0.01, 1.45, 0x8a8f96, 4); this.cyl('satin', x, 0.55, z, 0.2, 0.2, 1.2, 0xc8102e, 14); this.solid(x - 0.22, z - 0.22, x + 0.22, z + 0.22, 1.8); }
    for (let k = 0; k < 3; k++) this.box('matte', x0 + 0.5, 0.036, z0 + 6.0 + k * 0.85, x0 + 2.3, 0.05, z0 + 6.65 + k * 0.85, [0x7a2a8a, 0x0b8a8a, 0xe46a1f][k]);
    { const x = x1 - 0.35, z = z1 - 4.5; this.box('satin', x - 0.2, 0, z - 0.2, x + 0.2, 1.0, z + 0.2, 0xe8e8e8); this.cyl('glass', x, 1.0, z, 0.15, 0.15, 0.38, 0x8ad0f0, 12); this.solid(x - 0.2, z - 0.2, x + 0.2, z + 0.2, 1.4); }
    { const x = x1 - 0.3; for (let s = 0; s < 3; s++) { this.box('satin', x - 0.2, 0.6 + s * 0.4, z1 - 8.2, x + 0.2, 0.63 + s * 0.4, z1 - 6.8, C.oak); for (let k = 0; k < 4; k++) this.box('matte', x - 0.15, 0.63 + s * 0.4, z1 - 8.1 + k * 0.33, x + 0.15, 0.78 + s * 0.4, z1 - 7.82 + k * 0.33, [C.ivory, 0x1f4e9c, C.ivory, 0x0b6e4f][k]); } }
    this.clock((x0 + x1) / 2, 2.4, z0 + 0.09, 0); this.painting(x1 - 0.12, 1.95, z1 - 2.2, -PI / 2, 1.2, 0.9, 1); this.plant(x1 - 0.6, z1 - 0.7, 0.85);
  }
  // ------------------------------------------------------------------ pièces de service et murs : salle de bains, buanderie, espace du personnel, horloges et photos des couloirs
  service() {
    const S = this.villa.rooms.sdb; if (S) { const { x0, x1, z0, z1 } = S; this.box('gloss', x0 + 0.1, 0.02, z0 + 3, x0 + 0.14, 2.9, z1 - 1.2, 0xf2ece6); for (let k = 0; k < 5; k++) this.box('gloss', x0 + 0.141, 0.4 + k * 0.55, z0 + 3.2, x0 + 0.145, 0.42 + k * 0.55, z1 - 1.4, 0xd8cfc0);
      this.box('metal', x1 - 0.14, 1.15, z1 - 4.2, x1 - 0.1, 2.35, z1 - 2.6, C.gold); this.box('gloss', x1 - 0.15, 1.21, z1 - 4.14, x1 - 0.14, 2.29, z1 - 2.66, 0xd8e4ea); this.box('metal', x1 - 0.12, 1.2, z0 + 3.5, x1 - 0.08, 1.24, z0 + 4.7, C.gold); this.box('matte', x1 - 0.2, 0.75, z0 + 3.55, x1 - 0.11, 1.22, z0 + 4.65, C.ivory); this.plant(x1 - 0.5, z1 - 1.2, 0.75); }
    const B = this.villa.rooms.buanderie; if (B) { const { x0, cz } = B; for (const y of [1.6, 2.05]) this.box('satin', x0 + 0.1, y, cz - 1.5, x0 + 0.4, y + 0.04, cz + 1.5, C.oak); for (let k = 0; k < 4; k++) this.box('matte', x0 + 0.12, 1.64, cz - 1.3 + k * 0.7, x0 + 0.38, 1.94, cz - 0.85 + k * 0.7, [0xc89a5a, 0xe8dcc4, 0xc89a5a, 0x5aa0c8][k]); this.clock(x0 + 0.09, 2.45, cz + 2.6, PI / 2); }
    const Pn = this.villa.rooms.personnel; if (Pn) { const { x0, cz, z1, cx } = Pn; for (const [dx, dz, ry] of [[-1.45, -0.4, PI / 2], [-1.45, 0.4, PI / 2], [1.45, -0.4, -PI / 2], [1.45, 0.4, -PI / 2]]) { const x = cx + dx, z = cz + dz; this.obox('satin', x, z, ry, -0.22, 0.42, -0.22, 0.22, 0.5, 0.22, 0x5a6a7a); this.obox('satin', x, z, ry, -0.22, 0.5, -0.27, 0.22, 0.95, -0.2, 0x5a6a7a); this.cyl('metal', x, 0, z, 0.025, 0.025, 0.42, C.chrome, 6); this.seats.push({ x, z, ry, kind: 'chaise' }); } this.clock(x0 + 0.09, 2.3, cz - 2.5, PI / 2); this.painting(x0 + 0.12, 1.9, cz + 2.5, PI / 2, 1.2, 0.85, 13); this.plant(x0 + 0.6, z1 - 0.7, 0.85); }
    // couloirs : horloges, « photographies » (illustrations stylisées) de lieux du Bénin
    this.clock(-9.0, 2.2, 6.1, 0, 0.32); this.clock(-36.85, 2.3, -11.5, PI / 2, 0.3);
    [[-13.8, 12], [9.0, 13], [27, 15]].forEach(([x, i]) => this.painting(x, 1.7, 6.12, 0, 1.2, 0.9, i, 0x1a1a1a));
    this.painting(-34.1, 2.1, 22.0, -PI / 2, 1.3, 0.95, 14); this.painting(-36.85, 2.1, 18.6, PI / 2, 1.0, 0.75, 15);
  }
  // ------------------------------------------------------------------ extérieur : pergola et salle à manger d'été (pelouse ouest), jardinières près de la porte de l'aile
  exterior() {
    const parts = { matte: [], satin: [], gloss: [], metal: [], glass: [], glow: [], art: [] }, keep = this.parts; this.parts = parts;
    const col = this.world.collision, ext = (x0, z0, x1, z1, h) => col.addBox(x0, z0, x1, z1, h);
    const tx = -53.5, tz = 140.3;
    for (const [x, z] of [[-56.3, 139.0], [-50.7, 139.0], [-56.3, 141.6], [-50.7, 141.6]]) { this.box('satin', x - 0.08, 0, z - 0.08, x + 0.08, 2.7, z + 0.08, C.walnut); col.addCircle(x, z, 0.12, 2.7); }
    for (const z of [139.0, 141.6]) this.box('satin', -56.4, 2.7, z - 0.07, -50.6, 2.85, z + 0.07, C.walnut); for (let k = 0; k < 9; k++) this.box('satin', -56.3 + k * 0.7, 2.85, 138.9, -56.2 + k * 0.7, 2.93, 141.7, C.oak);
    for (let k = 0; k < 15; k++) { const x = -56.2 + k * 0.4; this.sph('glow', x, 2.62 - Math.sin((k / 14) * PI) * 0.15, 140.3, 0.04, C.warm); }
    this.box('gloss', tx - 1.2, 0.74, tz - 0.45, tx + 1.2, 0.8, tz + 0.45, 0x8a6440); for (const s of [-1, 1]) this.box('satin', tx + s * 0.95 - 0.06, 0, tz - 0.35, tx + s * 0.95 + 0.06, 0.74, tz + 0.35, C.walnut); ext(tx - 1.2, tz - 0.45, tx + 1.2, tz + 0.45, 0.8);
    for (let k = 0; k < 3; k++) for (const s of [-1, 1]) { const x = tx - 0.8 + k * 0.8, z = tz + s * 0.78, ry = s > 0 ? PI : 0; this.obox('satin', x, z, ry, -0.22, 0.42, -0.22, 0.22, 0.5, 0.22, C.oak); this.obox('satin', x, z, ry, -0.22, 0.5, -0.27, 0.22, 0.92, -0.2, C.oak); this.obox('satin', x, z, ry, -0.2, 0.5, -0.2, 0.2, 0.56, 0.2, C.cream); this.seats.push({ x, z, ry, kind: 'chaise de jardin', out: true }); }
    this.vase(tx, 0.8, tz); this.lamp(tx + 0.8, 0.8, tz); this.lamp(tx - 0.8, 0.8, tz);
    for (const [x, z] of [[-57.6, 139.2], [-49.4, 141.3], [-44.0, 134.8], [-40.0, 134.8]]) { this.cyl('satin', x, 0, z, 0.32, 0.26, 0.7, 0x3a3d42); this.cyl('satin', x, 0.6, z, 0.05, 0.06, 1.3, 0x6a4a2a, 6); for (let a = 0; a < 6; a++) this.parts.matte.push(colorize(new THREE.ConeGeometry(0.12, 1.1, 4).rotateZ(PI / 2.3).rotateY(a * 1.05).translate(x + Math.cos(a * 1.05) * 0.45, 1.9, z - Math.sin(a * 1.05) * 0.45), C.plant)); col.addCircle(x, z, 0.34, 1.2); }
    const g = new THREE.Group(); g.name = 'VILLA_TERRASSE'; this.villa.scene.add(g); this.build(g, parts, 'terrasse'); this.outG = g;
    this.parts = keep;
  }
  // ------------------------------------------------------------------ hall d'entrée (galerie ouest) et couloirs
  halls() {
    // hall d'entrée : grande console, miroir, fauteuils d'attente, plantes, vases sur colonnes
    this.box('gloss', -36.75, 0.82, 13.0, -36.2, 0.88, 16.0, C.marble); for (const z of [13.1, 15.9]) this.box('metal', -36.7, 0, z - 0.05, -36.25, 0.82, z + 0.05, C.gold); this.solid(-36.8, 12.95, -36.15, 16.05, 0.9);
    this.vase(-36.47, 0.88, 13.8); this.lamp(-36.47, 0.88, 15.3); this.box('metal', -36.86, 1.25, 13.2, -36.82, 2.75, 15.8, C.gold); this.box('gloss', -36.82, 1.33, 13.3, -36.8, 2.67, 15.7, 0xd8e4ea);
    this.armchair(-35.0, 19.0, -PI / 2, C.velvet); this.armchair(-35.0, 21.0, -PI / 2, C.velvet); this.sideTable(-35.0, 20.0, 0.25, 0.5);
    for (const z of [11.0, 25.6]) { this.cyl('gloss', -36.4, 0, z, 0.2, 0.22, 1.0, C.marble); this.vase(-36.4, 1.0, z, C.gold); this.solid(-36.62, z - 0.22, -36.18, z + 0.22, 1.2); }
    this.rug(-36.7, 10.6, -34.3, 26.4, C.burgundy, C.gold); this.chandelier(-35.5, 18.5, 3.05, 0.6);
    this.painting(-36.85, 2.1, 22.8, PI / 2, 1.4, 1.0, 2); this.painting(-34.1, 2.1, 13.0, -PI / 2, 1.0, 0.75, 3);
    // couloir nord (z 6–10) : consoles et miroirs, banquettes sous les tableaux, appliques
    for (const x of [-17, -1, 10.5, 20]) { this.box('gloss', x - 0.8, 0.8, 9.5, x + 0.8, 0.85, 9.88, C.marble); for (const s of [-1, 1]) this.box('metal', x + s * 0.7 - 0.03, 0, 9.55, x + s * 0.7 + 0.03, 0.8, 9.85, C.gold); this.solid(x - 0.8, 9.45, x + 0.8, 9.9, 0.85); this.vase(x + 0.4, 0.85, 9.68); this.box('metal', x - 0.6, 1.2, 9.88, x + 0.6, 2.4, 9.91, C.gold); this.box('gloss', x - 0.53, 1.27, 9.86, x + 0.53, 2.33, 9.88, 0xd8e4ea); }
    for (const x of [-24, 0, 25.5]) { this.box('satin', x - 0.7, 0.3, 6.12, x + 0.7, 0.46, 6.55, C.burgundy); for (const s of [-1, 1]) this.box('metal', x + s * 0.62 - 0.03, 0, 6.15, x + s * 0.62 + 0.03, 0.3, 6.5, C.gold); this.solid(x - 0.7, 6.1, x + 0.7, 6.56, 0.5); }
    for (const x of [-33, -13, 3, 13, 28, 35]) this.sconce(x, 2.3, 9.9, PI); for (const x of [-27, -12.5, 11, 19]) this.sconce(x, 2.3, 6.1, 0);
    // couloir sud (z −14…−10) : consoles, miroirs, tableaux, plantes, appliques (le mur z = −10 n'a pas de porte)
    for (const x of [-26, -6, 14, 30]) { this.box('gloss', x - 0.9, 0.8, -10.5, x + 0.9, 0.85, -10.1, C.marble); for (const s of [-1, 1]) this.box('metal', x + s * 0.8 - 0.03, 0, -10.45, x + s * 0.8 + 0.03, 0.8, -10.15, C.gold); this.solid(x - 0.9, -10.55, x + 0.9, -10.08, 0.85); this.lamp(x - 0.5, 0.85, -10.3); this.vase(x + 0.5, 0.85, -10.3); }
    for (const [x, i] of [[-26, 1], [-6, 6], [14, 2], [30, 7]]) this.painting(x, 1.95, -10.1, PI, 1.6, 1.0, i);
    for (const x of [-16, 4, 24]) this.plant(x, -10.45, 0.8);
    for (const x of [-31, -16, -4, 4, 14, 24, 34]) this.sconce(x, 2.3, -13.9, 0);
  }
}
