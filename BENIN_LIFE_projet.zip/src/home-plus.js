// Complément mission 010 — aménagement complet de la maison : cuisine équipée (placards à portes, four, micro-ondes,
// vaisselle, ustensiles, poubelle), salon (fauteuils, rideaux, climatisation, tableaux, éclairage LED réglable),
// chambre (armoire, commode, miroir, espace informatique avec ordinateur, espace jeux avec console et mini-jeux),
// personnalisation de la décoration (sauvegardée). Les fonctions existantes (frigo, recettes, sommeil, douche,
// tenues, télévision, garage, marqueur M) sont conservées et réutilisées.
import * as THREE from 'three';
import { Batch, box, HOME } from './home.js';
import { fcfa } from './food-data.js';
import { JOBS } from './nova-data.js';

const PI = Math.PI;
// palettes de personnalisation
const DECOR = {
  sofa: { label: 'Canapé et fauteuils', opts: [['Vert forêt', 0x1f5a48], ['Gris anthracite', 0x3a3d42], ['Bleu nuit', 0x1f2f5a], ['Terracotta', 0xa8522e], ['Beige', 0xc8b494]] },
  accent: { label: 'Mur d’accent du salon', opts: [['Terre cuite', 0xc9714a], ['Bleu canard', 0x1f6a7a], ['Vert olive', 0x6a7a3a], ['Jaune soleil', 0xd8a830], ['Blanc cassé', 0xe8e2d6]] },
  led: { label: 'LED du salon', opts: [['Blanc chaud', 0xffd8a0], ['Bleu', 0x4a8aff], ['Violet', 0xa04aff], ['Vert', 0x2fd05a], ['Orange', 0xff7a2a]] },
  ledBed: { label: 'LED de la chambre', opts: [['Violet', 0xa04aff], ['Bleu', 0x4a8aff], ['Rouge', 0xff3a4a], ['Blanc', 0xffffff], ['Cyan', 0x2ae0e0]] },
  curtain: { label: 'Rideaux', opts: [['Lin naturel', 0xd8ccb4], ['Bleu', 0x2f4e7c], ['Bordeaux', 0x7a1f2a], ['Vert sauge', 0x7a9a7a], ['Gris', 0x8a8f96]] },
  cabinet: { label: 'Façades de cuisine', opts: [['Blanc laqué', 0xf4f2ee], ['Bois clair', 0xb08a5a], ['Vert sauge', 0x7a9a80], ['Bleu marine', 0x1f2f4a], ['Noir mat', 0x222326]] },
};
// mini-jeux de la console (jouables)
const GAMES = [
  { id: 'zem', name: 'Zem Rush', desc: 'Faufile ton zémidjan entre les voitures. ← → pour changer de file.' },
  { id: 'penalty', name: 'Penalty Cotonou', desc: 'Vise et tire au bon moment. ← → viser, Espace tirer.' },
];

export class HomePlus {
  constructor(ctx) {
    Object.assign(this, ctx); // scene, home, world, economy, nova, ui, audio, input, player, onSave
    const h = this.home, mats = h.mats, col = this.world.collision;
    // nouveaux matériaux
    Object.assign(mats, {
      curtain: new THREE.MeshStandardMaterial({ color: 0xd8ccb4, roughness: 1, side: THREE.DoubleSide }),
      ledLiving: new THREE.MeshBasicMaterial({ color: 0xffd8a0, toneMapped: false }),
      ledBed: new THREE.MeshBasicMaterial({ color: 0xa04aff, toneMapped: false }),
      glossBlack: new THREE.MeshStandardMaterial({ color: 0x0c0c0e, roughness: 0.12, metalness: 0.4 }),
      white: new THREE.MeshStandardMaterial({ color: 0xf6f6f4, roughness: 0.35 }),
      steel: new THREE.MeshStandardMaterial({ color: 0xb8bcc0, roughness: 0.25, metalness: 0.85 }),
      glassware: new THREE.MeshStandardMaterial({ color: 0xd8eef8, roughness: 0.05, metalness: 0.1, transparent: true, opacity: 0.55 }),
      leather: new THREE.MeshStandardMaterial({ color: 0x1a1a1c, roughness: 0.5 }),
      accentRed: new THREE.MeshStandardMaterial({ color: 0xc8102e, roughness: 0.5 }),
      art1: new THREE.MeshBasicMaterial({ map: this.artTex(['#e46a1f', '#1f4e9c', '#f2c200']) }),
      art2: new THREE.MeshBasicMaterial({ map: this.artTex(['#0b6e4f', '#c8102e', '#f2efe6']) }),
      backsplash: new THREE.MeshStandardMaterial({ map: this.tileTex(), roughness: 0.25 }),
    });
    const B = new Batch(mats);
    const F = (k, x0, y0, z0, x1, y1, z1, collide = false) => { B.add(k, box(x0, y0, z0, x1, y1, z1, 1)); if (collide) col.addBox(Math.min(x0, x1), Math.min(z0, z1), Math.max(x0, x1), Math.max(z0, z1), y1); };
    const cyl = (k, r, hgt, x, y, z, seg = 12) => B.add(k, new THREE.CylinderGeometry(r, r, hgt, seg).translate(x, y + hgt / 2, z));

    // ================= CUISINE (x −42 → −36, z 118 → 126) =================
    F('backsplash', -41.62, 0.93, 125.88, -36.4, 1.6, 125.92);                       // crédence carrelée
    F('glossBlack', -38.85, 0.12, 125.24, -37.55, 0.8, 125.28);                     // four (sous la plaque)
    F('steel', -38.7, 0.66, 125.2, -37.7, 0.7, 125.24);                             // poignée du four
    F('black', -41.45, 0.93, 125.35, -40.75, 1.33, 125.85); F('glossBlack', -41.4, 1.0, 125.33, -40.95, 1.27, 125.35); // micro-ondes
    // carcasse des placards hauts (ouverts) : étagères avec vaisselle, portes animées devant
    F('cabinet', -41.6, 1.6, 125.86, -38.9, 2.3, 125.94); F('cabinet', -41.6, 1.6, 125.55, -38.9, 1.63, 125.94); F('cabinet', -41.6, 1.94, 125.55, -38.9, 1.97, 125.94); F('cabinet', -41.6, 2.27, 125.55, -38.9, 2.3, 125.94);
    for (const x of [-41.6, -40.25, -38.93]) F('cabinet', x, 1.6, 125.55, x + 0.03, 2.3, 125.94);
    for (let i = 0; i < 6; i++) B.add('porcelain', new THREE.CylinderGeometry(0.11, 0.11, 0.025, 14).translate(-41.35 + i * 0.05, 1.64 + i * 0.022, 125.72)); // pile d'assiettes
    for (let i = 0; i < 5; i++) B.add('glassware', new THREE.CylinderGeometry(0.035, 0.03, 0.12, 10).translate(-40.75 + i * 0.1, 2.03, 125.72));       // verres
    for (let i = 0; i < 4; i++) B.add('porcelain', new THREE.CylinderGeometry(0.05, 0.035, 0.07, 10).translate(-40.0 + i * 0.13, 1.67, 125.72));        // bols
    for (let i = 0; i < 3; i++) B.add('porcelain', new THREE.CylinderGeometry(0.045, 0.04, 0.09, 10).translate(-39.6 + i * 0.12, 2.02, 125.72));        // tasses
    // ustensiles suspendus, égouttoir, couverts, planche, casserole
    F('steel', -39.9, 1.45, 125.86, -38.95, 1.47, 125.88);
    for (let i = 0; i < 5; i++) F('steel', -39.8 + i * 0.18, 1.18, 125.84, -39.78 + i * 0.18, 1.45, 125.86);
    F('steel', -39.75, 0.93, 125.45, -39.25, 0.97, 125.8); for (let i = 0; i < 4; i++) B.add('porcelain', new THREE.CylinderGeometry(0.1, 0.1, 0.02, 12).rotateX(PI / 2).translate(-39.65 + i * 0.1, 1.06, 125.6));
    F('furniture', -36.95, 0.93, 125.4, -36.55, 0.95, 125.75);
    cyl('steel', 0.13, 0.12, -38.25, 0.955, 125.5); F('black', -38.12, 1.02, 125.48, -37.9, 1.04, 125.52);
    // poubelle à pédale, suspensions au-dessus de la table, tabourets
    cyl('steel', 0.18, 0.55, -41.62, 0.07, 124.55, 14); B.add('black', new THREE.CylinderGeometry(0.185, 0.185, 0.04, 14).translate(-41.62, 0.64, 124.55)); col.addCircle(-41.62, 124.55, 0.22, 0.7);
    for (const lx of [-40.0, -39.2]) { F('frame', lx - 0.01, 2.2, 121.19, lx + 0.01, 3.3, 121.21); B.add('lampIn', new THREE.ConeGeometry(0.2, 0.22, 14, 1, true).translate(lx, 2.12, 121.2), false); }
    // rangement haut au-dessus du frigo, cadre décoratif
    F('cabinet', -36.95, 1.98, 123.0, -36.2, 2.4, 124.3);
    B.add('art1', new THREE.PlaneGeometry(0.6, 0.8).rotateY(-PI / 2).translate(-36.15, 1.6, 121.9));

    // ================= SALON (x −56 → −46, z 118 → 127) =================
    const armchair = (x, z, ry) => {
      const g = new THREE.Group(); const s = mats.sofa;
      const p = (w, hh, d, px, py, pz, m = s) => { const mm = new THREE.Mesh(new THREE.BoxGeometry(w, hh, d), m); mm.position.set(px, py, pz); mm.castShadow = true; g.add(mm); };
      p(0.85, 0.4, 0.8, 0, 0.27, 0); p(0.85, 0.55, 0.15, 0, 0.62, -0.35); p(0.12, 0.25, 0.8, -0.38, 0.55, 0); p(0.12, 0.25, 0.8, 0.38, 0.55, 0); p(0.55, 0.12, 0.45, 0, 0.53, 0.05, mats.cushion);
      g.position.set(x, 0.07, z); g.rotation.y = ry; this.home.group.add(g); col.addCircle(x, z, 0.45, 1);
    };
    armchair(-53.5, 120.2, 0.35); armchair(-53.5, 124.8, PI - 0.35);
    F('furniture', -51.9, 0.07, 119.85, -51.3, 0.55, 120.4, true); cyl('lampIn', 0.12, 0.25, -51.6, 0.55, 120.1); // guéridon + lampe
    cyl('frame', 0.02, 1.6, -50.6, 0.07, 125.9, 6); B.add('lampIn', new THREE.ConeGeometry(0.25, 0.3, 14, 1, true).translate(-50.6, 1.75, 125.9), false); col.addCircle(-50.6, 125.9, 0.15, 1.8); // lampadaire
    // rideaux de la grande baie, tableaux, climatisation, étagères murales, LED derrière la télévision
    for (const x of [-54.35, -48.15]) F('curtain', x - 0.3, 0.1, 118.2, x + 0.3, 3.0, 118.28);
    F('frame', -54.8, 2.95, 118.2, -47.7, 3.0, 118.3);
    B.add('art1', new THREE.PlaneGeometry(1.2, 0.8).rotateY(-PI / 2).translate(-46.08, 1.8, 120.5));
    B.add('art2', new THREE.PlaneGeometry(0.9, 1.2).rotateY(-PI / 2).translate(-46.08, 1.7, 123.3));
    F('white', -48.9, 2.55, 126.55, -47.5, 2.85, 126.85); F('frame', -48.85, 2.58, 126.53, -47.55, 2.6, 126.55); // climatisation
    F('furniture', -55.85, 2.1, 125.2, -55.6, 2.13, 126.6); for (let i = 0; i < 4; i++) F(['pot', 'cushion', 'bedding', 'accentRed'][i], -55.8, 2.13, 125.3 + i * 0.32, -55.65, 2.35 + (i % 2) * 0.1, 125.5 + i * 0.32);
    F('ledLiving', -55.86, 2.12, 121.3, -55.82, 2.16, 123.7); F('ledLiving', -55.86, 0.56, 120.9, -55.82, 0.6, 124.1); // rubans LED
    // tapis plus grand sous le coin salon (en plus du tapis existant)
    // ================= CHAMBRE (x −56 → −46, z 127 → 134) =================
    // armoire moderne (mur nord, côté lit)
    F('cabinet', -55.9, 0.07, 127.12, -53.75, 2.35, 127.7, true); F('steel', -54.86, 1.0, 127.71, -54.84, 1.6, 127.73); F('steel', -54.78, 1.0, 127.71, -54.76, 1.6, 127.73);
    // tête de lit capitonnée, banc en bout de lit, plaid, coussins
    F('sofa', -55.95, 0.6, 129.3, -55.8, 1.55, 131.9);
    F('leather', -53.4, 0.07, 129.8, -53.0, 0.5, 131.4, true);
    F('cushion', -54.6, 0.6, 129.55, -54.0, 0.64, 131.65);
    // commode + grand miroir (mur est)
    F('furniture', -46.65, 0.07, 131.2, -46.1, 0.9, 133.2, true); for (const y of [0.3, 0.6]) F('steel', -46.67, y, 131.9, -46.66, y + 0.03, 132.5);
    F('chrome', -46.1, 1.1, 131.5, -46.07, 2.5, 132.9);
    // espace informatique (sous la fenêtre sud)
    F('white', -49.7, 0.74, 133.15, -47.3, 0.79, 133.85, true); F('frame', -49.65, 0.07, 133.2, -49.6, 0.74, 133.8); F('frame', -47.4, 0.07, 133.2, -47.35, 0.74, 133.8);
    F('black', -49.0, 0.88, 133.62, -48.0, 1.45, 133.66); F('frame', -48.53, 0.79, 133.6, -48.47, 0.9, 133.68);  // écran
    F('black', -48.85, 0.79, 133.3, -48.15, 0.81, 133.48); F('black', -47.95, 0.79, 133.35, -47.85, 0.81, 133.48); // clavier, souris
    F('black', -49.55, 0.79, 133.5, -49.35, 1.05, 133.7); F('black', -47.65, 0.79, 133.5, -47.45, 1.05, 133.7); // enceintes
    F('black', -47.15, 0.07, 133.3, -46.8, 0.6, 133.85, true); F('ledBed', -47.16, 0.1, 133.32, -47.15, 0.58, 133.83); // tour du PC
    cyl('frame', 0.015, 0.4, -47.6, 0.79, 133.25, 6); B.add('lampIn', new THREE.ConeGeometry(0.1, 0.12, 10, 1, true).translate(-47.6, 1.22, 133.25), false); // lampe de bureau
    B.add('black', new THREE.TorusGeometry(0.1, 0.02, 6, 12, PI).translate(-49.4, 0.95, 133.35)); // casque audio
    // fauteuil ergonomique
    F('black', -48.75, 0.45, 132.35, -48.25, 0.52, 132.85); F('black', -48.75, 0.52, 132.3, -48.25, 1.2, 132.38); cyl('frame', 0.03, 0.38, -48.5, 0.07, 132.6, 6);
    this.pcScreen = this.screenMesh(0.96, 0.54, -48.5, 1.165, 133.615, PI);
    // espace jeux : télévision murale (mur nord), meuble, console, manette, fauteuil gaming, jeux, LED
    F('black', -51.2, 0.07, 127.12, -48.6, 0.5, 127.55, true); F('ledBed', -51.15, 0.05, 127.56, -48.65, 0.08, 127.6);
    F('black', -51.0, 0.95, 127.07, -48.8, 2.25, 127.12); this.gameTV = this.screenMesh(2.1, 1.2, -49.9, 1.6, 127.125, 0);
    F('ledBed', -51.15, 0.9, 127.06, -48.65, 0.93, 127.08); F('ledBed', -51.15, 2.27, 127.06, -48.65, 2.3, 127.08);
    F('white', -50.6, 0.5, 127.2, -50.4, 0.86, 127.5); F('glossBlack', -50.52, 0.5, 127.18, -50.48, 0.86, 127.52); // console (verticale)
    F('black', -49.3, 0.5, 127.25, -49.05, 0.55, 127.4); // manette
    for (let i = 0; i < 6; i++) F(['accentRed', 'cushion', 'bedding', 'sofa', 'pot', 'black'][i], -48.4 + i * 0.07, 0.07, 127.2, -48.36 + i * 0.07, 0.32, 127.45); // boîtiers de jeux
    // fauteuil gaming
    F('leather', -50.2, 0.4, 129.25, -49.6, 0.5, 129.85); F('leather', -50.2, 0.5, 129.8, -49.6, 1.35, 129.95); F('accentRed', -50.05, 0.9, 129.79, -49.75, 1.25, 129.81); cyl('frame', 0.04, 0.33, -49.9, 0.07, 129.55, 6);
    col.addCircle(-49.9, 129.6, 0.4, 1.3);
    // climatisation, rideaux, tableau, tapis
    F('white', -52.6, 2.55, 133.83, -51.2, 2.85, 133.93);
    for (const x of [-52.25, -47.75]) F('curtain', x - 0.25, 0.1, 133.82, x + 0.25, 3.0, 133.86);
    for (const z of [131.35, 133.65]) F('curtain', -55.9, 0.1, z - 0.25, -55.86, 3.0, z + 0.25);
    B.add('art2', new THREE.PlaneGeometry(1.4, 0.9).rotateY(PI / 2).translate(-55.86, 2.0, 128.2));
    F('ledBed', -55.9, 2.95, 127.2, -46.2, 2.98, 127.24); F('ledBed', -55.9, 2.95, 133.8, -46.2, 2.98, 133.84);
    B.add('rug', new THREE.PlaneGeometry(2.6, 1.8).rotateX(-PI / 2).translate(-49.9, 0.085, 129.1), false);
    B.build(h.group);

    // ---- placards à portes ouvrantes (cuisine) ----
    this.cabDoors = [];
    for (let i = 0; i < 4; i++) {
      const x0 = -41.6 + i * 0.675, piv = new THREE.Group(), left = i % 2 === 0;
      piv.position.set(left ? x0 : x0 + 0.675, 1.6, 125.54);
      const d = new THREE.Mesh(new THREE.BoxGeometry(0.665, 0.7, 0.03), mats.cabinet); d.position.set(left ? 0.333 : -0.333, 0.35, 0); d.castShadow = true; piv.add(d);
      const hd = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.15, 0.02), mats.steel); hd.position.set(left ? 0.6 : -0.6, 0.1, -0.03); piv.add(hd);
      h.group.add(piv); this.cabDoors.push({ piv, left, open: 0, target: 0 });
    }
    this.cabOpen = false;

    // ---- état, interactions ----
    this.decor = { sofa: 0, accent: 0, led: 0, ledBed: 0, curtain: 0, cabinet: 0 };
    this.ledLivingOn = true; this.ledBedOn = true; this.open = null; this.best = { zem: 0, penalty: 0 };
    const add = (x, z, r, label, action) => h.interactables.push({ x, z, r, label, action, when: () => true });
    add(-39.4, 124.85, 0.6, () => (this.cabOpen ? 'Fermer les placards' : 'Ouvrir les placards (vaisselle)'), () => this.toggleCabinets());
    add(-41.1, 124.85, 0.65, () => 'Micro-ondes', () => this.microwave());
    add(-40.2, 124.85, 0.55, () => 'Évier : faire la vaisselle', () => this.dishes());
    add(-47.2, 121.6, 0.9, () => 'Régler l’éclairage du salon (LED)', () => this.cycle('led'));
    add(-48.3, 126.0, 0.9, () => 'Personnaliser la décoration', () => this.openPanel('decor'));
    add(-54.6, 120.9, 0.9, () => 'S’asseoir dans le fauteuil', () => this.sit([-53.5, -0.47, 120.2, 0.35 + PI], [-53.0, 121.2], 'Fauteuil • E : se lever'));
    add(-48.5, 132.0, 0.9, () => 'S’asseoir au bureau (ordinateur)', () => this.usePC());
    add(-49.9, 128.8, 0.9, () => 'Fauteuil gaming : jouer à la console', () => this.useConsole());
    add(-54.8, 128.3, 0.9, () => 'Ouvrir l’armoire de la chambre (tenues)', () => h.wardrobe());
    add(-46.9, 129.0, 0.8, () => 'Régler les LED de la chambre', () => this.cycle('ledBed'));
    this.dom = document.querySelector('#hp');
    this.dom.addEventListener('click', (e) => this.onClick(e));
    this.gameCanvas = document.createElement('canvas'); this.gameCanvas.width = 480; this.gameCanvas.height = 270;
    this.gameTex = new THREE.CanvasTexture(this.gameCanvas); this.gameTex.colorSpace = THREE.SRGBColorSpace;
    this.gameTV.material.map = this.gameTex; this.gameTV.material.color.set(0x000000); this.gameTV.material.needsUpdate = true;
    this.pcTex = this.makePCTex(); this.pcScreen.material.map = this.pcTex; this.pcScreen.material.needsUpdate = true;
    this.applyDecor();
  }

  // ---------- petites textures ----------
  artTex(c) { const cv = document.createElement('canvas'); cv.width = 128; cv.height = 128; const x = cv.getContext('2d'); x.fillStyle = c[2]; x.fillRect(0, 0, 128, 128); x.fillStyle = c[0]; x.beginPath(); x.arc(48, 56, 34, 0, 7); x.fill(); x.fillStyle = c[1]; x.fillRect(64, 20, 44, 88); x.strokeStyle = '#1a1a1a'; x.lineWidth = 6; x.strokeRect(3, 3, 122, 122); const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; return t; }
  tileTex() { const cv = document.createElement('canvas'); cv.width = 128; cv.height = 64; const x = cv.getContext('2d'); for (let i = 0; i < 8; i++) for (let j = 0; j < 4; j++) { x.fillStyle = (i + j) % 3 ? '#e8ecee' : '#2a6a7a'; x.fillRect(i * 16 + (j % 2) * 8, j * 16, 15, 15); } const t = new THREE.CanvasTexture(cv); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(3, 1); t.colorSpace = THREE.SRGBColorSpace; return t; }
  screenMesh(w, hh, x, y, z, ry) { const m = new THREE.Mesh(new THREE.PlaneGeometry(w, hh), new THREE.MeshBasicMaterial({ color: 0x111418, toneMapped: false })); m.position.set(x, y, z); m.rotation.y = ry; this.home.group.add(m); return m; }
  makePCTex() {
    const cv = document.createElement('canvas'); cv.width = 256; cv.height = 144; const x = cv.getContext('2d');
    const g = x.createLinearGradient(0, 0, 256, 144); g.addColorStop(0, '#0b1220'); g.addColorStop(1, '#1f4e9c'); x.fillStyle = g; x.fillRect(0, 0, 256, 144);
    x.fillStyle = '#f2c200'; x.font = 'bold 20px Arial'; x.fillText('NOVA OS', 14, 30); x.fillStyle = '#fff'; x.font = '12px Arial'; x.fillText('Finances • Entreprises • Décoration', 14, 52);
    for (let i = 0; i < 4; i++) { x.fillStyle = ['#e46a1f', '#2fd05a', '#4a8aff', '#a04aff'][i]; x.fillRect(14 + i * 58, 80, 46, 40); }
    const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; return t;
  }

  // ---------- cuisine ----------
  toggleCabinets() { this.cabOpen = !this.cabOpen; for (const d of this.cabDoors) d.target = this.cabOpen ? 1 : 0; this.audio && this.audio.ctx && this.audio.door(); }
  microwave() {
    const k = this.home.game.kitchen;
    if (k && k.pending && k.pending.kind !== 'recipe') { this.ui.toast('Micro-ondes : ton assiette se réchauffe…', 2); if (this.audio && this.audio.ctx) this.audio.tone(980, 0.25, 0.05, 'sine'); k.useStove(); return; }
    this.ui.toast(k && k.pending ? 'Une recette se cuisine à la cuisinière, pas au micro-ondes.' : 'Rien à réchauffer : compose d’abord une assiette au réfrigérateur.', 2.5);
  }
  dishes() { this.home.startActivity('wash', 3); this.ui.toast('Tu fais la vaisselle. Propreté +20', 2); }

  // ---------- assise générique (fauteuil, bureau, fauteuil gaming) ----------
  sit(seat, exit, label, onEnd) { this.home.startActivity('seat', Infinity, { seat, exit, label, onEnd }); }
  usePC() { this.sit([-48.5, -0.47, 132.6, PI], [-48.5, 131.7], 'Au bureau • E : se lever', () => this.closePanel()); this.openPanel('pc'); }
  useConsole() { this.sit([-49.9, -0.42, 129.55, PI], [-49.9, 130.6], 'Fauteuil gaming • E : se lever', () => this.closePanel()); this.openPanel('console'); }

  // ---------- éclairage et décoration ----------
  cycle(key) { const n = DECOR[key].opts.length; this.decor[key] = (this.decor[key] + 1) % (n + 1); this.applyDecor(); const i = this.decor[key]; this.ui.toast(`${DECOR[key].label} : ${i === n ? 'éteint' : DECOR[key].opts[i][0]}`, 1.6); this.onSave && this.onSave(); }
  applyDecor() {
    const m = this.home.mats, d = this.decor, col = (k) => (DECOR[k].opts[d[k]] || DECOR[k].opts[0])[1];
    m.sofa.color.setHex(col('sofa')); m.accentWall.color.setHex(col('accent')); m.curtain.color.setHex(col('curtain')); m.cabinet.color.setHex(col('cabinet'));
    const led = (mat, k) => { const off = d[k] >= DECOR[k].opts.length; mat.color.setHex(off ? 0x222222 : col(k)); };
    led(m.ledLiving, 'led'); led(m.ledBed, 'ledBed');
  }

  // ---------- interfaces : ordinateur, console, décoration ----------
  openPanel(kind) { this.open = kind; this.tab = kind === 'pc' ? 'fin' : null; this.game = null; this.dom.classList.add('show'); this.render(); }
  closePanel() { if (!this.open) return; this.open = null; this.game = null; this.dom.classList.remove('show'); if (this.home.activity && this.home.activity.data.seat) this.home.endActivity(false); }
  render() {
    const E = this.economy, N = this.nova;
    let body = '';
    if (this.open === 'pc' || this.open === 'decor') {
      const tabs = this.open === 'pc' ? [['fin', '💳 Finances'], ['ent', '🏢 Mes entreprises'], ['deco', '🎨 Décoration']] : [];
      const t = this.open === 'decor' ? 'deco' : this.tab;
      body = `<div class="hp-tabs">${tabs.map(([k, l]) => `<button data-tab="${k}" class="${k === t ? 'on' : ''}">${l}</button>`).join('')}</div><div class="hp-body">`;
      if (t === 'fin') body += `<div class="hp-kpi"><div><small>Solde personnel</small><b>${fcfa(E.balance)}</b></div><div><small>Achats en cours de livraison</small><b>${E.orders.length}</b></div><div><small>Articles possédés</small><b>${Object.values(E.items).reduce((a, b) => a + b, 0)}</b></div></div>
        <h5>Dernières opérations</h5>${E.history.slice(0, 12).map((h) => `<div class="hp-row"><span>${h.label}<small>${h.place} • ${h.t}</small></span><em class="${h.amount < 0 ? 'neg' : 'pos'}">${h.amount < 0 ? '−' : '+'}${fcfa(Math.abs(h.amount))}</em></div>`).join('')}`;
      else if (t === 'ent') {
        const C = N && N.company, staff = C ? C.staff : N ? N.staff : [], mass = C ? C.massSalary() : staff.reduce((a, s) => a + JOBS[s.job].salary, 0);
        body += `<div class="hp-kpi"><div><small>NOVA BOOK — employés</small><b>${staff.length}</b></div><div><small>Masse salariale mensuelle</small><b>${fcfa(mass)}</b></div><div><small>Trésorerie</small><b>${C ? fcfa(C.cash) : '—'}</b></div></div>
          <h5>Équipe par département</h5>${Object.entries(staff.reduce((a, s) => { const d = JOBS[s.job].dept; a[d] = (a[d] || 0) + 1; return a; }, {})).map(([k, n]) => `<div class="hp-row"><span>${k}</span><em>${n}</em></div>`).join('')}
          <button class="hp-biz" data-biz>💼 Ouvrir NOVA Gestion (recrutement, paie, commandes, comptabilité)</button>
          <p class="hp-note">Le même logiciel est disponible au bureau du PDG, au 5e étage du siège.</p>`;
      } else {
        body += Object.entries(DECOR).map(([k, D]) => `<h5>${D.label}</h5><div class="hp-sw">${D.opts.map(([n, c], i) => `<button data-deco="${k}:${i}" class="${this.decor[k] === i ? 'on' : ''}" title="${n}"><i style="background:#${c.toString(16).padStart(6, '0')}"></i>${n}</button>`).join('')}${k.startsWith('led') ? `<button data-deco="${k}:${D.opts.length}" class="${this.decor[k] === D.opts.length ? 'on' : ''}"><i style="background:#222"></i>Éteint</button>` : ''}</div>`).join('');
      }
      body += '</div>';
    } else if (this.open === 'console') {
      if (!this.game) body = `<p class="hp-note">Console de salon NOVA X — choisis un jeu (manette : flèches + Espace, ou boutons tactiles).</p><div class="hp-games">${GAMES.map((g) => `<button data-game="${g.id}"><b>${g.name}</b><small>${g.desc}</small><em>Record : ${this.best[g.id]}</em></button>`).join('')}</div>`;
      else body = `<div class="hp-play"><canvas class="hp-cv" width="480" height="270"></canvas><div class="hp-pad"><button data-pad="L">◀</button><button data-pad="A">●</button><button data-pad="R">▶</button></div></div>`;
    }
    const title = { pc: '💻 Ordinateur — NOVA OS', decor: '🎨 Décoration de la maison', console: '🎮 Console NOVA X' }[this.open];
    this.dom.innerHTML = `<div class="hp-box"><div class="hp-head"><b>${title}</b>${this.game ? '<button data-back>↩ Jeux</button>' : ''}<button data-x>✕</button></div>${body}</div>`;
    if (this.game) this.view = this.dom.querySelector('.hp-cv').getContext('2d');
  }
  onClick(e) {
    const b = e.target.closest('[data-x],[data-tab],[data-deco],[data-game],[data-back],[data-pad],[data-biz]');
    if (!b) { if (e.target === this.dom) this.closePanel(); return; }
    e.stopPropagation(); if (this.audio && this.audio.ctx) this.audio.click();
    if (b.dataset.x !== undefined) return this.closePanel();
    if (b.dataset.biz !== undefined && this.openBiz) { this.dom.classList.remove('show'); this.open = 'biz'; this.openBiz(() => this.closePanel()); return; }
    if (b.dataset.tab) { this.tab = b.dataset.tab; return this.render(); }
    if (b.dataset.deco) { const [k, i] = b.dataset.deco.split(':'); this.decor[k] = +i; this.applyDecor(); this.onSave && this.onSave(); return this.render(); }
    if (b.dataset.game) { this.startGame(b.dataset.game); return; }
    if (b.dataset.back !== undefined) { this.game = null; return this.render(); }
    if (b.dataset.pad) this.padHit = b.dataset.pad;
  }
  handleKeys(input) {
    if (input.hit('Escape')) { if (this.game) { this.game = null; this.render(); } else this.closePanel(); return; }
    if (input.hit('KeyE') && !this.game) { this.closePanel(); return; }
    if (this.game) { if (input.hit('ArrowLeft') || input.hit('KeyA') || input.hit('KeyQ')) this.padHit = 'L'; if (input.hit('ArrowRight') || input.hit('KeyD')) this.padHit = 'R'; if (input.hit('Space') || input.hit('Enter')) this.padHit = 'A'; }
  }

  // ---------- mini-jeux ----------
  startGame(id) {
    this.game = id === 'zem' ? { id, lane: 1, t: 0, score: 0, speed: 120, cars: [], over: false, spawn: 0 } : { id, aim: 0, dir: 1, phase: 'aim', power: 0, goals: 0, shots: 0, ball: null, keeper: 0, kdir: 1, msg: '' };
    this.render();
  }
  updateGame(dt) {
    const G = this.game, x = this.gameCanvas.getContext('2d'), W = 480, H = 270, hit = this.padHit; this.padHit = null;
    if (G.id === 'zem') {
      if (!G.over) {
        if (hit === 'L') G.lane = Math.max(0, G.lane - 1); if (hit === 'R') G.lane = Math.min(2, G.lane + 1);
        G.t += dt; G.speed = 120 + G.t * 6; G.spawn -= dt; G.score += dt * 10;
        if (G.spawn <= 0) { G.spawn = Math.max(0.35, 1.1 - G.t * 0.02); G.cars.push({ lane: Math.floor(Math.random() * 3), y: -40, c: ['#c8102e', '#1f4e9c', '#f2c200', '#f2f2f2'][Math.floor(Math.random() * 4)] }); }
        for (const c of G.cars) c.y += G.speed * dt;
        G.cars = G.cars.filter((c) => c.y < H + 40);
        for (const c of G.cars) if (c.lane === G.lane && c.y > H - 80 && c.y < H - 20) { G.over = true; this.best.zem = Math.max(this.best.zem, Math.floor(G.score)); this.onSave && this.onSave(); }
      } else if (hit === 'A') { this.startGame('zem'); return; }
      x.fillStyle = '#2a2b30'; x.fillRect(0, 0, W, H); x.fillStyle = '#c9b98a'; x.fillRect(0, 0, 90, H); x.fillRect(W - 90, 0, 90, H);
      x.fillStyle = '#f2f2f2'; for (let i = 0; i < 2; i++) for (let y = (G.t * G.speed) % 40 - 40; y < H; y += 40) x.fillRect(90 + (i + 1) * 100 - 2, y, 4, 20);
      for (const c of G.cars) { x.fillStyle = c.c; x.fillRect(90 + c.lane * 100 + 22, c.y - 30, 56, 60); x.fillStyle = '#111'; x.fillRect(90 + c.lane * 100 + 28, c.y - 18, 44, 14); }
      const px = 90 + G.lane * 100 + 50; x.fillStyle = '#111'; x.fillRect(px - 6, H - 70, 12, 46); x.fillStyle = '#f2c200'; x.beginPath(); x.arc(px, H - 56, 11, 0, 7); x.fill();
      x.fillStyle = '#fff'; x.font = 'bold 18px Arial'; x.fillText(`ZEM RUSH  ${Math.floor(G.score)}`, 10, 24); x.fillText(`Record ${this.best.zem}`, W - 130, 24);
      if (G.over) { x.fillStyle = 'rgba(0,0,0,0.6)'; x.fillRect(0, 0, W, H); x.fillStyle = '#f2c200'; x.font = 'bold 30px Arial'; x.textAlign = 'center'; x.fillText('ACCIDENT !', W / 2, H / 2 - 10); x.font = '16px Arial'; x.fillStyle = '#fff'; x.fillText(`Score ${Math.floor(G.score)} • ● / Espace pour rejouer`, W / 2, H / 2 + 20); x.textAlign = 'left'; }
    } else {
      G.keeper += G.kdir * dt * 0.9; if (Math.abs(G.keeper) > 1) G.kdir *= -1;
      if (G.phase === 'aim') { G.aim += G.dir * dt * 1.4; if (Math.abs(G.aim) > 1) G.dir *= -1; if (hit === 'L') G.aim = Math.max(-1, G.aim - 0.25); if (hit === 'R') G.aim = Math.min(1, G.aim + 0.25); if (hit === 'A') { G.phase = 'shot'; G.ball = { t: 0, tx: G.aim }; G.shots++; } }
      else if (G.phase === 'shot') { G.ball.t += dt * 1.6; if (G.ball.t >= 1) { const saved = Math.abs(G.keeper - G.ball.tx) < 0.35; if (!saved) G.goals++; G.msg = saved ? 'Arrêté par le gardien !' : 'BUT !!!'; G.phase = 'res'; G.wait = 1.4; if (G.shots >= 5) { this.best.penalty = Math.max(this.best.penalty, G.goals); this.onSave && this.onSave(); } } }
      else { G.wait -= dt; if (G.wait <= 0) { if (G.shots >= 5) { if (hit === 'A') { this.startGame('penalty'); return; } G.msg = `Fin : ${G.goals}/5 • ● pour rejouer`; } else { G.phase = 'aim'; G.msg = ''; } } }
      x.fillStyle = '#2f8a3a'; x.fillRect(0, 0, W, H); x.fillStyle = '#3a9a46'; for (let i = 0; i < 8; i++) x.fillRect(i * 60, 0, 30, H);
      x.strokeStyle = '#fff'; x.lineWidth = 5; x.strokeRect(100, 40, 280, 110); x.fillStyle = 'rgba(255,255,255,0.15)'; x.fillRect(100, 40, 280, 110);
      const kx = 240 + G.keeper * 110; x.fillStyle = '#f2c200'; x.fillRect(kx - 14, 90, 28, 58); x.fillStyle = '#5a3a26'; x.beginPath(); x.arc(kx, 82, 10, 0, 7); x.fill();
      const tx = 240 + (G.ball ? G.ball.tx : G.aim) * 120;
      if (G.phase === 'aim') { x.strokeStyle = '#c8102e'; x.lineWidth = 3; x.beginPath(); x.arc(tx, 95, 12, 0, 7); x.stroke(); }
      const bt = G.ball ? Math.min(1, G.ball.t) : 0, bx = 240 + (tx - 240) * bt, by = 240 - 145 * bt, br = 12 - bt * 5;
      x.fillStyle = '#fff'; x.beginPath(); x.arc(bx, by, br, 0, 7); x.fill();
      x.fillStyle = '#fff'; x.font = 'bold 18px Arial'; x.fillText(`PENALTY COTONOU  ${G.goals}/${G.shots}`, 10, 24); x.fillText(`Record ${this.best.penalty}/5`, W - 140, 24);
      if (G.msg) { x.textAlign = 'center'; x.font = 'bold 26px Arial'; x.fillStyle = '#f2c200'; x.fillText(G.msg, W / 2, H - 20); x.textAlign = 'left'; }
    }
    this.gameTex.needsUpdate = true;
    if (this.view) this.view.drawImage(this.gameCanvas, 0, 0);
  }

  // ---------- boucle ----------
  update(dt) {
    for (const d of this.cabDoors) { d.open += (d.target - d.open) * Math.min(1, dt * 6); d.piv.rotation.y = (d.left ? -1 : 1) * d.open * 1.9; }
    if (this.game) this.updateGame(dt);
  }
  serialize() { return { decor: this.decor, best: this.best }; }
  restore(s) { if (!s) return; if (s.decor) Object.assign(this.decor, s.decor); if (s.best) Object.assign(this.best, s.best); this.applyDecor(); }
}
