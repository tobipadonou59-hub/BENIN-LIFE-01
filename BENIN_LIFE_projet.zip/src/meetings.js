// Mission 017, étape 4 — réunions d'affaires.
// Agenda (téléphone) → création d'une réunion (type, date, heure, salle, participants, ordre du jour) → invitations
// envoyées par message → confirmations (ou excuses) des invités → plan de table → préparation de la présentation →
// séance dans la salle choisie (accueil, présentation avec les vrais chiffres, avis des participants, décisions du PDG
// avec de vrais effets) → compte rendu archivé et envoyé aux participants. Réunion manquée : conséquences réelles.
// Toutes les sommes sont de la monnaie fictive du jeu ; chaque dépense est affichée sur le bouton de décision.
import { JOBS } from './nova-data.js';
import { fcfa } from './food-data.js';
import { CLIENTS } from './company.js';
import { PROJECT_TYPES } from './projects.js';
import { INSTR } from './group.js';

const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const hh = (h) => `${String(Math.floor(h)).padStart(2, '0')}:${String(Math.round((h % 1) * 60)).padStart(2, '0')}`;
const TYPES = {
  direction: { label: 'Comité de direction NOVA BOOK', icon: '🏛️', rooms: ['conseil', 'rdc', 'visio'] },
  equipe: { label: 'Réunion de département', icon: '👥', rooms: ['rdc', 'conseil', 'visio'] },
  filiales: { label: 'Réunion des directeurs du groupe', icon: '🏢', rooms: ['conseil', 'visio'] },
  filiale: { label: 'Réunion dans une filiale', icon: '🏬', rooms: ['sub'] },
  client: { label: 'Rendez-vous client', icon: '🤝', rooms: ['rdc', 'conseil', 'visio'] },
  reseau: { label: 'Rendez-vous avec un contact', icon: '☕', rooms: ['rdc', 'visio'] },
};
const MAX_PARTS = 9, MAX_ITEMS = 4;

export class Meetings {
  constructor(ctx) {
    Object.assign(this, ctx); // company, group, projects, phonePlus, social, talk, ceoLife, economy, env, ui, audio, needs, onSave
    this.list = []; this.uid = 1; this.queue = []; this.open = false; this.view = 'list'; this.sel = null; this.form = null; this.S = null; this.swap = null;
    this.dom = document.querySelector('#mtg');
    this.dom.addEventListener('click', (e) => this.onClick(e));
  }
  day() { return this.company.day; }
  now() { return this.env.time; }
  get(id) { return this.list.find((m) => m.id === id) || null; }
  // ------------------------------------------------------------------ salles et participants
  rooms(type, sub) {
    const T = TYPES[type], G = this.group, out = [];
    for (const r of T.rooms) {
      if (r === 'sub') { if (sub && G && G.subs[sub]) out.push(`f:${sub}`); }
      else out.push(r);
    }
    return out;
  }
  roomInfo(r) {
    if (r === 'conseil') return { label: 'Salle du conseil — tour NOVA BOOK (étage de direction)', short: 'Salle du conseil', seats: 10 };
    if (r === 'rdc') return { label: 'Salle de réunion — tour NOVA BOOK (rez-de-chaussée)', short: 'Salle de réunion RDC', seats: 8 };
    if (r === 'visio') return { label: 'Visioconférence (depuis le téléphone, n’importe où)', short: 'Visio', seats: 0 };
    const s = this.group && this.group.subs[r.slice(2)]; return { label: `Salle de réunion — bureaux de ${s ? s.name : '?'}`, short: s ? s.name : '?', seats: 8 };
  }
  candidates(type, opt = {}) {
    const P = this.phonePlus, C = this.company, G = this.group, emp = P.employees();
    if (type === 'direction') return emp.filter((c) => c.acc === 'book' && ['directeur', 'comptable', 'rh', 'commercial', 'secretaire'].includes(c.emp.job)).concat(emp.filter((c) => c.acc === 'book' && !['directeur', 'comptable', 'rh', 'commercial', 'secretaire'].includes(c.emp.job)));
    if (type === 'equipe') return emp.filter((c) => c.acc === 'book' && (!opt.dept || c.emp.dept === opt.dept));
    if (type === 'filiales') return emp.filter((c) => c.acc !== 'book' && G && G.subs[c.acc] && G.subs[c.acc].director === c.emp.id).concat(emp.filter((c) => c.acc === 'book' && ['directeur', 'comptable'].includes(c.emp.job)));
    if (type === 'filiale') return emp.filter((c) => c.acc === opt.sub);
    if (type === 'client') return [...P.contacts('cli'), ...emp.filter((c) => c.acc === 'book' && ['commercial', 'directeur'].includes(c.emp.job))];
    if (type === 'reseau') return P.contacts('ami');
    return [];
  }
  // ------------------------------------------------------------------ ordre du jour (points avec vrais effets)
  catalog(type, opt = {}) {
    const C = this.company, G = this.group, out = [{ id: 'bilan', label: 'Bilan et chiffres du moment (information)' }];
    if (type === 'direction' || type === 'equipe') {
      const scope = type === 'equipe' && opt.dept ? opt.dept : null, n = C.staff.filter((e) => !scope || e.dept === scope).length;
      out.push({ id: 'salaires', label: `Revalorisation des salaires de +5 % (${scope || 'tout NOVA BOOK'})`, cost: () => Math.round(C.staff.filter((e) => !scope || e.dept === scope).reduce((a, e) => a + e.salary * 0.05, 0)), costNote: 'par mois' });
      out.push({ id: 'prime', label: `Prime exceptionnelle de 50 000 FCFA (${n} employé${n > 1 ? 's' : ''})`, cost: () => 50000 * n });
      out.push({ id: 'formation', label: 'Former l’employé le moins expérimenté (150 000 FCFA)', cost: () => 150000 });
      out.push({ id: 'recrut', label: 'Lancer une annonce de recrutement (50 000 FCFA)', cost: () => 50000 });
      for (const d of Object.keys(C.equip)) if ((!scope || scope === d) && C.equip[d] < 3) out.push({ id: `equip:${d}`, label: `Investir dans l’équipement — ${d} (niveau ${C.equip[d] + 1})`, cost: () => C.equipCost(d) });
      for (const T of PROJECT_TYPES) if (!scope || scope === T.dept) out.push({ id: `projet:${T.id}`, label: `Lancer un projet : ${T.label}`, cost: () => T.budget });
      for (const o of C.offers.slice(0, 4)) if (!scope || scope === o.dept) out.push({ id: `offre:${o.oid}`, label: `Proposition de ${o.client.replace(/ \(fictiv?e?\)/, '')} : ${o.label} (${fcfa(o.price)})` });
    }
    if (type === 'filiales' || type === 'filiale') for (const s of Object.values(G ? G.subs : {})) if (type === 'filiales' || s.id === opt.sub) {
      for (const [k, v] of Object.entries(INSTR)) out.push({ id: `consigne:${s.id}|${k}`, label: `${s.name} : ${v.label.toLowerCase()} (${v.effect})` });
      if (s.equip < 3) out.push({ id: `equipsub:${s.id}`, label: `${s.name} : moderniser les équipements`, cost: () => [0, 1200000, 2500000][s.equip], acc: s.id });
    }
    if (type === 'client') { out.push({ id: 'commande', label: 'Proposer une nouvelle commande au client' }, { id: 'partenariat', label: 'Partenariat commercial (prix +5 % pendant 10 jours)' }, { id: 'remise', label: 'Remise de fidélité de 5 % (réputation +3)' }); }
    if (type === 'reseau') out.push({ id: 'reseau', label: 'Faire mieux connaissance et échanger des idées' }, { id: 'conseil', label: 'Demander un conseil sur un projet de NOVA BOOK' });
    return out;
  }
  itemLabel(m, id) { const it = this.catalog(m.type, m.opt).find((q) => q.id === id); return it ? it.label : (m.labels && m.labels[id]) || id; }
  // ------------------------------------------------------------------ création, invitations, confirmations
  newForm() { this.form = { type: 'direction', opt: {}, dayOff: 0, hour: Math.min(18, Math.max(9, Math.ceil(this.now() + 1))), room: 'conseil', parts: [], items: ['bilan'] }; this.view = 'new'; this.fixForm(); }
  fixForm() {
    const F = this.form, R = this.rooms(F.type, F.opt.sub); if (!R.includes(F.room)) F.room = R[0];
    const cand = this.candidates(F.type, F.opt).map((c) => c.key); F.parts = F.parts.filter((k) => cand.includes(k));
    const cat = this.catalog(F.type, F.opt).map((q) => q.id); F.items = F.items.filter((k) => cat.includes(k)); if (!F.items.length) F.items = ['bilan'];
  }
  create() {
    const F = this.form, day = this.day() + F.dayOff;
    if (!F.parts.length) return this.ui.toast('Invite au moins une personne.', 2);
    if (F.dayOff === 0 && F.hour < this.now() + 0.25) return this.ui.toast('Choisis une heure plus tardive (au moins 15 minutes à l’avance).', 2.5);
    if (this.list.some((m) => m.status === 'prévue' && m.day === day && Math.abs(m.hour - F.hour) < 1)) return this.ui.toast('Tu as déjà une réunion à cette heure-là.', 2.5);
    const seats = this.roomInfo(F.room).seats; if (seats && F.parts.length > seats) return this.ui.toast(`Cette salle n’a que ${seats} places.`, 2);
    const T = TYPES[F.type], labels = {}; for (const id of F.items) labels[id] = this.itemLabel({ type: F.type, opt: F.opt }, id);
    const m = { id: this.uid++, type: F.type, opt: { ...F.opt }, title: `${T.label}${F.opt.dept ? ` — ${F.opt.dept}` : ''}${F.opt.sub && this.group.subs[F.opt.sub] ? ` — ${this.group.subs[F.opt.sub].name}` : ''}`, day, hour: F.hour, room: F.room, parts: [...F.parts], rsvp: {}, why: {}, items: [...F.items], labels, seats: [], prepared: false, status: 'prévue', created: this.economy.stamp(), minutes: null };
    for (const k of m.parts) {
      m.rsvp[k] = 'attente';
      this.phonePlus.push(k, 'me', `📅 Invitation : ${m.title}, ${this.when(m)}, ${this.roomInfo(m.room).short}. Ordre du jour : ${m.items.map((i) => labels[i].replace(/ \(.*\)$/, '')).join(' ; ')}. Merci de confirmer.`);
      this.queue.push({ mid: m.id, key: k, at: performance.now() + 1500 + Math.random() * 4000 });
    }
    this.autoSeat(m); this.list.unshift(m); this.sel = m.id; this.view = 'detail'; this.form = null;
    this.ui.toast(`📨 ${m.parts.length} invitation(s) envoyée(s)`, 2); this.onSave && this.onSave();
  }
  when(m) { const d = m.day - this.day(); return `${d === 0 ? 'aujourd’hui' : d === 1 ? 'demain' : `dans ${d} jours (J${m.day})`} à ${hh(m.hour)}`; }
  respond(m, k) {
    if (!m || m.status !== 'prévue' || m.rsvp[k] !== 'attente') return;
    const c = this.phonePlus.contact(k); if (!c) { m.rsvp[k] = 'non'; m.why[k] = 'contact introuvable'; return; }
    let yes = true, why = '';
    if (c.kind === 'emp') { const e = c.emp; if (m.day === this.day() && e.status && e.status !== 'présent') { yes = false; why = `je suis en ${e.status} ce jour-là`; } else if (e.morale < 35 && Math.random() < 0.35) { yes = false; why = 'je ne me sens pas bien, je m’excuse'; } }
    else if (c.kind === 'cli') { const rep = this.ceoLife ? this.ceoLife.rep : 50; if (Math.random() > 0.55 + rep / 200) { yes = false; why = 'notre agenda est complet ce jour-là'; } }
    else if (c.kind === 'ami') { const r = c.friend.rapport; if (r < 45 && Math.random() < 0.5) { yes = false; why = 'je ne suis pas disponible, désolé·e'.replace('é·e', c.friend.female ? 'ée' : 'é'); } }
    m.rsvp[k] = yes ? 'oui' : 'non'; if (why) m.why[k] = why;
    this.phonePlus.receive(k, yes ? `✅ C’est noté pour ${m.title.toLowerCase().startsWith('rendez') ? 'notre rendez-vous' : 'la réunion'} (${this.when(m)}), je serai là.` : `❌ Désolé, je ne pourrai pas venir : ${why}.`);
    if (!yes) m.seats = m.seats.map((s) => (s === k ? null : s));
    this.render(); this.onSave && this.onSave();
  }
  cancel(m) {
    if (m.status !== 'prévue') return; m.status = 'annulée';
    for (const k of m.parts) if (m.rsvp[k] !== 'non') this.phonePlus.push(k, 'me', `📅 Annulation : ${m.title} (${this.when(m)}) est annulée. Désolé pour le dérangement.`);
    this.ui.toast('Réunion annulée, les invités sont prévenus.', 2.2); this.onSave && this.onSave();
  }
  prepare(m) {
    if (m.prepared) return; if (m.day === this.day() && this.now() + 1 > m.hour + 0.25) return this.ui.toast('Plus assez de temps pour préparer la présentation (1 heure).', 2.5);
    m.prepared = true; this.env.time = (this.env.time + 1) % 24; if (this.needs) this.needs.energy = Math.max(0, this.needs.energy - 4);
    this.ui.toast('📊 Présentation préparée (1 heure de travail) : chiffres, projets et propositions sont prêts.', 3); this.onSave && this.onSave();
  }
  // ------------------------------------------------------------------ plan de table
  autoSeat(m) { const n = this.roomInfo(m.room).seats; if (!n) { m.seats = []; return; } const order = [...m.parts].filter((k) => m.rsvp[k] !== 'non').sort((a, b) => this.rank(b) - this.rank(a)); m.seats = Array.from({ length: n }, (_, i) => order[i] || null); }
  fem(k) { const c = this.phonePlus.contact(k); if (!c) return false; if (c.friend) return c.friend.female; if (c.emp && this.talk) { const p = this.talk.find(k); return p ? this.talk.profile(p).female : false; } return false; }
  rank(k) { const c = this.phonePlus.contact(k); if (!c) return 0; if (c.kind === 'cli') return 10; if (c.kind === 'ami') return 8; const e = c.emp; return (this.group && c.acc !== 'book' && this.group.subs[c.acc] && this.group.subs[c.acc].director === e.id ? 7 : 0) + ({ directeur: 6, comptable: 5, rh: 4, commercial: 4 }[e.job] || 1) + e.grade * 0.1; }
  seatSVG(m) {
    const n = m.seats.length; if (!n) return '<p class="ph-note">Visioconférence : pas de plan de table.</p>';
    const half = Math.ceil(n / 2), W = 360, H = 150, tx = 70, tw = 240;
    const pos = (i) => { const top = i % 2 === 0, j = Math.floor(i / 2); return { x: tx + 20 + j * ((tw - 40) / Math.max(1, half - 1)), y: top ? 30 : 120, top }; };
    const nm = (k) => { const c = k && this.phonePlus.contact(k); return c ? c.name.split(' ')[0].slice(0, 9) : 'libre'; };
    let s = `<svg viewBox="0 0 ${W} ${H}" class="mt-plan"><rect x="${tx}" y="50" width="${tw}" height="50" rx="10" fill="#6a4426"/><circle cx="${tx - 22}" cy="75" r="17" fill="#fcd116"/><text x="${tx - 22}" y="79" text-anchor="middle" font-size="10" font-weight="900">PDG</text>`;
    m.seats.forEach((k, i) => { const p = pos(i), on = this.swap === i, guest = k && /^c:|^n:/.test(k); s += `<g data-mt="seat:${i}" style="cursor:pointer"><circle cx="${p.x}" cy="${p.y}" r="16" fill="${on ? '#e46a1f' : k ? (guest ? '#0b6e4f' : '#1f4e9c') : '#c9bb9f'}" stroke="#fff" stroke-width="2"/><text x="${p.x}" y="${p.top ? p.y - 20 : p.y + 29}" text-anchor="middle" font-size="10" fill="#1a140c">${esc(nm(k))}</text><text x="${p.x}" y="${p.y + 4}" text-anchor="middle" font-size="10" fill="#fff">${i + 1}</text></g>`; });
    return s + '</svg><p class="ph-note">Touche deux places pour échanger. Places 1 et 2 : à côté du PDG (invités d’honneur). En vert : invités extérieurs.</p>';
  }
  // ------------------------------------------------------------------ séance
  window(m) { return m.status === 'prévue' && m.day === this.day() && this.now() >= m.hour - 0.5 && this.now() <= m.hour + 2; }
  tryStart(room) { // appelé depuis les points « salle de réunion »
    const m = this.list.find((q) => q.room === room && this.window(q)); if (!m) return false;
    this.begin(m); return true;
  }
  begin(m) {
    const present = m.parts.filter((k) => m.rsvp[k] === 'oui'); if (!present.length) { this.ui.toast('Aucun invité n’a confirmé : la réunion ne peut pas commencer.', 3); return; }
    const late = this.now() - m.hour > 0.25, lateGuests = present.filter((k, i) => (m.id * 7 + i * 13) % 10 === 0);
    this.S = { m, phase: 'accueil', idx: 0, slide: 0, present, lateGuests, late, decisions: [], ops: {} };
    m.status = 'en cours'; m.started = this.economy.stamp(); this.open = true; this.view = 'session'; this.dom.classList.add('show'); this.render();
  }
  opinion(k, item, m) {
    const c = this.phonePlus.contact(k); if (!c) return { v: 0, txt: '…' };
    const C = this.company, G = this.group, [id, arg] = item.split(':');
    const nm = c.name.split(' ')[0];
    if (c.kind === 'cli') {
      const rep = this.ceoLife ? this.ceoLife.rep : 50, conv = rep / 100 + (m.prepared ? 0.25 : -0.1) + (m.seats.indexOf(k) <= 1 && m.seats.length ? 0.1 : 0);
      if (id === 'remise') return { v: 1, txt: 'Une remise ? Nous apprécions ce geste, merci.' };
      if (id === 'bilan') return { v: 0, txt: 'Merci pour ces informations.' };
      return conv >= 0.6 ? { v: 1, txt: m.prepared ? 'Votre présentation est convaincante. Nous sommes d’accord.' : 'Votre réputation parle pour vous : d’accord.' } : conv >= 0.45 ? { v: 0, txt: 'Nous devons y réfléchir encore.' } : { v: -1, txt: 'Pour l’instant, ce n’est pas le moment pour nous.' };
    }
    if (c.kind === 'ami') return id === 'conseil' ? { v: 1, txt: `À ta place, je miserais sur la qualité : les gens recommandent ce qui est bien fait. (${c.friend.job})` } : { v: 1, txt: 'Ravi·e de cet échange, on reste en contact !'.replace('Ravi·e', c.friend.female ? 'Ravie' : 'Ravi') };
    const e = c.emp, job = e.job, trait = this.talk ? this.talk.profile(this.talk.find(k) || { e }).trait : 'pragmatique';
    const tone = (t) => (trait === 'enthousiaste' && /^Je suis pour/.test(t) ? t + ' 👍' : t);
    if (id === 'bilan') return { v: 0, txt: e.morale < 45 ? 'Les chiffres sont là, mais l’équipe est fatiguée.' : 'Merci pour la transparence, PDG.' };
    if (id === 'salaires') return job === 'comptable' && C.cash < C.massSalary() * 2 ? { v: -1, txt: `La trésorerie (${fcfa(C.cash)}) ne permet pas une hausse durable.` } : { v: 1, txt: tone('Je suis pour : l’équipe sera plus motivée.') };
    if (id === 'prime') return job === 'comptable' && C.cash < 3000000 ? { v: 0, txt: 'Prudence : la trésorerie est juste.' } : { v: 1, txt: tone('Je suis pour, c’est un beau geste.') };
    if (id === 'formation') return { v: 1, txt: tone('Je suis pour : la compétence, c’est la qualité.') };
    if (id === 'recrut') { const full = Object.keys(C.equip).some((d) => C.orders.filter((o) => o.dept === d).length >= C.capacity(d)); return job === 'rh' || full ? { v: 1, txt: full ? 'Je suis pour : certains départements sont complets.' : 'Je suis pour, je m’occupe des entretiens.' } : { v: 0, txt: 'Je ne vois pas d’urgence à recruter.' }; }
    if (id === 'equip') { const cost = C.equipCost(arg); return job === 'comptable' && C.cash < cost * 2 ? { v: -1, txt: `Investir ${fcfa(cost)} maintenant serait risqué.` } : e.dept === arg || job === 'directeur' ? { v: 1, txt: tone('Je suis pour : nos machines nous ralentissent.') } : { v: 0, txt: 'Pourquoi pas, si les finances le permettent.' }; }
    if (id === 'projet') { const T = PROJECT_TYPES.find((q) => q.id === arg); return T && C.cash < T.budget * 1.5 && job === 'comptable' ? { v: -1, txt: `Le budget de ${fcfa(T.budget)} pèserait sur la trésorerie.` } : T && e.dept === T.dept ? { v: 1, txt: tone('Je suis pour, et je veux bien en faire partie !') } : { v: 0, txt: 'C’est intéressant.' }; }
    if (id === 'offre') { const o = C.offers.find((q) => q.oid === arg); if (!o) return { v: 0, txt: 'Cette proposition n’est plus disponible.' }; const full = C.orders.filter((q) => q.dept === o.dept).length >= C.capacity(o.dept); return full ? { v: -1, txt: `Le département ${o.dept} est déjà complet.` } : { v: 1, txt: tone(`Je suis pour : ${fcfa(o.price)} de chiffre d’affaires.`) }; }
    if (id === 'consigne') { const [sid, k2] = arg.split('|'), s = G && G.subs[sid]; const avg = s ? s.staff.reduce((a, q) => a + q.morale, 0) / Math.max(1, s.staff.length) : 60; return k2 === 'cadence' && avg < 55 ? { v: -1, txt: 'Les équipes sont déjà fatiguées, accélérer serait risqué.' } : k2 === 'economies' && s && s.cash > 5000000 ? { v: 0, txt: 'La trésorerie est saine, est-ce nécessaire ?' } : { v: 1, txt: 'D’accord avec cette orientation.' }; }
    if (id === 'equipsub') return { v: 1, txt: 'Je suis pour : de meilleurs outils, une meilleure production.' };
    if (id === 'commande' || id === 'partenariat' || id === 'remise') return id === 'remise' && job === 'comptable' ? { v: 0, txt: 'Une remise réduit nos marges, mais fidélise.' } : { v: 1, txt: 'Je soutiens la proposition.' };
    return { v: 0, txt: 'Je n’ai pas d’avis tranché.' };
  }
  decide(dec) {
    const S = this.S, m = S.m, item = m.items[S.idx]; if (!item || S.decisions[S.idx]) return;
    const [id, arg] = item.split(':'), C = this.company, G = this.group, label = m.labels[item] || item;
    const ops = S.opinions[S.idx], pour = ops.filter((o) => o.v > 0).length, contre = ops.filter((o) => o.v < 0).length;
    let effect = '';
    if (dec === 'oui') {
      const it = this.catalog(m.type, m.opt).find((q) => q.id === item), cost = it && it.cost ? it.cost() : 0;
      const acc = it && it.acc ? it.acc : 'book', bal = acc === 'book' ? C.cash : G.subs[acc] ? G.subs[acc].cash : 0;
      if (cost && id !== 'salaires' && bal < cost) return this.ui.toast(`Fonds insuffisants sur ${acc === 'book' ? 'NOVA BOOK' : G.subs[acc].name} (${fcfa(bal)} pour ${fcfa(cost)}).`, 3);
      const scope = m.type === 'equipe' && m.opt.dept ? m.opt.dept : null, staff = C.staff.filter((e) => !scope || e.dept === scope);
      if (id === 'bilan') effect = 'Bilan présenté.';
      else if (id === 'salaires') { for (const e of staff) { e.salary = Math.round(e.salary * 1.05 / 5) * 5; e.morale = Math.min(100, e.morale + 6); } effect = `Salaires +5 % pour ${staff.length} employé(s) (+${fcfa(cost)} par mois), moral +6.`; }
      else if (id === 'prime') { C.post(`Prime exceptionnelle décidée en réunion (${staff.length} employés)`, -cost, 'salaires'); for (const e of staff) e.morale = Math.min(100, e.morale + 5); effect = `Prime versée : ${fcfa(cost)} débités de NOVA BOOK, moral +5.`; }
      else if (id === 'formation') { const e = staff.filter((q) => q.status === 'présent').sort((a, b) => a.skill - b.skill)[0]; if (e) { C.train(e.id); effect = `${e.name} part en formation (150 000 FCFA, compétence +10 demain).`; } else effect = 'Aucun employé disponible pour une formation aujourd’hui.'; }
      else if (id === 'recrut') { C.post('Annonce de recrutement (décision de réunion)', -50000, 'frais'); C.refreshCandidates(); effect = 'Annonce publiée : 6 nouveaux candidats dans NOVA Gestion.'; }
      else if (id === 'equip') { C.upgrade(arg); effect = `Équipement ${arg} au niveau ${C.equip[arg]} (${fcfa(cost)}).`; }
      else if (id === 'projet') { const n = this.projects.list.length; this.projects.create(arg); effect = this.projects.list.length > n ? `Projet lancé : « ${this.projects.list[0].name} » (budget ${fcfa(cost)}). Équipe à affecter dans NOVA Gestion › Projets.` : 'Projet non lancé (trésorerie insuffisante).'; }
      else if (id === 'offre') { const o = C.offers.find((q) => q.oid === arg); const n = C.orders.length; if (o) C.accept(arg); effect = C.orders.length > n ? `Contrat signé avec ${o.client} : ${fcfa(o.price)}.` : 'Contrat non signé (proposition expirée ou département complet).'; }
      else if (id === 'consigne') { const [sid, k2] = arg.split('|'); G.setInstruction(sid, k2); effect = `${G.subs[sid] ? G.subs[sid].name : ''} : consigne « ${INSTR[k2].label} » appliquée.`; }
      else if (id === 'equipsub') { const s = G.subs[arg], lv = s.equip; G.upgrade(arg); effect = s.equip > lv ? `${s.name} : équipements niveau ${s.equip} (${fcfa(cost)}).` : 'Investissement non réalisé.'; }
      else if (id === 'commande' || id === 'partenariat' || id === 'remise') {
        const cli = ops.find((o) => o.cli), agree = !cli || cli.v > 0 || id === 'remise';
        if (!agree) effect = `Le client n’a pas donné son accord (${cli.v === 0 ? 'il réfléchit' : 'il refuse'}).`;
        else if (id === 'commande') { const nm = cli ? cli.name : CLIENTS[0]; C.offers.length = Math.min(C.offers.length, 4); C.refreshOffers(); const o = C.offers[C.offers.length - 1]; o.client = CLIENTS.find((q) => q.startsWith(nm)) || o.client; o.price = Math.round(o.price * 1.1 / 5) * 5; effect = `Nouvelle demande : ${o.label} pour ${o.client} (${fcfa(o.price)}) dans NOVA Gestion › Commandes.`; }
        else if (id === 'partenariat') { this.ceoLife.addMod('price', '*', 1.05, 10, 'Partenariat signé en réunion'); this.ceoLife.repAdd(2); effect = 'Partenariat signé : prix des offres +5 % pendant 10 jours, réputation +2.'; }
        else { this.ceoLife.addMod('price', '*', 0.95, 10, 'Remise de fidélité'); this.ceoLife.repAdd(3); effect = 'Remise de 5 % pendant 10 jours, réputation +3.'; }
      }
      else if (id === 'reseau' || id === 'conseil') { for (const k of S.present) { const c = this.phonePlus.contact(k); if (c && c.friend) c.friend.rapport = Math.min(100, c.friend.rapport + (id === 'reseau' ? 10 : 5)); } effect = id === 'reseau' ? 'Sympathie +10 avec les participants.' : 'Conseil reçu et noté, sympathie +5.'; }
    } else effect = dec === 'non' ? 'Proposition rejetée.' : 'Point reporté à une prochaine réunion.';
    // l'avis des participants compte : décider contre la majorité déçoit, la suivre motive
    const maj = pour > contre ? 'oui' : contre > pour ? 'non' : null;
    if (maj && dec !== 'report') for (const o of ops) { const c = this.phonePlus.contact(o.k); if (c && c.emp && o.v !== 0) c.emp.morale = Math.max(5, Math.min(100, c.emp.morale + ((o.v > 0) === (dec === 'oui') ? 1 : -1))); }
    S.decisions[S.idx] = { item, label, dec, effect, pour, contre, neutre: ops.length - pour - contre };
    this.onSave && this.onSave(); this.render();
  }
  finish() {
    const S = this.S, m = S.m, C = this.company;
    for (const k of S.present) { const c = this.phonePlus.contact(k); if (c && c.emp) c.emp.morale = Math.min(100, Math.max(5, c.emp.morale + (S.late ? -1 : m.prepared ? 2 : 1))); }
    const guests = S.present.filter((k) => /^c:/.test(k));
    if (guests.length && this.ceoLife) this.ceoLife.repAdd(S.late ? -1 : m.prepared ? 2 : 1);
    const nm = (k) => { const c = this.phonePlus.contact(k); return c ? `${c.name} (${c.role.replace(/ \(fictif\)| \(fictive\)/g, '')})` : k; };
    const L = [`COMPTE RENDU — ${m.title}`, `Date : J${m.day} à ${hh(m.hour)} (début effectif : ${m.started})${S.late ? ' — le PDG est arrivé en retard' : ''}`, `Lieu : ${this.roomInfo(m.room).label}`, `Présidée par : le PDG de NOVA BOOK`,
      `Présents : ${S.present.map(nm).join(' ; ')}`, `Excusés : ${m.parts.filter((k) => m.rsvp[k] === 'non').map((k) => `${nm(k)} — ${m.why[k] || 'excusé'}`).join(' ; ') || 'aucun'}`, `Sans réponse : ${m.parts.filter((k) => m.rsvp[k] === 'attente').map(nm).join(' ; ') || 'aucun'}`,
      `Présentation : ${m.prepared ? 'préparée (chiffres, projets, propositions)' : 'improvisée'}`, ...(m.seats.length ? [`Plan de table : ${m.seats.map((k, i) => (k ? `${i + 1}. ${nm(k).split(' (')[0]}` : null)).filter(Boolean).join(', ')}`] : []), 'ORDRE DU JOUR ET DÉCISIONS :'];
    S.decisions.forEach((d, i) => { if (d) L.push(`${i + 1}. ${d.label} — avis : ${d.pour} pour, ${d.contre} contre, ${d.neutre} réservé(s) — décision : ${d.item === 'bilan' ? 'PRIS ACTE' : d.dec === 'oui' ? 'APPROUVÉ' : d.dec === 'non' ? 'REJETÉ' : 'REPORTÉ'}. ${d.effect}`); });
    L.push(`Situation après la réunion : trésorerie NOVA BOOK ${fcfa(C.cash)}.`, 'Document fictif généré par le jeu.');
    if (this.events) { this.events.repAdd('pro', S.late ? -1 : m.prepared ? 2 : 1); this.events.repAdd('fiabilite', S.late ? -2 : 1); }
    m.minutes = L; m.status = 'terminée'; m.ended = this.economy.stamp(); m.sent = false;
    this.S = null; this.view = 'minutes'; this.sel = m.id; this.ui.toast('📝 Réunion terminée : compte rendu disponible dans l’agenda.', 3); this.onSave && this.onSave(); this.render();
  }
  sendMinutes(m) { if (!m.minutes || m.sent) return; m.sent = true; for (const k of m.parts) this.phonePlus.push(k, 'me', `📝 Compte rendu — ${m.title} (J${m.day}) : ${m.minutes.filter((l) => /^\d+\./.test(l)).map((l) => l.replace(/ — avis.*décision : /, ' → ')).join(' | ') || 'aucune décision'}`); this.ui.toast('Compte rendu envoyé aux participants.', 2); this.onSave && this.onSave(); }
  // ------------------------------------------------------------------ interface
  show(view = 'list') { this.open = true; this.view = view; this.dom.classList.add('show'); this.render(); }
  close() { if (this.S) { this.ui.toast('La réunion est en cours : termine-la avec « Clore la réunion ».', 2.5); return; } this.open = false; this.dom.classList.remove('show'); this.onSave && this.onSave(); }
  rsvpTag(v) { return v === 'oui' ? '<em class="pos">✅ confirmé</em>' : v === 'non' ? '<em class="neg">❌ excusé</em>' : '<em>⏳ en attente</em>'; }
  render() {
    if (!this.open) return;
    const head = (t, back) => `<div class="tk-head"><h2>${t}</h2>${back ? `<button data-mt="${back}">← Retour</button>` : ''}${this.S ? '' : '<button data-mt="x">✕</button>'}</div>`;
    let h = '';
    if (this.view === 'list') {
      const up = this.list.filter((m) => m.status === 'prévue' || m.status === 'en cours').sort((a, b) => a.day - b.day || a.hour - b.hour), past = this.list.filter((m) => !['prévue', 'en cours'].includes(m.status)).slice(0, 12);
      h = head('📅 Agenda des réunions') + `<div class="mt-body"><button class="sc-save" data-mt="new">+ Planifier une réunion</button><h5>À venir</h5>${up.map((m) => `<div class="ve-row" data-mt="open:${m.id}"><span><b>${TYPES[m.type].icon} ${esc(m.title)}</b><small>${this.when(m)} • ${esc(this.roomInfo(m.room).short)} • ${Object.values(m.rsvp).filter((v) => v === 'oui').length}/${m.parts.length} confirmé(s)${m.prepared ? ' • présentation prête' : ''}</small></span>${this.window(m) ? '<em class="pos">C’est l’heure !</em>' : ''}</div>`).join('') || '<p class="ve-note">Aucune réunion prévue.</p>'}
        <h5>Archives et comptes rendus</h5>${past.map((m) => `<div class="ve-row${m.status === 'terminée' ? '' : ' dim'}" data-mt="open:${m.id}"><span><b>${esc(m.title)}</b><small>J${m.day} ${hh(m.hour)} • ${m.status}</small></span></div>`).join('') || '<p class="ve-note">Pas encore d’archives.</p>'}</div>`;
    } else if (this.view === 'new') {
      const F = this.form, G = this.group, cand = this.candidates(F.type, F.opt), cat = this.catalog(F.type, F.opt), chip = (k, l, on) => `<button data-mt="${k}" class="${on ? 'on' : ''}">${l}</button>`;
      const depts = [...new Set(this.company.staff.map((e) => e.dept))], subs = Object.values(G ? G.subs : {});
      h = head('📅 Planifier une réunion', 'list') + `<div class="mt-body">
        <h5>Type</h5><div class="mt-chips">${Object.entries(TYPES).filter(([k]) => (k !== 'filiale' && k !== 'filiales') || subs.length).map(([k, t]) => chip(`ft:${k}`, `${t.icon} ${t.label}`, F.type === k)).join('')}</div>
        ${F.type === 'equipe' ? `<div class="mt-chips">${depts.map((d) => chip(`fd:${d}`, d, F.opt.dept === d)).join('')}</div>` : ''}${F.type === 'filiale' ? `<div class="mt-chips">${subs.map((s) => chip(`fs:${s.id}`, s.name, F.opt.sub === s.id)).join('')}</div>` : ''}
        <h5>Date et heure</h5><div class="mt-chips">${[0, 1, 2, 3, 4, 5, 6].map((d) => chip(`fday:${d}`, d === 0 ? 'Aujourd’hui' : d === 1 ? 'Demain' : `J${this.day() + d}`, F.dayOff === d)).join('')}</div>
        <div class="mt-chips">${[8, 9, 10, 11, 12, 14, 15, 16, 17, 18].map((x) => chip(`fh:${x}`, hh(x), F.hour === x)).join('')}</div>
        <h5>Salle</h5><div class="mt-chips">${this.rooms(F.type, F.opt.sub).map((r) => chip(`fr:${r}`, `${this.roomInfo(r).short}${this.roomInfo(r).seats ? ` (${this.roomInfo(r).seats} places)` : ''}`, F.room === r)).join('')}</div>
        <h5>Participants (${F.parts.length}/${MAX_PARTS})</h5><div class="mt-chips">${cand.map((c) => chip(`fp:${c.key}`, `${F.parts.includes(c.key) ? '☑' : '☐'} ${esc(c.name)} <small>${esc(c.role.split(' • ')[0].replace(/ \(fictif\)| \(fictive\)/, ''))}</small>`, F.parts.includes(c.key))).join('') || '<p class="ve-note">Aucune personne disponible pour ce type de réunion (ex. rencontre des habitants pour un rendez-vous contact, crée une filiale pour une réunion de filiale).</p>'}</div>
        <h5>Ordre du jour (${F.items.length}/${MAX_ITEMS})</h5><div class="mt-chips mt-col">${cat.map((q) => chip(`fi:${q.id}`, `${F.items.includes(q.id) ? '☑' : '☐'} ${esc(q.label)}${q.cost ? ` <small>• ${fcfa(q.cost())}${q.costNote ? ` ${q.costNote}` : ''}</small>` : ''}`, F.items.includes(q.id))).join('')}</div>
        <button class="sc-save" data-mt="create">📨 Envoyer les invitations</button></div>`;
    } else if (this.view === 'detail' || this.view === 'minutes') {
      const m = this.get(this.sel); if (!m) { this.view = 'list'; return this.render(); }
      if (this.view === 'minutes' && m.minutes) h = head('📝 Compte rendu', 'list') + `<div class="mt-body mt-min">${m.minutes.map((l) => `<p>${esc(l)}</p>`).join('')}<button class="sc-save" data-mt="send:${m.id}" ${m.sent ? 'disabled' : ''}>${m.sent ? 'Compte rendu envoyé ✓' : '📨 Envoyer le compte rendu aux participants'}</button></div>`;
      else h = head(`${TYPES[m.type].icon} ${esc(m.title)}`, 'list') + `<div class="mt-body"><p class="ve-note">${this.when(m)} • ${esc(this.roomInfo(m.room).label)} • statut : ${m.status}</p>
        <h5>Invités</h5>${m.parts.map((k) => { const c = this.phonePlus.contact(k); return `<div class="ve-row"><span><b>${c ? esc(c.name) : k}</b><small>${c ? esc(c.role) : ''}${m.why[k] ? ` • « ${esc(m.why[k])} »` : ''}</small></span>${this.rsvpTag(m.rsvp[k])}</div>`; }).join('')}
        <h5>Ordre du jour</h5>${m.items.map((i, n) => `<p class="ve-note">${n + 1}. ${esc(m.labels[i] || i)}</p>`).join('')}
        ${m.status === 'prévue' ? `<h5>Plan de table</h5>${this.seatSVG(m)}${m.seats.length ? '<button data-mt="auto">Placement automatique</button>' : ''}
        <div class="mt-chips">${m.room !== 'visio' && this.chauffeur ? '<button data-mt="limo">🚘 Y aller avec mon chauffeur</button>' : ''}<button data-mt="prep" ${m.prepared ? 'disabled' : ''}>${m.prepared ? '📊 Présentation prête ✓' : '📊 Préparer la présentation (1 h)'}</button>${m.room === 'visio' && this.window(m) ? '<button class="on" data-mt="visio">🎥 Démarrer la visioconférence</button>' : ''}<button data-mt="cancel">Annuler la réunion</button></div>
        <p class="ve-note">${m.room === 'visio' ? 'La visioconférence se lance d’ici, à l’heure prévue (de 30 min avant à 2 h après).' : `Rends-toi dans la ${esc(this.roomInfo(m.room).short.toLowerCase())} à l’heure prévue (de 30 min avant à 2 h après) et utilise le point « réunion » de la salle.`} Une réunion manquée déçoit les invités.</p>` : ''}</div>`;
    } else if (this.view === 'session') h = this.renderSession(head);
    this.dom.innerHTML = `<div class="tk-box mt-box">${h}</div>`;
  }
  renderSession(head) {
    const S = this.S, m = S.m, C = this.company, nm = (k) => { const c = this.phonePlus.contact(k); return c ? c.name : k; };
    let b = '';
    if (S.phase === 'accueil') {
      b = `<p class="ve-note">${esc(this.roomInfo(m.room).label)} • ${S.late ? '⚠️ Tu arrives en retard : les participants t’attendaient.' : 'Tu es à l’heure.'}</p>
        ${m.seats.length ? this.seatSVG(m) : ''}<h5>Accueil des participants</h5>${S.present.map((k) => `<div class="ve-row"><span><b>${esc(nm(k))}</b><small>${S.lateGuests.includes(k) ? 'arrive avec quelques minutes de retard, s’excuse' : `${this.fem(k) ? 'présente' : 'présent'}, salue le PDG`}</small></span><em class="pos">présent</em></div>`).join('')}
        ${m.parts.filter((k) => m.rsvp[k] !== 'oui').map((k) => `<div class="ve-row dim"><span><b>${esc(nm(k))}</b><small>${m.rsvp[k] === 'non' ? `${this.fem(k) ? 'excusée' : 'excusé'} : ${esc(m.why[k] || '')}` : 'n’a pas répondu'}</small></span><em class="neg">absent</em></div>`).join('')}
        <button class="sc-save" data-mt="go:pres">Ouvrir la séance et présenter</button>`;
    } else if (S.phase === 'pres') {
      const pj = this.projects ? this.projects.list.filter((p) => p.state !== 'livré') : [];
      const slides = [
        ['📈 Résultats', `<div class="mt-kpis"><div><small>CA du mois</small><b>${fcfa(C.cur().ca)}</b></div><div><small>Trésorerie</small><b>${fcfa(C.cash)}</b></div><div><small>Commandes en cours</small><b>${C.orders.length}</b></div><div><small>Effectif</small><b>${C.staff.length}</b></div>${this.ceoLife ? `<div><small>Réputation</small><b>${Math.round(this.ceoLife.rep)}/100</b></div>` : ''}</div>`],
        ['🗂️ Projets et commandes', `${pj.slice(0, 4).map((p) => `<p class="ve-note">• ${esc(p.name)} — ${p.state}</p>`).join('') || '<p class="ve-note">Aucun projet en cours.</p>'}${C.orders.slice(0, 4).map((o) => `<p class="ve-note">• ${esc(o.label)} pour ${esc(o.client)} — ${Math.min(100, Math.round(100 * o.done / Math.max(1, o.work)))} %</p>`).join('')}`],
        ['🧭 Ordre du jour', m.items.map((i, n) => `<p class="ve-note">${n + 1}. ${esc(m.labels[i] || i)}</p>`).join('')],
      ];
      const [t, body] = slides[S.slide];
      b = `<div class="mt-slide"><small>Diapositive ${S.slide + 1}/3 ${m.prepared ? '• présentation préparée' : '• présentation improvisée'}</small><h3>${t}</h3>${body}</div>
        <p class="ve-note">${m.prepared ? 'Les participants suivent avec attention.' : 'Sans préparation, la présentation est moins convaincante (surtout pour un client).'}</p>
        <div class="mt-chips">${S.slide > 0 ? '<button data-mt="sl:-1">← Précédente</button>' : ''}${S.slide < 2 ? '<button data-mt="sl:1">Suivante →</button>' : '<button class="on" data-mt="go:item">Passer à l’ordre du jour</button>'}</div>`;
    } else if (S.phase === 'item') {
      const item = m.items[S.idx];
      if (!S.opinions[S.idx]) S.opinions[S.idx] = S.present.map((k) => { const o = this.opinion(k, item, m), c = this.phonePlus.contact(k); return { k, ...o, name: nm(k), cli: c && c.kind === 'cli' }; });
      const ops = S.opinions[S.idx], d = S.decisions[S.idx], it = this.catalog(m.type, m.opt).find((q) => q.id === item), cost = it && it.cost ? it.cost() : 0;
      b = `<h5>Point ${S.idx + 1}/${m.items.length} : ${esc(m.labels[item] || item)}</h5><div class="tk-log mt-log">${ops.map((o) => `<div class="tk-msg"><small>${esc(o.name)} ${o.v > 0 ? '👍' : o.v < 0 ? '👎' : '🤔'}</small><span>${esc(o.txt)}</span></div>`).join('')}</div>
        <p class="ve-note">Avis : ${ops.filter((o) => o.v > 0).length} pour • ${ops.filter((o) => o.v < 0).length} contre • ${ops.filter((o) => o.v === 0).length} réservé(s). Suivre ou non la majorité influence le moral.</p>
        ${d ? `<div class="ve-row"><span><b>Décision : ${d.dec === 'oui' ? 'approuvé' : d.dec === 'non' ? 'rejeté' : 'reporté'}</b><small>${esc(d.effect)}</small></span></div><button class="sc-save" data-mt="${S.idx + 1 < m.items.length ? 'next' : 'go:fin'}">${S.idx + 1 < m.items.length ? 'Point suivant →' : 'Conclure'}</button>`
        : `<div class="mt-chips"><button class="on" data-mt="dec:oui">✅ ${item === 'bilan' ? 'Prendre acte' : /^(commande|partenariat|remise|reseau|conseil)$/.test(item) ? 'Proposer' : 'Approuver'}${cost ? ` (${fcfa(cost)}${it.costNote ? ` ${it.costNote}` : ''})` : ''}</button>${item === 'bilan' ? '' : '<button data-mt="dec:non">❌ Rejeter</button><button data-mt="dec:report">⏸️ Reporter</button>'}</div>`}`;
    } else if (S.phase === 'fin') {
      b = `<h5>Clôture</h5>${S.decisions.map((d, i) => d ? `<div class="ve-row"><span><b>${i + 1}. ${esc(d.label)}</b><small>${d.dec === 'oui' ? '✅' : d.dec === 'non' ? '❌' : '⏸️'} ${esc(d.effect)}</small></span></div>` : '').join('')}<button class="sc-save" data-mt="finish">📝 Clore la réunion et rédiger le compte rendu</button>`;
    }
    return head(`${TYPES[m.type].icon} ${esc(m.title)} — en séance`) + `<div class="mt-body">${b}</div>`;
  }
  onClick(ev) {
    const b = ev.target.closest('[data-mt]'); if (!b) { if (ev.target === this.dom) this.close(); return; }
    ev.stopPropagation(); const raw = b.dataset.mt, i = raw.indexOf(':'), a = i < 0 ? raw : raw.slice(0, i), v = i < 0 ? '' : raw.slice(i + 1);
    const F = this.form, m = this.get(this.sel), S = this.S;
    if (a === 'x') return this.close();
    if (a === 'list') { this.view = 'list'; this.swap = null; }
    else if (a === 'new') this.newForm();
    else if (a === 'open') { this.sel = +v; const q = this.get(+v); this.view = q && q.minutes ? 'minutes' : 'detail'; this.swap = null; }
    else if (F && a === 'ft') { F.type = v; F.opt = v === 'equipe' ? { dept: this.company.staff[0] && this.company.staff[0].dept } : v === 'filiale' ? { sub: Object.keys(this.group.subs)[0] } : {}; this.fixForm(); }
    else if (F && a === 'fd') { F.opt.dept = v; this.fixForm(); }
    else if (F && a === 'fs') { F.opt.sub = v; this.fixForm(); }
    else if (F && a === 'fday') F.dayOff = +v;
    else if (F && a === 'fh') F.hour = +v;
    else if (F && a === 'fr') F.room = v;
    else if (F && a === 'fp') { if (F.parts.includes(v)) F.parts = F.parts.filter((k) => k !== v); else if (F.parts.length < MAX_PARTS) F.parts.push(v); else this.ui.toast(`${MAX_PARTS} participants au maximum.`, 2); }
    else if (F && a === 'fi') { if (F.items.includes(v)) F.items = F.items.filter((k) => k !== v); else if (F.items.length < MAX_ITEMS) F.items.push(v); else this.ui.toast(`${MAX_ITEMS} points au maximum.`, 2); }
    else if (F && a === 'create') return this.create();
    else if (m && a === 'seat') { const s = +v; if (this.swap === null) this.swap = s; else { const t = m.seats[s]; m.seats[s] = m.seats[this.swap]; m.seats[this.swap] = t; this.swap = null; this.onSave && this.onSave(); } }
    else if (m && a === 'auto') { this.autoSeat(m); this.swap = null; }
    else if (m && a === 'prep') this.prepare(m);
    else if (m && a === 'limo' && this.chauffeur) { const st = this.chauffeur.security && this.chauffeur.security.site(m.room.startsWith('f:') ? m.room.slice(2) : 'book'); if (st) { this.open = false; this.dom.classList.remove('show'); this.chauffeur.toDest({ id: `mtg:${m.id}`, label: `${m.title} (${st.name})`, x: st.door.x, z: st.door.z }); return; } }
    else if (m && a === 'cancel') { this.cancel(m); this.view = 'list'; }
    else if (m && a === 'visio') return this.begin(m);
    else if (a === 'send') { const q = this.get(+v); if (q) this.sendMinutes(q); }
    else if (S && a === 'go') { S.phase = v; if (v === 'item') { S.idx = 0; S.opinions = S.opinions || []; } }
    else if (S && a === 'sl') S.slide = Math.max(0, Math.min(2, S.slide + +v));
    else if (S && a === 'dec') return this.decide(v);
    else if (S && a === 'next') S.idx++;
    else if (S && a === 'finish') return this.finish();
    this.render();
  }
  handleKeys(input) { if (input.hit('Escape')) this.close(); }
  // ------------------------------------------------------------------ téléphone : application Agenda
  renderApp(b) {
    const up = this.list.filter((m) => m.status === 'prévue').sort((a, c) => a.day - c.day || a.hour - c.hour);
    b.innerHTML = `<h4>📅 Agenda</h4><div class="ph-list">${up.map((m) => `<div class="ph-row"><span><b>${TYPES[m.type].icon} ${esc(m.title)}</b><small>${this.when(m)} • ${esc(this.roomInfo(m.room).short)} • ${Object.values(m.rsvp).filter((x) => x === 'oui').length}/${m.parts.length} confirmé(s)</small></span></div>`).join('') || '<p class="ph-note">Aucune réunion prévue.</p>'}</div><button class="ph-go" data-mtp="open">Ouvrir l’agenda complet</button>`;
  }
  // ------------------------------------------------------------------ boucle
  update() {
    const t = performance.now();
    for (let i = this.queue.length - 1; i >= 0; i--) if (t >= this.queue[i].at) { const q = this.queue.splice(i, 1)[0]; this.respond(this.get(q.mid), q.key); }
    const d = this.day(), h = this.now();
    for (const m of this.list) {
      if (m.status !== 'prévue') continue;
      if (!m.reminded && m.day === d && h >= m.hour - 0.5 && h < m.hour) { m.reminded = true; this.economy.notify(`⏰ Réunion à ${hh(m.hour)} : ${m.title} — ${this.roomInfo(m.room).short}${m.room !== 'visio' && this.chauffeur ? ' • 🚘 votre chauffeur peut vous y conduire (Agenda)' : ''}`); }
      if (d > m.day || (d === m.day && h > m.hour + 2)) { // réunion manquée
        m.status = 'manquée'; if (this.events) this.events.repAdd('fiabilite', -5);
        for (const k of m.parts) { if (m.rsvp[k] !== 'oui') continue; const c = this.phonePlus.contact(k); if (c && c.emp) c.emp.morale = Math.max(5, c.emp.morale - 3); if (c && c.friend) c.friend.rapport = Math.max(0, c.friend.rapport - 10); this.phonePlus.receive(k, 'Nous vous avons attendu pour la réunion… Elle n’a pas eu lieu.'); }
        if (m.parts.some((k) => /^c:/.test(k) && m.rsvp[k] === 'oui') && this.ceoLife) this.ceoLife.repAdd(-3);
        this.economy.notify(`⚠️ Réunion manquée : ${m.title}`); this.onSave && this.onSave();
      }
    }
  }
  serialize() { return { list: this.list.slice(0, 40), uid: this.uid }; }
  restore(s) {
    if (!s) return; this.list = s.list || []; this.uid = s.uid || 1;
    for (const m of this.list) { if (m.status === 'en cours') m.status = 'prévue'; for (const k of m.parts) if (m.rsvp[k] === 'attente' && m.status === 'prévue') this.queue.push({ mid: m.id, key: k, at: performance.now() + 3000 }); }
  }
}
