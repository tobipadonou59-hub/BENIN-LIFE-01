// Mission 013, étape 1 — économie en FCFA : portefeuille, historique, sac de courses, notifications,
// téléphone virtuel (portefeuille, historique, courses à domicile, contenu du frigo).
import { FOOD, FOOD_BY_ID, GASTRO_CATS, fcfa } from './food-data.js';
import { ARTICLE_BY_ID } from './market-data.js';
import { B, abbr, fcfaBig } from './money.js';

// Mission 025 — NOVA PRIVATE BANK : dotations uniques (monnaie fictive du jeu)
export const VIP_FORTUNE = 10n ** 17n; // 100 000 billions FCFA sur le compte personnel
export const VIP_CARD = 10n ** 13n;    // 10 000 milliards FCFA sur la carte VIP
export const PAY_METHODS = { carte: ['💳', 'Carte VIP'], compte: ['🏦', 'Compte personnel'], especes: ['💵', 'Espèces'] };

const START = 25000, DAILY = 5000, DELIVERY_FEE = 500;

export class Economy {
  constructor(ctx) {
    Object.assign(this, ctx); // ui, env, audio, onSave ; kitchen est branché ensuite
    this.wal = { compte: BigInt(START), carte: 0n, especes: 0n }; // soldes personnels exacts (BigInt)
    this.method = 'carte'; this.vip = null; this.xfers = []; // moyen de paiement choisi, carte VIP, transferts internes
    this.history = [{ t: this.stamp(), label: 'Solde de départ', amount: START, place: 'BENIN LIFE' }];
    this.bag = {};            // achats transportés (à ranger au frigo)
    this.items = {};          // articles non alimentaires achetés (marché)
    this.orders = [];         // livraisons en cours { items, eta }
    this.lastDay = null; this.day = 1;
    this.phoneOpen = false; this.app = 'home'; this.cart = {};
    this.buildDom();
    this.renderHud();
  }
  stamp() { return `J${this.day || 1} ${this.env ? this.env.clock : ''}`; }

  // ---- argent ----
  // solde du moyen de paiement choisi (nombre ordinaire, pour les comparaisons des autres modules) ; les opérations sont en BigInt
  get balance() { return Number(this.wal[this.method]); }
  set balance(v) { this.wal[this.method] = B(v); }
  canPay(n, via) { return this.wal[via || this.method] >= B(n); }
  log(e) { this.history.unshift(e); this.history.length = Math.min(this.history.length, 300); }
  pay(amount, label, place, via) {
    const src = PAY_METHODS[via] ? via : this.method, a = B(amount);
    if (a < 0n) return false;
    if (src === 'carte' && this.vip && this.vip.blocked) { this.notify(`🔒 Carte VIP bloquée : paiement refusé (${label}). Débloque-la ou change de moyen de paiement dans NOVA PRIVATE BANK.`); return false; }
    if (a > this.wal[src]) { this.notify(`❌ Solde insuffisant sur ${PAY_METHODS[src][1]} (${abbr(this.wal[src])}) pour ${label}`); return false; }
    this.wal[src] -= a;
    this.log({ t: this.stamp(), label, amount: -Number(a), big: (-a).toString(), place, via: src });
    this.notify(`${PAY_METHODS[src][0]} −${abbr(a)} • ${label}`);
    if (this.audio && this.audio.ctx) { this.audio.tone(1320, 0.08, 0.05, 'triangle'); this.audio.tone(1760, 0.12, 0.05, 'triangle', undefined, 0.08); }
    this.renderHud(); this.onSave && this.onSave();
    return true;
  }
  earn(amount, label, place, to = 'compte') { // revenus personnels : crédités sur le compte NOVA PRIVATE BANK
    const dst = PAY_METHODS[to] ? to : 'compte', a = B(amount); if (a <= 0n) return;
    this.wal[dst] += a;
    this.log({ t: this.stamp(), label, amount: Number(a), big: a.toString(), place, via: dst });
    this.notify(`💰 +${abbr(a)} • ${label}`);
    this.renderHud(); this.onSave && this.onSave();
  }
  // transfert interne entre poches personnelles (compte ↔ carte, dépôt/retrait d'espèces) : solde vérifié, montant exact
  move(from, to, amount, label) {
    const a = B(amount); if (!PAY_METHODS[from] || !PAY_METHODS[to] || from === to || a <= 0n || a > this.wal[from]) return false;
    this.wal[from] -= a; this.wal[to] += a;
    const rec = { id: `X${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`, from, to, big: a.toString(), t: this.stamp(), label };
    this.xfers.unshift(rec); this.xfers.length = Math.min(this.xfers.length, 200);
    this.log({ t: rec.t, label, amount: 0, big: a.toString(), place: 'NOVA PRIVATE BANK', via: `${from}>${to}`, xfer: rec.id });
    this.renderHud(); this.onSave && this.onSave(); return rec;
  }
  // dotation UNIQUE (nouvelle partie ou ancienne sauvegarde) : jamais renouvelée après un chargement (indicateur sauvegardé)
  grantVip() {
    if (this.vip) return;
    const digits = Array.from({ length: 15 }, () => Math.floor(Math.random() * 10)).join('');
    this.vip = { holder: 'LE PDG', number: `9${digits}`, exp: `${String(1 + Math.floor(Math.random() * 12)).padStart(2, '0')}/${35 + Math.floor(Math.random() * 4)}`, since: this.stamp() };
    this.wal.compte += VIP_FORTUNE; this.wal.carte += VIP_CARD; this.method = 'carte';
    this.log({ t: this.stamp(), label: 'Ouverture NOVA PRIVATE BANK — dotation du compte personnel : 100 000 billions FCFA (monnaie fictive)', amount: Number(VIP_FORTUNE), big: VIP_FORTUNE.toString(), place: 'NOVA PRIVATE BANK', via: 'compte', grant: true });
    this.log({ t: this.stamp(), label: 'Carte VIP NOVA — dotation initiale : 10 000 milliards FCFA (monnaie fictive)', amount: Number(VIP_CARD), big: VIP_CARD.toString(), place: 'NOVA PRIVATE BANK', via: 'carte', grant: true });
    this.notify('🏦 NOVA PRIVATE BANK : compte personnel de 100 000 billions FCFA et carte VIP de 10 000 milliards FCFA (monnaie fictive du jeu)');
    this.renderHud(); this.onSave && this.onSave();
  }
  addToBag(id, n = 1) { this.bag[id] = (this.bag[id] || 0) + n; }
  addItem(id, n = 1) { this.items[id] = (this.items[id] || 0) + n; }
  notify(msg) {
    const box = this.dom.notes, el = document.createElement('div');
    el.className = 'nt'; el.textContent = msg; box.prepend(el);
    while (box.children.length > 4) box.lastChild.remove();
    setTimeout(() => el.classList.add('out'), 3800); setTimeout(() => el.remove(), 4400);
  }

  // ---- temps qui passe : allocation quotidienne et livraisons ----
  update(dt) {
    if (!this.vip) this.grantVip();
    const h = this.env.time;
    if (this.lastDay === null) this.lastDay = h;
    const a = this.lastDay, wrapped = h < a;
    const passed7 = wrapped ? (a < 7 || h >= 7) : (a < 7 && h >= 7); // 7 h franchi (y compris en dormant)
    const dh = wrapped ? h + 24 - a : h - a;                          // heures de jeu écoulées (sommeil compris)
    if (passed7) { this.day++; this.earn(DAILY, 'Allocation quotidienne (7 h)', 'BENIN LIFE'); }
    this.lastDay = h;
    for (let i = this.orders.length - 1; i >= 0; i--) {
      const o = this.orders[i]; o.left -= dh;
      if (o.left <= 0) {
        this.orders.splice(i, 1);
        let inFridge = 0, inBag = 0;
        for (const [id, n] of Object.entries(o.items)) for (let k = 0; k < n; k++) {
          if (this.kitchen && this.kitchen.count() < 80) { this.kitchen.add(id); inFridge++; } else { this.addToBag(id); inBag++; }
        }
        this.notify(`🛵 Livraison arrivée : ${inFridge} article${inFridge > 1 ? 's' : ''} au réfrigérateur${inBag ? `, ${inBag} dans ton sac (frigo plein)` : ''}`);
        if (this.audio && this.audio.ctx) this.audio.horn(0, 0, 'moto', true);
        this.onSave && this.onSave();
        if (this.phoneOpen) this.renderPhone();
      }
    }
  }

  // ---- HUD et téléphone ----
  buildDom() {
    const $ = (s) => document.querySelector(s);
    this.dom = { wallet: $('#wallet'), notes: $('#notes'), phone: $('#phone') };
    const p = this.dom.phone;
    p.innerHTML = `<div class="ph"><div class="ph-top"><span class="ph-time"></span><b>BENIN LIFE</b><span>📶 🔋</span></div><div class="ph-body"></div>
      <div class="ph-nav"><button data-ph="home">⌂</button><button data-ph="close">✕</button></div></div>`;
    p.addEventListener('click', (e) => {
      const b = e.target.closest('[data-fx],[data-nb],[data-pp],[data-ph],[data-buy],[data-cart],[data-order],[data-ride],[data-scat],[data-mksec],[data-mkgo],[data-mtp],[data-evp],[data-sec],[data-drv],[data-vl],[data-ck],[data-st],[data-so],[data-fm],[data-sc],[data-ntv],[data-amb],[data-dec],[data-tr]'); if (!b) return; e.stopPropagation();
      if (b.dataset.pp && this.phonePlus) return this.phonePlus.onClick(b);
      if (b.dataset.fx && this.fortune) return this.fortune.onClick(b);
      if (b.dataset.nb && this.bank) return this.bank.onClick(b);
      if (b.dataset.tr && this.terminal) return this.terminal.onPhone(b.dataset.tr);
      if (b.dataset.dec && this.deco) return this.deco.onPhone(b.dataset.dec);
      if (b.dataset.amb && this.ambiance) return this.ambiance.onPhone(b.dataset.amb);
      if (b.dataset.ntv && this.tv) return this.tv.onPhone(b.dataset.ntv);
      if (b.dataset.sc && this.schools) return this.schools.onPhone(b.dataset.sc);
      if (b.dataset.fm && this.family) return this.family.onPhone(b.dataset.fm);
      if (b.dataset.so && this.solidarity) return this.solidarity.onPhone(b.dataset.so);
      if (b.dataset.st && this.staff) return this.staff.onPhone(b.dataset.st);
      if (b.dataset.ck && this.cook) return this.cook.onPhone(b.dataset.ck);
      if (b.dataset.vl && this.villa) return this.villa.onPhone(b.dataset.vl);
      if (b.dataset.drv && this.chauffeur) return this.chauffeur.onPhone(b.dataset.drv);
      if (b.dataset.sec && this.security) return this.security.onPhone(b.dataset.sec);
      if (b.dataset.evp && this.events) { this.togglePhone(false); return this.events.show('inv'); }
      if (b.dataset.mtp && this.meetings) { this.togglePhone(false); return this.meetings.show('list'); }
      if (b.dataset.mksec && this.market) { this.market.appSec = b.dataset.mksec; this.renderPhone(); return; }
      if (b.dataset.mkgo && this.market) { this.market.guide(b.dataset.mkgo); this.togglePhone(false); return; }
      if (b.dataset.scat) { this.shopCat = b.dataset.scat; this.renderPhone(); const l = this.dom.phone.querySelector('.ph-list'); if (l) l.scrollTop = 0; return; }
      if (b.dataset.ride && this.transport) return this.transport.onPhone(b.dataset.ride);
      if (b.dataset.ph === 'close') return this.togglePhone(false);
      if (b.dataset.ph) { this.app = b.dataset.ph; this.renderPhone(); return; }
      if (b.dataset.cart) { const [id, d] = b.dataset.cart.split(':'); this.cart[id] = Math.max(0, (this.cart[id] || 0) + (+d)); if (!this.cart[id]) delete this.cart[id]; this.renderPhone(); return; }
      if (b.dataset.order !== undefined) this.placeOrder();
    });
  }
  renderHud() { if (this.dom.wallet) this.dom.wallet.textContent = `${PAY_METHODS[this.method][0]} ${abbr(this.wal[this.method])}`; }
  togglePhone(on = !this.phoneOpen) {
    if (!on && this.phonePlus && this.phonePlus.call) this.phonePlus.hangup(); // fermer le téléphone raccroche
    this.phoneOpen = on; this.dom.phone.classList.toggle('show', on);
    if (on) { this.app = 'home'; this.renderPhone(); if (this.audio && this.audio.ctx) this.audio.tone(990, 0.06, 0.04, 'sine'); }
  }
  cartTotal() { return Object.entries(this.cart).reduce((a, [id, n]) => a + FOOD_BY_ID[id].price * n, 0); }
  placeOrder() {
    const items = { ...this.cart }, n = Object.values(items).reduce((a, b) => a + b, 0);
    if (!n) return;
    const total = this.cartTotal() + DELIVERY_FEE;
    if (!this.pay(total, `Courses à domicile (${n} article${n > 1 ? 's' : ''})`, 'Livraison')) return;
    this.orders.push({ items, left: 0.5 }); // 30 minutes de jeu
    this.cart = {}; this.app = 'orders'; this.renderPhone();
  }
  renderPhone() {
    const b = this.dom.phone.querySelector('.ph-body');
    this.dom.phone.querySelector('.ph-time').textContent = this.env.clock;
    const fridgeN = this.kitchen ? this.kitchen.count() : 0, bagN = Object.values(this.bag).reduce((a, c) => a + c, 0);
    if (this.app === 'home') {
      b.innerHTML = `<div class="ph-bal"><small>${PAY_METHODS[this.method][1]} (moyen de paiement)</small><b>${abbr(this.wal[this.method])}</b></div>
        <div class="ph-apps">
          ${this.bank ? '<button data-ph="npb"><i>🏛️</i>NOVA PRIVATE BANK</button>' : ''}${this.fortune ? '<button data-ph="bank"><i>🏦</i>Épargne & sociétés</button><button data-ph="achats"><i>🛍️</i>Achats & patrimoine</button>' : ''}${this.phonePlus ? this.phonePlus.homeButtons() : ''}<button data-ph="wallet"><i>💳</i>Portefeuille</button><button data-ph="shop"><i>🛵</i>Courses à domicile</button>
          <button data-ph="fridge"><i>🧊</i>Mon frigo (${fridgeN})</button><button data-ph="orders"><i>📦</i>Livraisons (${this.orders.length})</button>
          <button data-ph="bag"><i>🧺</i>Mon sac (${bagN})</button><button data-ph="ride"><i>🚦</i>Transports</button><button data-ph="catalog"><i>📖</i>Cuisine du Bénin</button><button data-ph="dantokpa"><i>🏪</i>Marché Dantokpa</button><button data-ph="items"><i>🛍️</i>Mes articles (${Object.values(this.items).reduce((a, c) => a + c, 0)})</button>
        </div><p class="ph-note">Allocation quotidienne de ${fcfa(DAILY)} versée chaque matin à 7 h.</p>`;
    } else if (this.app === 'wallet') {
      b.innerHTML = `<h4>💳 Portefeuille</h4><div class="ph-bal"><small>${PAY_METHODS[this.method][1]} (moyen de paiement)</small><b>${abbr(this.wal[this.method])}</b></div><p class="ph-note">${Object.entries(PAY_METHODS).map(([k, [ic, n]]) => `${ic} ${n} : ${abbr(this.wal[k])}`).join(' • ')}</p><h5>Historique</h5>
        <div class="ph-list">${this.history.map((h) => { const v = h.big !== undefined ? BigInt(h.big) : B(h.amount), tr = h.xfer; return `<div class="ph-row"><span><b>${h.label}</b><small>${h.place} • ${h.t}</small></span><em class="${tr ? '' : v < 0n ? 'neg' : 'pos'}">${tr ? '⇄ ' : v < 0n ? '' : '+'}${abbr(v)}</em></div>`; }).join('')}</div>`;
    } else if (this.app === 'shop') {
      const cat = this.shopCat || 'trad', tot = this.cartTotal(), n = Object.values(this.cart).reduce((a, c) => a + c, 0);
      b.innerHTML = `<h4>🛵 Courses à domicile</h4><p class="ph-note">Livré au réfrigérateur en 30 min de jeu • frais ${fcfa(DELIVERY_FEE)} • ${FOOD.length} produits</p>
        <div class="ph-chips">${Object.entries(GASTRO_CATS).map(([k, l]) => `<button data-scat="${k}" class="${k === cat ? 'on' : ''}">${l}</button>`).join('')}</div>
        <div class="ph-list">${FOOD.filter((f) => f.cat === cat).map((f) => `<div class="ph-row"><span><b>${f.name}</b><small>${fcfa(f.price)}</small></span>
          <span class="ph-qty"><button data-cart="${f.id}:-1">−</button><i>${this.cart[f.id] || 0}</i><button data-cart="${f.id}:1">+</button></span></div>`).join('')}</div>
        <button class="ph-go" data-order ${n ? '' : 'disabled'}>COMMANDER ${n ? `(${n})` : ''} • ${fcfa(n ? tot + DELIVERY_FEE : 0)}</button>`;
    } else if (this.app === 'catalog') {
      const cat = this.shopCat || 'trad', list = FOOD.filter((f) => f.cat === cat);
      b.innerHTML = `<h4>📖 Cuisine du Bénin</h4><p class="ph-note">${FOOD.length} aliments et plats du jeu • ${list.length} dans « ${GASTRO_CATS[cat]} ». Prix indicatifs en FCFA.</p>
        <div class="ph-chips">${Object.entries(GASTRO_CATS).map(([k, l]) => `<button data-scat="${k}" class="${k === cat ? 'on' : ''}">${l}</button>`).join('')}</div>
        <div class="ph-list">${list.map((f) => `<div class="ph-row ph-cat"><span><b>${f.name}</b><small>${f.desc}</small><small>${f.hunger ? `Faim +${f.hunger} • ` : ''}${f.hot ? 'se mange chaud • ' : ''}${fcfa(f.price)}</small></span></div>`).join('')}</div>`;
    } else if (this.app === 'orders') {
      b.innerHTML = `<h4>📦 Livraisons</h4>${this.orders.length ? this.orders.map((o) => `<div class="ph-row"><span><b>${Object.entries(o.items).map(([id, n]) => `${FOOD_BY_ID[id].name} ×${n}`).join(', ')}</b><small>Arrivée dans ${Math.max(1, Math.round(o.left * 60))} min de jeu</small></span></div>`).join('') : '<p class="ph-note">Aucune livraison en cours.</p>'}`;
    } else if (this.app === 'fridge') {
      const s = this.kitchen ? this.kitchen.stock : {};
      b.innerHTML = `<h4>🧊 Mon frigo (${fridgeN} / 80)</h4><div class="ph-list">${Object.entries(s).map(([id, n]) => `<div class="ph-row"><span><b>${FOOD_BY_ID[id].name}</b></span><em>×${n}</em></div>`).join('') || '<p class="ph-note">Vide.</p>'}</div>`;
    } else if (this.app === 'bag') {
      b.innerHTML = `<h4>🧺 Mon sac de courses</h4><p class="ph-note">Les achats faits en ville se rangent au réfrigérateur de ta maison.</p><div class="ph-list">${Object.entries(this.bag).map(([id, n]) => `<div class="ph-row"><span><b>${FOOD_BY_ID[id] ? FOOD_BY_ID[id].name : id}</b></span><em>×${n}</em></div>`).join('') || '<p class="ph-note">Vide.</p>'}</div>`;
    } else if (this.africa && this.app === 'afrique') { this.africa.renderApp(b);
    } else if (this.terminal && this.app === 'travel') { this.terminal.renderApp(b);
    } else if (this.deco && this.app === 'deco') { this.deco.renderApp(b);
    } else if (this.ambiance && this.app === 'lum') { this.ambiance.renderApp(b);
    } else if (this.tv && this.app === 'tv') { this.tv.renderApp(b);
    } else if (this.schools && this.app === 'ecole') { this.schools.renderApp(b);
    } else if (this.family && this.app === 'fam') { this.family.renderApp(b);
    } else if (this.solidarity && this.app === 'soli') { this.solidarity.renderApp(b);
    } else if (this.staff && this.app === 'dom') { this.staff.renderApp(b);
    } else if (this.cook && this.app === 'chef') { this.cook.renderApp(b);
    } else if (this.villa && this.app === 'villa') { this.villa.renderApp(b);
    } else if (this.chauffeur && this.app === 'drv') { this.chauffeur.renderApp(b);
    } else if (this.security && this.app === 'secu') { this.security.renderApp(b);
    } else if (this.events && this.app === 'events') { this.events.renderApp(b);
    } else if (this.meetings && this.app === 'agenda') { this.meetings.renderApp(b);
    } else if (this.bank && this.app === 'npb') { this.bank.renderApp(b);
    } else if (this.fortune && this.app === 'bank') { this.fortune.renderBank(b);
    } else if (this.fortune && this.app === 'achats') { this.fortune.renderShop(b);
    } else if (this.phonePlus && ['contacts', 'messages', 'chat', 'call', 'calls', 'transfers', 'transfer', 'leds', 'card'].includes(this.app)) {
      this.phonePlus.renderApp(this.app, b);
    } else if (this.app === 'dantokpa' && this.market) {
      this.market.renderApp(b);
    } else if (this.app === 'ride' && this.transport) {
      this.transport.renderApp(b);
    } else if (this.app === 'items') {
      b.innerHTML = `<h4>🛍️ Mes articles</h4><p class="ph-note">Objets achetés au marché Dantokpa et au supermarché.</p><div class="ph-list">${Object.entries(this.items).map(([id, n]) => { const a = ARTICLE_BY_ID[id]; return `<div class="ph-row"><span><b>${a ? a.icon + ' ' + a.name : id}</b><small>${a ? a.desc : ''}</small></span><em>×${n}</em></div>`; }).join('') || '<p class="ph-note">Aucun article pour l’instant. Va au marché Dantokpa !</p>'}</div>`;
    }
  }
  handleKeys(input) { if (input.hit('Escape') || input.hit('KeyN')) this.togglePhone(false); }

  serialize() { return { balance: Number(this.wal.compte), wal: { compte: this.wal.compte.toString(), carte: this.wal.carte.toString(), especes: this.wal.especes.toString() }, method: this.method, vip: this.vip, xfers: this.xfers.slice(0, 200), history: this.history.slice(0, 300), bag: { ...this.bag }, items: { ...this.items }, orders: this.orders, day: this.day }; }
  restore(s) {
    if (!s) return;
    if (s.wal) { for (const k of Object.keys(PAY_METHODS)) if (/^-?\d+$/.test(String(s.wal[k] ?? ''))) this.wal[k] = BigInt(s.wal[k]); } // soldes exacts
    else if (typeof s.balance === 'number') this.wal.compte = B(s.balance); // ancienne sauvegarde : l'ancien compte personnel est conservé
    if (PAY_METHODS[s.method]) this.method = s.method; if (s.vip && s.vip.number) this.vip = s.vip; if (Array.isArray(s.xfers)) this.xfers = s.xfers;
    if (Array.isArray(s.history)) this.history = s.history;
    if (s.bag) this.bag = s.bag; if (s.items) this.items = s.items; if (Array.isArray(s.orders)) this.orders = s.orders.filter((o) => o.items);
    this.day = s.day || 1; this.renderHud();
  }
}
