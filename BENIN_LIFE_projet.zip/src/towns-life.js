// Mission 015, phase 2 — vie dans les villes de la région (Porto-Novo, Ouidah, Pahou, Cocotomey) et trafic sur la RNIE 1.
// Un seul « pool » de personnages est réutilisé pour la ville la plus proche du joueur (jamais toutes les villes à la fois) ;
// les véhicules de la RNIE 1 n'existent qu'autour du joueur et sont recyclés devant / derrière lui, hors de sa vue.
import * as THREE from 'three';
import { createCharacter, SKINS } from './character.js';
import { createCarMesh, createMotoMesh } from './vehicles.js';
import { REGION, TOWNS, inLake, coastZ, nearestOnRoad } from './region-geo.js';
import { PROFILES } from './pedestrians.js';
import { hourFactor, DENSITY } from './population.js';

const PI = Math.PI;
const okLand = (x, z) => z < coastZ(x) - 6 && !inLake(x, z);

// ---------------- habitants des villes ----------------
export class TownLife {
  constructor({ scene, region, settings, touch }) {
    this.scene = scene; this.region = region; this.settings = settings;
    this.max = touch ? 14 : 24; this.town = null; this.walkers = []; this.idle = []; this.zems = [];
    this.R = Math.random;
  }
  ensurePool() {
    if (this.walkers.length) return;
    const R = this.R;
    for (let i = 0; i < this.max; i++) {
      const prof = PROFILES[[0, 0, 1, 2, 3, 4, 5, 6, 7][i % 9]], female = prof.female ?? R() < 0.5;
      const c = createCharacter({ female, carry: prof.id === 'commercante', skin: SKINS[i % SKINS.length], pagne: i % 6, pants: [0x2a2f3a, 0x5a4a3a, 0x1f3a5a][i % 3], ...(prof.look ? prof.look(R, female) : {}) });
      c.group.visible = false; this.scene.add(c.group);
      this.walkers.push({ c, prof, x: 0, z: 0, h: 0, state: 'walk', t: 0, active: false, speed: (1.0 + R() * 0.5) * (prof.speed || 1), acc: 0 });
    }
    for (let i = 0; i < 6; i++) { const c = createCharacter({ female: true, carry: i < 3, skin: SKINS[(i + 2) % SKINS.length], pagne: (i + 3) % 6 }); if (i >= 3) c.sit(false); c.group.visible = false; this.scene.add(c.group); this.idle.push({ c, seated: i >= 3 }); }
    for (let i = 0; i < 3; i++) { const m = createMotoMesh(7000 + i, { passenger: false }); m.group.visible = false; this.scene.add(m.group); this.zems.push(m.group); }
  }
  // repère local de la ville (u le long de la route, v en travers), nœuds du quadrillage entre les pâtés de maisons
  toWorld(t, u, v) { const c = Math.cos(t.ang), s = Math.sin(t.ang); return { x: t.x + u * s + v * c, z: t.z + u * c - v * s }; }
  nodeOK(t, i, j) { const u = -t.r + 17 + 34 * i, v = -t.r + 17 + 34 * j; if (Math.hypot(u, v) > t.r * 0.92) return false; const w = this.toWorld(t, u, v); return okLand(w.x, w.z); }
  assign(t) {
    this.town = t; this.ensurePool();
    const n = Math.floor((2 * t.r) / 34);
    this.nodes = []; for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) if (this.nodeOK(t, i, j)) this.nodes.push([i, j]);
    for (const w of this.walkers) this.placeWalker(w);
    // vendeuses et zémidjans au centre, au bord de la RNIE 1
    const np = nearestOnRoad(t.x, t.z), nx = Math.cos(np.h), nz = -Math.sin(np.h);
    this.idle.forEach((p, k) => { const side = k % 2 ? 1 : -1, along = (k - 3) * 2.2, x = np.x + nx * 9.5 * side + Math.sin(np.h) * along, z = np.z + nz * 9.5 * side + Math.cos(np.h) * along; p.c.group.position.set(x, p.seated ? -0.48 : 0, z); p.c.group.rotation.y = np.h + (side > 0 ? -PI / 2 : PI / 2); p.c.group.visible = true; p.x = x; p.z = z; });
    this.zems.forEach((m, k) => { const x = np.x + nx * 8.2 + Math.sin(np.h) * (12 + k * 1.3), z = np.z + nz * 8.2 + Math.cos(np.h) * (12 + k * 1.3); m.position.set(x, 0, z); m.rotation.set(0, np.h + PI / 2, 0.1); m.visible = true; });
  }
  release() { this.town = null; for (const w of this.walkers) { w.active = false; w.c.group.visible = false; } for (const p of this.idle) p.c.group.visible = false; for (const m of this.zems) m.visible = false; }
  placeWalker(w, P = this.P) {
    if (!this.nodes.length) return;
    let [i, j] = this.nodes[Math.floor(this.R() * this.nodes.length)];
    // de préférence assez près du joueur (mais pas sous ses yeux) : la rue semble animée sans tout simuler
    if (P) for (let k = 0; k < 14; k++) { const [a, b] = this.nodes[Math.floor(this.R() * this.nodes.length)], q = this.toWorld(this.town, -this.town.r + 17 + 34 * a, -this.town.r + 17 + 34 * b), d = Math.hypot(q.x - P.x, q.z - P.z); if (d > 25 && d < 110) { i = a; j = b; break; } }
    w.i = i; w.j = j; this.pickNext(w); const p = this.toWorld(this.town, -this.town.r + 17 + 34 * i, -this.town.r + 17 + 34 * j); w.x = p.x; w.z = p.z; w.state = 'walk'; w.k = this.R();
  }
  pickNext(w) {
    const dirs = [[1, 0], [-1, 0], [0, 1], [0, -1]].filter(([a, b]) => this.nodeOK(this.town, w.i + a, w.j + b));
    const d = dirs.length ? dirs[Math.floor(this.R() * dirs.length)] : [0, 0];
    w.ti = w.i + d[0]; w.tj = w.j + d[1]; w.k = 0;
  }
  nearestTown(P) { let best = null; for (const t of this.region.towns) { const d = Math.hypot(P.x - t.x, P.z - t.z) - t.r; if (!best || d < best.d) best = { d, t }; } return best; }
  update(dt, P, env) {
    this.P = P;
    const nb = this.nearestTown(P);
    if (nb && nb.d < 350) { if (this.town !== nb.t) this.assign(nb.t); }
    else if (this.town && (!nb || nb.d > 450)) this.release();
    if (!this.town) return;
    const t = this.town, k = (DENSITY[this.settings.density] || DENSITY.medium).k * hourFactor(env.time) * (t.name === 'Porto-Novo' ? 1 : t.name === 'Ouidah' ? 0.85 : 0.65);
    const target = Math.round(this.walkers.length * Math.min(1, k * 1.1));
    this.walkers.forEach((w, i) => { const on = i < target; if (on !== w.active) { w.active = on; if (on) this.placeWalker(w); w.c.group.visible = on; } });
    const night = env.time < 6 || env.time > 21.5;
    for (const p of this.idle) p.c.group.visible = !night;
    for (const w of this.walkers) {
      if (!w.active) continue;
      w.t += dt; let v = 0;
      if (w.state === 'walk') {
        const a = this.toWorld(t, -t.r + 17 + 34 * w.i, -t.r + 17 + 34 * w.j), b = this.toWorld(t, -t.r + 17 + 34 * w.ti, -t.r + 17 + 34 * w.tj);
        v = w.speed; w.k += (v * dt) / 34;
        if (w.k >= 1) { w.i = w.ti; w.j = w.tj; this.pickNext(w); if (this.R() < 0.12) { w.state = 'pause'; w.t = 0; w.dur = 2 + this.R() * 5; } }
        const kk = Math.min(1, w.k); w.x = a.x + (b.x - a.x) * kk; w.z = a.z + (b.z - a.z) * kk; if (b.x !== a.x || b.z !== a.z) w.h = Math.atan2(b.x - a.x, b.z - a.z);
      } else if (w.state === 'pause') { if (w.t > w.dur) w.state = 'walk'; }
      else if (w.state === 'talk') { if (w.face) w.h = Math.atan2(w.face.x - w.x, w.face.z - w.z); }
      let d2 = (P.x - w.x) ** 2 + (P.z - w.z) ** 2;
      if (d2 > 170 * 170 && w.state !== 'talk') { this.placeWalker(w, P); d2 = (P.x - w.x) ** 2 + (P.z - w.z) ** 2; }
      const far = d2 > 120 * 120;
      w.c.group.visible = !far; if (far) continue;
      w.c.group.position.set(w.x, 0, w.z); w.c.group.rotation.y = w.h;
      w.acc += dt; if (d2 < 40 * 40 || (w.f = (w.f || 0) + 1) % 3 === 0) { w.c.animate(w.acc, v); w.acc = 0; }
    }
  }
  blockers() { const out = []; if (this.town) for (const w of this.walkers) if (w.active) out.push({ x: w.x, z: w.z }); return out; }
  nearest(x, z) {
    let best = null; if (!this.town) return null;
    for (const w of this.walkers) { if (!w.active || !w.c.group.visible) continue; const d = Math.hypot(w.x - x, w.z - z); if (d < 1.9 && (!best || d < best.d)) best = { d, w }; }
    return best;
  }
}

// ---------------- trafic sur la RNIE 1 ----------------
function pathOf(pts) { const cum = [0]; for (let i = 1; i < pts.length; i++) cum.push(cum[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1])); return { pts, cum, len: cum[cum.length - 1] }; }
function at(P, s, out) {
  s = Math.max(0, Math.min(P.len, s)); let lo = 0, hi = P.cum.length - 1;
  while (hi - lo > 1) { const m = (lo + hi) >> 1; if (P.cum[m] <= s) lo = m; else hi = m; }
  const a = P.pts[lo], b = P.pts[hi], t = (s - P.cum[lo]) / ((P.cum[hi] - P.cum[lo]) || 1);
  out.x = a[0] + (b[0] - a[0]) * t; out.z = a[1] + (b[1] - a[1]) * t; out.h = Math.atan2(b[0] - a[0], b[1] - a[1]); return out;
}
const KINDS = [['sedan', 0xf2f2f2], ['citadine', 0x7a1010], ['sedan', 0xf2c200, 'taxi'], ['minibus', 0xf2c200, 'tokpa'], ['truck', 0xe8e2d6], ['van', 0xf2f2f2], ['pickup', 0x2e6b3a], ['moto'], ['moto'], ['moto'], ['sedan', 0x1f3e7c], ['bus', 0x0b6e4f]];
export class RoadTraffic {
  constructor({ scene, settings, touch }) {
    this.scene = scene; this.settings = settings; this.max = touch ? 9 : 16;
    this.paths = REGION.roads.map((r) => pathOf(r.pts));
    this.list = []; this._q = { x: 0, z: 0, h: 0 }; this.horns = [];
  }
  ensure() {
    if (this.list.length) return;
    for (let i = 0; i < this.max; i++) {
      const [kind, col, role] = KINDS[i % KINDS.length];
      const m = kind === 'moto' ? createMotoMesh(8000 + i) : createCarMesh(col, kind);
      m.group.visible = false; this.scene.add(m.group);
      this.list.push({ mesh: m.group, wheels: m.wheels, moto: kind === 'moto', role: role || kind, active: false, half: kind === 'bus' ? 5 : kind === 'truck' ? 3.5 : kind === 'moto' ? 1 : 2.5, max: kind === 'moto' ? 13 : kind === 'truck' || kind === 'bus' ? 11 : 15, speed: 0, spin: 0, x: 0, z: 0, h: 0 });
    }
  }
  // position du joueur projetée sur la route la plus proche
  focusOn(P) { const np = nearestOnRoad(P.x, P.z); return np; }
  spawn(v, np, ahead) {
    const P = this.paths[np.road]; v.road = np.road; v.dir = Math.random() < 0.5 ? 1 : -1;
    for (let k = 0; k < 8; k++) {
      const off = (ahead ? 1 : -1) * (180 + Math.random() * 220), s = np.s + off;
      if (s < 30 || s > P.len - 30) continue;
      if (this.list.some((o) => o.active && o.road === v.road && o.dir === v.dir && Math.abs(o.s - s) < 25)) continue;
      v.s = s; v.speed = v.max * 0.7; v.active = true; v.mesh.visible = true; return;
    }
  }
  update(dt, P, env, extraBlockers, playerCar) {
    const np = this.focusOn(P);
    const inRegion = np && np.d < 600 && !(Math.abs(P.x) < 200 && P.z > -200 && P.z < 210);
    if (!inRegion) { for (const v of this.list) if (v.active) { v.active = false; v.mesh.visible = false; } return; }
    this.ensure();
    const k = (DENSITY[this.settings.density] || DENSITY.medium).k * hourFactor(env.time), target = Math.max(2, Math.round(this.list.length * k));
    let act = 0;
    for (const v of this.list) {
      if (v.active) { const d = Math.abs(v.s - np.s); if (v.road !== np.road || d > 480) { v.active = false; v.mesh.visible = false; } else act++; }
    }
    for (const v of this.list) if (!v.active && act < target) { this.spawn(v, np, Math.random() < 0.5); if (v.active) act++; }
    const q = this._q;
    for (const v of this.list) {
      if (!v.active) continue;
      const Pth = this.paths[v.road];
      // vitesse : ralentit dans les villes, garde ses distances, s'arrête devant le joueur et les piétons
      let target = v.max;
      at(Pth, v.s, q);
      for (const t of TOWNS) if (Math.hypot(q.x - t.x, q.z - t.z) < t.r) { target = Math.min(target, v.moto ? 9 : 8); break; }
      for (const o of this.list) if (o !== v && o.active && o.road === v.road && o.dir === v.dir) { const gap = (o.s - v.s) * v.dir - o.half - v.half; if (gap > -1 && gap < 30) target = Math.min(target, Math.max(0, (gap - 4) * 0.8)); }
      const fx = Math.sin(q.h) * v.dir, fz = Math.cos(q.h) * v.dir;
      const obs = [...extraBlockers]; if (playerCar) obs.push({ x: playerCar.pos.x, z: playerCar.pos.z, r: 1.4 }); else obs.push({ x: P.x, z: P.z, r: 0.5 });
      let blocked = false;
      for (const b of obs) { const dx = b.x - v.x, dz = b.z - v.z, along = dx * fx + dz * fz, lat = Math.abs(dx * fz - dz * fx); if (along > 0 && along < 12 + v.half && lat < 2.2 + (b.r || 0.4)) { blocked = true; target = Math.min(target, Math.max(0, (along - v.half - 2.5) * 0.9)); } }
      v.speed = target < v.speed ? Math.max(target, v.speed - 8 * dt) : v.speed + Math.min(target - v.speed, 2.5 * dt);
      v.stuck = blocked && v.speed < 0.3 ? (v.stuck || 0) + dt : 0;
      if (v.stuck > 2.5 && Math.random() < dt * 0.4) this.horns.push({ x: v.x, z: v.z, kind: v.moto ? 'moto' : 'car' });
      v.s += v.speed * dt * v.dir;
      if (v.s < 5 || v.s > Pth.len - 5) { v.active = false; v.mesh.visible = false; continue; }
      at(Pth, v.s, q);
      const h = v.dir > 0 ? q.h : q.h + PI;
      v.x = q.x - Math.cos(h) * 3.0; v.z = q.z + Math.sin(h) * 3.0; // voie de droite (comme en ville)
      const dh = Math.atan2(Math.sin(h - v.h), Math.cos(h - v.h)); v.h += dh * Math.min(1, dt * 6);
      v.mesh.position.set(v.x, 0, v.z); v.mesh.rotation.set(0, v.h, v.moto ? Math.max(-0.3, Math.min(0.3, -dh * 3)) : 0, 'YXZ');
      v.spin += v.speed / 0.35 * dt;
      if (v.moto) for (const w of v.wheels) w.rotation.x = v.spin; else for (const w of v.wheels) w.spin.rotation.x = v.spin;
    }
  }
  obstacles() { const out = []; for (const v of this.list) if (v.active) out.push({ x: v.x, z: v.z, r: v.moto ? 0.6 : 1.3 }); return out; }
}
