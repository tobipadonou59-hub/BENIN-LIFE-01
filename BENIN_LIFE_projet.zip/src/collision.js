// Collisions 2D (plan XZ) avec grille spatiale : boîtes alignées + cercles.
// Suffisant et très rapide pour une ville composée de bâtiments rectangulaires.

export class CollisionWorld {
  constructor(cell = 16) {
    this.cell = cell;
    this.grid = new Map();
    this.objects = [];
    this.stamp = 0;
    this.level = 0; // étage courant : les obstacles avec o.lv ne comptent qu'à leur étage (bâtiments à étages)
  }

  _key(i, j) { return i * 73856093 ^ j * 19349663; }

  _insert(o, a, b, c, d) {
    const s = this.cell;
    for (let i = Math.floor(a / s); i <= Math.floor(c / s); i++)
      for (let j = Math.floor(b / s); j <= Math.floor(d / s); j++) {
        const k = this._key(i, j);
        let arr = this.grid.get(k);
        if (!arr) this.grid.set(k, (arr = []));
        arr.push(o);
      }
  }

  addBox(minX, minZ, maxX, maxZ, h = 10) {
    const o = { t: 0, minX, minZ, maxX, maxZ, h, s: 0 };
    this.objects.push(o);
    this._insert(o, minX, minZ, maxX, maxZ);
    return o;
  }

  addCircle(x, z, r, h = 10) {
    const o = { t: 1, x, z, r, h, s: 0 };
    this.objects.push(o);
    this._insert(o, x - r, z - r, x + r, z + r);
    return o;
  }

  query(x, z, r, out) {
    out.length = 0;
    const s = this.cell, st = ++this.stamp;
    for (let i = Math.floor((x - r) / s); i <= Math.floor((x + r) / s); i++)
      for (let j = Math.floor((z - r) / s); j <= Math.floor((z + r) / s); j++) {
        const arr = this.grid.get(this._key(i, j));
        if (!arr) continue;
        for (const o of arr) if (o.s !== st) { o.s = st; out.push(o); }
      }
    return out;
  }

  // Repousse un cercle (pos.x, pos.z, rayon r) hors des obstacles. Renvoie la normale du dernier contact ou null.
  resolve(pos, r, extra = null) {
    const list = this.query(pos.x, pos.z, r + 1, this._tmp || (this._tmp = []));
    let hit = null;
    for (let iter = 0; iter < 2; iter++) {
      for (const o of list) {
        if (o.disabled || (o.lv !== undefined ? o.lv !== this.level : this.level >= 100)) continue; // niveaux ≥ 100 : intérieurs isolés
        const n = o.t === 0 ? pushBox(pos, r, o) : pushCircle(pos, r, o.x, o.z, o.r);
        if (n) hit = n;
      }
      if (extra && this.level < 100) for (const c of extra) {
        const n = pushCircle(pos, r, c.x, c.z, c.r);
        if (n) hit = n;
      }
    }
    return hit;
  }

  pointBlocked(x, y, z) {
    const list = this.query(x, z, 0, this._tmp2 || (this._tmp2 = []));
    for (const o of list) {
      if (o.disabled || (o.lv !== undefined ? o.lv !== this.level : this.level >= 100) || y > o.h) continue;
      if (o.t === 0) { if (x > o.minX && x < o.maxX && z > o.minZ && z < o.maxZ) return true; }
      else { const dx = x - o.x, dz = z - o.z; if (dx * dx + dz * dz < o.r * o.r) return true; }
    }
    return false;
  }
}

function pushBox(pos, r, o) {
  const cx = Math.max(o.minX, Math.min(pos.x, o.maxX));
  const cz = Math.max(o.minZ, Math.min(pos.z, o.maxZ));
  let dx = pos.x - cx, dz = pos.z - cz;
  const d2 = dx * dx + dz * dz;
  if (d2 >= r * r) return null;
  if (d2 > 1e-9) {
    const d = Math.sqrt(d2), k = (r - d) / d;
    pos.x += dx * k; pos.z += dz * k;
    return { x: dx / d, z: dz / d };
  }
  // centre à l'intérieur de la boîte : sortie par l'axe le plus court
  const l = pos.x - o.minX, rr = o.maxX - pos.x, t = pos.z - o.minZ, b = o.maxZ - pos.z;
  const m = Math.min(l, rr, t, b);
  if (m === l) { pos.x = o.minX - r; return { x: -1, z: 0 }; }
  if (m === rr) { pos.x = o.maxX + r; return { x: 1, z: 0 }; }
  if (m === t) { pos.z = o.minZ - r; return { x: 0, z: -1 }; }
  pos.z = o.maxZ + r; return { x: 0, z: 1 };
}

function pushCircle(pos, r, x, z, cr) {
  const dx = pos.x - x, dz = pos.z - z, d2 = dx * dx + dz * dz, R = r + cr;
  if (d2 >= R * R) return null;
  const d = Math.sqrt(d2) || 1e-4;
  const k = (R - d) / d;
  pos.x += dx * k; pos.z += dz * k;
  return { x: dx / d, z: dz / d };
}
