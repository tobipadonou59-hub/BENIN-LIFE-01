// Gestion clavier / souris.
export class Input {
  constructor(dom) {
    this.keys = new Set();
    this.pressed = new Set();
    this.mouseDX = 0; this.mouseDY = 0; this.wheel = 0;
    this.dragging = false;
    this.locked = false;
    this.dom = dom;
    addEventListener('keydown', (e) => {
      const tg = e.target; if (tg && (tg.tagName === 'INPUT' || tg.tagName === 'TEXTAREA') && e.code !== 'Escape') return; // saisie de texte (téléphone)
      if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Tab'].includes(e.code)) e.preventDefault();
      if (!this.keys.has(e.code)) this.pressed.add(e.code);
      this.keys.add(e.code);
    });
    addEventListener('keyup', (e) => this.keys.delete(e.code));
    addEventListener('blur', () => this.keys.clear());
    dom.addEventListener('mousedown', (e) => { if (e.button === 0 || e.button === 2) this.dragging = true; });
    addEventListener('mouseup', () => (this.dragging = false));
    dom.addEventListener('contextmenu', (e) => e.preventDefault());
    addEventListener('mousemove', (e) => {
      if (this.locked || this.dragging) { this.mouseDX += e.movementX; this.mouseDY += e.movementY; }
    });
    dom.addEventListener('wheel', (e) => { this.wheel += Math.sign(e.deltaY); e.preventDefault(); }, { passive: false });
    document.addEventListener('pointerlockchange', () => { this.locked = document.pointerLockElement === dom; });
  }
  // touches virtuelles (commandes tactiles)
  setVirtual(code, on) {
    if (on) { if (!this.keys.has(code)) this.pressed.add(code); this.keys.add(code); } else this.keys.delete(code);
  }
  down(code) { return this.keys.has(code); }
  hit(code) { return this.pressed.has(code); }
  requestLock() {
    try { const p = this.dom.requestPointerLock(); if (p && p.catch) p.catch(() => {}); } catch (e) { /* iframe sans pointer-lock : on garde le glisser-souris */ }
  }
  releaseLock() { if (document.pointerLockElement) document.exitPointerLock(); }
  endFrame() { this.pressed.clear(); this.mouseDX = this.mouseDY = 0; this.wheel = 0; }
}
