// Mission 026, étape 1 — collection privée de Mercedes-Benz dans un GARAGE SOUTERRAIN de la VILLA NOVA (intérieur isolé,
// même principe que l'aile de la villa et les hôtels du jeu). Accès : plateforme d'ascenseur à voitures dans l'allée de la
// villa (à pied ou en voiture). Garage : 32 emplacements numérotés, sol brillant de showroom, éclairage LED, murs portant
// l'inscription « MERCEDES-BENZ • COLLECTION PRIVÉE » (typographie neutre : le logo officiel, marque déposée, n'est pas
// reproduit ; collection fictive, non affiliée à Mercedes-Benz), porte de garage automatique, zone de lavage et d'entretien,
// plateau de présentation tournant, tableau numérique de la collection. Chaque voiture est visible, accessible et
// sélectionnable ; « Prendre le volant » la fait remonter par l'ascenseur : c'est alors un véritable véhicule conduisible
// (GarageCar), compatible avec la circulation, les routes, les parkings, la carte et la sauvegarde.
// Optimisation : voitures exposées fusionnées par matériau (4 maillages par voiture), modèle détaillé (portes, phares)
// seulement pour la voiture la plus proche ; intérieur construit au premier passage et masqué en dehors.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { GarageCar, buildCarMesh } from './garage.js';
import { CAR_BY_ID } from './cars-data.js';
import { MB_CARS, MB_BY_ID, MB_COLORS } from './mercedes-data.js';
import { colorize, paintMat, glassMat, wheelMat } from './vehicles.js';
import { abbr } from './money.js';

const PI = Math.PI;
for (const c of MB_CARS) CAR_BY_ID[c.id] = c; // les Mercedes deviennent des véhicules conduisibles (même classe que le garage)
export const MBG = { O: { x: -44, z: 126 }, Y: 900, LV: 240 };
export const PAD = { x: -49, z: 115, h: PI / 2 }; // ascenseur à voitures (allée de la villa), sortie vers l'est (portail)
const HALL = { x0: -40, x1: 40, z0: -14, z1: 14, H: 7.5 };
const NB = 32, bayPos = (i) => ({ x: -30 + (i % 16) * 4, z: i < 16 ? -10.25 : 10.25, h: i < 16 ? 0 : PI });
const TURN = { x: -35.5, z: 0, r: 3.4 }, WASH = { x: 36, z: -8 }, LIFT = { x: 37.5, z: 10.5 }, BOARD = { x: -35.5, z: 9 };
const colorName = (hex) => (MB_COLORS.find((c) => c.hex === hex) || { name: 'Personnalisée' }).name;
const ENG = { ev: 'électrique', diesel: 'diesel', v8: 'V8', v12: 'V12', v6: 'V6 hybride', i6: '6 cylindres' };
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

function normGeo(geo, hex) { // attributs homogènes (position, normal, uv, color) pour la fusion
  let g = geo.index ? geo.toNonIndexed() : geo.clone();
  for (const k of Object.keys(g.attributes)) if (!['position', 'normal', 'uv', 'color'].includes(k)) g.deleteAttribute(k);
  if (!g.attributes.normal) g.computeVertexNormals();
  if (!g.attributes.color || hex !== undefined) g = colorize(g, hex !== undefined ? hex : 0xffffff);
  if (!g.attributes.uv) g.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(g.attributes.position.count * 2), 2));
  return g;
}
const MISC = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.5, metalness: 0.3 });

export class MercedesGarage {
  constructor(ctx) {
    Object.assign(this, ctx); // scene, world, player, ui, audio, env, cars, home, tpc, enterCar, exitCar, onSave
    this.recs = {}; MB_CARS.forEach((c, i) => { this.recs[c.id] = { bay: i, color: c.colors[0], out: null, damage: 0, km: 0 }; });
    this.present = null; this.live = new Map(); this.inside = false; this.built = false; this.statics = {}; this.lod = null; this.doorT = 0;
    this.buildOutside();
  }
  spec(id) { return MB_BY_ID[id]; }
  list() { return MB_CARS.map((c) => ({ c, r: this.recs[c.id] })); }
  status(id) { const r = this.recs[id]; return r.out ? 'dehors' : this.present === id ? 'en présentation' : 'au garage'; }
  // ------------------------------------------------------------------ extérieur : ascenseur à voitures dans l'allée
  buildOutside() {
    const g = new THREE.Group(), C = this.world.collision, P = PAD;
    const mat = (c, o = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.4, ...o });
    const add = (geo, m, x, y, z) => { const o = new THREE.Mesh(geo, m); o.position.set(x, y, z); o.receiveShadow = true; g.add(o); return o; };
    add(new THREE.BoxGeometry(6.2, 0.06, 3.0), mat(0x1c1e22, { metalness: 0.5, roughness: 0.25 }), P.x, 0.03, P.z);
    for (const [w, d, dx, dz] of [[6.4, 0.14, 0, -1.57], [6.4, 0.14, 0, 1.57], [0.14, 3.2, -3.17, 0], [0.14, 3.2, 3.17, 0]]) add(new THREE.BoxGeometry(w, 0.07, d), mat(0xf2c200, { emissive: 0x6a5000, emissiveIntensity: 0.4 }), P.x + dx, 0.05, P.z + dz);
    for (let k = -2; k <= 2; k++) add(new THREE.BoxGeometry(0.5, 0.065, 2.6), mat(0x2a2d33), P.x + k * 1.1, 0.045, P.z);
    for (const dx of [-3.3, 3.3]) { add(new THREE.BoxGeometry(0.16, 2.9, 0.16), mat(0x8a8f96, { metalness: 0.7 }), P.x + dx, 1.45, P.z + 1.75); C.addCircle(P.x + dx, P.z + 1.75, 0.12, 2.9); }
    add(new THREE.BoxGeometry(6.8, 0.5, 0.3), mat(0x0b0c0e), P.x, 3.05, P.z + 1.75);
    const sign = this.label('GARAGE PRIVÉ • MERCEDES-BENZ', 'ascenseur à voitures • collection privée (non affiliée)', 6.4, 0.46, '#0b0c0e', '#e8e8e8'); sign.position.set(P.x, 3.05, P.z + 1.58); sign.rotation.y = PI; g.add(sign);
    this.padLed = add(new THREE.BoxGeometry(6.2, 0.06, 0.06), new THREE.MeshBasicMaterial({ color: 0xe8f0ff }), P.x, 2.78, P.z + 1.62);
    this.scene.add(g); this.outGroup = g;
    if (this.ui && this.ui.pois && !this.ui.pois.some((q) => q.id === 'mb_garage')) this.ui.pois.push({ id: 'mb_garage', name: 'Garage privé — collection Mercedes-Benz (ascenseur)', cat: 'maison', x: P.x, z: P.z, status: 'fictif', access: true, address: 'VILLA NOVA', note: 'Garage souterrain de 32 places (collection fictive, non affiliée à Mercedes-Benz)' });
  }
  label(t, sub, w, h, bg, fg) { const c = document.createElement('canvas'); c.width = 1024; c.height = Math.max(64, Math.round(1024 * h / w)); const x = c.getContext('2d'); x.fillStyle = bg; x.fillRect(0, 0, c.width, c.height); x.fillStyle = fg; x.textAlign = 'center'; x.textBaseline = 'middle'; x.font = `700 ${Math.round(c.height * (sub ? 0.36 : 0.52))}px Arial`; x.fillText(t, c.width / 2, c.height * (sub ? 0.36 : 0.52), c.width - 30); if (sub) { x.font = `400 ${Math.round(c.height * 0.2)}px Arial`; x.fillStyle = '#b8bcc2'; x.fillText(sub, c.width / 2, c.height * 0.78, c.width - 30); } const tx = new THREE.CanvasTexture(c); tx.colorSpace = THREE.SRGBColorSpace; return new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ map: tx, side: THREE.DoubleSide, toneMapped: false })); }
  // ------------------------------------------------------------------ intérieur : garage souterrain (construit au premier passage)
  buildInside() {
    if (this.built) return; this.built = true;
    const { O, Y, LV } = MBG, g = new THREE.Group(), C = this.world.collision, H = HALL.H; g.position.set(O.x, Y, O.z); this.scene.add(g); this.inGroup = g; this.cols = [];
    const solid = (x0, z0, x1, z1, h = H) => { const o = C.addBox(O.x + Math.min(x0, x1), O.z + Math.min(z0, z1), O.x + Math.max(x0, x1), O.z + Math.max(z0, z1), Y + h); o.lv = LV; this.cols.push(o); return o; };
    const parts = [], box = (x0, y0, z0, x1, y1, z1, c) => parts.push(colorize(new THREE.BoxGeometry(Math.abs(x1 - x0) || 0.01, Math.abs(y1 - y0) || 0.01, Math.abs(z1 - z0) || 0.01).translate((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), c)), led = [];
    // sol brillant de showroom (matériau propre), marquages, murs, plafond
    const floor = new THREE.Mesh(new THREE.BoxGeometry(HALL.x1 - HALL.x0, 0.1, HALL.z1 - HALL.z0), new THREE.MeshStandardMaterial({ color: 0x5a5e66, roughness: 0.1, metalness: 0.35 })); floor.position.set(0, -0.05, 0); floor.receiveShadow = true; g.add(floor);
    for (let i = 0; i < NB; i++) { const p = bayPos(i), zr = p.z < 0 ? [-14, -6.6] : [6.6, 14]; box(p.x - 2, 0.002, zr[0], p.x - 1.92, 0.012, zr[1], 0xe8e8e8); if (i % 16 === 15) box(p.x + 1.92, 0.002, zr[0], p.x + 2, 0.012, zr[1], 0xe8e8e8); }
    box(-32, 0.002, -0.06, 32, 0.012, 0.06, 0x8a8f96);
    for (const [a, b, c2, d] of [[HALL.x0, HALL.z0 - 0.3, HALL.x1, HALL.z0], [HALL.x0, HALL.z1, HALL.x1, HALL.z1 + 0.3], [HALL.x0 - 0.3, HALL.z0, HALL.x0, HALL.z1], [HALL.x1, HALL.z0, HALL.x1 + 0.3, -3.4], [HALL.x1, 3.4, HALL.x1 + 0.3, HALL.z1]]) { box(a, 0, b, c2, H, d, 0xe9e9ec); solid(a, b, c2, d); }
    box(HALL.x0, 0, HALL.z0, HALL.x1, 0.9, HALL.z0 + 0.04, 0x2a2d33); box(HALL.x0, 0, HALL.z1 - 0.04, HALL.x1, 0.9, HALL.z1, 0x2a2d33); // plinthes sombres
    const ceil = new THREE.Mesh(new THREE.PlaneGeometry(HALL.x1 - HALL.x0 + 0.6, HALL.z1 - HALL.z0 + 0.6).rotateX(PI / 2), new THREE.MeshStandardMaterial({ color: 0x3a3d44, roughness: 0.9, emissive: 0x202228 })); ceil.position.set(0, H, 0); g.add(ceil); // visible seulement par en dessous
    // éclairage LED professionnel : une rampe au-dessus de chaque emplacement + lignes de l'allée
    for (let i = 0; i < NB; i++) { const p = bayPos(i); led.push(new THREE.BoxGeometry(0.22, 0.06, 5.6).translate(p.x, H - 0.05, p.z)); }
    for (const z of [-4, 0, 4]) led.push(new THREE.BoxGeometry(70, 0.05, 0.12).translate(0, H - 0.05, z));
    g.add(new THREE.Mesh(mergeGeometries(led), new THREE.MeshBasicMaterial({ color: 0xf2f6ff, toneMapped: false })));
    // inscriptions murales (typographie neutre, sans logo) et numéros d'emplacement
    for (const [x, z, ry] of [[-16, HALL.z0 + 0.06, 0], [16, HALL.z0 + 0.06, 0], [-16, HALL.z1 - 0.06, PI], [16, HALL.z1 - 0.06, PI]]) { const m = this.label('MERCEDES-BENZ', 'COLLECTION PRIVÉE • VILLA NOVA', 9, 1.3, '#e9e9ec', '#16181c'); m.position.set(x, 4.1, z); m.rotation.y = ry; g.add(m); }
    for (let i = 0; i < NB; i++) { const p = bayPos(i), m = this.label(String(i + 1).padStart(2, '0'), '', 0.8, 0.42, '#16181c', '#e8e8e8'); m.position.set(p.x, 3.0, p.z < 0 ? HALL.z0 + 0.06 : HALL.z1 - 0.06); m.rotation.y = p.z < 0 ? 0 : PI; g.add(m); }
    // porte de garage automatique (mur est) : panneau qui se relève quand une voiture sort ou rentre
    box(HALL.x1 - 0.1, 0, -3.6, HALL.x1 + 0.4, 0.3, 3.6, 0x8a8f96); box(HALL.x1 - 0.1, 4.2, -3.6, HALL.x1 + 0.4, H, 3.6, 0x2a2d33);
    this.door = new THREE.Mesh(new THREE.BoxGeometry(0.12, 4.2, 6.8), new THREE.MeshStandardMaterial({ color: 0x9aa0a8, metalness: 0.6, roughness: 0.35 })); this.door.position.set(HALL.x1 + 0.1, 2.1, 0); g.add(this.door); this.doorCol = solid(HALL.x1 - 0.1, -3.4, HALL.x1 + 0.3, 3.4);
    { const m = this.label('PORTE AUTOMATIQUE', 'ascenseur à voitures → allée de la villa', 4.8, 0.6, '#16181c', '#f2c200'); m.position.set(HALL.x1 - 0.08, 4.55, 0); m.rotation.y = -PI / 2; g.add(m); }
    // zone de lavage et d'entretien (portique, rouleaux, pont élévateur)
    box(32.2, 0.004, -13.8, 39.8, 0.014, -2.6, 0x1f4e9c); for (const z of [-12.6, -3.8]) for (const x of [32.6, 39.4]) { box(x - 0.15, 0, z - 0.15, x + 0.15, 3.6, z + 0.15, 0xc8ccd0); solid(x - 0.15, z - 0.15, x + 0.15, z + 0.15, 3.6); }
    box(32.4, 3.6, -12.8, 39.6, 3.9, -12.4, 0xc8ccd0); box(32.4, 3.6, -4, 39.6, 3.9, -3.6, 0xc8ccd0);
    for (const x of [33.4, 38.6]) parts.push(colorize(new THREE.CylinderGeometry(0.35, 0.35, 3.0, 12).translate(x, 1.9, -8.2), 0x2a6ad8));
    { const m = this.label('LAVAGE & ENTRETIEN', 'nettoyage, contrôle, réparation', 5, 0.7, '#1f4e9c', '#ffffff'); m.position.set(36, 4.6, HALL.z0 + 0.07); g.add(m); }
    // espace de présentation : plateau tournant éclairé, cordons
    this.turn = new THREE.Mesh(new THREE.CylinderGeometry(TURN.r, TURN.r, 0.18, 48), new THREE.MeshStandardMaterial({ color: 0x2a2d33, metalness: 0.6, roughness: 0.25 })); this.turn.position.set(TURN.x, 0.09, TURN.z); g.add(this.turn);
    { const ring = new THREE.Mesh(new THREE.TorusGeometry(TURN.r + 0.05, 0.04, 6, 64).rotateX(PI / 2), new THREE.MeshBasicMaterial({ color: 0xf2f6ff, toneMapped: false })); ring.position.set(TURN.x, 0.19, TURN.z); g.add(ring); }
    { const t = solid(TURN.x - TURN.r, TURN.z - TURN.r, TURN.x + TURN.r, TURN.z + TURN.r, 1.6); this.turnCol = t; }
    { const m = this.label('PRÉSENTATION', 'plateau tournant', 3.4, 0.6, '#16181c', '#e8e8e8'); m.position.set(HALL.x0 + 0.07, 3.6, 0); m.rotation.y = PI / 2; g.add(m); }
    // tableau numérique de la collection (mur ouest)
    this.boardCanvas = document.createElement('canvas'); this.boardCanvas.width = 1400; this.boardCanvas.height = 1000; this.boardTex = new THREE.CanvasTexture(this.boardCanvas); this.boardTex.colorSpace = THREE.SRGBColorSpace;
    const bd = new THREE.Mesh(new THREE.PlaneGeometry(6.3, 4.5), new THREE.MeshBasicMaterial({ map: this.boardTex, toneMapped: false })); bd.position.set(HALL.x0 + 0.08, 2.6, BOARD.z + 1.2); bd.rotation.y = PI / 2; g.add(bd); box(HALL.x0, 0.3, BOARD.z + 1.2 - 3.3, HALL.x0 + 0.06, 4.9, BOARD.z + 1.2 + 3.3, 0x0b0c0e);
    // ascenseur piétons (vers l'allée de la villa)
    box(36, 0, 12.4, 39, 3, 13.98, 0x8a8f96); box(36.5, 0.2, 12.38, 38.5, 2.6, 12.42, 0x2a2d33); { const m = this.label('ASCENSEUR', 'vers l’allée de la villa', 2.6, 0.5, '#16181c', '#e8e8e8'); m.position.set(37.5, 3.3, 12.36); m.rotation.y = PI; g.add(m); }
    g.add(new THREE.Mesh(mergeGeometries(parts), new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.55 })));
    // voitures exposées
    this.carRoot = new THREE.Group(); g.add(this.carRoot); this.bayCols = {};
    for (const { c } of this.list()) this.placeStatic(c.id);
    this.drawBoard(); g.visible = false;
  }
  // voiture exposée : 4 maillages fusionnés (peinture, vitres, roues, détails), sans matériau propre à la voiture
  staticMesh(spec, hex) {
    const m = buildCarMesh(spec, hex), b = { paint: [], glass: [], wheel: [], misc: [] };
    m.group.updateMatrixWorld(true);
    m.group.traverse((o) => { if (!o.isMesh) return; const geo = o.geometry.clone().applyMatrix4(o.matrixWorld), mt = o.material;
      if (mt === paintMat()) b.paint.push(normGeo(geo)); else if (mt === glassMat()) b.glass.push(normGeo(geo, 0x0d151c)); else if (mt === wheelMat()) b.wheel.push(normGeo(geo)); else b.misc.push(normGeo(geo, mt.color ? mt.color.getHex() : 0x888888)); });
    m.group.traverse((o) => { if (!o.isMesh) return; if (o.material !== glassMat() && o.material !== wheelMat()) o.geometry.dispose(); if (o.material !== paintMat() && o.material !== glassMat() && o.material !== wheelMat()) o.material.dispose(); });
    const grp = new THREE.Group();
    for (const [k, mat] of [['paint', paintMat()], ['glass', glassMat()], ['wheel', wheelMat()], ['misc', MISC]]) if (b[k].length) { const ms = new THREE.Mesh(mergeGeometries(b[k]), mat); ms.castShadow = k === 'paint'; ms.receiveShadow = true; grp.add(ms); }
    return grp;
  }
  spot(id) { const r = this.recs[id]; return this.present === id ? { x: TURN.x, z: TURN.z, h: this._turnA || 0 } : bayPos(r.bay); }
  placeStatic(id) {
    if (!this.built) return; this.dropStatic(id); const r = this.recs[id], s = this.spec(id); if (r.out) return;
    const grp = this.staticMesh(s, r.color), p = this.spot(id); grp.position.set(p.x, this.present === id ? 0.18 : 0, p.z); grp.rotation.y = p.h; this.carRoot.add(grp); this.statics[id] = grp;
    if (this.present !== id) { const hw = s.width / 2 + 0.05, hl = s.len / 2; this.bayCols[id] = this.solidCar(p.x - hw, p.z - hl, p.x + hw, p.z + hl); }
  }
  solidCar(x0, z0, x1, z1) { const { O, Y, LV } = MBG, o = this.world.collision.addBox(O.x + x0, O.z + z0, O.x + x1, O.z + z1, Y + 1.9); o.lv = LV; return o; }
  dropStatic(id) { const m = this.statics[id]; if (m) { this.carRoot.remove(m); m.traverse((o) => { if (o.isMesh) o.geometry.dispose(); }); delete this.statics[id]; } const c = this.bayCols && this.bayCols[id]; if (c) { c.disabled = true; delete this.bayCols[id]; } if (this.lod && this.lod.id === id) this.dropLod(); }
  // modèle détaillé de la voiture la plus proche (portes et phares animés)
  setLod(id) {
    if (this.lod && this.lod.id === id) return; this.dropLod(); const r = this.recs[id]; if (!id || r.out || !this.statics[id]) return;
    const m = buildCarMesh(this.spec(id), r.color), p = this.spot(id); m.group.position.set(p.x, this.present === id ? 0.18 : 0, p.z); m.group.rotation.y = p.h; this.carRoot.add(m.group); this.statics[id].visible = false;
    this.lod = { id, m, doors: 0, lights: false };
  }
  dropLod() { const L = this.lod; if (!L) return; this.carRoot.remove(L.m.group); L.m.group.traverse((o) => { if (o.isMesh) { if (o.geometry !== undefined && o.material !== glassMat() && o.material !== wheelMat()) o.geometry.dispose(); if (o.material !== paintMat() && o.material !== glassMat() && o.material !== wheelMat()) o.material.dispose(); } }); if (this.statics[L.id]) this.statics[L.id].visible = true; this.lod = null; }
  drawBoard() {
    if (!this.boardCanvas) return; const x = this.boardCanvas.getContext('2d'), W = 1400, Hh = 1000;
    x.fillStyle = '#07080a'; x.fillRect(0, 0, W, Hh); x.fillStyle = '#e8e8e8'; x.font = '700 46px Arial'; x.textAlign = 'left'; x.fillText('MA COLLECTION — MERCEDES-BENZ', 40, 70);
    const L = this.list(), out = L.filter((q) => q.r.out).length; x.font = '400 26px Arial'; x.fillStyle = '#9aa0a8'; x.fillText(`${L.length} véhicules • ${L.length - out} au garage • ${out} dehors • collection fictive du jeu, non affiliée`, 40, 110);
    x.font = '400 25px Arial';
    L.forEach(({ c, r }, i) => { const col = i < 16 ? 0 : 1, row = i % 16, X = 40 + col * 680, Yy = 160 + row * 52, st = this.status(c.id);
      x.fillStyle = st === 'dehors' ? '#f2c200' : st === 'en présentation' ? '#7ad0ff' : '#2fb07a'; x.beginPath(); x.arc(X + 8, Yy - 8, 7, 0, 7); x.fill();
      x.fillStyle = '#e8e8e8'; x.fillText(`${String(r.bay + 1).padStart(2, '0')}  ${c.name.replace('Mercedes-Benz ', '').replace('Mercedes-', '')}`.slice(0, 44), X + 26, Yy); x.fillStyle = '#7a8088'; x.fillText(st, X + 560, Yy); });
    this.boardTex.needsUpdate = true;
  }
  // ------------------------------------------------------------------ entrer / sortir du garage
  enter(id) {
    this.buildInside(); const { O, Y, LV } = MBG, pl = this.player;
    this.inside = true; this.inGroup.visible = true; this.world.collision.level = LV; pl.floorY = Y; pl.vy = 0;
    const p = id ? bayPos(this.recs[id].bay) : { x: LIFT.x, z: LIFT.z - 1.8 }, z = id ? (p.z < 0 ? -5.4 : 5.4) : p.z;
    pl.pos.set(O.x + p.x, Y, O.z + z); pl.facing = id ? (p.z < 0 ? PI : 0) : PI; pl.mesh.position.copy(pl.pos); if (this.tpc && this.tpc.snap) this.tpc.snap(pl.pos);
    this.lightRig(true); this.drawBoard();
    this.ui.toast('🅿️ Garage privé : collection Mercedes-Benz (32 emplacements). Approche-toi d’une voiture et appuie sur E.', 3.5);
    if (this.audio && this.audio.ctx) this.audio.door();
  }
  leave(silent) {
    const pl = this.player; this.inside = false; if (this.inGroup) this.inGroup.visible = false; this.world.collision.level = 0; pl.floorY = 0; pl.vy = 0; this.dropLod(); this.lightRig(false);
    pl.pos.set(PAD.x - 3.6, 0, PAD.z - 2.1); pl.facing = PI; pl.mesh.position.copy(pl.pos); if (this.tpc && this.tpc.snap) this.tpc.snap(pl.pos);
    if (!silent) this.ui.toast('Tu remontes dans l’allée de la villa.', 1.6);
  }
  lightRig(on) {
    const ls = this.home && this.home.lights; if (!ls) return; if (!this._orig) this._orig = ls.map((l) => ({ p: l.position.clone(), d: l.distance, c: l.color.getHex() }));
    if (on) { this._follow = true; ls.forEach((l) => { l.distance = 32; l.decay = 0.9; l.color.setHex(0xf2f6ff); }); this.followLights(); }
    else if (this._follow) { this._follow = false; ls.forEach((l, i) => { l.position.copy(this._orig[i].p); l.distance = this._orig[i].d; l.decay = 1.6; l.intensity = 0; l.color.setHex(this._orig[i].c); }); }
  }
  followLights() { const ls = this.home.lights, P = this.player.pos, { Y } = MBG; ls.forEach((l, i) => { l.position.set(P.x - 10 + i * 10, Y + HALL.H - 1.2, P.z + (i === 1 ? 5 : -4)); l.intensity = 34; }); }
  // ------------------------------------------------------------------ voitures dehors (véhicules conduisibles)
  padFree() { return !this.cars.some((c) => Math.hypot(c.pos.x - PAD.x, c.pos.z - PAD.z) < 3.2); }
  spawn(id) {
    if (this.live.has(id)) return this.live.get(id); const r = this.recs[id]; if (!r.out) return null;
    const car = new GarageCar(this.scene, { x: r.out.x, z: r.out.z, h: r.out.h, model: id, color: r.color, damage: r.damage });
    car.mbId = id; car.onHint = (m) => this.ui.toast(m, 2); car.onDamage = (c, b) => { if (Math.floor(c.damage / 25) > Math.floor(b / 25)) this.ui.toast(`Carrosserie abîmée : ${Math.round(c.damage)} % — zone d’entretien du garage privé`, 2.2); };
    this.live.set(id, car); this.cars.push(car); return car;
  }
  despawn(id) { const car = this.live.get(id); if (!car || car.occupied) return; this.sync(car); car.dispose(this.scene); this.live.delete(id); const i = this.cars.indexOf(car); if (i >= 0) this.cars.splice(i, 1); }
  sync(car) { const r = this.recs[car.mbId]; if (r && r.out) { r.out = { x: Math.round(car.pos.x * 10) / 10, z: Math.round(car.pos.z * 10) / 10, h: Math.round(car.heading * 100) / 100 }; r.damage = Math.round(car.damage); } }
  takeOut(id, drive = true) {
    const r = this.recs[id], s = this.spec(id); if (!r) return;
    if (r.out) return this.ui.toast(`${s.name} est déjà dehors.`, 2.5);
    if (!this.padFree()) return this.ui.toast('L’ascenseur à voitures est occupé : dégage d’abord la plateforme de l’allée.', 3);
    this.ui.fade && this.ui.fade(true);
    setTimeout(() => {
      if (this.present === id) this.present = null;
      r.out = { x: PAD.x, z: PAD.z, h: PAD.h }; this.dropStatic(id); if (this.inside) this.leave(true);
      const car = this.spawn(id); this.drawBoard(); this.onSave && this.onSave();
      if (drive && car && this.enterCar) { this.player.pos.set(car.pos.x, 0, car.pos.z); this.enterCar(car); }
      this.ui.fade && this.ui.fade(false);
      this.ui.toast(`🚘 ${s.name} remonte par l’ascenseur : la porte automatique s’ouvre. Bonne route ! (R moteur • L phares • 1/3 clignotants • 2 détresse • O portes • V vues • K klaxon)`, 5.5);
      if (this.audio && this.audio.ctx) this.audio.tone(220, 0.6, 0.05, 'sine');
    }, 600);
  }
  onPad(car) { return car && car.mbId && Math.hypot(car.pos.x - PAD.x, car.pos.z - PAD.z) < 3 && Math.abs(car.speed) < 0.6; }
  storeMenu(car) {
    const s = this.spec(car.mbId);
    this.ui.openMenu(`🅿️ ${s.name}`, 'Plateforme de l’ascenseur à voitures', [{ label: '⬇️ Ranger la voiture au garage privé (et descendre avec elle)', action: () => this.store(car, true) }, { label: '🚶 Descendre de la voiture ici', action: () => { this.exitCar && this.exitCar(); } }, { label: 'Rester au volant', action: () => {} }]);
  }
  store(car, follow) {
    const id = car.mbId, r = this.recs[id]; if (!r) return;
    this.ui.fade && this.ui.fade(true);
    setTimeout(() => {
      if (this.player.inCar === car && this.exitCar) this.exitCar();
      this.sync(car); car.occupied = false; r.damage = Math.round(car.damage); r.out = null; this.despawn(id);
      this.buildInside(); this.placeStatic(id); this.drawBoard(); if (follow) this.enter(id);
      this.ui.fade && this.ui.fade(false); this.onSave && this.onSave();
      this.ui.toast(`🅿️ ${this.spec(id).name} rangée à l’emplacement ${String(r.bay + 1).padStart(2, '0')}.`, 2.5);
    }, 600);
  }
  // ------------------------------------------------------------------ menus
  carMenu(id) {
    const s = this.spec(id), r = this.recs[id], L = this.lod && this.lod.id === id ? this.lod : null;
    this.ui.openMenu(`🚘 ${s.name}`, `${s.type} • emplacement ${String(r.bay + 1).padStart(2, '0')} • ${colorName(r.color)}`, [
      { label: '🔑 Prendre le volant', desc: 'La voiture remonte par l’ascenseur dans l’allée de la villa', action: () => this.takeOut(id, true) },
      { label: L && L.doors ? '🚪 Fermer les portes' : '🚪 Ouvrir les portes', action: () => { if (this.lod && this.lod.id === id) { this.lod.doors = this.lod.doors ? 0 : 1; if (this.audio && this.audio.ctx) this.audio.door(); } } },
      { label: L && L.lights ? '💡 Éteindre les phares' : '💡 Allumer les phares', action: () => { if (this.lod && this.lod.id === id) { this.lod.lights = !this.lod.lights; const m = this.lod.m; m.headMat.emissiveIntensity = this.lod.lights ? 2.4 : 0.12; m.tailMat.emissiveIntensity = this.lod.lights ? 0.9 : 0.12; } } },
      { label: '📯 Klaxonner', action: () => { const p = this.player.pos; if (this.audio && this.audio.ctx) this.audio.horn(p.x, p.z, s.horn, true); } },
      { label: '🎨 Couleur de carrosserie', desc: colorName(r.color), action: () => setTimeout(() => this.colorMenu(id), 60) },
      { label: this.present === id ? '↩️ Remettre à son emplacement' : '⭐ Mettre sur le plateau de présentation', action: () => this.setPresent(this.present === id ? null : id) },
      { label: 'ℹ️ Fiche du véhicule', action: () => setTimeout(() => this.info(id), 60) },
    ]);
  }
  colorMenu(id) { const s = this.spec(id), r = this.recs[id]; this.ui.openMenu(`🎨 ${s.name}`, 'Teintes proposées pour ce modèle (peinture du jeu)', s.colors.map((hex) => ({ label: `${hex === r.color ? '✔ ' : ''}${colorName(hex)}`, action: () => { r.color = hex; this.placeStatic(id); this.drawBoard(); this.onSave && this.onSave(); this.ui.toast(`🎨 ${s.name} : ${colorName(hex)}`, 2); } }))); }
  info(id) {
    const s = this.spec(id), r = this.recs[id];
    this.ui.openMenu(`ℹ️ ${s.name}`, `${s.series} • ${s.type}`, [
      { label: `📏 ${s.len.toFixed(2).replace('.', ',')} m × ${s.width.toFixed(2).replace('.', ',')} m • ${s.stats.mass.toLocaleString('fr-FR')} kg (approx.)`, action: () => {} },
      { label: `⚙️ Motorisation : ${ENG[s.sound.type] || s.sound.type} • 0-100 km/h ≈ ${String(s.stats.t100).replace('.', ',')} s • vitesse maxi ≈ ${s.stats.realVmax} km/h${s.stats.realVmax > s.stats.vmax ? ` (limitée à ${s.stats.vmax} km/h dans le jeu)` : ''}`, action: () => {} },
      { label: `🎨 ${colorName(r.color)} • état : ${100 - r.damage} % • ${this.status(id)}`, action: () => {} },
      { label: `💰 Valeur de jeu indicative : ${abbr(s.value)}`, action: () => {} },
      { label: 'ℹ️ Données de jeu approximatives (pas une fiche officielle) • collection fictive, non affiliée à Mercedes-Benz', action: () => {} },
    ]);
  }
  setPresent(id) {
    const prev = this.present; this.present = id; if (prev) this.placeStatic(prev); if (id) this.placeStatic(id); this.drawBoard(); this.onSave && this.onSave();
    if (id) this.ui.toast(`⭐ ${this.spec(id).name} sur le plateau de présentation.`, 2.5);
  }
  boardMenu() {
    this.ui.openMenu('📋 Tableau numérique de la collection', `${MB_CARS.length} véhicules • choisis une voiture`, this.list().map(({ c, r }) => ({ label: `${String(r.bay + 1).padStart(2, '0')} • ${c.name}`, desc: this.status(c.id), action: () => setTimeout(() => (r.out ? this.ui.toast(`${c.name} est dehors : elle reviendra au garage quand tu la rangeras sur la plateforme de l’ascenseur.`, 3.5) : this.carMenu(c.id)), 60) })));
  }
  washMenu() {
    const dirty = this.list().filter(({ r }) => !r.out && r.damage > 0);
    this.ui.openMenu('🧽 Lavage & entretien', dirty.length ? 'Véhicules à remettre en état' : 'Tous les véhicules du garage sont impeccables.', [...dirty.map(({ c, r }) => ({ label: `🔧 ${c.name}`, desc: `état ${100 - r.damage} %`, action: () => { r.damage = 0; this.placeStatic(c.id); this.onSave && this.onSave(); this.ui.toast(`✨ ${c.name} lavée et remise à neuf.`, 2.2); } })), { label: '✨ Lavage de toute la collection (1 h)', action: () => { for (const { r } of this.list()) if (!r.out) r.damage = 0; this.env.time = (this.env.time + 1) % 24; this.ui.toast('✨ Toute la collection est lavée et contrôlée.', 2.5); this.onSave && this.onSave(); } }]);
  }
  // ------------------------------------------------------------------ interactions (E)
  nearest(x, z) {
    const { O } = MBG;
    if (!this.inside) {
      if (this.player.inCar) return null; const d = Math.hypot(x - PAD.x, z - PAD.z);
      return d < 3.4 ? { d, it: { label: () => '🛗 Descendre au garage privé (collection Mercedes-Benz)', action: () => this.enter() } } : null;
    }
    const lx = x - O.x, lz = z - O.z; let best = null; const consider = (d, label, action) => { if (!best || d < best.d) best = { d, it: { label: () => label, action } }; };
    for (const { c, r } of this.list()) { if (r.out) continue; const p = this.spot(c.id), pr = this.present === c.id, ax = pr ? p.x + TURN.r + 0.8 : p.x, az = pr ? p.z : p.z < 0 ? p.z + c.len / 2 + 0.9 : p.z - c.len / 2 - 0.9;
      const d = Math.hypot(lx - ax, lz - az); if (d < 2.1) consider(d, `🚘 ${c.name}`, () => this.carMenu(c.id)); }
    const db = Math.hypot(lx - BOARD.x, lz - BOARD.z); if (db < 2.4) consider(db, '📋 Tableau numérique de la collection', () => this.boardMenu());
    const dw = Math.hypot(lx - WASH.x, lz - WASH.z); if (dw < 3) consider(dw, '🧽 Lavage & entretien', () => this.washMenu());
    const dl = Math.hypot(lx - LIFT.x, lz - (LIFT.z - 1)); if (dl < 2) consider(dl, '🛗 Remonter dans l’allée de la villa', () => this.leave());
    return best;
  }
  // ------------------------------------------------------------------ boucle
  update(dt) {
    const pl = this.player, P = pl.pos, { O, Y } = MBG;
    this.outGroup.visible = Math.hypot(P.x - PAD.x, P.z - PAD.z) < 160;
    if (this.padLed) this.padLed.material.color.setHex(this.padFree() ? 0xe8f0ff : 0xf2c200);
    // voitures dehors : chargement à proximité, feux, sauvegarde légère des positions
    for (const [id, r] of Object.entries(this.recs)) { if (!r.out) continue; const car = this.live.get(id), d = Math.hypot((car ? car.pos.x : r.out.x) - P.x, (car ? car.pos.z : r.out.z) - P.z); if (!car && d < 220 && !this.inside) this.spawn(id); else if (car && d > 280 && !car.occupied) this.despawn(id); }
    for (const car of this.live.values()) car.setLights(this.env.lightsOn > 0.3 || (car.occupied && this.env.lightsOn > 0.1));
    this._sT = (this._sT || 0) + dt; if (this._sT > 5) { this._sT = 0; for (const c of this.live.values()) this.sync(c); }
    const cur = pl.inCar && pl.inCar.mbId ? pl.inCar : null; if (cur && this.onPad(cur) && !this._padHint) { this._padHint = true; this.ui.toast('🅿️ Plateforme du garage privé : E pour ranger la voiture', 2.5); } if (!cur || !this.onPad(cur)) this._padHint = false;
    if (!this.inside) return;
    if (Math.abs((P.y || Y) - Y) > 6 || Math.hypot(P.x - O.x, P.z - O.z) > 70) { this.inside = false; this.inGroup.visible = false; this.world.collision.level = 0; pl.floorY = 0; this.dropLod(); this.lightRig(false); return; } // sortie par un autre moyen
    this.followLights();
    // voiture la plus proche en modèle détaillé
    const lx = P.x - O.x, lz = P.z - O.z; let near = null, nd = 6.5; for (const { c, r } of this.list()) { if (r.out) continue; const p = this.spot(c.id), d = Math.hypot(lx - p.x, lz - p.z); if (d < nd) { nd = d; near = c.id; } }
    if (near !== (this.lod && this.lod.id)) this.setLod(near);
    if (this.lod) { for (const d of this.lod.m.doors) { d.open += ((this.lod.doors ? 1 : 0) - d.open) * Math.min(1, dt * 6); d.pivot.rotation.y = d.side * d.open * 1.05; } }
    // plateau de présentation et porte automatique
    this._turnA = ((this._turnA || 0) + dt * 0.3) % (2 * PI); this.turn.rotation.y = this._turnA;
    if (this.present && this.statics[this.present]) this.statics[this.present].rotation.y = this._turnA; if (this.lod && this.lod.id === this.present) this.lod.m.group.rotation.y = this._turnA;
    const nearDoor = Math.hypot(lx - HALL.x1, lz) < 9; this.doorT += ((nearDoor ? 1 : 0) - this.doorT) * Math.min(1, dt * 2); this.door.position.y = 2.1 + this.doorT * 3.0; this.door.scale.y = 1 - this.doorT * 0.6;
  }
  // ------------------------------------------------------------------ touches de conduite (toutes les voitures du garage et de la collection)
  carKeys(input, car, garage) {
    if (!car || !car.spec || car.isLimo) return;
    if (input.hit('Digit1') || input.hit('Numpad1')) { car.blink = car.blink === 'l' ? null : 'l'; }
    if (input.hit('Digit3') || input.hit('Numpad3')) { car.blink = car.blink === 'r' ? null : 'r'; }
    if (input.hit('Digit2') || input.hit('Numpad2')) { car.blink = car.blink === 'w' ? null : 'w'; this.ui.toast(car.blink ? '⚠️ Feux de détresse' : 'Feux de détresse éteints', 1.2); }
    if (input.hit('KeyL')) { car.lightMode = car.lightMode === 'auto' ? 'on' : car.lightMode === 'on' ? 'off' : 'auto'; this.ui.toast(`💡 Phares : ${car.lightMode === 'auto' ? 'automatiques' : car.lightMode === 'on' ? 'allumés' : 'éteints'}`, 1.4); }
    if (input.hit('KeyR')) { if (Math.abs(car.speed) > 1 && !car.engineOff) this.ui.toast('Arrête-toi avant de couper le moteur.', 1.6); else { car.engineOff = !car.engineOff; car._offHint = false; this.ui.toast(car.engineOff ? '⛔ Moteur arrêté' : '🔑 Moteur démarré', 1.4); if (!car.engineOff && this.audio && this.audio.ctx) this.audio.tone(90, 0.5, 0.06, 'sawtooth'); } }
    if (input.hit('KeyO')) { if (Math.abs(car.speed) > 0.5) this.ui.toast('Arrête-toi pour ouvrir les portes.', 1.4); else { car.doorsOpen = !car.doorsOpen; if (this.audio && this.audio.ctx) this.audio.door(); } }
    if (car.blink === 'l' || car.blink === 'r') { const t = performance.now(); if (!this._tick || t - this._tick > 380) { this._tick = t; if (this.audio && this.audio.ctx) this.audio.tone(1800, 0.02, 0.015, 'square'); } // retour automatique du clignotant après un virage
      if (Math.abs(car.steer) > 0.25) car._turned = true; else if (car._turned && Math.abs(car.steer) < 0.05) { car._turned = false; car.blink = null; } }
  }
  serialize() { for (const c of this.live.values()) this.sync(c); return { recs: this.recs, present: this.present }; }
  restore(s) {
    if (!s || !s.recs) return;
    for (const [id, r] of Object.entries(s.recs)) if (this.recs[id] && r) Object.assign(this.recs[id], { color: r.color ?? this.recs[id].color, out: r.out && Number.isFinite(r.out.x) ? r.out : null, damage: r.damage || 0, km: r.km || 0 });
    this.present = s.present && this.recs[s.present] && !this.recs[s.present].out ? s.present : null;
  }
}
