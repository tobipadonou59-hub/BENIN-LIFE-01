// Mission 013, étape 4 — transports commandés au téléphone : zémidjan (moto-taxi), tokpa-tokpa (minibus collectif),
// taxi. Le véhicule vient te chercher sur la route la plus proche, tu montes (E), il roule tout seul sur le réseau
// routier jusqu'à la destination choisie, puis tu descends sur le trottoir. Tarifs du jeu en FCFA (indicatifs, fictifs).
import * as THREE from 'three';
import { createCarMesh, createMotoMesh } from './vehicles.js';
import { fcfa } from './food-data.js';
import { REGION, TOWNS, nearestOnRoad } from './region-geo.js';

const PI = Math.PI, LANE = 3.5;
export const RIDES = {
  zem: { label: 'Zémidjan', sub: 'moto-taxi', icon: '🛵', base: 200, perM: 0.6, speed: 11.5, eta: 8, moto: true, cam: 5 },
  tokpa: { label: 'Tokpa-tokpa', sub: 'minibus collectif, arrêts en route', icon: '🚐', base: 150, perM: 0.3, speed: 9, eta: 18, model: 'minibus', color: 0xf2c200, stops: 2, cam: 9 },
  taxi: { label: 'Taxi', sub: 'voiture privée, direct', icon: '🚕', base: 600, perM: 1.5, speed: 13, eta: 12, model: 'sedan', color: 0xf2c200, cam: 7.5 },
};
// destinations : lieux qui existent déjà dans le jeu (coordonnées du jeu, pas de géographie réelle ajoutée)
export const DESTS = [
  { id: 'maison', label: 'Ma maison', icon: '🏠', x: -42, z: 108 },
  { id: 'dantokpa', label: 'Marché Dantokpa', icon: '🧺', x: -50, z: 93 },
  { id: 'laguna', label: 'Supermarché LAGUNA', icon: '🛒', x: 42, z: -108 },
  { id: 'garage', label: 'Garage AUTO CONCEPT', icon: '🚗', x: -42, z: -108 },
  { id: 'martyrs', label: 'Place des Martyrs', icon: '🏛️', x: 50, z: 107 },
  { id: 'jardin', label: 'Jardin de Cadjèhoun', icon: '🌳', x: 50, z: -7 },
  { id: 'plage', label: 'Plage (Boulevard de la Marina)', icon: '🏖️', x: 0, z: 158 },
  { id: 'aeroport', label: 'Aéroport', icon: '✈️', x: -440, z: 106 },
  // villes de la région (centres OpenStreetMap ; arrêt sur la RNIE 1 au plus près du centre)
  ...TOWNS.map((t) => { const p = nearestOnRoad(t.x, t.z); return { id: 'v_' + t.name, label: t.name, icon: '🏙️', x: p.x, z: p.z, far: true }; }),
];

// ---- réseau routier (axes des boulevards) : graphe sans le rond-point central ----
const XS = [-100, 0, 100], ZS = [-100, 0, 100, 152];
const key = (x, z) => `${x},${z}`;
const NODES = new Map();
for (const x of XS) for (const z of ZS) if (!(x === 0 && z === 0)) NODES.set(key(x, z), { x, z });
NODES.set(key(-440, 100), { x: -440, z: 100 });
const EDGES = [];
for (const x of XS) for (let i = 0; i < ZS.length - 1; i++) EDGES.push([x, ZS[i], x, ZS[i + 1]]);
for (const z of ZS) for (let i = 0; i < XS.length - 1; i++) EDGES.push([XS[i], z, XS[i + 1], z]);
EDGES.push([-440, 100, -100, 100]);
// RNIE 1 : sortie nord (x = −100) et sortie est (z = −100) de la ville du jeu, puis tracé OpenStreetMap
NODES.set(key(-100, -175), { x: -100, z: -175 }); EDGES.push([-100, -175, -100, -100]);
NODES.set(key(175, -100), { x: 175, z: -100 }); EDGES.push([100, -100, 175, -100]);
for (const r of REGION.roads) for (let i = 0; i < r.pts.length - 1; i++) {
  const [ax, az] = r.pts[i], [bx, bz] = r.pts[i + 1];
  NODES.set(key(ax, az), { x: ax, z: az }); NODES.set(key(bx, bz), { x: bx, z: bz }); EDGES.push([ax, az, bx, bz]);
}
const isCenter = (x, z) => x === 0 && z === 0;
const ADJ = new Map();
for (const [ax, az, bx, bz] of EDGES) {
  if (isCenter(ax, az) || isCenter(bx, bz)) continue;
  const a = key(ax, az), b = key(bx, bz), d = Math.hypot(bx - ax, bz - az);
  (ADJ.get(a) || ADJ.set(a, []).get(a)).push([b, d]); (ADJ.get(b) || ADJ.set(b, []).get(b)).push([a, d]);
}
function dijkstra(src) {
  const dist = new Map([[src, 0]]), prev = new Map(), todo = new Set(NODES.keys());
  while (todo.size) {
    let u = null, best = Infinity;
    for (const k of todo) { const d = dist.has(k) ? dist.get(k) : Infinity; if (d < best) { best = d; u = k; } }
    if (u === null) break; todo.delete(u);
    for (const [v, w] of ADJ.get(u) || []) { const nd = best + w; if (nd < (dist.has(v) ? dist.get(v) : Infinity)) { dist.set(v, nd); prev.set(v, u); } }
  }
  return { dist, prev };
}
const DJ = new Map(); const dj = (k) => DJ.get(k) || DJ.set(k, dijkstra(k)).get(k);
// point le plus proche sur un axe routier
export function snap(x, z) {
  let best = null;
  for (const e of EDGES) {
    const [ax, az, bx, bz] = e, L = Math.hypot(bx - ax, bz - az), t = Math.max(0, Math.min(1, ((x - ax) * (bx - ax) + (z - az) * (bz - az)) / (L * L)));
    let px = ax + (bx - ax) * t, pz = az + (bz - az) * t;
    // pas de prise en charge dans l'anneau du rond-point
    if (Math.hypot(px, pz) < 30 && (ax === bx || az === bz)) { const k = 30 / (Math.hypot(px, pz) || 1); if (ax === bx) pz *= k; else px *= k; }
    const d = Math.hypot(x - px, z - pz);
    if (!best || d < best.d) best = { d, x: px, z: pz, e };
  }
  return best;
}
// itinéraire (axes) entre deux points du réseau
export function planRoute(from, to) {
  const S = snap(from.x, from.z), D = snap(to.x, to.z);
  const ends = (p) => [[p.e[0], p.e[1]], [p.e[2], p.e[3]]].filter(([x, z]) => !isCenter(x, z)).map(([x, z]) => ({ k: key(x, z), x, z, d: Math.hypot(p.x - x, p.z - z) }));
  let best = null;
  if (S.e === D.e) best = { len: Math.hypot(S.x - D.x, S.z - D.z), pts: [] };
  for (const a of ends(S)) for (const b of ends(D)) {
    const r = dj(a.k); const mid = r.dist.get(b.k); if (mid === undefined) continue;
    const len = a.d + mid + b.d;
    if (!best || len < best.len - 0.01) {
      const pts = []; let k = b.k; while (k) { pts.unshift(NODES.get(k)); if (k === a.k) break; k = r.prev.get(k); }
      best = { len, pts: pts.map((n) => [n.x, n.z]) };
    }
  }
  const raw = [[S.x, S.z], ...best.pts, [D.x, D.z]].filter((p, i, arr) => i === 0 || Math.hypot(p[0] - arr[i - 1][0], p[1] - arr[i - 1][1]) > 0.5);
  if (raw.length < 2) { const e = D.e, L = Math.hypot(e[2] - e[0], e[3] - e[1]); raw.push([D.x + (e[2] - e[0]) / L, D.z + (e[3] - e[1]) / L]); }
  return { S, D, len: best.len, axis: raw };
}
// décalage sur la voie de droite + virages arrondis + échantillonnage régulier
function lanePath(axis) {
  const n = axis.length, out = [];
  const right = (a, b) => { const dx = b[0] - a[0], dz = b[1] - a[1], l = Math.hypot(dx, dz) || 1; return [-dz / l, dx / l]; };
  for (let i = 0; i < n; i++) {
    const r1 = i > 0 ? right(axis[i - 1], axis[i]) : right(axis[0], axis[1]);
    const r2 = i < n - 1 ? right(axis[i], axis[i + 1]) : r1;
    let mx = r1[0] + r2[0], mz = r1[1] + r2[1]; const ml = Math.hypot(mx, mz) || 1; mx /= ml; mz /= ml;
    const k = LANE / Math.max(0.3, mx * r1[0] + mz * r1[1]);
    out.push([axis[i][0] + mx * k, axis[i][1] + mz * k]);
  }
  // arrondi des angles (rayon 7 m)
  const fil = [out[0]];
  for (let i = 1; i < out.length - 1; i++) {
    const p = out[i - 1], c = out[i], q = out[i + 1];
    const ux = p[0] - c[0], uz = p[1] - c[1], vx = q[0] - c[0], vz = q[1] - c[1], lu = Math.hypot(ux, uz), lv = Math.hypot(vx, vz);
    const r = Math.min(7, lu * 0.45, lv * 0.45);
    const a = [c[0] + ux / lu * r, c[1] + uz / lu * r], b = [c[0] + vx / lv * r, c[1] + vz / lv * r];
    for (let t = 0; t <= 1.0001; t += 0.125) { const m = 1 - t; fil.push([m * m * a[0] + 2 * m * t * c[0] + t * t * b[0], m * m * a[1] + 2 * m * t * c[1] + t * t * b[1]]); }
  }
  fil.push(out[out.length - 1]);
  const pts = [fil[0]], cum = [0];
  for (let i = 1; i < fil.length; i++) { const d = Math.hypot(fil[i][0] - pts[pts.length - 1][0], fil[i][1] - pts[pts.length - 1][1]); if (d < 0.05) continue; pts.push(fil[i]); cum.push(cum[cum.length - 1] + d); }
  return { pts, cum, length: cum[cum.length - 1] };
}
function sample(P, s, out = {}) {
  s = Math.max(0, Math.min(P.length, s));
  let lo = 0, hi = P.cum.length - 1;
  while (hi - lo > 1) { const m = (lo + hi) >> 1; if (P.cum[m] <= s) lo = m; else hi = m; }
  const a = P.pts[lo], b = P.pts[hi], t = (s - P.cum[lo]) / ((P.cum[hi] - P.cum[lo]) || 1);
  out.x = a[0] + (b[0] - a[0]) * t; out.z = a[1] + (b[1] - a[1]) * t; out.h = Math.atan2(b[0] - a[0], b[1] - a[1]);
  return out;
}

export class Transport {
  constructor(ctx) {
    Object.assign(this, ctx); // scene, world, economy, ui, audio, env, player, traffic, onSave
    this.ride = null; this.pick = 'zem'; this._q = {};
    this.hud = document.querySelector('#ride');
    this.hud.addEventListener('click', (e) => { const b = e.target.closest('[data-rd]'); if (!b) return; e.stopPropagation(); if (b.dataset.rd === 'skip') this.skip(); else if (b.dataset.rd === 'cancel') this.cancel(); });
  }
  pathFor(from, dest) { const rt = planRoute(from, dest); return { len: rt.len, ...lanePath(rt.axis) }; }
  get riding() { return !!this.ride && this.ride.phase === 'riding'; }
  // tarif dégressif au-delà de 1,5 km (trajets interurbains)
  price(type, len) { const T = RIDES[type], d = Math.min(len, 1500) + Math.max(0, len - 1500) * 0.4; return Math.max(T.base, Math.round((T.base + d * T.perM) / 50) * 50); }
  // durée réelle du trajet en secondes (vitesse moyenne ≈ 85 % de la vitesse de croisière, arrêts compris)
  seconds(type, len) { const T = RIDES[type]; return Math.max(5, Math.round(len / (T.speed * 0.85) + (T.stops || 0) * 3.5)); }

  // ---- application « Transports » du téléphone ----
  renderApp(b) {
    const P = this.player.pos;
    if (this.ride) {
      const r = this.ride, T = RIDES[r.type];
      b.innerHTML = `<h4>🚦 Transports</h4><div class="ph-row"><span><b>${T.icon} ${T.label} → ${r.dest.label}</b><small>${r.phase === 'coming' ? `Arrive dans ${Math.ceil(r.t)} s` : r.phase === 'waiting' ? 'T’attend sur la route (E pour monter)' : 'Trajet en cours'} • ${fcfa(r.price)}</small></span></div>
        ${r.phase !== 'riding' ? '<button class="ph-go" data-ride="cancel">ANNULER (GRATUIT)</button>' : ''}`;
      return;
    }
    b.innerHTML = `<h4>🚦 Transports</h4><div class="ph-tabs">${Object.entries(RIDES).map(([k, T]) => `<button data-ride="type:${k}" class="${k === this.pick ? 'on' : ''}">${T.icon} ${T.label}</button>`).join('')}</div>
      <p class="ph-note">${RIDES[this.pick].sub} • arrive en ~${RIDES[this.pick].eta} s • payé en montant</p>
      <div class="ph-list">${DESTS.map((d) => { const near = Math.hypot(P.x - d.x, P.z - d.z) < (d.far ? 150 : 25); const rt = planRoute(P, d); const pr = this.price(this.pick, rt.len);
        return `<div class="ph-row"><span><b>${d.icon} ${d.label}</b><small>${near ? 'Tu y es déjà' : `${(rt.len / 1000).toFixed(2).replace('.', ',')} km • ~${((sec) => sec < 90 ? sec + ' s' : Math.round(sec / 60) + ' min')(this.seconds(this.pick, rt.len))} de trajet • ${fcfa(pr)}`}</small></span>${near ? '' : `<button class="ph-mini" data-ride="go:${d.id}" ${this.economy.balance >= pr ? '' : 'disabled'}>Commander</button>`}</div>`; }).join('')}</div>`;
  }
  onPhone(v) {
    if (v === 'cancel') return this.cancel();
    const [a, b] = v.split(':');
    if (a === 'type') { this.pick = b; this.economy.renderPhone(); return; }
    if (a === 'go') this.order(this.pick, DESTS.find((d) => d.id === b));
  }
  order(type, dest) {
    if (this.ride) return;
    const P = this.player.pos, rt = planRoute(P, dest), price = this.price(type, rt.len);
    if (this.economy.balance < price) { this.economy.notify(`❌ Solde insuffisant pour ce trajet (${fcfa(price)})`); return; }
    this.ride = { type, dest, price, phase: 'coming', t: RIDES[type].eta, route: rt };
    this.economy.togglePhone(false);
    this.ui.toast(`${RIDES[type].icon} ${RIDES[type].label} commandé pour ${dest.label} (${fcfa(price)}). Il arrive dans ${RIDES[type].eta} s : va au bord de la route.`, 3.5);
    if (this.audio && this.audio.ctx) this.audio.tone(990, 0.08, 0.05, 'sine');
    this.renderHud();
  }
  cancel() {
    if (!this.ride || this.ride.phase === 'riding') return;
    this.removeVehicle(); this.ride = null; this.ui.toast('Course annulée (rien n’a été payé).', 2); this.renderHud();
    if (this.economy.phoneOpen) this.economy.renderPhone();
  }

  // ---- véhicule ----
  spawn() {
    const r = this.ride, T = RIDES[r.type];
    // l'itinéraire est recalculé depuis la position actuelle (le joueur a pu bouger en attendant)
    r.route = planRoute(this.player.pos, r.dest); r.path = lanePath(r.route.axis); r.s = 0; r.speed = 0;
    let m;
    if (T.moto) m = createMotoMesh(5000 + Math.floor(Math.random() * 999), { passenger: false });
    else m = createCarMesh(T.color, T.model);
    r.mesh = m.group; r.wheels = m.wheels; r.wheelR = T.moto ? 0.36 : 0.36; r.spin = 0;
    if (T.model === 'minibus' || r.type === 'taxi') r.mesh.add(this.roofSign(r.type));
    this.scene.add(r.mesh);
    const p = sample(r.path, 0); r.x = p.x; r.z = p.z; r.h = p.h; this.place(r);
    r.phase = 'waiting'; r.wait = 120; r.stopsLeft = T.stops || 0; r.nextStop = T.stops ? r.path.length / (T.stops + 1) : Infinity;
    if (this.audio && this.audio.ctx) this.audio.horn(r.x, r.z, T.moto ? 'moto' : 'car', true);
    this.ui.toast(`${T.icon} Ton ${T.label.toLowerCase()} est arrivé sur la route : approche-toi et appuie sur E pour monter.`, 3);
  }
  roofSign(type) {
    const c = document.createElement('canvas'); c.width = 256; c.height = 64; const x = c.getContext('2d');
    x.fillStyle = '#111'; x.fillRect(0, 0, 256, 64); x.fillStyle = '#f2c200'; x.font = '900 40px Arial'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(type === 'taxi' ? 'TAXI' : 'TOKPA', 128, 34);
    const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace;
    const g = new THREE.Group(), mat = new THREE.MeshBasicMaterial({ map: tex, toneMapped: false });
    const y = type === 'taxi' ? 1.62 : 2.42;
    for (const s of [1, -1]) { const p = new THREE.Mesh(new THREE.PlaneGeometry(0.8, 0.2), mat); p.position.set(0, y, s * 0.13); p.rotation.y = s > 0 ? 0 : PI; g.add(p); }
    const bx = new THREE.Mesh(new THREE.BoxGeometry(0.82, 0.22, 0.24), new THREE.MeshStandardMaterial({ color: 0x111111 })); bx.position.y = y; g.add(bx);
    return g;
  }
  place(r) {
    r.mesh.position.set(r.x, 0, r.z); r.mesh.rotation.set(0, r.h, 0);
    if (RIDES[r.type].moto) for (const w of r.wheels) w.rotation.x = r.spin;
    else for (const w of r.wheels) if (w.spin) w.spin.rotation.x = r.spin;
  }
  removeVehicle() { const r = this.ride; if (r && r.mesh) { this.scene.remove(r.mesh); r.mesh = null; } }
  nearest(x, z) {
    const r = this.ride; if (!r || r.phase !== 'waiting') return null;
    const d = Math.hypot(x - r.x, z - r.z);
    if (d > 5.5) return null;
    const T = RIDES[r.type];
    return { d: Math.max(0, d - 1), it: { label: () => `Monter : ${T.label} → ${r.dest.label} (${fcfa(r.price)})`, action: () => this.board() } };
  }
  board() {
    const r = this.ride, T = RIDES[r.type], pl = this.player;
    if (!this.economy.pay(r.price, `${T.label} → ${r.dest.label}`, 'Transport')) { this.removeVehicle(); this.ride = null; this.renderHud(); return; }
    r.phase = 'riding';
    if (T.moto) { pl.char.sit && pl.char.sit(true); pl.mesh.visible = true; }
    else pl.mesh.visible = false;
    if (this.audio && this.audio.ctx) this.audio.door();
    this.tpc.yaw = r.h + PI;
    this.ui.toast(`En route vers ${r.dest.label}. Espace (ou ⏩) pour passer le trajet.`, 3);
    this.renderHud();
  }
  skip() {
    const r = this.ride; if (!r || r.phase !== 'riding') return;
    const left = r.path.length - r.s;
    this.env.time = (this.env.time + Math.min(1, (left / (RIDES[r.type].speed * 0.85) + (r.stopsLeft || 0) * 3.5) * this.env.rate)) % 24; // au plus 1 h de jeu // temps de jeu écoulé pendant le trajet
    r.s = r.path.length; const p = sample(r.path, r.s); r.x = p.x; r.z = p.z; r.h = p.h; this.place(r);
    this.arrive();
  }
  arrive() {
    const r = this.ride, T = RIDES[r.type], pl = this.player;
    // descente côté trottoir (à droite de la voie)
    const rx = Math.cos(r.h), rz = -Math.sin(r.h);
    let placed = false;
    // côté du trottoir le plus proche de la destination (droite : −5,2 m ; gauche, de l'autre côté de la chaussée : +12,2 m)
    const kr = -5.2, kl = 12.2, d = r.dest;
    const side = Math.hypot(r.x + rx * kl - d.x, r.z + rz * kl - d.z) < Math.hypot(r.x + rx * kr - d.x, r.z + rz * kr - d.z) - 1 ? [kl, 11.2, kr, -4.2] : [kr, -4.2, -6.5, kl];
    for (const k of side) { const x = r.x + rx * k, z = r.z + rz * k; if (!this.world.collision.pointBlocked(x, 1, z)) { pl.pos.set(x, 0, z); placed = true; break; } }
    if (!placed) pl.pos.set(r.x, 0, r.z);
    pl.char.stand && pl.char.stand(); pl.mesh.visible = true; pl.mesh.position.copy(pl.pos); pl.mesh.rotation.set(0, r.h, 0);
    this.ui.toast(`Arrivé : ${r.dest.label}. ${T.moto ? 'Le zem' : T.label === 'Taxi' ? 'Le taxi' : 'Le tokpa-tokpa'} repart. Bonne journée !`, 3);
    if (this.audio && this.audio.ctx) this.audio.door();
    r.phase = 'leaving'; r.leave = 0; this.onSave && this.onSave(); this.renderHud();
  }

  update(dt) {
    const r = this.ride; if (!r) return;
    const T = RIDES[r.type];
    if (r.phase === 'coming') { r.t -= dt; if (r.t <= 0) this.spawn(); this.renderHud(); return; }
    if (r.phase === 'waiting') {
      r.wait -= dt;
      if (r.wait <= 0) { this.removeVehicle(); this.ride = null; this.ui.toast(`${T.label} : personne n’est venu, il est reparti (rien n’a été payé).`, 3); this.renderHud(); }
      return;
    }
    if (r.phase === 'leaving') {
      r.leave += dt; r.x += Math.sin(r.h) * 8 * dt; r.z += Math.cos(r.h) * 8 * dt; r.spin += 8 / r.wheelR * dt; this.place(r);
      if (r.leave > 5) { this.removeVehicle(); this.ride = null; this.renderHud(); }
      return;
    }
    // ---- en route ----
    const p = sample(r.path, r.s + 1.5, this._q), fx = Math.sin(p.h), fz = Math.cos(p.h);
    const q2 = sample(r.path, r.s + 9, {}), turn = Math.abs(Math.atan2(Math.sin(q2.h - p.h), Math.cos(q2.h - p.h)));
    let target = T.speed * (1 - Math.min(0.6, turn * 0.7));
    // circulation devant : on s'arrête (puis on la contourne après 2,5 s d'attente)
    if (!(r.ghost > 0)) {
      for (const o of this.traffic.obstacles()) {
        const dx = o.x - r.x, dz = o.z - r.z, ahead = dx * fx + dz * fz, side = Math.abs(dx * fz - dz * fx);
        if (ahead > 0.5 && ahead < 8 && side < 1.6 + o.r * 0.5) { target = 0; break; }
      }
    } else r.ghost -= dt;
    r.stuck = target === 0 && r.speed < 0.3 ? (r.stuck || 0) + dt : 0;
    if (r.stuck > 2.5) { r.ghost = 2; r.stuck = 0; }
    // arrêts du tokpa-tokpa
    if (r.stopsLeft > 0 && r.s >= r.nextStop) { r.pause = 3.5; r.stopsLeft--; r.nextStop += r.path.length / (T.stops + 1); if (this.audio && this.audio.ctx) this.audio.horn(r.x, r.z, 'car', true); this.ui.toast('Arrêt : des passagers descendent et montent…', 2); }
    if (r.pause > 0) { r.pause -= dt; target = 0; }
    // arrivée : freinage progressif
    const left = r.path.length - r.s;
    target = Math.min(target, Math.sqrt(2 * 3.5 * Math.max(0, left - 0.3)));
    r.speed = target < r.speed ? Math.max(target, r.speed - 7 * dt) : r.speed + Math.min(target - r.speed, 3 * dt);
    r.s += r.speed * dt;
    const c = sample(r.path, r.s, {});
    r.x = c.x; r.z = c.z;
    const dh = Math.atan2(Math.sin(c.h - r.h), Math.cos(c.h - r.h)); r.h += dh * (1 - Math.exp(-8 * dt));
    r.spin += r.speed / r.wheelR * dt;
    this.place(r);
    if (T.moto) r.mesh.rotation.z = Math.max(-0.3, Math.min(0.3, -dh * 3));
    // le joueur suit le véhicule
    const pl = this.player; pl.pos.set(r.x, 0, r.z);
    if (T.moto) { pl.mesh.position.set(r.x - Math.sin(r.h) * 0.6, -0.09, r.z - Math.cos(r.h) * 0.6); pl.mesh.rotation.set(0, r.h, r.mesh.rotation.z); }
    if (left < 0.4 && r.speed < 0.2) this.arrive();
  }
  camInfo() { const r = this.ride; return { heading: r.h, speed: r.speed, dist: RIDES[r.type].cam }; }
  handleRideKeys(input) { if (input.hit('Space')) this.skip(); }
  renderHud() {
    const r = this.ride, el = this.hud;
    el.classList.toggle('show', !!r && r.phase !== 'leaving');
    if (!r) return;
    const T = RIDES[r.type];
    const html = r.phase === 'coming' ? `${T.icon} ${T.label} → ${r.dest.label} • arrive dans ${Math.ceil(r.t)} s <button data-rd="cancel">Annuler</button>`
      : r.phase === 'waiting' ? `${T.icon} ${T.label} t’attend sur la route • E pour monter <button data-rd="cancel">Annuler</button>`
      : r.phase === 'riding' ? `${T.icon} En route vers ${r.dest.label} <button data-rd="skip">⏩ Passer le trajet</button>` : '';
    if (html !== this._hudHtml) { el.innerHTML = html; this._hudHtml = html; }
  }
}
