// Véhicules : voitures profilées (berline, minibus, pick-up), zémidjans et circulation automatique.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { createCharacter, SKINS } from './character.js';
import { clamp, damp, mulberry32 } from './util.js';
import { MAP, SEA_Z, BOUNDS } from './world.js';
import { landClamp } from './region-geo.js';

const PI = Math.PI;
const cache = {};
const S = (k, f) => cache[k] || (cache[k] = f());

export const glassMat = () => S('glass', () => new THREE.MeshStandardMaterial({ color: 0x0d151c, metalness: 0.2, roughness: 0.05, envMapIntensity: 1.6 }));
export const wheelMat = () => S('wheel', () => new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.6, metalness: 0.4 }));
const paintMats = new Map();
export function paintMat(hex) {
  // couleur de carrosserie dans les couleurs de sommet : un seul matériau partagé
  return S('paint', () => new THREE.MeshPhysicalMaterial({ vertexColors: true, metalness: 0.35, roughness: 0.35, clearcoat: 0.8, clearcoatRoughness: 0.15 }));
}
export const headMat = () => S('head', () => new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xfff2d0, emissiveIntensity: 0.2 }));

export function colorize(geo, hex) {
  const g = geo.index ? geo.toNonIndexed() : geo;
  const c = new THREE.Color(hex), n = g.attributes.position.count, a = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { a[i * 3] = c.r; a[i * 3 + 1] = c.g; a[i * 3 + 2] = c.b; }
  g.setAttribute('color', new THREE.BufferAttribute(a, 3));
  if (!g.attributes.uv) g.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(n * 2), 2));
  return g;
}

// Extrusion d'un profil latéral (z = longueur, y = hauteur) sur la largeur du véhicule
export function extrudeProfile(pts, width, bevel = 0.06) {
  const shape = new THREE.Shape(pts.map(([z, y]) => new THREE.Vector2(z, y)));
  const g = new THREE.ExtrudeGeometry(shape, { depth: width - bevel * 2, bevelEnabled: true, bevelThickness: bevel, bevelSize: bevel, bevelSegments: 3, curveSegments: 4 });
  g.rotateY(-PI / 2);
  g.translate((width - bevel * 2) / 2, 0, 0);
  g.computeVertexNormals();
  return g;
}

// lower = caisse (jusqu'à la ceinture de caisse), cabin = habitacle vitré, roof = pavillon peint [z centre, y, longueur]
const MODELS = {
  sedan: {
    len: 4.4, width: 1.76, wheelR: 0.34, wheelZ: [1.38, -1.32], wheelX: 0.78, mirrorY: 1.08,
    lower: [[-2.2, 0.32], [-2.24, 0.8], [-2.05, 0.98], [-1.15, 1.02], [1.08, 1.02], [2.0, 0.9], [2.24, 0.7], [2.2, 0.32]],
    cabin: [[-1.12, 1.0], [-0.7, 1.43], [0.42, 1.45], [1.06, 1.0]],
    roof: [-0.15, 1.46, 1.2], pillars: [-0.15],
  },
  minibus: {
    len: 5.0, width: 1.9, wheelR: 0.38, wheelZ: [1.75, -1.6], wheelX: 0.84, mirrorY: 1.5,
    lower: [[-2.5, 0.38], [-2.5, 1.32], [2.28, 1.32], [2.5, 1.05], [2.5, 0.38]],
    cabin: [[-2.46, 1.3], [-2.46, 1.98], [1.62, 1.98], [2.3, 1.3]],
    upper: [[-2.5, 1.95], [-2.5, 2.08], [-2.35, 2.2], [1.55, 2.2], [1.72, 1.95]],
    pillars: [-1.6, -0.6, 0.4],
  },
  citadine: {
    len: 3.75, width: 1.66, wheelR: 0.3, wheelZ: [1.2, -1.14], wheelX: 0.72, mirrorY: 1.06,
    lower: [[-1.85, 0.3], [-1.88, 0.98], [-1.62, 1.02], [0.9, 1.02], [1.68, 0.88], [1.88, 0.66], [1.85, 0.3]],
    cabin: [[-1.8, 1.0], [-1.6, 1.5], [0.12, 1.53], [0.88, 1.0]],
    roof: [-0.74, 1.54, 1.72], pillars: [-0.55],
  },
  // mission 015 : bus, camion, camionnette de livraison
  bus: {
    len: 10.0, width: 2.45, wheelR: 0.5, wheelZ: [3.4, -3.1], wheelX: 1.05, mirrorY: 2.2,
    lower: [[-5.0, 0.45], [-5.0, 1.42], [4.85, 1.42], [5.0, 1.2], [5.0, 0.45]],
    cabin: [[-4.95, 1.4], [-4.95, 2.55], [4.75, 2.55], [4.95, 1.4]],
    upper: [[-5.0, 2.5], [-5.0, 2.95], [4.8, 2.95], [5.0, 2.5]],
    pillars: [-3.2, -1.2, 0.8, 2.8],
  },
  truck: {
    len: 7.0, width: 2.35, wheelR: 0.5, wheelZ: [2.6, -2.3], wheelX: 1.0, mirrorY: 2.0,
    lower: [[-3.5, 0.5], [-3.5, 1.25], [3.5, 1.25], [3.5, 0.5]],
    cabin: [[1.7, 1.22], [1.75, 2.45], [3.1, 2.45], [3.45, 1.22]],
    upper: [[-3.5, 1.22], [-3.5, 3.1], [1.55, 3.1], [1.55, 1.22]],
    pillars: [],
  },
  van: {
    len: 5.0, width: 1.92, wheelR: 0.36, wheelZ: [1.7, -1.6], wheelX: 0.84, mirrorY: 1.45,
    lower: [[-2.5, 0.38], [-2.5, 1.2], [1.6, 1.2], [2.4, 0.95], [2.5, 0.4]],
    cabin: [[0.4, 1.18], [0.45, 2.05], [0.95, 2.05], [1.62, 1.18]],
    upper: [[-2.5, 1.18], [-2.5, 2.12], [0.5, 2.12], [0.5, 1.18]],
    pillars: [],
  },
  pickup: {
    len: 5.0, width: 1.82, wheelR: 0.38, wheelZ: [1.6, -1.5], wheelX: 0.8, mirrorY: 1.2,
    lower: [[-2.5, 0.42], [-2.5, 1.05], [-0.64, 1.05], [-0.64, 1.12], [1.15, 1.12], [2.3, 0.98], [2.5, 0.7], [2.45, 0.42]],
    cabin: [[-0.62, 1.1], [-0.6, 1.76], [0.55, 1.79], [1.13, 1.1]],
    roof: [-0.02, 1.8, 1.2], pillars: [],
  },
};

function bodyGeometry(model, hex) {
  const M = MODELS[model];
  const parts = [];
  parts.push(colorize(extrudeProfile(M.lower, M.width), hex));
  if (M.upper) parts.push(colorize(extrudeProfile(M.upper, M.width), hex));
  const black = 0x1a1a1a, chrome = 0xc8ccd0, L = M.len / 2;
  const box = (w, h, d, x, y, z, c) => parts.push(colorize(new THREE.BoxGeometry(w, h, d).translate(x, y, z), c));
  if (M.roof) box(M.width - 0.12, 0.06, M.roof[2], 0, M.roof[1], M.roof[0], hex);
  for (const z of M.pillars) for (const sx of [-1, 1]) box(0.04, (M.upper ? 0.66 : 0.42), 0.12, sx * (M.width / 2 - 0.06), M.upper ? 1.64 : 1.22, z, model === 'minibus' ? hex : black);
  box(M.width + 0.04, 0.22, 0.22, 0, 0.42, L + 0.02, black);         // pare-chocs avant
  box(M.width + 0.04, 0.22, 0.22, 0, 0.42, -L - 0.02, black);        // pare-chocs arrière
  box(M.width - 0.2, 0.18, M.len - 0.6, 0, 0.3, 0, 0x111111);         // bas de caisse
  box(0.8, 0.16, 0.04, 0, 0.62, L + 0.05, 0x202020);                  // calandre
  for (const s of [-1, 1]) {
    box(0.34, 0.13, 0.05, s * (M.width / 2 - 0.3), 0.74, L + 0.03, 0xfffbea); // phares
    box(0.32, 0.16, 0.05, s * (M.width / 2 - 0.28), 0.82, -L - 0.03, 0xc01818); // feux arrière
    box(0.06, 0.1, 0.18, s * (M.width / 2 + 0.06), M.mirrorY, M.cabin[3][0] - 0.15, black); // rétroviseurs
    box(0.03, 0.04, 0.25, s * (M.width / 2 + 0.01), model === 'minibus' ? 1.1 : 0.85, 0.2, chrome); // poignées
  }
  if (model === 'minibus') {
    box(M.width - 0.2, 0.08, 2.6, 0, 2.26, -0.6, 0x2a2a2a);  // galerie de toit
    for (let k = 0; k < 4; k++) box(0.35 + (k % 2) * 0.2, 0.3, 0.4, -0.4 + k * 0.3, 2.44, -1.4 + k * 0.6, [0x1f4e9c, 0xc8102e, 0x6a4a2a, 0xe0b020][k]); // bagages
  }
  if (model === 'pickup') {
    for (const s of [-1, 1]) box(0.06, 0.4, 1.8, s * (M.width / 2 - 0.05), 1.25, -1.55, hex); // ridelles
    box(M.width, 0.4, 0.06, 0, 1.25, -2.45, hex);
  }
  return mergeGeometries(parts);
}

export function wheelGeometry(r) {
  const tyre = colorize(new THREE.CylinderGeometry(r, r, 0.24, 18).rotateZ(PI / 2), 0x141414);
  const rim = colorize(new THREE.CylinderGeometry(r * 0.62, r * 0.62, 0.26, 12).rotateZ(PI / 2), 0xb8bcc0);
  const hub = colorize(new THREE.CylinderGeometry(r * 0.2, r * 0.2, 0.28, 8).rotateZ(PI / 2), 0x555555);
  return mergeGeometries([tyre, rim, hub]);
}

export function createCarMesh(color, model = 'sedan') {
  const Mo = MODELS[model];
  const g = new THREE.Group();
  const body = new THREE.Mesh(bodyGeometry(model, color), paintMat());
  body.castShadow = true; body.receiveShadow = true;
  g.add(body);
  const glass = new THREE.Mesh(S('glassGeo' + model, () => extrudeProfile(Mo.cabin, Mo.width - 0.1, 0.04)), glassMat());
  g.add(glass);
  const wg = S('wheel' + Mo.wheelR, () => wheelGeometry(Mo.wheelR));
  const wheels = [];
  for (const z of Mo.wheelZ) for (const s of [1, -1]) {
    const pivot = new THREE.Group(); pivot.position.set(s * Mo.wheelX, Mo.wheelR, z); g.add(pivot);
    const spin = new THREE.Mesh(wg, wheelMat()); spin.castShadow = true; pivot.add(spin);
    wheels.push({ pivot, spin });
  }
  return { group: g, wheels, model };
}

// ---------------- Zémidjan (moto-taxi) ----------------
function motoGeometry(hex) {
  const parts = [];
  const add = (geo, c) => parts.push(colorize(geo, c));
  const black = 0x161616, chrome = 0xc0c4c8;
  add(new THREE.BoxGeometry(0.16, 0.34, 0.9).translate(0, 0.55, 0.0), 0x2a2a2a);                       // cadre
  add(new THREE.SphereGeometry(0.2, 12, 8).scale(0.85, 0.55, 1.3).translate(0, 0.86, 0.3), hex);        // réservoir
  add(new THREE.BoxGeometry(0.28, 0.24, 0.5).translate(0, 0.64, -0.18), hex);                           // carénages latéraux
  add(new THREE.BoxGeometry(0.28, 0.1, 0.78).translate(0, 0.86, -0.28), black);                        // selle
  add(new THREE.BoxGeometry(0.22, 0.05, 0.4).translate(0, 0.8, -0.78), black);                         // porte-bagages
  add(new THREE.CylinderGeometry(0.035, 0.035, 0.85, 6).rotateX(-0.38).translate(0, 0.72, 0.6), chrome); // fourche
  add(new THREE.CylinderGeometry(0.018, 0.018, 0.72, 6).rotateZ(PI / 2).translate(0, 1.06, 0.48), black); // guidon
  add(new THREE.SphereGeometry(0.09, 10, 8).scale(1, 0.9, 0.6).translate(0, 0.96, 0.7), 0xfff6dd);      // phare
  add(new THREE.BoxGeometry(0.26, 0.04, 0.42).translate(0, 0.66, 0.68), hex);                           // garde-boue avant
  add(new THREE.BoxGeometry(0.24, 0.04, 0.36).translate(0, 0.72, -0.72), hex);                          // garde-boue arrière
  add(new THREE.CylinderGeometry(0.04, 0.05, 0.7, 8).rotateX(PI / 2 - 0.15).translate(0.16, 0.38, -0.4), chrome); // pot d'échappement
  add(new THREE.BoxGeometry(0.2, 0.18, 0.28).translate(0, 0.4, 0.05), 0x333333);                        // moteur
  return mergeGeometries(parts);
}
function motoWheel() {
  const tyre = colorize(new THREE.TorusGeometry(0.29, 0.07, 8, 18).rotateY(PI / 2), 0x141414);
  const rim = colorize(new THREE.CylinderGeometry(0.22, 0.22, 0.04, 14).rotateZ(PI / 2), 0x9a9ea2);
  return mergeGeometries([tyre, rim]);
}

export function createMotoMesh(seed, opts = {}) {
  const R = mulberry32(seed);
  const g = new THREE.Group();
  const colors = [0x1a1a1a, 0xc8102e, 0x1f4e9c, 0xdddddd, 0x6a2a8a, 0x1f7a4a];
  const pick = colors[Math.floor(R() * colors.length)];
  const body = new THREE.Mesh(motoGeometry(opts.color ?? pick), paintMat());
  body.castShadow = true;
  g.add(body);
  const wg = S('motoWheel', motoWheel);
  const wheels = [];
  for (const z of [0.68, -0.62]) {
    const w = new THREE.Mesh(wg, wheelMat()); w.position.set(0, 0.36, z); w.castShadow = true; g.add(w); wheels.push(w);
  }
  if (opts.rider === false) return { group: g, wheels };
  // conducteur zémidjan : chemise jaune réglementaire
  const rider = createCharacter({ shirtColor: 0xf2c200, skin: SKINS[Math.floor(R() * SKINS.length)], pants: [0x2a2a3a, 0x3a3a2a, 0x1f2f4a][Math.floor(R() * 3)] });
  rider.sit(true);
  rider.group.position.set(0, -0.11, -0.1);
  g.add(rider.group);
  if (opts.passenger !== false && R() < 0.55) {
    const female = R() < 0.5;
    const pass = createCharacter({ pagne: Math.floor(R() * 6), skin: SKINS[Math.floor(R() * SKINS.length)], female });
    pass.sit(true);
    pass.group.position.set(0, -0.09, -0.6);
    g.add(pass.group);
  }
  return { group: g, wheels };
}

// ---------------- Voiture conduisible ----------------
export class DrivableCar {
  constructor(scene, { x, z, h, color, model = 'sedan' }) {
    const m = createCarMesh(color, model);
    this.mesh = m.group;
    this.wheels = m.wheels;
    this.model = MODELS[model];
    this.pos = new THREE.Vector3(x, 0, z);
    this.heading = h;
    this.speed = 0;
    this.steer = 0;
    this.occupied = false;
    this.wheelSpin = 0;
    this.headlight = null;
    this.pitch = 0;
    scene.add(this.mesh);
    this.sync();
  }

  enableHeadlight() {
    if (this.headlight) return;
    const l = new THREE.SpotLight(0xfff2d0, 0, 50, 0.55, 0.5, 1.2);
    l.position.set(0, 0.8, 2.2);
    l.target.position.set(0, 0, 14);
    this.mesh.add(l); this.mesh.add(l.target);
    this.headlight = l;
  }

  get forward() { return { x: Math.sin(this.heading), z: Math.cos(this.heading) }; }

  circles() {
    const f = this.forward;
    return [
      { x: this.pos.x + f.x * 1.25, z: this.pos.z + f.z * 1.25, r: 1.0 },
      { x: this.pos.x - f.x * 1.25, z: this.pos.z - f.z * 1.25, r: 1.0 },
    ];
  }

  update(dt, input, world, obstacles) {
    let accel = 0;
    const prev = this.speed;
    if (this.occupied) {
      const thr = (input.down('KeyW') || input.down('ArrowUp') ? 1 : 0) - (input.down('KeyS') || input.down('ArrowDown') ? 1 : 0);
      const st = (input.down('KeyA') || input.down('ArrowLeft') ? 1 : 0) - (input.down('KeyD') || input.down('ArrowRight') ? 1 : 0);
      const hb = input.down('Space');
      const MAX = 30, REV = 8;
      if (thr > 0) {
        if (this.speed < -0.3) this.speed += 20 * dt;
        else this.speed += 10 * (1 - this.speed / MAX) * dt;
      } else if (thr < 0) {
        if (this.speed > 0.3) this.speed -= 22 * dt;
        else this.speed -= 6 * (1 + this.speed / REV) * dt;
      } else {
        this.speed -= Math.sign(this.speed) * Math.min(Math.abs(this.speed), (2 + Math.abs(this.speed) * 0.05) * dt);
      }
      if (hb) this.speed -= Math.sign(this.speed) * Math.min(Math.abs(this.speed), 16 * dt);
      const maxSteer = 0.6 / (1 + Math.abs(this.speed) * 0.07);
      this.steer = damp(this.steer, st * maxSteer, 10, dt);
    } else {
      this.speed = damp(this.speed, 0, 3, dt);
      this.steer = damp(this.steer, 0, 5, dt);
    }
    const L = 2.7;
    this.heading += (this.speed / L) * Math.tan(this.steer) * dt * (input && input.down('Space') && this.occupied ? 1.25 : 1);
    const f = this.forward;
    this.pos.x += f.x * this.speed * dt;
    this.pos.z += f.z * this.speed * dt;

    let impact = 0;
    for (const off of [1.25, -1.25]) {
      const c = { x: this.pos.x + f.x * off, z: this.pos.z + f.z * off };
      const n = world.collision.resolve(c, 1.0, obstacles);
      if (n) {
        const dx = c.x - (this.pos.x + f.x * off), dz = c.z - (this.pos.z + f.z * off);
        this.pos.x += dx; this.pos.z += dz;
        const vn = (f.x * n.x + f.z * n.z) * Math.sign(this.speed);
        if (vn < -0.2) impact = Math.max(impact, Math.abs(this.speed));
        this.speed *= vn < -0.5 ? -0.25 : 0.96;
      }
    }
    landClamp(this, 3);
    if (dt > 0) accel = (this.speed - prev) / dt;
    // tangage (freinage / accélération) amorti
    this.pitch = damp(this.pitch, clamp(-accel * 0.004, -0.04, 0.04), 6, dt);
    this.sync(dt);
    return impact;
  }

  sync(dt = 0) {
    this.mesh.position.copy(this.pos);
    this.mesh.rotation.set(this.pitch, this.heading, -this.steer * Math.min(1, Math.abs(this.speed) / 20) * 0.08, 'YXZ');
    this.wheelSpin += (this.speed / this.model.wheelR) * dt;
    for (let i = 0; i < 4; i++) {
      this.wheels[i].spin.rotation.x = this.wheelSpin;
      if (i < 2) this.wheels[i].pivot.rotation.y = this.steer;
    }
  }
}

// ---------------- Moto conduisible ----------------
export class DrivableMoto {
  constructor(scene, { x, z, h, color = 0xc8102e }) {
    this.isMoto = true;
    this.model = { wheelR: 0.36 };
    this.mesh = new THREE.Group();
    this.lean = new THREE.Group();          // l'inclinaison s'applique au châssis et au pilote
    this.mesh.add(this.lean);
    const m = createMotoMesh(77, { rider: false, color });
    this.lean.add(m.group);
    this.wheels = m.wheels;
    this.riderKind = null;
    this.setRider('male');
    this.pos = new THREE.Vector3(x, 0, z);
    this.heading = h; this.speed = 0; this.steer = 0; this.leanAngle = 0.12;
    this.occupied = false; this.wheelSpin = 0; this.headlight = null;
    scene.add(this.mesh);
    this.sync();
  }
  setRider(kind) {
    if (kind === this.riderKind) return;
    if (this.rider) this.lean.remove(this.rider.group);
    this.riderKind = kind;
    this.rider = kind === 'female' ? createCharacter({ female: true, pagne: 2, skin: 0x5a3a26 }) : createCharacter({ pagne: 0, skin: 0x4e3122, pants: 0x2b3442 });
    this.rider.sit(true);
    this.rider.group.position.set(0, -0.11, -0.1);
    this.rider.group.visible = this.occupied;
    this.lean.add(this.rider.group);
  }
  enableHeadlight() {
    if (this.headlight) return;
    const l = new THREE.SpotLight(0xfff2d0, 0, 40, 0.5, 0.5, 1.2);
    l.position.set(0, 1.0, 0.75); l.target.position.set(0, 0, 12);
    this.mesh.add(l); this.mesh.add(l.target);
    this.headlight = l;
  }
  get forward() { return { x: Math.sin(this.heading), z: Math.cos(this.heading) }; }
  circles() {
    const f = this.forward;
    return [{ x: this.pos.x + f.x * 0.55, z: this.pos.z + f.z * 0.55, r: 0.45 }, { x: this.pos.x - f.x * 0.55, z: this.pos.z - f.z * 0.55, r: 0.45 }];
  }
  update(dt, input, world, obstacles) {
    if (this.rider) this.rider.group.visible = this.occupied;
    if (this.occupied) {
      const thr = (input.down('KeyW') || input.down('ArrowUp') ? 1 : 0) - (input.down('KeyS') || input.down('ArrowDown') ? 1 : 0);
      const st = (input.down('KeyA') || input.down('ArrowLeft') ? 1 : 0) - (input.down('KeyD') || input.down('ArrowRight') ? 1 : 0);
      const MAX = 21;
      if (thr > 0) { if (this.speed < -0.2) this.speed += 14 * dt; else this.speed += 8 * (1 - this.speed / MAX) * dt; }
      else if (thr < 0) { if (this.speed > 0.2) this.speed -= 18 * dt; else this.speed = Math.max(-1.6, this.speed - 3 * dt); } // on pousse la moto en arrière
      else this.speed -= Math.sign(this.speed) * Math.min(Math.abs(this.speed), (1.5 + Math.abs(this.speed) * 0.06) * dt);
      if (input.down('Space')) this.speed -= Math.sign(this.speed) * Math.min(Math.abs(this.speed), 14 * dt);
      this.steer = damp(this.steer, st * 0.55 / (1 + Math.abs(this.speed) * 0.12), 8, dt);
    } else { this.speed = damp(this.speed, 0, 4, dt); this.steer = damp(this.steer, 0, 5, dt); }
    this.heading += (this.speed / 1.35) * Math.tan(this.steer) * dt;
    const f = this.forward;
    this.pos.x += f.x * this.speed * dt; this.pos.z += f.z * this.speed * dt;
    let impact = 0;
    for (const off of [0.55, -0.55]) {
      const c = { x: this.pos.x + f.x * off, z: this.pos.z + f.z * off };
      const n = world.collision.resolve(c, 0.45, obstacles);
      if (n) {
        this.pos.x += c.x - (this.pos.x + f.x * off); this.pos.z += c.z - (this.pos.z + f.z * off);
        const vn = (f.x * n.x + f.z * n.z) * Math.sign(this.speed);
        if (vn < -0.2) impact = Math.max(impact, Math.abs(this.speed));
        this.speed *= vn < -0.5 ? -0.2 : 0.95;
      }
    }
    landClamp(this, 3);
    // inclinaison dans les virages ; béquille latérale quand la moto est garée
    const wantLean = this.occupied || Math.abs(this.speed) > 0.5 ? -this.steer * clamp(Math.abs(this.speed) / 7, 0, 1) * 1.1 : 0.12;
    this.leanAngle = damp(this.leanAngle, wantLean, 6, dt);
    this.sync(dt);
    return impact;
  }
  sync(dt = 0) {
    this.mesh.position.copy(this.pos);
    this.mesh.rotation.y = this.heading;
    this.lean.rotation.z = this.leanAngle;
    this.wheelSpin += (this.speed / 0.36) * dt;
    for (const w of this.wheels) w.rotation.x = this.wheelSpin;
    this.wheels[0].rotation.y = this.steer; // roue avant braquée
  }
}

// ---------------- Véhicule GLB (ex. carrosserie générée par Tripo) ----------------
// La carrosserie est mise à l'échelle sur la longueur réelle et orientée vers +Z ;
// les roues du jeu (qui tournent et braquent) sont ajoutées aux emplacements du modèle choisi.
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
export function loadGLBVehicleBody(url, { model = 'sedan', length = null, rotateY = 0 } = {}) {
  const Mo = MODELS[model];
  return new Promise((resolve, reject) => new GLTFLoader().load(url, (gltf) => {
    const body = gltf.scene;
    body.rotation.y = rotateY;
    body.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
    body.updateMatrixWorld(true);
    let box = new THREE.Box3().setFromObject(body);
    const size = box.getSize(new THREE.Vector3());
    const L = length || Mo.len;
    body.scale.multiplyScalar(L / Math.max(size.x, size.z)); // la plus grande dimension horizontale = longueur
    body.updateMatrixWorld(true);
    box = new THREE.Box3().setFromObject(body);
    const c = box.getCenter(new THREE.Vector3());
    body.position.x -= c.x; body.position.z -= c.z; body.position.y -= box.min.y;
    let tris = 0; body.traverse((o) => { if (o.isMesh) tris += (o.geometry.index ? o.geometry.index.count : o.geometry.attributes.position.count) / 3; });
    resolve({ body, report: { model, length: L, triangles: Math.round(tris), size: size.toArray().map((v) => +v.toFixed(2)) } });
  }, undefined, reject));
}

// Remplace la carrosserie procédurale d'une voiture conduisible par une carrosserie GLB (roues conservées)
DrivableCar.prototype.setGLBBody = function (body) {
  for (const ch of [...this.mesh.children]) if (ch.isMesh) this.mesh.remove(ch);
  this.mesh.add(body);
};

// ---------------- Circulation automatique ----------------
// Arrondit les angles d'un circuit (rayon r) puis lisse avec une courbe Catmull-Rom.
function filletLoop(pts, r) {
  const out = [], n = pts.length;
  for (let i = 0; i < n; i++) {
    const p = pts[(i - 1 + n) % n], c = pts[i], q = pts[(i + 1) % n];
    const ux = p[0] - c[0], uz = p[1] - c[1], vx = q[0] - c[0], vz = q[1] - c[1];
    const lu = Math.hypot(ux, uz), lv = Math.hypot(vx, vz);
    const cos = (ux * vx + uz * vz) / (lu * lv);
    if (cos > -0.85 && lu > 2.2 * r && lv > 2.2 * r) {
      const a = [ux / lu, uz / lu], b = [vx / lv, vz / lv];
      out.push([c[0] + a[0] * r, c[1] + a[1] * r]);
      out.push([c[0] + (a[0] + b[0]) * r * 0.293, c[1] + (a[1] + b[1]) * r * 0.293]);
      out.push([c[0] + b[0] * r, c[1] + b[1] * r]);
    } else out.push(c);
  }
  return out;
}
function laneLoop(pts, off) {
  const n = pts.length, out = [];
  const right = (a, b) => { const dx = b[0] - a[0], dz = b[1] - a[1], l = Math.hypot(dx, dz); return [-dz / l, dx / l]; };
  for (let i = 0; i < n; i++) {
    const p = pts[(i - 1 + n) % n], c = pts[i], nx = pts[(i + 1) % n];
    const r1 = right(p, c), r2 = right(c, nx);
    let mx = r1[0] + r2[0], mz = r1[1] + r2[1];
    const ml = Math.hypot(mx, mz) || 1; mx /= ml; mz /= ml;
    const k = off / Math.max(0.3, mx * r1[0] + mz * r1[1]);
    out.push([c[0] + mx * k, c[1] + mz * k]);
  }
  return out;
}
function ring(a0, a1, r = 16.5, step = 0.18) {
  const out = [];
  const n = Math.ceil(Math.abs(a1 - a0) / step);
  for (let i = 0; i <= n; i++) { const a = a0 + (a1 - a0) * (i / n); out.push([Math.cos(a) * r, Math.sin(a) * r]); }
  return out;
}

class Route {
  constructor(keypts) {
    // densification : sans points intermédiaires, la courbe lissée bombe les longues lignes droites
    const dense = [];
    for (let i = 0; i < keypts.length; i++) {
      const a = keypts[i], b = keypts[(i + 1) % keypts.length];
      const L = Math.hypot(b[0] - a[0], b[1] - a[1]), n = Math.max(1, Math.floor(L / 6));
      for (let k = 0; k < n; k++) dense.push([a[0] + (b[0] - a[0]) * k / n, a[1] + (b[1] - a[1]) * k / n]);
    }
    const curve = new THREE.CatmullRomCurve3(dense.map(([x, z]) => new THREE.Vector3(x, 0, z)), true, 'centripetal');
    const len = curve.getLength();
    const pts = curve.getSpacedPoints(Math.ceil(len / 1.5)).map((v) => [v.x, v.z]);
    pts.pop();
    this.pts = pts;
    this.cum = [0];
    for (let i = 0; i < pts.length; i++) {
      const a = pts[i], b = pts[(i + 1) % pts.length];
      this.cum.push(this.cum[i] + Math.hypot(b[0] - a[0], b[1] - a[1]));
    }
    this.length = this.cum[pts.length];
    this.step = this.length / pts.length;
  }
  sample(s, out) {
    s = ((s % this.length) + this.length) % this.length;
    let i = Math.min(this.pts.length - 1, Math.floor(s / this.step));
    while (i > 0 && this.cum[i] > s) i--;
    while (this.cum[i + 1] < s) i++;
    const a = this.pts[i], b = this.pts[(i + 1) % this.pts.length];
    const t = (s - this.cum[i]) / (this.cum[i + 1] - this.cum[i] || 1);
    out.x = a[0] + (b[0] - a[0]) * t;
    out.z = a[1] + (b[1] - a[1]) * t;
    out.h = Math.atan2(b[0] - a[0], b[1] - a[1]);
    return out;
  }
}

export class Traffic {
  constructor(scene, lights = null) {
    const R = mulberry32(229);
    this.lights = lights;
    this.nearCount = 0;
    const rect = (pts, rev = false) => { const p = rev ? [...pts].reverse() : pts; return new Route(filletLoop(laneLoop(p, 3.5), 7)); };
    const big = [[-100, -100], [100, -100], [100, 100], [-100, 100]];
    const beach = [[-100, 100], [100, 100], [100, 152], [-100, 152]];
    const outer = [[-100, -100], [100, -100], [100, 152], [-100, 152]];
    const A = rect(big), A2 = rect(big, true), B = rect(beach), B2 = rect(beach, true), C = rect(outer), C2 = rect(outer, true);
    // boucles passant par le rond-point (sens anti-horaire, îlot à gauche)
    const RB1 = new Route([
      [-3.5, -92], [-3.5, -32], ...ring(-PI / 2 - 0.62, -2 * PI + 0.62), [32, 3.5], [96, 3.5], [101.3, 1.3], [103.5, -4],
      [103.5, -96], [101.3, -101.3], [96, -103.5], [4, -103.5], [-1.3, -101.3],
    ]);
    const RB2 = new Route([
      [-32, 3.5], ...ring(-PI - 0.62, -1.5 * PI + 0.62), [-3.5, 32], [-3.5, 89], [-5.7, 94.3], [-11, 96.5], [-89, 96.5],
      [-94.3, 94.3], [-96.5, 89], [-96.5, 11], [-94.3, 5.7], [-89, 3.5],
    ]);
    this.routes = [A, A2, B, B2, C, C2, RB1, RB2];
    this.buildTransfers();
    this.vehicles = [];
    const carColors = [0xf2f2f2, 0x9aa0a6, 0x1a1a1a, 0x7a1010, 0x1f3e7c, 0xf2c200, 0x2e6b3a, 0xe8e2d0];
    const spawn = (route, count, motoRatio) => {
      for (let i = 0; i < count; i++) {
        const moto = R() < motoRatio;
        let m, kind = 'moto';
        if (moto) m = createMotoMesh(1000 + this.vehicles.length);
        else {
          const k = R();
          kind = k < 0.4 ? 'sedan' : k < 0.62 ? 'citadine' : k < 0.82 ? 'minibus' : 'pickup';
          const col = kind === 'minibus' ? [0xf2f2f2, 0xf2c200, 0x2e6b9a][Math.floor(R() * 3)] : carColors[Math.floor(R() * carColors.length)];
          m = createCarMesh(col, kind);
        }
        scene.add(m.group);
        this.vehicles.push({
          route, moto, kind, mesh: m.group, wheels: m.wheels,
          wheelR: moto ? 0.36 : MODELS[kind].wheelR, half: moto ? 1.0 : MODELS[kind].len / 2,
          s: (route.length * i) / count + R() * 4, lastIdx: -1, cooldown: 0, rnd: R,
          speed: 0, max: moto ? 11 + R() * 2.5 : kind === 'minibus' ? 10 : 12, h: 0, x: 0, z: 0, spin: 0, fx: 0, fz: 1, wait: 0,
        });
      }
    };
    spawn(A, 6, 0.55); spawn(A2, 5, 0.55); spawn(B, 4, 0.5); spawn(B2, 3, 0.5);
    spawn(C, 3, 0.5); spawn(C2, 3, 0.5); spawn(RB1, 6, 0.5); spawn(RB2, 6, 0.5);
    // mission 015 : taxis, bus, camions, camionnettes (activés selon l'heure et la densité choisie)
    const special = (route, kind, color, extra = {}) => {
      const m = createCarMesh(color, kind);
      if (extra.sign) m.group.add(roofSign(extra.sign, kind));
      scene.add(m.group);
      this.vehicles.push({
        route, moto: false, kind, mesh: m.group, wheels: m.wheels, wheelR: MODELS[kind].wheelR, half: MODELS[kind].len / 2,
        s: R() * route.length, lastIdx: -1, cooldown: 0, rnd: R, speed: 0, max: extra.max || 11, h: 0, x: 0, z: 0, spin: 0, fx: 0, fz: 1, wait: 0, role: extra.role || kind,
      });
    };
    for (const r of [A, C2, RB1, B]) special(r, 'sedan', 0xf2c200, { sign: 'TAXI', role: 'taxi', max: 12.5 });
    for (const r of [C, RB2]) special(r, 'citadine', 0xf2c200, { sign: 'TAXI', role: 'taxi', max: 12 });
    for (const r of [A, C, RB2]) special(r, 'bus', [0x1f6aa8, 0x0b6e4f, 0xc8102e][this.vehicles.length % 3], { sign: 'BUS', role: 'bus', max: 9 });
    for (const r of [A, C2, B2]) special(r, 'truck', [0xe8e2d6, 0x2a5a8a, 0xb84a2a][this.vehicles.length % 3], { role: 'truck', max: 8.5 });
    for (const r of [A2, C, RB2, B]) special(r, 'van', [0xf2f2f2, 0xd8d0c0, 0x2e6b3a, 0xe46a1f][this.vehicles.length % 4], { role: 'van', max: 10.5 });
    for (const v of this.vehicles) { v.active = true; v.role = v.role || (v.moto ? 'zem' : v.kind === 'minibus' ? 'tokpa' : 'car'); }
    this.stops = []; this.horns = []; this.rush = 0; this.jam = 0;
    this._p = { x: 0, z: 0, h: 0 };
    for (const v of this.vehicles) { const q = v.route.sample(v.s, this._p); v.x = q.x; v.z = q.z; v.h = q.h; v.lastIdx = Math.floor(v.s / v.route.step); }
    this.inters = [];
    for (const X of [-100, 0, 100]) for (const Z of [-100, 0, 100, 152]) if (!(X === 0 && Z === 0)) this.inters.push({ x: X, z: Z, occ: [] });
    if (lights) for (const it of this.inters) it.light = lights.list.find((l) => l.x === it.x && l.z === it.z) || null;
  }

  // points où deux itinéraires partagent la même voie, dans le même sens : un véhicule peut y changer d'itinéraire
  buildTransfers() {
    for (const r of this.routes) r.transfers = new Map();
    const cell = (x, z) => Math.floor(x / 4) * 1000 + Math.floor(z / 4);
    const grid = new Map();
    this.routes.forEach((r, ri) => r.pts.forEach((p, i) => {
      const k = cell(p[0], p[1]); if (!grid.has(k)) grid.set(k, []); grid.get(k).push([ri, i]);
    }));
    const hd = (r, i) => { const a = r.pts[i], b = r.pts[(i + 1) % r.pts.length]; return Math.atan2(b[0] - a[0], b[1] - a[1]); };
    this.routes.forEach((r, ri) => r.pts.forEach((p, i) => {
      if (i % 4) return; // un point de transfert tous les ~6 m suffit
      const h = hd(r, i);
      for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) {
        const list = grid.get(cell(p[0] + dx * 4, p[1] + dz * 4)); if (!list) continue;
        for (const [rj, j] of list) {
          if (rj === ri) continue;
          const q = this.routes[rj].pts[j];
          if (Math.hypot(q[0] - p[0], q[1] - p[1]) > 0.6) continue;
          const dh = Math.abs(Math.atan2(Math.sin(hd(this.routes[rj], j) - h), Math.cos(hd(this.routes[rj], j) - h)));
          if (dh > 0.12) continue;
          if (!r.transfers.has(i)) r.transfers.set(i, []);
          r.transfers.get(i).push([rj, this.routes[rj].cum[j]]);
        }
      }
    }));
  }

  obstacles() {
    const out = [];
    for (const v of this.vehicles) if (v.active) { out.push({ x: v.x, z: v.z, r: v.moto ? 0.6 : 1.3 }); if (v.half > 3) { out.push({ x: v.x + v.fx * v.half * 0.6, z: v.z + v.fz * v.half * 0.6, r: 1.3 }, { x: v.x - v.fx * v.half * 0.6, z: v.z - v.fz * v.half * 0.6, r: 1.3 }); } }
    return out;
  }
  // mission 015 : nombre de véhicules en circulation (selon l'heure et la densité). Les véhicules retirés
  // sont choisis loin du joueur ; ceux qui reviennent apparaissent hors de sa vue, sur une portion libre de leur route.
  setDensity(target, focus) {
    const V = this.vehicles, act = V.filter((v) => v.active), fx = focus ? focus.x : 0, fz = focus ? focus.z : 0;
    const d2 = (v) => (v.x - fx) ** 2 + (v.z - fz) ** 2;
    if (act.length > target) {
      const cand = act.filter((v) => d2(v) > 85 * 85).sort((a, b) => d2(b) - d2(a));
      for (const v of cand.slice(0, act.length - target)) { v.active = false; v.mesh.visible = false; v.speed = 0; }
    } else if (act.length < target) {
      const idle = V.filter((v) => !v.active);
      for (const v of idle.slice(0, target - act.length)) {
        for (let k = 0; k < 12; k++) {
          const s0 = v.rnd() * v.route.length, q = v.route.sample(s0, this._p);
          if ((q.x - fx) ** 2 + (q.z - fz) ** 2 < 90 * 90) continue;
          if (V.some((o) => o.active && (o.x - q.x) ** 2 + (o.z - q.z) ** 2 < 16 * 16)) continue;
          v.s = s0; v.x = q.x; v.z = q.z; v.h = q.h; v.speed = 0; v.active = true; v.lastIdx = Math.floor(s0 / v.route.step); break;
        }
      }
    }
  }

  // mission 015 : ralentissements aux heures de pointe autour du marché Dantokpa et sur les grands axes
  congestion(x, z) {
    if (!this.rush) return 1;
    const market = x > -108 && x < 8 && z > -8 && z < 108 ? 1 : 0;
    const axis = Math.abs(x) < 8 || Math.abs(z) < 8 ? 0.5 : 0;
    return 1 - this.rush * (market * 0.45 + axis * 0.3);
  }
  // vitesse adaptée à la rue : boulevards goudronnés, rues pavées plus lentes, rond-point
  roadFactor(x, z) {
    const r = Math.hypot(x, z);
    if (r < 24) return 0.62;
    if (Math.abs(Math.abs(x) - 100) < 8 && z < 145) return 0.75; // rues pavées
    if (Math.abs(z - 152) < 8) return 0.9;
    return 1;
  }

  update(dt, blockers, focus) {
    const V = this.vehicles;
    // occupation des carrefours
    for (const it of this.inters) {
      it.occ.length = 0;
      for (const v of V) if (v.active && Math.abs(v.x - it.x) < 7.5 && Math.abs(v.z - it.z) < 7.5) it.occ.push(v);
    }
    const ringCars = V.filter((v) => { const r = Math.hypot(v.x, v.z); return v.active && r > 11 && r < 21; });
    let jam = 0;
    for (const v of V) {
      if (!v.active) { v.mesh.visible = false; continue; }
      const near = !focus || (focus.x - v.x) ** 2 + (focus.z - v.z) ** 2 < 170 * 170;
      const p = v.route.sample(v.s + 1.5, this._p);
      const fx = Math.sin(p.h), fz = Math.cos(p.h);
      v.fx = fx; v.fz = fz;
      let blocked = false;
      const look = v.moto ? 5 : v.kind === 'minibus' ? 8 : 7;
      const check = (ox, oz, rad) => {
        const dx = ox - v.x, dz = oz - v.z;
        const ahead = dx * fx + dz * fz;
        const side = Math.abs(dx * fz - dz * fx);
        if (ahead > 0.5 && ahead < look + rad && side < 1.5 + rad) blocked = true;
      };
      // véhicules garés (r = 0.3) : après 4 s d'attente, on les contourne
      for (const b of blockers) if (!(b.r === 0.3 && (v.parkWait || 0) > 4)) { const was = blocked; check(b.x, b.z, b.r); if (!was && blocked && b.r === 0.3) v.parkHit = true; }
      v.parkWait = v.parkHit ? (v.parkWait || 0) + dt : 0; v.parkHit = false;
      // ne s'arrête que derrière un véhicule qui va dans le même sens
      for (const o of V) if (o !== v && o.active && o.fx * fx + o.fz * fz > 0.4 && Math.abs(o.x - v.x) < 12 + o.half && Math.abs(o.z - v.z) < 12 + o.half) { check(o.x - o.fx * o.half * 0.7, o.z - o.fz * o.half * 0.7, o.moto ? 0.3 : 0.9); }
      // ralentit dans les virages
      const q2 = v.route.sample(v.s + 8, this._p);
      const turn = Math.abs(Math.atan2(Math.sin(q2.h - p.h), Math.cos(q2.h - p.h)));
      let target = blocked ? 0 : v.max * this.roadFactor(v.x, v.z) * this.congestion(v.x, v.z) * (1 - Math.min(0.5, turn * 0.6));
      // arrêts de bus : les bus et les tokpa-tokpa marquent l'arrêt (montée et descente des passagers)
      if ((v.role === 'bus' || v.role === 'tokpa') && this.stops.length) {
        v.stopCool = (v.stopCool || 0) - dt;
        if (v.dwell > 0) { v.dwell -= dt; target = 0; if (v.dwell <= 0) { v.stopCool = 25; this.onDepart && this.onDepart(v.stopRef, v); } }
        else if (v.stopCool <= 0) for (const st of this.stops) {
          const dx = st.x - v.x, dz = st.z - v.z, along = dx * fx + dz * fz, lat = Math.abs(dx * fz - dz * fx);
          if (lat < 7.5 && along > -0.5 && along < 14) { const dd = Math.max(0, along - 0.5); if (dd < 0.6 && v.speed < 0.6) { v.dwell = v.role === 'bus' ? 6 : 4; v.stopRef = st; this.onArrive && this.onArrive(st, v); } else target = Math.min(target, Math.sqrt(2 * 3 * dd)); break; }
        }
      }
      // carrefours : feu rouge / orange, et priorité si un véhicule traverse déjà
      let stopAt = Infinity;
      for (const it of this.inters) {
        const dx = it.x - v.x, dz = it.z - v.z;
        const along = dx * fx + dz * fz, lat = Math.abs(dx * fz - dz * fx);
        if (lat > 6 || along < 7.5 || along > 45) continue;
        const dist = along - 10.8 - v.half; // l'avant du véhicule s'arrête à la ligne, avant le passage piéton
        const axis = Math.abs(fz) > Math.abs(fx) ? 'ns' : 'ew';
        let mustStop = false;
        if (it.light && v.commit !== it) {
          const st = this.lights.state(it.light, axis);
          if (st !== 'green') {
            // à l'orange (ou au rouge) : on s'arrête si on en a la place, sinon on s'engage franchement
            if (v.speed < 4 || dist > v.speed * v.speed / 12 + 0.5) mustStop = true; else v.commit = it;
          }
        }
        if (!mustStop) for (const o of it.occ) if (o !== v && Math.abs(o.fx * fx + o.fz * fz) < 0.5) { mustStop = true; break; }
        if (mustStop && dist > -1) stopAt = Math.min(stopAt, Math.max(0, dist));
      }
      if (v.commit && Math.hypot(v.commit.x - v.x, v.commit.z - v.z) > 12 && (v.commit.x - v.x) * fx + (v.commit.z - v.z) * fz < 0) v.commit = null;
      // piétons engagés sur la chaussée : freinage anticipé
      for (const b of blockers) {
        if (!b.ped) continue;
        const dx = b.x - v.x, dz = b.z - v.z, along = dx * fx + dz * fz, lat = Math.abs(dx * fz - dz * fx);
        if (along > 0 && along < 35 && lat < 3.2) stopAt = Math.min(stopAt, Math.max(0, along - 2.2 - v.half));
      }
      // rond-point : on cède le passage aux véhicules déjà engagés sur l'anneau
      const r0 = Math.hypot(v.x, v.z);
      if (r0 > 21 && r0 < 31 && -(v.x * fx + v.z * fz) / r0 > 0.6) {
        for (const o of ringCars) if (o !== v && (o.x - v.x) ** 2 + (o.z - v.z) ** 2 < 15 * 15 && (o.x * fx + o.z * fz) < 4) { stopAt = Math.min(stopAt, Math.max(0, r0 - 23)); break; }
      }
      // freinage progressif (≈ 4 m/s²) pour s'arrêter exactement à la ligne
      if (stopAt < Infinity) target = Math.min(target, Math.sqrt(2 * 4 * Math.max(0, stopAt - 0.4)));
      v.speed = target < v.speed ? Math.max(target, v.speed - 7 * dt) : damp(v.speed, target, 1.2, dt);
      if (v.speed < 0.05 && target < 0.05) v.speed = 0;
      v.blockedT = blocked && blockers.some((b) => (b.x - v.x) ** 2 + (b.z - v.z) ** 2 < 100) ? (v.blockedT || 0) + dt : 0;
      // bouchons : temps passé à l'arrêt ; klaxon de temps en temps près du joueur
      v.stuck = v.speed < 0.5 && target < 0.5 && !(v.dwell > 0) ? (v.stuck || 0) + dt : 0;
      if (v.stuck > 2) jam++;
      if (v.stuck > 4 && near && focus && (focus.x - v.x) ** 2 + (focus.z - v.z) ** 2 < 60 * 60 && v.rnd() < dt * 0.12) this.horns.push({ x: v.x, z: v.z, kind: v.moto ? 'moto' : 'car' });
      v.s += v.speed * dt;
      // changement d'itinéraire aux embranchements (choix de direction)
      v.cooldown -= v.speed * dt;
      const idx = Math.floor((((v.s % v.route.length) + v.route.length) % v.route.length) / v.route.step);
      if (idx !== v.lastIdx) {
        const tr = v.route.transfers.get(idx);
        if (tr && v.cooldown <= 0 && v.rnd() < 0.3) {
          const [rj, sj] = tr[Math.floor(v.rnd() * tr.length)];
          v.route = this.routes[rj]; v.s = sj; v.cooldown = 60;
        }
        v.lastIdx = Math.floor((((v.s % v.route.length) + v.route.length) % v.route.length) / v.route.step);
      }
      const q = v.route.sample(v.s, this._p);
      v.x = q.x; v.z = q.z;
      const dh = Math.atan2(Math.sin(q.h - v.h), Math.cos(q.h - v.h));
      v.h += dh * (1 - Math.exp(-8 * dt));
      v.mesh.visible = near;
      if (!near) continue; // hors de vue : seule la simulation continue
      v.mesh.position.set(v.x, 0, v.z);
      v.mesh.rotation.set(0, v.h, v.moto ? clamp(-dh * 3, -0.35, 0.35) : 0, 'YXZ');
      v.spin += (v.speed / v.wheelR) * dt;
      if (v.moto) for (const w of v.wheels) w.rotation.x = v.spin;
      else for (let i = 0; i < 4; i++) { v.wheels[i].spin.rotation.x = v.spin; if (i < 2) v.wheels[i].pivot.rotation.y = clamp(dh * 4, -0.5, 0.5); }
    }
    this.jam = jam;
  }
}

// panneau de toit (taxi) ou girouette de destination (bus)
function roofSign(text, kind) {
  const c = document.createElement('canvas'); c.width = 256; c.height = 64; const x = c.getContext('2d');
  x.fillStyle = kind === 'bus' ? '#111' : '#f2c200'; x.fillRect(0, 0, 256, 64); x.fillStyle = kind === 'bus' ? '#ffb000' : '#111';
  x.font = '900 40px Arial'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(kind === 'bus' ? 'LIGNE 1 • DANTOKPA' : text, 128, 34);
  const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace;
  const g = new THREE.Group(), mat = new THREE.MeshBasicMaterial({ map: tex, toneMapped: false });
  if (kind === 'bus') { const p = new THREE.Mesh(new THREE.PlaneGeometry(1.9, 0.38), mat); p.position.set(0, 2.72, 5.03); g.add(p); return g; }
  const y = kind === 'citadine' ? 1.68 : 1.6;
  for (const s of [1, -1]) { const p = new THREE.Mesh(new THREE.PlaneGeometry(0.62, 0.17), mat); p.position.set(0, y, s * 0.11); p.rotation.y = s > 0 ? 0 : Math.PI; g.add(p); }
  const bx = new THREE.Mesh(new THREE.BoxGeometry(0.64, 0.19, 0.2), new THREE.MeshStandardMaterial({ color: 0xf2c200 })); bx.position.y = y; g.add(bx);
  return g;
}
