// Mission 012 — étape 4 : modèles procéduraux des 10 bateaux, pilotage (accélérer, ralentir, tourner, s'arrêter,
// marche arrière), houle (tangage, roulis, pilonnement), sillage, et couche de vagues animées près des côtes.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { isWater, coastZ, PIERS } from './region-geo.js';
import { clamp, damp } from './util.js';

const PI = Math.PI;
function colored(geo, hex) {
  const g = geo.index ? geo.toNonIndexed() : geo, c = new THREE.Color(hex), n = g.attributes.position.count, a = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { a[i * 3] = c.r; a[i * 3 + 1] = c.g; a[i * 3 + 2] = c.b; }
  g.setAttribute('color', new THREE.BufferAttribute(a, 3)); if (g.attributes.uv) g.deleteAttribute('uv'); return g;
}
const MATS = {};
const mat = (k) => MATS[k] || (MATS[k] = k === 'glow' ? new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false }) : new THREE.MeshStandardMaterial({ vertexColors: true, roughness: k === 'shiny' ? 0.3 : 0.6, metalness: k === 'shiny' ? 0.3 : 0.1 }));

// coque effilée à l'avant (proue), légèrement arrondie à l'arrière
function hullGeo(L, W, H) {
  const g = new THREE.BoxGeometry(W, H, L, 4, 2, 24), p = g.attributes.position;
  for (let i = 0; i < p.count; i++) {
    const z = p.getZ(i) / (L / 2), y = p.getY(i) / (H / 2);
    let k = 1; if (z > 0.55) k = Math.max(0.04, 1 - Math.pow((z - 0.55) / 0.45, 1.6)); if (z < -0.92) k = 0.92;
    const keel = y < 0 ? 0.55 + 0.45 * (1 + y) : 1; // carène plus étroite vers le bas
    p.setX(i, p.getX(i) * k * keel);
    if (z > 0.8 && y > 0) p.setY(i, p.getY(i) + (z - 0.8) * H * 0.6); // tonture de la proue
  }
  g.computeVertexNormals(); return g;
}

export function buildBoatMesh(sp) {
  const P = [], S = [], Gw = [], g = new THREE.Group(), L = sp.len, W = sp.beam;
  const add = (geo, c, arr = P) => arr.push(colored(geo, c));
  const big = sp.kind === 'cruise' || sp.kind === 'liner' || sp.kind === 'ferry';
  const H = big ? (sp.kind === 'ferry' ? 9 : 14) : sp.kind === 'yacht' ? 5 : Math.max(1.4, L * 0.09);
  const draft = H * 0.45; // partie immergée
  // coque : œuvres vives (antifouling) + œuvres mortes
  add(hullGeo(L, W, draft).translate(0, -draft / 2, 0), big ? 0x8a1a1a : 0x7a2a2a);
  add(hullGeo(L, W, H - draft).translate(0, (H - draft) / 2, 0), sp.hull);
  add(hullGeo(L * 1.002, W * 1.004, H * 0.08).translate(0, H * 0.18, 0), sp.accent);
  const deckY = H;
  add(new THREE.BoxGeometry(W * 0.92, 0.2, L * 0.8).translate(0, deckY, -L * 0.04), big ? 0x8a8f96 : 0xc8a878);
  if (sp.kind === 'cruise' || sp.kind === 'liner') {
    // superstructure : ponts en gradins, balcons (rangées de fenêtres éclairées), cheminée, canots de sauvetage
    const n = sp.decks - 4, dh = 2.9, sL = L * (sp.kind === 'liner' ? 0.62 : 0.78), z0 = sp.kind === 'liner' ? -L * 0.05 : -L * 0.06;
    for (let k = 0; k < n; k++) {
      const y = deckY + k * dh, lk = sL * (1 - Math.max(0, k - n * 0.55) * 0.035), wk = W * (k < n - 2 ? 0.96 : 0.8);
      add(new THREE.BoxGeometry(wk, dh, lk).translate(0, y + dh / 2, z0 + (sL - lk) * 0.2), k === n - 1 ? sp.accent : 0xf8f8f8);
      for (const s of [-1, 1]) add(new THREE.BoxGeometry(0.05, dh * 0.42, lk * 0.96).translate(s * (wk / 2 + 0.03), y + dh * 0.55, z0 + (sL - lk) * 0.2), (k + (s > 0 ? 1 : 0)) % 4 === 0 ? 0x2a3440 : 0xfff2c8, Gw);
    }
    const topY = deckY + n * dh;
    add(new THREE.BoxGeometry(W * 0.5, 4, L * 0.07).translate(0, topY + 2, L * 0.28), 0xf8f8f8); // passerelle de commandement
    add(new THREE.BoxGeometry(W * 0.52, 1.0, L * 0.072).translate(0, topY + 3.2, L * 0.28), 0x1a2430);
    add(new THREE.CylinderGeometry(W * 0.12, W * 0.15, 14, 16).scale(1, 1, 1.6).translate(0, topY + 7, -L * 0.18), sp.funnel);
    add(new THREE.CylinderGeometry(W * 0.124, W * 0.124, 2.5, 16).scale(1, 1, 1.6).translate(0, topY + 13.5, -L * 0.18), 0x1a1a1a);
    // piscine, transats, toboggans
    add(new THREE.BoxGeometry(W * 0.4, 0.3, L * 0.06).translate(0, topY + 0.2, L * 0.05), 0x2ab8e8, Gw);
    for (let k = 0; k < 8; k++) add(new THREE.BoxGeometry(0.8, 0.3, 2).translate(-W * 0.3 + (k % 4) * W * 0.2, topY + 0.15, L * 0.1 + (k < 4 ? 0 : 3)), 0xf2f2f2);
    if (sp.slides) for (let k = 0; k < 3; k++) add(new THREE.TorusGeometry(4 + k, 0.6, 6, 16, PI * 1.5).rotateX(PI / 2).translate(-W * 0.25 + k * 6, topY + 4 + k * 1.5, -L * 0.3), [0xe46a1f, 0x2fd05a, 0xf2c200][k]);
    // mâts radar, canots de sauvetage orange de chaque bord
    add(new THREE.CylinderGeometry(0.3, 0.3, 12, 8).translate(0, topY + 10, L * 0.24), 0xd8d8d8, S);
    for (const s of [-1, 1]) for (let k = 0; k < 9; k++) add(new THREE.CapsuleGeometry(1.3, 6, 3, 8).rotateX(PI / 2).translate(s * (W / 2 + 0.6), deckY + 4.5, -L * 0.25 + k * L * 0.06), 0xe46a1f);
  } else if (sp.kind === 'ferry') {
    add(new THREE.BoxGeometry(W * 0.95, 6, L * 0.55).translate(0, deckY + 3, -L * 0.05), 0xf8f8f8);
    add(new THREE.BoxGeometry(W * 0.85, 3, L * 0.35).translate(0, deckY + 7.5, L * 0.03), 0xf8f8f8);
    add(new THREE.BoxGeometry(W * 0.6, 2.4, 4).translate(0, deckY + 10.2, L * 0.16), 0x1a2430);
    add(new THREE.BoxGeometry(2.4, 7, 3.6).translate(0, deckY + 12, -L * 0.15), sp.funnel);
    for (const s of [-1, 1]) for (let k = 0; k < 2; k++) add(new THREE.BoxGeometry(0.05, 1.2, L * 0.5).translate(s * (W * 0.476 + 0.03), deckY + 2.5 + k * 3, -L * 0.05), 0xfff2c8, Gw);
    add(new THREE.BoxGeometry(W * 0.8, 7, 0.4).translate(0, deckY + 3.5, -L * 0.49), 0x3a3d42); // rampe arrière (véhicules)
  } else if (sp.kind === 'yacht') {
    for (let k = 0; k < 3; k++) { const lk = L * (0.6 - k * 0.12); add(new THREE.BoxGeometry(W * (0.86 - k * 0.1), 2.6, lk).translate(0, deckY + 1.3 + k * 2.6, -L * 0.05 - k * 2), 0xf8f8f8); for (const s of [-1, 1]) add(new THREE.BoxGeometry(0.05, 1.2, lk * 0.9).translate(s * (W * (0.43 - k * 0.05) + 0.03), deckY + 1.5 + k * 2.6, -L * 0.05 - k * 2), 0x1a2430, Gw); }
    add(new THREE.CylinderGeometry(0.15, 0.15, 6, 6).translate(0, deckY + 10, -L * 0.12), 0xd8d8d8, S);
    add(new THREE.BoxGeometry(W * 0.4, 0.3, 5).translate(0, deckY + 0.3, -L * 0.42), 0x2ab8e8, Gw);
  } else if (sp.kind === 'sport') {
    add(new THREE.BoxGeometry(W * 0.75, 1.4, L * 0.45).translate(0, deckY + 0.7, -L * 0.05), sp.accent);
    add(new THREE.BoxGeometry(W * 0.76, 0.7, L * 0.3).rotateX(-0.25).translate(0, deckY + 1.6, L * 0.08), 0x111418, Gw);
  } else if (sp.kind === 'fishing') {
    add(new THREE.BoxGeometry(W * 0.6, 2.4, L * 0.25).translate(0, deckY + 1.2, -L * 0.15), 0xf2f2f2);
    add(new THREE.BoxGeometry(W * 0.62, 0.3, L * 0.27).translate(0, deckY + 2.5, -L * 0.15), sp.accent);
    add(new THREE.CylinderGeometry(0.12, 0.12, 7, 6).translate(0, deckY + 3.5, L * 0.12), 0x6a4a32, S);
    add(new THREE.CylinderGeometry(0.08, 0.08, 6, 6).rotateZ(1.0).translate(1.5, deckY + 4, L * 0.12), 0x6a4a32, S);
    for (let k = 0; k < 6; k++) add(new THREE.SphereGeometry(0.3, 6, 4).translate(-W * 0.3 + (k % 3) * 0.6, deckY + 0.4, L * 0.25 + Math.floor(k / 3) * 0.7), [0xf2c200, 0xe46a1f][k % 2]); // flotteurs des filets
    add(new THREE.BoxGeometry(W * 0.5, 0.5, 1.6).translate(0, deckY + 0.3, L * 0.3), 0x3a6a3a); // filets
  } else if (sp.kind === 'speed') {
    add(new THREE.BoxGeometry(W * 0.8, 0.5, 1.2).rotateX(-0.5).translate(0, deckY + 0.6, L * 0.05), 0x9ab0c0, Gw);
    add(new THREE.BoxGeometry(0.6, 1.0, 0.7).translate(0, deckY - 0.1, -L / 2 - 0.2), 0x1a1a1a); // moteur hors-bord
    for (const s of [-1, 1]) add(new THREE.BoxGeometry(0.6, 0.6, 0.6).translate(s * 0.6, deckY + 0.4, -L * 0.15), 0xf2f2f2);
  } else if (sp.kind === 'shuttle') {
    add(new THREE.BoxGeometry(W * 0.92, 2.4, L * 0.7).translate(0, deckY + 1.2, -L * 0.05), 0xf2f2f2);
    add(new THREE.BoxGeometry(W * 0.96, 0.25, L * 0.74).translate(0, deckY + 2.5, -L * 0.05), sp.accent);
    for (const s of [-1, 1]) add(new THREE.BoxGeometry(0.05, 0.9, L * 0.62).translate(s * (W * 0.46 + 0.03), deckY + 1.5, -L * 0.05), 0x2a3440, Gw);
  }
  // feux de navigation (bâbord rouge, tribord vert)
  add(new THREE.SphereGeometry(Math.max(0.15, W * 0.01), 6, 4).translate(-W / 2, deckY + 0.5, L * 0.3), 0xff3a2a, Gw); add(new THREE.SphereGeometry(Math.max(0.15, W * 0.01), 6, 4).translate(W / 2, deckY + 0.5, L * 0.3), 0x2fd05a, Gw);
  const body = new THREE.Mesh(mergeGeometries(P), mat('n')); body.castShadow = !big; body.receiveShadow = true; g.add(body);
  if (S.length) g.add(new THREE.Mesh(mergeGeometries(S), mat('shiny')));
  g.add(new THREE.Mesh(mergeGeometries(Gw), mat('glow')));
  return { group: g, deckY, draft, H };
}

// ------------------------------------------------------------------ pilotage
export class Boat {
  constructor(scene, spec, rec) {
    this.isBoat = true; this.spec = null; this.bspec = spec; this.id = spec.id;
    this.parts = buildBoatMesh(spec); this.mesh = this.parts.group;
    this.pos = new THREE.Vector3(rec.x, 0, rec.z); this.heading = rec.h || 0; this.speed = 0; this.steer = 0; this.occupied = false; this.t = Math.random() * 10;
    const big = spec.len > 60;
    this.sound = { type: spec.kind === 'speed' || spec.kind === 'sport' ? 'v8' : 'diesel', mul: big ? 0.45 : 0.9 };
    this.hornFreqs = big ? [98, 123] : spec.kind === 'speed' ? [520, 660] : [330, 415];
    this.rpm = 700; this.throttle = 0; this.model = { wheelR: 0.3 };
    this.wake = this.makeWake(); scene.add(this.mesh); scene.add(this.wake);
    this.sync(0);
  }
  get forward() { return { x: Math.sin(this.heading), z: Math.cos(this.heading) }; }
  enableHeadlight() {}
  circles() { return []; }
  makeWake() {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1).rotateX(-PI / 2), new THREE.MeshBasicMaterial({ color: 0xf2f8fa, transparent: true, opacity: 0, depthWrite: false }));
    m.renderOrder = 2; return m;
  }
  // point de débarquement : terre ferme ou jetée la plus proche (sinon null : impossible de débarquer)
  exitPoint() {
    const sp = this.bspec, f = this.forward, rx = Math.cos(this.heading), rz = -Math.sin(this.heading);
    let best = null;
    for (const r of [sp.beam / 2 + 2, sp.beam / 2 + 5, sp.beam / 2 + 9, sp.beam / 2 + 14]) for (let k = -4; k <= 4; k++) for (const s of [-1, 1]) {
      const along = k * sp.len * 0.1, x = this.pos.x + f.x * along + rx * s * r, z = this.pos.z + f.z * along + rz * s * r;
      if (isWater(x, z) || (this.col && this.col.pointBlocked(x, 0.5, z))) continue;
      const d = r + Math.abs(along) * 0.3; if (!best || d < best.d) best = { d, x, z };
    }
    return best ? new THREE.Vector3(best.x, 0, best.z) : null;
  }
  update(dt, input) {
    const S = this.bspec;
    let thr = 0, st = 0, brake = false;
    if (this.occupied && input) {
      thr = (input.down('KeyW') || input.down('ArrowUp') ? 1 : 0) - (input.down('KeyS') || input.down('ArrowDown') ? 1 : 0);
      st = (input.down('KeyA') || input.down('ArrowLeft') ? 1 : 0) - (input.down('KeyD') || input.down('ArrowRight') ? 1 : 0);
      brake = input.down('Space');
    }
    this.throttle = Math.abs(thr);
    const target = thr > 0 ? S.vMax : thr < 0 ? -S.vMax * 0.3 : 0;
    const a = thr !== 0 ? S.acc : S.acc * 0.35 + (brake ? S.acc * 1.5 : 0);
    this.speed += clamp(target - this.speed, -a * dt, a * dt);
    this.steer = damp(this.steer, st, 2, dt);
    const eff = clamp(Math.abs(this.speed) / 2, 0.15, 1) * Math.sign(this.speed || 1);
    this.heading += this.steer * S.turn * eff * dt * (Math.abs(this.speed) > 0.2 ? 1 : 0.3);
    const f = this.forward, nx = this.pos.x + f.x * this.speed * dt, nz = this.pos.z + f.z * this.speed * dt;
    // reste dans l'eau : la proue, la poupe et les flancs doivent être sur l'eau (jetées comprises comme obstacles)
    const rx = Math.cos(this.heading), rz = -Math.sin(this.heading), hl = S.len / 2 * 0.95, hw = S.beam / 2 * 0.9;
    const ok = [[hl, 0], [-hl, 0], [0, hw], [0, -hw], [hl * 0.6, hw * 0.7], [hl * 0.6, -hw * 0.7]].every(([a2, b2]) => isWater(nx + f.x * a2 + rx * b2, nz + f.z * a2 + rz * b2));
    if (ok) { this.pos.x = nx; this.pos.z = nz; }
    else { if (Math.abs(this.speed) > 1 && this.onMsg) this.onMsg('Attention : rivage ou quai ! Le bateau s’arrête.'); this.speed *= -0.2; }
    this.rpm = 700 + Math.abs(this.speed) / S.vMax * 2400;
    this.sync(dt);
    return 0;
  }
  sync(dt) {
    const S = this.bspec, k = 1 / Math.max(1, S.len / 25);
    this.t += dt;
    const heave = Math.sin(this.t * 0.9) * 0.35 * Math.sqrt(k), pitch = Math.sin(this.t * 0.62) * 0.03 * k + (this.speed / S.vMax) * -0.02 * k * 3, roll = Math.sin(this.t * 0.75 + 1) * 0.045 * k - this.steer * (this.speed / S.vMax) * 0.06 * k;
    this.mesh.position.set(this.pos.x, heave, this.pos.z);
    this.mesh.rotation.set(pitch, this.heading, roll, 'YXZ');
    // sillage : bande d'écume qui s'allonge avec la vitesse
    const v = Math.abs(this.speed), w = this.wake, len = Math.min(S.len * 1.6, 6 + v * 8);
    w.visible = v > 0.6; if (w.visible) { const f = this.forward, back = -Math.sign(this.speed) * (S.len / 2 + len / 2); w.position.set(this.pos.x + f.x * back, 0.14, this.pos.z + f.z * back); w.rotation.y = this.heading; w.scale.set(S.beam * 1.1, 1, len); w.material.opacity = Math.min(0.5, v / S.vMax * 0.6); }
  }
  dispose(scene) { scene.remove(this.mesh); scene.remove(this.wake); }
}

// ------------------------------------------------------------------ vagues animées (près des côtes, autour de la caméra)
export class Waves {
  constructor(scene) {
    const N = 16, SIZE = 900;
    this.u = { uTime: { value: 0 }, uC: { value: new Array(N).fill(0) }, uX0: { value: 0 }, uW: { value: SIZE }, uP: { value: Array.from({ length: 6 }, () => new THREE.Vector4(0, 0, 0, 0)) } };
    const m = new THREE.MeshStandardMaterial({ color: 0x1d6f88, roughness: 0.12, metalness: 0.15, transparent: true, opacity: 0.92 });
    m.onBeforeCompile = (sh) => {
      Object.assign(sh.uniforms, this.u);
      sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nuniform float uTime; varying vec3 vWp;\nfloat wv(vec2 p){ return sin(p.x*0.09+uTime*1.3)*0.22+sin(p.y*0.13-uTime*1.1)*0.18+sin((p.x+p.y)*0.21+uTime*2.1)*0.08; }')
        .replace('#include <beginnormal_vertex>', '#include <beginnormal_vertex>\nvec4 wp0 = modelMatrix*vec4(position,1.0); float e=1.0; float hx=wv(wp0.xz+vec2(e,0.))-wv(wp0.xz-vec2(e,0.)); float hz=wv(wp0.xz+vec2(0.,e))-wv(wp0.xz-vec2(0.,e)); objectNormal=normalize(vec3(-hx/(2.0*e),1.0,-hz/(2.0*e)));')
        .replace('#include <begin_vertex>', '#include <begin_vertex>\nvec4 wp1 = modelMatrix*vec4(position,1.0); transformed.y += wv(wp1.xz); vWp = (modelMatrix*vec4(transformed,1.0)).xyz;');
      sh.fragmentShader = sh.fragmentShader.replace('#include <common>', `#include <common>\nuniform float uC[${N}]; uniform float uX0; uniform float uW; uniform vec4 uP[6]; varying vec3 vWp;`)
        .replace('void main() {', `void main() {\n float fi=clamp((vWp.x-uX0)/uW*${N - 1}.0,0.0,${N - 1}.0); int i0=int(floor(fi)); int i1=min(i0+1,${N - 1}); float cz=mix(uC[i0],uC[i1],fract(fi)); if (vWp.z < cz + 1.0) discard;\n for (int k=0;k<6;k++){ vec4 r=uP[k]; if (r.z>r.x && vWp.x>r.x && vWp.x<r.z && vWp.z>r.y && vWp.z<r.w) discard; }`);
    };
    this.mesh = new THREE.Mesh(new THREE.PlaneGeometry(SIZE, SIZE, 150, 150).rotateX(-PI / 2), m); this.mesh.position.y = 0.1; this.mesh.frustumCulled = false; this.mesh.renderOrder = 1;
    this.N = N; this.SIZE = SIZE; scene.add(this.mesh);
  }
  update(dt, cam) {
    const x = Math.round(cam.position.x / 20) * 20, cz = coastZ(x), near = cam.position.y < 500 && Math.abs(cam.position.z - cz) < 700;
    this.mesh.visible = near; if (!near) return;
    this.u.uTime.value += dt;
    const z = Math.max(cz + this.SIZE / 2 - 120, Math.round(cam.position.z / 20) * 20);
    this.mesh.position.set(x, 0.1, z);
    const x0 = x - this.SIZE / 2; this.u.uX0.value = x0;
    for (let i = 0; i < this.N; i++) this.u.uC.value[i] = coastZ(x0 + i * this.SIZE / (this.N - 1));
    PIERS.slice(0, 6).forEach((r, i) => this.u.uP.value[i].set(r.x0, r.z0, r.x1, r.z1));
  }
}
