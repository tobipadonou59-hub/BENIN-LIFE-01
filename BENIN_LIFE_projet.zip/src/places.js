// Complément mission 015 — registre des lieux de la carte : nom, catégorie, icône, position, statut
// (lieu réel à sa position OpenStreetMap / lieu réel représenté de façon stylisée dans la ville du jeu / lieu fictif),
// adresse dans l'univers du jeu, accès, découvertes (sauvegardées).
import { TOWNS, regionZone } from './region-geo.js';
import { HOME } from './home.js';
import { NOVA_LOT, SUPER_LOT, GARAGE_LOT } from './world.js';

export const CATS = {
  ville: { label: 'Villes', icon: '🏙️' },
  entreprise: { label: 'Mes entreprises', icon: '🏢' },
  visitable: { label: 'Bâtiments visitables', icon: '🚪' },
  marche: { label: 'Marchés & commerces', icon: '🛒' },
  restaurant: { label: 'Restaurants & maquis', icon: '🍲' },
  monument: { label: 'Monuments & places', icon: '🗿' },
  loisirs: { label: 'Loisirs & nature', icon: '🌴' },
  transport: { label: 'Transports', icon: '✈️' },
  services: { label: 'Banque, hôtel, santé', icon: '🏨' },
  quartier: { label: 'Quartiers', icon: '🏘️' },
  maison: { label: 'Ma maison', icon: '🏠' },
};
export const STATUS = { reel: 'Lieu réel (position OpenStreetMap, échelle 1:5)', stylise: 'Lieu réel, représenté de façon stylisée dans le jeu (position non géographique)', fictif: 'Lieu fictif (inventé pour le jeu)' };

export function buildPlaces(world) {
  const P = [];
  const add = (o) => P.push({ access: true, ...o, id: o.id || o.name });
  // villes (positions OpenStreetMap)
  for (const t of TOWNS) add({ name: t.name, cat: 'ville', x: t.x, z: t.z, status: 'reel', note: t.sub });
  add({ name: 'Cotonou (ville du jeu)', id: 'Cotonou', cat: 'ville', x: 0, z: 0, status: 'stylise', note: 'Plan de ville imaginé pour le jeu' });
  // maison, entreprises et bâtiments visitables
  add({ name: 'Ma maison', cat: 'maison', x: HOME.marker.x, z: HOME.marker.z, status: 'fictif', note: 'Cuisine, salon, chambre, garage' });
  add({ name: 'NOVA BOOK — siège social', id: 'NOVA BOOK', cat: 'entreprise', x: 59, z: 8.6, status: 'fictif', star: true, note: 'Édition, graphisme, impression • 6 niveaux visitables • bureau du PDG au 5e étage' });
  add({ name: 'Supermarché LAGUNA', cat: 'visitable', x: 42, z: -108.5, status: 'fictif', note: 'Ouvert de 7 h à 22 h' });
  add({ name: 'Garage AUTO CONCEPT', cat: 'visitable', x: (GARAGE_LOT.x0 + GARAGE_LOT.x1) / 2, z: GARAGE_LOT.z1 + 1, status: 'fictif', note: 'Concession, garage, réparation' });
  void SUPER_LOT; void NOVA_LOT;
  // sociétés du groupe NOVA : pas encore créées (mission 014) — locaux réservés dans des immeubles existants
  const towers = (world.footprints || []).filter((f) => f[4] === 1 && Math.abs((f[0] + f[2]) / 2) < 95 && Math.abs((f[1] + f[3]) / 2) < 95)
    .map((f) => ({ x: (f[0] + f[2]) / 2, z: (f[1] + f[3]) / 2, a: (f[2] - f[0]) * (f[3] - f[1]) }))
    .filter((f) => !(f.x > 38 && f.x < 90 && f.z > 10 && f.z < 58) && !(f.x > -93 && f.x < -7 && f.z > 7 && f.z < 93) && !(f.x > 7 && f.x < 93 && f.z > -93 && f.z < -7) && /^Quartier /.test(world.zoneName(f.x, f.z))).sort((a, b) => b.a - a.a); // immeubles de bureaux ordinaires (hors marché, jardin, NOVA BOOK)
  const used = [];
  for (const [n, desc] of [['NOVA DIGITAL', 'Informatique et développement'], ['NOVA MEDIA', 'Audiovisuel et production vidéo'], ['NOVA IMMOBILIER', 'Location et gestion de bâtiments'], ['NOVA TRANSPORT', 'Transport et logistique'], ['NOVA DISTRIBUTION', 'Commerce et distribution']]) {
    const t = towers.find((q) => !used.some((u) => Math.hypot(u.x - q.x, u.z - q.z) < 25));
    if (!t) continue; used.push(t);
    add({ name: n, cat: 'entreprise', x: t.x, z: t.z, status: 'fictif', access: false, reserved: true, note: `${desc} • société pas encore créée : locaux réservés (création prévue avec la mission 014)` });
  }
  // marchés, monuments, loisirs, transports
  add({ name: 'Marché Dantokpa', cat: 'marche', x: -50, z: 92.5, status: 'stylise', note: 'Grand marché • 69 vendeurs fictifs dans 12 allées, négociation' });
  if (world.martyrs && world.martyrs.x !== undefined) add({ name: 'Place des Martyrs', cat: 'monument', x: world.martyrs.x, z: world.martyrs.z, status: 'stylise' });
  if (world.amazone) add({ name: 'Place de l’Amazone', cat: 'monument', x: world.amazone.x, z: world.amazone.z, status: 'stylise', note: 'Statue de l’Amazone, en bord de mer' });
  add({ name: 'Rond-point central', cat: 'monument', x: 0, z: 0, status: 'fictif' });
  add({ name: 'Jardin de Cadjèhoun', cat: 'loisirs', x: 50, z: -50, status: 'fictif', note: 'Nom inspiré d’un quartier réel de Cotonou' });
  add({ name: 'Plage — Boulevard de la Marina', cat: 'loisirs', x: 0, z: 168, status: 'stylise', note: 'Baignade dangereuse' });
  add({ name: 'Lac Nokoué', cat: 'loisirs', x: 1700, z: -1700, status: 'reel', access: false, note: 'Contour OpenStreetMap' });
  add({ name: 'Aéroport de Cotonou', cat: 'transport', x: -462, z: 113, status: 'stylise', note: 'Comptoir des vols • 8 avions' });
  // enseignes du jeu (fictives)
  const seen = new Set();
  for (const o of world.namedPlaces || []) if (!seen.has(o.name)) { seen.add(o.name); add({ name: o.name.charAt(0) + o.name.slice(1).toLowerCase().replace('océan bleu', 'Océan Bleu').replace('lagune', 'Lagune'), cat: 'services', x: o.x, z: o.z, status: 'fictif', access: false, note: 'Enseigne du jeu (bâtiment non visitable)' }); }
  const shopCat = (n) => (/MAQUIS|TANTI|GLACIER|BOULANGERIE|BAR /.test(n) ? 'restaurant' : /PHARMACIE|DENTAIRE/.test(n) ? 'services' : 'marche');
  for (const f of world.shopFronts || []) if (f.name) add({ id: `${f.name}@${Math.round(f.x)},${Math.round(f.z)}`, name: f.name.charAt(0) + f.name.slice(1).toLowerCase(), cat: shopCat(f.name), x: f.x, z: f.z, status: 'fictif', access: false, small: true, note: 'Boutique du quartier (non visitable)' });
  // quartiers (noms réels de Cotonou, emplacements imaginés par le jeu)
  const seenQ = new Set();
  for (let x = -137; x <= 137; x += 91.3) for (let z = -137; z <= 125; z += 87) {
    const n = world.zoneName(x, z); if (!/^Quartier /.test(n) || seenQ.has(n)) continue; seenQ.add(n);
    add({ name: n.replace('Quartier ', ''), id: n, cat: 'quartier', x, z, status: 'stylise', access: false, note: 'Nom réel d’un quartier de Cotonou, emplacement imaginé par le jeu' });
  }
  for (const p of P) p.address = address(world, p);
  return P;
}
export function address(world, p) {
  const z = regionZone(p.x, p.z) || world.zoneName(p.x, p.z);
  const town = TOWNS.find((t) => Math.hypot(p.x - t.x, p.z - t.z) < t.r + 50);
  const city = town ? town.name : Math.abs(p.x) < 220 && p.z > -220 && p.z < 230 ? 'Cotonou' : 'Environs de Cotonou';
  return z && z !== city ? `${z}, ${city}` : city;
}
