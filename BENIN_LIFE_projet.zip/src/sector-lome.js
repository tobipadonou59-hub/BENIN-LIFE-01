// Mission 023, phase 1 — LOMÉ (Togo), premier secteur pays explorable. Placé à sa position géographique réelle dans le
// repère du jeu (même projection que la région du Bénin, échelle 1:5). Plan STYLISÉ : la côte au sud (boulevard du Mono),
// la lagune de Bè traversée par des ponts, le boulevard circulaire du 13 Janvier, la frontière du Ghana tout à l'ouest,
// le port à l'est, l'aéroport au nord-est, l'université au nord. Positions des lieux approximatives. Les commerces,
// hôtels, restaurants et compagnies portant un nom inventé sont FICTIFS.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { colorize } from './vehicles.js';
import { toWorld } from './africa-data.js';

const PI = Math.PI;
const O = toWorld(6.13, 1.22); // origine du secteur (centre de Lomé)
const L = (lat, lon) => { const w = toWorld(lat, lon); return { x: w.x - O.x, z: w.z - O.z }; };
export const LOME = {
  id: 'lome', country: '768', name: 'Lomé', O,
  X0: -480, X1: 1560, Z0: -1120, COAST: 172, // frontière du Ghana à l'ouest (x ≈ −480), côte au sud
  LAG: { x0: -390, x1: 1260, z0: -252, z1: -214 }, // lagune de Bè
  QUAY: { x0: 1300, x1: 1552, z0: 120, z1: 262 }, // quais du port
  bridges: [],
};
// voies principales (coordonnées locales) : [x0, z0, x1, z1, largeur, nom]
const EW = [[-480, 120, 1560, 120, 14, 'Boulevard du Mono'], [-470, 60, 1290, 60, 10, ''], [-470, -110, 1290, -110, 10, ''], [-380, -330, 1250, -330, 10, ''], [-420, -560, 1250, -560, 10, ''], [-420, -800, 640, -800, 10, 'Route de l’aéroport']];
const NS = [-300, -110, 90, 300, 520, 760, 1000, 1250].map((x) => [x, -800, x, 120, 10, '']);
const CROSS = [-110, 300, 760, 1000]; // avenues qui franchissent la lagune (ponts)
const RING = { cx: 250, cz: 120, r: 650 }; // boulevard du 13 Janvier (demi-cercle au nord)
for (const x of CROSS) LOME.bridges.push({ x0: x - 7, x1: x + 7 });
{ const dz = LOME.LAG.z0 + 19 - RING.cz, dx = Math.sqrt(RING.r * RING.r - dz * dz); LOME.bridges.push({ x0: RING.cx - dx - 9, x1: RING.cx - dx + 9 }, { x0: RING.cx + dx - 9, x1: RING.cx + dx + 9 }); }
const inLag = (x, z) => x > LOME.LAG.x0 && x < LOME.LAG.x1 && z > LOME.LAG.z0 && z < LOME.LAG.z1 && !LOME.bridges.some((b) => x > b.x0 && x < b.x1);
const onQuay = (x, z) => x > LOME.QUAY.x0 && x < LOME.QUAY.x1 && z > LOME.QUAY.z0 && z < LOME.QUAY.z1;
// fonctions de secteur utilisées par landClamp / isWater (en coordonnées du MONDE)
LOME.has = (x, z) => x > O.x + LOME.X0 - 40 && x < O.x + LOME.X1 + 40 && z > O.z + LOME.Z0 - 40 && z < O.z + 900;
LOME.near = (x, z) => Math.abs(x - O.x - 500) < 3500 && Math.abs(z - O.z) < 3000;
LOME.water = (x, z) => { const lx = x - O.x, lz = z - O.z; return (lz > LOME.COAST && !onQuay(lx, lz)) || inLag(lx, lz); };
LOME.clamp = (obj, margin = 1) => {
  const p = obj.pos; let lx = p.x - O.x, lz = p.z - O.z;
  lx = Math.max(LOME.X0 + 2, Math.min(LOME.X1 - 2, lx)); lz = Math.max(LOME.Z0 + 2, lz);
  if (!onQuay(lx, lz)) lz = Math.min(LOME.COAST - margin, lz);
  if (inLag(lx, lz)) { if (obj._dry) { lx = obj._dry.x - O.x; lz = obj._dry.z - O.z; if (obj.speed) obj.speed *= -0.2; } }
  p.x = O.x + lx; p.z = O.z + lz; if (!obj._dry) obj._dry = { x: 0, z: 0 }; if (!inLag(lx, lz)) { obj._dry.x = p.x; obj._dry.z = p.z; }
};
// lieux (coordonnées locales) — positions issues de coordonnées géographiques approximatives
const P = {
  monument: L(6.13, 1.215), marche: { x: 90, z: 90 }, cathedrale: { x: 25, z: 90 }, akodessawa: { x: 805, z: -286 }, port: { x: 1420, z: 70 },
  aeroport: { x: 680, z: -880 }, universite: { x: -220, z: -990 }, hopital: { x: -60, z: -485 }, gare: { x: 420, z: -172 }, mall: { x: 160, z: -15 },
  hotel: { x: -240, z: 90 }, frontiere: { x: -462, z: 120 }, sortieEst: { x: 1540, z: 112 }, plage: { x: 320, z: 150 },
};
const TAXIS = [[60, 53, 'Grand Marché'], [-111, 48.5, 'Place de l’Indépendance'], [700, -855, 'Aéroport'], [420, -125, 'Gare routière'], [880, -102, 'Bè'], [-380, 52.5, 'Frontière']];
const QUARTIERS = [['Kodjoviakopé', -380, 40], ['Nyékonakpoè', -230, -20], ['Hanoukopé', -120, -150], ['Centre (Grand Marché)', 80, 60], ['Bè', 620, -60], ['Akodessawa', 820, -330], ['Tokoin', 0, -480], ['Agbalépédogan', -250, -760], ['Quartier du port', 1380, 40], ['Aéroport', 820, -900], ['Université', -220, -1000]];
const SHOPS = ['ALIMENTATION LA GRÂCE', 'COIFFURE AFI BEAUTÉ', 'QUINCAILLERIE AKPÉ', 'TRANSFERT D’ARGENT', 'PAGNES WAX DU GOLFE', 'BOUTIQUE WOEZƆ', 'TÉLÉPHONIE MOBILE', 'PHARMACIE DU MONO', 'BOULANGERIE DU CENTRE', 'ATELIER COUTURE KOFFI', 'MAQUIS CHEZ YAWA', 'LIBRAIRIE DU SAVOIR'];
const NAMES = { f: ['Ama', 'Afi', 'Akossiwa', 'Yawa', 'Abla', 'Essi', 'Dzifa', 'Mawuena', 'Kafui', 'Essoham'], m: ['Kodjo', 'Kossi', 'Komlan', 'Koffi', 'Yao', 'Mawuli', 'Sena', 'Edem', 'Kokou', 'Essodina'] };

export function buildLome(ctx) {
  const { scene, world, quality } = ctx, C = world.collision, g = new THREE.Group(); g.position.set(O.x, 0, O.z); scene.add(g);
  const parts = [], glow = [], heads = [], signs = {}, cols = [], points = [], lanes = [], lamps = [];
  const box = (x0, y0, z0, x1, y1, z1, c, arr = parts) => arr.push(colorize(new THREE.BoxGeometry(Math.abs(x1 - x0) || 0.01, Math.abs(y1 - y0) || 0.01, Math.abs(z1 - z0) || 0.01).translate((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), c));
  const solid = (x0, z0, x1, z1, h) => { const o = C.addBox(O.x + Math.min(x0, x1), O.z + Math.min(z0, z1), O.x + Math.max(x0, x1), O.z + Math.max(z0, z1), h); cols.push(o); return o; };
  const circle = (x, z, r, h) => { const o = C.addCircle(O.x + x, O.z + z, r, h); cols.push(o); return o; };
  const Pt = (x, z, r, label, action) => points.push({ x, z, r, label, action });
  const R = (() => { let a = 9917; return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; })();
  const reserved = [];
  const reserve = (x0, z0, x1, z1) => reserved.push({ x0, z0, x1, z1 });
  const isRes = (x0, z0, x1, z1) => reserved.some((r) => x1 > r.x0 && x0 < r.x1 && z1 > r.z0 && z0 < r.z1);
  // ---- sol, mer, plage, lagune ----
  box(LOME.X0 - 400, -0.12, LOME.Z0 - 400, LOME.X1 + 400, -0.02, LOME.COAST, 0x9a8a5a);
  const sea = new THREE.Mesh(new THREE.PlaneGeometry(LOME.X1 - LOME.X0 + 3000, 1500).rotateX(-PI / 2), new THREE.MeshStandardMaterial({ color: 0x1b6a82, roughness: 0.18, metalness: 0.1 })); sea.position.set((LOME.X0 + LOME.X1) / 2, 0.02, LOME.COAST + 740); g.add(sea);
  box(LOME.X0 - 400, -0.01, 132, LOME.X1 + 400, 0.01, LOME.COAST + 4, 0xe8d8b0);
  box(LOME.LAG.x0, -0.01, LOME.LAG.z0, LOME.LAG.x1, 0.03, LOME.LAG.z1, 0x3a6a5a);
  for (const b of LOME.bridges) { box(b.x0, 0.6, LOME.LAG.z0 - 4, b.x1, 0.9, LOME.LAG.z1 + 4, 0xb8b4ac); for (const s of [b.x0, b.x1]) box(s - 0.2, 0.9, LOME.LAG.z0 - 4, s + 0.2, 1.8, LOME.LAG.z1 + 4, 0xd8d4cc); }
  // ---- routes : bitume (axes), latérite (rues) ----
  const roadSeg = (x0, z0, x1, z1, w, c = 0x3c3e42) => { if (x0 === x1) box(x0 - w / 2, 0.02, Math.min(z0, z1), x0 + w / 2, 0.05, Math.max(z0, z1), c); else box(Math.min(x0, x1), 0.02, z0 - w / 2, Math.max(x0, x1), 0.05, z0 + w / 2, c); };
  for (const [x0, z0, x1, z1, w] of EW) { roadSeg(x0, z0, x1, z1, w); box(x0, 0.05, z0 - 0.08, x1, 0.06, z0 + 0.08, 0xe8e8e8); }
  for (const [x0, z0, x1, z1, w] of NS) { const cross = CROSS.includes(x0); if (cross) roadSeg(x0, z0, x0, z1, w); else { roadSeg(x0, -800, x0, LOME.LAG.z0 - 6, w); roadSeg(x0, LOME.LAG.z1 + 6, x0, z1, w); } }
  const ringPts = []; for (let a = PI; a <= 2 * PI + 1e-6; a += PI / 90) ringPts.push([RING.cx + Math.cos(a) * RING.r, RING.cz + Math.sin(a) * RING.r]);
  for (let i = 0; i < ringPts.length - 1; i++) { const [ax, az] = ringPts[i], [bx, bz] = ringPts[i + 1], len = Math.hypot(bx - ax, bz - az); parts.push(colorize(new THREE.BoxGeometry(12, 0.03, len + 1).rotateY(Math.atan2(bx - ax, bz - az)).translate((ax + bx) / 2, 0.045, (az + bz) / 2), 0x3c3e42)); }
  const nearRing = (x, z, d) => Math.abs(Math.hypot(x - RING.cx, z - RING.cz) - RING.r) < d && z < RING.cz;
  const roadAt = (x, z, m) => EW.some(([x0, zz, x1, , w]) => x > x0 - m && x < x1 + m && Math.abs(z - zz) < w / 2 + m) || NS.some(([xx, z0, , z1, w]) => Math.abs(x - xx) < w / 2 + m && z > z0 - m && z < z1 + m) || nearRing(x, z, 6 + m);
  // ---- lieux réservés ----
  const M = P.monument, mk = P.marche;
  reserve(M.x - 40, M.z - 45, M.x + 40, M.z + 40); reserve(mk.x - 32, 70, mk.x + 32, 112); reserve(5, 70, 45, 112); reserve(P.hotel.x - 26, 68, P.hotel.x + 26, 112);
  reserve(770, -312, 845, -262); reserve(1290, 0, 1560, 115); reserve(560, -1120, 1560, -650); reserve(-330, -1110, -110, -880); reserve(-100, -525, -20, -445); reserve(375, -208, 465, -138); reserve(120, -55, 205, 30);
  reserve(535, 66, 585, 104); reserve(-330, -600, -270, -565); reserve(-470, 66, -420, 112); reserve(1480, 66, 1560, 112);
  reserve(630, -133, 650, -117); reserve(433, -484, 487, -443); // maquis Akpé, école (réservés AVANT la génération des immeubles)
  for (const [x, z] of TAXIS) reserve(x - 4, z - 4, x + 4, z + 4);
  // ---- immeubles et maisons (identité togolaise : façades ocre, crème, vertes, bleues, terre cuite ; balcons ; tôles) ----
  const FAC = [0xd8a860, 0xf0e4c8, 0xb8d8a8, 0xa8c8e0, 0xc8785a, 0xf4f0e6, 0xe8c8a0, 0xd8d0b8], TRIM = [0x1f6a3a, 0xe0b020, 0x8a2a2a, 0x2a4a8a], ROOF = [0x8a8a86, 0x9a5a3a, 0x7a7a78];
  const signPlane = (txt) => (signs[txt] || (signs[txt] = []));
  const building = (x, z, w, d, ry, kind) => {
    const fac = FAC[(R() * FAC.length) | 0], trim = TRIM[(R() * TRIM.length) | 0], floors = kind === 'tour' ? 5 + ((R() * 6) | 0) : kind === 'centre' ? 2 + ((R() * 3) | 0) : kind === 'maison' ? 1 : 1 + ((R() * 2) | 0), h = floors * 3.1;
    const m = new THREE.Matrix4().makeRotationY(ry).setPosition(x, 0, z), add = (geo, c) => parts.push(colorize(geo.applyMatrix4(m), c));
    if (kind === 'concession') { // concession familiale : mur d'enceinte, portail, maison à tôle
      const W = w / 2, D = d / 2; for (const [a, b, c2, e] of [[-W, -D, W, -D + 0.25], [-W, -D, -W + 0.25, D], [W - 0.25, -D, W, D], [-W, D - 0.25, -1.2, D], [1.2, D - 0.25, W, D]]) add(new THREE.BoxGeometry(c2 - a, 2.1, e - b).translate((a + c2) / 2, 1.05, (b + e) / 2), fac);
      add(new THREE.BoxGeometry(2.4, 2.0, 0.08).translate(0, 1.0, D - 0.12), trim); add(new THREE.BoxGeometry(w * 0.6, 2.9, d * 0.42).translate(0, 1.45, -D * 0.45), FAC[(R() * FAC.length) | 0]); add(new THREE.BoxGeometry(w * 0.66, 0.12, d * 0.5).translate(0, 3.0, -D * 0.45), ROOF[(R() * ROOF.length) | 0]);
    } else {
      add(new THREE.BoxGeometry(w, h, d).translate(0, h / 2, 0), fac); add(new THREE.BoxGeometry(w + 0.3, 0.5, d + 0.3).translate(0, h + 0.25, 0), kind === 'maison' ? ROOF[(R() * ROOF.length) | 0] : 0xe8e0d0);
      for (let f = 0; f < floors; f++) for (let k = -1; k <= 1; k += 2) add(new THREE.BoxGeometry(w * 0.22, 1.2, 0.06).translate(k * w * 0.25, 1.7 + f * 3.1, d / 2 + 0.03), 0x2a3a44);
      for (let f = 1; f < floors; f++) add(new THREE.BoxGeometry(w * 0.8, 0.15, 1.1).translate(0, f * 3.1, d / 2 + 0.55), trim); // balcons
      if (kind === 'centre' || (kind !== 'maison' && R() < 0.35)) { add(new THREE.BoxGeometry(w * 0.9, 0.12, 1.6).translate(0, 2.7, d / 2 + 0.8), TRIM[(R() * TRIM.length) | 0]); const t = SHOPS[(R() * SHOPS.length) | 0]; const sg = new THREE.PlaneGeometry(Math.min(w * 0.8, 6), 0.7).translate(0, 3.3, d / 2 + 0.05).applyMatrix4(m); signPlane(t).push(sg); }
    }
    const e = Math.max(w, d) / 2 * 0.95, cx = x, cz = z; const oo = C.addBox(O.x + cx - (Math.abs(Math.sin(ry)) > 0.5 ? d : w) / 2, O.z + cz - (Math.abs(Math.sin(ry)) > 0.5 ? w : d) / 2, O.x + cx + (Math.abs(Math.sin(ry)) > 0.5 ? d : w) / 2, O.z + cz + (Math.abs(Math.sin(ry)) > 0.5 ? w : d) / 2, kind === 'concession' ? 3.2 : h); cols.push(oo); void e;
  };
  const zoneKind = (x, z) => (x > 300 && x < 640 && z > -110 && z < 55 ? 'tour' : x > -250 && x < 520 && z > -110 && z < 115 ? 'centre' : z < -260 ? (R() < 0.6 ? 'concession' : 'maison') : R() < 0.45 ? 'concession' : R() < 0.5 ? 'maison' : 'immeuble');
  const dens = quality === 'low' ? 0.55 : quality === 'high' ? 0.95 : 0.8;
  const xs = [-470, ...NS.map((n) => n[0]), 1290], zs = [-800, -560, -330, -110, 60, 120];
  for (let i = 0; i < xs.length - 1; i++) for (let j = 0; j < zs.length - 1; j++) {
    const bx0 = xs[i] + 8, bx1 = xs[i + 1] - 8, bz0 = zs[j] + 8, bz1 = zs[j + 1] - 8; if (bx1 - bx0 < 20 || bz1 - bz0 < 20) continue;
    const place = (x, z, w, d, ry) => { const hw = (Math.abs(Math.sin(ry)) > 0.5 ? d : w) / 2 + 1, hd = (Math.abs(Math.sin(ry)) > 0.5 ? w : d) / 2 + 1;
      if (R() > dens || isRes(x - hw, z - hd, x + hw, z + hd) || roadAt(x, z, Math.max(hw, hd)) || inLag(x, z) || inLag(x - hw, z) || inLag(x + hw, z) || z + hd > LOME.COAST - 40) return; building(x, z, w, d, ry, zoneKind(x, z)); reserve(x - hw, z - hd, x + hw, z + hd); };
    for (let x = bx0 + 8; x < bx1 - 6; x += 15) { const w = 9 + R() * 4, d = 9 + R() * 4; place(x, bz1 - d / 2 - 1, w, d, 0); place(x, bz0 + d / 2 + 1, w, d, PI); }
    for (let z = bz0 + 22; z < bz1 - 20; z += 15) { const w = 9 + R() * 4, d = 9 + R() * 4; place(bx0 + d / 2 + 1, z, w, d, -PI / 2); place(bx1 - d / 2 - 1, z, w, d, PI / 2); }
  }
  // ---- arbres, cocotiers, lampadaires ----
  const tree = (x, z, h, r, palm) => { parts.push(colorize(new THREE.CylinderGeometry(0.16, 0.28, h, 5).translate(x, h / 2, z), 0x6a5236)); parts.push(colorize(palm ? new THREE.ConeGeometry(2.8, 1.4, 7).translate(x, h + 0.3, z) : new THREE.SphereGeometry(r, 7, 5).translate(x, h + r * 0.4, z), palm ? 0x3f7a2a : 0x2f6a2a)); circle(x, z, 0.35, h); };
  for (let x = LOME.X0 + 20; x < 1280; x += 22) { tree(x + 4, 129.5, 8 + R() * 3, 0, true); }
  const lamp = (x, z, ry) => { const m = new THREE.Matrix4().makeRotationY(ry).setPosition(x, 0, z); parts.push(colorize(new THREE.CylinderGeometry(0.07, 0.1, 7, 6).translate(0, 3.5, 0).applyMatrix4(m), 0x5a5e64)); parts.push(colorize(new THREE.BoxGeometry(0.08, 0.08, 1.8).translate(0, 6.9, 0.85).applyMatrix4(m), 0x5a5e64)); heads.push(new THREE.BoxGeometry(0.35, 0.15, 0.7).translate(0, 6.85, 1.7).applyMatrix4(m)); circle(x, z, 0.18, 7); lamps.push([x + Math.sin(ry) * 1.7, z + Math.cos(ry) * 1.7]); };
  for (const [x0, z0, x1, , w, name] of EW) for (let x = x0 + 15, k = 0; x < x1 - 10; x += 34, k++) { const s = k % 2 ? 1 : -1, z = z0 + s * (w / 2 + 0.7); if (isRes(x - 1, z - 1, x + 1, z + 1) || NS.some((n) => Math.abs(n[0] - x) < 9) || nearRing(x, z, 8) || inLag(x, z)) continue; if (name === 'Boulevard du Mono' && s > 0) continue; lamp(x, z, s > 0 ? PI : 0); }
  for (const [x0] of NS) for (let z = -780, k = 0; z < 100; z += 34, k++) { const s = k % 2 ? 1 : -1, x = x0 + s * 5.7; if (isRes(x - 1, z - 1, x + 1, z + 1) || EW.some((e) => Math.abs(e[1] - z) < 9) || nearRing(x, z, 8) || inLag(x, z) || (z > LOME.LAG.z0 - 8 && z < LOME.LAG.z1 + 8)) continue; lamp(x, z, s > 0 ? -PI / 2 : PI / 2); }
  // ---- drapeau du Togo (5 bandes vert/jaune, canton rouge à étoile blanche) ----
  const flagTex = (() => { const c = document.createElement('canvas'); c.width = 300; c.height = 186; const x = c.getContext('2d'); for (let i = 0; i < 5; i++) { x.fillStyle = i % 2 ? '#ffce00' : '#006a4e'; x.fillRect(0, i * 37.2, 300, 37.4); } x.fillStyle = '#d21034'; x.fillRect(0, 0, 112, 112); x.fillStyle = '#fff'; x.beginPath(); for (let k = 0; k < 10; k++) { const r = k % 2 ? 15 : 38, a = -PI / 2 + k * PI / 5; x.lineTo(56 + Math.cos(a) * r, 56 + Math.sin(a) * r); } x.fill(); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t; })();
  const flags = new THREE.Group(); g.add(flags);
  const flag = (x, z, h = 9) => { parts.push(colorize(new THREE.CylinderGeometry(0.06, 0.08, h, 6).translate(x, h / 2, z), 0xd8dde2)); const f = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 1.5), new THREE.MeshBasicMaterial({ map: flagTex, side: THREE.DoubleSide })); f.position.set(x + 1.25, h - 0.9, z); flags.add(f); circle(x, z, 0.12, h); };
  const label = (t, sub, w, h, bg, fg) => { const c = document.createElement('canvas'); c.width = 1024; c.height = Math.max(64, Math.round(1024 * h / w)); const x = c.getContext('2d'); x.fillStyle = bg; x.fillRect(0, 0, c.width, c.height); x.fillStyle = fg; x.textAlign = 'center'; x.textBaseline = 'middle'; x.font = `900 ${Math.round(c.height * (sub ? 0.38 : 0.55))}px Arial`; x.fillText(t, c.width / 2, c.height * (sub ? 0.38 : 0.52), c.width - 30); if (sub) { x.font = `700 ${Math.round(c.height * 0.2)}px Arial`; x.fillText(sub, c.width / 2, c.height * 0.78, c.width - 30); } const tx = new THREE.CanvasTexture(c); tx.colorSpace = THREE.SRGBColorSpace; return new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ map: tx, side: THREE.DoubleSide })); };
  const put = (mesh, x, y, z, ry = 0) => { mesh.position.set(x, y, z); mesh.rotation.y = ry; g.add(mesh); return mesh; };
  const roadSign = (t, x, z, ry) => { parts.push(colorize(new THREE.CylinderGeometry(0.05, 0.05, 3, 6).translate(x, 1.5, z), 0x8a8f96)); put(label(t, '', 3.2, 0.7, '#1f4e9c', '#ffffff'), x, 3.1, z, ry); circle(x, z, 0.1, 3); };
  // ---- Monument de l'Indépendance (interprétation stylisée) sur son esplanade ----
  box(M.x - 38, 0.03, M.z - 42, M.x + 38, 0.09, M.z + 38, 0xd8d0c0); box(M.x - 9, 0.09, M.z - 9, M.x + 9, 0.8, M.z + 9, 0xe8e4dc); box(M.x - 6.5, 0.8, M.z - 6.5, M.x + 6.5, 1.5, M.z + 6.5, 0xf2f0ea); solid(M.x - 9, M.z - 9, M.x + 9, M.z + 9, 1.5);
  box(M.x - 3.2, 1.5, M.z - 1.6, M.x - 1.2, 22, M.z + 1.6, 0xf6f6f2); box(M.x + 1.2, 1.5, M.z - 1.6, M.x + 3.2, 22, M.z + 1.6, 0xf6f6f2); box(M.x - 3.2, 22, M.z - 1.6, M.x + 3.2, 24, M.z + 1.6, 0xf6f6f2); solid(M.x - 3.3, M.z - 1.7, M.x + 3.3, M.z + 1.7, 24);
  { const st = new THREE.Group(), br = new THREE.MeshStandardMaterial({ color: 0x8a6a3a, metalness: 0.6, roughness: 0.4 }); const body = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.55, 3.4, 8), br); body.position.y = 1.7; st.add(body); const head = new THREE.Mesh(new THREE.SphereGeometry(0.42, 10, 8), br); head.position.y = 3.75; st.add(head); for (const s of [-1, 1]) { const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 2.2, 6), br); arm.position.set(s * 0.75, 4.2, 0); arm.rotation.z = -s * 0.55; st.add(arm); } st.position.set(M.x, 9, M.z + 0.2); g.add(st); }
  for (const [dx, dz] of [[-22, -28], [22, -28], [-22, 26], [22, 26]]) { box(M.x + dx - 4, 0.09, M.z + dz - 3, M.x + dx + 4, 0.6, M.z + dz + 3, 0xd8d0c0); box(M.x + dx - 3.6, 0.5, M.z + dz - 2.6, M.x + dx + 3.6, 0.56, M.z + dz + 2.6, 0x4aa8d8, glow); solid(M.x + dx - 4, M.z + dz - 3, M.x + dx + 4, M.z + dz + 3, 0.6); }
  for (const dx of [-14, 14]) flag(M.x + dx, M.z + 14);
  put(label('MONUMENT DE L’INDÉPENDANCE', 'Place de l’Indépendance • représentation stylisée', 7, 1.2, '#006a4e', '#ffffff'), M.x, 2.6, M.z + 18);
  Pt(M.x, M.z + 13, 3, '🏛️ Visiter : Monument de l’Indépendance', () => ctx.visit('monument'));
  // ---- Grand Marché (Assigamé) et étals ----
  box(mk.x - 28, 0, 76, mk.x + 28, 9.5, 106, 0xd8c8a8); box(mk.x - 29, 9.5, 75, mk.x + 29, 10.2, 107, 0x8a8a86); for (let k = 0; k < 3; k++) box(mk.x - 28.2, 2.6 + k * 3.1, 105.9, mk.x + 28.2, 3.0 + k * 3.1, 106.4, 0x1f6a3a); solid(mk.x - 28, 76, mk.x + 28, 106, 10);
  put(label('GRAND MARCHÉ DE LOMÉ', 'Assigamé • représentation stylisée', 10, 1.4, '#ffce00', '#1a1a1a'), mk.x, 7.6, 106.6);
  for (let k = 0; k < 8; k++) { const x = mk.x - 26 + k * 7.4, z = 67 + (k % 2) * 1.5; box(x - 1.4, 0, z - 0.9, x + 1.4, 0.85, z + 0.9, 0x8a6440); parts.push(colorize(new THREE.ConeGeometry(1.9, 0.8, 8).translate(x, 2.7, z), [0xe8112d, 0xfcd116, 0x0b6e4f, 0x1f4e9c][k % 4])); parts.push(colorize(new THREE.CylinderGeometry(0.04, 0.04, 2.3, 4).translate(x, 1.15, z), 0x5a4228)); for (let j = 0; j < 3; j++) box(x - 1.1 + j * 0.8, 0.85, z - 0.6, x - 0.6 + j * 0.8, 1.1, z + 0.6, [0xc8102e, 0xf2c200, 0x2fb04a, 0x7a2a8a][(j + k) % 4]); solid(x - 1.4, z - 0.9, x + 1.4, z + 0.9, 1); }
  Pt(mk.x, 72.5, 3.5, '🛍️ Grand Marché de Lomé : acheter', () => ctx.market('marche'));
  // ---- Cathédrale du Sacré-Cœur (stylisée) ----
  { const cx = P.cathedrale.x, cz = P.cathedrale.z; box(cx - 7, 0, cz - 14, cx + 7, 10, cz + 12, 0xf2ecd8); parts.push(colorize(new THREE.CylinderGeometry(0.01, 7.6, 4.5, 4).rotateY(PI / 4).scale(1, 1, 1.85).translate(cx, 12.2, cz - 1), 0x9a6a4a)); for (const s of [-1, 1]) { box(cx + s * 4.5 - 2, 0, cz + 10, cx + s * 4.5 + 2, 20, cz + 14, 0xf2ecd8); parts.push(colorize(new THREE.ConeGeometry(2.4, 6, 4).rotateY(PI / 4).translate(cx + s * 4.5, 23, cz + 12), 0x6a4a3a)); }
    box(cx - 1.4, 0, cz + 13.9, cx + 1.4, 4.2, cz + 14.05, 0x5a3a22); solid(cx - 7, cz - 14, cx + 7, cz + 14, 20); put(label('CATHÉDRALE DU SACRÉ-CŒUR', 'représentation stylisée', 6, 1, '#f2ecd8', '#3a2a1a'), cx, 5.4, cz + 14.2); Pt(cx, cz + 17, 2.6, '⛪ Cathédrale du Sacré-Cœur de Lomé', () => ctx.visit('cathedrale')); }
  // ---- hôtel fictif, restaurants fictifs, centre commercial fictif, stations ----
  { const h = P.hotel; box(h.x - 22, 0, 72, h.x + 22, 18.6, 100, 0xf4f0e6); for (let f = 1; f < 6; f++) box(h.x - 21, f * 3.1, 100, h.x + 21, f * 3.1 + 0.2, 101.4, 0x1f6a3a); solid(h.x - 22, 72, h.x + 22, 100, 19); put(label('HÔTEL BAIE DE LOMÉ', 'hôtel fictif', 8, 1.2, '#1f6a3a', '#ffce00'), h.x, 16, 101.5); Pt(h.x, 104.5, 2.6, '🏨 Hôtel Baie de Lomé (fictif) : réception', () => ctx.hotel()); }
  { const r = { x: P.plage.x, z: 148 }; box(r.x - 6, 0, r.z - 4, r.x + 6, 0.8, r.z + 4, 0x8a6440); parts.push(colorize(new THREE.ConeGeometry(8.5, 2.6, 8).translate(r.x, 4.2, r.z), 0xb89a5a)); for (const [a, b] of [[-5, -3.5], [5, -3.5], [-5, 3.5], [5, 3.5]]) parts.push(colorize(new THREE.CylinderGeometry(0.1, 0.1, 3, 5).translate(r.x + a, 1.5, r.z + b), 0x5a4228)); solid(r.x - 6, r.z - 4, r.x + 6, r.z + 4, 0.9);
    put(label('LA PAILLOTE DU MONO', 'restaurant fictif', 4, 0.8, '#8a2a2a', '#ffffff'), r.x, 2.4, r.z - 4.3, PI); Pt(r.x, r.z - 6.5, 2.4, '🍲 La Paillote du Mono (fictive) : manger', () => ctx.restaurant('La Paillote du Mono')); Pt(r.x + 20, 152, 3, '🌴 Plage de Lomé', () => ctx.visit('plage')); }
  { const s = P.mall; box(s.x - 38, 0, s.z - 36, s.x + 38, 8, s.z + 36, 0xe8e0d0); box(s.x - 39, 8, s.z - 37, s.x + 39, 8.6, s.z + 37, 0x1f4e9c); box(s.x - 30, 0.2, s.z + 36, s.x + 30, 6, s.z + 36.2, 0x2a4a5a); solid(s.x - 38, s.z - 36, s.x + 38, s.z + 36, 8.6); put(label('LOMÉ CENTRE', 'centre commercial fictif', 9, 1.3, '#1f4e9c', '#ffffff'), s.x, 7, s.z + 36.6); Pt(s.x, s.z + 39, 3, '🛒 Centre commercial Lomé Centre (fictif)', () => ctx.market('mall')); }
  for (const [sx, sz] of [[560, 85], [-300, -582]]) { box(sx - 18, 0, sz - 14, sx + 18, 0.05, sz + 14, 0x4a4d52); for (const dx of [-6, 6]) { box(sx + dx - 0.6, 0, sz - 1, sx + dx + 0.6, 1.8, sz + 1, 0xd8dde2); solid(sx + dx - 0.6, sz - 1, sx + dx + 0.6, sz + 1, 1.8); } box(sx - 12, 4.4, sz - 6, sx + 12, 4.8, sz + 6, 0xe8112d); for (const [a, b] of [[-11, -5], [11, -5], [-11, 5], [11, 5]]) { box(sx + a - 0.2, 0, sz + b - 0.2, sx + a + 0.2, 4.4, sz + b + 0.2, 0xd8dde2); circle(sx + a, sz + b, 0.25, 4.4); } box(sx + 10, 0, sz - 13, sx + 17, 3, sz - 6, 0xf4f0e6); solid(sx + 10, sz - 13, sx + 17, sz - 6, 3);
    put(label('STATION ÉTOILE', 'station-service fictive', 5, 0.9, '#e8112d', '#ffffff'), sx, 5.4, sz + 6.2); Pt(sx + 13.5, sz - 4.5, 2.2, '⛽ Station Étoile (fictive) : boutique', () => ctx.shopStation()); }
  { const rx = 640, rz = -125; box(rx - 8, 0, rz - 6, rx + 8, 3.4, rz + 5, 0xd8a860); box(rx - 9, 3.4, rz - 7, rx + 9, 3.7, rz + 7, 0x9a5a3a); solid(rx - 8, rz - 6, rx + 8, rz + 5, 3.4); put(label('MAQUIS AKPÉ', 'restaurant fictif', 4, 0.8, '#1f6a3a', '#ffce00'), rx, 2.6, rz + 5.1); Pt(rx, rz + 8, 2.4, '🍲 Maquis Akpé (fictif) : manger', () => ctx.restaurant('Maquis Akpé')); }
  // ---- marché des féticheurs d'Akodessawa ----
  { const a = P.akodessawa; for (let k = 0; k < 6; k++) { const x = a.x - 28 + (k % 3) * 18, z = a.z - 12 + Math.floor(k / 3) * 18; box(x - 4, 0, z - 2.4, x + 4, 0.9, z + 2.4, 0x6a4a32); for (const [p, q] of [[-4, -2.4], [4, -2.4], [-4, 2.4], [4, 2.4]]) box(x + p - 0.1, 0, z + q - 0.1, x + p + 0.1, 2.6, z + q + 0.1, 0x5a4228); box(x - 4.6, 2.6, z - 3, x + 4.6, 2.75, z + 3, 0x8a8a86); for (let j = 0; j < 6; j++) { const c2 = [0xc8a070, 0x5a3a22, 0xe8dcc0, 0x8a2a2a, 0x2a2a2a, 0x6a8a3a][j]; parts.push(colorize(new THREE.SphereGeometry(0.25, 6, 5).translate(x - 3.2 + j * 1.3, 1.15, z - 0.8), c2)); box(x - 3.4 + j * 1.3, 0.9, z + 0.4, x - 3.0 + j * 1.3, 1.5, z + 0.8, c2); } solid(x - 4, z - 2.4, x + 4, z + 2.4, 1); }
    put(label('MARCHÉ DES FÉTICHEURS D’AKODESSAWA', 'Marché vodun • respect des croyances • représentation stylisée', 9, 1.3, '#3a2a1a', '#f2e6c8'), a.x - 10, 3.4, a.z + 24); Pt(a.x - 10, a.z + 21, 3, '🪬 Visiter : Marché des féticheurs d’Akodessawa', () => ctx.visit('akodessawa')); }
  // ---- port autonome (décor) : quais, entrepôts, grues, conteneurs ----
  box(LOME.QUAY.x0, -0.05, LOME.QUAY.z0, LOME.QUAY.x1, 0.6, LOME.QUAY.z1, 0xb8b4ac); for (let k = 0; k < 3; k++) { box(1310 + k * 78, 0, 20, 1370 + k * 78, 9, 108, 0xc8ccd2); box(1308 + k * 78, 9, 18, 1372 + k * 78, 9.6, 110, 0x5a6a7a); solid(1310 + k * 78, 20, 1370 + k * 78, 108, 9.6); }
  for (let k = 0; k < 4; k++) { const x = 1330 + k * 60, z = 240; for (const dx of [-5, 5]) for (const dz of [-3, 3]) box(x + dx - 0.4, 0.6, z + dz - 0.4, x + dx + 0.4, 26, z + dz + 0.4, 0xe8b020); box(x - 6, 26, z - 14, x + 6, 28, z + 6, 0xe8b020); solid(x - 6, z - 4, x + 6, z + 4, 28); }
  for (let k = 0; k < 40; k++) { const x = 1315 + (k % 10) * 22, z = 150 + Math.floor(k / 10) * 18, ht = 1 + ((k * 7) % 3); for (let y = 0; y < ht; y++) box(x - 6, 0.6 + y * 2.6, z - 1.2, x + 6, 3.2 + y * 2.6, z + 1.2, [0xc8102e, 0x1f4e9c, 0x0b6e4f, 0xe8b020, 0x8a8f96][(k + y) % 5]); solid(x - 6, z - 1.2, x + 6, z + 1.2, 0.6 + ht * 2.6); }
  put(label('PORT AUTONOME DE LOMÉ', 'décor • transport maritime à une étape suivante', 9, 1.3, '#1f4e9c', '#ffffff'), 1300, 4, 116, -PI / 2);
  Pt(1290, 100, 3, '⚓ Port autonome de Lomé', () => ctx.toast('⚓ Port autonome de Lomé (port en eau profonde). Les ferries et bateaux de passagers arriveront à une étape suivante de la mission.', 4.5));
  // ---- aéroport international (stylisé) : aérogare, piste orientée nord-est, avions ----
  { const a = P.aeroport; box(a.x - 60, 0, a.z - 26, a.x + 60, 11, a.z + 6, 0xe8e4dc); box(a.x - 62, 11, a.z - 28, a.x + 62, 12, a.z + 8, 0x1f6a3a); box(a.x - 50, 0.4, a.z + 6, a.x + 50, 7, a.z + 6.2, 0x2a4a5a); solid(a.x - 60, a.z - 26, a.x + 60, a.z + 6, 12);
    put(label('AÉROPORT INTERNATIONAL GNASSINGBÉ EYADÉMA', 'Lomé-Tokoin • représentation stylisée', 14, 1.6, '#1f6a3a', '#ffffff'), a.x, 9, a.z + 6.4); for (const dx of [-30, 30]) flag(a.x + dx, a.z + 22);
    const rw = new THREE.BoxGeometry(30, 0.06, 600).rotateY(-0.7).translate(900, 0.06, -880); parts.push(colorize(rw, 0x3a3c40)); box(a.x - 60, 0.03, a.z - 120, a.x + 160, 0.05, a.z - 26, 0x5a5c60);
    for (const [px, pz] of [[a.x - 20, a.z - 70], [a.x + 70, a.z - 75]]) { box(px - 1.6, 1.2, pz - 16, px + 1.6, 4.2, pz + 16, 0xf4f4f2); box(px - 15, 2.2, pz - 2, px + 15, 2.6, pz + 3, 0xd8dde2); box(px - 0.2, 4.2, pz - 16, px + 0.2, 8, pz - 12, 0x1f6a3a); solid(px - 1.8, pz - 16, px + 1.8, pz + 16, 4.5); }
    Pt(a.x, a.z + 10, 3.5, '✈️ Aérogare : vols, jet privé', () => ctx.airport()); }
  // ---- université, hôpital, école, gare routière ----
  { const u = P.universite; for (const [dx, dz, w, d, hh] of [[-60, -40, 50, 18, 12], [20, -40, 40, 18, 9], [-60, 30, 30, 30, 6], [40, 30, 50, 20, 9]]) { box(u.x + dx - w / 2, 0, u.z + dz - d / 2, u.x + dx + w / 2, hh, u.z + dz + d / 2, 0xe8dcc0); for (let f = 1; f * 3 < hh; f++) box(u.x + dx - w / 2, f * 3, u.z + dz + d / 2, u.x + dx + w / 2, f * 3 + 0.3, u.z + dz + d / 2 + 0.6, 0x8a2a2a); solid(u.x + dx - w / 2, u.z + dz - d / 2, u.x + dx + w / 2, u.z + dz + d / 2, hh); }
    put(label('UNIVERSITÉ DE LOMÉ', 'campus • représentation stylisée', 8, 1.2, '#8a2a2a', '#ffffff'), u.x, 3.4, u.z + 106); for (const s of [-6, 6]) { box(u.x + s - 0.4, 0, u.z + 105.6, u.x + s + 0.4, 4.4, u.z + 106.4, 0xe8dcc0); circle(u.x + s, u.z + 106, 0.5, 4.4); } Pt(u.x, u.z + 109, 3, '🎓 Université de Lomé', () => ctx.visit('universite')); }
  { const h = P.hopital; box(h.x - 36, 0, h.z - 30, h.x + 36, 9.3, h.z + 30, 0xf4f4f2); box(h.x - 4, 9.3, h.z - 4, h.x + 4, 9.5, h.z + 4, 0xe8112d); solid(h.x - 36, h.z - 30, h.x + 36, h.z + 30, 9.5); put(label('CENTRE HOSPITALIER UNIVERSITAIRE', 'Tokoin • représentation stylisée', 9, 1.2, '#ffffff', '#c8102e'), h.x, 7.2, h.z + 30.2); Pt(h.x, h.z + 33, 3, '🏥 Centre hospitalier : consultation', () => ctx.hospital()); }
  { const e = { x: 520 - 60, z: -470 }; box(e.x - 25, 0, e.z - 12, e.x + 25, 3.4, e.z + 2, 0xf0e4c8); box(e.x - 26, 3.4, e.z - 13, e.x + 26, 3.7, e.z + 3, 0x9a5a3a); solid(e.x - 25, e.z - 12, e.x + 25, e.z + 2, 3.7); box(e.x - 25, 0, e.z + 2, e.x + 25, 0.04, e.z + 25, 0xc8a070); put(label('ÉCOLE PRIMAIRE PUBLIQUE', 'établissement stylisé', 6, 1, '#1f6a3a', '#ffffff'), e.x, 2.6, e.z + 2.1); Pt(e.x, e.z + 6, 2.6, '🎒 École primaire publique', () => ctx.visit('ecole')); flag(e.x + 20, e.z + 18, 7); }
  { const s = P.gare; box(s.x - 42, 0, s.z - 32, s.x + 42, 0.05, s.z + 32, 0x5a5c60); box(s.x - 30, 4, s.z - 20, s.x + 30, 4.4, s.z - 8, 0x8a8a86); for (const dx of [-28, 0, 28]) { box(s.x + dx - 0.3, 0, s.z - 20, s.x + dx + 0.3, 4, s.z - 19.4, 0x5a5e64); circle(s.x + dx, s.z - 19.7, 0.4, 4); }
    for (const [bx, bz] of [[s.x - 25, s.z + 8], [s.x + 5, s.z + 8]]) { box(bx - 6, 0.4, bz - 1.4, bx + 6, 3.4, bz + 1.4, 0xf2c200); box(bx - 5.6, 1.8, bz + 1.4, bx + 5.6, 2.8, bz + 1.45, 0x2a3a44); solid(bx - 6, bz - 1.4, bx + 6, bz + 1.4, 3.4); }
    put(label('GARE ROUTIÈRE DE LOMÉ', 'bus et taxis-brousse • représentation stylisée', 8, 1.2, '#2a2d33', '#ffce00'), s.x, 5.4, s.z - 7.8); Pt(s.x, s.z - 4, 3, '🚌 Gare routière : bus interurbains', () => ctx.busStation()); }
  // ---- frontière du Ghana (poste inspiré de Kodjoviakopé–Aflao) et sortie vers le Bénin ----
  { const f = P.frontiere; box(f.x - 6, 0, 70, f.x + 18, 4, 100, 0xf0e4c8); solid(f.x - 6, 70, f.x + 18, 100, 4); box(f.x + 4, 1, 104, f.x + 4.3, 1.2, 126, 0xe8112d); put(label('POSTE-FRONTIÈRE TOGO – GHANA', 'inspiré de Kodjoviakopé–Aflao • Ghana en développement', 8, 1.2, '#006a4e', '#ffffff'), f.x + 6, 5.2, 100.3); flag(f.x + 14, 106); Pt(f.x + 10, 112, 3, '🛂 Frontière du Ghana', () => ctx.border('ghana')); }
  { const e = P.sortieEst; roadSign('← Aného • Bénin (RN2)', e.x - 10, 104, 0); Pt(e.x, e.z, 4, '🛣️ Route nationale 2 vers Aného et le Bénin', () => ctx.border('benin')); }
  roadSign('↑ Kara • Dapaong • Burkina Faso (RN1)', 96.5, -793.5, 0); Pt(90, -800, 5, '🛣️ Route nationale 1 vers Kara, Dapaong et le Burkina Faso', () => ctx.border('burkina'));
  roadSign('Boulevard du Mono', 0, 104.5, 0); roadSign('Aéroport ↑', 760, -100, 0); roadSign('Port autonome →', 1180, 104.5, 0); roadSign('Frontière Ghana ←', -380, 104.5, 0); roadSign('Bd du 13 Janvier', RING.cx - 3, RING.cz - RING.r + 12, 0);
  // ---- stations de taxis ----
  for (const [x, z, n] of TAXIS) { put(label('TAXI', '', 1.2, 0.5, '#f2c200', '#1a1a1a'), x, 2.4, z, 0); parts.push(colorize(new THREE.CylinderGeometry(0.05, 0.05, 2.2, 5).translate(x, 1.1, z), 0x5a5e64)); circle(x, z, 0.1, 2.2); Pt(x, z + 1.4, 2.2, `🚕 Station de taxis (${n})`, () => ctx.taxi()); }
  // ---- maillage final ----
  const mkm = (arr, mat) => { if (!arr.length) return null; const ms = new THREE.Mesh(mergeGeometries(arr), mat); ms.receiveShadow = true; ms.castShadow = mat !== ctx.glowMat; g.add(ms); return ms; };
  mkm(parts, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.85 })); mkm(glow, new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false }));
  if (heads.length) { for (const h of heads) for (const k of Object.keys(h.attributes)) if (!['position', 'normal'].includes(k)) h.deleteAttribute(k); g.add(new THREE.Mesh(mergeGeometries(heads), ctx.lampMat)); const pool = new THREE.InstancedMesh(new THREE.PlaneGeometry(13, 13).rotateX(-PI / 2), ctx.poolMat, lamps.length), dm = new THREE.Object3D(); lamps.forEach(([x, z], i) => { dm.position.set(x, 0.07, z); dm.updateMatrix(); pool.setMatrixAt(i, dm.matrix); }); pool.renderOrder = 2; g.add(pool); }
  for (const [t, arr] of Object.entries(signs)) { const c = document.createElement('canvas'); c.width = 512; c.height = 64; const x = c.getContext('2d'); x.fillStyle = '#f6f2e6'; x.fillRect(0, 0, 512, 64); x.fillStyle = '#1a2a44'; x.font = '900 36px Arial'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(t, 256, 34, 500); const tx = new THREE.CanvasTexture(c); tx.colorSpace = THREE.SRGBColorSpace; const mm = new THREE.Mesh(mergeGeometries(arr), new THREE.MeshBasicMaterial({ map: tx })); g.add(mm); }
  // ---- trottoirs empruntés par les piétons : segments libres le long des axes ----
  const free = (x, z) => ![[0, 0], [0.4, 0], [-0.4, 0], [0, 0.4], [0, -0.4]].some(([a, b]) => C.pointBlocked(O.x + x + a, 0.5, O.z + z + b)) && !inLag(x, z);
  const runs = (ax, az, bx, bz) => { const L2 = Math.hypot(bx - ax, bz - az), n = Math.floor(L2 / 2), out = []; let st = null; for (let i = 0; i <= n; i++) { const t = i / n, x = ax + (bx - ax) * t, z = az + (bz - az) * t; if (free(x, z)) { if (!st) st = [x, z]; } else if (st) { if (Math.hypot(x - st[0], z - st[1]) > 30) out.push([st, [ax + (bx - ax) * ((i - 1) / n), az + (bz - az) * ((i - 1) / n)]]); st = null; } } if (st && Math.hypot(bx - st[0], bz - st[1]) > 30) out.push([st, [bx, bz]]); return out; };
  for (const [x0, z0, x1, , w] of EW) for (const s of [-1, 1]) lanes.push(...runs(x0 + 5, z0 + s * (w / 2 + 2), x1 - 5, z0 + s * (w / 2 + 2)));
  for (const [x0, , , , w] of NS) for (const s of [-1, 1]) lanes.push(...runs(x0 + s * (w / 2 + 2), -790, x0 + s * (w / 2 + 2), 110));
  // carte du secteur (mini-carte et grande carte)
  const S = 0.5, W = LOME.X1 - LOME.X0 + 80, H = 1500, cv = document.createElement('canvas'); cv.width = Math.round(W * S); cv.height = Math.round(H * S); const x = cv.getContext('2d'), T = (lx, lz) => [(lx - LOME.X0 + 40) * S, (lz - LOME.Z0 + 40) * S];
  x.fillStyle = '#a89a6a'; x.fillRect(0, 0, cv.width, cv.height); { const [, sy] = T(0, LOME.COAST); x.fillStyle = '#e8d6a8'; x.fillRect(0, T(0, 132)[1], cv.width, sy - T(0, 132)[1]); x.fillStyle = '#2a7a92'; x.fillRect(0, sy, cv.width, cv.height); }
  { const [a, b] = T(LOME.LAG.x0, LOME.LAG.z0), [c2, d] = T(LOME.LAG.x1, LOME.LAG.z1); x.fillStyle = '#3a7a6a'; x.fillRect(a, b, c2 - a, d - b); }
  x.fillStyle = '#d8ccb0'; for (const r of reserved) { const [a, b] = T(r.x0, r.z0), [c2, d] = T(r.x1, r.z1); x.fillRect(a, b, c2 - a, d - b); }
  x.strokeStyle = '#4d4f55'; x.lineCap = 'round'; for (const [x0, z0, x1, z1, w] of [...EW, ...NS]) { x.lineWidth = w * S * 1.3; x.beginPath(); x.moveTo(...T(x0, z0)); x.lineTo(...T(x1, z1)); x.stroke(); }
  x.lineWidth = 12 * S * 1.3; x.beginPath(); ringPts.forEach((p, i) => (i ? x.lineTo(...T(p[0], p[1])) : x.moveTo(...T(p[0], p[1])))); x.stroke();
  { const [a, b] = T(LOME.QUAY.x0, LOME.QUAY.z0), [c2, d] = T(LOME.QUAY.x1, LOME.QUAY.z1); x.fillStyle = '#b8b4ac'; x.fillRect(a, b, c2 - a, d - b); }
  x.save(); x.translate(...T(900, -880)); x.rotate(0.7); x.fillStyle = '#3a3c40'; x.fillRect(-15 * S, -300 * S, 30 * S, 600 * S); x.restore();
  return { group: g, cols, points, lanes, map: { canvas: cv, X0: O.x + LOME.X0 - 40, Z0: O.z + LOME.Z0 - 40, W, H, S, has: LOME.has } };
}
export const LOME_PLACES = P;
export const LOME_QUARTIERS = QUARTIERS;
export const LOME_NAMES = NAMES;
