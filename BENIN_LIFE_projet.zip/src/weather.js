// Mission 008 — météo dynamique : ciel dégagé, nuages, pluie tropicale (averses + orages), brume légère,
// sol mouillé qui sèche progressivement. Tout est procédural et peu coûteux :
// la pluie est un seul maillage de segments animé entièrement dans le shader (aucun calcul CPU par goutte).
import * as THREE from 'three';
import { globalUniforms } from './shaderfx.js';
import { clamp, damp } from './util.js';

export const WEATHERS = {
  clear: { label: 'Dégagé', icon: '☀', cover: 0.56, overcast: 0, rain: 0, fog: 0 },
  cloudy: { label: 'Nuageux', icon: '⛅', cover: 0.34, overcast: 0.5, rain: 0, fog: 0.08 },
  rain: { label: 'Pluie tropicale', icon: '🌧', cover: 0.1, overcast: 1, rain: 1, fog: 0.42 },
  fog: { label: 'Brume légère', icon: '🌫', cover: 0.5, overcast: 0.3, rain: 0, fog: 1 },
};
export const WEATHER_MODES = ['auto', 'clear', 'cloudy', 'rain', 'fog'];

const rainVert = /* glsl */`
uniform float uTime; uniform vec3 uCam; uniform float uRain; uniform vec2 uWind;
attribute vec4 aSeed; attribute float aEnd;
varying float vA;
void main() {
  const float S = 44.0; const float H = 26.0;
  float speed = 17.0 + aSeed.w * 7.0;
  vec3 vel = vec3(uWind.x, -speed, uWind.y);
  // gouttes fixes dans le monde, réparties dans une boîte qui suit la caméra
  float t = uTime;
  vec3 p;
  p.x = aSeed.x * S + vel.x * t; p.z = aSeed.y * S + vel.z * t;
  p.x = uCam.x + (fract((p.x - uCam.x) / S) - 0.5) * S;
  p.z = uCam.z + (fract((p.z - uCam.z) / S) - 0.5) * S;
  p.y = uCam.y - 8.0 + mod(aSeed.z * H - t * speed, H);
  p -= vel * 0.045 * aEnd; // traînée
  vA = step(aSeed.w, uRain) * (0.24 + 0.3 * aSeed.z);
  gl_Position = projectionMatrix * viewMatrix * vec4(p, 1.0);
}`;
const rainFrag = /* glsl */`
uniform vec3 uColor; varying float vA;
void main() { if (vA <= 0.0) discard; gl_FragColor = vec4(uColor, vA); }`;

const rand = (a, b) => a + Math.random() * (b - a);

export class Weather {
  constructor(scene) {
    this.scene = scene;
    this.mode = 'auto';           // 'auto' ou un type forcé
    this.current = 'clear';       // type visé actuellement
    this.p = { ...WEATHERS.clear }; // paramètres lissés (transition progressive)
    this.wet = 0;                 // humidité du sol 0..1
    this.next = rand(1.5, 3);     // heures de jeu avant le prochain changement automatique
    this.flash = 0;               // éclair
    this.nextFlash = rand(6, 14);
    this.indoor = false;
    this.onThunder = null;
    globalUniforms.uWet = globalUniforms.uWet || { value: 0 };

    this.rainMat = new THREE.ShaderMaterial({
      vertexShader: rainVert, fragmentShader: rainFrag, transparent: true, depthWrite: false, fog: false,
      uniforms: {
        uTime: globalUniforms.uTime, uCam: { value: new THREE.Vector3() }, uRain: { value: 0 },
        uWind: { value: new THREE.Vector2(1.6, 0.7) }, uColor: { value: new THREE.Color(0xc8d2dc) },
      },
    });
    this.rain = null;
    this.setQuality('medium');
  }

  setQuality(q) {
    const n = q === 'high' ? 7000 : q === 'medium' ? 3800 : 1600;
    if (this.rain && this.rain.userData.n === n) return;
    if (this.rain) { this.scene.remove(this.rain); this.rain.geometry.dispose(); }
    const seed = new Float32Array(n * 2 * 4), end = new Float32Array(n * 2), pos = new Float32Array(n * 2 * 3);
    for (let i = 0; i < n; i++) {
      const s = [Math.random(), Math.random(), Math.random(), Math.random()];
      for (let k = 0; k < 2; k++) { seed.set(s, (i * 2 + k) * 4); end[i * 2 + k] = k; }
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    g.setAttribute('aSeed', new THREE.BufferAttribute(seed, 4));
    g.setAttribute('aEnd', new THREE.BufferAttribute(end, 1));
    this.rain = new THREE.LineSegments(g, this.rainMat);
    this.rain.frustumCulled = false;
    this.rain.renderOrder = 2;
    this.rain.userData.n = n;
    this.rain.visible = false;
    this.scene.add(this.rain);
  }

  get label() { const w = WEATHERS[this.current]; return `${w.icon} ${w.label}`; }

  setMode(mode) {
    this.mode = WEATHER_MODES.includes(mode) ? mode : 'auto';
    if (this.mode !== 'auto') this.current = this.mode;
    else this.next = rand(1, 2.5);
  }

  // choix automatique : averses tropicales surtout l'après-midi, brume le matin près de la côte
  pickNext(hour) {
    const c = this.current, r = Math.random();
    const afternoon = hour >= 12.5 && hour <= 19, morning = hour >= 4 && hour <= 8.5;
    let n = c, dur = rand(1.5, 3.5);
    if (c === 'clear') { n = morning && r < 0.35 ? 'fog' : r < 0.55 ? 'cloudy' : 'clear'; }
    else if (c === 'cloudy') { n = r < (afternoon ? 0.6 : 0.38) ? 'rain' : r < 0.85 ? 'clear' : 'cloudy'; }
    else if (c === 'rain') { n = 'cloudy'; }
    else if (c === 'fog') { n = 'clear'; }
    if (n === 'rain') dur = rand(0.6, 1.6);
    else if (n === 'fog') dur = rand(1.5, 3);
    else if (n === 'cloudy') dur = rand(1, 2.5);
    this.current = n; this.next = dur;
  }

  // dt réel (s), dtHours : heures de jeu écoulées, day : 0 nuit .. 1 plein jour
  update(dt, dtHours, hour, day, camera) {
    if (this.mode === 'auto') {
      this.next -= dtHours;
      if (this.next <= 0) this.pickNext(hour);
      if (this.current === 'fog' && hour > 10.5) { this.current = 'clear'; this.next = rand(1.5, 3); } // la brume se lève
    }
    const tgt = WEATHERS[this.current], p = this.p;
    // transition progressive (~15 s réelles) ; la pluie démarre après l'assombrissement du ciel
    p.cover = damp(p.cover, tgt.cover, 0.09, dt);
    p.overcast = damp(p.overcast, tgt.overcast, 0.09, dt);
    p.fog = damp(p.fog, tgt.fog, 0.07, dt);
    const rainTarget = tgt.rain * clamp((p.overcast - 0.6) / 0.35, 0, 1);
    p.rain = damp(p.rain, rainTarget, rainTarget > p.rain ? 0.12 : 0.2, dt);

    // sol mouillé : se mouille vite sous la pluie, sèche en 1 à 3 h de jeu selon le soleil
    if (p.rain > 0.25) this.wet = Math.min(1, this.wet + dt * 0.07 * p.rain);
    else this.wet = Math.max(0, this.wet - dtHours * (0.35 + 0.65 * day) * (1 - p.overcast * 0.5));
    globalUniforms.uWet.value = this.wet;

    // éclairs pendant les fortes averses
    this.flash = Math.max(0, this.flash - dt * 4);
    if (p.rain > 0.8) {
      this.nextFlash -= dt;
      if (this.nextFlash <= 0) {
        this.nextFlash = rand(9, 26);
        this.flash = 1;
        if (this.onThunder) this.onThunder(rand(0.6, 3.2));
      }
    }

    const show = p.rain > 0.02 && !this.indoor;
    this.rain.visible = show;
    if (show) {
      const u = this.rainMat.uniforms;
      u.uRain.value = p.rain;
      u.uCam.value.copy(camera.position);
      u.uColor.value.setRGB(0.25 + 0.55 * day, 0.28 + 0.57 * day, 0.33 + 0.57 * day).addScalar(this.flash * 0.5);
    }
  }

  serialize() { return { mode: this.mode, current: this.current, p: { ...this.p }, wet: this.wet, next: this.next }; }
  restore(s) {
    if (!s) return;
    if (WEATHERS[s.current]) this.current = s.current;
    if (s.p) Object.assign(this.p, s.p);
    if (typeof s.wet === 'number') this.wet = s.wet;
    if (typeof s.next === 'number') this.next = s.next;
  }
}
