// Mission 019, étape 3 — personnel domestique de la VILLA NOVA.
// Recrutement par poste (2 agents d'entretien, jardinier, blanchisseur·se, responsable de maison ; le cuisinier est géré
// par cook.js et apparaît dans la même équipe), horaires et jour de repos, disponibilité, salaires en FCFA virtuels
// (compte personnel, tous les 7 jours de jeu), tâches attribuées par le joueur (application, conversation) ou
// planifiées chaque matin par le responsable de maison. Les tâches sont VISIBLES : l'employé se rend dans la pièce ou au
// jardin (couloirs de l'aile, allées de la parcelle), travaille avec son outil (balai, arrosoir, tondeuse, panier de
// linge, mallette), puis l'état de la maison s'améliore (propreté des pièces, jardin, piscine, linge, équipements).
import * as THREE from 'three';
import { createCharacter, SKINS } from './character.js';
import { fcfa } from './food-data.js';
import { VILLA, POOL } from './villa.js';

const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const norm = (s) => s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[’']/g, ' ');
const pick = (a) => a[Math.floor(Math.random() * a.length)];
export const ROLES = {
  entretien: { label: 'Agent d’entretien', fem: 'Agente d’entretien', icon: '🧹', slots: 2, hours: [7, 16], uniform: { shirtColor: 0x2f80ed, pants: 0x1f3a5a } },
  jardinier: { label: 'Jardinier', fem: 'Jardinière', icon: '🌿', slots: 1, hours: [6, 13], uniform: { shirtColor: 0x2f7a3a, pants: 0x3a4a2a, hat: 'straw' } },
  linge: { label: 'Blanchisseur', fem: 'Blanchisseuse', icon: '🧺', slots: 1, hours: [8, 17], uniform: { shirtColor: 0xb8a8e0, pants: 0x3a3a5a } },
  responsable: { label: 'Responsable de maison', fem: 'Responsable de maison', icon: '🗝️', slots: 1, hours: [7, 19], uniform: { shirtColor: 0xf4f4f4, pants: 0x1a1a1a, jacket: 0x1a1a1a, tie: 0xd8a830, collar: true } },
};
export const CANDIDATES = {
  entretien: [['ent1', 'Yolande Hounkpè', true, 34, 'Bohicon', 90000, 'méticuleuse, chante en travaillant'], ['ent2', 'Mathieu Dossou', false, 29, 'Cotonou', 85000, 'rapide et serviable'], ['ent3', 'Pascaline Gbénou', true, 41, 'Allada', 95000, '15 ans d’expérience dans un hôtel']],
  jardinier: [['jar1', 'Faustin Akakpo', false, 47, 'Ouidah', 100000, 'passionné de plantes tropicales'], ['jar2', 'Sylvie Tchibozo', true, 36, 'Porto-Novo', 95000, 'spécialiste des jardins fleuris']],
  linge: [['lin1', 'Hortense Fagbohoun', true, 44, 'Abomey', 85000, 'repassage impeccable'], ['lin2', 'Gilbert Ahouansou', false, 39, 'Cotonou', 80000, 'soigneux avec les tissus wax']],
  responsable: [['res1', 'Bernadette Ahyi', true, 50, 'Porto-Novo', 180000, 'ancienne gouvernante d’hôtel, organisée et bienveillante'], ['res2', 'Achille Quenum', false, 45, 'Ouidah', 190000, 'majordome rigoureux, sens de l’accueil']],
};
// zones d'état de la maison
export const AREAS = { vie: 'Pièces de vie', cuisine: 'Cuisine', chambres: 'Chambres', bains: 'Salles de bains', linge: 'Linge', jardin: 'Jardin', piscine: 'Piscine', equip: 'Équipements' };
// tâches : rôle, zone, lieu (pièce de l'aile ou point extérieur), durée en minutes de jeu, outil
const EXT = { pelouse: [[-52, 114], [-40, 115.5], [-56, 116.5]], massifs: [[-54, 114.5], [-39, 114.5], [-55, 137.4]], haies: [[-58.6, 111.6], [-26, 133], [-60, 136]], piscine: [[POOL.x0 - 0.6, 132], [POOL.x0 - 0.6, 138], [POOL.x1 + 0.6, 135]], terrasse: [[-50, 135.4], [-45, 135.2]] };
export const TASKS = [
  { id: 'salon', label: 'Nettoyer le grand salon', role: 'entretien', area: 'vie', at: ['salon', 'manger'], min: 45, tool: 'balai' },
  { id: 'cuisine', label: 'Nettoyer la cuisine', role: 'entretien', area: 'cuisine', at: ['cuisine'], min: 40, tool: 'balai' },
  { id: 'chambres', label: 'Faire le ménage des chambres', role: 'entretien', area: 'chambres', at: ['suite', 'enf1', 'enf2', 'enf3', 'inv1', 'inv2'], min: 70, tool: 'balai' },
  { id: 'bains', label: 'Nettoyer les salles de bains', role: 'entretien', area: 'bains', at: ['sdb', 'suite'], min: 35, tool: 'seau' },
  { id: 'rangement', label: 'Ranger le bureau, le cinéma et la salle de jeux', role: 'entretien', area: 'vie', at: ['bureau', 'cinema', 'jeux'], min: 40, tool: 'panier' },
  { id: 'terrasse', label: 'Laver la terrasse et les vitres', role: 'entretien', area: 'vie', ext: 'terrasse', min: 35, tool: 'seau' },
  { id: 'tonte', label: 'Tondre la pelouse', role: 'jardinier', area: 'jardin', ext: 'pelouse', min: 60, tool: 'tondeuse' },
  { id: 'arrosage', label: 'Arroser les massifs fleuris', role: 'jardinier', area: 'jardin', ext: 'massifs', min: 30, tool: 'arrosoir' },
  { id: 'taille', label: 'Tailler les haies et les palmiers', role: 'jardinier', area: 'jardin', ext: 'haies', min: 50, tool: 'cisaille' },
  { id: 'piscine', label: 'Nettoyer la piscine', role: 'jardinier', area: 'piscine', ext: 'piscine', min: 40, tool: 'epuisette' },
  { id: 'lessive', label: 'Laver le linge', role: 'linge', area: 'linge', at: ['buanderie'], min: 45, tool: 'panier' },
  { id: 'repassage', label: 'Repasser et plier les vêtements', role: 'linge', area: 'linge', at: ['buanderie'], min: 50, tool: 'panier' },
  { id: 'draps', label: 'Changer les draps', role: 'linge', area: 'chambres', at: ['suite', 'enf1', 'inv1', 'inv2'], min: 40, tool: 'panier' },
  { id: 'inspection', label: 'Inspection générale de la villa', role: 'responsable', area: null, at: ['salon', 'cuisine', 'suite', 'sport', 'cinema'], min: 40, tool: 'tablette' },
  { id: 'equip', label: 'Entretien des équipements (climatisation, cinéma, sport)', role: 'responsable', area: 'equip', at: ['cinema', 'sport', 'jeux'], min: 50, tool: 'mallette' },
  { id: 'reserves', label: 'Vérifier les réserves de la cuisine', role: 'responsable', area: null, at: ['cuisine'], min: 20, tool: 'tablette' },
  { id: 'accueil', label: 'Préparer l’accueil des invités', role: 'responsable', area: 'vie', at: ['salon', 'inv1', 'inv2'], min: 40, tool: 'tablette' },
];
const TBY = Object.fromEntries(TASKS.map((t) => [t.id, t]));

export class Staff {
  constructor(ctx) {
    Object.assign(this, ctx); // scene, villa, cook, economy, env, ui, audio, player, phonePlus, onSave
    this.team = []; this.state = Object.fromEntries(Object.keys(AREAS).map((k) => [k, 70])); this.view = 'equipe'; this.lastH = null; this.planDay = null; this.log = [];
  }
  // ------------------------------------------------------------------ recrutement
  hired(id) { return this.team.find((m) => m.id === id) || null; }
  hire(role, cid) {
    const R = ROLES[role], c = CANDIDATES[role].find((q) => q[0] === cid); if (!R || !c || this.hired(cid)) return;
    if (this.team.filter((m) => m.role === role).length >= R.slots) return this.ui.toast(`Le poste « ${R.label} » est déjà pourvu (${R.slots} place${R.slots > 1 ? 's' : ''}).`, 2.5);
    const [id, name, female, age, origin, salary, trait] = c, off = (this.team.length * 3 + 2) % 7;
    const m = { id, role, name, female, age, origin, salary, trait, off, morale: 75, since: this.economy.stamp(), payDay: this.economy.day + 7, tasks: [], done: 0, cur: null };
    this.team.push(m); this.ui.toast(`${R.icon} ${name} rejoint la VILLA NOVA (${female ? R.fem : R.label}, ${fcfa(salary)} tous les 7 jours).`, 3);
    this.onSave && this.onSave();
  }
  fire(id) { const m = this.hired(id); if (!m) return; this.despawn(m); this.team = this.team.filter((q) => q !== m); this.ui.toast(`${m.name} quitte la villa. Merci pour son travail.`, 2.5); this.onSave && this.onSave(); }
  job(m) { const R = ROLES[m.role]; return m.female ? R.fem : R.label; }
  // ------------------------------------------------------------------ horaires et disponibilité
  onDuty(m) { const [a, b] = ROLES[m.role].hours, h = this.env.time; return (this.economy.day % 7) !== m.off && h >= a && h < b; }
  avail(m) { if ((this.economy.day % 7) === m.off) return '🟡 jour de repos'; if (!this.onDuty(m)) return '⚪ hors service'; return m.cur ? `🔵 ${TBY[m.cur.id].label.toLowerCase()} (${Math.round(100 * m.cur.p)} %)` : '🟢 disponible'; }
  hoursText(m) { const [a, b] = ROLES[m.role].hours, days = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi']; return `${a} h – ${b} h • repos : jour ${m.off + 1} de la semaine (${days[m.off]})`; }
  // ------------------------------------------------------------------ tâches
  assign(id, taskId, quiet) {
    const m = this.hired(id), T = TBY[taskId]; if (!m || !T) return false;
    if (T.role !== m.role) { if (!quiet) this.ui.toast(`Cette tâche revient à un${ROLES[T.role].label.startsWith('A') ? '' : ''} ${ROLES[T.role].label.toLowerCase()}.`, 2.5); return false; }
    if (m.tasks.length >= 6) { if (!quiet) this.ui.toast(`${m.name.split(' ')[0]} a déjà 6 tâches prévues.`, 2); return false; }
    m.tasks.push({ id: taskId, by: quiet ? 'planning' : 'PDG' });
    if (!quiet) { this.ui.toast(`${ROLES[m.role].icon} ${m.name.split(' ')[0]} : « ${pick(['Bien, Monsieur le PDG, je m’en occupe.', 'C’est noté !', 'Tout de suite.'])} » (${T.label.toLowerCase()})`, 2.5); this.onSave && this.onSave(); }
    return true;
  }
  forTask(taskId) { const T = TBY[taskId]; return this.team.filter((m) => m.role === T.role).sort((a, b) => a.tasks.length - b.tasks.length)[0] || null; }
  dailyPlan() { // le responsable (ou, à défaut, chaque employé) organise la journée
    const day = this.economy.day; if (this.planDay === day) return; this.planDay = day;
    const low = Object.entries(this.state).sort((a, b) => a[1] - b[1]).map(([k]) => k);
    for (const m of this.team) if (m.tasks.length < 2) for (const T of TASKS.filter((t) => t.role === m.role).sort((a, b) => (low.indexOf(a.area) < 0 ? 9 : low.indexOf(a.area)) - (low.indexOf(b.area) < 0 ? 9 : low.indexOf(b.area))).slice(0, 2)) this.assign(m.id, T.id, true);
    const R = this.team.find((m) => m.role === 'responsable');
    if (R) this.notifyFrom(R, `Planning du jour établi : ${this.team.filter((m) => m.tasks.length).length} employé(s) ont leurs tâches. Point faible de la maison : ${AREAS[low[0]].toLowerCase()} (${Math.round(this.state[low[0]])} %).`);
  }
  // ------------------------------------------------------------------ personnages visibles
  spawn(m) {
    if (m.c) return; const R = ROLES[m.role], i = this.team.indexOf(m);
    m.c = createCharacter({ female: m.female, skin: SKINS[(i * 2 + 1) % SKINS.length], skirt: false, headwrap: m.female && m.role !== 'responsable', shoes: 0x1a1a1a, ...R.uniform });
    m.tool = this.toolMesh(m); m.c.bones.foreR.add(m.tool);
  }
  despawn(m) { if (m.c && m.c.group.parent) m.c.group.parent.remove(m.c.group); m.c = null; }
  toolMesh(m) {
    const g = new THREE.Group(), M = (c) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.6 });
    const add = (geo, c, x, y, z, rx = 0) => { const o = new THREE.Mesh(geo, M(c)); o.position.set(x, y, z); o.rotation.x = rx; g.add(o); return o; };
    g.userData.parts = {
      balai: [add(new THREE.CylinderGeometry(0.015, 0.015, 1.2, 5), 0x8a6a42, 0, -0.45, 0.1), add(new THREE.BoxGeometry(0.28, 0.08, 0.06), 0x2a2a2a, 0, -1.05, 0.1)],
      seau: [add(new THREE.CylinderGeometry(0.12, 0.1, 0.22, 10), 0x2f80ed, 0, -0.3, 0.05)],
      panier: [add(new THREE.BoxGeometry(0.4, 0.22, 0.28), 0xd8b070, 0, -0.25, 0.1)],
      arrosoir: [add(new THREE.CylinderGeometry(0.1, 0.12, 0.24, 10), 0x2f7a3a, 0, -0.28, 0.05), add(new THREE.CylinderGeometry(0.015, 0.02, 0.3, 5), 0x2f7a3a, 0, -0.25, 0.22, 1.1)],
      tondeuse: [add(new THREE.BoxGeometry(0.45, 0.2, 0.5), 0xc8102e, 0, -0.75, 0.55), add(new THREE.CylinderGeometry(0.012, 0.012, 0.8, 5), 0x333333, 0, -0.45, 0.3, 0.8)],
      cisaille: [add(new THREE.BoxGeometry(0.04, 0.04, 0.5), 0x9a9ea2, 0, -0.2, 0.25)],
      epuisette: [add(new THREE.CylinderGeometry(0.012, 0.012, 1.8, 5), 0xd8dde2, 0, -0.5, 0.5, 1.0), add(new THREE.TorusGeometry(0.15, 0.015, 5, 12), 0x2f80ed, 0, -1.1, 1.2)],
      tablette: [add(new THREE.BoxGeometry(0.18, 0.02, 0.25), 0x111111, 0, -0.18, 0.1)],
      mallette: [add(new THREE.BoxGeometry(0.35, 0.25, 0.1), 0x3a3d42, 0, -0.3, 0.05)],
    };
    for (const arr of Object.values(g.userData.parts)) for (const o of arr) o.visible = false;
    return g;
  }
  showTool(m, name) { for (const [k, arr] of Object.entries(m.tool.userData.parts)) for (const o of arr) o.visible = k === name; }
  // trajets : couloirs de l'aile (z 8 et z −12, galerie ouest x −35,5) ; allées extérieures (cour z 113,5, arrière z 138,5, bande ouest x −58,5)
  roomOf(x, z) { return Object.values(this.villa.rooms).find((R) => x >= R.x0 && x <= R.x1 && z >= R.z0 && z <= R.z1) || null; }
  pathIn(m, tx, tz) {
    const A = this.roomOf(m.x, m.z), B = this.roomOf(tx, tz), pts = [], inDoor = (R) => (R.z0 === 10 ? 10.6 : R.z0 === -10 ? 5.4 : -14.6), corr = (R, z) => (R ? (R.z0 === -30 ? -12 : 8) : (z < -2 ? -12 : 8));
    if (A && A === B) return [[tx, tz]];
    const ca = corr(A, m.z), cb = corr(B, tz);
    if (A) pts.push([A.door.x, inDoor(A)], [A.door.x, ca]); else pts.push([m.x, ca]);
    if (ca !== cb) pts.push([-35.5, ca], [-35.5, cb]);
    if (B) pts.push([B.door.x, cb], [B.door.x, inDoor(B)]); else pts.push([tx, cb]);
    pts.push([tx, tz]); return pts;
  }
  pathOut(m, tx, tz) { const zone = (z) => (z < 125 ? 'av' : 'ar'); if (zone(m.z) === zone(tz)) return [[tx, tz]]; const za = zone(m.z) === 'av' ? 113.6 : 138.6, zb = zone(tz) === 'av' ? 113.6 : 138.6; return [[-58.4, za], [-58.4, zb], [tx, tz]]; }
  // ------------------------------------------------------------------ boucle
  update(dt) {
    if (!this.team.length) return;
    const day = this.economy.day, h = this.env.time;
    if (h >= 6.5 && this.planDay !== day) this.dailyPlan();
    // usure de la maison (par heure de jeu)
    const gh = day * 24 + h; if (this.lastH === null) this.lastH = gh; const dh = Math.min(6, Math.max(0, gh - this.lastH)); this.lastH = gh;
    if (dh > 0) for (const k of Object.keys(this.state)) this.state[k] = Math.max(0, this.state[k] - dh * (k === 'jardin' || k === 'piscine' ? 0.8 : k === 'equip' ? 0.3 : 1.1));
    // salaires
    for (const m of this.team) if (day >= m.payDay) { m.payDay = day + 7; if (this.economy.pay(m.salary, `Salaire — ${m.name} (${this.job(m)}, VILLA NOVA)`, 'Personnel de maison')) { m.morale = Math.min(100, m.morale + 3); } else { m.morale = Math.max(10, m.morale - 10); this.economy.notify(`⚠️ Solde insuffisant pour le salaire de ${m.name}.`); } }
    const inside = this.villa.inside, P = this.player.pos;
    for (const m of this.team) {
      const duty = this.onDuty(m);
      // avancement de la tâche en cours (même si le joueur n'est pas là)
      if (duty && !m.cur && m.tasks.length) this.startTask(m);
      if (!duty && m.cur) { m.tasks.unshift({ id: m.cur.id, by: m.cur.by }); m.cur = null; }
      if (m.cur && m.cur.working) { m.cur.p += (dh * 60) / TBY[m.cur.id].min; if (m.cur.p >= 1) this.finishTask(m); }
      // rendu : à l'intérieur de l'aile ou dans le jardin, seulement si le joueur peut le voir
      const extTask = m.cur && TBY[m.cur.id].ext, showIn = inside && duty && !extTask, showOut = !inside && duty && !!extTask && Math.hypot(P.x + 44, P.z - 126) < 90;
      if (!showIn && !showOut) { if (m.c) m.c.group.visible = false; if (m.cur && !m.cur.working && m.cur.walk) { m.cur.walk = null; m.cur.working = true; } continue; }
      this.spawn(m); const parent = showIn ? this.villa.inGroup : this.scene; if (m.c.group.parent !== parent) { parent.add(m.c.group); if (m.cur) this.placeAtSpot(m); }
      m.c.group.visible = true; this.animate(m, dt);
    }
  }
  startTask(m) {
    const t = m.tasks.shift(), T = TBY[t.id]; m.cur = { id: t.id, by: t.by, p: 0, working: false, walk: null, spot: null };
    if (T.ext) { const s = pick(EXT[T.ext]); m.cur.spot = { x: s[0], z: s[1], ext: true }; if (m.x === undefined || m.inExt !== true) { m.x = -44.5; m.z = 113; m.inExt = true; } m.cur.walk = this.pathOut(m, s[0], s[1]); }
    else { const R = this.villa.rooms[pick(T.at)]; let sx = R.cx + (Math.random() - 0.5) * (R.x1 - R.x0 - 3), sz = R.cz + (Math.random() - 0.5) * (R.z1 - R.z0 - 5); if (T.id === 'chambres' && R.bed) { sx = R.bed.x + (R.type === 'suite' ? 1.2 : 0.8) + 0.45; sz = R.bed.z; } if (this.furniture) [sx, sz] = this.furniture.freeSpot(R, sx, sz); m.cur.spot = { x: sx, z: sz, room: R.id, face: T.id === 'chambres' && R.bed ? -Math.PI / 2 : undefined }; if (m.x === undefined || m.inExt !== false) { const S = this.villa.rooms.personnel; m.x = S.cx; m.z = S.cz; m.inExt = false; } m.cur.walk = this.pathIn(m, sx, sz); }
  }
  placeAtSpot(m) { if (m.cur && m.cur.spot && m.cur.working) { m.x = m.cur.spot.x; m.z = m.cur.spot.z; } }
  finishTask(m) {
    const T = TBY[m.cur.id]; m.done++; m.cur = null;
    if (T.area) this.state[T.area] = Math.min(100, this.state[T.area] + (T.id === 'chambres' || T.id === 'tonte' ? 45 : 35));
    if (T.id === 'inspection') for (const k of Object.keys(this.state)) this.state[k] = Math.min(100, this.state[k] + 3);
    if (T.id === 'reserves' && this.cook && this.cook.hired) { const w = this.cook.restock(); if (w.length) this.notifyFrom(m, `Réserves vérifiées : il faudrait ${fcfa(this.cook.shopCost(w))} de courses. Vous pouvez les valider dans « Mon cuisinier ».`); }
    this.log.unshift({ t: this.economy.stamp(), who: m.name, what: T.label }); this.log.length = Math.min(this.log.length, 30);
    this.onSave && this.onSave();
  }
  animate(m, dt) {
    const c = m.c, cur = m.cur; let sp = 0;
    if (cur && cur.walk && cur.walk.length) {
      const [tx, tz] = cur.walk[0], dx = tx - m.x, dz = tz - m.z, d = Math.hypot(dx, dz);
      if (d < 0.15) { cur.walk.shift(); if (!cur.walk.length) { cur.walk = null; cur.working = true; } }
      else { sp = Math.min(1.4, d * 3); m.x += dx / d * sp * dt; m.z += dz / d * sp * dt; m.h = Math.atan2(dx, dz); }
      this.showTool(m, TBY[cur.id].tool === 'tondeuse' ? 'tondeuse' : 'none');
    } else if (cur && cur.working) {
      const T = TBY[cur.id]; this.showTool(m, T.tool); if (cur.spot && cur.spot.face !== undefined) m.h = cur.spot.face;
      if (T.tool === 'tondeuse') { const t = performance.now() / 1000; m.x = cur.spot.x + Math.sin(t * 0.4) * 3; m.h = Math.cos(t * 0.4) > 0 ? Math.PI / 2 : -Math.PI / 2; sp = 0.9; }
    } else { // pause entre deux tâches
      this.showTool(m, 'none');
    }
    c.group.position.set(m.x, 0, m.z); c.group.rotation.y = m.h || 0; c.animate(dt, sp);
    if (cur && cur.working && sp < 0.2) { const b = c.bones, k = Math.sin(performance.now() / 220 + m.done), T = TBY[cur.id];
      if (T.tool === 'balai') { b.armR.rotation.x = -0.5 + k * 0.35; b.armL.rotation.x = -0.5 + k * 0.35; b.spine.rotation.x = 0.25; }
      else if (T.tool === 'arrosoir') { b.armR.rotation.x = -0.9; b.foreR.rotation.x = -0.3 + k * 0.1; }
      else if (T.tool === 'cisaille') { b.armR.rotation.x = -1.3 + k * 0.15; b.armL.rotation.x = -1.3 - k * 0.15; }
      else if (T.tool === 'epuisette') { b.armR.rotation.x = -0.8 + k * 0.4; b.armL.rotation.x = -0.6 + k * 0.4; }
      else if (T.tool === 'panier' || T.tool === 'seau') { b.armR.rotation.x = -0.7 + k * 0.25; b.armL.rotation.x = -0.7 - k * 0.25; b.spine.rotation.x = 0.3; }
      else { b.armR.rotation.x = -0.6; b.foreR.rotation.x = -1.2; b.head.rotation.x = 0.3; } }
  }
  // ------------------------------------------------------------------ interactions et conversation
  nearest(x, z) {
    const { O } = VILLA; let best = null;
    for (const m of this.team) { if (!m.c || !m.c.group.visible) continue; const inGrp = m.c.group.parent === this.villa.inGroup, wx = inGrp ? O.x + m.x : m.x, wz = inGrp ? O.z + m.z : m.z; if (inGrp !== this.villa.inside) continue; const d = Math.hypot(x - wx, z - wz); if (d < 1.7 && (!best || d < best.d)) best = { d, m }; }
    if (!best) return null; const m = best.m;
    return { d: best.d, it: { label: () => `Parler à ${m.name} (${this.job(m).toLowerCase()})`, action: () => this.talkMenu(m) } };
  }
  talkMenu(m) {
    const items = [{ label: '💬 Comment ça va ?', action: () => this.ui.toast(`${m.name.split(' ')[0]} : « ${this.reply(m, 'ça va ?')} »`, 3.5) }];
    for (const T of TASKS.filter((t) => t.role === m.role)) items.push({ label: `📋 ${T.label}`, action: () => this.assign(m.id, T.id) });
    items.push({ label: '👏 Merci pour votre travail', action: () => this.ui.toast(`${m.name.split(' ')[0]} : « ${this.reply(m, 'merci bravo')} »`, 3) });
    this.ui.openMenu(`${ROLES[m.role].icon} ${m.name}`, `${this.job(m)} • ${this.avail(m)} • ${this.hoursText(m)}`, items);
  }
  contacts() { return this.team.map((m) => ({ key: `dom:${m.id}`, kind: 'dom', name: m.name, role: `${this.job(m)} • VILLA NOVA`, icon: ROLES[m.role].icon, staff: m })); }
  reply(m, txt) {
    const t = norm(txt), T = TASKS.filter((q) => q.role === m.role);
    const task = T.find((q) => norm(q.label).split(' ').filter((w) => w.length > 4).some((w) => t.includes(w)));
    if (task && /(peux|pourrais|fais|faites|nettoie|nettoyez|range|rangez|arrose|tonds|tondez|taille|lave|repasse|change|verifie|prepare|occupe)/.test(t)) { this.assign(m.id, task.id, true); this.onSave && this.onSave(); return `Bien, Monsieur le PDG : « ${task.label.toLowerCase()} », c’est prévu${m.cur ? ' juste après ma tâche en cours' : ''}.`; }
    if (/(ca va|comment vas|comment allez)/.test(t)) return m.morale >= 60 ? 'Très bien, merci ! Je suis content·e de travailler ici.'.replace('content·e', m.female ? 'contente' : 'content') : 'Ça va… un peu fatigué·e, mais je fais de mon mieux.'.replace('fatigué·e', m.female ? 'fatiguée' : 'fatigué');
    if (/(merci|bravo|bon travail|excellent)/.test(t)) { m.morale = Math.min(100, m.morale + 3); return 'Merci beaucoup, Monsieur le PDG, ça fait plaisir !'; }
    if (/(tache|travail|fais quoi|que fais|tu fais|vous faites|occupe|en cours|en ce moment)/.test(t)) return m.cur ? `Je suis en train de : ${TBY[m.cur.id].label.toLowerCase()} (${Math.round(100 * m.cur.p)} %). Ensuite : ${m.tasks.map((q) => TBY[q.id].label.toLowerCase()).join(', ') || 'rien de prévu'}.` : m.tasks.length ? `Prochaine tâche : ${TBY[m.tasks[0].id].label.toLowerCase()}.` : 'Je n’ai pas de tâche en ce moment. Que puis-je faire ?';
    if (/(horaire|heure|repos|conge)/.test(t)) return `Je travaille de ${this.hoursText(m)}.`;
    if (/(salaire|paie)/.test(t)) return `Mon salaire est de ${fcfa(m.salary)} tous les 7 jours. Merci, il est toujours versé à temps.`;
    if (/(d ou viens|originaire|famille)/.test(t)) return `Je viens de ${m.origin}. J’ai ${m.age} ans ; on dit de moi que je suis ${m.trait}.`;
    if (/(maison|etat|propre)/.test(t)) { const low = Object.entries(this.state).sort((a, b) => a[1] - b[1])[0]; return `Le point à surveiller : ${AREAS[low[0]].toLowerCase()} (${Math.round(low[1])} %).`; }
    if (/(bonjour|bonsoir|salut)/.test(t)) return `${this.env.time < 12 ? 'Bonjour' : 'Bonsoir'} Monsieur le PDG !`;
    return pick(['Bien noté.', 'D’accord, Monsieur le PDG.', 'Je vous écoute.']);
  }
  notifyFrom(m, txt) { if (this.phonePlus) this.phonePlus.receive(`dom:${m.id}`, txt); else this.economy.notify(`${m.name} : ${txt}`); }
  // ------------------------------------------------------------------ application « Personnel domestique »
  renderApp(b) {
    const tabs = [['equipe', 'Équipe'], ['taches', 'Tâches'], ['maison', 'État de la maison'], ['recruter', 'Recruter'], ['salaires', 'Salaires']];
    let body = '';
    if (this.view === 'equipe') body = `${this.cook && this.cook.hired ? `<div class="ph-row"><span><b>👩🏿‍🍳 ${esc(this.cook.hired.name)}</b><small>${this.cook.title()} • 6 h – 22 h • ${this.cook.queue.length ? 'en cuisine' : 'disponible'} • ${fcfa(this.cook.hired.salary)} / 7 jours</small></span><button class="ph-mini" data-ph="chef">Ouvrir</button></div>` : '<p class="ph-note">Cuisinier : à recruter dans « Mon cuisinier ».</p>'}
      ${this.team.map((m) => `<div class="ph-row"><span><b>${ROLES[m.role].icon} ${esc(m.name)}</b><small>${this.job(m)} • ${this.hoursText(m)}<br>${this.avail(m)} • ${m.tasks.length} tâche(s) prévue(s) • moral ${Math.round(m.morale)} • ${m.done} tâche(s) faite(s)</small></span><span class="pp-acts"><button class="ph-mini" data-st="give:${m.id}">📋</button><button class="ph-mini" data-pp="chat:dom:${m.id}">💬</button></span></div>`).join('') || '<p class="ph-note">Aucun employé : onglet « Recruter ».</p>'}`;
    else if (this.view === 'taches') body = `<p class="ph-note">Touche une tâche : elle est confiée à l’employé du poste concerné le moins occupé.</p>${Object.keys(ROLES).map((r) => `<h5>${ROLES[r].icon} ${ROLES[r].label}</h5><div class="ph-list">${TASKS.filter((t) => t.role === r).map((t) => `<div class="ph-row" data-st="task:${t.id}"><span><b>${esc(t.label)}</b><small>${t.min} min • ${t.ext ? 'jardin / extérieur' : 'aile principale'}${t.area ? ` • ${AREAS[t.area]} ${Math.round(this.state[t.area])} %` : ''}</small></span></div>`).join('')}</div>`).join('')}`;
    else if (this.view === 'maison') body = `<div class="ev-rep">${Object.entries(AREAS).map(([k, l]) => `<div><span>${l}</span><i><b style="width:${this.state[k]}%"></b></i><em>${Math.round(this.state[k])} %</em></div>`).join('')}</div><h5>Dernières tâches réalisées</h5>${this.log.slice(0, 8).map((l) => `<p class="ph-note">${l.t} • ${esc(l.who)} : ${esc(l.what.toLowerCase())}</p>`).join('') || '<p class="ph-note">Aucune pour le moment.</p>'}`;
    else if (this.view === 'recruter') body = Object.entries(ROLES).map(([r, R]) => `<h5>${R.icon} ${R.label} (${this.team.filter((m) => m.role === r).length}/${R.slots})</h5><div class="ph-list">${CANDIDATES[r].map(([id, name, f, age, origin, sal, trait]) => `<div class="ph-row"><span><b>${esc(name)}, ${age} ans</b><small>${f ? R.fem : R.label} • ${origin} • ${esc(trait)}</small></span><span class="pp-acts"><em>${fcfa(sal)}</em>${this.hired(id) ? '<button class="ph-mini" disabled>Recruté·e</button>' : `<button class="ph-mini" data-st="hire:${r}|${id}">Recruter</button>`}</span></div>`).join('')}</div>`).join('');
    else { const tot = this.team.reduce((a, m) => a + m.salary, 0) + (this.cook && this.cook.hired ? this.cook.hired.salary : 0); body = `<p class="ph-note">Salaires en FCFA virtuels, prélevés sur le compte personnel tous les 7 jours de jeu (jamais sur les comptes des entreprises).</p><div class="ph-row"><span><b>Total par période de 7 jours</b></span><em>${fcfa(tot)}</em></div>${this.team.map((m) => `<div class="ph-row"><span><b>${esc(m.name)}</b><small>${this.job(m)} • prochain versement J${m.payDay}</small></span><span class="pp-acts"><em>${fcfa(m.salary)}</em><button class="ph-mini" data-st="fire:${m.id}">Fin de contrat</button></span></div>`).join('')}`; }
    b.innerHTML = `<h4>🏠 Personnel domestique</h4><div class="ph-chips">${tabs.map(([k, l]) => `<button data-st="tab:${k}" class="${this.view === k ? 'on' : ''}">${l}</button>`).join('')}</div>${body}`;
  }
  onPhone(v) {
    const i = v.indexOf(':'), a = v.slice(0, i), arg = v.slice(i + 1);
    if (a === 'tab') this.view = arg;
    else if (a === 'hire') { const [r, id] = arg.split('|'); this.hire(r, id); }
    else if (a === 'fire') this.fire(arg);
    else if (a === 'task') { const m = this.forTask(arg); if (m) this.assign(m.id, arg); else this.ui.toast(`Recrute d’abord un ${ROLES[TBY[arg].role].label.toLowerCase()}.`, 2.5); }
    else if (a === 'give') { this.view = 'taches'; }
    this.onSave && this.onSave(); if (this.economy.phoneOpen) this.economy.renderPhone();
  }
  serialize() { return { team: this.team.map(({ c, tool, x, z, h, inExt, ...m }) => ({ ...m, cur: m.cur ? { id: m.cur.id, by: m.cur.by, p: m.cur.p } : null })), state: this.state, planDay: this.planDay, log: this.log }; }
  restore(s) {
    if (!s) return; this.state = { ...this.state, ...(s.state || {}) }; this.planDay = s.planDay ?? null; this.log = s.log || [];
    const seen = new Set(); this.team = (s.team || []).filter((m) => !seen.has(m.id) && seen.add(m.id)).map((m) => ({ ...m, tasks: m.tasks || [], cur: m.cur ? { ...m.cur, working: false, walk: null, spot: null } : null }));
    for (const m of this.team) if (m.cur) { m.tasks.unshift({ id: m.cur.id, by: m.cur.by }); m.cur = null; }
  }
}
