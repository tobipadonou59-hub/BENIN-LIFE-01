# BENIN LIFE : COTONOU OPEN WORLD — Prototype v0.3 (son + amélioration visuelle)

Jeu 3D en monde ouvert inspiré de Cotonou (Bénin), réalisé avec **Three.js** (WebGL, gratuit et open source).
Les bâtiments, personnages, véhicules et la végétation sont **générés par le code**. Aucun modèle 3D n'est à fournir.
Trois matériaux PBR réalistes (asphalte, trottoir, latérite) ont été **générés par IA avec Scenario** (modèle PATINA, plan gratuit)
et sont intégrés au fichier du jeu. Aucun crédit n'a été acheté.

## ▶ Lancer le jeu sur PC

**Méthode la plus simple :** double-clique sur **`BENIN_LIFE.html`**.
Le fichier s'ouvre dans Chrome, Edge ou Firefox, sans installation et sans connexion Internet.

> Conseil : sur un PC portable avec deux cartes graphiques, force le navigateur sur le GPU « hautes performances »
> (Windows → Paramètres → Affichage → Graphiques).

### Pour modifier le code (développeurs)
Prérequis : [Node.js](https://nodejs.org) 18 ou plus récent.
```
npm install
npm run build      # régénère dist/game.js et BENIN_LIFE.html
npm run dev        # reconstruit automatiquement à chaque sauvegarde
```

## 🎮 Commandes
| Action | Clavier AZERTY | QWERTY |
|---|---|---|
| Se déplacer / conduire | Z Q S D ou flèches | W A S D |
| Courir | Maj | Shift |
| Sauter / frein à main | Espace | Space |
| Monter / descendre de voiture | E | E |
| Caméra | Souris (clic pour capturer) · molette = zoom | |
| Klaxon (en voiture) | K | K |
| Monter / descendre (à l'arrêt) | E | E |
| Couper / rétablir le son | M | M |
| Pause | Échap ou P | |
| Aide à l'écran · +1 heure · FPS | H · T · F | |

## 🗺 Contenu de la zone
- **Rond-point de l'Indépendance** : monument en bronze, drapeau du Bénin qui flotte, passages piétons.
- **Boulevard central** goudronné avec lampadaires, et **rues pavées** (pavés autobloquants).
- **Quartiers** d'immeubles R+1 à R+4 aux façades colorées, avec persiennes, balcons, citernes,
  « poteaux en attente » sur les toits, et commerces avec enseignes peintes (maquis, pharmacie, couture…).
- **Concessions** : murs à éclaboussures de latérite et portails métalliques.
- **Vendeurs d'essence « kpayo »** au bord des routes.
- **Grand Marché** : étals, bâches et parasols colorés. **Jardin** avec terrain de foot en sable.
- **Plage de Fidjrossè** : cocotiers, pirogues peintes et océan animé.
- **Circulation** de zémidjans (chemise jaune, avec ou sans passager) et de voitures, plus des piétons en pagne.
- **4 voitures conduisibles** (points bleus sur la mini-carte).
- **Cycle jour/nuit** : une journée dure 20 minutes. La nuit, les fenêtres, les enseignes, les lampadaires et les phares s'allument.

## 🔊 Son (v0.3)
Tous les sons sont **synthétisés en temps réel** par le navigateur (Web Audio API). Il n'y a aucun fichier audio :
le jeu reste léger et jouable hors-ligne.
- **Musique du menu** : rythme en 12/8 construit sur la cloche **gankogui** (tradition fon/ewe), avec tambour et hochet.
- **Ambiances** :
  - rumeur de la ville ;
  - vagues et écume qui montent quand on approche de la plage ;
  - vent, oiseaux le jour et grillons la nuit ;
  - brouhaha du **Grand Marché** quand on s'en approche.
- **Joueur** : bruits de pas différents sur asphalte, pavés, trottoir, latérite, herbe et sable, plus un bruit à l'atterrissage.
- **Voiture** : moteur dont le régime suit les vitesses (boîte à 5 rapports simulée), admission, crissement des pneus au frein à main, portières, chocs, klaxon (**K**).
- **Circulation** : zémidjans (moteur deux-temps aigu) et voitures spatialisés en 3D.
  Ils klaxonnent quand on leur bloque le passage, et parfois sans raison… on est à Cotonou !
- **Interface** : clics et survols des boutons.
- **Options** : volume général et musique du menu. La touche **M** coupe le son.

## ✨ Nouveautés de la Mission 002
- **Textures IA (Scenario/PATINA)** : asphalte fissuré, dalles de trottoir et latérite, avec cartes de relief.
  Une variation à grande échelle évite l'effet de répétition.
- **Architecture de Cotonou** :
  - soubassements colorés, corniches à chaque étage, claustras (blocs ajourés), cages d'escalier en claustras ;
  - balcons à balustres, galeries commerçantes à piliers, climatiseurs, paraboles, citernes, fresques peintes ;
  - villas à toit de tôle (rouge, verte, bleue ou galvanisée), portails, et un maquis avec parasol et chaises plastiques.
- **Façades HD** : enduit, coulures de pluie, persiennes, grilles en fer forgé, rideaux, fissures, avec carte de relief.
- **Rues** :
  - caniveaux couverts de dalles et bordures ;
  - sable et latérite qui débordent sur la chaussée ;
  - pavés autobloquants et sable de plage avec relief.
- **Personnages réalistes** : squelette animé de 17 os, avec visage, oreilles, mains et pieds.
  - Animations : repos (respiration), marche, course (buste penché, coudes pliés), saut, position assise sur moto.
  - Femmes en pagne et foulard. Vendeuses avec une bassine de marchandises sur la tête.
- **Végétation** : cocotiers (16 palmes, palmes sèches, noix de coco), manguiers, flamboyants en fleurs,
  bougainvilliers, bananiers et touffes d'herbe, le tout balancé par le vent.
- **Lumière et ciel** :
  - ciel physique avec nuages animés, lune et étoiles ;
  - éclairage d'ambiance calculé depuis le ciel ;
  - ombres stabilisées (sans scintillement) ;
  - halos des lampadaires la nuit, brume dorée au coucher du soleil.
- **Post-traitement** (selon la qualité) : halo lumineux (bloom), étalonnage des couleurs et vignettage.
  En qualité Haute, occlusion ambiante (GTAO).
- **Véhicules** :
  - berline, minibus avec bagages sur le toit et pick-up, à carrosserie profilée et vernis ;
  - zémidjans détaillés avec passagers ;
  - 32 véhicules en circulation, dont deux boucles qui passent par le rond-point.
- **Piétons** : 36 promeneurs et des groupes qui discutent devant les boutiques.
- **Mini-carte** : tourne avec la caméra, affiche les bâtiments, le marquage des routes, des icônes de lieux
  (M marché, J jardin, P plage, ★ rond-point) et une boussole, avec un zoom qui s'adapte à la vitesse.

## ⚙ Performances (PC 16 Go de RAM)
- Géométrie statique fusionnée par matériau (environ 70 appels de rendu pour toute la ville), végétation instanciée.
- Ombres limitées à une zone de 110 m autour du joueur, brouillard de distance, PNJ éloignés masqués.
- Options → Qualité :
  - **Basse** : sans ombres ni post-traitement, herbes réduites ;
  - **Moyenne** (recommandée) : ombres 2K et bloom ;
  - **Haute** : ombres 4K, occlusion ambiante GTAO et rendu net.
- Mesures sur la ville complète : environ 200 appels de rendu, 570 000 triangles, 120 Mo de mémoire JS.
  Le fichier du jeu pèse 2,6 Mo, textures IA comprises.
- La génération de la ville prend quelques secondes au lancement (textures calculées sur place).

## 📁 Organisation
```
BENIN_LIFE.html     ← jeu complet en un seul fichier (à double-cliquer)
assets/textures/    ← textures PBR générées par IA (Scenario / PATINA)
index.html          ← interface (HTML/CSS), charge dist/game.js
src/
  main.js           boucle de jeu, états (menu/jeu/pause), entrée/sortie de voiture
  world.js          génération de la ville, routes, plage, collisions, zones
  textures.js       textures procédurales (façades HD, claustras, balustres, pagnes, enseignes…)
  assets.js         chargement des textures IA
  vegetation.js     végétation instanciée + vent
  shaderfx.js       variation anti-répétition des sols, vent
  post.js           post-traitement (bloom, GTAO, étalonnage)
  audio.js          son synthétisé (ambiances, moteur, klaxons, pas, musique)
  environment.js    ciel dynamique, soleil/lune, brouillard, étoiles, cycle jour/nuit
  player.js         joueur à pied (marche, course, saut, collisions)
  character.js      personnage articulé + animation
  vehicles.js       voiture conduisible, zémidjans, circulation automatique
  pedestrians.js    piétons
  camera.js         caméra 3e personne anti-collision
  input.js · ui.js  clavier/souris · menus, HUD, mini-carte
  collision.js      collisions 2D avec grille spatiale
tools/build.mjs     build (esbuild) · tools/smoke-test.cjs test automatisé (Playwright)
```

## 🔜 Prochaines étapes proposées
1. Sons : moteurs, klaxons de zémidjans, ambiance de marché, vagues.
2. Zémidjan conduisible par le joueur et missions de taxi.
3. D'autres matériaux IA (façades, tôle, sable, herbe) quand le quota gratuit de Scenario sera renouvelé.
   Ou modèles 3D IA de lieux emblématiques, avec ton accord pour les crédits.
4. Feux de circulation, piétons qui traversent, interactions avec les PNJ.

## 🧍 Mission 003 : personnage principal (préparation)
État : **en attente de crédits Scenario**. Tripo est utilisé via Scenario. Le quota gratuit est épuisé (11 CU restants
pour 12 CU nécessaires à la première étape). Aucun crédit n'a été dépensé pour cette mission.

**Formule B validée** (122 CU par personnage) :
1. Image de concept (12 CU).
2. Tripo 3.1 : GLB optimisé à 15 000 faces, matériaux PBR, échelle réelle (60 CU).
3. Tripo Rigging Biped : squelette seul (50 CU).

Les animations (repos, marche, course, saut, assis) sont celles du jeu, transférées automatiquement sur le squelette Tripo.

**Déjà en place et testé :**
- Choix **HOMME / FEMME** dans le menu principal (mémorisé), fonctionnel avec les personnages actuels.
- `src/glbCharacter.js`, le chargeur de personnage GLB :
  - mise à l'échelle automatique (1,78 m, pieds au sol, centré), correction des fichiers en centimètres ;
  - reconnaissance des os par leur nom (conventions Tripo, Mixamo, Unreal, Blender…) et transfert des animations ;
  - utilise en priorité les clips idle/walk/run si le GLB en contient, avec transitions selon la vitesse ;
  - rapport de vérification dans la console : os, rôles reconnus et manquants, triangles, hauteur, clips.
- **Intégration** : déposer `assets/characters/male.glb` (et/ou `female.glb`), puis lancer `npm run build`.
  Le modèle est intégré à `BENIN_LIFE.html` et devient le personnage du joueur.
  Si le fichier est absent ou illisible, le personnage procédural est utilisé : rien ne casse.

## 🚗 Mission 004 : véhicules et conduite
**Déjà présents (Missions 001 et 002, conservés)** : berline, minibus et pick-up procéduraux, roues qui tournent
et braquent, conduite au clavier (ZQSD/WASD + flèches, Espace = frein à main), caméra de poursuite,
collisions, et 32 véhicules en circulation.

**Ajouts (gratuits, procéduraux, aucun modèle attribué à Tripo)** :
- **Citadine** (3,75 m, hayon), garée dans les rues et présente dans la circulation.
- **Moto conduisible** :
  - pilote visible, homme ou femme selon le personnage choisi ;
  - inclinaison dans les virages et béquille à l'arrêt ;
  - en marche arrière, on pousse la moto ;
  - son moteur plus aigu et caméra plus proche.
- **Immobilisation** : on ne peut descendre qu'à l'arrêt (moins de 9 km/h), et le véhicule quitté reste immobile.
- **12 véhicules garés** au bord des voies, sans bloquer la circulation.
  Correctif : avant, un pick-up garé bloquait les véhicules derrière lui.
- **`loadGLBVehicleBody()`** : charge une carrosserie GLB (ex. Tripo), la met à la longueur réelle,
  la pose au sol et lui garde les roues animées du jeu. Testé avec un GLB factice, retiré ensuite.

**Tests de conduite (simulation physique)** :
- Citadine : 68 km/h en 3 s ; frein à main jusqu'à l'arrêt complet ; marche arrière à 22 km/h.
- Choc à 45 km/h : arrêt devant le mur, sans le traverser.
- Moto : 52 km/h en 3 s ; inclinaison en virage ; choc à 40 km/h sans traverser le mur.
- Circulation : 0 véhicule bloqué sur 32 ; descente refusée en roulant.

**Performances** : 213 appels de rendu, 582 000 triangles, 123 Mo de mémoire JS.

**Tripo (via Scenario), en attente d'autorisation et de crédits** :

| Option | Par véhicule | 3 véhicules |
|---|---|---|
| 1. Image de concept + carrosserie Tripo 3.1 à 12 000 faces + roues du jeu | 72 CU | 216 CU |
| 2. Option 1 + roues séparées par Tripo Segmentation v2 | 152 CU | 456 CU |

## 🚦 Mission 005 : circulation routière et piétons (v0.6)
Aucune génération Tripo : les ressources du jeu suffisaient (**0 crédit**).

**Circulation (36 véhicules : berlines, citadines, minibus, pick-up, zémidjans)** :
- 8 itinéraires qui se croisent. Aux embranchements, les véhicules bifurquent au hasard (environ 350 changements de direction en 2 min 30).
- **Feux tricolores** aux 8 grands carrefours (vert 11 s, orange 2,5 s, rouge intégral 1,5 s), avec un freinage progressif jusqu'à la ligne d'arrêt.
- Priorité dans les carrefours : on attend si un véhicule traverse déjà, et on cède le passage à l'entrée du rond-point.
- Arrêt pour les piétons engagés sur la chaussée (freinage anticipé dès 35 m).
- Vitesse adaptée à la rue : boulevards, rues pavées plus lentes, rond-point, route de la plage.
- Les véhicules garés sont contournés après 4 s d'attente.
- Correctif : les longues lignes droites des itinéraires étaient courbées par le lissage. Les véhicules sont maintenant au centre de leur voie.

**Piétons (44 promeneurs + 63 personnes immobiles)** :
- Marche sur les trottoirs, avec des pauses devant les vitrines et des demi-tours. Les vendeuses portent leur bassine sur la tête.
- **Traversées aux passages piétons** (41 passages peints). Ils attendent une voie libre ; aux feux, ils traversent quand les voitures ont le rouge.
- Personnes assises aux arrêts de bus, sur les bancs et aux grillades ; vendeuses au marché ; groupes devant les boutiques ; zémidjans qui attendent les clients.

**Ambiance urbaine** :
- 6 abribus avec panneau BUS, 4 stations de zémidjans, grillades de rue (braise rougeoyante la nuit, fumée).
- Panneaux : STOP, cédez le passage, 50, feux, passage piéton, directions (Grand Marché, Plage, Centre-ville).
- Poubelles, bancs publics, et des lampadaires sur toutes les rues.

**Performances** :
- Mobilier fusionné en quelques maillages ; feux réduits à 4 maillages ; animations à cadence réduite au-delà de 35 m.
- Rendu et animation coupés hors de vue (véhicules au-delà de 170 m, piétons au-delà de 90 à 110 m).
- Calculs d'IA : environ 0,3 ms par image. Rendu : environ 200 appels de rendu (identique à la v0.5).

**Tests (simulation de 150 s)** :
- Véhicules dans un bâtiment : **0** ; points d'itinéraire dans un bâtiment : **0**.
- Piétons touchés : **0** ; piétons hors trottoir ou passage : uniquement pendant leur demi-tour au bord du rond-point.
- Véhicules bloqués : **0** (arrêt le plus long : 19 s, soit un cycle de feu).
- 2 à 6 véhicules engagés à l'orange franchissent la ligne au rouge (selon les essais).
- Quelques frôlements brefs aux jonctions sans feu (route de la plage) et au rond-point.

## 🗿 Mission 006 : lieux emblématiques (étape 1 : Place de l'Amazone)
**Emplacement** : en front de mer, au bout du boulevard nord-sud, sur la route côtière.
La carte est une **version stylisée** de Cotonou : aucune coordonnée géographique réelle n'est inventée ni reproduite.

**Réalisé (gratuit, procédural)** :
- Esplanade pavée de 72 × 28 m avec allée centrale, socle à gradins et piédestal en pierre.
- Plaque « AMAZONE – Hommage aux Agodjié » et panneau d'information historique.
- Deux drapeaux du Bénin, quatre jardins tropicaux (cocotiers, bougainvilliers, herbes), six bancs tournés vers la statue.
- Lampadaires de promenade, garde-corps face à l'océan et visiteurs.
- **Statue provisoire procédurale** : guerrière Agodjié en bronze, coupe-coupe à la main, environ 9,5 m sur un piédestal de 6,7 m.
  Éclairée par deux projecteurs la nuit. C'est une **interprétation libre**, et non une copie de l'œuvre réelle.
- Mini-carte : esplanade, jardins et icône « A ». Le nom de la zone s'affiche à l'écran.

**Tripo (en attente d'autorisation et de crédits)**, pour une statue de remplacement en GLB :

| Qualité | Coût |
|---|---|
| Standard (image de concept + Tripo 3.1, 30 000 faces) | 57 CU |
| Haute définition (géométrie et textures détaillées, 40 000 faces) | 102 CU |

**Droits** : la statue réelle (2022) est une œuvre protégée. Une interprétation libre est recommandée.
Vérifier aussi les conditions de Tripo (https://www.tripo3d.ai/terms) avant une diffusion commerciale.

**Prochaines étapes (après validation)** : Place des Martyrs, Marché Dantokpa (extension du marché actuel),
Boulevard de la Marina (le nom passera de l'axe central à la route côtière), zone côtière, nouveaux quartiers.

## 🏛 Mission 006 : étape 2 (v0.8), lieux emblématiques suivants
Tout est procédural et gratuit (0 crédit). Les monuments sont des **interprétations libres**.
La carte reste une **version stylisée**, sans coordonnées réelles.

- **Boulevard de la Marina** : la route côtière porte désormais ce nom (l'axe central devient « Boulevard central »).
  - Terre-plein central planté (cocotiers, bougainvilliers), lampadaires à double crosse, plaques de rue bleues.
- **Zone côtière** : 6 paillotes (toit de paille, comptoir, tables, clients), filets de pêche qui sèchent, pêcheurs, panneau « Baignade dangereuse ».
- **Place des Martyrs** (îlot entre la rue z = 100 et la Marina) :
  - mémorial en interprétation libre : stèle blanche sur gradins, flamme de bronze qui s'allume la nuit ;
  - quatre murs de plaques, trois drapeaux, jardins de flamboyants, bancs, visiteurs.
- **Marché Dantokpa** (l'ancien Grand Marché) :
  - bâtiment de marché à trois niveaux avec enseigne, deux halles couvertes en tôle remplies d'étals ;
  - arche « MARCHÉ DANTOKPA », porteurs, plus de vendeuses.
- **Quartiers** :
  - **quartier d'affaires** le long des boulevards centraux : tours vitrées de 5 à 7 étages, enseignes fictives (Banque Lagune, Hôtel Océan Bleu, Centre d'affaires) ;
  - **quartiers résidentiels** en périphérie : surtout des villas en concession et des immeubles de R+1 à R+2.
- **Mini-carte** : icônes D (Dantokpa), ✦ (Martyrs), A (Amazone), terre-plein de la Marina.
- **Correctif** : une grillade de rue (Mission 005) était posée sur la chaussée de la route côtière ; elle est replacée sur le trottoir.

**Performances (vue de départ, qualité Basse)** : 284 appels de rendu, 847 000 triangles, 225 Mo de mémoire JS.

## 🏠 Mission 010 : maison personnelle et vie quotidienne (v0.9)
Les missions 007 à 009 n'ont pas été reçues : cette version s'appuie sur la v0.8.
Tout est procédural (**0 crédit**, Tripo non nécessaire).

**La maison** (repère **M**, quartier situé entre la rue z = 100 et la Marina) :
- **Extérieur** : villa contemporaine sur deux niveaux.
  - Enduit clair, bardage bois, soubassement en pierre, grandes baies, auvent d'entrée.
  - Balcon à garde-corps vitré, toit-terrasse, citerne.
  - Clôture avec **portillon** et **portail coulissant**, allées pavées, jardin (cocotiers, bougainvilliers, flamboyant, manguier), terrasse avec parasol.
  - Lampes d'extérieur qui s'allument la nuit.
- **Intérieur visitable (rez-de-chaussée)** :
  - **pièces** : salon, cuisine avec coin repas, chambre, salle de bain, dressing, couloir d'entrée et garage ;
  - **portes** : porte d'entrée (E), portes intérieures automatiques, porte cuisine → garage ;
  - **éclairage** : 3 lumières réelles et des plafonniers (interrupteur à l'entrée) ;
  - **caméra** : en entrant, le toit et l'étage se masquent et la vue devient plongeante. Aucun chargement ni téléportation.
- **Limite** : l'étage existe en façade (balcon, baie, terrasse) mais **n'est pas visitable**, le moteur ne gère pas encore les escaliers.

**Activités (touche E, menus avec les chiffres 1 à 9)** :
- **Cuisine** :
  - le réfrigérateur propose amiwo, pâte & sauce gombo, atassi, akassa & poisson braisé, alloco et jus de bissap, avec un stock qui se recharge le matin ;
  - on cuisine à la cuisinière (vapeur, brûleur rougeoyant, grésillement), puis on mange assis à table. La jauge de faim remonte.
- **Chambre** : sieste (2 h) ou nuit complète jusqu'à 7 h. Le personnage s'allonge, l'écran passe au noir, l'heure avance et l'énergie est restaurée.
- **Salle de bain** : douche (eau animée et son, propreté à 100 %) ; lavabo (+20) avec un **vrai miroir réfléchissant**.
- **Dressing** : 6 tenues par personnage (homme ou femme), en 3 catégories : quotidien, élégant, décontracté. Exemples : boubou en bazin, costume, robe en bazin, jean et t-shirt. Le changement est visible immédiatement.
- **Salon** : télévision allumable, avec 5 chaînes fictives animées (Lagune Info, Sport+ Bénin, Météo Cotonou, Afro Clips, Nature TV). Canapé : ← → pour changer de chaîne, Espace pour allumer ou éteindre.
- **Garage** :
  - **voiture personnelle** (berline verte) ;
  - porte sectionnelle (E), et télécommande automatique qui ouvre le portail et le garage à l'approche en voiture ;
  - tableau à clés pour rapatrier la voiture au garage. Les murs et la porte fermée bloquent le véhicule.

**Jauges** : faim, énergie et propreté baissent avec le temps de jeu, plus vite en courant. Une énergie trop basse empêche de courir.

**Carte et marqueur M** :
- **M** apparaît sur la mini-carte, avec une flèche sur le bord quand la maison est hors de vue.
- La **carte générale** s'ouvre avec la touche **C** ; un toucher sur M ou le bouton « Définir M comme destination » active l'itinéraire.
- Pendant l'itinéraire : **ligne pointillée sur la carte, colonne lumineuse au-dessus de la maison**, distance affichée en permanence.
- C'est un guidage à vol d'oiseau, pas un GPS rue par rue.

**Sauvegarde automatique** (navigateur, toutes les 15 s et à la fermeture) :
- position de la maison, tenue, état du garage et du portail, position de la voiture personnelle ;
- faim, énergie et propreté, heure du jeu, position du joueur, réfrigérateur, télévision et lumières.
- Menu → **NOUVELLE PARTIE** pour tout effacer.

**Commandes tactiles (iPhone / Android)** : joystick à gauche (pousser à fond = courir), glisser à droite pour la caméra, boutons **E**, **saut / frein**, **course**, **klaxon** (en voiture), **CARTE** et **pause**. Qualité Basse par défaut sur mobile.

**Tests** :
- Maison :
  - collisions (murs, porte fermée / ouverte), repas (faim de 30 à 75), nuit (22 h → 07:00, énergie 100 %), douche (propreté de 15 à 100 %) ;
  - tenues, télévision (on/off/chaînes), garage (voiture bloquée puis sortie dans la rue), rapatriement, distance M ;
  - **sauvegarde puis rechargement réel de la page** : tout est restauré.
- iPhone 13 émulé (paysage) : joystick (déplacement), bouton E (montée en voiture), disposition compacte.
- Performances : 290 appels de rendu, 871 000 triangles.

## 🌦 Mission 008 : jour, nuit et météo dynamique (v1.0)

**Cycle jour/nuit** (déjà présent, enrichi) : soleil physique (ciel `Sky` de Three.js), lune, étoiles, ombres qui tournent avec le soleil, éclairage d'ambiance recalculé depuis le ciel (reflets). Périodes affichées sous l'horloge : *Lever du soleil* (5h20), *Matin*, *Après-midi*, *Coucher du soleil* (17h35), *Crépuscule* (18h55), *Nuit* (19h50).

**Météo** (`src/weather.js`) : ☀ dégagé, ⛅ nuageux, 🌧 pluie tropicale, 🌫 brume légère.
- Transitions progressives : les nuages s'épaississent, le soleil se voile, puis la pluie commence.
- Mode automatique : averses plus probables l'après-midi, brume côtière seulement le matin (elle se lève vers 10h30). Une averse dure 0,6 à 1,6 h de jeu.
- Pluie : 1 600 / 3 800 / 7 000 gouttes selon la qualité (Basse / Moyenne / Haute), animées entièrement par la carte graphique. Pas de pluie à l'intérieur de la maison.
- Orages : éclairs (flash de lumière) et tonnerre décalé. Son de pluie, étouffé à l'intérieur ; oiseaux et grillons se taisent sous la pluie.
- Sol mouillé : routes, trottoirs, pavés et latérite s'assombrissent et deviennent brillants, avec des flaques dans les creux. Ils sèchent en 1 à 3 h de jeu, plus vite au soleil. Herbe et sable sont peu affectés.
- Lampadaires, vitrines et fenêtres s'allument la nuit, et aussi pendant un gros orage en journée. Les phares suivent la même règle.

**Horloge et réglages**
- `T` avance d'une heure, `Maj+T` recule d'une heure, `Y` change la météo (auto → dégagé → nuageux → pluie → brume).
- Options : *Heure de la journée* (curseur), *Météo*, *Vitesse du temps* (figée, lente, normale = 20 min, rapide, très rapide).
- L'heure et la météo sont sauvegardées.

**Performances** : aucune lumière dynamique ajoutée. Pluie en un seul appel de dessin, sol mouillé calculé dans le shader existant (aucune texture en plus). L'éclairage d'ambiance n'est recalculé que quand l'heure ou la météo change vraiment. Aucun crédit Tripo/Scenario utilisé.

## 🎒 Mission 009 : arsenal et système d'équipement (v1.1)

**50 objets imaginaires**, 10 par catégorie : Protection, Gadgets, Outils, Énergie, Spéciaux. Le détail est dans `CATALOGUE_OBJETS.md`, généré par `node tools/catalogue.mjs` depuis `src/items.js`. Aucun objet ne reproduit une arme réelle ni un mécanisme réel : les effets « offensifs » sont des jouets lumineux, des bulles, du vent, des confettis.

**Modèles 3D** : procéduraux (formes simples fusionnées, 70 à 900 triangles, 1 à 3 appels de dessin par objet). Les icônes et l'aperçu 3D tournant sont rendus par le moteur du jeu, sans aucun fichier image. Aucune génération Tripo n'a été faite (crédits non autorisés).

**Inventaire** (touche `I`, ou bouton 🎒 sur iPhone)
- Grille d'icônes, filtres par catégorie et par rareté (Commun, Peu commun, Rare, Épique, Légendaire).
- Fiche descriptive avec aperçu 3D, pastille « nouveau » pour les objets jamais consultés.
- 4 emplacements : Tête, Corps, Main, Dos. Équiper / retirer au clic, au double-clic, avec Entrée ou E. Navigation au clavier (flèches, Tab).
- Sauvegarde : objets équipés et objets consultés.

**En jeu**
- Les objets équipés sont portés par le personnage (os de la tête, de la poitrine, de la main droite), avec une apparition animée. Ils sont rappelés dans le HUD.
- `G` (ou bouton ✦) utilise l'objet tenu en main. Effets réels :

| Type d'effet | Objets |
|---|---|
| Particules | bulles, confettis, étincelles, sable, poussière, arcs |
| Anneau | anneau lumineux |
| Lumière | dôme lumineux, lampe torche (faisceau et halo au sol) |
| Animations | drone en orbite (15 s), disque-boomerang, hologramme du drapeau, orbe flottante |
| Objet animé | parapluie qui s'ouvre |
| Caméra | zoom des jumelles |
| Photo | vraie capture d'écran à enregistrer |
| Sons | radio (air de musique), tam-tam (rythme) |
| Informations | scanner (compte réel des passants et véhicules à 35 m), boussole (distance et direction réelles vers M et la mer), carte |
| Jauges | gourde +8 énergie, calebasse +10 propreté (une fois par minute) |

- Passifs réels : récupération de l'endurance de +15 % à +60 % selon l'objet de dos. Les lunettes ambrées ajoutent un filtre doré à l'écran.

**Performances** : un seul système de particules (700 points) pour tous les effets. Seuls les objets équipés sont présents dans la scène. Les icônes sont rendues une seule fois, et l'aperçu 3D seulement pendant que l'inventaire est ouvert.

## ✧ Mission 011 : 20 pouvoirs mystiques (v1.2)

Univers **fantastique** inspiré des couleurs, motifs (tentures appliquées d'Abomey), paysages et sons du Bénin. Les pouvoirs et leurs symboles sont **inventés pour le jeu** : ils ne représentent ni divinités, ni rites, ni cérémonies réelles du Vodun. Un avertissement est affiché dans le menu.

**Fichiers**
- `src/powers-data.js` : les 20 pouvoirs (catégorie, niveau de déblocage, durée, recharge, puissance, coût, description) et les 20 symboles dessinés en vectoriel.
- `src/powers.js` : le système complet.

**Système de jeu**
- *Énergie mystique* (barre violette « MYSTIQUE ») : 100 au départ, +10 par niveau. Elle se recharge de 1,5/s, deux fois plus vite la nuit et trois fois plus près d'une pierre-portail découverte.
- *Progression* : 10 niveaux. On gagne de l'XP en lançant les pouvoirs (+25 la première fois, +4 ensuite), en recueillant les 20 symboles cachés (+60), en découvrant les 6 pierres-portails (+80) et en repoussant des feux follets (+15).
- *Déblocage* : au niveau 1 (Feu, Vent, Aura, Vision), puis progressivement jusqu'au niveau 10 (Éveil Mystique).
- *Améliorations* : 2 points par niveau, 3 rangs par pouvoir (durée +25 %, recharge −15 %, puissance +1 par rang).
- *Raccourcis* : 5 emplacements. `1`…`5` lancent, `R` sélectionne le suivant, `X` lance le pouvoir sélectionné. Sur iPhone, on touche directement la barre.
- *Menu* : touche `U` (bouton ✧ sur iPhone), avec catégories, fiches, statistiques, rang suivant, amélioration, attribution d'un raccourci et lancement.

**Éléments ajoutés pour que les pouvoirs aient de vrais effets**
- 9 feux follets : créatures imaginaires et inoffensives qui aspirent un peu d'énergie mystique au contact.
- 20 symboles cachés, visibles uniquement avec *Vision des Esprits*.
- 6 pierres-portails : Maison, Amazone, Martyrs, Dantokpa, Plage, Carrefour.

**Effets réels branchés sur le jeu**
- *Déplacement* : vitesse et saut (Vent, Éveil), téléportation qui respecte les murs (Pas Fantôme), téléportation vers une pierre découverte (Portail).
- *Jauges* : énergie restaurée (Régénération), endurance qui ne baisse plus (Aura, Terre).
- *Circulation et passants* : véhicules qui s'arrêtent et passants écartés (Bouclier, Eau, Terre, Colosse, Gardiens, Double). Passants et véhicules garés repoussés (Onde, Foudre, Danse).
- *Créatures et ambiance* : feux follets repoussés (Feu, Lumière, Onde, Gardiens, Danse, Éveil), brouillard magique (Brume), éclairs qui illuminent toute la ville (Foudre, Danse).

**Rendu**
- Auras en shader de flammes, coques de bouclier à motifs de losanges ou d'eau, symboles tournants au sol, colonnes de lumière.
- Blocs de latérite, gardiens géométriques de latérite et d'or, illusion du personnage, silhouettes lumineuses imaginaires.
- Sons synthétisés : cloche double (type gankogui), tambour à hauteur glissante, hochets, souffles.

**Performances** : aucune lumière dynamique (pas de recompilation de shaders), un seul système de particules, des effets créés seulement pendant leur durée. Le coût mesuré est d'environ +9 appels de dessin (pierres-portails). Aucun crédit payant utilisé.

## 📱 Jouer sur iPhone sans connexion

`npm run build` génère aussi `dist/iphone-hors-ligne/` : une application web installable (manifeste et icônes) avec cache hors ligne (service worker). Il faut l'héberger une fois en HTTPS, par exemple sur GitHub Pages (gratuit). On l'ouvre ensuite dans Safari, puis Partager → « Sur l'écran d'accueil ». Après cette première ouverture, le jeu se lance sans connexion.

## 🚗 Mission 012, étape 1 : garage AUTO CONCEPT et 13 véhicules (v1.3)

**Noms fictifs** (validés par l'utilisateur) : chaque véhicule s'inspire d'une catégorie et d'une silhouette de voiture réelle, sans logo, nom déposé ni copie exacte. Fichier `src/cars-data.js`.

| Véhicule | Inspiration | Vmax | 0-100 | Moteur |
|---|---|---|---|---|
| Voltex Cybra | pick-up électrique anguleux | 175 | 3,6 s | électrique |
| Fiorano Rosso 48 | supercar à moteur central | 215 | 3,0 s | V8 |
| Taurino Urca | SUV super-sportif | 190 | 3,8 s | V8 |
| Merano G-Kaiser | 4x4 carré de luxe | 160 | 5,5 s | V8 |
| Bavaro M-Coupé | coupé sportif | 200 | 3,9 s | 6 en ligne |
| Toyoka Sahel Cruiser | grand 4x4 | 165 | 7,0 s | diesel |
| Rangers Sport | SUV de luxe | 180 | 5,0 s | V6 |
| Stuttgarto 9-11 | sportive à moteur arrière | 205 | 3,4 s | 6 à plat |
| Ingolda RS Fastback | berline sportive | 200 | 3,6 s | V8 |
| Nikko GT-Raijin | coupé GT | 205 | 3,1 s | V6 biturbo |
| Royce-Ashanti Diamant | SUV d'ultra-luxe | 170 | 5,2 s | V12 |
| Dearborn Stallion | muscle car | 195 | 4,4 s | V8 |
| Toyoka Hilo | pick-up robuste | 150 | 9,5 s | diesel |

**Garage AUTO CONCEPT** (Quartier Jéricho, bord du boulevard nord) :
- showroom vitré avec enseigne, 3 plateaux tournants d'exposition (qui changent toutes les 25 s) ;
- comptoir d'accueil (`E` pour ouvrir le menu), 3 zones de livraison jaunes, atelier de réparation bleu (s'arrêter 2 s).

**Menu** :
- *Concession* : aperçu 3D tournant, statistiques et 6 couleurs par modèle ;
- *Mes véhicules* : distance, état, « Livrer ici », « Réparer », « Retirer ».

**Chaque véhicule** (`src/garage.js`) :
- modèle 3D propre ; roues qui tournent et braquent ; portière conducteur qui s'ouvre à l'entrée et à la sortie ;
- phares (allumés automatiquement la nuit), feux arrière, feux stop, feux de recul, phare dynamique unique partagé ;
- physique distincte (accélération, vitesse max, freinage, braquage, adhérence, glisse au frein à main) ;
- boîte de vitesses simulée (1 rapport pour l'électrique) ;
- son moteur propre (V8, V12, V6, 6 en ligne, 6 à plat, diesel, sifflement électrique) et klaxon propre (`K`) ;
- tableau de bord : vitesse, rapport, compte-tours, état, phares, vue ;
- vue intérieure / extérieure (`V`, bouton 👁 sur iPhone) avec sièges, planche de bord et volant qui tourne.

**Dégâts visuels non graphiques** : rayures et salissures au point de choc, phares cassés après 35 % puis 60 %, fumée au-delà de 65 %, véhicule moins rapide et direction qui flotte au-delà de 70 %. Tout est réparable à l'atelier.

**Sauvegarde et performances** :
- véhicules possédés sauvegardés (modèle, couleur, position, état), retrouvés où on les a laissés ;
- véhicules ajoutés à moins de 220 m du joueur et retirés au-delà de 280 m ;
- bâtiment affiché à moins de 170 m, voitures d'exposition à moins de 90 m.

Mesures en simulation : 0-100 km/h et vitesses max conformes aux fiches ; coût de rendu inchangé loin du garage. Aucun crédit payant utilisé.

## ✈ Mission 012, étape 2 : monde agrandi, aéroport et 8 avions (v1.4)

**Monde agrandi** (`src/airport.js`, seulement 6 maillages) : savane, banlieues (maisons basses aux toits de tôle), cocotiers et arbres, bande de sable, océan sur plusieurs kilomètres, lagune au nord. La disposition est stylisée, sans coordonnées géographiques réelles. Zone de vol d'environ 12 km × 12 km, avec demi-tour automatique aux limites.

**Aéroport de Cotonou** (à l'ouest, le long de la côte, relié par la route du boulevard z = 100) :
- piste de 1,5 km (marquages, seuils, numéros 09/27, balisage lumineux la nuit), voie de circulation et bretelles ;
- deux aires de stationnement, terminal vitré avec passerelles, tour de contrôle, 3 hangars, manche à air, clôture ;
- kiosque « VOLS » (`E`) : choix de l'avion, puis « Préparer sur la piste » ou « Embarquer au parking » ;
- pierre-portail de l'aéroport : 7e pierre du pouvoir Portail Mystique.

**8 avions** (noms fictifs, `src/aircraft-data.js`) :

| Avion | Type |
|---|---|
| Cesla 172 | avion léger à hélice |
| Atlantis 72 | avion régional à turbopropulseurs |
| Gulfwing G65 | jet privé |
| Faucon 8X | jet d'affaires triréacteur |
| Skyliner 737 | avion de ligne |
| Aeria A320 | avion de ligne |
| Jumbo 747 | gros-porteur à bosse |
| Aeria Super A380 | très gros-porteur à double pont |

**Chaque avion** :
- modèle 3D procédural (fuselage, ailes en flèche et dièdre, winglets, empennage classique ou en T, nacelles, inscription « BENIN LIFE AIR », drapeau sur la dérive) ;
- pièces mobiles : soufflantes de réacteur et hélices qui tournent, train rentrable, volets ;
- escalier d'embarquement au poste de stationnement, embarquement et débarquement avec fondu ;
- vue cockpit avec planche de bord (`V`) et son propre (grondement de réacteur ou bourdonnement d'hélice).

**Pilotage arcade** :

| Touche | Action |
|---|---|
| `Maj` / `Espace` | gaz + / gaz − (au sol, `Espace` freine quand les gaz sont coupés) |
| `Z/W` | monter (cabrer) |
| `S` | descendre (piquer) ; au sol à l'arrêt : repoussage |
| `Q`/`D` | virer en inclinant (au sol : roulette de nez) |
| `G` | train d'atterrissage |
| `B` | volets (automatiques par défaut) |

Décrochage sous la vitesse minimale. Atterrissage réussi si le train est sorti, la descente modérée et les ailes à plat. Sinon (ventre, trop brutal, eau, bâtiment), l'avion est ramené sur la piste, sans aucune image choquante.

**Tableau de bord de vol** : vitesse (km/h et nœuds), altitude, vitesse verticale, cap, horizon artificiel, gaz, train, volets, alarmes (décrochage, trop bas, rotation).

Mesures en simulation :

| Mesure | Résultat |
|---|---|
| Course de décollage | de 75 m (Cesla 172) à 720 m (Jumbo 747) |
| Montée | 100 à 350 m en 18 s |
| Virage en 8 s | de 27° (A380) à 115° (Cesla) |

Les atterrissages réussis et les cas de crash ont été vérifiés.

**Performances** : avions présents seulement à moins de 1,8 km ; en vol, la vue lointaine et la brume s'adaptent à l'altitude. En qualité basse, les banlieues lointaines ne s'affichent qu'en vol ou près de l'aéroport. Les murs invisibles de la ville sont ignorés par les avions. Positions des avions sauvegardées. Aucun crédit payant utilisé.

## 🍲 Mission 013, étape 1 : économie en FCFA, téléphone et cuisine béninoise (v1.5)

**Économie** (`src/economy.js`) :
- portefeuille en **FCFA** : solde de départ de 25 000 FCFA, puis **allocation quotidienne de 5 000 FCFA à 7 h**, versée aussi quand on dort jusqu'au matin ;
- historique des opérations (montant, lieu, jour, heure) ; un achat est refusé si le solde est insuffisant ;
- notifications à l'écran pour chaque achat, revenu ou livraison ;
- **sac de courses** : les achats faits en ville seront transportés puis rangés au réfrigérateur (bouton « Ranger mes courses »).

**Téléphone virtuel** (`N`, bouton 📱 sur iPhone) : Portefeuille et historique, **Courses à domicile**, Livraisons en cours, Mon frigo, Mon sac.
- Courses à domicile : produits frais, boissons et fruits ; panier, total, frais de 500 FCFA.
- La livraison arrive au réfrigérateur au bout de 30 minutes de jeu.

**Cuisine** (`src/food-data.js`, `src/food.js`) : **51 aliments béninois** avec prix indicatifs du jeu et un **modèle 3D chacun**.
- *Plats* : pâte rouge, pâte blanche, igname pilée (agoun), akassa, gari, riz, ablo, amiwo au poulet, watché, atassi, riz au gras, riz sauce tomate, haricots, gari avec sauce, alloco.
- *Sauces* : arachide, tomate, légumes, gombo, feuille, pimentée.
- *Garnitures* : wagashi, poisson grillé, poulet grillé.
- *Boissons* : bissap, baobab, gingembre, eau, akpan.
- *Fruits* : mangue, ananas, bananes, oranges, papaye, coco.
- *Produits frais et ingrédients* : 16 au total.

**Nouveau réfrigérateur** :
- onglets, icônes 3D générées progressivement, quantités, capacité de 80 ;
- on compose une assiette (plat + sauce + garniture), on la réchauffe à la cuisinière si un élément se mange chaud, puis elle est servie en 3D sur la table et on la mange ; la jauge de faim augmente de la somme des éléments ;
- boissons et fruits se consomment tout de suite.

**18 recettes** à la cuisinière (pâtes, amiwo, igname pilée, riz, watché, atassi, haricots, 6 sauces, poisson, poulet, alloco). Les ingrédients sont consommés et les portions rangées au réfrigérateur ; une seule préparation à la fois.

**Sauvegarde et compatibilité** : solde, historique, sac, livraisons, stock, préparation en cours et assiette servie sont sauvegardés. Les anciennes sauvegardes reprennent le stock de l'ancien réfrigérateur. Le rechargement gratuit du frigo chaque matin est remplacé par l'allocation quotidienne.

Testé : assiette pâte rouge + sauce arachide + poisson (faim +60), recette (riz au gras ×3), boisson, commande et livraison, allocation après une nuit, refus si solde insuffisant, sac vers frigo, sauvegarde et rechargement. Pas d'erreur sur ordinateur ni en simulation iPhone ; coût de rendu inchangé.

## 🧺 Mission 013, étape 2 : marché Dantokpa interactif (v1.6)

Le marché Dantokpa existant (halles couvertes, étals en plein air, arche « GRAND MARCHÉ ») devient interactif (`src/market.js`, `src/market-data.js`).
- **12 étals tenus par des vendeurs fictifs**, chacun avec un nom affiché au-dessus de l'étal et une spécialité : légumes, céréales et farines, fruits, poissons, volailles et œufs, épices, plats cuisinés, boissons fraîches, wagashi, tissus et vêtements, accessoires et décoration, produits locaux.
- Approche-toi d'un vendeur et appuie sur **E** (bouton E sur iPhone) : « Parler à… ».
- **Négociation** :
  - le vendeur annonce un prix au-dessus du prix de base, et tu proposes ton offre (±50 FCFA, −10 / −20 / −30 %) ;
  - le vendeur accepte, fait une contre-offre ou se vexe si l'offre est trop basse ;
  - sa patience est limitée : il finit par annoncer son « dernier prix ».
- **Achat** : choix de la quantité, paiement en FCFA dans le portefeuille (historique « Marché Dantokpa • nom du vendeur »).
  - Les aliments vont dans le **sac** puis au réfrigérateur de la maison.
  - Les objets (pagnes wax, chemise, robe, sandales, chapeau, sac en raphia, perles, panier, savon noir, karité, calebasse, statuette, radio, lampe solaire) vont dans **« Mes articles »** du téléphone. Ce sont des possessions : ils ne s'équipent pas encore sur le personnage.
- **Horaires** : les étals sont ouverts de 6 h à 20 h.
- **Ambiance** : appels de vendeurs au loin, petite voix stylisée quand le vendeur parle, son de paiement. Le brouhaha existant est conservé.
- **Sauvegarde** : les articles achetés sont sauvegardés. Les prix négociés repartent de zéro à chaque achat.

Testé :
- les 12 vendeurs sont accessibles malgré les collisions ;
- négociation et contre-offre ;
- achat d'aliments vers le sac et d'articles vers « Mes articles » ;
- refus si le solde est insuffisant ;
- marché fermé la nuit ;
- sauvegarde et rechargement ;
- parcours complet au toucher sur iPhone (E → choisir → −30 % → proposer → acheter → téléphone).

Aucune erreur détectée.

## 🛒 Mission 013, étape 3 : supermarché LAGUNA (v1.7)

**LAGUNA** est une enseigne **fictive** (nom inventé, aucun lien avec un supermarché réel). Le magasin se trouve sur le boulevard nord, côté est, face au garage AUTO CONCEPT. Son code est dans `src/supermarket.js`.

**Le bâtiment se visite** :
- parking avec places marquées, totem et enseigne, auvent ;
- façade vitrée et **portes coulissantes automatiques** ;
- ouvert de **7 h à 22 h** : la nuit, les portes restent fermées depuis l'extérieur, mais on peut toujours sortir ;
- à l'intérieur, le toit se masque pour garder la caméra sur le joueur ;
- 4 gondoles garnies de produits, réfrigérateurs vitrés au fond, étals de fruits et légumes ;
- 3 caisses, dont 2 tenues par des caissières, et des clients dans les allées ;
- la nuit, l'intérieur est éclairé sans lumière supplémentaire : les lampes de la maison, éteintes car loin, sont réutilisées.

**Les courses** :
- **E devant un rayon** ouvre la liste des produits (icônes 3D, prix affichés, sans négociation) ; on ajoute au **panier** (40 articles au maximum).
- Le panier s'affiche à l'écran (🛒 nombre d'articles et total).
- Rayons : fruits & légumes, épicerie, boissons, pain & en-cas, produits frais, hygiène & maison.
- **E à une caisse** affiche le détail du panier (on peut retirer des articles), le total et le bouton **PAYER**, puis le **ticket de caisse**.
- Les aliments vont dans le sac (puis au réfrigérateur), les autres articles dans « Mes articles ».
- **Sortir sans payer** déclenche l'alarme et ramène le joueur à l'intérieur.
- Si l'on s'éloigne autrement (portail, téléportation), les articles sont reposés en rayon.

**Nouveaux produits avec modèle 3D** : lait, jus d'orange, soda, yaourt à boire, pain, biscuits, chocolat, sardines, spaghetti, concentré de tomate, sucre.
- Le réfrigérateur de la maison a un nouvel onglet « Pain & en-cas ».
- Nouvelle **recette** : spaghetti sauce tomate (spaghetti + concentré de tomate + oignons).
- Nouveaux articles d'hygiène et de maison : dentifrice, gel douche, lessive, papier toilette, piles, bougies.

Testé :
- entrée par la porte avec les collisions ;
- les 11 points d'interaction répondent ;
- panier, puis tentative de sortie sans payer (bloquée), paiement, sortie ;
- portes fermées la nuit ;
- produits rangés au réfrigérateur ;
- parcours complet au toucher sur iPhone (rayon, ajout, caisse, paiement, ticket).

Aucune erreur détectée.

## 🚦 Mission 013, étape 4 : zémidjan, tokpa-tokpa et taxi (v1.8)

Nouvelle application **Transports** dans le téléphone (`N`), code dans `src/transport.js`.

**Trois services** (tarifs du jeu en FCFA, indicatifs) :

| Service | Type | Prise en charge | Prix |
|---|---|---|---|
| Zémidjan | moto-taxi : le conducteur porte la chemise jaune, tu es assis derrière lui | ~8 s | à partir de 200 FCFA |
| Tokpa-tokpa | minibus collectif, deux arrêts en route | ~18 s | le moins cher, à partir de 150 FCFA |
| Taxi | voiture avec plaque « TAXI », trajet direct | ~12 s | le plus cher, à partir de 600 FCFA |

**8 destinations**, toutes déjà présentes dans le jeu : ma maison, marché Dantokpa, supermarché LAGUNA, garage AUTO CONCEPT, place des Martyrs, jardin de Cadjèhoun, plage (boulevard de la Marina), aéroport. Pour chacune, le téléphone affiche la distance, la durée du trajet et le prix.

**Déroulement d'une course** :
1. Tu commandes depuis le téléphone ; un bandeau indique l'arrivée du véhicule et permet d'annuler gratuitement.
2. Le véhicule s'arrête sur la route la plus proche et klaxonne. Tu t'en approches et appuies sur **E** pour monter : la course est payée à ce moment-là.
3. Le véhicule roule tout seul sur la voie de droite des boulevards, arrondit les virages, contourne le rond-point central, s'arrête derrière la circulation, puis la dépasse si elle est bloquée.
4. **Espace** (ou le bouton ⏩) passe le trajet ; l'heure du jeu avance de la durée restante.
5. À l'arrivée, tu descends sur le trottoir du côté de la destination, et le véhicule repart.

Si personne ne monte au bout de 2 minutes, le véhicule repart sans rien facturer. Une commande est refusée si le solde est insuffisant.

Testé :
- 64 itinéraires (8 départs × 8 destinations) : aucun obstacle sur le trajet, aucun passage dans l'anneau du rond-point ;
- course complète en taxi (paiement, trajet de 37 s, descente du bon côté) ;
- tokpa-tokpa vers l'aéroport avec ses arrêts et « passer le trajet » ;
- annulation, solde insuffisant, attente trop longue ;
- commande, montée et « passer le trajet » au toucher sur iPhone.

Aucune erreur détectée.

## 🗺️ Mission 013, étape 6 : la région de Cotonou à l'échelle 1:5 (v1.9)

La carte s'étend désormais à **Porto-Novo, Ouidah, Pahou et Cocotomey**, reliées à Cotonou par la **RNIE 1**.
- Code : `src/region-geo.js`, `src/region.js`.
- Données générées par `tools/region/build_region.py` dans `src/region-data.js`.

**Sources vérifiables (aucune position inventée)** :
- **Centres des villes** : OpenStreetMap (Nominatim). Exemples : Porto-Novo 6,4991 N / 2,6253 E ; Ouidah 6,3666 N / 2,0854 E ; Pahou 6,3839 N / 2,2128 E ; Cocotomey 6,3918 N / 2,3012 E.
- **Tracé de la RNIE 1** (Ouidah – Pahou – Cocotomey – Cotonou – Sèmè-Kpodji – Porto-Novo) : 86 tronçons OpenStreetMap.
- **Lac Nokoué et lagune de Porto-Novo** : contours OpenStreetMap. Ils remplacent l'ancienne lagune rectangulaire fictive.
- **Trait de côte** : Natural Earth 1:10m (domaine public). Cette donnée est peu détaillée, et le littoral est donc tracé de façon simplifiée.
- Les données brutes sont dans `tools/region/osm/`. Données © contributeurs OpenStreetMap, licence ODbL.

**Échelle et raccords de jeu** (signalés, non géographiques) :
- 1 m du jeu = 5 m réels ; Ouidah est à environ 7,5 km de Cotonou dans le jeu.
- La ville du jeu reste celle des missions précédentes. Elle n'est pas un plan réel de Cotonou.
- La RNIE 1 est reliée aux boulevards de la ville : sortie nord par le boulevard x = −100, sortie est par le boulevard z = −100.
- Le littoral réel est raccordé progressivement à la plage du jeu à moins de 1,5 km de la ville.
- Les petits trous de la donnée routière (tronçons non renvoyés par Nominatim) sont comblés en ligne droite.

**Dans le jeu** :
- **Route** : RNIE 1 goudronnée avec bandes de rive et ligne médiane, accotements en terre ; habitations et cocotiers le long de la route.
- **Villes** : générées autour de leur centre réel, avec des quartiers en damier orientés comme la route, des rues en terre, des maisons, des immeubles et boutiques au centre, et des cocotiers. Chaque ville a son panneau d'entrée (par exemple « PORTO-NOVO — Capitale du Bénin »).
- **Monuments** : aucun monument réel n'a été ajouté, faute de positions vérifiées pour chacun.
- **Déplacements** : à pied, en voiture ou à moto, on quitte la ville librement. La mer et les lacs arrêtent les déplacements, et le nom de la zone s'affiche (ville, RNIE 1, Lac Nokoué, Environs de Cotonou).
- **Carte (C)** :
  - bouton « Voir la région / Voir Cotonou » ;
  - la région s'affiche avec ses villes, la route, le lac, l'aéroport et la distance de chaque ville ;
  - hors de Cotonou, la mini-carte passe automatiquement sur la carte de la région.
- **Transports** :
  - le taxi, le zem et le tokpa-tokpa vont jusqu'aux 4 villes, avec un tarif dégressif au-delà de 1,5 km ;
  - « passer le trajet » avance l'heure d'au plus 1 h.
- **Performances** : villes et bords de route chargés à moins de 1,2 à 1,8 km et libérés au-delà. À Porto-Novo (simulation iPhone), le rendu reste à 13 appels de dessin.

Testé :
- 12 trajets en taxi vers les 4 villes, sans obstacle ;
- sorties nord et est de la ville ;
- course complète jusqu'à Ouidah ;
- carte de la région sur ordinateur et sur iPhone ;
- aucune erreur.

## 🏢 Mission 014, étape 1 : siège de NOVA BOOK (v2.0)

Le siège de **NOVA BOOK**, la maison d'édition du joueur, se trouve dans le quartier d'affaires, au bord du boulevard central, au sud-est du rond-point. Le bâtiment est entièrement procédural (aucune ressource payante) ; le code est dans `src/nova.js` et `src/nova-data.js`.

**Extérieur** :
- immeuble moderne vitré de 6 niveaux, avec bandeaux d'étage et poteaux ;
- grande enseigne lumineuse « NOVA BOOK » sur le toit (plus brillante la nuit) et enseigne verticale « NOVA » ;
- auvent d'entrée, portes coulissantes automatiques, jardinières ;
- parking réservé aux employés et visiteurs, avec panneau et voitures garées.

**Intérieur (6 niveaux visitables)** :

| Niveau | Contenu |
|---|---|
| Rez-de-chaussée | hall, réception avec réceptionniste, mur logo, espace d'attente, présentoirs de livres, service commercial et clientèle (2 employés), salle de réunion vitrée avec écran interactif (E l'allume et affiche le catalogue) |
| 1er étage — graphisme | 8 postes avec écran (logiciel fictif *NovaDesign*) et tablette graphique, panneaux de couvertures, mur d'affiches et d'illustrations ; 5 personnes au travail |
| 2e étage — maquettisme et édition | postes à double écran (*NovaPage*), tables de correction avec manuscrits, rayonnages de livres et de maquettes ; 5 personnes |
| 3e étage — informatique et audiovisuel | postes triple écran (*NovaCode*), salle de tests et de maintenance avec baies de serveurs ; stations de montage (*NovaCut*), monteurs avec casque, studio (fond vert, caméra, projecteurs, micro) ; 5 personnes |
| 4e étage — impression | presse offset, traceur grand format, relieuse, massicot, plastifieuse, poste de contrôle qualité, palettes de papier, zone d'emballage avec tapis ; 4 imprimeurs ; machines animées |
| 5e étage — direction | bureau vitré du PDG, administration (comptable, RH, secrétaire), salle du conseil, espace de repos avec machine à café, agent d'entretien |

Machines du 4e étage : rouleaux, chariot, lame, livres et cartons bougent. **E** devant une machine la fait tourner à plein régime.

Bureau du PDG :
- grand bureau en bois, fauteuil, 3 écrans, téléphone, canapé, table de réunion privée, bibliothèque, tableaux, grandes baies vitrées ;
- **E** permet de s'asseoir au bureau ou dans le canapé ;
- un interrupteur règle l'éclairage (blanc, chaleureux, bleu NOVA, tamisé) ;
- un **écran mural de statistiques** s'actualise en direct (heure, effectif par département, masse salariale).

Dans tout le bâtiment :
- ascenseur et escaliers à chaque étage (**E**) ;
- sanitaires visitables ;
- panneau d'étage devant l'ascenseur ;
- **E** près d'un employé pour le saluer : il répond en décrivant son travail.

**Équipe de départ** : 26 employés fictifs (nom, métier, étage, salaire mensuel de base) dans `src/nova-data.js`. Chacun a une animation adaptée : frappe au clavier, dessin sur tablette, lecture de manuscrit, montage avec casque, manipulation de machine, balai.

**Technique** :
- collisions par étage (le niveau courant filtre les obstacles) et plancher du joueur à la hauteur de l'étage ;
- seul l'étage visité est affiché et animé ; les niveaux supérieurs et le toit sont masqués à l'intérieur ;
- employés créés à la première visite de leur étage ;
- caméra intérieure plus large dans ces grands plateaux ;
- la nuit, les lampes de la maison, éteintes car loin, sont réutilisées pour éclairer l'étage, sans lumière supplémentaire.

**Pas encore fonctionnel** : le logiciel de gestion de l'ordinateur du PDG (recrutement, salaires, commandes, comptabilité, groupe de sociétés, banque). Le jeu l'indique clairement quand on s'assoit au bureau. C'est l'objet des étapes suivantes.

## 🏠 Complément mission 010 : maison entièrement aménagée (v2.1)

Le plan des pièces, les portes et toutes les fonctions existantes sont conservés : réfrigérateur et recettes (mission 013), cuisinière, table, sommeil, douche, tenues, télévision, garage, marqueur M. L'aménagement est ajouté par `src/home-plus.js`. Tout est procédural (coût : 0).

**Cuisine** :
- crédence carrelée, four sous la plaque, micro-ondes ;
- **placards hauts à portes ouvrantes** (E) avec assiettes, verres, bols et tasses ;
- ustensiles suspendus, égouttoir, casserole, planche, poubelle à pédale, suspensions au-dessus de la table, rangement au-dessus du réfrigérateur, tableau.

Interactions de la cuisine :
- **micro-ondes** : réchauffe l'assiette composée au réfrigérateur ;
- **évier** : faire la vaisselle (propreté +20) ;
- les courses du marché Dantokpa et du supermarché LAGUNA se rangent toujours au réfrigérateur.

**Salon** :
- deux fauteuils (on peut s'y asseoir), guéridon avec lampe, lampadaire ;
- rideaux, deux tableaux, climatisation, étagère murale ;
- **rubans LED** derrière et sous la télévision, réglables (E près de la porte) ;
- télévision : nouveau **programme TV du jour** (émissions fictives par chaîne et par heure). Assis sur le canapé, les flèches servent de télécommande pour changer de chaîne, Espace allume ou éteint.

**Chambre** :
- armoire moderne (ouvre les tenues), tête de lit capitonnée, banc en bout de lit, plaid ;
- commode, grand miroir, rideaux, tableau, climatisation, tapis ;
- **LED d'ambiance réglables**.

Espace informatique de la chambre :
- bureau, fauteuil ergonomique, écran, clavier, souris, enceintes, casque, lampe, tour lumineuse ;
- **ordinateur NOVA OS** : finances personnelles (solde, opérations), « Mes entreprises » (effectif et masse salariale de NOVA BOOK par département ; la gestion complète arrive avec la mission 014, étape 2), décoration.

Espace jeux de la chambre :
- télévision murale, meuble avec LED, **console de salon NOVA X** (nom fictif, à la place d'une marque réelle), manette, boîtiers de jeux, fauteuil gaming ;
- **2 jeux jouables** : *Zem Rush* (esquiver les voitures en zem) et *Penalty Cotonou* (viser et tirer, 5 tirs) ;
- l'image s'affiche aussi sur la télévision de la chambre, avec les records ;
- commandes : flèches et Espace, ou boutons tactiles sur iPhone.

**Personnalisation** (ordinateur ou E près de la bibliothèque du salon) :
- couleurs du canapé et des fauteuils, du mur d'accent, des rideaux, des façades de cuisine ;
- LED du salon et de la chambre (ou éteintes) ;
- tous les choix et les records sont **sauvegardés**.

Testé :
- les 13 points d'interaction des pièces ;
- placards, micro-ondes avec une assiette réelle, ordinateur, décoration ;
- les deux jeux ;
- sauvegarde et rechargement ;
- parcours au toucher sur iPhone.

Aucune erreur détectée.

## 🚦 Mission 015, phase 1 : Cotonou vivante, zone de test (v2.2)

Comme demandé, le système est d'abord testé **à Cotonou** avant d'être étendu aux autres villes. Les piétons et la circulation existants sont conservés et enrichis. Code : `src/population.js`, `src/pedestrians.js`, `src/vehicles.js`. Tout est procédural (coût : 0).

**Habitants** (réserve de 64 passants sur ordinateur, 36 sur iPhone) :

| Profil | Particularités |
|---|---|
| Habitants, jeunes | téléphone pour certains |
| Personnes âgées | démarche lente et penchée, canne ; boubou ou foulard |
| Élèves | tenue kaki, cartable |
| Étudiants | sac à dos |
| Employés de bureau | chemise claire, mallette |
| Commerçantes | bassine sur la tête |
| Travailleurs | tenue orange |
| Parents | accompagnés d'un enfant |

**Comportements** :
- marcher sur les trottoirs et traverser aux passages piétons en attendant le feu (déjà présent) ;
- s'arrêter devant les vitrines ;
- **entrer dans les boutiques et en ressortir** ;
- **téléphoner en marchant** ;
- **discuter à deux** en se faisant face, avec des gestes ;
- attendre aux arrêts, monter dans le bus et en descendre.

**Circulation (52 véhicules)** :
- zems, voitures, tokpa-tokpa, et nouveaux véhicules : **6 taxis** (jaunes, panneau TAXI), **3 bus** (« LIGNE 1 • DANTOKPA »), **3 camions**, **4 camionnettes de livraison**.
- Les conducteurs gardent l'IA existante (voies, feux, priorités, rond-point, distances de sécurité, piétons). En plus :
  - prise en compte de la longueur des bus et des camions pour les distances ;
  - ralentissements aux **heures de pointe** autour du marché Dantokpa et sur les grands axes ;
  - **klaxons** dans les bouchons près du joueur.

**Ligne de bus** :
- 14 arrêts au total : arrêts « BUS • LIGNE 1 » ajoutés automatiquement sur le trottoir des boucles empruntées par les bus (poteau, banc, voyageurs), plus les abribus existants ;
- les bus et les tokpa-tokpa marquent l'arrêt (6 s et 4 s) ;
- des voyageurs montent et disparaissent dans le véhicule, d'autres descendent et repartent à pied.

**Densité selon l'heure** :

| Heure | Passants actifs | Véhicules actifs |
|---|---|---|
| 4 h | 12 | 9 |
| Pointe de 7 h 30 | 64 | 52 |
| Midi | 57 | 44 |
| Pointe de 18 h | 64 | 52 |
| 23 h | 19 | 15 |

**Réglage dans les Options** : « Population et circulation : Faible / Moyenne / Élevée » (Moyenne par défaut sur iPhone, Élevée sur ordinateur), sauvegardé avec les paramètres.

**Optimisation** :
- *pooling* : les passants et véhicules en trop sont mis en réserve loin du joueur, puis réapparaissent hors de sa vue, sur une portion libre ;
- animations réduites au loin, personnages cachés au-delà de 90 à 110 m.

**Parler aux habitants (E)** :
- discuter, avec des expressions du français de Cotonou (« Bonne arrivée ! », « On dit quoi ? », « Doucement doucement… ») ;
- **demander son chemin** : distance et direction de 9 lieux du jeu, avec le conseil de prendre un zem si c'est loin ;
- **infos sur le quartier** ;
- **acheter des fruits aux commerçantes** : payés en FCFA, rangés dans le sac.

**Son** : un brouhaha de foule proportionnel au nombre de passants proches, en plus de celui du marché et des klaxons.

Testé :
- simulation accélérée à 5 heures de la journée ;
- 2 rapprochements brefs sur 3 739 contrôles entre véhicules ;
- 8 montées et 4 descentes aux arrêts ;
- 7 entrées en boutique et des conversations ;
- dialogue avec un passant ;
- aucune erreur ;
- iPhone (densité moyenne) : 279 appels de dessin à l'heure de pointe.

## 🏘️ Mission 015, phase 2 : habitants et trafic dans toute la région (v2.3)

Code : `src/towns-life.js`. Tout est procédural (coût : 0).

**Habitants à Porto-Novo, Ouidah, Pahou et Cocotomey** :
- un seul groupe de personnages (24 sur ordinateur, 14 sur iPhone) est réutilisé pour la ville la plus proche du joueur, jamais pour toutes les villes à la fois ;
- les habitants marchent dans les allées entre les pâtés de maisons et font des pauses (aucun passage dans les murs sur 1 890 contrôles) ;
- vendeuses et zems stationnés au bord de la RNIE 1, au centre de chaque ville ;
- densité selon l'heure, le réglage choisi et la ville : Porto-Novo la plus animée, puis Ouidah ;
- on peut leur parler partout : discussion, chemin (les 4 villes sont ajoutées aux destinations), infos sur la ville (Porto-Novo capitale, Ouidah ville d'histoire et Route des Esclaves, etc.).

**Trafic sur la RNIE 1** :
- 16 véhicules sur ordinateur, 9 sur iPhone : voitures, taxis, tokpa-tokpa, camions, camionnettes, pick-up, zems, bus ;
- ils roulent sur la voie de droite, dans les deux sens, autour du joueur, et sont recyclés devant ou derrière lui hors de sa vue ;
- distances de sécurité (au moins 10 m mesurés), ralentissement dans les villes ;
- arrêt devant le joueur, sa voiture et les piétons, avec klaxon s'ils attendent.

## 🗺️ Complément mission 015 : carte complète, entreprises et accès au bureau du PDG (v2.3)

**Carte (C)** : 56 lieux dans un registre (`src/places.js`).
- Chaque lieu a : nom, icône, catégorie, adresse dans le jeu, marqueur, et une fiche avec un **statut clair** :
  - 🟢 lieu réel à sa position OpenStreetMap : les 4 villes de la région ;
  - 🟡 lieu réel représenté de façon stylisée : marché Dantokpa, places des Martyrs et de l'Amazone, plage, aéroport, noms des quartiers de Cotonou ;
  - 🟠 lieu fictif : maison, NOVA BOOK, LAGUNA, AUTO CONCEPT, banque, hôtel, centre d'affaires, boutiques et maquis des enseignes.
- **Absents de la carte** : stations-service et port, car ils n'existent pas encore dans le jeu.
- Recherche par nom, 11 filtres de catégories, liste triée (NOVA BOOK en tête).
- Touche un marqueur ou une ligne pour afficher la fiche du lieu.
- **Itinéraire** sur le réseau routier, jusqu'aux autres villes. Il est tracé en jaune sur la carte et la mini-carte ; la distance restante s'affiche ; « Arrivé » à destination.
- **Découvertes** : les lieux approchés sont marqués ✓.
- Les découvertes et l'itinéraire en cours sont **sauvegardés**.

**Entreprises** :
- **NOVA BOOK** a une icône spéciale « NB » dorée.
- NOVA DIGITAL, MEDIA, IMMOBILIER, TRANSPORT et DISTRIBUTION sont placées sur des immeubles de bureaux existants. Elles sont indiquées « société pas encore créée — locaux réservés », car la création des sociétés arrive avec la mission 014.

**Entrée principale de NOVA BOOK** :
- allée piétonne en pierre avec bandes jaunes de guidage, 6 bornes lumineuses, appliques, lampadaires ;
- totem « NOVA BOOK • Accueil → • Parking → », bandeau « ENTRÉE PRINCIPALE » au-dessus des portes automatiques ;
- **barrière de parking** qui se lève à l'approche de la voiture du joueur ;
- éclairage plus fort la nuit ;
- le mobilier urbain ne bloque plus l'entrée.

**Parcours jusqu'au bureau du PDG** (le bureau reste au 5e étage, à la Direction) :
1. La rue, puis la porte principale.
2. Le hall, avec **la réceptionniste qui indique le chemin** et un panneau « ASCENSEURS → • Bureau du PDG : 5e étage ».
3. Un **couloir dégagé** jusqu'aux ascenseurs et escaliers : la salle de réunion du rez-de-chaussée et la salle serveurs du 3e ont été raccourcies, car elles bloquaient l'accès.
4. L'ascenseur jusqu'au 5e étage.
5. La **porte « BUREAU DU PDG »** :
   - battant en bois avec poignée animée et plaques « BUREAU DU PDG — PDG — NOVA BOOK — Accès réservé » des deux côtés ;
   - **E pour ouvrir ou fermer**, de l'extérieur comme de l'intérieur, avec un son discret ;
   - fermée, elle bloque le passage ;
   - **refermeture automatique** quand le PDG s'éloigne.

Testé :
- le parcours entier, à pied avec les collisions : rue → porte → hall → réceptionniste → couloir → ascenseur → 5e étage → porte fermée (bloquée) → ouverte → bureau → refermeture automatique → sortie ;
- l'itinéraire de Ouidah à NOVA BOOK (8,6 km par la route) ;
- la recherche ;
- la sauvegarde après rechargement ;
- la carte sur iPhone ;
- aucune erreur.

## 💼 Mission 014, étape 2 : NOVA Gestion, le logiciel du PDG (v2.4)

On l'ouvre en s'asseyant **au bureau du PDG** (5e étage), ou depuis l'ordinateur de la maison (onglet « Mes entreprises » → « Ouvrir NOVA Gestion »). Code : `src/company.js`, `src/biz-ui.js`. Tout est procédural (coût : 0).

**Réglages appliqués** (proposés et non contestés) :
- **1 mois de jeu = 7 jours de jeu** (environ 2 h 20 de jeu réel) ;
- **capital de départ de 3 000 000 FCFA** sur le compte de l'entreprise, séparé du compte personnel ;
- charges fixes de 400 000 FCFA par mois (électricité, internet, entretien).

**Les 10 rubriques** :

| Rubrique | Contenu |
|---|---|
| Tableau de bord | trésorerie, chiffre d'affaires, dépenses, salaires, bénéfice net du mois, masse salariale, commandes en cours, alertes |
| Mes entreprises | NOVA BOOK et les 5 autres sociétés, indiquées « pas encore créées » (étape 4) |
| Employés | 26 employés de départ avec nom fictif, métier, département, étage, salaire, compétence, expérience, échelon, moral, productivité, état ; **former** (150 000 FCFA, 1 jour, +10 de compétence), **promouvoir** (+15 % de salaire, 3 échelons), **licencier** (indemnité d'un mois, avec confirmation) |
| Recrutement | 6 candidats renouvelés chaque mois, nouvelle annonce à 50 000 FCFA ; les recrues prennent un poste libre de leur étage et **apparaissent dans l'immeuble** |
| Salaires | à chaque fin de mois : notification, liste des employés et salaires individuels, total, **validation par le PDG** (paiement automatique seulement si tu l'actives) ; tant que ce n'est pas payé, le moral baisse chaque jour |
| Commandes | 11 prestations (romans, manuels scolaires, livres éducatifs, mise en page, couvertures, impression de livres et de brochures, affiches, supports publicitaires, vidéos promotionnelles, site de commande), voir ci-dessous |
| Comptabilité | journal comptable, **virements** entre le compte personnel et le compte de l'entreprise (apport du PDG, dividende) |
| Investissements | équipements par département, 3 niveaux, +25 % de production par niveau |
| Immobilier | le siège (propriété de l'entreprise) ; les autres locaux arrivent à l'étape 4 |
| Statistiques | historique mensuel, effectif et production par département |

**Commandes et contrats** :
- chaque commande a un client fictif, un montant, une charge de travail, un délai, un département responsable et un avancement ;
- les équipes travaillent **de 7 h à 19 h** ;
- l'avancement dépend de la compétence, du moral, de l'échelon et de l'équipement ;
- la capacité de chaque département dépend de son effectif ;
- le paiement se fait à la livraison, avec 30 % de moins en cas de retard.

**Alertes financières** : si la trésorerie ne couvre pas la paie, une alerte propose des décisions : apport personnel, livraison des commandes en cours, réduction des effectifs.

**Autres liens** :
- l'écran mural du bureau du PDG affiche la trésorerie, le chiffre d'affaires et les commandes en direct ;
- la salle du conseil ouvre le bilan de la réunion de direction ;
- tout est sauvegardé : trésorerie, employés, candidats, commandes, journal, historique, équipements, paie en attente.

**Testé** (un mois simulé en acceptant toutes les commandes) :
- 13 commandes livrées : la trésorerie passe de 3 M à 11,1 M FCFA ;
- paie de 5,9 M FCFA validée, soit un bénéfice d'environ 2,2 M FCFA par mois ;
- recrutement, licenciement, formation, promotion, alerte de trésorerie ;
- bureau du PDG vers le logiciel, sauvegarde et rechargement ;
- parcours au toucher sur iPhone.

Aucune erreur détectée.

## 🏦 Mission 014, étape 4 : groupe NOVA et banque (v2.5)

Tout se passe dans NOVA Gestion (bureau du PDG ou ordinateur de la maison). Code : `src/group.js`. Coût : 0.

**Mes entreprises** :
- NOVA DIGITAL, NOVA MEDIA, NOVA IMMOBILIER, NOVA TRANSPORT et NOVA DISTRIBUTION peuvent être :
  - **créées** (4,5 à 6 M FCFA : 4 employés débutants, capital de 2 M) ;
  - ou **rachetées** (13 à 16 M FCFA : 8 employés expérimentés, clientèle, trésorerie de 1,5 M) ;
  - et payées par NOVA BOOK ou par le compte personnel.
- Chaque société a **sa trésorerie, ses employés, son directeur, ses locaux, ses équipements, ses recettes et ses charges**.
- Recettes quotidiennes selon la compétence et le moral de l'équipe, la présence d'un directeur, les équipements et une fluctuation du marché.
- Charges mensuelles : salaires (paie automatique activable ou désactivable), loyer de 300 000 FCFA, charges fixes de 150 000 FCFA.
- Gestion de chaque société :
  - recruter selon le métier du secteur (chauffeurs-livreurs, logisticiens, vendeurs, agents immobiliers… nouveaux métiers) ;
  - **nommer un directeur** (+40 % de salaire, production améliorée) et licencier ;
  - investir dans les équipements (+25 % par niveau) ;
  - **acheter les locaux** (9 M FCFA, plus de loyer) ;
  - percevoir les bénéfices par virement.
- Sur la carte, les sociétés actives deviennent « société active » (bureaux non aménagés pour la visite).

**Banque** :
- un compte personnel et un compte par société, avec soldes ;
- **virements** entre tous les comptes ;
- **relevés bancaires** par compte ;
- **prêts facultatifs** (taux du jeu 1,2 % par mois, 12 mensualités prélevées automatiquement, remboursement anticipé possible) ;
- **bilan mensuel du groupe** (CA, charges, résultat, trésorerie par société) ;
- notifications de paiement et alertes de découvert.

L'argent personnel et l'argent des entreprises sont strictement séparés : les seuls passages se font par virement, apport ou dividende.

**Testé** (un mois simulé) :
- création refusée faute de fonds ;
- prêt de 22 M, création de NOVA DIGITAL, rachat de NOVA TRANSPORT avec nomination d'un directeur ;
- résultats du mois : NOVA DIGITAL −140 000 FCFA (débutante), NOVA TRANSPORT +1,2 M FCFA ;
- mensualité du prêt prélevée, bilan, virement vers le compte personnel, relevés ;
- carte mise à jour, sauvegarde et rechargement.

Aucune erreur détectée.

## Mission 016 — phase 1 : 175 aliments, frigo du PDG, toilettes H/F

**Catalogue alimentaire : 175 références distinctes** (62 existantes + 113 nouvelles), classées en 14 catégories :
- plats traditionnels ;
- pâtes et préparations à base de maïs ;
- riz et céréales ;
- ignames et tubercules ;
- haricots et légumineuses ;
- sauces ;
- poissons et fruits de mer ;
- viandes et volailles ;
- fruits locaux ;
- légumes ;
- épices et condiments ;
- pâtisseries et collations ;
- boissons locales (aucun alcool) ;
- produits transformés.

Chaque aliment a un nom, une catégorie, une description, un modèle 3D procédural (icône générée), un prix indicatif en FCFA et une valeur nutritive (faim).

Nouveaux plats vérifiés sur des sources publiques : télibo, dakouin, yêkêyêkê, toubani, piron, adowè, tô, calalou dahoméen, fontêtê, sauces crincrin et assrokouin, dja, aklui, koko, dèguè, lait caillé, yovo doko, atchomon, kuli-kuli, afitin, akara…

Les spécialités non vérifiables ou surtout étrangères n'ont pas été ajoutées.

Renommages : « Wɔ̌ (pâte blanche) », « Poisson braisé », « Haricots préparés ».

**Où les trouver** :
- **Réfrigérateur de la maison** : tous les aliments, avec un filtre « En stock seulement » et 18 nouvelles recettes (télibo, dakouin, yêkêyêkê, toubani, piron, adowè, tô, aklui, koko, akara, atchomon, crincrin, fontêtê, dja…).
- **Supermarché LAGUNA** : 143 aliments en rayon, avec un nouveau **rayon Traiteur** (plats à emporter).
  - Les **stocks sont limités** (rupture affichée) et réapprovisionnés chaque matin.
  - Les stocks sont sauvegardés.
- **Téléphone** :
  - « Courses à domicile » propose les 175 produits, classés par catégorie ;
  - la nouvelle app **« Cuisine du Bénin »** est un catalogue avec descriptions.
- **Marché Dantokpa** : les vendeurs existants (60 vendeurs prévus en phase 2).

**Réfrigérateur du bureau du PDG** (5e étage de NOVA BOOK) :
- un frigo vitré dont la porte s'ouvre et se ferme avec une lumière intérieure ;
- 16 boissons et en-cas : eau, jus, bissap, gingembre, baobab, eau de coco, yaourt, noix de cajou, kuli-kuli… ;
- actions possibles : consulter, boire ou manger, emporter dans le sac ;
- **réapprovisionnement** :
  - une confirmation est demandée avant de payer ;
  - le compte débité est au choix : compte personnel ou trésorerie NOVA BOOK (passée en frais dans la comptabilité) ;
  - le solde est vérifié et le double paiement est bloqué ;
  - tout se fait uniquement en monnaie virtuelle.

**Toilettes Hommes / Femmes à chacun des 6 niveaux** de NOVA BOOK (l'ancien bloc mixte non accessible a été remplacé) :
- deux salles séparées, chacune avec une porte battante, une plaque et un pictogramme, et une fermeture automatique ;
- un panneau « TOILETTES H • F » dans le couloir ;
- 2 lavabos, du savon, un miroir, un essuie-mains, une poubelle, une grille de ventilation et un éclairage à détection de présence ;
- 2 cabines avec WC, papier et porte animée ;
- côté Hommes : urinoirs ; côté Femmes : poubelles sanitaires et une table à langer ;
- des murs opaques côté façade vitrée.

Actions :
- se laver les mains (propreté +8) ;
- utiliser une cabine (la porte se ferme, puis la chasse d'eau) ;
- un rappel s'affiche si tu sors sans te laver les mains.

**Testé** :
- les 175 identifiants et noms sont uniques ;
- toutes les recettes pointent vers des aliments existants ;
- recette du télibo ;
- commande livrée ;
- rupture puis réassort chez LAGUNA ;
- portes, lavabo et cabine des toilettes (étages 2 et 3) ;
- frigo du PDG : boire, puis réassort payé une seule fois malgré deux clics ;
- sauvegarde et rechargement ;
- test de fumée sur PC et affichage sur iPhone.

Aucune erreur détectée.

## Mission 016 — phase 2 : marché Dantokpa, 60 vendeurs

**60 vendeuses et vendeurs** (personnes fictives, noms uniques) répartis en **12 allées** :
- céréales & farines (5) ;
- ignames & tubercules (4) ;
- légumes & feuilles (6) ;
- fruits (6) ;
- poissons & fruits de mer (5) ;
- viandes & volailles (5) ;
- épices & condiments (5) ;
- plats cuisinés & en-cas (7) ;
- boissons (4) ;
- tissus, vêtements & chaussures (6) ;
- artisanat & bijoux (4) ;
- ménage, ustensiles & divers (3).

Les 12 vendeurs existants sont conservés (mêmes noms et spécialités, gamme élargie).

Contenu :
- **166 des 175 aliments** sont vendus au marché ; les 9 autres sont des produits de supermarché (soda, lait UHT, conserves…).
- **24 nouveaux articles** : boubou, fripes, chaussures, bijoux en laiton, tableaux, tambour, marmite, mortier et pilon, natte, chargeur, cahiers…
- Chaque étal a un vendeur visible, du même sexe que sur son étiquette, affiché seulement à moins de 42 m pour préserver les performances.

**Nouveautés** :
- **stock limité par étal** : « Épuisé » quand il n'y en a plus, réassort chaque matin, stocks sauvegardés ;
- **clients fidèles** : 1 % de remise par achat chez le même vendeur (jusqu'à 8 %) et un accueil personnalisé ;
- prix stables dans la journée : la remise de fidélité fait réellement baisser le prix ;
- protection contre le double clic à l'achat ;
- négociation inchangée ;
- **application téléphone « Marché Dantokpa »** : répertoire par allée et bouton « Y aller » qui trace l'itinéraire jusqu'à l'étal.

**Testé** :
- 60 étals à des emplacements distincts, avec 60 vendeurs visibles ;
- achat de tout un stock, puis « Épuisé », puis réassort le lendemain ;
- baisse de prix avec la fidélité (2 450 → 2 375 FCFA) ;
- double clic débité une seule fois ;
- répertoire et itinéraire ;
- sauvegarde et rechargement ;
- test de fumée sur PC et affichage sur iPhone.

Aucune erreur détectée. Mémoire : 322 Mo (contre 286 Mo avant, à cause des vendeurs supplémentaires).

## Mission 016 — phase 3 : lieux de vie dans les 5 villes et carburant

**35 établissements** : 7 types dans chacune des 5 villes (Cotonou, Porto-Novo, Ouidah, Pahou, Cocotomey). Tous sont **fictifs** et signalés comme tels sur la carte (aucun partenariat). Ils ont leurs horaires, une enseigne et un point sur la carte.

| Type | Ce qu'on peut y faire |
|---|---|
| 🍲 Restaurant (7 h–23 h) | Carte d'assiettes propre à chaque ville (pâte rouge, amiwo, igname pilée sauce graine, télibo, dakouin, yêkêyêkê…) ; manger sur place ou emporter |
| 🥤 Bar **sans alcool** (9 h–24 h) | 13 boissons (bissap, gingembre, baobab, jus, eau de coco, thé, café, dèguè…) ; boire sur place ou emporter |
| 🐟 Poissonnerie (6 h–19 h) | Poissons et crustacés selon la ville (mer ou lagune) |
| 🛒 Mini-marché (7 h–22 h) | 21 produits de base, prix fixes |
| 🏦 Banque (8 h–17 h) | Soldes de tous les comptes, dernières opérations, accès à l'espace bancaire (virements, prêts, relevés) |
| 🏨 Hôtel (24 h/24) | Repos 2 h, nuit standard ou confort (dormir jusqu'à 7 h), douche |
| ⛽ Station-service (24 h/24) | Sur la RNIE 1 à l'entrée de chaque ville : auvent, 2 îlots de pompes, boutique, totem des prix |

À Cotonou, les enseignes fictives qui existaient déjà sont réutilisées : MAQUIS LE BON GOÛT, ALIMENTATION DIEU MERCI, BANQUE LAGUNE, HÔTEL OCÉAN BLEU, ainsi que deux paillotes de la plage. Dans les autres villes, des maisons-boutiques du centre reçoivent une enseigne et un auvent.

Les stocks sont limités, réapprovisionnés chaque matin et sauvegardés.

**Carburant** (voiture personnelle et véhicules achetés au garage ; avions et taxis exclus) :
- réservoir de 50 L (moto : 12 L), consommation de 0,9 L/km à l'échelle du jeu, soit environ 55 km d'autonomie ;
- jauge à l'écran pendant la conduite ;
- alerte de réserve sous 15 %, avec la station la plus proche ;
- **panne sèche** : on ne peut plus accélérer (le frein fonctionne) ;
- à la station : se garer près des pompes, descendre, puis choisir **le plein** ou **5 000 FCFA** ;
  - la quantité et le prix sont confirmés avant le paiement (prix du jeu : 680 FCFA/L) ;
  - le paiement se fait depuis le compte personnel ;
  - les doublons sont bloqués.

**Testé** :
- 35 lieux (7 types dans chaque ville), 5 stations, points d'accès non bloqués, 35 points sur la carte sans doublon ;
- restaurant (sur place et à emporter), bar, banque (fermée à 20 h) ;
- hôtel : nuit de 22 h à 7 h, énergie et propreté à 100 % ;
- 30 km de conduite = 27 L consommés ; panne sèche ; plein de 5 000 FCFA (7,35 L) puis plein complet ;
- double clic bloqué ; sauvegarde et rechargement ;
- test de fumée sur PC et affichage sur iPhone.

Aucune erreur détectée.

## Mission 016 — phase 4 : contacts, appels, messages et virements

Le téléphone (touche N) a 4 nouvelles applications.

**📇 Contacts**, en 3 onglets :
- **employés** : tous les employés de NOVA BOOK et des sociétés du groupe, avec poste et société ;
- **commerçants** : les vendeurs du marché Dantokpa chez qui tu as déjà acheté ;
- **services** : garage AUTO CONCEPT, supermarché LAGUNA, BANQUE LAGUNE.

Toutes les personnes et entreprises sont fictives. Aucun numéro n'est affiché, pour ne pas reproduire un vrai numéro par hasard.

**📞 Appels** :
- sonnerie, puis réponse ou messagerie selon l'heure (employés surtout pendant les heures de travail, vendeurs pendant l'ouverture du marché) ;
- dialogues :
  - employés : « faire le point », qui reprend leur vraie situation (commande en cours avec son avancement, formation, absence, moral) ; « féliciter » (moral +3, une fois par jour) ;
  - vendeurs : prix du jour ;
  - banque : solde ;
- journal d'appels avec durée et bouton « Rappeler » ; fermer le téléphone raccroche.

**💬 Messages** :
- conversations sauvegardées et compteur de non-lus ;
- réponses rapides, auxquelles le contact répond après quelques secondes ;
- chaque matin vers 9 h, un employé écrit au PDG : salut, rappel de paie à verser, nouvelles demandes de clients, ou demande d'entretien si son moral est bas.

**💸 Virements aux employés** (monnaie virtuelle du jeu uniquement) :
- montant (5 000 à 100 000 FCFA, ajustable, maximum 2 000 000) et motif (prime, avance sur salaire, remboursement de frais, cadeau) ;
- compte à débiter : compte personnel, NOVA BOOK ou une société du groupe ;
- **vérification du solde**, puis un **écran de confirmation** obligatoire (bénéficiaire, montant, compte, solde après) ;
- **anti-doublon** : chaque confirmation a un jeton à usage unique, et un virement identique vers la même personne est bloqué pendant 10 s ;
- **chaque opération est enregistrée** : relevé du compte débité, historique des virements, message dans la conversation ;
- une prime ou un cadeau améliore le moral de l'employé.

Correction : sur iPhone, le compteur de vitesse ne chevauche plus le message d'action.

**Testé** :
- 26 employés, 1 vendeur et 3 services en contacts ;
- message avec réponse contextuelle ; appel décroché, point de travail, félicitations limitées à une fois par jour ;
- virement refusé (solde insuffisant) ; virement de 25 000 FCFA débité une seule fois malgré un double clic et la réutilisation du jeton ;
- même virement relancé tout de suite : bloqué ;
- virement depuis NOVA BOOK inscrit dans sa comptabilité ;
- message du matin ; sauvegarde et rechargement ;
- test de fumée sur PC et affichage sur iPhone.

Aucune erreur détectée.

## Mission 016 — phase 5 : sociétés visitables, LED, projets du PDG (et compléments)

**Sièges visitables des 5 sociétés du groupe** (NOVA DIGITAL, MEDIA, IMMOBILIER, TRANSPORT, DISTRIBUTION) :
- sur l'immeuble réservé à chaque société : enseigne lumineuse avec cadre LED et porte vitrée, placées sur la façade la plus dégagée ;
- l'entrée n'ouvre que si la société a été créée ou rachetée ;
- intérieur aménagé :
  - réception avec hôtesse, mur du logo avec LED, espace d'attente ;
  - 8 postes de travail occupés par les vrais employés de la société ;
  - bureau vitré du directeur (assis s'il est nommé) ;
  - salle de réunion, tableau de bord en direct ;
- équipements du métier : salle serveurs (DIGITAL), studio fond vert (MEDIA), maquettes (IMMOBILIER), écran de suivi (TRANSPORT), entrepôt (DISTRIBUTION) ;
- actions : accueil, tableau de bord (NOVA Gestion), superviser l'équipe (moral +2 par jour), point d'équipe, parler au directeur, équipements ;
- aspects techniques : intérieur placé en hauteur avec collisions isolées, caméra recalée à l'entrée et à la sortie, vue en coupe.

**Décoration LED** (application « 💡 Décoration LED » du téléphone) :
- **maison** : derrière la télévision, LED murales du salon, plafonds (éclairage indirect), chambre, bureau informatique, cuisine ;
- **entreprises** : hall de NOVA BOOK, couloirs des 6 niveaux, salles de réunion, espaces de travail, bureau du PDG, enseignes NOVA, sociétés du groupe ;
- 5 styles (blanc chaud, blanc froid, bleu, violet, RGB avec 8 couleurs), intensité de 10 à 100 %, extinction, réglages sauvegardés.

**Projets du PDG** (onglet « 🗂️ Projets » de NOVA Gestion : bureau du PDG ou ordinateur de la maison) :
- 10 types : livre, roman, manuel scolaire, couverture, mise en page, affiche, développement informatique, vidéo, communication, impression ;
- chaque projet a un nom, une description, un département, un budget (débité de NOVA BOOK), un délai, un revenu prévu, des étapes et un état (en attente, en cours, terminé, livré) ;
- équipe de 4 personnes au maximum, et un employé ne travaille que sur un projet à la fois ; l'avancement est horaire, selon la productivité réelle ;
- le PDG peut travailler lui-même (+15 %, 30 min, énergie −3) ;
- validation de chaque étape, puis livraison : le revenu est versé à NOVA BOOK, −30 % en cas de retard ;
- raccourci vers le recrutement ; plusieurs projets peuvent avancer en même temps.

**Compléments du téléphone** :
- recherche par nom ;
- onglets Clients & partenaires et Personnels (fictifs) ;
- messages libres ;
- appels entrants (accepter ou refuser) ;
- consignes aux directeurs, avec un effet réel sur la production, le moral et les frais.

**Complément du marché** : 69 vendeurs (8 poissons, 8 viandes, 8 vêtements, 6 épices, conformément à la répartition demandée).

**Correction** : le texte de version de l'écran d'accueil, abîmé depuis la v2.8, est réécrit.

**Testé** :
- sociétés : 5 entrées, aucune bloquée ; entrée refusée tant que la société n'existe pas ; visites avec employés et directeur ; supervision ; sortie ;
- projet : budget, équipe, employé déjà occupé refusé, avancement, travail du PDG, validations, livraison de 450 000 FCFA ;
- LED : RGB, intensité, extinction ;
- téléphone : recherche, consigne, message libre, appel entrant accepté puis refusé ;
- sauvegarde et rechargement ;
- test de fumée sur PC et affichage sur iPhone.

Aucune erreur détectée.

## Mission 016 — phase 6 : garde-robe de 200 vêtements et vérification finale

**200 vêtements et accessoires distincts**, selon la répartition demandée :

| Catégorie | Nombre |
|---|---|
| Chemises & polos | 30 |
| Pantalons | 25 |
| Jeans | 20 |
| T-shirts | 20 |
| Vestes & blazers | 15 |
| Ensembles professionnels | 15 |
| Tenues traditionnelles béninoises | 15 |
| Tenues décontractées | 15 |
| Tenues sportives | 15 |
| Chaussures | 10 |
| Accessoires | 10 |
| Tenues spéciales | 10 |

Chaque vêtement a un nom, une catégorie, une couleur ou un motif wax (8 motifs), et est **réellement visible sur le personnage**. Aucune apparence n'est en double (vérifié automatiquement). La géométrie du personnage gère :
- manches longues ou débardeur, col, veste ouverte, cravate, bande de maillot ;
- grand boubou, pagne et foulard ;
- casquette, chapeau de paille, bonnet traditionnel (fila), toque ;
- lunettes, montre, collier, sac à dos, semelles de baskets.

Le personnage reste un seul maillage et un seul matériau (1 appel de rendu). Les personnages non joueurs ne sont pas modifiés.

**Garde-robe** (armoires de la chambre et du dressing, et nouveau point « Se changer devant le miroir » dans la chambre) :
- 12 onglets, plus « ⭐ Favoris » et « Tenues de base » (les 12 tenues d'origine sont conservées) ;
- **essayage en direct** en vue miroir : la caméra se place face au personnage, à côté du panneau ;
- **combinaisons** : haut, bas, veste, chaussures et jusqu'à 3 accessoires ; une tenue complète remplace haut, bas et veste ;
- **ensembles favoris** : jusqu'à 12, sans doublon, à porter ou supprimer (avec confirmation) ;
- **Valider** enregistre la tenue, **Annuler** revient à la tenue précédente.
- La tenue et les favoris sont sauvegardés.

**Vérification finale** :
- état complet du jeu sauvegardé puis rechargé, sans aucune différence : comptes, sociétés, consignes, prêt, virements, messages, appels, réfrigérateurs, stocks des commerces, fidélité au marché, carburant, garde-robe et favoris, LED, projets ;
- taille de la sauvegarde : environ 28 Ko ;
- test de fumée sans erreur ; mémoire du test de fumée : 322 Mo (rendu logiciel) ; tests sur iPhone (paysage) sans erreur.

Aucune erreur détectée.

## Mission 014 — étape 5 : vie quotidienne du PDG

Ce qui existait déjà de la section 9 : se rendre à NOVA BOOK en véhicule, entrer, saluer les employés, visiter les étages, observer les équipes, réunions, ordinateur, décisions, résultats, recrutement.

**Clients et partenaires reçus en personne** :
- La plupart des jours (7 sur 10), un visiteur fictif arrive entre 9 h et 16 h et attend à l'accueil de NOVA BOOK (rez-de-chaussée) ; la réceptionniste prévient le PDG par message.
- **Client** : il apporte une commande payée 15 % de plus qu'une demande ordinaire. On peut :
  - signer le contrat (réputation +2) ;
  - négocier +10 % (60 % de chances ; sinon le client repart et la réputation baisse de 1) ;
  - refuser poliment.
- **Partenaire** (librairie, fournisseur de papier ou agence de communication, tous fictifs) : partenariat payant avec un effet réel :
  - 2 nouvelles demandes de clients et réputation +3 ;
  - impression +20 % pendant 7 jours ;
  - prix des commandes +10 % pendant 7 jours.
- Un visiteur non reçu avant 18 h repart, et la réputation baisse de 2.

**Événements professionnels** (onglet « 🎯 Objectifs & événements » de NOVA Gestion) — 10 situations avec des décisions aux effets réels :
- presse en panne (réparer pour 250 000 FCFA, ou impression −50 % pendant 2 jours) ;
- coupure d'électricité ;
- salon du livre (fictif) ;
- demande d'augmentation (+10 % de salaire et moral +15, ou moral −12) ;
- commande urgente (+40 %, livrée en 2 jours) ;
- article de presse élogieux ;
- pénurie de papier ;
- formation groupée (compétence +5 pour 3 employés) ;
- candidature remarquable (compétence 88) ;
- client mécontent.

Sans réponse au bout de 2 jours, la décision par défaut s'applique. Les effets en cours sont affichés avec leur date de fin.

**Réputation** de NOVA BOOK (0 à 100, 50 au départ) : elle modifie le prix des nouvelles commandes, de −10 % à +10 %.

**10 objectifs de développement**, avec barre de progression et prime versée à NOVA BOOK (une seule fois) :
- livrer 5 commandes ;
- recevoir 3 visiteurs ;
- 15 M FCFA de trésorerie ;
- 35 employés ;
- un département équipé au niveau 3 ;
- 2e société du groupe ;
- livrer un projet personnel ;
- réputation de 75 ;
- 8 M FCFA de chiffre d'affaires dans un mois ;
- posséder les 6 sociétés.

**Testé** :
- visite d'un client : message, visiteur à l'accueil, contrat signé ;
- partenariat payé avec son effet ;
- événements : panne, augmentation, salon, candidat, décision automatique au bout de 2 jours ;
- objectif non atteint impossible à encaisser, pas de double encaissement ;
- visiteur reparti sans être reçu ;
- sauvegarde et rechargement ; test de fumée.

Aucune erreur détectée.

## Mission 016 — compléments : restaurants, hôtels et banques visitables, animation des vendeurs

**Intérieurs visitables** dans les 5 villes. On entre par la porte de l'établissement ; l'intérieur est construit à l'entrée (un seul à la fois, collisions isolées) et respecte les horaires d'ouverture.
- **Restaurants** :
  - salle avec 6 tables et leurs chaises, comptoir, marmites, tableau « menu du jour » ;
  - un cuisinier avec sa toque, un serveur, des clients attablés ;
  - le joueur **s'assoit à une table** (E pour se lever) et commande « Manger ici » ; **le serveur traverse la salle et apporte l'assiette**, dont le modèle 3D apparaît sur la table ;
  - le comptoir permet aussi de commander à emporter.
- **Hôtels** :
  - réception avec hôtesse et tableau à clés, salon (espace commun), coin restaurant servi par un serveur (carte du restaurant de la ville) ;
  - **chambre n° 12** : lit, chevets, télévision, armoire, salle d'eau ;
  - la réservation à la réception remet une **clé** (repos, nuit standard, nuit confort ou douche) ; sans clé, la porte reste fermée ;
  - au lit : repos de 2 h ou nuit jusqu'à 7 h ; salle d'eau : propreté 100 %.
- **Banques** (BANQUE LAGUNE, fictive) :
  - 2 **guichets** avec employés derrière une vitre, 2 **distributeurs**, chaises d'attente, agent d'accueil ;
  - nouveau **compte de dépôt personnel**, avec **dépôts et retraits** en monnaie du jeu (5 000 à 100 000 FCFA) ;
  - confirmation obligatoire, solde vérifié, **jeton à usage unique** contre les doubles opérations, historique enregistré ;
  - le guichet donne aussi accès aux comptes et à l'espace bancaire.

**Animation de vente des 69 vendeurs de Dantokpa** :
- ils appellent les passants et rangent leurs marchandises ;
- ils se tournent vers le joueur qui s'approche et le saluent ;
- **ils tendent l'article à chaque vente**.

**Testé** :
- restaurant : entrée, table, commande, assiette apportée par le serveur, se lever ;
- hôtel : porte fermée sans clé, réservation confort, ouverture, nuit de 22 h à 7 h (énergie et propreté à 100 %) ;
- banque : dépôt de 25 000 FCFA débité une seule fois, retrait au distributeur, retrait supérieur au solde impossible ;
- vendeur : geste de remise après une vente ;
- sortie : retour au niveau du sol ; sauvegarde et rechargement ; test de fumée.

Aucune erreur détectée.

## Mission 012 — étape 3 : hélicoptères et héliport

**8 hélicoptères** (noms fictifs inspirés de catégories d'appareils réels, versions civiles, dimensions approximatives) :

| Hélicoptère | Type | Rotor | Places |
|---|---|---|---|
| Aerion H125 | léger polyvalent | 3 pales | 6 |
| Aerion H145 | bimoteur médical, rotor de queue caréné | 4 pales | 10 |
| Belle 407 | d'affaires | 4 pales | 7 |
| Belle 429 | bimoteur, sur roues | 4 pales | 8 |
| Robison R44 | petit appareil à pistons | 2 pales | 4 |
| Sikora S-76 | transport offshore | 4 pales | 12 |
| Chinouk CH-47 | gros porteur à **rotors en tandem** | 2 × 3 pales | 33 |
| Hawkline UH-60 | utilitaire de sauvetage | 4 pales | 11 |

Les modèles 3D sont procéduraux : cabine, verrière, poutre de queue, dérive, patins ou roues, feux de navigation, **rotor principal et rotor de queue animés**, avec un disque flou à plein régime.

**Pilotage** (simplifié) :
- **G** démarre ou coupe le moteur ; le rotor monte en régime en quelques secondes et on ne peut pas décoller avant le plein régime ;
- **Maj** monte, **Espace** descend ;
- **Z/W** avance, **S** recule, **Q-D (A-D)** tourne, **flèches ←/→** translation latérale ;
- **décollage et atterrissage verticaux**, avec descente amortie près du sol ;
- atterrissage trop rapide, amerrissage ou collision avec un bâtiment : retour à l'héliport ;
- moteur coupé en vol : autorotation ;
- **V** vue cockpit ; le tableau de bord de vol est réutilisé (régime du rotor, état du moteur) ;
- son de rotor (battement des pales et sifflement de la turbine) ;
- **E** pour descendre une fois posé (le moteur se coupe).

**Héliport** à l'aéroport : 8 aires numérotées (cercle, H, balisage lumineux) et un comptoir 🚁 à côté du comptoir des vols, avec un menu de choix.

**Hélisurfaces** de destination, placées automatiquement sur des emplacements vérifiés libres (aucun obstacle dans un rayon de 9 m, pas d'eau) : NOVA BOOK, plage de Cotonou, Ouidah, Porto-Novo.

**Vols de passagers fictifs** :
- choix de la destination au comptoir ;
- 2 à 5 passagers embarquent et l'itinéraire s'affiche sur la carte ;
- un atterrissage au centre de l'hélisurface rapporte une rémunération en FCFA (monnaie du jeu), selon la distance et le nombre de passagers.

**Correction** : la détection de collision des avions (et des hélicoptères) ignore désormais les intérieurs placés en hauteur (sociétés, restaurants, hôtels, banques), qui pouvaient provoquer de faux accidents en vol à basse altitude.

**Testé** :
- comptoir, choix, embarquement ;
- démarrage du moteur et décollage impossible avant le plein régime ;
- montée à 44 m, vol de 1,5 km jusqu'à NOVA BOOK, atterrissage, **26 000 FCFA encaissés** ;
- atterrissage trop rapide : retour à l'héliport ;
- coupure du moteur et sortie ; sauvegarde des positions ; test de fumée.

Aucune erreur détectée.

## Mission 012 — étape 4 : port maritime et 10 bateaux

**Port de Cotonou** : représentation stylisée à l'est de la ville du jeu, sans position géographique exacte, signalée comme telle sur la carte.
- terre-plein et bord de quai le long du rivage ;
- **3 jetées praticables** (deux de 420 m pour les paquebots, une de 150 m pour la marina) avec bittes d'amarrage, lampadaires, bordures et garde-corps ;
- **gare maritime**, **capitainerie** (choix des bateaux), entrepôt, **grues portiques**, piles de conteneurs ;
- 2 entrées sur la carte (port, capitainerie).

**10 bateaux** (noms fictifs inspirés de catégories de navires réels, dimensions approximatives) :

| Bateau | Type | Longueur |
|---|---|---|
| Symphonie des Mers | grand navire de croisière | 362 m |
| Merveille des Mers | navire de croisière | 362 m |
| Euromonde | navire de croisière | 333 m |
| Reine Marine 2 | paquebot transatlantique | 345 m |
| Perle du Golfe | yacht de luxe | 80 m |
| Flèche d'Ouidah | yacht sportif | 24 m |
| Espoir de la Lagune | bateau de pêche | 18 m |
| Éclair | vedette rapide | 10 m |
| Navette de la Lagune | transport de passagers | 22 m |
| Ferry du Golfe | ferry (passagers et véhicules) | 120 m |

Les modèles 3D sont procéduraux, chacun avec son allure :
- paquebots : ponts en gradins, rangées de fenêtres éclairées, passerelle de commandement, cheminée, canots orange, piscine, toboggans ;
- ferry : rampe arrière ;
- bateau de pêche : mât, filets et flotteurs ;
- vedette : moteur hors-bord ;
- tous : feux de navigation.

**Navigation** :
- accélérer, ralentir (Espace), marche arrière, tourner, s'arrêter ; chaque bateau a sa vitesse et sa maniabilité ;
- **houle** (pilonnement, tangage, roulis), **sillage** d'écume, **vagues animées** près des côtes ;
- son du moteur (diesel, ou V8 pour les bateaux rapides) et **corne** (K, grave pour les grands navires) ;
- le bateau s'arrête devant le rivage et les jetées ;
- **débarquement** (E) seulement près d'un quai, d'une jetée ou du rivage ; près de son poste, le bateau se range à quai ;
- capitainerie : « Ramener à son poste d'amarrage ».

**Grands navires visitables** (paquebots et ferry) — on monte par la passerelle d'embarquement depuis la jetée, ou depuis la barre avec **B** une fois le navire arrêté, même en mer :
- **pont piscine** (piscine, transats, toboggans, baigneurs) ;
- **salon-bar** (canapés, piano, barman ; cocktail sans alcool) ;
- **restaurant** (tables, clients, serveur ; dîner) ;
- **coursive et cabine** (repos d'une heure) ;
- **passerelle de commandement** (officier ; « prendre la barre ») ;
- **descente à quai** quand le navire est amarré.

Les paiements se font en monnaie du jeu.

**Corrections** :
- `landClamp` laisse marcher sur les jetées et dans les espaces placés en hauteur (pont des navires) ;
- `isWater` traite les jetées comme des obstacles pour les bateaux.

**Testé** :
- 10 bateaux à quai ;
- bateau de pêche : embarquement, 89 m parcourus, virage, arrêt devant le rivage, débarquement sur la jetée ;
- paquebot : 7 espaces visités, bar payé, prise de la barre et navigation (7,5 m/s) ;
- sauvegarde des bateaux déplacés ; test de fumée ; vue aérienne du port.

Aucune erreur détectée.

## Mission 017 — étape 1 : compte personnel de 10 milliards, banque personnelle et achats

> Tous les montants sont une **monnaie fictive du jeu**, sans aucune valeur réelle.

Plan de la mission 017 :
1. fortune et banque personnelle (fait) ;
2. conversations libres avec les employés (personnalité, humeur, mémoire, voix facultative du navigateur) ;
3. carnet de contacts complet et rencontres avec les habitants ;
4. réunions d'affaires ;
5. invitations, dîners de gala, réputation à 7 indicateurs.

**Compte personnel** :
- dotation unique de **10 000 000 000 FCFA**, versée une seule fois (nouvelle partie comme sauvegarde existante), après le chargement de la sauvegarde ;
- solde affiché en abrégé à l'écran (« 10,00 Md FCFA ») et en détail dans le téléphone ;
- l'historique conserve désormais 300 opérations (au lieu de 80).

**Application « 🏦 Ma banque »** :
- compte personnel, épargne et patrimoine (propriétés et véhicules) ;
- historique filtrable (tout, dépenses, revenus) avec une **catégorie** par opération : alimentation et sorties, transport, hébergement, véhicules, immobilier, mode, loisirs, banque et entreprises, revenus ;
- graphique des **dépenses par catégorie** ;
- **virements** : vers l'épargne et retour ; **apport** du compte personnel vers une société NOVA ; **dividende** d'une société vers le compte personnel ;
- chaque virement est vérifié puis confirmé, avec un jeton à usage unique ;
- les comptes des sociétés restent séparés : un virement explicite est le seul passage possible.

**Application « 🛍️ Achats & patrimoine »**, avec confirmation à chaque achat :
- **véhicules** : les 13 voitures du garage AUTO CONCEPT ont désormais un prix (de 25 M à 250 M FCFA), et l'achat se fait en deux clics au garage ;
- **propriétés** : 6 maisons et immeubles réels du décor (Porto-Novo, Ouidah, Pahou, Cocotomey), de 435 M à 1,5 Md FCFA. À l'achat, une enseigne « PROPRIÉTÉ DU PDG » apparaît sur la façade et un repère sur la carte ; un **loyer** est versé chaque mois de jeu ;
- **mode de luxe** : 12 pièces dans la garde-robe (onglet « Collection de luxe ») — costumes sur mesure, smoking blanc, boubou de gala brodé or, souliers vernis, mocassins, montres en or et en platine, lunettes, collier en or, panama. Cadenas et prix tant que la pièce n'est pas achetée, puis elle est portable ;
- **équipements** : ordinateur, tablette, appareil photo, drone, montre connectée (rangés dans « Mes articles ») ;
- **loisirs** : spa, massage, dîner privé, cinéma privé, avec des effets sur l'énergie, la propreté et la faim.

**Testé** :
- dotation unique ;
- dépôt d'un milliard sur l'épargne (jeton non réutilisable) ;
- apport de 100 M à NOVA BOOK ;
- achat d'un immeuble : enseigne, repère sur la carte, loyer au bout d'un mois de jeu ;
- appareil photo et spa ;
- voiture à 250 M (double clic de confirmation) ;
- montre en or achetée puis portée ;
- rechargement sans double dotation ; test de fumée.

Aucune erreur détectée.

## v3.7 — Mission 017, étape 2 : conversations libres avec les employés

- **Moteur de dialogue local et gratuit** (`src/talk.js`), sans service en ligne ni crédit payant. Le joueur écrit librement. L'employé répond selon :
  - sa **personnalité** (chaleureux, réservé, enthousiaste, pragmatique, blagueur) ;
  - son **humeur**, qui dépend du moral ;
  - son **métier** ;
  - les **données réelles du jeu** : commande en cours et avancement, projets, chiffre d'affaires, trésorerie, équipements.
- **Vie personnelle cohérente** : famille, ville d'origine, loisirs, plat préféré, toujours identiques pour un même employé.
- **Mémoire** de chaque employé (sauvegardée) : instructions, félicitations, reproches, promesses. « Tu te souviens… ? » rappelle les derniers échanges.
  - Une promesse d'augmentation non tenue après 7 jours est rappelée, et le moral baisse de 5.
  - Une promotion accordée est remerciée.
- **Effets réels** :
  - félicitations : moral +3, une fois par jour ;
  - reproche : moral −4 ;
  - « accélère » : production +12 % jusqu'au lendemain ;
  - « prends ta journée » : absence d'un jour, moral +8 ;
  - « soigne la qualité » : moral +1.
- **Où discuter** :
  - **Tour NOVA BOOK** : « Parler à … » sur chaque employé.
  - **NOVA Gestion** :
    - bouton 💬 Parler sur chaque fiche ;
    - discussion collective par département ;
    - discussion collective par filiale.
  - **Bureaux des filiales** :
    - conversation avec le directeur ;
    - salle de réunion = discussion collective.
  - **Téléphone** : les messages aux employés passent par le même moteur et partagent la même mémoire.
- **Voix facultative** :
  - 🔊 lecture des réponses par la synthèse vocale du navigateur (Web Speech API, fr-FR) ;
  - 🎤 dictée, seulement si le navigateur la propose (sur certains navigateurs, la reconnaissance vocale passe par le service du navigateur).
  - Rien d'obligatoire.
