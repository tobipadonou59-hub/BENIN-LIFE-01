# BENIN LIFE : COTONOU OPEN WORLD — Prototype v0.3 (son + amélioration visuelle)

Jeu 3D en monde ouvert inspiré de Cotonou (Bénin), réalisé avec **Three.js** (WebGL, gratuit et open source).
Les bâtiments, personnages, véhicules et la végétation sont **générés par le code**. Aucun modèle 3D n'est à fournir.
Trois matériaux PBR réalistes (asphalte, trottoir, latérite) ont été **générés par IA avec Scenario** (modèle PATINA, plan gratuit)
et sont intégrés au fichier du jeu. Aucun crédit n'a été acheté.

## ▶ Lancer le jeu sur PC

**Méthode la plus simple :** double-clique sur **`BENIN_LIFE.html`**.
Le fichier s'ouvre dans Chrome, Edge ou Firefox, sans installation et sans connexion Internet.

> Conseil : sur un PC portable avec deux cartes graphiques, force le navigateur sur le GPU « hautes performances »
> (Windows → Paramètres → Affichage → Graphiques).

### Pour modifier le code (développeurs)
Prérequis : [Node.js](https://nodejs.org) 18 ou plus récent.
```
npm install
npm run build      # régénère dist/game.js et BENIN_LIFE.html
npm run dev        # reconstruit automatiquement à chaque sauvegarde
```

## 🎮 Commandes
| Action | Clavier AZERTY | QWERTY |
|---|---|---|
| Se déplacer / conduire | Z Q S D ou flèches | W A S D |
| Courir | Maj | Shift |
| Sauter / frein à main | Espace | Space |
| Monter / descendre de voiture | E | E |
| Caméra | Souris (clic pour capturer) · molette = zoom | |
| Klaxon (en voiture) | K | K |
| Monter / descendre (à l'arrêt) | E | E |
| Couper / rétablir le son | M | M |
| Pause | Échap ou P | |
| Aide à l'écran · +1 heure · FPS | H · T · F | |

## 🗺 Contenu de la zone
- **Rond-point de l'Indépendance** : monument en bronze, drapeau du Bénin qui flotte, passages piétons.
- **Boulevard central** goudronné avec lampadaires, et **rues pavées** (pavés autobloquants).
- **Quartiers** d'immeubles R+1 à R+4 aux façades colorées, avec persiennes, balcons, citernes,
  « poteaux en attente » sur les toits, et commerces avec enseignes peintes (maquis, pharmacie, couture…).
- **Concessions** : murs à éclaboussures de latérite et portails métalliques.
- **Vendeurs d'essence « kpayo »** au bord des routes.
- **Grand Marché** : étals, bâches et parasols colorés. **Jardin** avec terrain de foot en sable.
- **Plage de Fidjrossè** : cocotiers, pirogues peintes et océan animé.
- **Circulation** de zémidjans (chemise jaune, avec ou sans passager) et de voitures, plus des piétons en pagne.
- **4 voitures conduisibles** (points bleus sur la mini-carte).
- **Cycle jour/nuit** : une journée dure 20 minutes. La nuit, les fenêtres, les enseignes, les lampadaires et les phares s'allument.

## 🔊 Son (v0.3)
Tous les sons sont **synthétisés en temps réel** par le navigateur (Web Audio API). Il n'y a aucun fichier audio :
le jeu reste léger et jouable hors-ligne.
- **Musique du menu** : rythme en 12/8 construit sur la cloche **gankogui** (tradition fon/ewe), avec tambour et hochet.
- **Ambiances** :
  - rumeur de la ville ;
  - vagues et écume qui montent quand on approche de la plage ;
  - vent, oiseaux le jour et grillons la nuit ;
  - brouhaha du **Grand Marché** quand on s'en approche.
- **Joueur** : bruits de pas différents sur asphalte, pavés, trottoir, latérite, herbe et sable, plus un bruit à l'atterrissage.
- **Voiture** : moteur dont le régime suit les vitesses (boîte à 5 rapports simulée), admission, crissement des pneus au frein à main, portières, chocs, klaxon (**K**).
- **Circulation** : zémidjans (moteur deux-temps aigu) et voitures spatialisés en 3D.
  Ils klaxonnent quand on leur bloque le passage, et parfois sans raison… on est à Cotonou !
- **Interface** : clics et survols des boutons.
- **Options** : volume général et musique du menu. La touche **M** coupe le son.

## ✨ Nouveautés de la Mission 002
- **Textures IA (Scenario/PATINA)** : asphalte fissuré, dalles de trottoir et latérite, avec cartes de relief.
  Une variation à grande échelle évite l'effet de répétition.
- **Architecture de Cotonou** :
  - soubassements colorés, corniches à chaque étage, claustras (blocs ajourés), cages d'escalier en claustras ;
  - balcons à balustres, galeries commerçantes à piliers, climatiseurs, paraboles, citernes, fresques peintes ;
  - villas à toit de tôle (rouge, verte, bleue ou galvanisée), portails, et un maquis avec parasol et chaises plastiques.
- **Façades HD** : enduit, coulures de pluie, persiennes, grilles en fer forgé, rideaux, fissures, avec carte de relief.
- **Rues** :
  - caniveaux couverts de dalles et bordures ;
  - sable et latérite qui débordent sur la chaussée ;
  - pavés autobloquants et sable de plage avec relief.
- **Personnages réalistes** : squelette animé de 17 os, avec visage, oreilles, mains et pieds.
  - Animations : repos (respiration), marche, course (buste penché, coudes pliés), saut, position assise sur moto.
  - Femmes en pagne et foulard. Vendeuses avec une bassine de marchandises sur la tête.
- **Végétation** : cocotiers (16 palmes, palmes sèches, noix de coco), manguiers, flamboyants en fleurs,
  bougainvilliers, bananiers et touffes d'herbe, le tout balancé par le vent.
- **Lumière et ciel** :
  - ciel physique avec nuages animés, lune et étoiles ;
  - éclairage d'ambiance calculé depuis le ciel ;
  - ombres stabilisées (sans scintillement) ;
  - halos des lampadaires la nuit, brume dorée au coucher du soleil.
- **Post-traitement** (selon la qualité) : halo lumineux (bloom), étalonnage des couleurs et vignettage.
  En qualité Haute, occlusion ambiante (GTAO).
- **Véhicules** :
  - berline, minibus avec bagages sur le toit et pick-up, à carrosserie profilée et vernis ;
  - zémidjans détaillés avec passagers ;
  - 32 véhicules en circulation, dont deux boucles qui passent par le rond-point.
- **Piétons** : 36 promeneurs et des groupes qui discutent devant les boutiques.
- **Mini-carte** : tourne avec la caméra, affiche les bâtiments, le marquage des routes, des icônes de lieux
  (M marché, J jardin, P plage, ★ rond-point) et une boussole, avec un zoom qui s'adapte à la vitesse.

## ⚙ Performances (PC 16 Go de RAM)
- Géométrie statique fusionnée par matériau (environ 70 appels de rendu pour toute la ville), végétation instanciée.
- Ombres limitées à une zone de 110 m autour du joueur, brouillard de distance, PNJ éloignés masqués.
- Options → Qualité :
  - **Basse** : sans ombres ni post-traitement, herbes réduites ;
  - **Moyenne** (recommandée) : ombres 2K et bloom ;
  - **Haute** : ombres 4K, occlusion ambiante GTAO et rendu net.
- Mesures sur la ville complète : environ 200 appels de rendu, 570 000 triangles, 120 Mo de mémoire JS.
  Le fichier du jeu pèse 2,6 Mo, textures IA comprises.
- La génération de la ville prend quelques secondes au lancement (textures calculées sur place).

## 📁 Organisation
```
BENIN_LIFE.html     ← jeu complet en un seul fichier (à double-cliquer)
assets/textures/    ← textures PBR générées par IA (Scenario / PATINA)
index.html          ← interface (HTML/CSS), charge dist/game.js
src/
  main.js           boucle de jeu, états (menu/jeu/pause), entrée/sortie de voiture
  world.js          génération de la ville, routes, plage, collisions, zones
  textures.js       textures procédurales (façades HD, claustras, balustres, pagnes, enseignes…)
  assets.js         chargement des textures IA
  vegetation.js     végétation instanciée + vent
  shaderfx.js       variation anti-répétition des sols, vent
  post.js           post-traitement (bloom, GTAO, étalonnage)
  audio.js          son synthétisé (ambiances, moteur, klaxons, pas, musique)
  environment.js    ciel dynamique, soleil/lune, brouillard, étoiles, cycle jour/nuit
  player.js         joueur à pied (marche, course, saut, collisions)
  character.js      personnage articulé + animation
  vehicles.js       voiture conduisible, zémidjans, circulation automatique
  pedestrians.js    piétons
  camera.js         caméra 3e personne anti-collision
  input.js · ui.js  clavier/souris · menus, HUD, mini-carte
  collision.js      collisions 2D avec grille spatiale
tools/build.mjs     build (esbuild) · tools/smoke-test.cjs test automatisé (Playwright)
```

## 🔜 Prochaines étapes proposées
1. Sons : moteurs, klaxons de zémidjans, ambiance de marché, vagues.
2. Zémidjan conduisible par le joueur et missions de taxi.
3. D'autres matériaux IA (façades, tôle, sable, herbe) quand le quota gratuit de Scenario sera renouvelé.
   Ou modèles 3D IA de lieux emblématiques, avec ton accord pour les crédits.
4. Feux de circulation, piétons qui traversent, interactions avec les PNJ.

## 🧍 Mission 003 : personnage principal (préparation)
État : **en attente de crédits Scenario**. Tripo est utilisé via Scenario. Le quota gratuit est épuisé (11 CU restants
pour 12 CU nécessaires à la première étape). Aucun crédit n'a été dépensé pour cette mission.

**Formule B validée** (122 CU par personnage) :
1. Image de concept (12 CU).
2. Tripo 3.1 : GLB optimisé à 15 000 faces, matériaux PBR, échelle réelle (60 CU).
3. Tripo Rigging Biped : squelette seul (50 CU).

Les animations (repos, marche, course, saut, assis) sont celles du jeu, transférées automatiquement sur le squelette Tripo.

**Déjà en place et testé :**
- Choix **HOMME / FEMME** dans le menu principal (mémorisé), fonctionnel avec les personnages actuels.
- `src/glbCharacter.js`, le chargeur de personnage GLB :
  - mise à l'échelle automatique (1,78 m, pieds au sol, centré), correction des fichiers en centimètres ;
  - reconnaissance des os par leur nom (conventions Tripo, Mixamo, Unreal, Blender…) et transfert des animations ;
  - utilise en priorité les clips idle/walk/run si le GLB en contient, avec transitions selon la vitesse ;
  - rapport de vérification dans la console : os, rôles reconnus et manquants, triangles, hauteur, clips.
- **Intégration** : déposer `assets/characters/male.glb` (et/ou `female.glb`), puis lancer `npm run build`.
  Le modèle est intégré à `BENIN_LIFE.html` et devient le personnage du joueur.
  Si le fichier est absent ou illisible, le personnage procédural est utilisé : rien ne casse.

## 🚗 Mission 004 : véhicules et conduite
**Déjà présents (Missions 001 et 002, conservés)** : berline, minibus et pick-up procéduraux, roues qui tournent
et braquent, conduite au clavier (ZQSD/WASD + flèches, Espace = frein à main), caméra de poursuite,
collisions, et 32 véhicules en circulation.

**Ajouts (gratuits, procéduraux, aucun modèle attribué à Tripo)** :
- **Citadine** (3,75 m, hayon), garée dans les rues et présente dans la circulation.
- **Moto conduisible** :
  - pilote visible, homme ou femme selon le personnage choisi ;
  - inclinaison dans les virages et béquille à l'arrêt ;
  - en marche arrière, on pousse la moto ;
  - son moteur plus aigu et caméra plus proche.
- **Immobilisation** : on ne peut descendre qu'à l'arrêt (moins de 9 km/h), et le véhicule quitté reste immobile.
- **12 véhicules garés** au bord des voies, sans bloquer la circulation.
  Correctif : avant, un pick-up garé bloquait les véhicules derrière lui.
- **`loadGLBVehicleBody()`** : charge une carrosserie GLB (ex. Tripo), la met à la longueur réelle,
  la pose au sol et lui garde les roues animées du jeu. Testé avec un GLB factice, retiré ensuite.

**Tests de conduite (simulation physique)** :
- Citadine : 68 km/h en 3 s ; frein à main jusqu'à l'arrêt complet ; marche arrière à 22 km/h.
- Choc à 45 km/h : arrêt devant le mur, sans le traverser.
- Moto : 52 km/h en 3 s ; inclinaison en virage ; choc à 40 km/h sans traverser le mur.
- Circulation : 0 véhicule bloqué sur 32 ; descente refusée en roulant.

**Performances** : 213 appels de rendu, 582 000 triangles, 123 Mo de mémoire JS.

**Tripo (via Scenario), en attente d'autorisation et de crédits** :

| Option | Par véhicule | 3 véhicules |
|---|---|---|
| 1. Image de concept + carrosserie Tripo 3.1 à 12 000 faces + roues du jeu | 72 CU | 216 CU |
| 2. Option 1 + roues séparées par Tripo Segmentation v2 | 152 CU | 456 CU |

## 🚦 Mission 005 : circulation routière et piétons (v0.6)
Aucune génération Tripo : les ressources du jeu suffisaient (**0 crédit**).

**Circulation (36 véhicules : berlines, citadines, minibus, pick-up, zémidjans)** :
- 8 itinéraires qui se croisent. Aux embranchements, les véhicules bifurquent au hasard (environ 350 changements de direction en 2 min 30).
- **Feux tricolores** aux 8 grands carrefours (vert 11 s, orange 2,5 s, rouge intégral 1,5 s), avec un freinage progressif jusqu'à la ligne d'arrêt.
- Priorité dans les carrefours : on attend si un véhicule traverse déjà, et on cède le passage à l'entrée du rond-point.
- Arrêt pour les piétons engagés sur la chaussée (freinage anticipé dès 35 m).
- Vitesse adaptée à la rue : boulevards, rues pavées plus lentes, rond-point, route de la plage.
- Les véhicules garés sont contournés après 4 s d'attente.
- Correctif : les longues lignes droites des itinéraires étaient courbées par le lissage. Les véhicules sont maintenant au centre de leur voie.

**Piétons (44 promeneurs + 63 personnes immobiles)** :
- Marche sur les trottoirs, avec des pauses devant les vitrines et des demi-tours. Les vendeuses portent leur bassine sur la tête.
- **Traversées aux passages piétons** (41 passages peints). Ils attendent une voie libre ; aux feux, ils traversent quand les voitures ont le rouge.
- Personnes assises aux arrêts de bus, sur les bancs et aux grillades ; vendeuses au marché ; groupes devant les boutiques ; zémidjans qui attendent les clients.

**Ambiance urbaine** :
- 6 abribus avec panneau BUS, 4 stations de zémidjans, grillades de rue (braise rougeoyante la nuit, fumée).
- Panneaux : STOP, cédez le passage, 50, feux, passage piéton, directions (Grand Marché, Plage, Centre-ville).
- Poubelles, bancs publics, et des lampadaires sur toutes les rues.

**Performances** :
- Mobilier fusionné en quelques maillages ; feux réduits à 4 maillages ; animations à cadence réduite au-delà de 35 m.
- Rendu et animation coupés hors de vue (véhicules au-delà de 170 m, piétons au-delà de 90 à 110 m).
- Calculs d'IA : environ 0,3 ms par image. Rendu : environ 200 appels de rendu (identique à la v0.5).

**Tests (simulation de 150 s)** :
- Véhicules dans un bâtiment : **0** ; points d'itinéraire dans un bâtiment : **0**.
- Piétons touchés : **0** ; piétons hors trottoir ou passage : uniquement pendant leur demi-tour au bord du rond-point.
- Véhicules bloqués : **0** (arrêt le plus long : 19 s, soit un cycle de feu).
- 2 à 6 véhicules engagés à l'orange franchissent la ligne au rouge (selon les essais).
- Quelques frôlements brefs aux jonctions sans feu (route de la plage) et au rond-point.

## 🗿 Mission 006 : lieux emblématiques (étape 1 : Place de l'Amazone)
**Emplacement** : en front de mer, au bout du boulevard nord-sud, sur la route côtière.
La carte est une **version stylisée** de Cotonou : aucune coordonnée géographique réelle n'est inventée ni reproduite.

**Réalisé (gratuit, procédural)** :
- Esplanade pavée de 72 × 28 m avec allée centrale, socle à gradins et piédestal en pierre.
- Plaque « AMAZONE – Hommage aux Agodjié » et panneau d'information historique.
- Deux drapeaux du Bénin, quatre jardins tropicaux (cocotiers, bougainvilliers, herbes), six bancs tournés vers la statue.
- Lampadaires de promenade, garde-corps face à l'océan et visiteurs.
- **Statue provisoire procédurale** : guerrière Agodjié en bronze, coupe-coupe à la main, environ 9,5 m sur un piédestal de 6,7 m.
  Éclairée par deux projecteurs la nuit. C'est une **interprétation libre**, et non une copie de l'œuvre réelle.
- Mini-carte : esplanade, jardins et icône « A ». Le nom de la zone s'affiche à l'écran.

**Tripo (en attente d'autorisation et de crédits)**, pour une statue de remplacement en GLB :

| Qualité | Coût |
|---|---|
| Standard (image de concept + Tripo 3.1, 30 000 faces) | 57 CU |
| Haute définition (géométrie et textures détaillées, 40 000 faces) | 102 CU |

**Droits** : la statue réelle (2022) est une œuvre protégée. Une interprétation libre est recommandée.
Vérifier aussi les conditions de Tripo (https://www.tripo3d.ai/terms) avant une diffusion commerciale.

**Prochaines étapes (après validation)** : Place des Martyrs, Marché Dantokpa (extension du marché actuel),
Boulevard de la Marina (le nom passera de l'axe central à la route côtière), zone côtière, nouveaux quartiers.

## 🏛 Mission 006 : étape 2 (v0.8), lieux emblématiques suivants
Tout est procédural et gratuit (0 crédit). Les monuments sont des **interprétations libres**.
La carte reste une **version stylisée**, sans coordonnées réelles.

- **Boulevard de la Marina** : la route côtière porte désormais ce nom (l'axe central devient « Boulevard central »).
  - Terre-plein central planté (cocotiers, bougainvilliers), lampadaires à double crosse, plaques de rue bleues.
- **Zone côtière** : 6 paillotes (toit de paille, comptoir, tables, clients), filets de pêche qui sèchent, pêcheurs, panneau « Baignade dangereuse ».
- **Place des Martyrs** (îlot entre la rue z = 100 et la Marina) :
  - mémorial en interprétation libre : stèle blanche sur gradins, flamme de bronze qui s'allume la nuit ;
  - quatre murs de plaques, trois drapeaux, jardins de flamboyants, bancs, visiteurs.
- **Marché Dantokpa** (l'ancien Grand Marché) :
  - bâtiment de marché à trois niveaux avec enseigne, deux halles couvertes en tôle remplies d'étals ;
  - arche « MARCHÉ DANTOKPA », porteurs, plus de vendeuses.
- **Quartiers** :
  - **quartier d'affaires** le long des boulevards centraux : tours vitrées de 5 à 7 étages, enseignes fictives (Banque Lagune, Hôtel Océan Bleu, Centre d'affaires) ;
  - **quartiers résidentiels** en périphérie : surtout des villas en concession et des immeubles de R+1 à R+2.
- **Mini-carte** : icônes D (Dantokpa), ✦ (Martyrs), A (Amazone), terre-plein de la Marina.
- **Correctif** : une grillade de rue (Mission 005) était posée sur la chaussée de la route côtière ; elle est replacée sur le trottoir.

**Performances (vue de départ, qualité Basse)** : 284 appels de rendu, 847 000 triangles, 225 Mo de mémoire JS.

## 🏠 Mission 010 : maison personnelle et vie quotidienne (v0.9)
Les missions 007 à 009 n'ont pas été reçues : cette version s'appuie sur la v0.8.
Tout est procédural (**0 crédit**, Tripo non nécessaire).

**La maison** (repère **M**, quartier situé entre la rue z = 100 et la Marina) :
- **Extérieur** : villa contemporaine sur deux niveaux.
  - Enduit clair, bardage bois, soubassement en pierre, grandes baies, auvent d'entrée.
  - Balcon à garde-corps vitré, toit-terrasse, citerne.
  - Clôture avec **portillon** et **portail coulissant**, allées pavées, jardin (cocotiers, bougainvilliers, flamboyant, manguier), terrasse avec parasol.
  - Lampes d'extérieur qui s'allument la nuit.
- **Intérieur visitable (rez-de-chaussée)** :
  - **pièces** : salon, cuisine avec coin repas, chambre, salle de bain, dressing, couloir d'entrée et garage ;
  - **portes** : porte d'entrée (E), portes intérieures automatiques, porte cuisine → garage ;
  - **éclairage** : 3 lumières réelles et des plafonniers (interrupteur à l'entrée) ;
  - **caméra** : en entrant, le toit et l'étage se masquent et la vue devient plongeante. Aucun chargement ni téléportation.
- **Limite** : l'étage existe en façade (balcon, baie, terrasse) mais **n'est pas visitable**, le moteur ne gère pas encore les escaliers.

**Activités (touche E, menus avec les chiffres 1 à 9)** :
- **Cuisine** :
  - le réfrigérateur propose amiwo, pâte & sauce gombo, atassi, akassa & poisson braisé, alloco et jus de bissap, avec un stock qui se recharge le matin ;
  - on cuisine à la cuisinière (vapeur, brûleur rougeoyant, grésillement), puis on mange assis à table. La jauge de faim remonte.
- **Chambre** : sieste (2 h) ou nuit complète jusqu'à 7 h. Le personnage s'allonge, l'écran passe au noir, l'heure avance et l'énergie est restaurée.
- **Salle de bain** : douche (eau animée et son, propreté à 100 %) ; lavabo (+20) avec un **vrai miroir réfléchissant**.
- **Dressing** : 6 tenues par personnage (homme ou femme), en 3 catégories : quotidien, élégant, décontracté. Exemples : boubou en bazin, costume, robe en bazin, jean et t-shirt. Le changement est visible immédiatement.
- **Salon** : télévision allumable, avec 5 chaînes fictives animées (Lagune Info, Sport+ Bénin, Météo Cotonou, Afro Clips, Nature TV). Canapé : ← → pour changer de chaîne, Espace pour allumer ou éteindre.
- **Garage** :
  - **voiture personnelle** (berline verte) ;
  - porte sectionnelle (E), et télécommande automatique qui ouvre le portail et le garage à l'approche en voiture ;
  - tableau à clés pour rapatrier la voiture au garage. Les murs et la porte fermée bloquent le véhicule.

**Jauges** : faim, énergie et propreté baissent avec le temps de jeu, plus vite en courant. Une énergie trop basse empêche de courir.

**Carte et marqueur M** :
- **M** apparaît sur la mini-carte, avec une flèche sur le bord quand la maison est hors de vue.
- La **carte générale** s'ouvre avec la touche **C** ; un toucher sur M ou le bouton « Définir M comme destination » active l'itinéraire.
- Pendant l'itinéraire : **ligne pointillée sur la carte, colonne lumineuse au-dessus de la maison**, distance affichée en permanence.
- C'est un guidage à vol d'oiseau, pas un GPS rue par rue.

**Sauvegarde automatique** (navigateur, toutes les 15 s et à la fermeture) :
- position de la maison, tenue, état du garage et du portail, position de la voiture personnelle ;
- faim, énergie et propreté, heure du jeu, position du joueur, réfrigérateur, télévision et lumières.
- Menu → **NOUVELLE PARTIE** pour tout effacer.

**Commandes tactiles (iPhone / Android)** : joystick à gauche (pousser à fond = courir), glisser à droite pour la caméra, boutons **E**, **saut / frein**, **course**, **klaxon** (en voiture), **CARTE** et **pause**. Qualité Basse par défaut sur mobile.

**Tests** :
- Maison :
  - collisions (murs, porte fermée / ouverte), repas (faim de 30 à 75), nuit (22 h → 07:00, énergie 100 %), douche (propreté de 15 à 100 %) ;
  - tenues, télévision (on/off/chaînes), garage (voiture bloquée puis sortie dans la rue), rapatriement, distance M ;
  - **sauvegarde puis rechargement réel de la page** : tout est restauré.
- iPhone 13 émulé (paysage) : joystick (déplacement), bouton E (montée en voiture), disposition compacte.
- Performances : 290 appels de rendu, 871 000 triangles.

## 🌦 Mission 008 : jour, nuit et météo dynamique (v1.0)

**Cycle jour/nuit** (déjà présent, enrichi) : soleil physique (ciel `Sky` de Three.js), lune, étoiles, ombres qui tournent avec le soleil, éclairage d'ambiance recalculé depuis le ciel (reflets). Périodes affichées sous l'horloge : *Lever du soleil* (5h20), *Matin*, *Après-midi*, *Coucher du soleil* (17h35), *Crépuscule* (18h55), *Nuit* (19h50).

**Météo** (`src/weather.js`) : ☀ dégagé, ⛅ nuageux, 🌧 pluie tropicale, 🌫 brume légère.
- Transitions progressives : les nuages s'épaississent, le soleil se voile, puis la pluie commence.
- Mode automatique : averses plus probables l'après-midi, brume côtière seulement le matin (elle se lève vers 10h30). Une averse dure 0,6 à 1,6 h de jeu.
- Pluie : 1 600 / 3 800 / 7 000 gouttes selon la qualité (Basse / Moyenne / Haute), animées entièrement par la carte graphique. Pas de pluie à l'intérieur de la maison.
- Orages : éclairs (flash de lumière) et tonnerre décalé. Son de pluie, étouffé à l'intérieur ; oiseaux et grillons se taisent sous la pluie.
- Sol mouillé : routes, trottoirs, pavés et latérite s'assombrissent et deviennent brillants, avec des flaques dans les creux. Ils sèchent en 1 à 3 h de jeu, plus vite au soleil. Herbe et sable sont peu affectés.
- Lampadaires, vitrines et fenêtres s'allument la nuit, et aussi pendant un gros orage en journée. Les phares suivent la même règle.

**Horloge et réglages**
- `T` avance d'une heure, `Maj+T` recule d'une heure, `Y` change la météo (auto → dégagé → nuageux → pluie → brume).
- Options : *Heure de la journée* (curseur), *Météo*, *Vitesse du temps* (figée, lente, normale = 20 min, rapide, très rapide).
- L'heure et la météo sont sauvegardées.

**Performances** : aucune lumière dynamique ajoutée. Pluie en un seul appel de dessin, sol mouillé calculé dans le shader existant (aucune texture en plus). L'éclairage d'ambiance n'est recalculé que quand l'heure ou la météo change vraiment. Aucun crédit Tripo/Scenario utilisé.

## 🎒 Mission 009 : arsenal et système d'équipement (v1.1)

**50 objets imaginaires**, 10 par catégorie : Protection, Gadgets, Outils, Énergie, Spéciaux. Le détail est dans `CATALOGUE_OBJETS.md`, généré par `node tools/catalogue.mjs` depuis `src/items.js`. Aucun objet ne reproduit une arme réelle ni un mécanisme réel : les effets « offensifs » sont des jouets lumineux, des bulles, du vent, des confettis.

**Modèles 3D** : procéduraux (formes simples fusionnées, 70 à 900 triangles, 1 à 3 appels de dessin par objet). Les icônes et l'aperçu 3D tournant sont rendus par le moteur du jeu, sans aucun fichier image. Aucune génération Tripo n'a été faite (crédits non autorisés).

**Inventaire** (touche `I`, ou bouton 🎒 sur iPhone)
- Grille d'icônes, filtres par catégorie et par rareté (Commun, Peu commun, Rare, Épique, Légendaire).
- Fiche descriptive avec aperçu 3D, pastille « nouveau » pour les objets jamais consultés.
- 4 emplacements : Tête, Corps, Main, Dos. Équiper / retirer au clic, au double-clic, avec Entrée ou E. Navigation au clavier (flèches, Tab).
- Sauvegarde : objets équipés et objets consultés.

**En jeu**
- Les objets équipés sont portés par le personnage (os de la tête, de la poitrine, de la main droite), avec une apparition animée. Ils sont rappelés dans le HUD.
- `G` (ou bouton ✦) utilise l'objet tenu en main. Effets réels :

| Type d'effet | Objets |
|---|---|
| Particules | bulles, confettis, étincelles, sable, poussière, arcs |
| Anneau | anneau lumineux |
| Lumière | dôme lumineux, lampe torche (faisceau et halo au sol) |
| Animations | drone en orbite (15 s), disque-boomerang, hologramme du drapeau, orbe flottante |
| Objet animé | parapluie qui s'ouvre |
| Caméra | zoom des jumelles |
| Photo | vraie capture d'écran à enregistrer |
| Sons | radio (air de musique), tam-tam (rythme) |
| Informations | scanner (compte réel des passants et véhicules à 35 m), boussole (distance et direction réelles vers M et la mer), carte |
| Jauges | gourde +8 énergie, calebasse +10 propreté (une fois par minute) |

- Passifs réels : récupération de l'endurance de +15 % à +60 % selon l'objet de dos. Les lunettes ambrées ajoutent un filtre doré à l'écran.

**Performances** : un seul système de particules (700 points) pour tous les effets. Seuls les objets équipés sont présents dans la scène. Les icônes sont rendues une seule fois, et l'aperçu 3D seulement pendant que l'inventaire est ouvert.

## ✧ Mission 011 : 20 pouvoirs mystiques (v1.2)

Univers **fantastique** inspiré des couleurs, motifs (tentures appliquées d'Abomey), paysages et sons du Bénin. Les pouvoirs et leurs symboles sont **inventés pour le jeu** : ils ne représentent ni divinités, ni rites, ni cérémonies réelles du Vodun. Un avertissement est affiché dans le menu.

**Fichiers**
- `src/powers-data.js` : les 20 pouvoirs (catégorie, niveau de déblocage, durée, recharge, puissance, coût, description) et les 20 symboles dessinés en vectoriel.
- `src/powers.js` : le système complet.

**Système de jeu**
- *Énergie mystique* (barre violette « MYSTIQUE ») : 100 au départ, +10 par niveau. Elle se recharge de 1,5/s, deux fois plus vite la nuit et trois fois plus près d'une pierre-portail découverte.
- *Progression* : 10 niveaux. On gagne de l'XP en lançant les pouvoirs (+25 la première fois, +4 ensuite), en recueillant les 20 symboles cachés (+60), en découvrant les 6 pierres-portails (+80) et en repoussant des feux follets (+15).
- *Déblocage* : au niveau 1 (Feu, Vent, Aura, Vision), puis progressivement jusqu'au niveau 10 (Éveil Mystique).
- *Améliorations* : 2 points par niveau, 3 rangs par pouvoir (durée +25 %, recharge −15 %, puissance +1 par rang).
- *Raccourcis* : 5 emplacements. `1`…`5` lancent, `R` sélectionne le suivant, `X` lance le pouvoir sélectionné. Sur iPhone, on touche directement la barre.
- *Menu* : touche `U` (bouton ✧ sur iPhone), avec catégories, fiches, statistiques, rang suivant, amélioration, attribution d'un raccourci et lancement.

**Éléments ajoutés pour que les pouvoirs aient de vrais effets**
- 9 feux follets : créatures imaginaires et inoffensives qui aspirent un peu d'énergie mystique au contact.
- 20 symboles cachés, visibles uniquement avec *Vision des Esprits*.
- 6 pierres-portails : Maison, Amazone, Martyrs, Dantokpa, Plage, Carrefour.

**Effets réels branchés sur le jeu**
- *Déplacement* : vitesse et saut (Vent, Éveil), téléportation qui respecte les murs (Pas Fantôme), téléportation vers une pierre découverte (Portail).
- *Jauges* : énergie restaurée (Régénération), endurance qui ne baisse plus (Aura, Terre).
- *Circulation et passants* : véhicules qui s'arrêtent et passants écartés (Bouclier, Eau, Terre, Colosse, Gardiens, Double). Passants et véhicules garés repoussés (Onde, Foudre, Danse).
- *Créatures et ambiance* : feux follets repoussés (Feu, Lumière, Onde, Gardiens, Danse, Éveil), brouillard magique (Brume), éclairs qui illuminent toute la ville (Foudre, Danse).

**Rendu**
- Auras en shader de flammes, coques de bouclier à motifs de losanges ou d'eau, symboles tournants au sol, colonnes de lumière.
- Blocs de latérite, gardiens géométriques de latérite et d'or, illusion du personnage, silhouettes lumineuses imaginaires.
- Sons synthétisés : cloche double (type gankogui), tambour à hauteur glissante, hochets, souffles.

**Performances** : aucune lumière dynamique (pas de recompilation de shaders), un seul système de particules, des effets créés seulement pendant leur durée. Le coût mesuré est d'environ +9 appels de dessin (pierres-portails). Aucun crédit payant utilisé.

## 📱 Jouer sur iPhone sans connexion

`npm run build` génère aussi `dist/iphone-hors-ligne/` : une application web installable (manifeste et icônes) avec cache hors ligne (service worker). Il faut l'héberger une fois en HTTPS, par exemple sur GitHub Pages (gratuit). On l'ouvre ensuite dans Safari, puis Partager → « Sur l'écran d'accueil ». Après cette première ouverture, le jeu se lance sans connexion.

## 🚗 Mission 012, étape 1 : garage AUTO CONCEPT et 13 véhicules (v1.3)

**Noms fictifs** (validés par l'utilisateur) : chaque véhicule s'inspire d'une catégorie et d'une silhouette de voiture réelle, sans logo, nom déposé ni copie exacte. Fichier `src/cars-data.js`.

| Véhicule | Inspiration | Vmax | 0-100 | Moteur |
|---|---|---|---|---|
| Voltex Cybra | pick-up électrique anguleux | 175 | 3,6 s | électrique |
| Fiorano Rosso 48 | supercar à moteur central | 215 | 3,0 s | V8 |
| Taurino Urca | SUV super-sportif | 190 | 3,8 s | V8 |
| Merano G-Kaiser | 4x4 carré de luxe | 160 | 5,5 s | V8 |
| Bavaro M-Coupé | coupé sportif | 200 | 3,9 s | 6 en ligne |
| Toyoka Sahel Cruiser | grand 4x4 | 165 | 7,0 s | diesel |
| Rangers Sport | SUV de luxe | 180 | 5,0 s | V6 |
| Stuttgarto 9-11 | sportive à moteur arrière | 205 | 3,4 s | 6 à plat |
| Ingolda RS Fastback | berline sportive | 200 | 3,6 s | V8 |
| Nikko GT-Raijin | coupé GT | 205 | 3,1 s | V6 biturbo |
| Royce-Ashanti Diamant | SUV d'ultra-luxe | 170 | 5,2 s | V12 |
| Dearborn Stallion | muscle car | 195 | 4,4 s | V8 |
| Toyoka Hilo | pick-up robuste | 150 | 9,5 s | diesel |

**Garage AUTO CONCEPT** (Quartier Jéricho, bord du boulevard nord) :
- showroom vitré avec enseigne, 3 plateaux tournants d'exposition (qui changent toutes les 25 s) ;
- comptoir d'accueil (`E` pour ouvrir le menu), 3 zones de livraison jaunes, atelier de réparation bleu (s'arrêter 2 s).

**Menu** :
- *Concession* : aperçu 3D tournant, statistiques et 6 couleurs par modèle ;
- *Mes véhicules* : distance, état, « Livrer ici », « Réparer », « Retirer ».

**Chaque véhicule** (`src/garage.js`) :
- modèle 3D propre ; roues qui tournent et braquent ; portière conducteur qui s'ouvre à l'entrée et à la sortie ;
- phares (allumés automatiquement la nuit), feux arrière, feux stop, feux de recul, phare dynamique unique partagé ;
- physique distincte (accélération, vitesse max, freinage, braquage, adhérence, glisse au frein à main) ;
- boîte de vitesses simulée (1 rapport pour l'électrique) ;
- son moteur propre (V8, V12, V6, 6 en ligne, 6 à plat, diesel, sifflement électrique) et klaxon propre (`K`) ;
- tableau de bord : vitesse, rapport, compte-tours, état, phares, vue ;
- vue intérieure / extérieure (`V`, bouton 👁 sur iPhone) avec sièges, planche de bord et volant qui tourne.

**Dégâts visuels non graphiques** : rayures et salissures au point de choc, phares cassés après 35 % puis 60 %, fumée au-delà de 65 %, véhicule moins rapide et direction qui flotte au-delà de 70 %. Tout est réparable à l'atelier.

**Sauvegarde et performances** :
- véhicules possédés sauvegardés (modèle, couleur, position, état), retrouvés où on les a laissés ;
- véhicules ajoutés à moins de 220 m du joueur et retirés au-delà de 280 m ;
- bâtiment affiché à moins de 170 m, voitures d'exposition à moins de 90 m.

Mesures en simulation : 0-100 km/h et vitesses max conformes aux fiches ; coût de rendu inchangé loin du garage. Aucun crédit payant utilisé.

## ✈ Mission 012, étape 2 : monde agrandi, aéroport et 8 avions (v1.4)

**Monde agrandi** (`src/airport.js`, seulement 6 maillages) : savane, banlieues (maisons basses aux toits de tôle), cocotiers et arbres, bande de sable, océan sur plusieurs kilomètres, lagune au nord. La disposition est stylisée, sans coordonnées géographiques réelles. Zone de vol d'environ 12 km × 12 km, avec demi-tour automatique aux limites.

**Aéroport de Cotonou** (à l'ouest, le long de la côte, relié par la route du boulevard z = 100) :
- piste de 1,5 km (marquages, seuils, numéros 09/27, balisage lumineux la nuit), voie de circulation et bretelles ;
- deux aires de stationnement, terminal vitré avec passerelles, tour de contrôle, 3 hangars, manche à air, clôture ;
- kiosque « VOLS » (`E`) : choix de l'avion, puis « Préparer sur la piste » ou « Embarquer au parking » ;
- pierre-portail de l'aéroport : 7e pierre du pouvoir Portail Mystique.

**8 avions** (noms fictifs, `src/aircraft-data.js`) :

| Avion | Type |
|---|---|
| Cesla 172 | avion léger à hélice |
| Atlantis 72 | avion régional à turbopropulseurs |
| Gulfwing G65 | jet privé |
| Faucon 8X | jet d'affaires triréacteur |
| Skyliner 737 | avion de ligne |
| Aeria A320 | avion de ligne |
| Jumbo 747 | gros-porteur à bosse |
| Aeria Super A380 | très gros-porteur à double pont |

**Chaque avion** :
- modèle 3D procédural (fuselage, ailes en flèche et dièdre, winglets, empennage classique ou en T, nacelles, inscription « BENIN LIFE AIR », drapeau sur la dérive) ;
- pièces mobiles : soufflantes de réacteur et hélices qui tournent, train rentrable, volets ;
- escalier d'embarquement au poste de stationnement, embarquement et débarquement avec fondu ;
- vue cockpit avec planche de bord (`V`) et son propre (grondement de réacteur ou bourdonnement d'hélice).

**Pilotage arcade** :

| Touche | Action |
|---|---|
| `Maj` / `Espace` | gaz + / gaz − (au sol, `Espace` freine quand les gaz sont coupés) |
| `Z/W` | monter (cabrer) |
| `S` | descendre (piquer) ; au sol à l'arrêt : repoussage |
| `Q`/`D` | virer en inclinant (au sol : roulette de nez) |
| `G` | train d'atterrissage |
| `B` | volets (automatiques par défaut) |

Décrochage sous la vitesse minimale. Atterrissage réussi si le train est sorti, la descente modérée et les ailes à plat. Sinon (ventre, trop brutal, eau, bâtiment), l'avion est ramené sur la piste, sans aucune image choquante.

**Tableau de bord de vol** : vitesse (km/h et nœuds), altitude, vitesse verticale, cap, horizon artificiel, gaz, train, volets, alarmes (décrochage, trop bas, rotation).

Mesures en simulation :

| Mesure | Résultat |
|---|---|
| Course de décollage | de 75 m (Cesla 172) à 720 m (Jumbo 747) |
| Montée | 100 à 350 m en 18 s |
| Virage en 8 s | de 27° (A380) à 115° (Cesla) |

Les atterrissages réussis et les cas de crash ont été vérifiés.

**Performances** : avions présents seulement à moins de 1,8 km ; en vol, la vue lointaine et la brume s'adaptent à l'altitude. En qualité basse, les banlieues lointaines ne s'affichent qu'en vol ou près de l'aéroport. Les murs invisibles de la ville sont ignorés par les avions. Positions des avions sauvegardées. Aucun crédit payant utilisé.

## 🍲 Mission 013, étape 1 : économie en FCFA, téléphone et cuisine béninoise (v1.5)

**Économie** (`src/economy.js`) :
- portefeuille en **FCFA** : solde de départ de 25 000 FCFA, puis **allocation quotidienne de 5 000 FCFA à 7 h**, versée aussi quand on dort jusqu'au matin ;
- historique des opérations (montant, lieu, jour, heure) ; un achat est refusé si le solde est insuffisant ;
- notifications à l'écran pour chaque achat, revenu ou livraison ;
- **sac de courses** : les achats faits en ville seront transportés puis rangés au réfrigérateur (bouton « Ranger mes courses »).

**Téléphone virtuel** (`N`, bouton 📱 sur iPhone) : Portefeuille et historique, **Courses à domicile**, Livraisons en cours, Mon frigo, Mon sac.
- Courses à domicile : produits frais, boissons et fruits ; panier, total, frais de 500 FCFA.
- La livraison arrive au réfrigérateur au bout de 30 minutes de jeu.

**Cuisine** (`src/food-data.js`, `src/food.js`) : **51 aliments béninois** avec prix indicatifs du jeu et un **modèle 3D chacun**.
- *Plats* : pâte rouge, pâte blanche, igname pilée (agoun), akassa, gari, riz, ablo, amiwo au poulet, watché, atassi, riz au gras, riz sauce tomate, haricots, gari avec sauce, alloco.
- *Sauces* : arachide, tomate, légumes, gombo, feuille, pimentée.
- *Garnitures* : wagashi, poisson grillé, poulet grillé.
- *Boissons* : bissap, baobab, gingembre, eau, akpan.
- *Fruits* : mangue, ananas, bananes, oranges, papaye, coco.
- *Produits frais et ingrédients* : 16 au total.

**Nouveau réfrigérateur** :
- onglets, icônes 3D générées progressivement, quantités, capacité de 80 ;
- on compose une assiette (plat + sauce + garniture), on la réchauffe à la cuisinière si un élément se mange chaud, puis elle est servie en 3D sur la table et on la mange ; la jauge de faim augmente de la somme des éléments ;
- boissons et fruits se consomment tout de suite.

**18 recettes** à la cuisinière (pâtes, amiwo, igname pilée, riz, watché, atassi, haricots, 6 sauces, poisson, poulet, alloco). Les ingrédients sont consommés et les portions rangées au réfrigérateur ; une seule préparation à la fois.

**Sauvegarde et compatibilité** : solde, historique, sac, livraisons, stock, préparation en cours et assiette servie sont sauvegardés. Les anciennes sauvegardes reprennent le stock de l'ancien réfrigérateur. Le rechargement gratuit du frigo chaque matin est remplacé par l'allocation quotidienne.

Testé : assiette pâte rouge + sauce arachide + poisson (faim +60), recette (riz au gras ×3), boisson, commande et livraison, allocation après une nuit, refus si solde insuffisant, sac vers frigo, sauvegarde et rechargement. Pas d'erreur sur ordinateur ni en simulation iPhone ; coût de rendu inchangé.

## 🧺 Mission 013, étape 2 : marché Dantokpa interactif (v1.6)

Le marché Dantokpa existant (halles couvertes, étals en plein air, arche « GRAND MARCHÉ ») devient interactif (`src/market.js`, `src/market-data.js`).
- **12 étals tenus par des vendeurs fictifs**, chacun avec un nom affiché au-dessus de l'étal et une spécialité : légumes, céréales et farines, fruits, poissons, volailles et œufs, épices, plats cuisinés, boissons fraîches, wagashi, tissus et vêtements, accessoires et décoration, produits locaux.
- Approche-toi d'un vendeur et appuie sur **E** (bouton E sur iPhone) : « Parler à… ».
- **Négociation** :
  - le vendeur annonce un prix au-dessus du prix de base, et tu proposes ton offre (±50 FCFA, −10 / −20 / −30 %) ;
  - le vendeur accepte, fait une contre-offre ou se vexe si l'offre est trop basse ;
  - sa patience est limitée : il finit par annoncer son « dernier prix ».
- **Achat** : choix de la quantité, paiement en FCFA dans le portefeuille (historique « Marché Dantokpa • nom du vendeur »).
  - Les aliments vont dans le **sac** puis au réfrigérateur de la maison.
  - Les objets (pagnes wax, chemise, robe, sandales, chapeau, sac en raphia, perles, panier, savon noir, karité, calebasse, statuette, radio, lampe solaire) vont dans **« Mes articles »** du téléphone. Ce sont des possessions : ils ne s'équipent pas encore sur le personnage.
- **Horaires** : les étals sont ouverts de 6 h à 20 h.
- **Ambiance** : appels de vendeurs au loin, petite voix stylisée quand le vendeur parle, son de paiement. Le brouhaha existant est conservé.
- **Sauvegarde** : les articles achetés sont sauvegardés. Les prix négociés repartent de zéro à chaque achat.

Testé :
- les 12 vendeurs sont accessibles malgré les collisions ;
- négociation et contre-offre ;
- achat d'aliments vers le sac et d'articles vers « Mes articles » ;
- refus si le solde est insuffisant ;
- marché fermé la nuit ;
- sauvegarde et rechargement ;
- parcours complet au toucher sur iPhone (E → choisir → −30 % → proposer → acheter → téléphone).

Aucune erreur détectée.

## 🛒 Mission 013, étape 3 : supermarché LAGUNA (v1.7)

**LAGUNA** est une enseigne **fictive** (nom inventé, aucun lien avec un supermarché réel). Le magasin se trouve sur le boulevard nord, côté est, face au garage AUTO CONCEPT. Son code est dans `src/supermarket.js`.

**Le bâtiment se visite** :
- parking avec places marquées, totem et enseigne, auvent ;
- façade vitrée et **portes coulissantes automatiques** ;
- ouvert de **7 h à 22 h** : la nuit, les portes restent fermées depuis l'extérieur, mais on peut toujours sortir ;
- à l'intérieur, le toit se masque pour garder la caméra sur le joueur ;
- 4 gondoles garnies de produits, réfrigérateurs vitrés au fond, étals de fruits et légumes ;
- 3 caisses, dont 2 tenues par des caissières, et des clients dans les allées ;
- la nuit, l'intérieur est éclairé sans lumière supplémentaire : les lampes de la maison, éteintes car loin, sont réutilisées.

**Les courses** :
- **E devant un rayon** ouvre la liste des produits (icônes 3D, prix affichés, sans négociation) ; on ajoute au **panier** (40 articles au maximum).
- Le panier s'affiche à l'écran (🛒 nombre d'articles et total).
- Rayons : fruits & légumes, épicerie, boissons, pain & en-cas, produits frais, hygiène & maison.
- **E à une caisse** affiche le détail du panier (on peut retirer des articles), le total et le bouton **PAYER**, puis le **ticket de caisse**.
- Les aliments vont dans le sac (puis au réfrigérateur), les autres articles dans « Mes articles ».
- **Sortir sans payer** déclenche l'alarme et ramène le joueur à l'intérieur.
- Si l'on s'éloigne autrement (portail, téléportation), les articles sont reposés en rayon.

**Nouveaux produits avec modèle 3D** : lait, jus d'orange, soda, yaourt à boire, pain, biscuits, chocolat, sardines, spaghetti, concentré de tomate, sucre.
- Le réfrigérateur de la maison a un nouvel onglet « Pain & en-cas ».
- Nouvelle **recette** : spaghetti sauce tomate (spaghetti + concentré de tomate + oignons).
- Nouveaux articles d'hygiène et de maison : dentifrice, gel douche, lessive, papier toilette, piles, bougies.

Testé :
- entrée par la porte avec les collisions ;
- les 11 points d'interaction répondent ;
- panier, puis tentative de sortie sans payer (bloquée), paiement, sortie ;
- portes fermées la nuit ;
- produits rangés au réfrigérateur ;
- parcours complet au toucher sur iPhone (rayon, ajout, caisse, paiement, ticket).

Aucune erreur détectée.

## 🚦 Mission 013, étape 4 : zémidjan, tokpa-tokpa et taxi (v1.8)

Nouvelle application **Transports** dans le téléphone (`N`), code dans `src/transport.js`.

**Trois services** (tarifs du jeu en FCFA, indicatifs) :

| Service | Type | Prise en charge | Prix |
|---|---|---|---|
| Zémidjan | moto-taxi : le conducteur porte la chemise jaune, tu es assis derrière lui | ~8 s | à partir de 200 FCFA |
| Tokpa-tokpa | minibus collectif, deux arrêts en route | ~18 s | le moins cher, à partir de 150 FCFA |
| Taxi | voiture avec plaque « TAXI », trajet direct | ~12 s | le plus cher, à partir de 600 FCFA |

**8 destinations**, toutes déjà présentes dans le jeu : ma maison, marché Dantokpa, supermarché LAGUNA, garage AUTO CONCEPT, place des Martyrs, jardin de Cadjèhoun, plage (boulevard de la Marina), aéroport. Pour chacune, le téléphone affiche la distance, la durée du trajet et le prix.

**Déroulement d'une course** :
1. Tu commandes depuis le téléphone ; un bandeau indique l'arrivée du véhicule et permet d'annuler gratuitement.
2. Le véhicule s'arrête sur la route la plus proche et klaxonne. Tu t'en approches et appuies sur **E** pour monter : la course est payée à ce moment-là.
3. Le véhicule roule tout seul sur la voie de droite des boulevards, arrondit les virages, contourne le rond-point central, s'arrête derrière la circulation, puis la dépasse si elle est bloquée.
4. **Espace** (ou le bouton ⏩) passe le trajet ; l'heure du jeu avance de la durée restante.
5. À l'arrivée, tu descends sur le trottoir du côté de la destination, et le véhicule repart.

Si personne ne monte au bout de 2 minutes, le véhicule repart sans rien facturer. Une commande est refusée si le solde est insuffisant.

Testé :
- 64 itinéraires (8 départs × 8 destinations) : aucun obstacle sur le trajet, aucun passage dans l'anneau du rond-point ;
- course complète en taxi (paiement, trajet de 37 s, descente du bon côté) ;
- tokpa-tokpa vers l'aéroport avec ses arrêts et « passer le trajet » ;
- annulation, solde insuffisant, attente trop longue ;
- commande, montée et « passer le trajet » au toucher sur iPhone.

Aucune erreur détectée.

## 🗺️ Mission 013, étape 6 : la région de Cotonou à l'échelle 1:5 (v1.9)

La carte s'étend désormais à **Porto-Novo, Ouidah, Pahou et Cocotomey**, reliées à Cotonou par la **RNIE 1**.
- Code : `src/region-geo.js`, `src/region.js`.
- Données générées par `tools/region/build_region.py` dans `src/region-data.js`.

**Sources vérifiables (aucune position inventée)** :
- **Centres des villes** : OpenStreetMap (Nominatim). Exemples : Porto-Novo 6,4991 N / 2,6253 E ; Ouidah 6,3666 N / 2,0854 E ; Pahou 6,3839 N / 2,2128 E ; Cocotomey 6,3918 N / 2,3012 E.
- **Tracé de la RNIE 1** (Ouidah – Pahou – Cocotomey – Cotonou – Sèmè-Kpodji – Porto-Novo) : 86 tronçons OpenStreetMap.
- **Lac Nokoué et lagune de Porto-Novo** : contours OpenStreetMap. Ils remplacent l'ancienne lagune rectangulaire fictive.
- **Trait de côte** : Natural Earth 1:10m (domaine public). Cette donnée est peu détaillée, et le littoral est donc tracé de façon simplifiée.
- Les données brutes sont dans `tools/region/osm/`. Données © contributeurs OpenStreetMap, licence ODbL.

**Échelle et raccords de jeu** (signalés, non géographiques) :
- 1 m du jeu = 5 m réels ; Ouidah est à environ 7,5 km de Cotonou dans le jeu.
- La ville du jeu reste celle des missions précédentes. Elle n'est pas un plan réel de Cotonou.
- La RNIE 1 est reliée aux boulevards de la ville : sortie nord par le boulevard x = −100, sortie est par le boulevard z = −100.
- Le littoral réel est raccordé progressivement à la plage du jeu à moins de 1,5 km de la ville.
- Les petits trous de la donnée routière (tronçons non renvoyés par Nominatim) sont comblés en ligne droite.

**Dans le jeu** :
- **Route** : RNIE 1 goudronnée avec bandes de rive et ligne médiane, accotements en terre ; habitations et cocotiers le long de la route.
- **Villes** : générées autour de leur centre réel, avec des quartiers en damier orientés comme la route, des rues en terre, des maisons, des immeubles et boutiques au centre, et des cocotiers. Chaque ville a son panneau d'entrée (par exemple « PORTO-NOVO — Capitale du Bénin »).
- **Monuments** : aucun monument réel n'a été ajouté, faute de positions vérifiées pour chacun.
- **Déplacements** : à pied, en voiture ou à moto, on quitte la ville librement. La mer et les lacs arrêtent les déplacements, et le nom de la zone s'affiche (ville, RNIE 1, Lac Nokoué, Environs de Cotonou).
- **Carte (C)** :
  - bouton « Voir la région / Voir Cotonou » ;
  - la région s'affiche avec ses villes, la route, le lac, l'aéroport et la distance de chaque ville ;
  - hors de Cotonou, la mini-carte passe automatiquement sur la carte de la région.
- **Transports** :
  - le taxi, le zem et le tokpa-tokpa vont jusqu'aux 4 villes, avec un tarif dégressif au-delà de 1,5 km ;
  - « passer le trajet » avance l'heure d'au plus 1 h.
- **Performances** : villes et bords de route chargés à moins de 1,2 à 1,8 km et libérés au-delà. À Porto-Novo (simulation iPhone), le rendu reste à 13 appels de dessin.

Testé :
- 12 trajets en taxi vers les 4 villes, sans obstacle ;
- sorties nord et est de la ville ;
- course complète jusqu'à Ouidah ;
- carte de la région sur ordinateur et sur iPhone ;
- aucune erreur.

## 🏢 Mission 014, étape 1 : siège de NOVA BOOK (v2.0)

Le siège de **NOVA BOOK**, la maison d'édition du joueur, se trouve dans le quartier d'affaires, au bord du boulevard central, au sud-est du rond-point. Le bâtiment est entièrement procédural (aucune ressource payante) ; le code est dans `src/nova.js` et `src/nova-data.js`.

**Extérieur** :
- immeuble moderne vitré de 6 niveaux, avec bandeaux d'étage et poteaux ;
- grande enseigne lumineuse « NOVA BOOK » sur le toit (plus brillante la nuit) et enseigne verticale « NOVA » ;
- auvent d'entrée, portes coulissantes automatiques, jardinières ;
- parking réservé aux employés et visiteurs, avec panneau et voitures garées.

**Intérieur (6 niveaux visitables)** :

| Niveau | Contenu |
|---|---|
| Rez-de-chaussée | hall, réception avec réceptionniste, mur logo, espace d'attente, présentoirs de livres, service commercial et clientèle (2 employés), salle de réunion vitrée avec écran interactif (E l'allume et affiche le catalogue) |
| 1er étage — graphisme | 8 postes avec écran (logiciel fictif *NovaDesign*) et tablette graphique, panneaux de couvertures, mur d'affiches et d'illustrations ; 5 personnes au travail |
| 2e étage — maquettisme et édition | postes à double écran (*NovaPage*), tables de correction avec manuscrits, rayonnages de livres et de maquettes ; 5 personnes |
| 3e étage — informatique et audiovisuel | postes triple écran (*NovaCode*), salle de tests et de maintenance avec baies de serveurs ; stations de montage (*NovaCut*), monteurs avec casque, studio (fond vert, caméra, projecteurs, micro) ; 5 personnes |
| 4e étage — impression | presse offset, traceur grand format, relieuse, massicot, plastifieuse, poste de contrôle qualité, palettes de papier, zone d'emballage avec tapis ; 4 imprimeurs ; machines animées |
| 5e étage — direction | bureau vitré du PDG, administration (comptable, RH, secrétaire), salle du conseil, espace de repos avec machine à café, agent d'entretien |

Machines du 4e étage : rouleaux, chariot, lame, livres et cartons bougent. **E** devant une machine la fait tourner à plein régime.

Bureau du PDG :
- grand bureau en bois, fauteuil, 3 écrans, téléphone, canapé, table de réunion privée, bibliothèque, tableaux, grandes baies vitrées ;
- **E** permet de s'asseoir au bureau ou dans le canapé ;
- un interrupteur règle l'éclairage (blanc, chaleureux, bleu NOVA, tamisé) ;
- un **écran mural de statistiques** s'actualise en direct (heure, effectif par département, masse salariale).

Dans tout le bâtiment :
- ascenseur et escaliers à chaque étage (**E**) ;
- sanitaires visitables ;
- panneau d'étage devant l'ascenseur ;
- **E** près d'un employé pour le saluer : il répond en décrivant son travail.

**Équipe de départ** : 26 employés fictifs (nom, métier, étage, salaire mensuel de base) dans `src/nova-data.js`. Chacun a une animation adaptée : frappe au clavier, dessin sur tablette, lecture de manuscrit, montage avec casque, manipulation de machine, balai.

**Technique** :
- collisions par étage (le niveau courant filtre les obstacles) et plancher du joueur à la hauteur de l'étage ;
- seul l'étage visité est affiché et animé ; les niveaux supérieurs et le toit sont masqués à l'intérieur ;
- employés créés à la première visite de leur étage ;
- caméra intérieure plus large dans ces grands plateaux ;
- la nuit, les lampes de la maison, éteintes car loin, sont réutilisées pour éclairer l'étage, sans lumière supplémentaire.

**Pas encore fonctionnel** : le logiciel de gestion de l'ordinateur du PDG (recrutement, salaires, commandes, comptabilité, groupe de sociétés, banque). Le jeu l'indique clairement quand on s'assoit au bureau. C'est l'objet des étapes suivantes.

## 🏠 Complément mission 010 : maison entièrement aménagée (v2.1)

Le plan des pièces, les portes et toutes les fonctions existantes sont conservés : réfrigérateur et recettes (mission 013), cuisinière, table, sommeil, douche, tenues, télévision, garage, marqueur M. L'aménagement est ajouté par `src/home-plus.js`. Tout est procédural (coût : 0).

**Cuisine** :
- crédence carrelée, four sous la plaque, micro-ondes ;
- **placards hauts à portes ouvrantes** (E) avec assiettes, verres, bols et tasses ;
- ustensiles suspendus, égouttoir, casserole, planche, poubelle à pédale, suspensions au-dessus de la table, rangement au-dessus du réfrigérateur, tableau.

Interactions de la cuisine :
- **micro-ondes** : réchauffe l'assiette composée au réfrigérateur ;
- **évier** : faire la vaisselle (propreté +20) ;
- les courses du marché Dantokpa et du supermarché LAGUNA se rangent toujours au réfrigérateur.

**Salon** :
- deux fauteuils (on peut s'y asseoir), guéridon avec lampe, lampadaire ;
- rideaux, deux tableaux, climatisation, étagère murale ;
- **rubans LED** derrière et sous la télévision, réglables (E près de la porte) ;
- télévision : nouveau **programme TV du jour** (émissions fictives par chaîne et par heure). Assis sur le canapé, les flèches servent de télécommande pour changer de chaîne, Espace allume ou éteint.

**Chambre** :
- armoire moderne (ouvre les tenues), tête de lit capitonnée, banc en bout de lit, plaid ;
- commode, grand miroir, rideaux, tableau, climatisation, tapis ;
- **LED d'ambiance réglables**.

Espace informatique de la chambre :
- bureau, fauteuil ergonomique, écran, clavier, souris, enceintes, casque, lampe, tour lumineuse ;
- **ordinateur NOVA OS** : finances personnelles (solde, opérations), « Mes entreprises » (effectif et masse salariale de NOVA BOOK par département ; la gestion complète arrive avec la mission 014, étape 2), décoration.

Espace jeux de la chambre :
- télévision murale, meuble avec LED, **console de salon NOVA X** (nom fictif, à la place d'une marque réelle), manette, boîtiers de jeux, fauteuil gaming ;
- **2 jeux jouables** : *Zem Rush* (esquiver les voitures en zem) et *Penalty Cotonou* (viser et tirer, 5 tirs) ;
- l'image s'affiche aussi sur la télévision de la chambre, avec les records ;
- commandes : flèches et Espace, ou boutons tactiles sur iPhone.

**Personnalisation** (ordinateur ou E près de la bibliothèque du salon) :
- couleurs du canapé et des fauteuils, du mur d'accent, des rideaux, des façades de cuisine ;
- LED du salon et de la chambre (ou éteintes) ;
- tous les choix et les records sont **sauvegardés**.

Testé :
- les 13 points d'interaction des pièces ;
- placards, micro-ondes avec une assiette réelle, ordinateur, décoration ;
- les deux jeux ;
- sauvegarde et rechargement ;
- parcours au toucher sur iPhone.

Aucune erreur détectée.

## 🚦 Mission 015, phase 1 : Cotonou vivante, zone de test (v2.2)

Comme demandé, le système est d'abord testé **à Cotonou** avant d'être étendu aux autres villes. Les piétons et la circulation existants sont conservés et enrichis. Code : `src/population.js`, `src/pedestrians.js`, `src/vehicles.js`. Tout est procédural (coût : 0).

**Habitants** (réserve de 64 passants sur ordinateur, 36 sur iPhone) :

| Profil | Particularités |
|---|---|
| Habitants, jeunes | téléphone pour certains |
| Personnes âgées | démarche lente et penchée, canne ; boubou ou foulard |
| Élèves | tenue kaki, cartable |
| Étudiants | sac à dos |
| Employés de bureau | chemise claire, mallette |
| Commerçantes | bassine sur la tête |
| Travailleurs | tenue orange |
| Parents | accompagnés d'un enfant |

**Comportements** :
- marcher sur les trottoirs et traverser aux passages piétons en attendant le feu (déjà présent) ;
- s'arrêter devant les vitrines ;
- **entrer dans les boutiques et en ressortir** ;
- **téléphoner en marchant** ;
- **discuter à deux** en se faisant face, avec des gestes ;
- attendre aux arrêts, monter dans le bus et en descendre.

**Circulation (52 véhicules)** :
- zems, voitures, tokpa-tokpa, et nouveaux véhicules : **6 taxis** (jaunes, panneau TAXI), **3 bus** (« LIGNE 1 • DANTOKPA »), **3 camions**, **4 camionnettes de livraison**.
- Les conducteurs gardent l'IA existante (voies, feux, priorités, rond-point, distances de sécurité, piétons). En plus :
  - prise en compte de la longueur des bus et des camions pour les distances ;
  - ralentissements aux **heures de pointe** autour du marché Dantokpa et sur les grands axes ;
  - **klaxons** dans les bouchons près du joueur.

**Ligne de bus** :
- 14 arrêts au total : arrêts « BUS • LIGNE 1 » ajoutés automatiquement sur le trottoir des boucles empruntées par les bus (poteau, banc, voyageurs), plus les abribus existants ;
- les bus et les tokpa-tokpa marquent l'arrêt (6 s et 4 s) ;
- des voyageurs montent et disparaissent dans le véhicule, d'autres descendent et repartent à pied.

**Densité selon l'heure** :

| Heure | Passants actifs | Véhicules actifs |
|---|---|---|
| 4 h | 12 | 9 |
| Pointe de 7 h 30 | 64 | 52 |
| Midi | 57 | 44 |
| Pointe de 18 h | 64 | 52 |
| 23 h | 19 | 15 |

**Réglage dans les Options** : « Population et circulation : Faible / Moyenne / Élevée » (Moyenne par défaut sur iPhone, Élevée sur ordinateur), sauvegardé avec les paramètres.

**Optimisation** :
- *pooling* : les passants et véhicules en trop sont mis en réserve loin du joueur, puis réapparaissent hors de sa vue, sur une portion libre ;
- animations réduites au loin, personnages cachés au-delà de 90 à 110 m.

**Parler aux habitants (E)** :
- discuter, avec des expressions du français de Cotonou (« Bonne arrivée ! », « On dit quoi ? », « Doucement doucement… ») ;
- **demander son chemin** : distance et direction de 9 lieux du jeu, avec le conseil de prendre un zem si c'est loin ;
- **infos sur le quartier** ;
- **acheter des fruits aux commerçantes** : payés en FCFA, rangés dans le sac.

**Son** : un brouhaha de foule proportionnel au nombre de passants proches, en plus de celui du marché et des klaxons.

Testé :
- simulation accélérée à 5 heures de la journée ;
- 2 rapprochements brefs sur 3 739 contrôles entre véhicules ;
- 8 montées et 4 descentes aux arrêts ;
- 7 entrées en boutique et des conversations ;
- dialogue avec un passant ;
- aucune erreur ;
- iPhone (densité moyenne) : 279 appels de dessin à l'heure de pointe.

## 🏘️ Mission 015, phase 2 : habitants et trafic dans toute la région (v2.3)

Code : `src/towns-life.js`. Tout est procédural (coût : 0).

**Habitants à Porto-Novo, Ouidah, Pahou et Cocotomey** :
- un seul groupe de personnages (24 sur ordinateur, 14 sur iPhone) est réutilisé pour la ville la plus proche du joueur, jamais pour toutes les villes à la fois ;
- les habitants marchent dans les allées entre les pâtés de maisons et font des pauses (aucun passage dans les murs sur 1 890 contrôles) ;
- vendeuses et zems stationnés au bord de la RNIE 1, au centre de chaque ville ;
- densité selon l'heure, le réglage choisi et la ville : Porto-Novo la plus animée, puis Ouidah ;
- on peut leur parler partout : discussion, chemin (les 4 villes sont ajoutées aux destinations), infos sur la ville (Porto-Novo capitale, Ouidah ville d'histoire et Route des Esclaves, etc.).

**Trafic sur la RNIE 1** :
- 16 véhicules sur ordinateur, 9 sur iPhone : voitures, taxis, tokpa-tokpa, camions, camionnettes, pick-up, zems, bus ;
- ils roulent sur la voie de droite, dans les deux sens, autour du joueur, et sont recyclés devant ou derrière lui hors de sa vue ;
- distances de sécurité (au moins 10 m mesurés), ralentissement dans les villes ;
- arrêt devant le joueur, sa voiture et les piétons, avec klaxon s'ils attendent.

## 🗺️ Complément mission 015 : carte complète, entreprises et accès au bureau du PDG (v2.3)

**Carte (C)** : 56 lieux dans un registre (`src/places.js`).
- Chaque lieu a : nom, icône, catégorie, adresse dans le jeu, marqueur, et une fiche avec un **statut clair** :
  - 🟢 lieu réel à sa position OpenStreetMap : les 4 villes de la région ;
  - 🟡 lieu réel représenté de façon stylisée : marché Dantokpa, places des Martyrs et de l'Amazone, plage, aéroport, noms des quartiers de Cotonou ;
  - 🟠 lieu fictif : maison, NOVA BOOK, LAGUNA, AUTO CONCEPT, banque, hôtel, centre d'affaires, boutiques et maquis des enseignes.
- **Absents de la carte** : stations-service et port, car ils n'existent pas encore dans le jeu.
- Recherche par nom, 11 filtres de catégories, liste triée (NOVA BOOK en tête).
- Touche un marqueur ou une ligne pour afficher la fiche du lieu.
- **Itinéraire** sur le réseau routier, jusqu'aux autres villes. Il est tracé en jaune sur la carte et la mini-carte ; la distance restante s'affiche ; « Arrivé » à destination.
- **Découvertes** : les lieux approchés sont marqués ✓.
- Les découvertes et l'itinéraire en cours sont **sauvegardés**.

**Entreprises** :
- **NOVA BOOK** a une icône spéciale « NB » dorée.
- NOVA DIGITAL, MEDIA, IMMOBILIER, TRANSPORT et DISTRIBUTION sont placées sur des immeubles de bureaux existants. Elles sont indiquées « société pas encore créée — locaux réservés », car la création des sociétés arrive avec la mission 014.

**Entrée principale de NOVA BOOK** :
- allée piétonne en pierre avec bandes jaunes de guidage, 6 bornes lumineuses, appliques, lampadaires ;
- totem « NOVA BOOK • Accueil → • Parking → », bandeau « ENTRÉE PRINCIPALE » au-dessus des portes automatiques ;
- **barrière de parking** qui se lève à l'approche de la voiture du joueur ;
- éclairage plus fort la nuit ;
- le mobilier urbain ne bloque plus l'entrée.

**Parcours jusqu'au bureau du PDG** (le bureau reste au 5e étage, à la Direction) :
1. La rue, puis la porte principale.
2. Le hall, avec **la réceptionniste qui indique le chemin** et un panneau « ASCENSEURS → • Bureau du PDG : 5e étage ».
3. Un **couloir dégagé** jusqu'aux ascenseurs et escaliers : la salle de réunion du rez-de-chaussée et la salle serveurs du 3e ont été raccourcies, car elles bloquaient l'accès.
4. L'ascenseur jusqu'au 5e étage.
5. La **porte « BUREAU DU PDG »** :
   - battant en bois avec poignée animée et plaques « BUREAU DU PDG — PDG — NOVA BOOK — Accès réservé » des deux côtés ;
   - **E pour ouvrir ou fermer**, de l'extérieur comme de l'intérieur, avec un son discret ;
   - fermée, elle bloque le passage ;
   - **refermeture automatique** quand le PDG s'éloigne.

Testé :
- le parcours entier, à pied avec les collisions : rue → porte → hall → réceptionniste → couloir → ascenseur → 5e étage → porte fermée (bloquée) → ouverte → bureau → refermeture automatique → sortie ;
- l'itinéraire de Ouidah à NOVA BOOK (8,6 km par la route) ;
- la recherche ;
- la sauvegarde après rechargement ;
- la carte sur iPhone ;
- aucune erreur.

## 💼 Mission 014, étape 2 : NOVA Gestion, le logiciel du PDG (v2.4)

On l'ouvre en s'asseyant **au bureau du PDG** (5e étage), ou depuis l'ordinateur de la maison (onglet « Mes entreprises » → « Ouvrir NOVA Gestion »). Code : `src/company.js`, `src/biz-ui.js`. Tout est procédural (coût : 0).

**Réglages appliqués** (proposés et non contestés) :
- **1 mois de jeu = 7 jours de jeu** (environ 2 h 20 de jeu réel) ;
- **capital de départ de 3 000 000 FCFA** sur le compte de l'entreprise, séparé du compte personnel ;
- charges fixes de 400 000 FCFA par mois (électricité, internet, entretien).

**Les 10 rubriques** :

| Rubrique | Contenu |
|---|---|
| Tableau de bord | trésorerie, chiffre d'affaires, dépenses, salaires, bénéfice net du mois, masse salariale, commandes en cours, alertes |
| Mes entreprises | NOVA BOOK et les 5 autres sociétés, indiquées « pas encore créées » (étape 4) |
| Employés | 26 employés de départ avec nom fictif, métier, département, étage, salaire, compétence, expérience, échelon, moral, productivité, état ; **former** (150 000 FCFA, 1 jour, +10 de compétence), **promouvoir** (+15 % de salaire, 3 échelons), **licencier** (indemnité d'un mois, avec confirmation) |
| Recrutement | 6 candidats renouvelés chaque mois, nouvelle annonce à 50 000 FCFA ; les recrues prennent un poste libre de leur étage et **apparaissent dans l'immeuble** |
| Salaires | à chaque fin de mois : notification, liste des employés et salaires individuels, total, **validation par le PDG** (paiement automatique seulement si tu l'actives) ; tant que ce n'est pas payé, le moral baisse chaque jour |
| Commandes | 11 prestations (romans, manuels scolaires, livres éducatifs, mise en page, couvertures, impression de livres et de brochures, affiches, supports publicitaires, vidéos promotionnelles, site de commande), voir ci-dessous |
| Comptabilité | journal comptable, **virements** entre le compte personnel et le compte de l'entreprise (apport du PDG, dividende) |
| Investissements | équipements par département, 3 niveaux, +25 % de production par niveau |
| Immobilier | le siège (propriété de l'entreprise) ; les autres locaux arrivent à l'étape 4 |
| Statistiques | historique mensuel, effectif et production par département |

**Commandes et contrats** :
- chaque commande a un client fictif, un montant, une charge de travail, un délai, un département responsable et un avancement ;
- les équipes travaillent **de 7 h à 19 h** ;
- l'avancement dépend de la compétence, du moral, de l'échelon et de l'équipement ;
- la capacité de chaque département dépend de son effectif ;
- le paiement se fait à la livraison, avec 30 % de moins en cas de retard.

**Alertes financières** : si la trésorerie ne couvre pas la paie, une alerte propose des décisions : apport personnel, livraison des commandes en cours, réduction des effectifs.

**Autres liens** :
- l'écran mural du bureau du PDG affiche la trésorerie, le chiffre d'affaires et les commandes en direct ;
- la salle du conseil ouvre le bilan de la réunion de direction ;
- tout est sauvegardé : trésorerie, employés, candidats, commandes, journal, historique, équipements, paie en attente.

**Testé** (un mois simulé en acceptant toutes les commandes) :
- 13 commandes livrées : la trésorerie passe de 3 M à 11,1 M FCFA ;
- paie de 5,9 M FCFA validée, soit un bénéfice d'environ 2,2 M FCFA par mois ;
- recrutement, licenciement, formation, promotion, alerte de trésorerie ;
- bureau du PDG vers le logiciel, sauvegarde et rechargement ;
- parcours au toucher sur iPhone.

Aucune erreur détectée.

## 🏦 Mission 014, étape 4 : groupe NOVA et banque (v2.5)

Tout se passe dans NOVA Gestion (bureau du PDG ou ordinateur de la maison). Code : `src/group.js`. Coût : 0.

**Mes entreprises** :
- NOVA DIGITAL, NOVA MEDIA, NOVA IMMOBILIER, NOVA TRANSPORT et NOVA DISTRIBUTION peuvent être :
  - **créées** (4,5 à 6 M FCFA : 4 employés débutants, capital de 2 M) ;
  - ou **rachetées** (13 à 16 M FCFA : 8 employés expérimentés, clientèle, trésorerie de 1,5 M) ;
  - et payées par NOVA BOOK ou par le compte personnel.
- Chaque société a **sa trésorerie, ses employés, son directeur, ses locaux, ses équipements, ses recettes et ses charges**.
- Recettes quotidiennes selon la compétence et le moral de l'équipe, la présence d'un directeur, les équipements et une fluctuation du marché.
- Charges mensuelles : salaires (paie automatique activable ou désactivable), loyer de 300 000 FCFA, charges fixes de 150 000 FCFA.
- Gestion de chaque société :
  - recruter selon le métier du secteur (chauffeurs-livreurs, logisticiens, vendeurs, agents immobiliers… nouveaux métiers) ;
  - **nommer un directeur** (+40 % de salaire, production améliorée) et licencier ;
  - investir dans les équipements (+25 % par niveau) ;
  - **acheter les locaux** (9 M FCFA, plus de loyer) ;
  - percevoir les bénéfices par virement.
- Sur la carte, les sociétés actives deviennent « société active » (bureaux non aménagés pour la visite).

**Banque** :
- un compte personnel et un compte par société, avec soldes ;
- **virements** entre tous les comptes ;
- **relevés bancaires** par compte ;
- **prêts facultatifs** (taux du jeu 1,2 % par mois, 12 mensualités prélevées automatiquement, remboursement anticipé possible) ;
- **bilan mensuel du groupe** (CA, charges, résultat, trésorerie par société) ;
- notifications de paiement et alertes de découvert.

L'argent personnel et l'argent des entreprises sont strictement séparés : les seuls passages se font par virement, apport ou dividende.

**Testé** (un mois simulé) :
- création refusée faute de fonds ;
- prêt de 22 M, création de NOVA DIGITAL, rachat de NOVA TRANSPORT avec nomination d'un directeur ;
- résultats du mois : NOVA DIGITAL −140 000 FCFA (débutante), NOVA TRANSPORT +1,2 M FCFA ;
- mensualité du prêt prélevée, bilan, virement vers le compte personnel, relevés ;
- carte mise à jour, sauvegarde et rechargement.

Aucune erreur détectée.

## Mission 016 — phase 1 : 175 aliments, frigo du PDG, toilettes H/F

**Catalogue alimentaire : 175 références distinctes** (62 existantes + 113 nouvelles), classées en 14 catégories :
- plats traditionnels ;
- pâtes et préparations à base de maïs ;
- riz et céréales ;
- ignames et tubercules ;
- haricots et légumineuses ;
- sauces ;
- poissons et fruits de mer ;
- viandes et volailles ;
- fruits locaux ;
- légumes ;
- épices et condiments ;
- pâtisseries et collations ;
- boissons locales (aucun alcool) ;
- produits transformés.

Chaque aliment a un nom, une catégorie, une description, un modèle 3D procédural (icône générée), un prix indicatif en FCFA et une valeur nutritive (faim).

Nouveaux plats vérifiés sur des sources publiques : télibo, dakouin, yêkêyêkê, toubani, piron, adowè, tô, calalou dahoméen, fontêtê, sauces crincrin et assrokouin, dja, aklui, koko, dèguè, lait caillé, yovo doko, atchomon, kuli-kuli, afitin, akara…

Les spécialités non vérifiables ou surtout étrangères n'ont pas été ajoutées.

Renommages : « Wɔ̌ (pâte blanche) », « Poisson braisé », « Haricots préparés ».

**Où les trouver** :
- **Réfrigérateur de la maison** : tous les aliments, avec un filtre « En stock seulement » et 18 nouvelles recettes (télibo, dakouin, yêkêyêkê, toubani, piron, adowè, tô, aklui, koko, akara, atchomon, crincrin, fontêtê, dja…).
- **Supermarché LAGUNA** : 143 aliments en rayon, avec un nouveau **rayon Traiteur** (plats à emporter).
  - Les **stocks sont limités** (rupture affichée) et réapprovisionnés chaque matin.
  - Les stocks sont sauvegardés.
- **Téléphone** :
  - « Courses à domicile » propose les 175 produits, classés par catégorie ;
  - la nouvelle app **« Cuisine du Bénin »** est un catalogue avec descriptions.
- **Marché Dantokpa** : les vendeurs existants (60 vendeurs prévus en phase 2).

**Réfrigérateur du bureau du PDG** (5e étage de NOVA BOOK) :
- un frigo vitré dont la porte s'ouvre et se ferme avec une lumière intérieure ;
- 16 boissons et en-cas : eau, jus, bissap, gingembre, baobab, eau de coco, yaourt, noix de cajou, kuli-kuli… ;
- actions possibles : consulter, boire ou manger, emporter dans le sac ;
- **réapprovisionnement** :
  - une confirmation est demandée avant de payer ;
  - le compte débité est au choix : compte personnel ou trésorerie NOVA BOOK (passée en frais dans la comptabilité) ;
  - le solde est vérifié et le double paiement est bloqué ;
  - tout se fait uniquement en monnaie virtuelle.

**Toilettes Hommes / Femmes à chacun des 6 niveaux** de NOVA BOOK (l'ancien bloc mixte non accessible a été remplacé) :
- deux salles séparées, chacune avec une porte battante, une plaque et un pictogramme, et une fermeture automatique ;
- un panneau « TOILETTES H • F » dans le couloir ;
- 2 lavabos, du savon, un miroir, un essuie-mains, une poubelle, une grille de ventilation et un éclairage à détection de présence ;
- 2 cabines avec WC, papier et porte animée ;
- côté Hommes : urinoirs ; côté Femmes : poubelles sanitaires et une table à langer ;
- des murs opaques côté façade vitrée.

Actions :
- se laver les mains (propreté +8) ;
- utiliser une cabine (la porte se ferme, puis la chasse d'eau) ;
- un rappel s'affiche si tu sors sans te laver les mains.

**Testé** :
- les 175 identifiants et noms sont uniques ;
- toutes les recettes pointent vers des aliments existants ;
- recette du télibo ;
- commande livrée ;
- rupture puis réassort chez LAGUNA ;
- portes, lavabo et cabine des toilettes (étages 2 et 3) ;
- frigo du PDG : boire, puis réassort payé une seule fois malgré deux clics ;
- sauvegarde et rechargement ;
- test de fumée sur PC et affichage sur iPhone.

Aucune erreur détectée.

## Mission 016 — phase 2 : marché Dantokpa, 60 vendeurs

**60 vendeuses et vendeurs** (personnes fictives, noms uniques) répartis en **12 allées** :
- céréales & farines (5) ;
- ignames & tubercules (4) ;
- légumes & feuilles (6) ;
- fruits (6) ;
- poissons & fruits de mer (5) ;
- viandes & volailles (5) ;
- épices & condiments (5) ;
- plats cuisinés & en-cas (7) ;
- boissons (4) ;
- tissus, vêtements & chaussures (6) ;
- artisanat & bijoux (4) ;
- ménage, ustensiles & divers (3).

Les 12 vendeurs existants sont conservés (mêmes noms et spécialités, gamme élargie).

Contenu :
- **166 des 175 aliments** sont vendus au marché ; les 9 autres sont des produits de supermarché (soda, lait UHT, conserves…).
- **24 nouveaux articles** : boubou, fripes, chaussures, bijoux en laiton, tableaux, tambour, marmite, mortier et pilon, natte, chargeur, cahiers…
- Chaque étal a un vendeur visible, du même sexe que sur son étiquette, affiché seulement à moins de 42 m pour préserver les performances.

**Nouveautés** :
- **stock limité par étal** : « Épuisé » quand il n'y en a plus, réassort chaque matin, stocks sauvegardés ;
- **clients fidèles** : 1 % de remise par achat chez le même vendeur (jusqu'à 8 %) et un accueil personnalisé ;
- prix stables dans la journée : la remise de fidélité fait réellement baisser le prix ;
- protection contre le double clic à l'achat ;
- négociation inchangée ;
- **application téléphone « Marché Dantokpa »** : répertoire par allée et bouton « Y aller » qui trace l'itinéraire jusqu'à l'étal.

**Testé** :
- 60 étals à des emplacements distincts, avec 60 vendeurs visibles ;
- achat de tout un stock, puis « Épuisé », puis réassort le lendemain ;
- baisse de prix avec la fidélité (2 450 → 2 375 FCFA) ;
- double clic débité une seule fois ;
- répertoire et itinéraire ;
- sauvegarde et rechargement ;
- test de fumée sur PC et affichage sur iPhone.

Aucune erreur détectée. Mémoire : 322 Mo (contre 286 Mo avant, à cause des vendeurs supplémentaires).

## Mission 016 — phase 3 : lieux de vie dans les 5 villes et carburant

**35 établissements** : 7 types dans chacune des 5 villes (Cotonou, Porto-Novo, Ouidah, Pahou, Cocotomey). Tous sont **fictifs** et signalés comme tels sur la carte (aucun partenariat). Ils ont leurs horaires, une enseigne et un point sur la carte.

| Type | Ce qu'on peut y faire |
|---|---|
| 🍲 Restaurant (7 h–23 h) | Carte d'assiettes propre à chaque ville (pâte rouge, amiwo, igname pilée sauce graine, télibo, dakouin, yêkêyêkê…) ; manger sur place ou emporter |
| 🥤 Bar **sans alcool** (9 h–24 h) | 13 boissons (bissap, gingembre, baobab, jus, eau de coco, thé, café, dèguè…) ; boire sur place ou emporter |
| 🐟 Poissonnerie (6 h–19 h) | Poissons et crustacés selon la ville (mer ou lagune) |
| 🛒 Mini-marché (7 h–22 h) | 21 produits de base, prix fixes |
| 🏦 Banque (8 h–17 h) | Soldes de tous les comptes, dernières opérations, accès à l'espace bancaire (virements, prêts, relevés) |
| 🏨 Hôtel (24 h/24) | Repos 2 h, nuit standard ou confort (dormir jusqu'à 7 h), douche |
| ⛽ Station-service (24 h/24) | Sur la RNIE 1 à l'entrée de chaque ville : auvent, 2 îlots de pompes, boutique, totem des prix |

À Cotonou, les enseignes fictives qui existaient déjà sont réutilisées : MAQUIS LE BON GOÛT, ALIMENTATION DIEU MERCI, BANQUE LAGUNE, HÔTEL OCÉAN BLEU, ainsi que deux paillotes de la plage. Dans les autres villes, des maisons-boutiques du centre reçoivent une enseigne et un auvent.

Les stocks sont limités, réapprovisionnés chaque matin et sauvegardés.

**Carburant** (voiture personnelle et véhicules achetés au garage ; avions et taxis exclus) :
- réservoir de 50 L (moto : 12 L), consommation de 0,9 L/km à l'échelle du jeu, soit environ 55 km d'autonomie ;
- jauge à l'écran pendant la conduite ;
- alerte de réserve sous 15 %, avec la station la plus proche ;
- **panne sèche** : on ne peut plus accélérer (le frein fonctionne) ;
- à la station : se garer près des pompes, descendre, puis choisir **le plein** ou **5 000 FCFA** ;
  - la quantité et le prix sont confirmés avant le paiement (prix du jeu : 680 FCFA/L) ;
  - le paiement se fait depuis le compte personnel ;
  - les doublons sont bloqués.

**Testé** :
- 35 lieux (7 types dans chaque ville), 5 stations, points d'accès non bloqués, 35 points sur la carte sans doublon ;
- restaurant (sur place et à emporter), bar, banque (fermée à 20 h) ;
- hôtel : nuit de 22 h à 7 h, énergie et propreté à 100 % ;
- 30 km de conduite = 27 L consommés ; panne sèche ; plein de 5 000 FCFA (7,35 L) puis plein complet ;
- double clic bloqué ; sauvegarde et rechargement ;
- test de fumée sur PC et affichage sur iPhone.

Aucune erreur détectée.

## Mission 016 — phase 4 : contacts, appels, messages et virements

Le téléphone (touche N) a 4 nouvelles applications.

**📇 Contacts**, en 3 onglets :
- **employés** : tous les employés de NOVA BOOK et des sociétés du groupe, avec poste et société ;
- **commerçants** : les vendeurs du marché Dantokpa chez qui tu as déjà acheté ;
- **services** : garage AUTO CONCEPT, supermarché LAGUNA, BANQUE LAGUNE.

Toutes les personnes et entreprises sont fictives. Aucun numéro n'est affiché, pour ne pas reproduire un vrai numéro par hasard.

**📞 Appels** :
- sonnerie, puis réponse ou messagerie selon l'heure (employés surtout pendant les heures de travail, vendeurs pendant l'ouverture du marché) ;
- dialogues :
  - employés : « faire le point », qui reprend leur vraie situation (commande en cours avec son avancement, formation, absence, moral) ; « féliciter » (moral +3, une fois par jour) ;
  - vendeurs : prix du jour ;
  - banque : solde ;
- journal d'appels avec durée et bouton « Rappeler » ; fermer le téléphone raccroche.

**💬 Messages** :
- conversations sauvegardées et compteur de non-lus ;
- réponses rapides, auxquelles le contact répond après quelques secondes ;
- chaque matin vers 9 h, un employé écrit au PDG : salut, rappel de paie à verser, nouvelles demandes de clients, ou demande d'entretien si son moral est bas.

**💸 Virements aux employés** (monnaie virtuelle du jeu uniquement) :
- montant (5 000 à 100 000 FCFA, ajustable, maximum 2 000 000) et motif (prime, avance sur salaire, remboursement de frais, cadeau) ;
- compte à débiter : compte personnel, NOVA BOOK ou une société du groupe ;
- **vérification du solde**, puis un **écran de confirmation** obligatoire (bénéficiaire, montant, compte, solde après) ;
- **anti-doublon** : chaque confirmation a un jeton à usage unique, et un virement identique vers la même personne est bloqué pendant 10 s ;
- **chaque opération est enregistrée** : relevé du compte débité, historique des virements, message dans la conversation ;
- une prime ou un cadeau améliore le moral de l'employé.

Correction : sur iPhone, le compteur de vitesse ne chevauche plus le message d'action.

**Testé** :
- 26 employés, 1 vendeur et 3 services en contacts ;
- message avec réponse contextuelle ; appel décroché, point de travail, félicitations limitées à une fois par jour ;
- virement refusé (solde insuffisant) ; virement de 25 000 FCFA débité une seule fois malgré un double clic et la réutilisation du jeton ;
- même virement relancé tout de suite : bloqué ;
- virement depuis NOVA BOOK inscrit dans sa comptabilité ;
- message du matin ; sauvegarde et rechargement ;
- test de fumée sur PC et affichage sur iPhone.

Aucune erreur détectée.

## Mission 016 — phase 5 : sociétés visitables, LED, projets du PDG (et compléments)

**Sièges visitables des 5 sociétés du groupe** (NOVA DIGITAL, MEDIA, IMMOBILIER, TRANSPORT, DISTRIBUTION) :
- sur l'immeuble réservé à chaque société : enseigne lumineuse avec cadre LED et porte vitrée, placées sur la façade la plus dégagée ;
- l'entrée n'ouvre que si la société a été créée ou rachetée ;
- intérieur aménagé :
  - réception avec hôtesse, mur du logo avec LED, espace d'attente ;
  - 8 postes de travail occupés par les vrais employés de la société ;
  - bureau vitré du directeur (assis s'il est nommé) ;
  - salle de réunion, tableau de bord en direct ;
- équipements du métier : salle serveurs (DIGITAL), studio fond vert (MEDIA), maquettes (IMMOBILIER), écran de suivi (TRANSPORT), entrepôt (DISTRIBUTION) ;
- actions : accueil, tableau de bord (NOVA Gestion), superviser l'équipe (moral +2 par jour), point d'équipe, parler au directeur, équipements ;
- aspects techniques : intérieur placé en hauteur avec collisions isolées, caméra recalée à l'entrée et à la sortie, vue en coupe.

**Décoration LED** (application « 💡 Décoration LED » du téléphone) :
- **maison** : derrière la télévision, LED murales du salon, plafonds (éclairage indirect), chambre, bureau informatique, cuisine ;
- **entreprises** : hall de NOVA BOOK, couloirs des 6 niveaux, salles de réunion, espaces de travail, bureau du PDG, enseignes NOVA, sociétés du groupe ;
- 5 styles (blanc chaud, blanc froid, bleu, violet, RGB avec 8 couleurs), intensité de 10 à 100 %, extinction, réglages sauvegardés.

**Projets du PDG** (onglet « 🗂️ Projets » de NOVA Gestion : bureau du PDG ou ordinateur de la maison) :
- 10 types : livre, roman, manuel scolaire, couverture, mise en page, affiche, développement informatique, vidéo, communication, impression ;
- chaque projet a un nom, une description, un département, un budget (débité de NOVA BOOK), un délai, un revenu prévu, des étapes et un état (en attente, en cours, terminé, livré) ;
- équipe de 4 personnes au maximum, et un employé ne travaille que sur un projet à la fois ; l'avancement est horaire, selon la productivité réelle ;
- le PDG peut travailler lui-même (+15 %, 30 min, énergie −3) ;
- validation de chaque étape, puis livraison : le revenu est versé à NOVA BOOK, −30 % en cas de retard ;
- raccourci vers le recrutement ; plusieurs projets peuvent avancer en même temps.

**Compléments du téléphone** :
- recherche par nom ;
- onglets Clients & partenaires et Personnels (fictifs) ;
- messages libres ;
- appels entrants (accepter ou refuser) ;
- consignes aux directeurs, avec un effet réel sur la production, le moral et les frais.

**Complément du marché** : 69 vendeurs (8 poissons, 8 viandes, 8 vêtements, 6 épices, conformément à la répartition demandée).

**Correction** : le texte de version de l'écran d'accueil, abîmé depuis la v2.8, est réécrit.

**Testé** :
- sociétés : 5 entrées, aucune bloquée ; entrée refusée tant que la société n'existe pas ; visites avec employés et directeur ; supervision ; sortie ;
- projet : budget, équipe, employé déjà occupé refusé, avancement, travail du PDG, validations, livraison de 450 000 FCFA ;
- LED : RGB, intensité, extinction ;
- téléphone : recherche, consigne, message libre, appel entrant accepté puis refusé ;
- sauvegarde et rechargement ;
- test de fumée sur PC et affichage sur iPhone.

Aucune erreur détectée.

## Mission 016 — phase 6 : garde-robe de 200 vêtements et vérification finale

**200 vêtements et accessoires distincts**, selon la répartition demandée :

| Catégorie | Nombre |
|---|---|
| Chemises & polos | 30 |
| Pantalons | 25 |
| Jeans | 20 |
| T-shirts | 20 |
| Vestes & blazers | 15 |
| Ensembles professionnels | 15 |
| Tenues traditionnelles béninoises | 15 |
| Tenues décontractées | 15 |
| Tenues sportives | 15 |
| Chaussures | 10 |
| Accessoires | 10 |
| Tenues spéciales | 10 |

Chaque vêtement a un nom, une catégorie, une couleur ou un motif wax (8 motifs), et est **réellement visible sur le personnage**. Aucune apparence n'est en double (vérifié automatiquement). La géométrie du personnage gère :
- manches longues ou débardeur, col, veste ouverte, cravate, bande de maillot ;
- grand boubou, pagne et foulard ;
- casquette, chapeau de paille, bonnet traditionnel (fila), toque ;
- lunettes, montre, collier, sac à dos, semelles de baskets.

Le personnage reste un seul maillage et un seul matériau (1 appel de rendu). Les personnages non joueurs ne sont pas modifiés.

**Garde-robe** (armoires de la chambre et du dressing, et nouveau point « Se changer devant le miroir » dans la chambre) :
- 12 onglets, plus « ⭐ Favoris » et « Tenues de base » (les 12 tenues d'origine sont conservées) ;
- **essayage en direct** en vue miroir : la caméra se place face au personnage, à côté du panneau ;
- **combinaisons** : haut, bas, veste, chaussures et jusqu'à 3 accessoires ; une tenue complète remplace haut, bas et veste ;
- **ensembles favoris** : jusqu'à 12, sans doublon, à porter ou supprimer (avec confirmation) ;
- **Valider** enregistre la tenue, **Annuler** revient à la tenue précédente.
- La tenue et les favoris sont sauvegardés.

**Vérification finale** :
- état complet du jeu sauvegardé puis rechargé, sans aucune différence : comptes, sociétés, consignes, prêt, virements, messages, appels, réfrigérateurs, stocks des commerces, fidélité au marché, carburant, garde-robe et favoris, LED, projets ;
- taille de la sauvegarde : environ 28 Ko ;
- test de fumée sans erreur ; mémoire du test de fumée : 322 Mo (rendu logiciel) ; tests sur iPhone (paysage) sans erreur.

Aucune erreur détectée.

## Mission 014 — étape 5 : vie quotidienne du PDG

Ce qui existait déjà de la section 9 : se rendre à NOVA BOOK en véhicule, entrer, saluer les employés, visiter les étages, observer les équipes, réunions, ordinateur, décisions, résultats, recrutement.

**Clients et partenaires reçus en personne** :
- La plupart des jours (7 sur 10), un visiteur fictif arrive entre 9 h et 16 h et attend à l'accueil de NOVA BOOK (rez-de-chaussée) ; la réceptionniste prévient le PDG par message.
- **Client** : il apporte une commande payée 15 % de plus qu'une demande ordinaire. On peut :
  - signer le contrat (réputation +2) ;
  - négocier +10 % (60 % de chances ; sinon le client repart et la réputation baisse de 1) ;
  - refuser poliment.
- **Partenaire** (librairie, fournisseur de papier ou agence de communication, tous fictifs) : partenariat payant avec un effet réel :
  - 2 nouvelles demandes de clients et réputation +3 ;
  - impression +20 % pendant 7 jours ;
  - prix des commandes +10 % pendant 7 jours.
- Un visiteur non reçu avant 18 h repart, et la réputation baisse de 2.

**Événements professionnels** (onglet « 🎯 Objectifs & événements » de NOVA Gestion) — 10 situations avec des décisions aux effets réels :
- presse en panne (réparer pour 250 000 FCFA, ou impression −50 % pendant 2 jours) ;
- coupure d'électricité ;
- salon du livre (fictif) ;
- demande d'augmentation (+10 % de salaire et moral +15, ou moral −12) ;
- commande urgente (+40 %, livrée en 2 jours) ;
- article de presse élogieux ;
- pénurie de papier ;
- formation groupée (compétence +5 pour 3 employés) ;
- candidature remarquable (compétence 88) ;
- client mécontent.

Sans réponse au bout de 2 jours, la décision par défaut s'applique. Les effets en cours sont affichés avec leur date de fin.

**Réputation** de NOVA BOOK (0 à 100, 50 au départ) : elle modifie le prix des nouvelles commandes, de −10 % à +10 %.

**10 objectifs de développement**, avec barre de progression et prime versée à NOVA BOOK (une seule fois) :
- livrer 5 commandes ;
- recevoir 3 visiteurs ;
- 15 M FCFA de trésorerie ;
- 35 employés ;
- un département équipé au niveau 3 ;
- 2e société du groupe ;
- livrer un projet personnel ;
- réputation de 75 ;
- 8 M FCFA de chiffre d'affaires dans un mois ;
- posséder les 6 sociétés.

**Testé** :
- visite d'un client : message, visiteur à l'accueil, contrat signé ;
- partenariat payé avec son effet ;
- événements : panne, augmentation, salon, candidat, décision automatique au bout de 2 jours ;
- objectif non atteint impossible à encaisser, pas de double encaissement ;
- visiteur reparti sans être reçu ;
- sauvegarde et rechargement ; test de fumée.

Aucune erreur détectée.

## Mission 016 — compléments : restaurants, hôtels et banques visitables, animation des vendeurs

**Intérieurs visitables** dans les 5 villes. On entre par la porte de l'établissement ; l'intérieur est construit à l'entrée (un seul à la fois, collisions isolées) et respecte les horaires d'ouverture.
- **Restaurants** :
  - salle avec 6 tables et leurs chaises, comptoir, marmites, tableau « menu du jour » ;
  - un cuisinier avec sa toque, un serveur, des clients attablés ;
  - le joueur **s'assoit à une table** (E pour se lever) et commande « Manger ici » ; **le serveur traverse la salle et apporte l'assiette**, dont le modèle 3D apparaît sur la table ;
  - le comptoir permet aussi de commander à emporter.
- **Hôtels** :
  - réception avec hôtesse et tableau à clés, salon (espace commun), coin restaurant servi par un serveur (carte du restaurant de la ville) ;
  - **chambre n° 12** : lit, chevets, télévision, armoire, salle d'eau ;
  - la réservation à la réception remet une **clé** (repos, nuit standard, nuit confort ou douche) ; sans clé, la porte reste fermée ;
  - au lit : repos de 2 h ou nuit jusqu'à 7 h ; salle d'eau : propreté 100 %.
- **Banques** (BANQUE LAGUNE, fictive) :
  - 2 **guichets** avec employés derrière une vitre, 2 **distributeurs**, chaises d'attente, agent d'accueil ;
  - nouveau **compte de dépôt personnel**, avec **dépôts et retraits** en monnaie du jeu (5 000 à 100 000 FCFA) ;
  - confirmation obligatoire, solde vérifié, **jeton à usage unique** contre les doubles opérations, historique enregistré ;
  - le guichet donne aussi accès aux comptes et à l'espace bancaire.

**Animation de vente des 69 vendeurs de Dantokpa** :
- ils appellent les passants et rangent leurs marchandises ;
- ils se tournent vers le joueur qui s'approche et le saluent ;
- **ils tendent l'article à chaque vente**.

**Testé** :
- restaurant : entrée, table, commande, assiette apportée par le serveur, se lever ;
- hôtel : porte fermée sans clé, réservation confort, ouverture, nuit de 22 h à 7 h (énergie et propreté à 100 %) ;
- banque : dépôt de 25 000 FCFA débité une seule fois, retrait au distributeur, retrait supérieur au solde impossible ;
- vendeur : geste de remise après une vente ;
- sortie : retour au niveau du sol ; sauvegarde et rechargement ; test de fumée.

Aucune erreur détectée.

## Mission 012 — étape 3 : hélicoptères et héliport

**8 hélicoptères** (noms fictifs inspirés de catégories d'appareils réels, versions civiles, dimensions approximatives) :

| Hélicoptère | Type | Rotor | Places |
|---|---|---|---|
| Aerion H125 | léger polyvalent | 3 pales | 6 |
| Aerion H145 | bimoteur médical, rotor de queue caréné | 4 pales | 10 |
| Belle 407 | d'affaires | 4 pales | 7 |
| Belle 429 | bimoteur, sur roues | 4 pales | 8 |
| Robison R44 | petit appareil à pistons | 2 pales | 4 |
| Sikora S-76 | transport offshore | 4 pales | 12 |
| Chinouk CH-47 | gros porteur à **rotors en tandem** | 2 × 3 pales | 33 |
| Hawkline UH-60 | utilitaire de sauvetage | 4 pales | 11 |

Les modèles 3D sont procéduraux : cabine, verrière, poutre de queue, dérive, patins ou roues, feux de navigation, **rotor principal et rotor de queue animés**, avec un disque flou à plein régime.

**Pilotage** (simplifié) :
- **G** démarre ou coupe le moteur ; le rotor monte en régime en quelques secondes et on ne peut pas décoller avant le plein régime ;
- **Maj** monte, **Espace** descend ;
- **Z/W** avance, **S** recule, **Q-D (A-D)** tourne, **flèches ←/→** translation latérale ;
- **décollage et atterrissage verticaux**, avec descente amortie près du sol ;
- atterrissage trop rapide, amerrissage ou collision avec un bâtiment : retour à l'héliport ;
- moteur coupé en vol : autorotation ;
- **V** vue cockpit ; le tableau de bord de vol est réutilisé (régime du rotor, état du moteur) ;
- son de rotor (battement des pales et sifflement de la turbine) ;
- **E** pour descendre une fois posé (le moteur se coupe).

**Héliport** à l'aéroport : 8 aires numérotées (cercle, H, balisage lumineux) et un comptoir 🚁 à côté du comptoir des vols, avec un menu de choix.

**Hélisurfaces** de destination, placées automatiquement sur des emplacements vérifiés libres (aucun obstacle dans un rayon de 9 m, pas d'eau) : NOVA BOOK, plage de Cotonou, Ouidah, Porto-Novo.

**Vols de passagers fictifs** :
- choix de la destination au comptoir ;
- 2 à 5 passagers embarquent et l'itinéraire s'affiche sur la carte ;
- un atterrissage au centre de l'hélisurface rapporte une rémunération en FCFA (monnaie du jeu), selon la distance et le nombre de passagers.

**Correction** : la détection de collision des avions (et des hélicoptères) ignore désormais les intérieurs placés en hauteur (sociétés, restaurants, hôtels, banques), qui pouvaient provoquer de faux accidents en vol à basse altitude.

**Testé** :
- comptoir, choix, embarquement ;
- démarrage du moteur et décollage impossible avant le plein régime ;
- montée à 44 m, vol de 1,5 km jusqu'à NOVA BOOK, atterrissage, **26 000 FCFA encaissés** ;
- atterrissage trop rapide : retour à l'héliport ;
- coupure du moteur et sortie ; sauvegarde des positions ; test de fumée.

Aucune erreur détectée.

## Mission 012 — étape 4 : port maritime et 10 bateaux

**Port de Cotonou** : représentation stylisée à l'est de la ville du jeu, sans position géographique exacte, signalée comme telle sur la carte.
- terre-plein et bord de quai le long du rivage ;
- **3 jetées praticables** (deux de 420 m pour les paquebots, une de 150 m pour la marina) avec bittes d'amarrage, lampadaires, bordures et garde-corps ;
- **gare maritime**, **capitainerie** (choix des bateaux), entrepôt, **grues portiques**, piles de conteneurs ;
- 2 entrées sur la carte (port, capitainerie).

**10 bateaux** (noms fictifs inspirés de catégories de navires réels, dimensions approximatives) :

| Bateau | Type | Longueur |
|---|---|---|
| Symphonie des Mers | grand navire de croisière | 362 m |
| Merveille des Mers | navire de croisière | 362 m |
| Euromonde | navire de croisière | 333 m |
| Reine Marine 2 | paquebot transatlantique | 345 m |
| Perle du Golfe | yacht de luxe | 80 m |
| Flèche d'Ouidah | yacht sportif | 24 m |
| Espoir de la Lagune | bateau de pêche | 18 m |
| Éclair | vedette rapide | 10 m |
| Navette de la Lagune | transport de passagers | 22 m |
| Ferry du Golfe | ferry (passagers et véhicules) | 120 m |

Les modèles 3D sont procéduraux, chacun avec son allure :
- paquebots : ponts en gradins, rangées de fenêtres éclairées, passerelle de commandement, cheminée, canots orange, piscine, toboggans ;
- ferry : rampe arrière ;
- bateau de pêche : mât, filets et flotteurs ;
- vedette : moteur hors-bord ;
- tous : feux de navigation.

**Navigation** :
- accélérer, ralentir (Espace), marche arrière, tourner, s'arrêter ; chaque bateau a sa vitesse et sa maniabilité ;
- **houle** (pilonnement, tangage, roulis), **sillage** d'écume, **vagues animées** près des côtes ;
- son du moteur (diesel, ou V8 pour les bateaux rapides) et **corne** (K, grave pour les grands navires) ;
- le bateau s'arrête devant le rivage et les jetées ;
- **débarquement** (E) seulement près d'un quai, d'une jetée ou du rivage ; près de son poste, le bateau se range à quai ;
- capitainerie : « Ramener à son poste d'amarrage ».

**Grands navires visitables** (paquebots et ferry) — on monte par la passerelle d'embarquement depuis la jetée, ou depuis la barre avec **B** une fois le navire arrêté, même en mer :
- **pont piscine** (piscine, transats, toboggans, baigneurs) ;
- **salon-bar** (canapés, piano, barman ; cocktail sans alcool) ;
- **restaurant** (tables, clients, serveur ; dîner) ;
- **coursive et cabine** (repos d'une heure) ;
- **passerelle de commandement** (officier ; « prendre la barre ») ;
- **descente à quai** quand le navire est amarré.

Les paiements se font en monnaie du jeu.

**Corrections** :
- `landClamp` laisse marcher sur les jetées et dans les espaces placés en hauteur (pont des navires) ;
- `isWater` traite les jetées comme des obstacles pour les bateaux.

**Testé** :
- 10 bateaux à quai ;
- bateau de pêche : embarquement, 89 m parcourus, virage, arrêt devant le rivage, débarquement sur la jetée ;
- paquebot : 7 espaces visités, bar payé, prise de la barre et navigation (7,5 m/s) ;
- sauvegarde des bateaux déplacés ; test de fumée ; vue aérienne du port.

Aucune erreur détectée.

## Mission 017 — étape 1 : compte personnel de 10 milliards, banque personnelle et achats

> Tous les montants sont une **monnaie fictive du jeu**, sans aucune valeur réelle.

Plan de la mission 017 :
1. fortune et banque personnelle (fait) ;
2. conversations libres avec les employés (personnalité, humeur, mémoire, voix facultative du navigateur) ;
3. carnet de contacts complet et rencontres avec les habitants ;
4. réunions d'affaires ;
5. invitations, dîners de gala, réputation à 7 indicateurs.

**Compte personnel** :
- dotation unique de **10 000 000 000 FCFA**, versée une seule fois (nouvelle partie comme sauvegarde existante), après le chargement de la sauvegarde ;
- solde affiché en abrégé à l'écran (« 10,00 Md FCFA ») et en détail dans le téléphone ;
- l'historique conserve désormais 300 opérations (au lieu de 80).

**Application « 🏦 Ma banque »** :
- compte personnel, épargne et patrimoine (propriétés et véhicules) ;
- historique filtrable (tout, dépenses, revenus) avec une **catégorie** par opération : alimentation et sorties, transport, hébergement, véhicules, immobilier, mode, loisirs, banque et entreprises, revenus ;
- graphique des **dépenses par catégorie** ;
- **virements** : vers l'épargne et retour ; **apport** du compte personnel vers une société NOVA ; **dividende** d'une société vers le compte personnel ;
- chaque virement est vérifié puis confirmé, avec un jeton à usage unique ;
- les comptes des sociétés restent séparés : un virement explicite est le seul passage possible.

**Application « 🛍️ Achats & patrimoine »**, avec confirmation à chaque achat :
- **véhicules** : les 13 voitures du garage AUTO CONCEPT ont désormais un prix (de 25 M à 250 M FCFA), et l'achat se fait en deux clics au garage ;
- **propriétés** : 6 maisons et immeubles réels du décor (Porto-Novo, Ouidah, Pahou, Cocotomey), de 435 M à 1,5 Md FCFA. À l'achat, une enseigne « PROPRIÉTÉ DU PDG » apparaît sur la façade et un repère sur la carte ; un **loyer** est versé chaque mois de jeu ;
- **mode de luxe** : 12 pièces dans la garde-robe (onglet « Collection de luxe ») — costumes sur mesure, smoking blanc, boubou de gala brodé or, souliers vernis, mocassins, montres en or et en platine, lunettes, collier en or, panama. Cadenas et prix tant que la pièce n'est pas achetée, puis elle est portable ;
- **équipements** : ordinateur, tablette, appareil photo, drone, montre connectée (rangés dans « Mes articles ») ;
- **loisirs** : spa, massage, dîner privé, cinéma privé, avec des effets sur l'énergie, la propreté et la faim.

**Testé** :
- dotation unique ;
- dépôt d'un milliard sur l'épargne (jeton non réutilisable) ;
- apport de 100 M à NOVA BOOK ;
- achat d'un immeuble : enseigne, repère sur la carte, loyer au bout d'un mois de jeu ;
- appareil photo et spa ;
- voiture à 250 M (double clic de confirmation) ;
- montre en or achetée puis portée ;
- rechargement sans double dotation ; test de fumée.

Aucune erreur détectée.

## v3.7 — Mission 017, étape 2 : conversations libres avec les employés

- **Moteur de dialogue local et gratuit** (`src/talk.js`), sans service en ligne ni crédit payant. Le joueur écrit librement. L'employé répond selon :
  - sa **personnalité** (chaleureux, réservé, enthousiaste, pragmatique, blagueur) ;
  - son **humeur**, qui dépend du moral ;
  - son **métier** ;
  - les **données réelles du jeu** : commande en cours et avancement, projets, chiffre d'affaires, trésorerie, équipements.
- **Vie personnelle cohérente** : famille, ville d'origine, loisirs, plat préféré, toujours identiques pour un même employé.
- **Mémoire** de chaque employé (sauvegardée) : instructions, félicitations, reproches, promesses. « Tu te souviens… ? » rappelle les derniers échanges.
  - Une promesse d'augmentation non tenue après 7 jours est rappelée, et le moral baisse de 5.
  - Une promotion accordée est remerciée.
- **Effets réels** :
  - félicitations : moral +3, une fois par jour ;
  - reproche : moral −4 ;
  - « accélère » : production +12 % jusqu'au lendemain ;
  - « prends ta journée » : absence d'un jour, moral +8 ;
  - « soigne la qualité » : moral +1.
- **Où discuter** :
  - **Tour NOVA BOOK** : « Parler à … » sur chaque employé.
  - **NOVA Gestion** :
    - bouton 💬 Parler sur chaque fiche ;
    - discussion collective par département ;
    - discussion collective par filiale.
  - **Bureaux des filiales** :
    - conversation avec le directeur ;
    - salle de réunion = discussion collective.
  - **Téléphone** : les messages aux employés passent par le même moteur et partagent la même mémoire.
- **Voix facultative** :
  - 🔊 lecture des réponses par la synthèse vocale du navigateur (Web Speech API, fr-FR) ;
  - 🎤 dictée, seulement si le navigateur la propose (sur certains navigateurs, la reconnaissance vocale passe par le service du navigateur).
  - Rien d'obligatoire.

## v3.8 — Mission 017, étape 3 : rencontres avec les habitants et carnet de contacts complet

- **Faire connaissance** : nouvelle option « 🤝 Faire connaissance » quand on parle à un habitant, à Cotonou comme dans les villes de la région. Les options existantes (discuter, demander son chemin, infos sur le quartier, achats) sont conservées.
- **Identité fictive stable** pour chaque passant abordé : nom, âge, métier, ville d'origine, loisirs, caractère (ouverture, humour).
- **Actions possibles** :
  - saluer (au Bénin on dit d'abord bonjour : sinon la sympathie baisse) ;
  - se présenter (la réputation de NOVA BOOK compte) ;
  - compliments respectueux (tenue, amabilité, quartier) ;
  - blague ;
  - discussion libre ;
  - demander le contact ;
  - au revoir.
- **Consentement** :
  - l'habitant accepte ou refuse selon la sympathie, son caractère, l'heure, s'il est pressé et la réputation du PDG ;
  - le contact n'est enregistré qu'après son accord (date du consentement conservée) ;
  - **un refus est définitif** : le jeu ne propose pas d'insister ; redemander fait baisser la sympathie, et la personne finit par partir ;
  - **les mineurs (élèves) ne donnent jamais leurs coordonnées**.
- **Carnet de contacts complet** (téléphone → Contacts) :
  - nouvel onglet « Rencontres » ;
  - fiche détaillée pour **chaque** contact : portrait illustré, téléphone « +229 00 … » (fictif, numéro non attribuable), e-mail en « .example » (domaine réservé, fictif), adresse (quartier de rencontre, ou adresse professionnelle) et historique (rencontre, messages, appels, virements) ;
  - favoris et suppression avec confirmation.
- **Messages et appels** avec les personnes rencontrées : elles répondent selon l'heure et la sympathie, et chaque échange est noté dans l'historique.
- **Sauvegarde** : carnet de contacts et refus enregistrés (clé `social`).

## v3.9 — Mission 017, étape 4 : réunions d'affaires

- **Agenda** : nouvelle application 📅 du téléphone, avec une vue complète (réunions à venir, archives, comptes rendus).
- **Types de réunion** :
  - comité de direction NOVA BOOK ;
  - réunion de département ;
  - réunion des directeurs du groupe ;
  - réunion dans une filiale ;
  - rendez-vous client ;
  - rendez-vous avec un contact rencontré.
- **Planification** :
  - date (jusqu'à 6 jours à l'avance) et heure ;
  - salle : salle du conseil de la tour NOVA (10 places), salle de réunion du rez-de-chaussée (8), salle de réunion d'une filiale (8) ou visioconférence ;
  - participants (9 au maximum) ;
  - ordre du jour : 4 points au maximum, avec le coût affiché.
- **Invitations** envoyées par message. Chaque invité **confirme ou s'excuse** avec une raison, selon son statut, son moral, la réputation de NOVA BOOK ou la sympathie.
- **Plan de table** : placement automatique par rang (invités d'honneur à côté du PDG), échange de places au toucher.
- **Préparation de la présentation** : 1 heure de jeu. Elle rend la présentation plus convaincante, surtout face aux clients.
- **Séance** : elle se lance au point « réunion » de la salle prévue (salle du conseil, écran de la salle du rez-de-chaussée, salle de réunion de la filiale) ou en visio, de 30 minutes avant à 2 heures après l'heure prévue.
  1. Accueil (présents, retardataires, absents).
  2. Présentation en 3 diapositives avec les vrais chiffres.
  3. Pour chaque point : avis argumentés des participants selon leur métier et la situation réelle (trésorerie, capacité des départements…), puis décision du PDG (approuver / rejeter / reporter).
- **Décisions aux effets réels** :
  - salaires +5 % ;
  - prime exceptionnelle ;
  - formation ;
  - annonce de recrutement ;
  - équipements ;
  - lancement d'un projet ;
  - signature d'une proposition client ;
  - consignes et équipements des filiales ;
  - nouvelle commande, partenariat ou remise négociés avec un client (le client peut refuser) ;
  - sympathie avec un contact.
  - Les fonds sont vérifiés avant chaque dépense.
  - Suivre ou non l'avis de la majorité influence le moral.
- **Compte rendu** généré automatiquement : date, lieu, présents, excusés, plan de table, avis, décisions et effets, trésorerie après la réunion. Il est archivé et peut être envoyé aux participants par message.
- **Réunion manquée** : les invités sont déçus (moral −3 ; sympathie −10 pour un contact ; réputation −3 si un client attendait).

## v4.0 — Mission 017, étape 5 : événements prestigieux et réputation (mission 017 terminée)

- **Invitations** : une première arrive peu après le début, puis environ tous les 2 jours.
  - Elles prennent la forme de cartons nominatifs : organisateur, date, lieu, code vestimentaire, numéro de table.
  - Il y en a 3 en attente au maximum, de types variés.
  - Les Trophées et les réceptions d'affaires demandent une réputation suffisante.
- **Six événements fictifs** : dîner de gala d'une fondation, cérémonie de trophées, vernissage, concert caritatif (place des Martyrs), réception d'affaires, ouverture du Salon du livre.
  - Ils ont lieu dans des établissements existants du jeu (hôtels, restaurants), à Cotonou, Porto-Novo et Ouidah.
- **Réponse à l'invitation** :
  - accepter : l'événement entre au calendrier et un repère 🎟️ apparaît sur la carte, avec itinéraire ;
  - décliner poliment : sans pénalité ;
  - ne pas répondre : fiabilité −2 ;
  - accepter puis ne pas venir : fiabilité −8, prestige −3.
- **Calendrier** : événements et réunions d'affaires réunis, avec rappel 2 heures avant.
- **Chauffeur privé** (15 000 FCFA, compte personnel) : aller jusqu'au lieu, et retour à la maison en fin de soirée.
- **La soirée** (entrée devant le lieu, de 30 minutes avant à 1 h 30 après l'heure prévue) :
  1. Accueil : tapis rouge, contrôle du carton, ponctualité, code vestimentaire. La tenue portée (garde-robe) est évaluée : luxe, professionnelle, traditionnelle ou trop décontractée.
  2. Cocktail : **boissons uniquement sans alcool** (bissap, jus de baobab, cocktail ananas-gingembre, citronnade, eau). On échange avec 3 invités fictifs ; les cartes de visite ne sont échangées **qu'avec leur accord** (un refus est respecté) et rejoignent le carnet de contacts.
  3. Dîner à la table indiquée : plan de table et menu de gastronomie béninoise.
  4. Moment fort, selon l'événement :
     - don, prélevé sur le compte personnel uniquement ;
     - trophée et discours ;
     - achat d'une œuvre ;
     - présentation de NOVA BOOK, qui amène une nouvelle demande client ;
     - dédicaces.
  5. Photos : avec l'**appareil photo acheté à l'étape 1** (organisateurs, table, salle, invités). Sans appareil, le photographe officiel prend une photo. Elles sont rangées dans un album.
  6. Départ : bilan des indicateurs ; article de presse fictif possible.
- **Réputation à 7 indicateurs** : prestige, élégance, réseau, générosité, fiabilité, professionnalisme, image médiatique.
  - Les événements la font évoluer, mais aussi les réunions (ponctualité, préparation, réunion manquée) et les nouveaux contacts.
  - La réputation globale ouvre l'accès aux événements les plus prestigieux.

## v4.1 — Mission 018, étape 1 : gardes du corps de la résidence

- Système de protection **fictif et non violent** : les gardes protègent, saluent et accompagnent. Ils ne s'en prennent jamais aux habitants.
- **4 gardes du corps** (identités fictives, sans doublon), avec costume noir, chemise blanche, cravate, lunettes noires, oreillette, insigne doré et montre :
  - Rodrigue Akpaki, chef d'équipe : entrée principale, gauche du portillon ;
  - Prudence Hounkanrin : entrée principale, droite du portillon ;
  - Firmin Dossa : ronde dans la cour ;
  - Abel Kouton : près du garage.
- **Animations** :
  - garde à vous, mains croisées ;
  - ronde lente dans la cour ;
  - discussion entre les deux gardes de l'entrée ;
  - salut au PDG quand il passe près d'eux.
- **Accompagnement** :
  - quand le PDG sort de la résidence, l'équipe d'escorte (2 gardes par défaut) le suit en formation et rattrape son retard en courant ;
  - les gardes attendent devant les bâtiments (tour NOVA, bureaux, restaurants, hôtels, navire) ;
  - ils « montent » dans le véhicule du PDG et réapparaissent près de lui à la descente ;
  - quand il rentre, ils retournent à leur poste.
- **Commandes** :
  - « Parler à … » près d'un garde : point de situation, m'accompagner, retourner au poste, rester ici, toute l'équipe avec moi, toute l'équipe au poste ;
  - application téléphone **🛡️ Sécurité personnelle** : liste, nom, grade, poste, emplacement actuel, disponibilité, affectation, accompagnement, choix de l'équipe d'escorte, escorte automatique activable.
- **Contacts** : onglet « Sécurité » (messages et appels : point de situation, « rejoignez-moi », « retournez à votre poste »).
- **Sauvegarde** : mode, affectation, poste et équipe d'escorte de chaque garde (clé `security`).

## v4.2 — Mission 018, étape 2 : sécurité devant les entreprises NOVA

- **14 gardes d'entreprise** aux identités fictives : 4 devant NOVA BOOK (porte de la tour), 2 devant chacune des filiales NOVA DIGITAL, NOVA MEDIA, NOVA IMMOBILIER, NOVA TRANSPORT et NOVA DISTRIBUTION (entrées signalées des bureaux).
  - Ils portent le même costume que les gardes de la résidence, avec une **cravate aux couleurs de la société**.
  - Chaque garde a un poste défini (de part et d'autre de l'entrée, ou sur le parvis), et chaque équipe a un chef de poste.
- **Accueil du PDG** : le chef de poste salue et souhaite la bienvenue. Si la filiale n'est pas encore créée, l'équipe surveille les locaux réservés.
- **Visiteurs** :
  - les passants qui approchent de l'entrée sont salués d'un geste, ou orientés du bras vers la réception ;
  - « Où est la réception ? » est disponible en parlant à un garde ;
  - les visites d'affaires attendues au siège sont accueillies et signalées par message.
- **Accompagnement dans les bâtiments** : un garde d'entreprise entre avec le PDG dans son bâtiment (tour NOVA BOOK, à tous les étages ; bureaux des filiales). Il reprend son poste quand le PDG s'éloigne.
- **Signalements de situations inhabituelles**, réglés **sans violence** :
  - colis sans étiquette, enfant égaré, véhicule mal garé : l'équipe s'en occupe seule ;
  - coupure de courant (technicien, 40 000 FCFA sur le compte de la société concernée), malaise d'un passant (appel des secours), visiteur sans rendez-vous (le recevoir, ou lui proposer un rendez-vous) : l'équipe demande l'accord du PDG.
  - Le PDG est prévenu par message du chef de poste. Un historique est conservé.
- **Application Sécurité personnelle** :
  - 18 gardes, regroupés par affectation ;
  - signalements en cours avec boutons de décision ;
  - toucher un garde permet de **changer son affectation** (résidence ou n'importe quel siège, selon les postes libres) ;
  - historique des signalements.
- **Sauvegarde** : affectations, postes, modes et signalements. Tout est conservé après rechargement, sans doublon.

## v4.3 — Mission 018, étape 3 : limousine personnelle

- **Une seule limousine** (identifiant `BL-LIMO-1`). Le jeu refuse d'en créer une seconde.
- Elle est garée dans un **garage limousine** construit à côté du garage de la résidence (côté est de la parcelle, emplacement vérifié libre) : porte enroulable, néons, enseigne « BENIN LIFE • GARAGE LIMOUSINE ».
  - La porte s'ouvre à la main, ou automatiquement quand la limousine approche.
  - Le poste du garde « garage » a été légèrement déplacé, pour laisser le passage.
- **Extérieur** :
  - carrosserie noire brillante allongée de 7,2 m ;
  - baguettes et ornement chromés ;
  - **plaques « BENIN LIFE »** (fictives) aux couleurs du Bénin ;
  - **vitres teintées** réglables (teintées ou claires).
- **Portières et coffre interactifs** : les portières arrière s'ouvrent en révélant le salon éclairé ; le coffre se soulève, avec des bagages dedans.
- **Salon arrière** : « S'installer dans le salon » quand une portière est ouverte. La vue en coupe retire le toit, les vitres et la carrosserie pour montrer l'intérieur.
  - Banquettes crème en L, moquette, cloison en bois.
  - **Éclairage LED** d'ambiance, 5 couleurs, avec ciel étoilé.
  - **Écran multimédia** : musique, infos, film et trajet (programmes fictifs).
  - **Climatisation** de 16 à 26 °C.
  - **Mini-bar sans alcool** : bissap, jus d'ananas, eau pétillante.
- **Conduite** : E près de la portière avant, comme pour les autres véhicules.
  - Un **tableau de bord** apparaît : vitesse, compteur kilométrique, climatisation, LED, écran.
- **Sauvegarde** : réglages, compteur et portières. À chaque chargement, la limousine est **rangée dans son garage**.

## v4.4 — Mission 018, étape 4 : conducteur personnel et limousine avec chauffeur

- **Augustin Sossou-Gbèdo** (personnage fictif), conducteur personnel permanent :
  - costume sombre, cravate bordeaux, casquette de chauffeur, montre ;
  - poli, avec sa propre personnalité : originaire d'Abomey, 18 ans de conduite, marié et père de trois enfants, passionné de football et de radio ;
  - il se souvient des trajets faits ensemble.
- **Contact du téléphone** (onglet « Sécurité & chauffeur »), avec **conversation libre** : salutations, nouvelles, famille, origine, loisirs, circulation, musique, climatisation, souvenirs de trajets, blagues.
  - Les messages servent aussi de **commandes** : « viens me chercher », « emmène-moi à NOVA BOOK », « rentre à la maison ».
- **Application « 🚘 Chauffeur personnel »** :
  1. « Appeler mon conducteur ».
  2. La limousine BL-LIMO-1 (la même, jamais une copie) arrive sur la route la plus proche et s'arrête devant le joueur. Augustin descend et ouvre la portière arrière.
  3. E pour monter à l'arrière, puis choix de la destination.
  4. Trajet automatique sur le réseau routier, grâce aux itinéraires du système de transport existant.
  5. Dépose sur le trottoir, au plus près de l'entrée. Le chauffeur reste à proximité (« Remonter », « Autre destination ») ou rentre au garage.
- **Destinations** :
  - ma maison ;
  - les 6 entreprises NOVA (dépose devant l'entrée gardée) ;
  - réunions et événements acceptés ;
  - restaurants, hôtels, banques, aéroport, port, marchés et centres commerciaux, monuments, villes, quartiers ;
  - **n'importe quel lieu ou point libre de la carte** : bouton « 🚘 Y aller en limousine » ; toucher un endroit vide de la grande carte place un repère rouge.
- **Pendant le trajet** :
  - ⏩ passer le trajet ;
  - 🛋️ vue salon (intérieur en coupe pendant la conduite) ;
  - 🏠 « Rentre à la maison » (bouton, touche H ou message) ;
  - 🎤 commande vocale facultative, si le navigateur la propose (reconnaissance vocale du navigateur, gratuite).
  - Les gardes de l'escorte montent dans le véhicule.
- **Secours** :
  - circulation : le chauffeur s'arrête, puis contourne prudemment au bout de 2,5 s ;
  - route bloquée plus de 25 s : détour ;
  - destination loin de toute route : dépose au plus près, avec la distance à faire à pied ;
  - sans réponse après 2 min 30 : la limousine retourne au garage.
- **Pas de doublon** : la limousine n'est jamais dupliquée et ne peut pas être prise au volant pendant qu'Augustin conduit.
- **Sauvegarde** : trajets, mémoire du conducteur, catégorie choisie. La limousine est rangée au garage à chaque chargement.

## v4.5 — Mission 018, étape 5 : escorte en véhicule, agenda relié, sauvegarde (mission 018 terminée)

- **Véhicule d'escorte unique** `BL-ESCORTE-1` : 4×4 noir « SÉCURITÉ NOVA » avec feux de signalisation discrets.
  - Quand des gardes accompagnent le PDG et qu'il se déplace en véhicule (limousine avec chauffeur, sa propre voiture, taxi), les gardes montent dans l'escorte.
  - L'escorte suit le véhicule du PDG à environ 13 m en reprenant **exactement sa trajectoire**, sans couper à travers les bâtiments.
  - À l'arrêt, elle se gare derrière. Les gardes en descendent et rejoignent le PDG à pied.
  - Elle retourne à la base quand le PDG s'éloigne à pied.
  - Activable ou désactivable dans l'application Sécurité personnelle, qui indique aussi son état.
- **Agenda relié au chauffeur** :
  - « 🚘 Y aller avec mon chauffeur » sur chaque réunion (dépose devant le siège concerné) ;
  - « 🚘 Ma limousine (Augustin) » sur chaque événement accepté ;
  - le rappel de réunion propose le chauffeur.
  - Le chauffeur privé payant de la mission 017 (trajet direct) est conservé.
- **Contrôle de la sauvegarde** (gardes, affectations, équipe d'escorte, signalements, limousine, conducteur, véhicule d'escorte) : identique après deux rechargements.
  - 18 gardes uniques, 1 limousine, 1 véhicule d'escorte. Taille de la sauvegarde : 28 Ko.

## v4.6 — Mission 019, étape 1 : VILLA NOVA

- **Maison d'origine conservée.** La parcelle est bordée par les maisons voisines et par la route. L'agrandissement se fait donc :
  - **sur la parcelle** (extérieur) ;
  - et par une **aile principale intérieure**, accessible par une porte dorée au dos de la maison (terrasse). C'est un intérieur isolé, sur le même principe que les bureaux et les hôtels du jeu.
- **Extérieur** :
  - fronton « VILLA NOVA » et lanternes sur les piliers (la nuit) ;
  - **portail et portillon automatiques** : ouverture à l'approche (à pied ou en voiture), fermeture après le passage, désactivable ;
  - **jardin paysager** : massifs fleuris, bornes lumineuses le long de l'allée ;
  - **grande piscine** (10 × 5 m) : bassin surélevé, margelles, lignes de nage, échelle, plage en bois, eau éclairée la nuit ; « Se baigner » (longueurs de nage) ;
  - 3 transats et un parasol ; **salon de jardin** sur la terrasse ;
  - **abri 2 véhicules**. Garage total : 4 places (garage de la maison, garage limousine, abri).
- **Aile principale (19 pièces)** :
  - **pièces de vie** : grand salon (canapés, écran géant, piano), salle à manger familiale (table de 12), cuisine professionnelle (îlot, inox, réfrigérateur américain, placards ; ouvre la cuisine du jeu), bureau personnel (ouvre NOVA Gestion), salle de cinéma (15 fauteuils sur gradins), salle de sport (tapis de course, musculation, miroir), salle de jeux (billard, baby-foot, console), buanderie (lessive, repassage), salle de bains commune (bain, douche), espace du personnel ;
  - **9 chambres** : suite parentale avec dressing, 3 chambres d'enfants, 4 chambres d'invités, chambre du personnel de maison. Chacune a un lit, une armoire (garde-robe du joueur), un bureau, une télévision murale et une **salle de bain privée** (douche).
  - Galerie de tableaux, tapis et plantes dans les couloirs.
- **Interactions dans chaque pièce** : se reposer ou dormir jusqu'à 7 h, douche, bain, télévision, film, sport, jeux, lessive, travail au bureau, repas…
- **Décoration personnalisable** de chaque chambre : 7 thèmes de couleurs pour les murs et le linge de lit, sauvegardés.
- **Application « 🏛️ Ma Villa »** : liste des pièces, accès direct à chaque pièce depuis la résidence, décoration, portail automatique, éclairage de la piscine.
- **Sauvegarde** : décoration et réglages. La villa n'est jamais construite deux fois.

## v4.7 — Mission 019, étape 2 : cuisinier personnel

- **Recrutement** (application « 👩🏿‍🍳 Mon cuisinier ») parmi 3 candidats fictifs aux profils, personnalités et salaires différents :
  - Clémentine Agossa : cuisine béninoise traditionnelle, 150 000 FCFA ;
  - Rodolphe Kiki : chef d'hôtellerie, 220 000 FCFA ;
  - Awa Sanni : cuisine du Nord et du Sud, jus, pâtisseries, 130 000 FCFA.
  - Le salaire est prélevé sur le compte personnel tous les 7 jours de jeu (monnaie virtuelle). On peut mettre fin au contrat.
- **Tenue de cuisine** (veste blanche, toque, tablier vert). Le cuisinier se déplace entre l'îlot, les plaques, le plan de travail et le réfrigérateur de la cuisine professionnelle (6 h – 22 h). Il fait des gestes de cuisine et une vapeur s'échappe de la marmite pendant la préparation.
- **19 préparations** avec les **vrais plats et ingrédients du jeu** :
  - **petit-déjeuner** : koko et akara, aklui et atchomon, akassa et akara ;
  - **plats** : amiwo, watché avec poisson braisé, atassi, akassa avec poisson frit et dja, ablo avec poisson grillé, wɔ̌ avec sauce gombo ou crincrin, igname pilée avec sauce graine et wagashi, riz au gras avec poulet braisé, gari et sauce, pâte rouge avec sauce arachide, poulet braisé avec alloco, wagashi frit ;
  - **jus** : bissap, gingembre, baobab.
- **Réserves** : produits frais dans le **réfrigérateur** (le stock de la cuisine du jeu) et épicerie sèche dans les **placards** (18 produits).
  - S'il manque des ingrédients, le cuisinier propose de faire les courses (prix affiché, accord demandé, compte personnel). Bouton « courses complètes ».
- **Commandes** :
  - depuis le téléphone (carte complète, « Commander » ou « 🚘 Livrer ») ;
  - dans la cuisine (« Parler à … » : menu du jour et plats proposés) ;
  - ou par message libre (« Prépare-moi un riz au gras », « Fais-moi un jus de gingembre », « … et livre-le au bureau »).
  - Le plat est **servi à la salle à manger** de la villa (« Prendre un repas » : faim et énergie) ou **livré par le chauffeur** dans le sac du joueur.
- **Repas planifiés** : petit-déjeuner (7 h), déjeuner (12 h 30) et dîner (19 h 30) préparés automatiquement avec le menu du jour, activables séparément.
- **Conversation libre** : Contacts › Maison (menu, réserves, courses, recettes, origine, compliments).
- **Sauvegarde** : cuisinier, réserves, commandes, repas servis, planning et salaire.

## v4.8 — Mission 019, étape 3 : personnel domestique

- **Recrutement par poste**, parmi des candidats fictifs (âge, origine, caractère, salaire) :
  - 2 agents d'entretien ;
  - 1 jardinier·ère ;
  - 1 blanchisseur·se ;
  - 1 responsable de maison.
  - Le nombre de places par poste est respecté, et il n'y a pas de doublon. Le cuisinier de l'étape 2 apparaît dans la même équipe.
- **Uniformes** : tunique bleue (entretien), vert et chapeau de paille (jardin), tunique lavande (linge), costume avec cravate dorée (responsable).
- **Horaires et disponibilité** :
  - entretien 7 h – 16 h, jardin 6 h – 13 h, linge 8 h – 17 h, responsable 7 h – 19 h ;
  - un jour de repos par semaine ;
  - état affiché en direct : disponible, tâche en cours avec pourcentage, hors service, repos.
- **17 tâches visibles dans le jeu** :
  - ménage du salon, de la cuisine, des chambres et des salles de bains ;
  - rangement ;
  - terrasse et vitres ;
  - tonte, arrosage, taille, nettoyage de la piscine ;
  - lessive, repassage, changement des draps ;
  - inspection, entretien des équipements, vérification des réserves (relié au cuisinier), accueil des invités.
  - L'employé se rend sur place par les couloirs de l'aile ou les allées du jardin, avec son outil (balai, seau, panier, arrosoir, tondeuse, cisaille, épuisette, tablette, mallette) et des gestes adaptés.
- **Attribution des tâches** :
  - depuis l'application (onglet Tâches) ;
  - en parlant à l'employé ;
  - par message libre (« Peux-tu nettoyer la piscine ? »).
  - Chaque matin, le **responsable de maison** établit le planning en priorité sur les zones les plus usées et envoie un rapport.
- **État de la maison** (8 zones : pièces de vie, cuisine, chambres, salles de bains, linge, jardin, piscine, équipements) : il baisse avec le temps et remonte quand les tâches sont faites. Une piscine négligée devient trouble.
- **Conversation libre** : Contacts › Maison (nouvelles, tâche en cours, horaires, salaire, origine, état de la maison, remerciements qui améliorent le moral).
- **Salaires** en FCFA virtuels, prélevés sur le compte personnel tous les 7 jours de jeu. Total affiché, fin de contrat possible.
- **Application « 🏠 Personnel domestique »** : Équipe, Tâches, État de la maison, Recruter, Salaires.
- **Sauvegarde** : équipe, tâches, moral, état de la maison, historique.

## v4.9 — Mission 019, étape 4 : actions sociales en ville

- **10 personnages fictifs** aux histoires, personnalités et situations différentes, placés sur des places, marchés et trottoirs existants (jamais sur la chaussée) :
  - Cotonou : Koffi (tailleur sinistré, Dantokpa), Mariama (vendeuse, enfant malade, Dantokpa), Grand-mère Agossi (personne âgée isolée, place des Martyrs), Ezéchiel (ancien zémidjan blessé, plage), Rodrigue (étudiant sans logement, Jardin de Cadjèhoun), Jules (maçon blessé, près de LAGUNA) ;
  - Porto-Novo : Sylvain, musicien âgé ;
  - Ouidah : Afi, pêcheuse dont la pirogue est cassée ;
  - Pahou : Bertrand, vendeur malade ;
  - Cocotomey : Adjoa, jeune femme venue du Nord pour chercher du travail.
- **Discuter avant d'aider** : se présenter, demander ce qui arrive, les besoins, les espoirs. On ne peut proposer une aide qu'après avoir écouté (sauf un repas, ou de l'eau et des vêtements).
  - Une personne peut solliciter poliment, une fois par jour, jamais avec insistance.
- **Aides possibles** (monnaie virtuelle, compte personnel) :
  - argent ;
  - repas ;
  - eau et vêtements ;
  - orientation vers le centre d'accueil Espérance (fictif) ;
  - hébergement temporaire de 7 nuits ;
  - soutien à l'association locale ;
  - **la solution propre à chaque situation** : machine à coudre, soins, formation, réparation de pirogue, caution de logement…
- **Dignité** : les personnes peuvent préférer une aide durable à un gros don d'argent (« Je ne veux pas dépendre d'un don »). Leur situation évolue réellement (difficile → soulagée → en amélioration → stabilisée). Une fois stabilisées, on les revoit en train de travailler et elles remercient à leur façon.
- **Conséquences** :
  - réputation humanitaire qui progresse doucement, sans points affichés ; chaque personne ne compte qu'une fois ;
  - effet sur la générosité et le prestige de la mission 017 ;
  - 5 associations fictives qui deviennent des contacts ;
  - **invitation à un concert caritatif** ;
  - **4 projets sociaux** à financer : cantine solidaire, atelier de couture, fonds pour les aînés, pirogues solidaires. Un projet réalisé améliore la situation des bénéficiaires.
- **Respect** : les lieux des personnes ne sont pas marqués sur la carte.
- **Application « 🤝 NOVA Solidarité »** : Personnes, Associations, Projets sociaux, Historique (complétée par l'orphelinat à l'étape 5).
- **Sauvegarde** de toutes les relations, aides, projets et de l'historique.
- **Correctif (présent depuis la v4.5)** : le lien entre l'agenda des événements et le conducteur personnel portait le même nom que la fonction du chauffeur privé payant (« trajet direct »). Le bouton « Chauffeur privé » et « Rentrer avec le chauffeur » en fin de soirée pouvaient échouer. Le lien a été renommé ; les deux chauffeurs fonctionnent.
- Entrée d'un événement : rayon de détection porté à 14 m (le chauffeur privé peut se garer jusqu'à 12 m).

## v5.0 — Mission 019, étape 5 : NOVA SOLIDARITÉ (centre d'accueil pour enfants, fictif)
- Bâtiment existant inutilisé de Cotonou réaménagé (pas de doublon) : enseigne, fresque, drapeau, porte ; point « NOVA SOLIDARITÉ » sur la carte.
- Intérieur isolé autour d'une cour : accueil, infirmerie, bibliothèque, salle d'étude, salle informatique, dortoirs (petits, filles, garçons, grands), sanitaires, réfectoire, cuisine, salle de jeux, détente.
- 11 membres du personnel fictifs (directrice, éducateurs, infirmière, cuisinière, agente chargée de la protection de l'enfance…) ; 60 places, enfants fictifs avec emploi du temps ; les enfants circulent par les portes.
- Visites encadrées (jour de visite ou rendez-vous), activités limitées à 3 par jour.
- 7 types de dons (argent virtuel, nourriture, fournitures, vêtements, médical, jouets/livres, matériel) avec historique ; besoins hebdomadaires ; 5 projets d'amélioration.
- Application NOVA Solidarité : onglets Centre d'accueil, Dons, Besoins et projets, Visites ; trajet en limousine avec le chauffeur.
- Sauvegarde permanente (clé `orphanage`). Les missions 001 à 018 et les étapes précédentes sont conservées.

## v5.1 — Mission 019, étape 6 : adoption fictive et responsable, vie familiale
- Démarche encadrée au centre NOVA SOLIDARITÉ (responsable de la protection de l'enfance, fictive) : réunion d'information, présentation d'un enfant par l'équipe (pas de choix « sur catalogue »), rencontres adaptées (une par jour, au rythme de l'enfant), entretien d'évaluation de la famille, visite du domicile (chambre préparée, propreté, barrière de piscine, repas), validation avec l'accord de l'enfant dès 7 ans, intégration progressive (journée, week-end, arrivée).
- L'adoption n'est jamais un achat : aucune étape n'est payante, les dons n'ont aucune influence. L'enfant peut demander plus de temps ou dire non : sa parole est respectée.
- Vie familiale à la VILLA NOVA : chambre d'enfant attribuée, journée rythmée (repas, soutien scolaire au centre en semaine en attendant l'inscription dans une école, jeux, devoirs, coucher), déplacements par les couloirs sans traverser les meubles.
- Moments partagés (discuter, devoirs, jeux, histoire du soir, repas), sorties en famille, indicateurs bonheur / confiance / santé / études, anniversaires, journal de famille, messages des enfants de 8 ans et plus (onglet « Famille » des contacts).
- Nouvelle application « Vie familiale » (Ma famille, Adoption, Activités, Journal). Sauvegarde permanente (clé `family`). Missions 001 à 018 et étapes précédentes conservées.

## v5.2 — Mission 019, étape 7 : 10 établissements scolaires et « Vie scolaire »
- Réseau de 10 écoles fictives : NOVA SCHOOL COTONOU, ACADÉMIE DU LITTORAL, GROUPE SCOLAIRE LES ÉLITES, ÉCOLE INTERNATIONALE DE COTONOU, LYCÉE DU GRAND COTONOU, INSTITUT SCOLAIRE NOVA (Cotonou), COLLÈGE MODERNE DE COCOTOMEY, ACADÉMIE DE PORTO-NOVO, GROUPE SCOLAIRE D'OUIDAH, ÉCOLE MODERNE DE PAHOU.
- Bâtiments existants réutilisés (pas de doublon) avec enseigne, logo, portail et drapeau ; points « Écoles » sur la carte.
- Campus intérieur (modèle unique habillé aux couleurs de chaque école) : 6 salles de classe, bureaux administratifs, salle des professeurs, bibliothèque, salle informatique, cantine, toilettes, cour de récréation avec préau, terrain de sport, infirmerie, parking, portail et clôture.
- PNJ fictifs : direction, secrétariat, enseignants, infirmière, cantinière, gardien et élèves en uniforme qui suivent l'emploi du temps (accueil, cours assis en classe, récréation, cantine, EPS) en passant par les portes et les allées.
- Inscription fictive : rendez-vous avec la direction (sur place ou par appel), classe selon l'âge, frais virtuels (inscription et trimestres), uniforme, fournitures, clubs du mercredi.
- Calendrier scolaire (année de 80 jours de jeu, 3 trimestres, vacances), notes et bulletins fictifs, absences, réunions parents-professeurs, accompagnement à l'école depuis la villa. L'enfant est visible dans sa classe pendant les cours.
- Application « Vie scolaire » : Mon enfant, Emploi du temps, Résultats, Réunions et activités, Calendrier, Établissements (liste, fiche, comparaison, rendez-vous, inscription, chauffeur). Sauvegarde permanente (clé `schools`).

## v5.3 — Mission 019, étape 8 : intégration finale et sauvegarde
- Vie familiale complétée : cadeaux adaptés à l'âge (un par jour ; trop de cadeaux = effet réduit, l'attention compte plus), fête d'anniversaire (en famille ou avec les camarades de classe, boissons sans alcool), vacances en famille à Ouidah, Porto-Novo ou Pahou pendant les week-ends et vacances scolaires (hôtels fictifs, annulation remboursée avant le départ), paroles adaptées à l'âge (petits, enfants, adolescents).
- « Ma Villa » : nouvelle section de gestion de la résidence (cuisinier, personnel domestique, sécurité et chauffeur, famille, scolarité) avec accès direct aux applications.
- Vérification de la sauvegarde : 15 systèmes (villa, cuisinier, personnel, solidarité, centre d'accueil, famille, écoles, sécurité, limousine, chauffeur, escorte, événements, rendez-vous, rencontres, conversations) identiques après rechargement ; une sauvegarde antérieure à la mission 019 se charge sans erreur. Taille de la sauvegarde : environ 30 Ko.

## v5.4 — Mission 020, étape 1 : Smart TV géante et NOVA TV
- Salon : l'ancien écran géant est remplacé par une Smart TV 100 pouces (16:9, rendu « 4K » stylisé) sur un panneau mural effet marbre, meuble TV intégré, barre de son, deux enceintes colonnes, éclairage LED derrière l'écran (7 couleurs), grand canapé d'angle en cuir face à l'écran et table basse en marbre (collisions comprises, passage depuis la porte libre).
- 13 autres écrans connectés à NOVA TV : 9 chambres, bureau du PDG (nouvel écran mural), salle de cinéma, salle de jeux, espace du personnel (nouvel écran).
- Application et télécommande « NOVA TV » : 100 chaînes fictives en 9 catégories (01–15 actualités, 16–30 divertissement, 31–40 documentaires, 41–50 culture et histoire du Bénin, 51–60 sport, 61–70 musique, 71–80 cinéma et séries, 81–90 jeunesse, 91–100 cuisine, voyages et lifestyle), programme en cours et à venir, guide TV électronique (à l'écran et dans le téléphone), chaînes par numéro, volume et sourdine, pause des programmes enregistrés (impossible en direct), favoris, allumer/éteindre chaque écran.
- Images animées originales dessinées par le jeu (aucune chaîne réelle, aucun flux vidéo), son d'ambiance procédural discret selon le type de programme.
- Regarder la TV : assis sur le canapé, vue face à l'écran ; clavier PC : flèches (chaînes/volume), chiffres, P pause, G guide, F favori, M muet, L LED, E quitter. Sauvegarde : clé `tv`.

## v5.5 — Mission 020, étape 2 : mobilier de luxe (salon, salle à manger, hall d'entrée, couloirs)
- Salon : grands tapis, fauteuils en velours et en cuir, tables d'appoint en marbre, lampes, coin lecture, deux grandes bibliothèques garnies, deux vitrines éclairées, console d'entrée avec miroir, grandes plantes, baie vitrée avec grands rideaux, tableaux, deux lustres, appliques (les canapés et la table basse existants sont conservés).
- Salle à manger : table familiale de 12 places (noyer et marbre, même emprise que l'ancienne), 12 chaises rembourrées, couverts, grand buffet, deux vitrines à vaisselle, tableaux, lustre linéaire moderne, tapis, plantes, appliques.
- Hall d'entrée (galerie ouest) : grande console et miroir, fauteuils d'attente, vases sur colonnes, tapis, lustre, tableaux. Couloirs : consoles et miroirs, banquettes, tableaux, plantes, appliques.
- 8 tableaux originaux dessinés par le jeu (lagune au couchant, plage et cocotiers, façades colorées, art contemporain, portrait en pagne, marché, savane du nord, or et nuit).
- Collisions sur tous les meubles ; portes, couloirs et galerie vérifiés libres. Tout le mobilier est fusionné en 7 maillages (performances PC).

## v5.6 — Mission 020, étape 3 : chambres, suite et bureau du PDG
- 9 chambres (lits, armoires, bureaux, TV et salles de bain d'origine conservés) : grande tête de lit capitonnée, oreillers, plaid, banc en bout de lit, deux tables de chevet en marbre avec lampe, commode et grand miroir, dressing ouvert garni, fauteuil de lecture et lampadaire, meuble TV, tapis, fenêtre lumineuse et rideaux, tableau au-dessus du lit. Chambres d'enfants : couleurs vives et coffre à jouets.
- Suite parentale : tête de lit haute, causeuse face à la TV, table basse en marbre, coiffeuse avec miroir rond, lustre, plante.
- Bureau du PDG : bureau de direction d'origine habillé (sous-main en cuir, lampe, globe, plaque), fauteuil de direction ergonomique, bibliothèque murale sur tout le mur du fond, canapé de réception en cuir et table basse, deux vitrines, table de réunion de 6 places, décorations professionnelles (affiche NOVA GROUPE, certificat fictif, graphique, plan de la villa), tapis, lustre, plantes.
- Atlas de 16 œuvres originales (dont 4 décorations professionnelles et 4 illustrations stylisées pour l'étape suivante).
- Vérification automatique : depuis chaque porte, tous les points d'interaction (lit, armoire, bureau, douche, TV, NOVA Gestion) restent accessibles dans les 12 pièces meublées. 63 places assises repérées pour l'étape « interactions ».

## v5.7 — Mission 020, étape 4 : cuisine, cinéma, jeux, sport, terrasse et décoration murale
- Cuisine : 4 tabourets côté nord de l'îlot, 3 suspensions, plaque de cuisson et hotte inox, évier, corbeille de fruits, herbes aromatiques, table du petit-déjeuner (3 chaises), étagères à bocaux, horloge, tableau, plante. Les postes du cuisinier (îlot, réfrigérateur, plans de travail, plaques) restent libres.
- Cinéma : panneaux acoustiques en lattes de bois, tapis, éclairage des marches, bar à collations (machine à pop-corn, réfrigérateur à boissons), affiches, appliques.
- Salle de jeux : canapé face à la TV, deux bornes d'arcade, table de cartes (4 chaises), bar à jus de fruits (sans alcool) avec tabourets, cible de fléchettes, râtelier de queues de billard, enseigne lumineuse, tableaux.
- Salle de sport : sol amortissant, râtelier d'haltères, deux vélos, sac de frappe, tapis de yoga, fontaine à eau, étagère à serviettes, horloge.
- Pièces de service : revêtement effet marbre et miroir (salle de bains), étagères et horloge (buanderie), horloge, tableau et plante (personnel).
- Couloirs et hall : horloges et illustrations stylisées de lieux du Bénin (arche commémorative, village sur pilotis, Cotonou la nuit, façade afro-brésilienne de Porto-Novo).
- Extérieur : pergola en bois avec guirlande lumineuse et table d'été de 6 places (pelouse ouest), palmiers en pot, jardinières de part et d'autre de la porte de l'aile.
- 6 horloges murales à l'heure du jeu. Vérification automatique : les 19 pièces, les postes du cuisinier et la sortie vers le jardin restent accessibles ; 85 places assises repérées.

## v5.8 — Mission 020, étape 5 : éclairage et ambiance
- Éclairage intégré dans les 19 pièces et les couloirs : gorges LED au plafond, spots encastrés, éclairage indirect (têtes de lit, sous le meuble TV du salon, sous le buffet, sous les placards de la cuisine), LED derrière les télévisions murales, en plus des lustres, suspensions, lampes, appliques et vitrines éclairées.
- Réglage par pièce (allumé/éteint, intensité, 8 couleurs : blanc chaud, blanc neutre, ambre, bleu lagune, violet, vert NOVA, rose, rouge tamisé). Le réglage agit sur les luminaires ET sur la lumière réelle de la pièce où se trouve le joueur.
- Interrupteurs près de la porte de chaque pièce (et dans le hall), application « Ma Villa → Éclairage et ambiance », 5 ambiances pour toute la villa : journée, dîner, soirée cinéma, nuit (veilleuses colorées dans les chambres d'enfants), fête.
- Luminaires regroupés par pièce (21 maillages, visibles seulement dans l'aile) ; les lampes de la maison d'origine retrouvent leur couleur en sortant. Sauvegarde : clé `ambiance`.

## v5.9 — Mission 020, étape 6 : interactions avec les meubles et équipements
- S'asseoir sur 122 places (canapés et fauteuils, chaises de la salle à manger, de la cuisine, du bureau et de réunion, tabourets, bancs, sièges du cinéma, fauteuil de direction, chaises de la pergola) ; barre d'actions selon l'endroit : regarder NOVA TV (salon), travailler (bureaux), NOVA Gestion (fauteuil de direction), prendre un repas (salle à manger, table du petit-déjeuner), regarder un film (cinéma), profiter du jardin, se détendre, se lever. En se levant, le joueur est placé à un endroit libre (jamais dans un meuble).
- S'allonger sur les 9 lits (tête vers la tête de lit), avec « Dormir / sieste » et téléphone.
- Ranger ses articles (achats du marché et du supermarché, « Mes articles ») dans 20 rangements : commodes et dressings des chambres, buffet de la salle à manger, vitrine du bureau du PDG ; les reprendre à tout moment. Sauvegarde : clé `mobilier`.
- Chaises de bureau ajoutées dans les 9 chambres et 4 chaises dans l'espace du personnel.
- Personnel : les plaques de cuisson s'allument quand le cuisinier cuisine ; les lave-linge tournent quand la blanchisseuse travaille à la buanderie ; l'équipe d'entretien fait les lits à côté du lit ; les postes de travail sont choisis hors des meubles ; pendant les pauses, le personnel s'assoit dans l'espace du personnel.

## v6.0 — Mission 020, étape 7 : décoration intérieure
- Application « Décoration intérieure » (Ma Villa → 🛋️) : catalogue de 20 objets achetés en FCFA virtuels (fauteuils, canapés, poufs, tables d'appoint, consoles, bibliothèques basses, bancs, palmiers, ficus, cactus, lampadaires, sculptures en bois, vases, tapis, aquarium, tableaux au choix parmi 11 œuvres, miroirs, horloges, étagères murales), plusieurs modèles et 10 couleurs.
- Réserve (objets achetés non posés, revente à 50 %), liste des objets placés (couleur, modèle, déplacer, ranger).
- Placement dans l'aile : l'objet suit le joueur (devant lui, ou contre le mur regardé pour les objets muraux) ; R tourner, C couleur, M modèle, Entrée poser, Échap annuler ; barre de placement tactile. Refus expliqué si l'objet déborde sur un mur, touche un meuble, gêne une porte, un passage du personnel ou un point d'interaction.
- Touche E sur un objet posé : déplacer, tourner, couleur, modèle, ranger. Fauteuils, canapés, poufs et bancs posés deviennent des sièges utilisables. Collisions ajoutées et retirées avec l'objet.
- 4 configurations enregistrables (objets posés, thèmes des chambres, éclairage) et applicables à tout moment. Thèmes des chambres aussi modifiables depuis l'application. Sauvegarde : clé `decoration`.

## v6.1 — Mission 020, étape 8 : intégration finale et vérification
- Décoration intérieure : en plus des règles de placement, un calcul de chemin depuis la porte vérifie à chaque pose que tous les lits, sièges, rangements, interrupteurs, téléviseurs, points d'interaction et postes du cuisinier de la pièce restent accessibles ; sinon l'objet n'est pas posé (message explicatif).
- Corrections d'accès révélées par la vérification : les deux fauteuils en velours du salon de réception ont été reculés (les canapés latéraux d'origine étaient enfermés) ; la table basse du coin réception du bureau a été éloignée du canapé.
- Test de charge : 57 objets posés au hasard dans les 19 pièces (règles normales) — toutes les pièces restent entièrement accessibles.
- Sauvegarde : 19 systèmes (mission 019, TV, éclairage personnalisé, rangements, décoration et configurations) identiques après rechargement ; une sauvegarde antérieure à la mission 020 se charge sans erreur avec les réglages par défaut.
- Performances : environ 120 appels de rendu dans le salon de la villa ; l'intérieur de l'aile est masqué hors de la villa ; le mobilier est fusionné par finition et les luminaires par pièce.

## v6.2 — Mission 013, étape 5 : manette, volant et pédalier
- API Gamepad du navigateur (gratuite, sans pilote ni module) : manettes (disposition standard) et volants / pédaliers USB reconnus par le PC (Logitech, Thrustmaster, Fanatec, Moza… détectés automatiquement).
- Menu « Commandes » : choix Automatique / Clavier et souris / Manette / Volant et pédalier, périphérique en cours, barres de valeurs en direct, association des axes (direction, accélérateur, frein, embrayage) avec bouton « Détecter » (calibrage de la position de repos des pédales), inversion de chaque axe, association des boutons du volant (entrer/sortir, frein à main, rapport +/−, klaxon, vue), sensibilité de la direction et des pédales, zones mortes, réglages par défaut. Réglages enregistrés dans le navigateur.
- Conduite progressive des voitures et motos : accélérateur et frein dosables, direction proportionnelle (moins atténuée en vitesse au volant), le clavier reste utilisable en même temps.
- Boîte manuelle optionnelle pour les voitures : R, N, 1–5, vitesse et force propres à chaque rapport, frein moteur ; avec un axe d'embrayage associé, changement de rapport seulement embrayage enfoncé (sinon embrayage automatique) ; indicateur de rapport à l'écran ; clavier : Maj droite / Page haut, Ctrl droit / Page bas.
- La manette pilote tout le jeu : marche, caméra (stick droit), interactions (A = E), retour / pause, frein à main et saut, klaxon / carte, téléphone, croix directionnelle ; bateaux, avions et hélicoptères via les commandes simulées.


## v6.3 — Mission 021, étape 1 : terminal international et NOVA TRAVEL
- Terminal international visitable à l'aéroport (porte vitrée côté ville, parking « P ») : hall avec dalles de pierre et allée, tableau des départs en direct, comptoir d'information, 3 comptoirs d'enregistrement, contrôle des billets, contrôle de sécurité (portiques), boutique duty free et « Souvenirs du Bénin », restaurant « Le Golfe » et café, portes d'embarquement A1–A4 avec rangées de sièges.
- Salon VIP (accès avec la carte Platinum NOVA, 1 500 000 FCFA virtuels pour 30 jours) et salon privé du PDG (table de réunion reliée au bureau d'affaires, bar sans alcool, repos).
- 34 PNJ : agents d'enregistrement, d'information, de sécurité et d'embarquement, vendeurs, serveur, hôte VIP, pilotes, hôtesses, voyageurs avec valises (trajets vérifiés sans traverser les meubles).
- Application téléphone « ✈️ NOVA TRAVEL » : 12 destinations (Lomé, Accra, Abidjan, Dakar, Casablanca, Johannesburg, Paris, Londres, Istanbul, Dubaï, Montréal, New York), horaires des prochains départs avec statut, accès à l'aéroport (chauffeur), carte Platinum, suivi des dépenses de voyage.
- Compagnies (NOVA AIR, Air Lagune, Atlantique Airways), numéros de vol, horaires et tarifs sont FICTIFS. La réservation et les vols arrivent à l'étape 2 ; les villes étrangères ne sont pas encore jouables (le jeu le dit clairement).
- Sauvegarde : clé `travel` (carte Platinum, dépenses). Aucune fonctionnalité existante retirée.
