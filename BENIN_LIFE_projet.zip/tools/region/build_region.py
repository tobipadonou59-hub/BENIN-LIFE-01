# Génère src/region-data.js à partir de données géographiques vérifiables :
#  - OpenStreetMap (© contributeurs OpenStreetMap, licence ODbL) via Nominatim : centres des villes,
#    tracé de la RNIE 1, contours du lac Nokoué et de la lagune de Porto-Novo (fichiers osm/*.json) ;
#  - Natural Earth 1:10m (domaine public) : trait de côte (osm/coast_naturalearth.json).
# Projection : équirectangulaire locale centrée sur Cotonou, échelle 1:5 (1 m du jeu = 5 m réels),
# x vers l'est, z vers le sud (convention du jeu). Le centre de Cotonou réel n'est pas le rond-point du jeu :
# la latitude de référence aligne le littoral réel sur la plage du jeu (z ≈ 180).
import json, math, heapq, os
H = os.path.dirname(os.path.abspath(__file__))
LON0, LAT0, SC = 2.4253, 6.3503, 5.0
KX = 111320 * math.cos(math.radians(6.37)); KY = 110574
def P(lo, la): return ((lo - LON0) * KX / SC, -(la - LAT0) * KY / SC)
def rd(v): return round(v, 1)
CITY = (-200, 200, -200, 210)  # ville du jeu (non remplacée)
def in_city(x, z): return CITY[0] < x < CITY[1] and CITY[2] < z < CITY[3]

def dp(pts, tol):
    if len(pts) < 3: return pts
    a, b = pts[0], pts[-1]; dx, dz = b[0]-a[0], b[1]-a[1]; L = math.hypot(dx, dz) or 1e-9
    i, dm = 0, -1
    for k in range(1, len(pts)-1):
        p = pts[k]; d = abs(dx*(a[1]-p[1]) - dz*(a[0]-p[0])) / L
        if d > dm: i, dm = k, d
    if dm <= tol: return [a, b]
    return dp(pts[:i+1], tol)[:-1] + dp(pts[i:], tol)

# ---- villes (Nominatim) ----
towns = []
for name, f in [('Cotonou', 'Cotonou'), ('Porto-Novo', 'Porto-Novo'), ('Ouidah', 'Ouidah'), ('Pahou', 'Pahou'), ('Cocotomey', 'Cocotomey')]:
    r = json.load(open(f'{H}/osm/{f}.json'))[0]
    x, z = P(float(r['lon']), float(r['lat']))
    towns.append({'name': name, 'lat': float(r['lat']), 'lon': float(r['lon']), 'x': rd(x), 'z': rd(z), 'osm': r['display_name']})

# ---- routes : segments RNIE 1, découpés hors de la ville du jeu et des branches nord ----
segs = []
for s in json.load(open(f'{H}/osm/rnie1.json')).values():
    cur = []
    for lo, la in s['coords']:
        x, z = P(lo, la)
        drop = in_city(x, z) or (x < 0 and z < -1250) or z < -3600
        if drop:
            if len(cur) > 1: segs.append(cur)
            cur = []
        else: cur.append((x, z))
    if len(cur) > 1: segs.append(cur)
# graphe : sommets des segments + raccords entre extrémités proches (trous de la donnée ≤ 80 m de jeu)
nodes = []; idx = {}
def nid(p):
    k = (round(p[0], 1), round(p[1], 1))
    if k not in idx: idx[k] = len(nodes); nodes.append(k)
    return idx[k]
adj = {}
def edge(a, b, w):
    adj.setdefault(a, []).append((b, w)); adj.setdefault(b, []).append((a, w))
ends = []
GAP = 300.0  # trous de la donnée (segments non renvoyés par Nominatim) comblés en ligne droite
for s in segs:
    ids = [nid(p) for p in s]
    for a, b in zip(ids, ids[1:]): edge(a, b, math.dist(nodes[a], nodes[b]))
    ends += [ids[0], ids[-1]]
for i in ends:
    for j in ends:
        if i < j:
            d = math.dist(nodes[i], nodes[j])
            if 0 < d < GAP: edge(i, j, d * 1.5)
def nearest(p): return min(range(len(nodes)), key=lambda i: math.dist(nodes[i], p))
def path(a, b):
    dist = {a: 0}; prev = {}; q = [(0, a)]
    while q:
        d, u = heapq.heappop(q)
        if u == b: break
        if d > dist[u]: continue
        for v, w in adj.get(u, []):
            nd = d + w
            if nd < dist.get(v, 1e18): dist[v] = nd; prev[v] = u; heapq.heappush(q, (nd, v))
    out = [b]
    while out[-1] != a: out.append(prev[out[-1]])
    return [nodes[i] for i in reversed(out)]
T = {t['name']: (t['x'], t['z']) for t in towns}
GW, GE = (-100.0, -175.0), (175.0, -100.0)   # sorties nord (boulevard x = -100) et est (boulevard z = -100) de la ville du jeu
west = path(nearest((-98.5, -257.6)), nearest(T['Ouidah']))  # la RNIE 1 quitte Cotonou par le nord-ouest
east = path(nearest(GE), nearest(T['Porto-Novo']))
def clean(c):
    c = dp(c, 1.5); out = [c[0]]
    for p in c[1:]:
        if math.dist(p, out[-1]) > 3: out.append(p)
    return out
def gaps(c, nm):
    for a, b in zip(c, c[1:]):
        if math.dist(a, b) > 40: print(f'  raccord {nm} : {math.dist(a, b):.0f} m de jeu entre {a} et {b}')
gaps([GW] + west, 'ouest'); gaps([GE] + east, 'est')
west = clean([GW] + west); east = clean([GE] + east)
# ---- eau ----
def poly(f, tol):
    g = json.load(open(f'{H}/osm/{f}'))[0]['geojson']
    ring = [P(*p) for p in g['coordinates'][0][:-1]]
    h = len(ring) // 2
    pts = dp(ring[:h + 1], tol)[:-1] + dp(ring[h:] + [ring[0]], tol)[:-1]
    return [[rd(x), rd(z)] for x, z in pts]
lakes = [{'name': 'Lac Nokoué', 'pts': poly('Lac_Nokoué.json', 6)}, {'name': 'Lagune de Porto-Novo', 'pts': poly('Lagune_de_Porto-Novo.json', 4)}]
coast_ll = [(2.7054, 6.3682), (2.7018, 6.3682), (2.3058, 6.331), (2.2266, 6.3141), (1.8846, 6.2753)]  # Natural Earth 10m
coast = [[rd(x), rd(z)] for x, z in sorted(P(lo, la) for lo, la in coast_ll)]
data = {
    'source': 'OpenStreetMap (© contributeurs OpenStreetMap, ODbL) via Nominatim ; trait de côte Natural Earth 1:10m (domaine public)',
    'projection': {'lon0': LON0, 'lat0': LAT0, 'scale': SC, 'kx': round(KX, 1), 'ky': KY},
    'towns': towns,
    'roads': [{'name': 'RNIE 1 (vers Cocotomey, Pahou, Ouidah)', 'pts': [[rd(x), rd(z)] for x, z in west]},
              {'name': 'RNIE 1 (vers Sèmè-Kpodji et Porto-Novo)', 'pts': [[rd(x), rd(z)] for x, z in east]}],
    'lakes': lakes, 'coast': coast,
}
js = '// Fichier généré par tools/region/build_region.py — ne pas modifier à la main.\n// ' + data['source'] + '\nexport const REGION = ' + json.dumps(data, ensure_ascii=False, separators=(',', ':')) + ';\n'
open(os.path.join(H, '..', '..', 'src', 'region-data.js'), 'w').write(js)
print('ouest', len(west), 'pts', round(sum(math.dist(a, b) for a, b in zip(west, west[1:]))), 'm ; est', len(east), 'pts', round(sum(math.dist(a, b) for a, b in zip(east, east[1:]))), 'm')
print('lacs', [len(l['pts']) for l in lakes], 'taille', len(js))
for t in towns: print(t['name'], t['x'], t['z'])
