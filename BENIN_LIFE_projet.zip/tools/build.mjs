// Construit dist/game.js puis un fichier unique BENIN_LIFE.html jouable hors-ligne (double-clic).
import * as esbuild from 'esbuild';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';

const watch = process.argv.includes('--watch');

// Personnages GLB (Mission 003) : assets/characters/male.glb et female.glb sont intégrés s'ils existent.
import { existsSync } from 'node:fs';
{
  const lines = ['// Fichier généré par tools/build.mjs : modèles de personnages GLB disponibles.'];
  const entries = [];
  for (const k of ['male', 'female']) {
    if (existsSync(`assets/characters/${k}.glb`)) { lines.push(`import ${k} from '../assets/characters/${k}.glb';`); entries.push(k); }
  }
  lines.push(`export const CHARACTER_GLB = { ${entries.join(', ')} };`);
  writeFileSync('src/characterAssets.gen.js', lines.join('\n') + '\n');
  console.log('Personnages GLB intégrés :', entries.length ? entries.join(', ') : 'aucun (personnages procéduraux)');
}
mkdirSync('dist', { recursive: true });

function inline() {
  const html = readFileSync('index.html', 'utf8');
  const js = readFileSync('dist/game.js', 'utf8').replace(/<\/script/gi, '<\\/script');
  const fav = `<link rel="icon" type="image/png" href="data:image/png;base64,${readFileSync('assets/pwa/favicon.png').toString('base64')}">`;
  const out = html.replace('<script src="dist/game.js"></script>', () => `<script>\n${js}\n</script>`).replace(/<title>/i, () => fav + '\n<title>');
  writeFileSync('BENIN_LIFE.html', out);
  // version « page web » (publication en ligne, ex. iPhone) : contenu sans enveloppe <html>/<head>/<body>
  const web = out.replace(/<!doctype html>\s*/i, '').replace(/<html[^>]*>\s*/i, '').replace(/<\/?head>\s*/gi, '').replace(/<\/?body>\s*/gi, '').replace(/<\/html>\s*/i, '');
  writeFileSync('dist/benin-life-web.html', web);
  console.log(`BENIN_LIFE.html généré (${(out.length / 1024).toFixed(0)} Ko)`);
  pwa(out);
}

// version iPhone hors connexion : application web installable (écran d'accueil) + cache hors ligne (service worker)
function pwa(out) {
  const dir = 'dist/iphone-hors-ligne';
  mkdirSync(dir, { recursive: true });
  const version = Date.now().toString(36);
  const head = `<link rel="manifest" href="manifest.webmanifest">
<link rel="apple-touch-icon" href="apple-touch-icon.png">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Benin Life">
<meta name="theme-color" content="#0d0f12">
<script>if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) navigator.serviceWorker.register('sw.js');</script>`;
  writeFileSync(`${dir}/index.html`, out.replace(/<title>/i, head + '\n<title>'));
  writeFileSync(`${dir}/manifest.webmanifest`, JSON.stringify({
    name: 'BENIN LIFE : Cotonou Open World', short_name: 'Benin Life', start_url: './', scope: './', display: 'fullscreen', orientation: 'landscape',
    background_color: '#0d0f12', theme_color: '#0d0f12',
    icons: [{ src: 'icon-192.png', sizes: '192x192', type: 'image/png' }, { src: 'icon-512.png', sizes: '512x512', type: 'image/png' }],
  }, null, 2));
  // réseau d'abord (les mises à jour arrivent dès qu'il y a internet), cache si pas de connexion.
  // Ce fichier ne change plus d'une version à l'autre : seuls index.html et les icônes sont à remplacer.
  writeFileSync(`${dir}/sw.js`, `// Cache hors ligne de BENIN LIFE : réseau d'abord, cache si pas de connexion
const CACHE = 'benin-life';
const FILES = ['./', './index.html', './manifest.webmanifest', './apple-touch-icon.png', './icon-192.png', './icon-512.png'];
self.addEventListener('install', (e) => { e.waitUntil(caches.open(CACHE).then((c) => Promise.all(FILES.map((f) => c.add(f).catch(() => null)))).then(() => self.skipWaiting())); });
self.addEventListener('activate', (e) => { e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;
  e.respondWith(fetch(e.request).then((r) => {
    if (r && r.ok) { const copy = r.clone(); caches.open(CACHE).then((c) => c.put(e.request, copy)); }
    return r;
  }).catch(() => caches.match(e.request, { ignoreSearch: true }).then((r) => r || caches.match('./index.html'))));
});
`);
  for (const f of ['apple-touch-icon.png', 'icon-192.png', 'icon-512.png']) writeFileSync(`${dir}/${f}`, readFileSync(`assets/pwa/${f}`));
}

const opts = {
  entryPoints: ['src/main.js'], bundle: true, minify: true, format: 'iife', target: 'es2020',
  outfile: 'dist/game.js', legalComments: 'none', logLevel: 'info', loader: { '.jpg': 'dataurl', '.png': 'dataurl', '.glb': 'dataurl' },
  plugins: [{ name: 'inline', setup(b) { b.onEnd((r) => { if (!r.errors.length) inline(); }); } }],
};
if (watch) { const ctx = await esbuild.context(opts); await ctx.watch(); console.log('Surveillance des fichiers…'); }
else await esbuild.build(opts);
