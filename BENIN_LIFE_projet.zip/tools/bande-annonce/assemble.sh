#!/bin/bash
# Assemble les images des 4 groupes + la musique en MP4 H.264 / AAC
set -e
D=/tmp/claude-0/-home-user/00d7eff4-63c9-5360-9b14-3ec08c1b3cec/scratchpad/film
rm -rf $D/all && mkdir -p $D/all
for f in $D/frames/g*/f*.jpg; do ln -s "$f" "$D/all/$(basename $f)"; done
N=$(ls $D/all | wc -l); echo "images: $N"
python3 - <<PY
import os
fs=sorted(os.listdir("$D/all")); idx=[int(f[1:6]) for f in fs]
miss=[i for i in range(idx[-1]+1) if i not in set(idx)]
print("manquantes:", len(miss), miss[:10])
PY
DUR=$(python3 -c "print($N/24)")
ffmpeg -hide_banner -loglevel error -y -framerate 24 -i $D/all/f%05d.jpg -i $D/musique.wav \
  -vf "fade=t=in:st=0:d=0.6,fade=t=out:st=$(python3 -c "print($N/24-1.0)"):d=1.0,format=yuv420p" \
  -c:v libx264 -preset slow -crf 18 -profile:v high -c:a aac -b:a 192k -shortest -movflags +faststart \
  $D/BENIN_LIFE_bande_annonce.mp4
ls -la $D/BENIN_LIFE_bande_annonce.mp4
ffprobe -v error -show_entries format=duration:stream=codec_name,width,height,r_frame_rate -of compact $D/BENIN_LIFE_bande_annonce.mp4
