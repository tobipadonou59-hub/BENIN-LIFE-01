# Bande-son originale de la bande-annonce BENIN LIFE (synthèse pure, aucun échantillon externe).
# Rythme en 12/8 avec une cloche double (motif « standard » de 7 frappes), hochets, tambours, basse, nappes,
# mélodie façon kalimba, effets synchronisés sur les plans (souffles, réacteur, pluie, tonnerre, scintillements).
import numpy as np, wave, sys

SR = 44100
CUTS = [0, 4.5, 9.5, 14.5, 19.5, 24.5, 28.5, 34.0, 40.0, 45.0, 50.0, 56.0, 59.208, 64.708]
DUR = CUTS[-1] + 0.3
N = int(DUR * SR)
L = np.zeros(N); R = np.zeros(N)
rng = np.random.default_rng(7)
PULSE = 0.2           # croche (12/8, noire pointée = 100 bpm)
BAR = PULSE * 12

def env_exp(n, tau):
    t = np.arange(n) / SR
    return np.exp(-t / tau)

def add(sig, t0, pan=0.0, gain=1.0):
    i = int(t0 * SR)
    if i >= N: return
    sig = sig[: N - i] * gain
    L[i:i + len(sig)] += sig * (1 - max(0, pan))
    R[i:i + len(sig)] += sig * (1 + min(0, pan))

def sine(f, dur, phase=0):
    t = np.arange(int(dur * SR)) / SR
    return np.sin(2 * np.pi * f * t + phase)

def bell(f, dur=0.5):
    n = int(dur * SR)
    s = sine(f, dur) * 1.0 + sine(f * 2.76, dur) * 0.45 + sine(f * 5.4, dur) * 0.2
    return s * env_exp(n, 0.12) * np.minimum(1, np.arange(n) / 40)

def drum(f0, f1, dur=0.45, tau=0.16):
    n = int(dur * SR); t = np.arange(n) / SR
    f = f1 + (f0 - f1) * np.exp(-t / 0.05)
    ph = 2 * np.pi * np.cumsum(f) / SR
    return np.sin(ph) * env_exp(n, tau)

def noise(dur):
    return rng.standard_normal(int(dur * SR))

def lowpass(x, a):
    # filtre passe-bas d'ordre 1 (a proche de 1 = plus sombre)
    y = np.empty_like(x); acc = 0.0
    for i in range(0, len(x), 1):
        acc = acc * a + x[i] * (1 - a); y[i] = acc
    return y

def lp_fast(x, k):
    # passe-bas rapide par moyenne glissante
    k = max(1, int(k)); c = np.cumsum(np.concatenate([[0], x]))
    y = (c[k:] - c[:-k]) / k
    return np.concatenate([y, np.zeros(len(x) - len(y))])

def shaker(dur=0.07):
    n = int(dur * SR); x = noise(dur); x = x - lp_fast(x, 6)
    return x * env_exp(n, 0.025)

def pluck(f, dur=0.9):
    n = int(dur * SR)
    s = sine(f, dur) + 0.35 * sine(f * 2, dur) + 0.12 * sine(f * 3.01, dur)
    return s * env_exp(n, 0.28) * np.minimum(1, np.arange(n) / 30)

def pad(freqs, dur, att=0.8, rel=1.0):
    n = int(dur * SR); t = np.arange(n) / SR
    s = np.zeros(n)
    for f in freqs:
        for d in (-0.6, 0.6):
            ph = 2 * np.pi * (f + d) * t
            s += (2 * ((ph / (2 * np.pi)) % 1) - 1) * 0.5 + np.sin(ph) * 0.5
    s = lp_fast(s, 18)
    e = np.minimum(1, t / att) * np.minimum(1, (dur - t) / rel)
    return s * e / len(freqs)

def swoosh(dur=0.9, rising=True):
    n = int(dur * SR); t = np.arange(n) / SR; x = noise(dur)
    k = np.linspace(40, 6, n) if rising else np.linspace(6, 40, n)
    out = np.zeros(n); seg = 2048
    for i in range(0, n, seg):
        out[i:i + seg] = lp_fast(x[i:i + seg], k[i])
    e = (t / dur) ** 2 if rising else (1 - t / dur) ** 1.5
    return out * e

def section(t):
    for i in range(len(CUTS) - 1):
        if CUTS[i] <= t < CUTS[i + 1]: return i
    return len(CUTS) - 2

# ---------------- rythme ----------------
BELL = [0, 2, 4, 5, 7, 9, 11]
A4 = 220.0
progression = [(220.0, [220, 261.6, 329.6]), (196.0, [196, 246.9, 293.7]), (174.6, [174.6, 220, 261.6]), (196.0, [196, 246.9, 293.7])]
t = 0.0; bar = 0
while t < DUR - 0.2:
    sec = section(t)
    intro, rain, inv, fin = sec == 0, sec == 9, sec == 11, sec == 12
    groove = 0.0 if intro else (0.55 if rain else (0.6 if inv else 1.0))
    for p in range(12):
        tp = t + p * PULSE
        if tp >= DUR - 0.2: break
        if p in BELL:
            hi = p not in (0, 7)
            add(bell(1350 if hi else 960), tp, pan=-0.35, gain=(0.10 if hi else 0.13) * (0.5 if intro else 1) * (1 if not fin else 0.8))
        if groove > 0:
            add(shaker(), tp, pan=0.4, gain=(0.05 if p % 3 else 0.09) * groove)
            if p in (0, 6) or (sec >= 7 and p in (3, 9) and sec not in (9, 11)):
                add(drum(120, 52, 0.5, 0.18), tp, gain=0.55 * groove)
            if p in (4, 10) and sec >= 2:
                add(drum(260, 170, 0.25, 0.08), tp, pan=0.2, gain=0.22 * groove)   # tambour parlant aigu
    # basse et nappe selon l'accord
    root, chord = progression[bar % 4]
    if not intro:
        for p in (0, 3, 6, 9):
            tp = t + p * PULSE
            n = int(0.55 * SR); b = (sine(root / 2, 0.55) * 0.8 + sine(root, 0.55) * 0.25) * env_exp(n, 0.25)
            add(b, tp, gain=0.32 * (0.6 if rain else 1))
    if sec >= 1:
        add(pad(chord, BAR + 0.4, 0.6, 0.6), t, gain=0.08 * (1.3 if sec in (8, 10) else 1))
    t += BAR; bar += 1

# mélodie pentatonique façon kalimba à partir du garage
scale = [440, 523.3, 587.3, 659.3, 784, 880, 1046.5]
motif = [0, 2, 3, 4, 3, 2, 4, 5, 4, 3, 2, 0]
t = CUTS[6]
k = 0
while t < CUTS[12]:
    sec = section(t)
    if sec not in (9,):
        add(pluck(scale[motif[k % len(motif)]] * (0.5 if sec == 11 else 1)), t, pan=0.25 * np.sin(k), gain=0.13)
    t += PULSE * (2 if k % 3 == 2 else 1); k += 1

# intro : nappe et montée
add(pad([110, 164.8, 220, 329.6], 4.8, 2.0, 0.8), 0.0, gain=0.14)
add(swoosh(1.6), CUTS[1] - 1.6, gain=0.12)
# souffles aux transitions
for c in CUTS[2:-1]:
    add(swoosh(0.7), c - 0.7, pan=0.0, gain=0.07)
    add(drum(90, 40, 0.8, 0.3), c, gain=0.35)

# aéroport : grondement de réacteur qui monte (décollage) puis souffle de croisière
s0, s1 = CUTS[7], CUTS[9]
n = int((s1 - s0) * SR); x = noise(s1 - s0); tt = np.arange(n) / SR
roar = lp_fast(x, 10) * np.minimum(1, tt / 2.5) * np.where(tt < 6, 1.0, 0.55) * np.minimum(1, (s1 - s0 - tt) / 0.6)
whine = np.sin(2 * np.pi * np.cumsum(900 + 700 * np.minimum(1, tt / 4)) / SR) * 0.08 * np.where(tt < 6, np.minimum(1, tt / 3), 0.3)
add(roar + whine, s0, gain=0.22)

# pluie tropicale + tonnerre
s0, s1 = CUTS[9], CUTS[10]
n = int((s1 - s0 + 0.8) * SR); tt = np.arange(n) / SR
rainn = (noise(s1 - s0 + 0.8) - lp_fast(noise(s1 - s0 + 0.8), 3) * 0) * np.minimum(1, tt / 0.5) * np.minimum(1, (s1 - s0 + 0.8 - tt) / 0.8)
add(lp_fast(rainn, 3) * 0.6, s0, pan=0.0, gain=0.16)
th = lp_fast(noise(3.2), 60) * env_exp(int(3.2 * SR), 0.9)
add(th * 6, s0 + 2.6, gain=0.5)
add(lp_fast(noise(0.4), 4) * env_exp(int(0.4 * SR), 0.08), s0 + 2.6, gain=0.35)

# pouvoirs : scintillements mystiques
for k in range(24):
    tp = CUTS[10] + 0.2 + k * 0.22
    add(bell([1568, 1760, 2093, 2349][k % 4], 0.6), tp, pan=np.sin(k * 1.3) * 0.8, gain=0.05)
for tp in (CUTS[10] + 0.3, CUTS[10] + 2.0, CUTS[10] + 3.9):
    add(drum(70, 35, 1.2, 0.45), tp, gain=0.6); add(swoosh(0.6, False), tp, gain=0.08)

# final : grand accord tenu
add(drum(80, 38, 1.6, 0.6), CUTS[12], gain=0.8)
add(pad([110, 220, 277.2, 329.6, 440], CUTS[13] - CUTS[12] + 0.3, 0.3, 2.5), CUTS[12], gain=0.22)
for k, f in enumerate([440, 554.4, 659.3, 880]):
    add(bell(f, 1.2), CUTS[12] + 0.15 * k, pan=(k - 1.5) * 0.3, gain=0.1)

# mixage : fondu, normalisation, écriture
fade = np.ones(N); fl = int(1.2 * SR); fade[-fl:] = np.linspace(1, 0, fl); fade[:int(0.3 * SR)] = np.linspace(0, 1, int(0.3 * SR))
L *= fade; R *= fade
peak = max(np.abs(L).max(), np.abs(R).max()); L = L / peak * 0.89; R = R / peak * 0.89
st = np.stack([L, R], 1)
pcm = (st * 32767).astype(np.int16)
with wave.open(sys.argv[1], 'wb') as w:
    w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())
print('ok', DUR, 's')
