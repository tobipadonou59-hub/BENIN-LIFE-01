// Tournage de la bande-annonce de BENIN LIFE : rendu image par image du vrai jeu (mode __manual), caméra scénarisée.
const { chromium } = require('playwright');
const fs = require('fs');
const OUT = process.argv[2], ONLY = process.argv[3] && process.argv[3] !== 'all' ? process.argv[3].split(',') : null, STEP = process.argv[4] === 'preview' ? 0 : +(process.argv[4] || 1);
fs.mkdirSync(OUT, { recursive: true });
const FPS = 24;

// ---------- code exécuté dans la page ----------
function pageSetup() {
  const B = window.__BL, THREE_V = (x, y, z) => ({ x, y, z });
  const st = document.createElement('style');
  st.textContent = `#hud,#touch,#pw-bar,#equip-hud,#dash,#fhud,#toast,#prompt,#loading,#menu,#pause,#imenu,#photo{display:none!important}
  #cine{position:fixed;inset:0;pointer-events:none;z-index:60;font-family:"DejaVu Sans",Arial,sans-serif;color:#fff}
  #cine .bar{position:absolute;left:0;right:0;height:9vh;background:#000}#cine .bar.t{top:0}#cine .bar.b{bottom:0}
  #cine .lt{position:absolute;left:6vw;bottom:15vh;max-width:70vw}
  #cine .lt .fl{display:flex;width:150px;height:6px;margin-bottom:12px}#cine .fl i{flex:2;background:#008751}#cine .fl i+i{flex:3;background:#fcd116}#cine .fl i+i+i{background:#e8112d}
  #cine .lt h2{margin:0;font-size:46px;font-weight:900;letter-spacing:.02em;text-shadow:0 4px 18px rgba(0,0,0,.7)}
  #cine .lt p{margin:6px 0 0;font-size:22px;font-weight:600;color:#f3ead8;text-shadow:0 2px 10px rgba(0,0,0,.8)}
  #cine .ti{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center}
  #cine .ti h1{margin:0;font-size:120px;font-weight:900;letter-spacing:.03em;line-height:.95;text-shadow:0 8px 40px rgba(0,0,0,.6)}#cine .ti h1 span{color:#fcd116}
  #cine .ti .fl{display:flex;width:340px;height:9px;margin:0 0 26px}
  #cine .ti h3{margin:20px 0 0;font-size:30px;letter-spacing:.42em;font-weight:700;color:#f3ead8;text-shadow:0 3px 14px rgba(0,0,0,.7)}
  #cine .ti p{margin:28px 0 0;font-size:24px;font-weight:600;color:#fff;text-shadow:0 2px 12px rgba(0,0,0,.8)}
  #cine .vg{position:absolute;inset:0;background:radial-gradient(ellipse at center,rgba(0,0,0,0) 55%,rgba(0,0,0,.45))}`;
  document.head.appendChild(st);
  const ov = document.createElement('div'); ov.id = 'cine';
  ov.innerHTML = '<div class="vg"></div><div class="bar t"></div><div class="bar b"></div><div class="lt"><div class="fl"><i></i><i></i><i></i></div><h2></h2><p></p></div><div class="ti"></div>';
  document.body.appendChild(ov);
  const lt = ov.querySelector('.lt'), ti = ov.querySelector('.ti');
  const ease = (x) => x < 0 ? 0 : x > 1 ? 1 : x * x * (3 - 2 * x);
  const lerp = (a, b, k) => a + (b - a) * k;
  const fade = (t, d, a = 0.6, b = 0.5) => Math.min(ease(t / a), ease((d - t) / b));
  window.CINE = {
    lt(t, d, h, p, t0 = 0.5) { lt.style.display = h ? 'block' : 'none'; if (!h) return; lt.querySelector('h2').textContent = h; lt.querySelector('p').textContent = p; const k = fade(t - t0, d - t0 - 0.2, 0.5, 0.45); lt.style.opacity = k; lt.style.transform = `translateX(${(1 - k) * -30}px)`; },
    title(html, k) { ti.innerHTML = html; ti.style.opacity = k; ti.style.display = html ? 'flex' : 'none'; },
    cam(px, py, pz, tx, ty, tz, fov = 55) { const c = B.camera; c.position.set(px, py, pz); c.lookAt(tx, ty, tz); if (c.fov !== fov) { c.fov = fov; c.updateProjectionMatrix(); } },
    sky(time, mode = 'clear', wet = 0) {
      const E = B.env, W = E.weather; E.time = time; E.timeScale = 0.0; W.setMode(mode);
      Object.assign(W.p, { clear: { cover: 0.56, overcast: 0, rain: 0, fog: 0 }, cloudy: { cover: 0.34, overcast: 0.5, rain: 0, fog: 0.08 }, rain: { cover: 0.1, overcast: 1, rain: 1, fog: 0.42 } }[mode]);
      W.wet = wet; E.lastEnvTime = -99; E.lastEnvKey = '';
    },
    reset() { const P = B.player; if (P.inCar) { const c = P.inCar; c.occupied = false; P.inCar = null; } P.mesh.visible = false; for (const k of ['ShiftLeft', 'KeyW', 'KeyS', 'KeyA', 'KeyD', 'Space']) B.input.setVirtual(k, false); if (B.inventory.open) B.inventory.toggle(false); for (const k of Object.keys(B.powers.active)) B.powers.stop(k); ti.style.display = 'none'; lt.style.display = 'none'; },
    lerp, ease, fade,
  };
}

// ---------- plans ----------
const SHOTS = [
  { id: 'title', d: 4.5, setup: `CINE.reset(); CINE.sky(8.2); __BL.player.pos.set(0,0,40);`,
    cine: `const a=0.25+t*0.05; CINE.cam(Math.sin(a)*165, 82-t*2, 40+Math.cos(a)*165, 0, 6, 40, 52);
      CINE.title('<div class="fl"><i></i><i></i><i></i></div><h1>BENIN <span>LIFE</span></h1><h3>COTONOU OPEN WORLD</h3>', CINE.fade(t-0.4, d-0.4, 1.0, 0.6)); CINE.lt(t,d,'','');` },
  { id: 'amazone', d: 5, setup: `CINE.reset(); CINE.sky(8.6); __BL.player.pos.set(0,0,160);`,
    cine: `const k=CINE.ease(t/d); CINE.cam(CINE.lerp(48,-38,k), CINE.lerp(16,12,k), CINE.lerp(138,150,k), 0, 9, 176, 50); CINE.lt(t,d,'Cotonou, Bénin','Place de l’Amazone — hommage aux guerrières du Dahomey');` },
  { id: 'rues', d: 5, setup: `CINE.reset(); CINE.sky(10.4); __BL.player.pos.set(40,0,-4);`,
    cine: `const k=CINE.ease(t/d); CINE.cam(CINE.lerp(82,40,k), 2.3, -4.5, CINE.lerp(30,0,k), 2.2, -1, 58); CINE.lt(t,d,'Zémidjans, taxis et piétons','Une ville vivante, de jour comme de nuit');` },
  { id: 'dantokpa', d: 5, setup: `CINE.reset(); CINE.sky(12.2); __BL.player.pos.set(-50,0,50);`,
    cine: `const a=1.1+t*0.12; CINE.cam(-50+Math.sin(a)*48, 24-t*0.8, 50+Math.cos(a)*48, -50, 2, 50, 52); CINE.lt(t,d,'Marché Dantokpa','L’un des plus grands marchés d’Afrique de l’Ouest');` },
  { id: 'cote', d: 5, setup: `CINE.reset(); CINE.sky(18.2); __BL.player.pos.set(60,0,172);`,
    cine: `const k=CINE.ease(t/d); CINE.cam(CINE.lerp(110,60,k), CINE.lerp(3.5,5,k), CINE.lerp(176,182,k), CINE.lerp(30,-10,k), 3, 215, 55); CINE.lt(t,d,'La côte atlantique','Plages, cocotiers et couchers de soleil sur le golfe de Guinée');` },
  { id: 'maison', d: 4, setup: `CINE.reset(); CINE.sky(17.7); __BL.player.pos.set(-44,0,108);`,
    cine: `const k=CINE.ease(t/d); CINE.cam(CINE.lerp(-30,-50,k), CINE.lerp(7,4.5,k), CINE.lerp(94,103,k), -45, 3.5, 124, 55); CINE.lt(t,d,'Ta maison à Cotonou','Manger, dormir, se doucher, s’habiller : la vie quotidienne');` },
  { id: 'garage', d: 5.5, setup: `CINE.reset(); CINE.sky(19.15); const B=__BL,G=B.garage; B.player.pos.set(-42,0,-112);
      if (G.owned.length<5) for (const [id,c] of [['rosso48',0xc8102e],['cybra',0xb8bcc2],['gkaiser',0x15171a],['urca',0xe8762a],['stallion',0xf2c200]]) G.take(id,c);
      [...G.live.values()].slice(0,5).forEach((c,i)=>{ c.pos.set(-56+i*7,0,-119); c.heading=0.25; c.vel.set(0,0); c.lat=0; c.sync(); });`,
    cine: `const k=CINE.ease(t/d); CINE.cam(CINE.lerp(-62,-22,k), CINE.lerp(3.4,2.6,k), -103.5, CINE.lerp(-48,-36,k), 1, -119, 50); CINE.lt(t,d,'Garage AUTO CONCEPT','13 véhicules à conduire — phares, tableau de bord, vue intérieure');` },
  { id: 'decollage', d: 6, setup: `CINE.reset(); CINE.sky(16.2); const B=__BL,A=B.airport; const r=A.recs.find(x=>x.id==='jumbo747'); const pl=A.spawnPlane(r); A.toRunway(pl);
      pl.pos.set(-760,0,-20); pl.speed=72; pl.throttle=1; pl.occupied=true; B.player.inCar=pl; B.player.mesh.visible=false; B.input.setVirtual('ShiftLeft',true); window.__pl=pl;`,
    cine: `const pl=window.__pl; __BL.input.setVirtual('KeyW', t>0.8 && t<2.6); if (t>3.4 && pl.gearDown && pl.airborne) pl.gearDown=false;
      CINE.cam(-905, 4.5, 34, pl.pos.x, pl.pos.y+6, pl.pos.z, CINE.lerp(48,34,CINE.ease(t/d))); CINE.lt(t,d,'Aéroport de Cotonou','8 avions pilotables, du petit avion au géant à double pont');` },
  { id: 'survol', d: 5, setup: `CINE.reset(); CINE.sky(16.9); const B=__BL,A=B.airport; const r=A.recs.find(x=>x.id==='aeria380'); const pl=A.spawnPlane(r);
      pl.pos.set(-330,240,95); pl.heading=Math.PI/2; pl.pitch=0.02; pl.roll=0; pl.speed=88; pl.throttle=0.62; pl.airborne=true; pl.gearDown=false; pl.gearT=0; pl.occupied=true; B.player.inCar=pl; window.__pl=pl;`,
    cine: `const pl=window.__pl; CINE.cam(pl.pos.x-62+t*4, pl.pos.y+16, pl.pos.z+70-t*3, pl.pos.x+18, pl.pos.y+2, pl.pos.z, 50); CINE.lt(t,d,'Survole Cotonou','Banlieues, lagune et océan : un monde de 12 km sur 12');` },
  { id: 'pluie', d: 5, setup: `CINE.reset(); CINE.sky(15.4,'rain',1); __BL.player.pos.set(2,0,60);`,
    cine: `const k=CINE.ease(t/d); if (Math.abs(t-2.6)<0.03) { __BL.env.weather.flash=1; } CINE.cam(2.5, CINE.lerp(2.6,2.1,k), CINE.lerp(72,54,k), 1.5, 2.0, 0, 56); CINE.lt(t,d,'Météo tropicale dynamique','Soleil, nuages, averses, brume, orages et sol mouillé');` },
  { id: 'pouvoirs', d: 6, setup: `CINE.reset(); CINE.sky(19.55); const B=__BL,P=B.player,W=B.powers; P.pos.set(22,0,159); P.facing=0.4; P.mesh.visible=true; if (W.level<10) W.addXp(2700); W.energy=W.maxEnergy; for (const k in W.cd) delete W.cd[k]; window.__cast=0;`,
    cine: `const B=__BL,P=B.player,W=B.powers; W.energy=W.maxEnergy; if (t>0.3 && window.__cast===0){ W.cast('feu'); window.__cast=1; } if (t>2.0 && window.__cast===1){ for (const k in W.cd) delete W.cd[k]; W.cast('gardiens'); window.__cast=2; } if (t>3.9 && window.__cast===2){ for (const k in W.cd) delete W.cd[k]; W.cast('eveil'); window.__cast=3; }
      const a=2.4+t*0.3; CINE.cam(P.pos.x+Math.sin(a)*8.5, 3.0, P.pos.z+Math.cos(a)*8.5, P.pos.x, 1.5, P.pos.z, 55); CINE.lt(t,d,'20 pouvoirs mystiques','Un univers fantastique inspiré des couleurs et motifs du Bénin');` },
  { id: 'inventaire', d: 3.2, setup: `CINE.reset(); CINE.sky(10.5); const B=__BL; B.player.pos.set(2,0,60); B.inventory.toggle(true); B.inventory.sel='recade'; B.inventory.renderUI();`,
    cine: `CINE.cam(2.5, 3, 80, 1.5, 2, 30, 55); CINE.lt(t,d,'',''); if (Math.abs(t-1.6)<0.03) { __BL.inventory.sel='drone_colibri'; __BL.inventory.renderUI(); }` },
  { id: 'fin', d: 5.5, setup: `CINE.reset(); CINE.sky(18.25); __BL.player.pos.set(0,0,120);`,
    cine: `const k=CINE.ease(t/d); CINE.cam(CINE.lerp(60,10,k), CINE.lerp(44,38,k), CINE.lerp(300,272,k), 0, 14, 100, 52);
      CINE.title('<div class="fl"><i></i><i></i><i></i></div><h1>BENIN <span>LIFE</span></h1><h3>COTONOU OPEN WORLD</h3><p>Jouable gratuitement sur PC et iPhone • Un hommage au Bénin</p>', CINE.fade(t-0.5, d-0.3, 1.0, 0.8));` },
];

(async () => {
  const b = await chromium.launch({ args: ['--use-gl=swiftshader', '--enable-webgl', '--ignore-gpu-blocklist'] });
  const ctx = await b.newContext({ viewport: { width: 1280, height: 720 } });
  const p = await ctx.newPage(); const errs = []; p.on('pageerror', (e) => errs.push(e.message));
  await p.addInitScript(() => { try { localStorage.setItem('beninlife.settings', JSON.stringify({ quality: 'medium', music: false, muted: true, showFps: false })); localStorage.removeItem('beninlife.save.v1'); } catch (e) {} });
  await p.goto('file:///home/user/benin-life/BENIN_LIFE.html'); await p.waitForFunction(() => window.__BL, null, { timeout: 240000 });
  await p.evaluate(() => { const B = window.__BL; B.input.requestLock = () => {}; B.input._hadLock = false; B.startPlaying(); B.ui.toast('', 0.01); });
  await p.waitForTimeout(1500);
  await p.evaluate(pageSetup);
  await p.evaluate(() => { window.__manual = true; window.__stepReq = 0; window.__rendered = 0; });
  let idx = 0; const t0 = Date.now();
  for (const s of SHOTS) {
    const n = Math.round(s.d * FPS);
    if (ONLY && !ONLY.includes(s.id)) { idx += n; continue; }
    await p.evaluate(`(()=>{ ${s.setup} window.__shotF=0; window.__cine=(dt,time)=>{ const t=window.__shotF/${FPS}, d=${s.d}; ${s.cine} window.__shotF++; }; })()`);
    // 3 images de mise en place (non enregistrées) : ombres, éclairage d'ambiance, objets proches
    for (let w = 0; w < 3; w++) { await p.evaluate(() => { window.__shotF = 0; const B = window.__BL; if (B.state() !== 'playing') { B.input._hadLock = false; B.startPlaying(); } const r = window.__rendered; window.__stepReq = 1; return new Promise((res) => { const k = () => window.__rendered > r ? res() : requestAnimationFrame(k); k(); }); }); }
    await p.evaluate(() => { window.__shotF = 0; });
    if (STEP === 0) { // aperçu : 3 images par plan (début, milieu, fin)
      for (const f of [Math.round(n * 0.15), Math.round(n * 0.55), n - 3]) {
        await p.evaluate((ff) => { window.__shotF = ff; const B = window.__BL; if (B.state() !== 'playing') { B.input._hadLock = false; B.startPlaying(); } const r = window.__rendered; window.__stepReq = 1; return new Promise((res) => { const k = () => window.__rendered > r ? res() : requestAnimationFrame(k); k(); }); }, f);
        await p.screenshot({ path: `${OUT}/${s.id}-${f}.jpg`, type: 'jpeg', quality: 80, timeout: 240000 });
      }
      idx += n; continue;
    }
    for (let f = 0; f < n; f++) {
      await p.evaluate(() => { const B = window.__BL; if (B.state() !== 'playing') { B.input._hadLock = false; B.startPlaying(); } const r = window.__rendered; window.__stepReq = 1; return new Promise((res) => { const k = () => window.__rendered > r ? res() : requestAnimationFrame(k); k(); }); });
      if (f % STEP === 0) await p.screenshot({ path: `${OUT}/f${String(idx).padStart(5, '0')}.jpg`, type: 'jpeg', quality: 90, timeout: 240000 });
      idx++;
      if (f % 24 === 0) fs.writeFileSync(`${OUT}/progress.txt`, `${s.id} ${f}/${n} total ${idx} ${Math.round((Date.now() - t0) / 1000)}s errs ${errs.length}\n`);
    }
  }
  fs.writeFileSync(`${OUT}/progress.txt`, `DONE ${idx} frames ${Math.round((Date.now() - t0) / 1000)}s errs ${errs.length} ${errs.slice(0, 3).join(' | ')}\n`);
  await b.close();
})();
