// Test automatisé : lance le jeu dans Chromium, vérifie l'absence d'erreurs, joue quelques secondes et prend des captures.
const { chromium } = require('playwright');
const path = require('path');
const out = process.argv[2] || '.';
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
  const errors = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') errors.push(m.type() + ': ' + m.text()); else console.log('console:', m.text()); });
  await page.goto('file://' + path.resolve(__dirname, '..', 'BENIN_LIFE.html'));
  await page.waitForFunction(() => window.__BL, null, { timeout: 180000 });
  await page.waitForTimeout(2500);
  await page.screenshot({ path: out + '/01-menu.png', timeout: 240000 });
  await page.click('[data-act=play]');
  await page.waitForTimeout(800);
  await page.screenshot({ path: out + '/02-start.png', timeout: 240000 });
  // marche + course
  await page.keyboard.down('KeyW'); await page.keyboard.down('ShiftLeft');
  await page.waitForTimeout(1500);
  await page.keyboard.up('ShiftLeft'); await page.keyboard.up('KeyW');
  const p1 = await page.evaluate(() => ({ x: __BL.player.pos.x, z: __BL.player.pos.z }));
  console.log('player after walk', p1);
  await page.screenshot({ path: out + '/03-walk.png', timeout: 240000 });
  // monter dans la voiture
  await page.evaluate(() => { const c = __BL.cars[0]; __BL.player.pos.set(c.pos.x + 2, 0, c.pos.z); });
  await page.waitForTimeout(200);
  await page.keyboard.press('KeyE');
  await page.waitForTimeout(200);
  const inCar = await page.evaluate(() => !!__BL.player.inCar);
  console.log('inCar', inCar);
  await page.keyboard.down('KeyW');
  await page.waitForTimeout(2500);
  await page.keyboard.down('KeyA'); await page.waitForTimeout(600); await page.keyboard.up('KeyA');
  await page.waitForTimeout(800);
  await page.keyboard.up('KeyW');
  const c = await page.evaluate(() => ({ x: __BL.cars[0].pos.x, z: __BL.cars[0].pos.z, v: __BL.cars[0].speed }));
  console.log('car', c);
  await page.screenshot({ path: out + '/04-drive.png', timeout: 240000 });
  // nuit
  await page.evaluate(() => { __BL.env.time = 20.5; });
  await page.waitForTimeout(800);
  await page.screenshot({ path: out + '/05-night.png', timeout: 240000 });
  // pause
  await page.keyboard.press('KeyP');
  await page.waitForTimeout(300);
  await page.screenshot({ path: out + '/06-pause.png', timeout: 240000 });
  const info = await page.evaluate(() => ({ calls: __BL.renderer.info.render.calls, tris: __BL.renderer.info.render.triangles, stats: __BL.world.stats, mem: performance.memory && performance.memory.usedJSHeapSize }));
  console.log('render', info);
  console.log('ERRORS', errors.length ? errors : 'none');
  await browser.close();
})();
