// Génère CATALOGUE_OBJETS.md à partir de src/items.js (source unique du catalogue)
import { writeFileSync } from 'node:fs';
import { ITEMS, CATEGORIES, RARITIES, SLOTS, effectText, buildItemModel } from '../src/items.js';
let md = '# BENIN LIFE — Catalogue des 50 équipements (Mission 009)\n\nObjets imaginaires de jeu : aucun objet réel, aucun mécanisme d’arme, effets uniquement visuels ou liés aux jauges du jeu.\nModèles 3D procéduraux (formes simples fusionnées, 1 à 3 appels de dessin par objet).\n\n';
for (const c of CATEGORIES) {
  const list = ITEMS.filter((i) => i.cat === c.id);
  md += `## ${c.icon} ${c.label} (${list.length})\n\n| # | Objet | Rareté | Emplacement | Triangles | Effet en jeu |\n|---|---|---|---|---|---|\n`;
  list.forEach((it, i) => { md += `| ${i + 1} | **${it.name}** — ${it.desc} | ${RARITIES[it.rarity].label} | ${SLOTS[it.slot]} | ${Math.round(buildItemModel(it).userData.tris)} | ${effectText(it)} |\n`; });
  md += '\n';
}
md += `**Total : ${ITEMS.length} objets.** Raretés : ${Object.values(RARITIES).map((r) => `${r.label} ${ITEMS.filter((i) => RARITIES[i.rarity] === r).length}`).join(', ')}.\n`;
writeFileSync(new URL('../CATALOGUE_OBJETS.md', import.meta.url), md);
console.log('ok', ITEMS.length, CATEGORIES.map((c) => ITEMS.filter((i) => i.cat === c.id).length).join('/'), new Set(ITEMS.map((i) => i.id)).size);
