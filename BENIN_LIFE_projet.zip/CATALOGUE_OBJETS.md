# BENIN LIFE — Catalogue des 50 équipements (Mission 009)

Objets imaginaires de jeu : aucun objet réel, aucun mécanisme d’arme, effets uniquement visuels ou liés aux jauges du jeu.
Modèles 3D procéduraux (formes simples fusionnées, 1 à 3 appels de dessin par objet).

## 🛡 Protection (10)

| # | Objet | Rareté | Emplacement | Triangles | Effet en jeu |
|---|---|---|---|---|---|
| 1 | **Casque de zémidjan** — Le casque jaune des conducteurs de zémidjan, renforcé et aéré pour la chaleur de Cotonou. | Commun | Tête | 584 | Objet porté : visible sur le personnage |
| 2 | **Gilet réfléchissant** — Gilet orange à bandes argentées : on te voit de loin, même la nuit sur la route des pêches. | Commun | Corps | 168 | Objet porté : visible sur le personnage |
| 3 | **Bouclier en raphia tressé** — Bouclier décoratif tressé à la main. G : posture de garde. | Peu commun | Main | 1268 | Touche G (ou bouton ✦) : utiliser |
| 4 | **Imperméable des pluies** — Long imperméable bleu avec capuche, taillé pour les averses de juin. | Peu commun | Corps | 352 | Objet porté : visible sur le personnage |
| 5 | **Lunettes anti-harmattan** — Lunettes enveloppantes contre la poussière de l’harmattan. | Commun | Tête | 824 | Objet porté : visible sur le personnage |
| 6 | **Casque de chantier** — Casque blanc des chantiers de la Haie Vive, avec visière. | Commun | Tête | 320 | Objet porté : visible sur le personnage |
| 7 | **Plastron en calebasse** — Plastron sculpté dans une calebasse, gravé de motifs géométriques. | Rare | Corps | 904 | Objet porté : visible sur le personnage |
| 8 | **Sac à dos renforcé** — Sac rigide aux couleurs nationales pour transporter tout ton équipement. | Peu commun | Dos | 60 | Objet porté : visible sur le personnage |
| 9 | **Bouclier prismatique** — Disque imaginaire qui projette un dôme de lumière. G : dôme lumineux (effet visuel, 4 s). | Épique | Main | 596 | Touche G (ou bouton ✦) : utiliser |
| 10 | **Cape en pagne wax** — Cape légère cousue dans un pagne wax aux motifs vifs. | Rare | Dos | 368 | Objet porté : visible sur le personnage |

## 📡 Gadgets (10)

| # | Objet | Rareté | Emplacement | Triangles | Effet en jeu |
|---|---|---|---|---|---|
| 1 | **Drone-colibri** — Mini-drone imaginaire en forme de colibri. G : il tourne autour de toi pendant 15 s. | Rare | Main | 796 | Touche G (ou bouton ✦) : utiliser |
| 2 | **Radio Kpakpato** — Petite radio de marché qui diffuse les nouvelles du quartier. G : joue un air (son réel du jeu). | Peu commun | Main | 148 | Touche G (ou bouton ✦) : utiliser |
| 3 | **Montre-carte holographique** — Montre qui projette la carte de la ville. G : ouvre la carte générale. | Rare | Main | 684 | Touche G (ou bouton ✦) : utiliser |
| 4 | **Scanner de quartier** — Compte les passants et les véhicules autour de toi. G : onde de détection (35 m) et résultat réel. | Rare | Main | 332 | Touche G (ou bouton ✦) : utiliser |
| 5 | **Lance-bulles** — Jouet coloré qui souffle des bulles de savon. G : nuée de bulles. | Commun | Main | 640 | Touche G (ou bouton ✦) : utiliser |
| 6 | **Canne à confettis** — Canne de fête des carnavals de Cotonou. G : pluie de confettis. | Peu commun | Main | 448 | Touche G (ou bouton ✦) : utiliser |
| 7 | **Disque-boomerang lumineux** — Disque de lumière imaginaire qui revient toujours. G : lancer et retour (effet visuel). | Épique | Main | 628 | Touche G (ou bouton ✦) : utiliser |
| 8 | **Projecteur d’hologrammes** — Projette un drapeau du Bénin lumineux au-dessus de toi. G : hologramme (6 s). | Épique | Main | 140 | Touche G (ou bouton ✦) : utiliser |
| 9 | **Talkie-walkie zém** — Talkie des zémidjans pour s’appeler entre carrefours. G : signal sonore et ondes. | Commun | Main | 332 | Touche G (ou bouton ✦) : utiliser |
| 10 | **Lunettes à vision ambrée** — Verres teintés qui donnent à la ville une lumière dorée. Équipées : filtre ambré à l’écran. | Rare | Tête | 332 | Équipé : filtre ambré à l’écran |

## 🔧 Outils (10)

| # | Objet | Rareté | Emplacement | Triangles | Effet en jeu |
|---|---|---|---|---|---|
| 1 | **Lampe torche** — Lampe robuste pour les rues sans éclairage. G : allumer / éteindre le faisceau. | Commun | Main | 168 | Touche G (ou bouton ✦) : utiliser |
| 2 | **Clé à molette géante** — L’outil favori des mécaniciens de rue. G : coup de clé et étincelles. | Commun | Main | 80 | Touche G (ou bouton ✦) : utiliser |
| 3 | **Parapluie tricolore** — Grand parapluie vert, jaune, rouge. G : ouvrir / fermer. | Peu commun | Main | 432 | Touche G (ou bouton ✦) : utiliser |
| 4 | **Cabas « Ghana Must Go »** — Le grand sac à carreaux des marchés. G : balancer le sac. | Commun | Main | 356 | Touche G (ou bouton ✦) : utiliser |
| 5 | **Gourde isotherme** — Eau fraîche toute la journée. G : boire (+8 énergie, une fois par minute). | Commun | Main | 124 | Touche G (ou bouton ✦) : utiliser |
| 6 | **Calebasse d’eau** — Calebasse remplie d’eau fraîche. G : s’asperger (+10 propreté, une fois par minute). | Peu commun | Main | 628 | Touche G (ou bouton ✦) : utiliser |
| 7 | **Jumelles** — Pour observer le port et la plage. G : zoom de la caméra (activer / désactiver). | Commun | Main | 236 | Touche G (ou bouton ✦) : utiliser |
| 8 | **Appareil photo** — Pour garder des souvenirs de Cotonou. G : prendre une vraie capture d’écran du jeu. | Peu commun | Main | 148 | Touche G (ou bouton ✦) : utiliser |
| 9 | **Boussole côtière** — Boussole en laiton des pêcheurs. G : direction et distance réelles vers ta maison (M) et la mer. | Peu commun | Main | 444 | Touche G (ou bouton ✦) : utiliser |
| 10 | **Balai en paille** — Balai traditionnel des cours de maison. G : un coup de balai (poussière). | Commun | Main | 404 | Touche G (ou bouton ✦) : utiliser |

## ⚡ Énergie (10)

| # | Objet | Rareté | Emplacement | Triangles | Effet en jeu |
|---|---|---|---|---|---|
| 1 | **Pile solaire de poche** — Panneau pliant accroché au dos. Passif : endurance +25 % de récupération le jour. | Peu commun | Dos | 48 | Passif : endurance +25 % de récupération (le jour) |
| 2 | **Cellule-éclair** — Réservoir d’énergie imaginaire. Passif : endurance +40 % de récupération. | Rare | Dos | 224 | Passif : endurance +40 % de récupération |
| 3 | **Bâton à impulsion** — Bâton imaginaire et inoffensif qui émet un anneau de lumière. G : onde lumineuse (visuel). | Rare | Main | 948 | Touche G (ou bouton ✦) : utiliser |
| 4 | **Gant cinétique** — Gant imaginaire qui crée un souffle d’air. G : rafale de vent (visuel). | Épique | Main | 880 | Touche G (ou bouton ✦) : utiliser |
| 5 | **Noyau plasma (jouet)** — Boule lumineuse en verre, simple jouet. G : la boule s’élève et tourbillonne. | Rare | Main | 560 | Touche G (ou bouton ✦) : utiliser |
| 6 | **Canon à vent « Harmattan »** — Souffleur imaginaire qui soulève un nuage de sable doré. G : bourrasque de sable (visuel). | Épique | Main | 444 | Touche G (ou bouton ✦) : utiliser |
| 7 | **Orbe de lumière** — Petite sphère lumineuse qui flotte au-dessus de ton épaule et éclaire la nuit. | Rare | Dos | 572 | Équipé : animation visible sur le personnage |
| 8 | **Batterie de secours** — Batterie de sac à dos. Passif : endurance +15 % de récupération. | Commun | Dos | 36 | Passif : endurance +15 % de récupération |
| 9 | **Bobine statique** — Bobine de cuivre imaginaire. G : petits arcs bleus (visuel, sans danger). | Peu commun | Main | 948 | Touche G (ou bouton ✦) : utiliser |
| 10 | **Réacteur de poche** — Le module d’énergie imaginaire ultime. Passif : endurance +60 % de récupération, tuyères lumineuses. | Légendaire | Dos | 432 | Passif : endurance +60 % de récupération |

## ★ Spéciaux (10)

| # | Objet | Rareté | Emplacement | Triangles | Effet en jeu |
|---|---|---|---|---|---|
| 1 | **Récade royale (réplique)** — Réplique décorative d’une récade, bâton de messager des rois d’Abomey. G : lever la récade (étincelles dorées). | Légendaire | Main | 720 | Touche G (ou bouton ✦) : utiliser |
| 2 | **Masque de carnaval** — Masque de fête peint de couleurs vives pour les carnavals de Cotonou. | Rare | Tête | 328 | Objet porté : visible sur le personnage |
| 3 | **Tam-tam doré** — Tambour décoré de fils dorés. G : joue un rythme (son réel du jeu). | Épique | Main | 752 | Touche G (ou bouton ✦) : utiliser |
| 4 | **Couronne de cauris** — Couronne ornée de cauris, coquillages longtemps utilisés comme monnaie et parure. | Épique | Tête | 2548 | Objet porté : visible sur le personnage |
| 5 | **Pirogue de Ganvié (miniature)** — Miniature sculptée des pirogues de la cité lacustre. G : la montrer fièrement. | Rare | Main | 320 | Touche G (ou bouton ✦) : utiliser |
| 6 | **Trophée de Dantokpa** — Trophée du meilleur négociateur du grand marché. G : le brandir (confettis). | Épique | Main | 764 | Touche G (ou bouton ✦) : utiliser |
| 7 | **Clé de la ville** — Clé dorée d’honneur de Cotonou, objet de collection. G : éclat doré. | Légendaire | Main | 652 | Touche G (ou bouton ✦) : utiliser |
| 8 | **Carte ancienne de la côte** — Vieille carte décorative de la côte des Esclaves. G : ouvre la carte générale de la ville. | Rare | Main | 124 | Touche G (ou bouton ✦) : utiliser |
| 9 | **Chapeau à plume** — Chapeau de cérémonie en feutre avec une longue plume. | Peu commun | Tête | 420 | Objet porté : visible sur le personnage |
| 10 | **Drapeau du Bénin** — Le drapeau national porté fièrement dans le dos. Il flotte au vent. | Rare | Dos | 92 | Équipé : animation visible sur le personnage |

**Total : 50 objets.** Raretés : Commun 13, Peu commun 12, Rare 14, Épique 8, Légendaire 3.
